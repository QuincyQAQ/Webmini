/*! Copyright 2026 Aditude Inc. All rights reserved. Raven v1.20.0-69wxiu 2026-04-29T19:45:41.031Z production */
(() => {
    var __webpack_modules__ = {
            7182(e, t, r) {
                "use strict";
                var s = this && this.__createBinding || (Object.create ? function(e, t, r, s) {
                        void 0 === s && (s = r);
                        var o = Object.getOwnPropertyDescriptor(t, r);
                        o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                            enumerable: !0,
                            get: function() {
                                return t[r]
                            }
                        }), Object.defineProperty(e, s, o)
                    } : function(e, t, r, s) {
                        void 0 === s && (s = r), e[s] = t[r]
                    }),
                    o = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    n = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var r in e) "default" !== r && Object.prototype.hasOwnProperty.call(e, r) && s(t, e, r);
                        return o(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.PrebidJSEventsClient = void 0;
                const i = n(r(5949)),
                    a = n(r(1739));
                t.PrebidJSEventsClient = class {
                    constructor(e, t, r) {
                        this.methodDescriptorLogBidJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogBidJs", i.MethodType.UNARY, a.LogBidJsRequest, a.LogBidJsResponse, e => e.serializeBinary(), a.LogBidJsResponse.deserializeBinary), this.methodDescriptorLogNotificationJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogNotificationJs", i.MethodType.UNARY, a.LogNotificationJsRequest, a.LogNotificationJsResponse, e => e.serializeBinary(), a.LogNotificationJsResponse.deserializeBinary), this.methodDescriptorLogOrtbRequestJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogOrtbRequestJs", i.MethodType.UNARY, a.LogOrtbRequestJsRequest, a.LogOrtbRequestJsResponse, e => e.serializeBinary(), a.LogOrtbRequestJsResponse.deserializeBinary), this.methodDescriptorLogImpressionRequestJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogImpressionRequestJs", i.MethodType.UNARY, a.LogImpressionRequestJsRequest, a.LogImpressionRequestJsResponse, e => e.serializeBinary(), a.LogImpressionRequestJsResponse.deserializeBinary), this.methodDescriptorLogBidderRequestJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogBidderRequestJs", i.MethodType.UNARY, a.LogBidderRequestJsRequest, a.LogBidderRequestJsResponse, e => e.serializeBinary(), a.LogBidderRequestJsResponse.deserializeBinary), this.methodDescriptorLogTestJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogTestJs", i.MethodType.UNARY, a.LogTestJsRequest, a.LogTestJsResponse, e => e.serializeBinary(), a.LogTestJsResponse.deserializeBinary), this.methodDescriptorLogErrorsJs = new i.MethodDescriptor("/prebid_js_events.PrebidJSEvents/LogErrorsJs", i.MethodType.UNARY, a.LogErrorsJsRequest, a.LogErrorsJsResponse, e => e.serializeBinary(), a.LogErrorsJsResponse.deserializeBinary), r || (r = {}), t || (t = {}), r.format = "binary", this.client_ = new i.GrpcWebClientBase(r), this.hostname_ = e.replace(/\/+$/, ""), this.credentials_ = t, this.options_ = r
                    }
                    logBidJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogBidJs", e, t || {}, this.methodDescriptorLogBidJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogBidJs", e, t || {}, this.methodDescriptorLogBidJs)
                    }
                    logNotificationJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogNotificationJs", e, t || {}, this.methodDescriptorLogNotificationJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogNotificationJs", e, t || {}, this.methodDescriptorLogNotificationJs)
                    }
                    logOrtbRequestJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogOrtbRequestJs", e, t || {}, this.methodDescriptorLogOrtbRequestJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogOrtbRequestJs", e, t || {}, this.methodDescriptorLogOrtbRequestJs)
                    }
                    logImpressionRequestJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogImpressionRequestJs", e, t || {}, this.methodDescriptorLogImpressionRequestJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogImpressionRequestJs", e, t || {}, this.methodDescriptorLogImpressionRequestJs)
                    }
                    logBidderRequestJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogBidderRequestJs", e, t || {}, this.methodDescriptorLogBidderRequestJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogBidderRequestJs", e, t || {}, this.methodDescriptorLogBidderRequestJs)
                    }
                    logTestJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogTestJs", e, t || {}, this.methodDescriptorLogTestJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogTestJs", e, t || {}, this.methodDescriptorLogTestJs)
                    }
                    logErrorsJs(e, t, r) {
                        return void 0 !== r ? this.client_.rpcCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogErrorsJs", e, t || {}, this.methodDescriptorLogErrorsJs, r) : this.client_.unaryCall(this.hostname_ + "/prebid_js_events.PrebidJSEvents/LogErrorsJs", e, t || {}, this.methodDescriptorLogErrorsJs)
                    }
                }
            },
            6442(e, t, r) {
                "use strict";
                var s = this && this.__createBinding || (Object.create ? function(e, t, r, s) {
                        void 0 === s && (s = r);
                        var o = Object.getOwnPropertyDescriptor(t, r);
                        o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                            enumerable: !0,
                            get: function() {
                                return t[r]
                            }
                        }), Object.defineProperty(e, s, o)
                    } : function(e, t, r, s) {
                        void 0 === s && (s = r), e[s] = t[r]
                    }),
                    o = this && this.__exportStar || function(e, t) {
                        for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || s(t, e, r)
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.PrebidJSEventsClient = void 0;
                var n = r(7182);
                Object.defineProperty(t, "PrebidJSEventsClient", {
                    enumerable: !0,
                    get: function() {
                        return n.PrebidJSEventsClient
                    }
                }), o(r(1739), t), o(r(5646), t)
            },
            1739(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4439);
                o.object.extend(proto, i);
                var a = r(6802);
                o.object.extend(proto, a);
                var g = r(6835);
                o.object.extend(proto, g);
                var u = r(1605);
                o.object.extend(proto, u);
                var d = r(3766);
                o.object.extend(proto, d);
                var l = r(3368);
                o.object.extend(proto, l);
                var c = r(9811);
                o.object.extend(proto, c), o.exportSymbol("proto.prebid_js_events.LogBidJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogBidJsResponse", null, n), o.exportSymbol("proto.prebid_js_events.LogBidderRequestJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogBidderRequestJsResponse", null, n), o.exportSymbol("proto.prebid_js_events.LogErrorsJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogErrorsJsResponse", null, n), o.exportSymbol("proto.prebid_js_events.LogImpressionRequestJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogImpressionRequestJsResponse", null, n), o.exportSymbol("proto.prebid_js_events.LogNotificationJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogNotificationJsResponse", null, n), o.exportSymbol("proto.prebid_js_events.LogOrtbRequestJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogOrtbRequestJsResponse", null, n), o.exportSymbol("proto.prebid_js_events.LogTestJsRequest", null, n), o.exportSymbol("proto.prebid_js_events.LogTestJsResponse", null, n), proto.prebid_js_events.LogBidJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogBidJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogBidJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogBidJsRequest.displayName = "proto.prebid_js_events.LogBidJsRequest"), proto.prebid_js_events.LogBidJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogBidJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogBidJsResponse.displayName = "proto.prebid_js_events.LogBidJsResponse"), proto.prebid_js_events.LogNotificationJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogNotificationJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogNotificationJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogNotificationJsRequest.displayName = "proto.prebid_js_events.LogNotificationJsRequest"), proto.prebid_js_events.LogNotificationJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogNotificationJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogNotificationJsResponse.displayName = "proto.prebid_js_events.LogNotificationJsResponse"), proto.prebid_js_events.LogOrtbRequestJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogOrtbRequestJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogOrtbRequestJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogOrtbRequestJsRequest.displayName = "proto.prebid_js_events.LogOrtbRequestJsRequest"), proto.prebid_js_events.LogOrtbRequestJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogOrtbRequestJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogOrtbRequestJsResponse.displayName = "proto.prebid_js_events.LogOrtbRequestJsResponse"), proto.prebid_js_events.LogImpressionRequestJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogImpressionRequestJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogImpressionRequestJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogImpressionRequestJsRequest.displayName = "proto.prebid_js_events.LogImpressionRequestJsRequest"), proto.prebid_js_events.LogImpressionRequestJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogImpressionRequestJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogImpressionRequestJsResponse.displayName = "proto.prebid_js_events.LogImpressionRequestJsResponse"), proto.prebid_js_events.LogBidderRequestJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogBidderRequestJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogBidderRequestJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogBidderRequestJsRequest.displayName = "proto.prebid_js_events.LogBidderRequestJsRequest"), proto.prebid_js_events.LogBidderRequestJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogBidderRequestJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogBidderRequestJsResponse.displayName = "proto.prebid_js_events.LogBidderRequestJsResponse"), proto.prebid_js_events.LogTestJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogTestJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogTestJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogTestJsRequest.displayName = "proto.prebid_js_events.LogTestJsRequest"), proto.prebid_js_events.LogTestJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogTestJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogTestJsResponse.displayName = "proto.prebid_js_events.LogTestJsResponse"), proto.prebid_js_events.LogErrorsJsRequest = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.prebid_js_events.LogErrorsJsRequest.repeatedFields_, null)
                }, o.inherits(proto.prebid_js_events.LogErrorsJsRequest, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogErrorsJsRequest.displayName = "proto.prebid_js_events.LogErrorsJsRequest"), proto.prebid_js_events.LogErrorsJsResponse = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.prebid_js_events.LogErrorsJsResponse, s.Message), o.DEBUG && !COMPILED && (proto.prebid_js_events.LogErrorsJsResponse.displayName = "proto.prebid_js_events.LogErrorsJsResponse"), proto.prebid_js_events.LogBidJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogBidJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogBidJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogBidJsRequest.toObject = function(e, t) {
                    var r = {
                        bidsList: s.Message.toObjectList(t.getBidsList(), i.BidJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogBidJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogBidJsRequest;
                    return proto.prebid_js_events.LogBidJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogBidJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new i.BidJs;
                            t.readMessage(r, i.BidJs.deserializeBinaryFromReader), e.addBids(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogBidJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogBidJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogBidJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getBidsList()).length > 0 && t.writeRepeatedMessage(1, r, i.BidJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogBidJsRequest.prototype.getBidsList = function() {
                    return s.Message.getRepeatedWrapperField(this, i.BidJs, 1)
                }, proto.prebid_js_events.LogBidJsRequest.prototype.setBidsList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogBidJsRequest.prototype.addBids = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.BidJs, t)
                }, proto.prebid_js_events.LogBidJsRequest.prototype.clearBidsList = function() {
                    return this.setBidsList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogBidJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogBidJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogBidJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogBidJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogBidJsResponse;
                    return proto.prebid_js_events.LogBidJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogBidJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogBidJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogBidJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogBidJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogBidJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogBidJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.prebid_js_events.LogNotificationJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogNotificationJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogNotificationJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogNotificationJsRequest.toObject = function(e, t) {
                    var r = {
                        notificationsList: s.Message.toObjectList(t.getNotificationsList(), a.NotificationJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogNotificationJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogNotificationJsRequest;
                    return proto.prebid_js_events.LogNotificationJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogNotificationJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new a.NotificationJs;
                            t.readMessage(r, a.NotificationJs.deserializeBinaryFromReader), e.addNotifications(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogNotificationJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogNotificationJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogNotificationJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getNotificationsList()).length > 0 && t.writeRepeatedMessage(1, r, a.NotificationJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogNotificationJsRequest.prototype.getNotificationsList = function() {
                    return s.Message.getRepeatedWrapperField(this, a.NotificationJs, 1)
                }, proto.prebid_js_events.LogNotificationJsRequest.prototype.setNotificationsList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogNotificationJsRequest.prototype.addNotifications = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.NotificationJs, t)
                }, proto.prebid_js_events.LogNotificationJsRequest.prototype.clearNotificationsList = function() {
                    return this.setNotificationsList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogNotificationJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogNotificationJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogNotificationJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogNotificationJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogNotificationJsResponse;
                    return proto.prebid_js_events.LogNotificationJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogNotificationJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogNotificationJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogNotificationJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogNotificationJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogNotificationJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogNotificationJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogOrtbRequestJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogOrtbRequestJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.toObject = function(e, t) {
                    var r = {
                        ortbRequestList: s.Message.toObjectList(t.getOrtbRequestList(), g.OrtbRequestJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogOrtbRequestJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogOrtbRequestJsRequest;
                    return proto.prebid_js_events.LogOrtbRequestJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new g.OrtbRequestJs;
                            t.readMessage(r, g.OrtbRequestJs.deserializeBinaryFromReader), e.addOrtbRequest(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogOrtbRequestJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getOrtbRequestList()).length > 0 && t.writeRepeatedMessage(1, r, g.OrtbRequestJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.prototype.getOrtbRequestList = function() {
                    return s.Message.getRepeatedWrapperField(this, g.OrtbRequestJs, 1)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.prototype.setOrtbRequestList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.prototype.addOrtbRequest = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.OrtbRequestJs, t)
                }, proto.prebid_js_events.LogOrtbRequestJsRequest.prototype.clearOrtbRequestList = function() {
                    return this.setOrtbRequestList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogOrtbRequestJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogOrtbRequestJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogOrtbRequestJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogOrtbRequestJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogOrtbRequestJsResponse;
                    return proto.prebid_js_events.LogOrtbRequestJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogOrtbRequestJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogOrtbRequestJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogOrtbRequestJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogOrtbRequestJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogOrtbRequestJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogOrtbRequestJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogImpressionRequestJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogImpressionRequestJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.toObject = function(e, t) {
                    var r = {
                        impressionRequestList: s.Message.toObjectList(t.getImpressionRequestList(), u.ImpressionRequestJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogImpressionRequestJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogImpressionRequestJsRequest;
                    return proto.prebid_js_events.LogImpressionRequestJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new u.ImpressionRequestJs;
                            t.readMessage(r, u.ImpressionRequestJs.deserializeBinaryFromReader), e.addImpressionRequest(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogImpressionRequestJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getImpressionRequestList()).length > 0 && t.writeRepeatedMessage(1, r, u.ImpressionRequestJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.prototype.getImpressionRequestList = function() {
                    return s.Message.getRepeatedWrapperField(this, u.ImpressionRequestJs, 1)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.prototype.setImpressionRequestList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.prototype.addImpressionRequest = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.ImpressionRequestJs, t)
                }, proto.prebid_js_events.LogImpressionRequestJsRequest.prototype.clearImpressionRequestList = function() {
                    return this.setImpressionRequestList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogImpressionRequestJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogImpressionRequestJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogImpressionRequestJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogImpressionRequestJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogImpressionRequestJsResponse;
                    return proto.prebid_js_events.LogImpressionRequestJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogImpressionRequestJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogImpressionRequestJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogImpressionRequestJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogImpressionRequestJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogImpressionRequestJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogImpressionRequestJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogBidderRequestJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogBidderRequestJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.toObject = function(e, t) {
                    var r = {
                        bidderRequestList: s.Message.toObjectList(t.getBidderRequestList(), d.BidderRequestJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogBidderRequestJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogBidderRequestJsRequest;
                    return proto.prebid_js_events.LogBidderRequestJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new d.BidderRequestJs;
                            t.readMessage(r, d.BidderRequestJs.deserializeBinaryFromReader), e.addBidderRequest(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogBidderRequestJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogBidderRequestJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogBidderRequestJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getBidderRequestList()).length > 0 && t.writeRepeatedMessage(1, r, d.BidderRequestJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.prototype.getBidderRequestList = function() {
                    return s.Message.getRepeatedWrapperField(this, d.BidderRequestJs, 1)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.prototype.setBidderRequestList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.prototype.addBidderRequest = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.BidderRequestJs, t)
                }, proto.prebid_js_events.LogBidderRequestJsRequest.prototype.clearBidderRequestList = function() {
                    return this.setBidderRequestList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogBidderRequestJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogBidderRequestJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogBidderRequestJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogBidderRequestJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogBidderRequestJsResponse;
                    return proto.prebid_js_events.LogBidderRequestJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogBidderRequestJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogBidderRequestJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogBidderRequestJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogBidderRequestJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogBidderRequestJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogBidderRequestJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.prebid_js_events.LogTestJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogTestJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogTestJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogTestJsRequest.toObject = function(e, t) {
                    var r = {
                        testsList: s.Message.toObjectList(t.getTestsList(), l.TestJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogTestJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogTestJsRequest;
                    return proto.prebid_js_events.LogTestJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogTestJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new l.TestJs;
                            t.readMessage(r, l.TestJs.deserializeBinaryFromReader), e.addTests(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogTestJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogTestJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogTestJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getTestsList()).length > 0 && t.writeRepeatedMessage(1, r, l.TestJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogTestJsRequest.prototype.getTestsList = function() {
                    return s.Message.getRepeatedWrapperField(this, l.TestJs, 1)
                }, proto.prebid_js_events.LogTestJsRequest.prototype.setTestsList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogTestJsRequest.prototype.addTests = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.TestJs, t)
                }, proto.prebid_js_events.LogTestJsRequest.prototype.clearTestsList = function() {
                    return this.setTestsList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogTestJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogTestJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogTestJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogTestJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogTestJsResponse;
                    return proto.prebid_js_events.LogTestJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogTestJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogTestJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogTestJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogTestJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogTestJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogTestJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.prebid_js_events.LogErrorsJsRequest.repeatedFields_ = [1], s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogErrorsJsRequest.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogErrorsJsRequest.toObject(e, this)
                }, proto.prebid_js_events.LogErrorsJsRequest.toObject = function(e, t) {
                    var r = {
                        errorsList: s.Message.toObjectList(t.getErrorsList(), c.ErrorsJs.toObject, e)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogErrorsJsRequest.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogErrorsJsRequest;
                    return proto.prebid_js_events.LogErrorsJsRequest.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogErrorsJsRequest.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = new c.ErrorsJs;
                            t.readMessage(r, c.ErrorsJs.deserializeBinaryFromReader), e.addErrors(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogErrorsJsRequest.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogErrorsJsRequest.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogErrorsJsRequest.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorsList()).length > 0 && t.writeRepeatedMessage(1, r, c.ErrorsJs.serializeBinaryToWriter)
                }, proto.prebid_js_events.LogErrorsJsRequest.prototype.getErrorsList = function() {
                    return s.Message.getRepeatedWrapperField(this, c.ErrorsJs, 1)
                }, proto.prebid_js_events.LogErrorsJsRequest.prototype.setErrorsList = function(e) {
                    return s.Message.setRepeatedWrapperField(this, 1, e)
                }, proto.prebid_js_events.LogErrorsJsRequest.prototype.addErrors = function(e, t) {
                    return s.Message.addToRepeatedWrapperField(this, 1, e, proto.schema_registry.prebid_js.ErrorsJs, t)
                }, proto.prebid_js_events.LogErrorsJsRequest.prototype.clearErrorsList = function() {
                    return this.setErrorsList([])
                }, s.Message.GENERATE_TO_OBJECT && (proto.prebid_js_events.LogErrorsJsResponse.prototype.toObject = function(e) {
                    return proto.prebid_js_events.LogErrorsJsResponse.toObject(e, this)
                }, proto.prebid_js_events.LogErrorsJsResponse.toObject = function(e, t) {
                    var r = {
                        errorMessage: s.Message.getFieldWithDefault(t, 1, "")
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.prebid_js_events.LogErrorsJsResponse.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.prebid_js_events.LogErrorsJsResponse;
                    return proto.prebid_js_events.LogErrorsJsResponse.deserializeBinaryFromReader(r, t)
                }, proto.prebid_js_events.LogErrorsJsResponse.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        if (1 === t.getFieldNumber()) {
                            var r = t.readString();
                            e.setErrorMessage(r)
                        } else t.skipField()
                    }
                    return e
                }, proto.prebid_js_events.LogErrorsJsResponse.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.prebid_js_events.LogErrorsJsResponse.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.prebid_js_events.LogErrorsJsResponse.serializeBinaryToWriter = function(e, t) {
                    var r;
                    (r = e.getErrorMessage()).length > 0 && t.writeString(1, r)
                }, proto.prebid_js_events.LogErrorsJsResponse.prototype.getErrorMessage = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.prebid_js_events.LogErrorsJsResponse.prototype.setErrorMessage = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, o.object.extend(t, proto.prebid_js_events)
            },
            5646(e, t, r) {
                const s = r(4439),
                    o = r(3766),
                    n = r(9811),
                    i = r(1605),
                    a = r(6802),
                    g = r(6835);
                e.exports = { ...s,
                    ...o,
                    ...n,
                    ...i,
                    ...a,
                    ...g
                }
            },
            4439(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.BidJs", null, n), proto.schema_registry.prebid_js.BidJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.schema_registry.prebid_js.BidJs.repeatedFields_, null)
                }, o.inherits(proto.schema_registry.prebid_js.BidJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.BidJs.displayName = "proto.schema_registry.prebid_js.BidJs"), proto.schema_registry.prebid_js.BidJs.repeatedFields_ = [15, 17], s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.BidJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.BidJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.BidJs.toObject = function(e, t) {
                    var r, o = {
                        timestamp: s.Message.getFieldWithDefault(t, 1, ""),
                        auctionId: s.Message.getFieldWithDefault(t, 2, ""),
                        impId: s.Message.getFieldWithDefault(t, 3, ""),
                        id: s.Message.getFieldWithDefault(t, 4, ""),
                        eventId: s.Message.getFieldWithDefault(t, 5, ""),
                        channel: s.Message.getFieldWithDefault(t, 6, ""),
                        integration: s.Message.getFieldWithDefault(t, 7, ""),
                        domain: s.Message.getFieldWithDefault(t, 8, ""),
                        publisherId: s.Message.getFieldWithDefault(t, 9, ""),
                        appBundle: s.Message.getFieldWithDefault(t, 10, ""),
                        bidder: s.Message.getFieldWithDefault(t, 11, ""),
                        seat: s.Message.getFieldWithDefault(t, 12, ""),
                        mediaType: s.Message.getFieldWithDefault(t, 13, ""),
                        price: s.Message.getFloatingPointFieldWithDefault(t, 14, 0),
                        advertiserDomainsList: null == (r = s.Message.getRepeatedField(t, 15)) ? void 0 : r,
                        creativeId: s.Message.getFieldWithDefault(t, 16, ""),
                        categoriesList: null == (r = s.Message.getRepeatedField(t, 17)) ? void 0 : r,
                        dealId: s.Message.getFieldWithDefault(t, 18, ""),
                        size: s.Message.getFieldWithDefault(t, 19, ""),
                        expireAfterSeconds: s.Message.getFieldWithDefault(t, 20, 0),
                        responseTime: s.Message.getFieldWithDefault(t, 21, 0),
                        ortbRequestId: s.Message.getFieldWithDefault(t, 22, ""),
                        tenantName: s.Message.getFieldWithDefault(t, 24, ""),
                        sampleRate: s.Message.getFloatingPointFieldWithDefault(t, 25, 0),
                        priceCurrency: s.Message.getFieldWithDefault(t, 26, ""),
                        gpid: s.Message.getFieldWithDefault(t, 27, ""),
                        placementId: s.Message.getFieldWithDefault(t, 28, ""),
                        timestampPb: (r = t.getTimestampPb()) && i.Timestamp.toObject(e, r),
                        platformAccountId: s.Message.getFieldWithDefault(t, 30, ""),
                        pbsAccountId: s.Message.getFieldWithDefault(t, 31, ""),
                        eventSource: s.Message.getFieldWithDefault(t, 32, ""),
                        priceUnmodified: s.Message.getFloatingPointFieldWithDefault(t, 33, 0),
                        schainNodes0Asi: s.Message.getFieldWithDefault(t, 34, ""),
                        schainNodes0Sid: s.Message.getFieldWithDefault(t, 35, ""),
                        schainNodes0Hp: s.Message.getFieldWithDefault(t, 36, 0),
                        schainNodes1Asi: s.Message.getFieldWithDefault(t, 37, ""),
                        schainNodes1Sid: s.Message.getFieldWithDefault(t, 38, ""),
                        schainNodes1Hp: s.Message.getFieldWithDefault(t, 39, 0),
                        timestampPbjs: s.Message.getFieldWithDefault(t, 40, 0),
                        prebidSource: s.Message.getFieldWithDefault(t, 41, ""),
                        bidModifier: s.Message.getFloatingPointFieldWithDefault(t, 42, 0)
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.BidJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.BidJs;
                    return proto.schema_registry.prebid_js.BidJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.BidJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setTimestamp(r);
                                break;
                            case 2:
                                r = t.readString();
                                e.setAuctionId(r);
                                break;
                            case 3:
                                r = t.readString();
                                e.setImpId(r);
                                break;
                            case 4:
                                r = t.readString();
                                e.setId(r);
                                break;
                            case 5:
                                r = t.readString();
                                e.setEventId(r);
                                break;
                            case 6:
                                r = t.readString();
                                e.setChannel(r);
                                break;
                            case 7:
                                r = t.readString();
                                e.setIntegration(r);
                                break;
                            case 8:
                                r = t.readString();
                                e.setDomain(r);
                                break;
                            case 9:
                                r = t.readString();
                                e.setPublisherId(r);
                                break;
                            case 10:
                                r = t.readString();
                                e.setAppBundle(r);
                                break;
                            case 11:
                                r = t.readString();
                                e.setBidder(r);
                                break;
                            case 12:
                                r = t.readString();
                                e.setSeat(r);
                                break;
                            case 13:
                                r = t.readString();
                                e.setMediaType(r);
                                break;
                            case 14:
                                r = t.readDouble();
                                e.setPrice(r);
                                break;
                            case 15:
                                r = t.readString();
                                e.addAdvertiserDomains(r);
                                break;
                            case 16:
                                r = t.readString();
                                e.setCreativeId(r);
                                break;
                            case 17:
                                r = t.readString();
                                e.addCategories(r);
                                break;
                            case 18:
                                r = t.readString();
                                e.setDealId(r);
                                break;
                            case 19:
                                r = t.readString();
                                e.setSize(r);
                                break;
                            case 20:
                                r = t.readInt32();
                                e.setExpireAfterSeconds(r);
                                break;
                            case 21:
                                r = t.readInt64();
                                e.setResponseTime(r);
                                break;
                            case 22:
                                r = t.readString();
                                e.setOrtbRequestId(r);
                                break;
                            case 24:
                                r = t.readString();
                                e.setTenantName(r);
                                break;
                            case 25:
                                r = t.readDouble();
                                e.setSampleRate(r);
                                break;
                            case 26:
                                r = t.readString();
                                e.setPriceCurrency(r);
                                break;
                            case 27:
                                r = t.readString();
                                e.setGpid(r);
                                break;
                            case 28:
                                r = t.readString();
                                e.setPlacementId(r);
                                break;
                            case 29:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestampPb(r);
                                break;
                            case 30:
                                r = t.readString();
                                e.setPlatformAccountId(r);
                                break;
                            case 31:
                                r = t.readString();
                                e.setPbsAccountId(r);
                                break;
                            case 32:
                                r = t.readString();
                                e.setEventSource(r);
                                break;
                            case 33:
                                r = t.readDouble();
                                e.setPriceUnmodified(r);
                                break;
                            case 34:
                                r = t.readString();
                                e.setSchainNodes0Asi(r);
                                break;
                            case 35:
                                r = t.readString();
                                e.setSchainNodes0Sid(r);
                                break;
                            case 36:
                                r = t.readInt32();
                                e.setSchainNodes0Hp(r);
                                break;
                            case 37:
                                r = t.readString();
                                e.setSchainNodes1Asi(r);
                                break;
                            case 38:
                                r = t.readString();
                                e.setSchainNodes1Sid(r);
                                break;
                            case 39:
                                r = t.readInt32();
                                e.setSchainNodes1Hp(r);
                                break;
                            case 40:
                                r = t.readInt64();
                                e.setTimestampPbjs(r);
                                break;
                            case 41:
                                r = t.readString();
                                e.setPrebidSource(r);
                                break;
                            case 42:
                                r = t.readDouble();
                                e.setBidModifier(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.BidJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.BidJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.BidJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getTimestamp()).length > 0 && t.writeString(1, r), (r = e.getAuctionId()).length > 0 && t.writeString(2, r), (r = e.getImpId()).length > 0 && t.writeString(3, r), (r = e.getId()).length > 0 && t.writeString(4, r), (r = e.getEventId()).length > 0 && t.writeString(5, r), (r = e.getChannel()).length > 0 && t.writeString(6, r), (r = e.getIntegration()).length > 0 && t.writeString(7, r), (r = e.getDomain()).length > 0 && t.writeString(8, r), (r = e.getPublisherId()).length > 0 && t.writeString(9, r), (r = e.getAppBundle()).length > 0 && t.writeString(10, r), (r = e.getBidder()).length > 0 && t.writeString(11, r), (r = e.getSeat()).length > 0 && t.writeString(12, r), (r = e.getMediaType()).length > 0 && t.writeString(13, r), 0 !== (r = e.getPrice()) && t.writeDouble(14, r), (r = e.getAdvertiserDomainsList()).length > 0 && t.writeRepeatedString(15, r), (r = e.getCreativeId()).length > 0 && t.writeString(16, r), (r = e.getCategoriesList()).length > 0 && t.writeRepeatedString(17, r), (r = e.getDealId()).length > 0 && t.writeString(18, r), (r = e.getSize()).length > 0 && t.writeString(19, r), 0 !== (r = e.getExpireAfterSeconds()) && t.writeInt32(20, r), 0 !== (r = e.getResponseTime()) && t.writeInt64(21, r), (r = e.getOrtbRequestId()).length > 0 && t.writeString(22, r), (r = e.getTenantName()).length > 0 && t.writeString(24, r), 0 !== (r = e.getSampleRate()) && t.writeDouble(25, r), (r = e.getPriceCurrency()).length > 0 && t.writeString(26, r), (r = e.getGpid()).length > 0 && t.writeString(27, r), (r = e.getPlacementId()).length > 0 && t.writeString(28, r), null != (r = e.getTimestampPb()) && t.writeMessage(29, r, i.Timestamp.serializeBinaryToWriter), (r = e.getPlatformAccountId()).length > 0 && t.writeString(30, r), (r = e.getPbsAccountId()).length > 0 && t.writeString(31, r), (r = e.getEventSource()).length > 0 && t.writeString(32, r), 0 !== (r = e.getPriceUnmodified()) && t.writeDouble(33, r), (r = e.getSchainNodes0Asi()).length > 0 && t.writeString(34, r), (r = e.getSchainNodes0Sid()).length > 0 && t.writeString(35, r), 0 !== (r = e.getSchainNodes0Hp()) && t.writeInt32(36, r), (r = e.getSchainNodes1Asi()).length > 0 && t.writeString(37, r), (r = e.getSchainNodes1Sid()).length > 0 && t.writeString(38, r), 0 !== (r = e.getSchainNodes1Hp()) && t.writeInt32(39, r), 0 !== (r = e.getTimestampPbjs()) && t.writeInt64(40, r), (r = e.getPrebidSource()).length > 0 && t.writeString(41, r), 0 !== (r = e.getBidModifier()) && t.writeDouble(42, r)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getAuctionId = function() {
                    return s.Message.getFieldWithDefault(this, 2, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setAuctionId = function(e) {
                    return s.Message.setProto3StringField(this, 2, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getImpId = function() {
                    return s.Message.getFieldWithDefault(this, 3, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setImpId = function(e) {
                    return s.Message.setProto3StringField(this, 3, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getId = function() {
                    return s.Message.getFieldWithDefault(this, 4, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setId = function(e) {
                    return s.Message.setProto3StringField(this, 4, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getEventId = function() {
                    return s.Message.getFieldWithDefault(this, 5, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setEventId = function(e) {
                    return s.Message.setProto3StringField(this, 5, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getChannel = function() {
                    return s.Message.getFieldWithDefault(this, 6, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setChannel = function(e) {
                    return s.Message.setProto3StringField(this, 6, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getIntegration = function() {
                    return s.Message.getFieldWithDefault(this, 7, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setIntegration = function(e) {
                    return s.Message.setProto3StringField(this, 7, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getDomain = function() {
                    return s.Message.getFieldWithDefault(this, 8, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setDomain = function(e) {
                    return s.Message.setProto3StringField(this, 8, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPublisherId = function() {
                    return s.Message.getFieldWithDefault(this, 9, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPublisherId = function(e) {
                    return s.Message.setProto3StringField(this, 9, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getAppBundle = function() {
                    return s.Message.getFieldWithDefault(this, 10, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setAppBundle = function(e) {
                    return s.Message.setProto3StringField(this, 10, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getBidder = function() {
                    return s.Message.getFieldWithDefault(this, 11, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setBidder = function(e) {
                    return s.Message.setProto3StringField(this, 11, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSeat = function() {
                    return s.Message.getFieldWithDefault(this, 12, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSeat = function(e) {
                    return s.Message.setProto3StringField(this, 12, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getMediaType = function() {
                    return s.Message.getFieldWithDefault(this, 13, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setMediaType = function(e) {
                    return s.Message.setProto3StringField(this, 13, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPrice = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 14, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPrice = function(e) {
                    return s.Message.setProto3FloatField(this, 14, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getAdvertiserDomainsList = function() {
                    return s.Message.getRepeatedField(this, 15)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setAdvertiserDomainsList = function(e) {
                    return s.Message.setField(this, 15, e || [])
                }, proto.schema_registry.prebid_js.BidJs.prototype.addAdvertiserDomains = function(e, t) {
                    return s.Message.addToRepeatedField(this, 15, e, t)
                }, proto.schema_registry.prebid_js.BidJs.prototype.clearAdvertiserDomainsList = function() {
                    return this.setAdvertiserDomainsList([])
                }, proto.schema_registry.prebid_js.BidJs.prototype.getCreativeId = function() {
                    return s.Message.getFieldWithDefault(this, 16, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setCreativeId = function(e) {
                    return s.Message.setProto3StringField(this, 16, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getCategoriesList = function() {
                    return s.Message.getRepeatedField(this, 17)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setCategoriesList = function(e) {
                    return s.Message.setField(this, 17, e || [])
                }, proto.schema_registry.prebid_js.BidJs.prototype.addCategories = function(e, t) {
                    return s.Message.addToRepeatedField(this, 17, e, t)
                }, proto.schema_registry.prebid_js.BidJs.prototype.clearCategoriesList = function() {
                    return this.setCategoriesList([])
                }, proto.schema_registry.prebid_js.BidJs.prototype.getDealId = function() {
                    return s.Message.getFieldWithDefault(this, 18, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setDealId = function(e) {
                    return s.Message.setProto3StringField(this, 18, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSize = function() {
                    return s.Message.getFieldWithDefault(this, 19, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSize = function(e) {
                    return s.Message.setProto3StringField(this, 19, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getExpireAfterSeconds = function() {
                    return s.Message.getFieldWithDefault(this, 20, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setExpireAfterSeconds = function(e) {
                    return s.Message.setProto3IntField(this, 20, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getResponseTime = function() {
                    return s.Message.getFieldWithDefault(this, 21, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setResponseTime = function(e) {
                    return s.Message.setProto3IntField(this, 21, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getOrtbRequestId = function() {
                    return s.Message.getFieldWithDefault(this, 22, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setOrtbRequestId = function(e) {
                    return s.Message.setProto3StringField(this, 22, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getTenantName = function() {
                    return s.Message.getFieldWithDefault(this, 24, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setTenantName = function(e) {
                    return s.Message.setProto3StringField(this, 24, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSampleRate = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 25, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSampleRate = function(e) {
                    return s.Message.setProto3FloatField(this, 25, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPriceCurrency = function() {
                    return s.Message.getFieldWithDefault(this, 26, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPriceCurrency = function(e) {
                    return s.Message.setProto3StringField(this, 26, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getGpid = function() {
                    return s.Message.getFieldWithDefault(this, 27, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setGpid = function(e) {
                    return s.Message.setProto3StringField(this, 27, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPlacementId = function() {
                    return s.Message.getFieldWithDefault(this, 28, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPlacementId = function(e) {
                    return s.Message.setProto3StringField(this, 28, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getTimestampPb = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 29)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setTimestampPb = function(e) {
                    return s.Message.setWrapperField(this, 29, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.clearTimestampPb = function() {
                    return this.setTimestampPb(void 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.hasTimestampPb = function() {
                    return null != s.Message.getField(this, 29)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPlatformAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 30, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPlatformAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 30, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPbsAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 31, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPbsAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 31, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getEventSource = function() {
                    return s.Message.getFieldWithDefault(this, 32, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setEventSource = function(e) {
                    return s.Message.setProto3StringField(this, 32, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPriceUnmodified = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 33, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPriceUnmodified = function(e) {
                    return s.Message.setProto3FloatField(this, 33, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSchainNodes0Asi = function() {
                    return s.Message.getFieldWithDefault(this, 34, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSchainNodes0Asi = function(e) {
                    return s.Message.setProto3StringField(this, 34, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSchainNodes0Sid = function() {
                    return s.Message.getFieldWithDefault(this, 35, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSchainNodes0Sid = function(e) {
                    return s.Message.setProto3StringField(this, 35, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSchainNodes0Hp = function() {
                    return s.Message.getFieldWithDefault(this, 36, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSchainNodes0Hp = function(e) {
                    return s.Message.setProto3IntField(this, 36, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSchainNodes1Asi = function() {
                    return s.Message.getFieldWithDefault(this, 37, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSchainNodes1Asi = function(e) {
                    return s.Message.setProto3StringField(this, 37, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSchainNodes1Sid = function() {
                    return s.Message.getFieldWithDefault(this, 38, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSchainNodes1Sid = function(e) {
                    return s.Message.setProto3StringField(this, 38, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getSchainNodes1Hp = function() {
                    return s.Message.getFieldWithDefault(this, 39, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setSchainNodes1Hp = function(e) {
                    return s.Message.setProto3IntField(this, 39, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getTimestampPbjs = function() {
                    return s.Message.getFieldWithDefault(this, 40, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setTimestampPbjs = function(e) {
                    return s.Message.setProto3IntField(this, 40, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getPrebidSource = function() {
                    return s.Message.getFieldWithDefault(this, 41, "")
                }, proto.schema_registry.prebid_js.BidJs.prototype.setPrebidSource = function(e) {
                    return s.Message.setProto3StringField(this, 41, e)
                }, proto.schema_registry.prebid_js.BidJs.prototype.getBidModifier = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 42, 0)
                }, proto.schema_registry.prebid_js.BidJs.prototype.setBidModifier = function(e) {
                    return s.Message.setProto3FloatField(this, 42, e)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            3766(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.BidderRequestJs", null, n), proto.schema_registry.prebid_js.BidderRequestJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.schema_registry.prebid_js.BidderRequestJs.repeatedFields_, null)
                }, o.inherits(proto.schema_registry.prebid_js.BidderRequestJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.BidderRequestJs.displayName = "proto.schema_registry.prebid_js.BidderRequestJs"), proto.schema_registry.prebid_js.BidderRequestJs.repeatedFields_ = [7, 8], s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.BidderRequestJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.BidderRequestJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.BidderRequestJs.toObject = function(e, t) {
                    var r, o = {
                        timestamp: s.Message.getFieldWithDefault(t, 1, ""),
                        bidder: s.Message.getFieldWithDefault(t, 2, ""),
                        ortbRequestId: s.Message.getFieldWithDefault(t, 3, ""),
                        appBundle: s.Message.getFieldWithDefault(t, 4, ""),
                        impCount: s.Message.getFieldWithDefault(t, 5, 0),
                        bidCount: s.Message.getFieldWithDefault(t, 6, 0),
                        errorsList: null == (r = s.Message.getRepeatedField(t, 7)) ? void 0 : r,
                        warningsList: null == (r = s.Message.getRepeatedField(t, 8)) ? void 0 : r,
                        channel: s.Message.getFieldWithDefault(t, 9, ""),
                        integration: s.Message.getFieldWithDefault(t, 10, ""),
                        domain: s.Message.getFieldWithDefault(t, 11, ""),
                        publisherId: s.Message.getFieldWithDefault(t, 12, ""),
                        tenantName: s.Message.getFieldWithDefault(t, 13, ""),
                        hasTimedOut: s.Message.getBooleanFieldWithDefault(t, 14, !1),
                        tmax: s.Message.getFieldWithDefault(t, 15, 0),
                        sampleRate: s.Message.getFloatingPointFieldWithDefault(t, 16, 0),
                        gpid: s.Message.getFieldWithDefault(t, 17, ""),
                        impressionId: s.Message.getFieldWithDefault(t, 18, ""),
                        placementId: s.Message.getFieldWithDefault(t, 19, ""),
                        bidderRequestId: s.Message.getFieldWithDefault(t, 20, ""),
                        timestampPb: (r = t.getTimestampPb()) && i.Timestamp.toObject(e, r),
                        platformAccountId: s.Message.getFieldWithDefault(t, 22, ""),
                        pbsAccountId: s.Message.getFieldWithDefault(t, 23, ""),
                        eventSource: s.Message.getFieldWithDefault(t, 24, ""),
                        schainNodes0Asi: s.Message.getFieldWithDefault(t, 25, ""),
                        schainNodes0Sid: s.Message.getFieldWithDefault(t, 26, ""),
                        schainNodes0Hp: s.Message.getFieldWithDefault(t, 27, 0),
                        schainNodes1Asi: s.Message.getFieldWithDefault(t, 28, ""),
                        schainNodes1Sid: s.Message.getFieldWithDefault(t, 29, ""),
                        schainNodes1Hp: s.Message.getFieldWithDefault(t, 30, 0),
                        timestampPbjs: s.Message.getFieldWithDefault(t, 31, 0),
                        prebidSource: s.Message.getFieldWithDefault(t, 32, ""),
                        hasError: s.Message.getBooleanFieldWithDefault(t, 33, !1)
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.BidderRequestJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.BidderRequestJs;
                    return proto.schema_registry.prebid_js.BidderRequestJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.BidderRequestJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setTimestamp(r);
                                break;
                            case 2:
                                r = t.readString();
                                e.setBidder(r);
                                break;
                            case 3:
                                r = t.readString();
                                e.setOrtbRequestId(r);
                                break;
                            case 4:
                                r = t.readString();
                                e.setAppBundle(r);
                                break;
                            case 5:
                                r = t.readInt32();
                                e.setImpCount(r);
                                break;
                            case 6:
                                r = t.readInt32();
                                e.setBidCount(r);
                                break;
                            case 7:
                                r = t.readString();
                                e.addErrors(r);
                                break;
                            case 8:
                                r = t.readString();
                                e.addWarnings(r);
                                break;
                            case 9:
                                r = t.readString();
                                e.setChannel(r);
                                break;
                            case 10:
                                r = t.readString();
                                e.setIntegration(r);
                                break;
                            case 11:
                                r = t.readString();
                                e.setDomain(r);
                                break;
                            case 12:
                                r = t.readString();
                                e.setPublisherId(r);
                                break;
                            case 13:
                                r = t.readString();
                                e.setTenantName(r);
                                break;
                            case 14:
                                r = t.readBool();
                                e.setHasTimedOut(r);
                                break;
                            case 15:
                                r = t.readInt64();
                                e.setTmax(r);
                                break;
                            case 16:
                                r = t.readDouble();
                                e.setSampleRate(r);
                                break;
                            case 17:
                                r = t.readString();
                                e.setGpid(r);
                                break;
                            case 18:
                                r = t.readString();
                                e.setImpressionId(r);
                                break;
                            case 19:
                                r = t.readString();
                                e.setPlacementId(r);
                                break;
                            case 20:
                                r = t.readString();
                                e.setBidderRequestId(r);
                                break;
                            case 21:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestampPb(r);
                                break;
                            case 22:
                                r = t.readString();
                                e.setPlatformAccountId(r);
                                break;
                            case 23:
                                r = t.readString();
                                e.setPbsAccountId(r);
                                break;
                            case 24:
                                r = t.readString();
                                e.setEventSource(r);
                                break;
                            case 25:
                                r = t.readString();
                                e.setSchainNodes0Asi(r);
                                break;
                            case 26:
                                r = t.readString();
                                e.setSchainNodes0Sid(r);
                                break;
                            case 27:
                                r = t.readInt32();
                                e.setSchainNodes0Hp(r);
                                break;
                            case 28:
                                r = t.readString();
                                e.setSchainNodes1Asi(r);
                                break;
                            case 29:
                                r = t.readString();
                                e.setSchainNodes1Sid(r);
                                break;
                            case 30:
                                r = t.readInt32();
                                e.setSchainNodes1Hp(r);
                                break;
                            case 31:
                                r = t.readInt64();
                                e.setTimestampPbjs(r);
                                break;
                            case 32:
                                r = t.readString();
                                e.setPrebidSource(r);
                                break;
                            case 33:
                                r = t.readBool();
                                e.setHasError(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.BidderRequestJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.BidderRequestJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getTimestamp()).length > 0 && t.writeString(1, r), (r = e.getBidder()).length > 0 && t.writeString(2, r), (r = e.getOrtbRequestId()).length > 0 && t.writeString(3, r), (r = e.getAppBundle()).length > 0 && t.writeString(4, r), 0 !== (r = e.getImpCount()) && t.writeInt32(5, r), 0 !== (r = e.getBidCount()) && t.writeInt32(6, r), (r = e.getErrorsList()).length > 0 && t.writeRepeatedString(7, r), (r = e.getWarningsList()).length > 0 && t.writeRepeatedString(8, r), (r = e.getChannel()).length > 0 && t.writeString(9, r), (r = e.getIntegration()).length > 0 && t.writeString(10, r), (r = e.getDomain()).length > 0 && t.writeString(11, r), (r = e.getPublisherId()).length > 0 && t.writeString(12, r), (r = e.getTenantName()).length > 0 && t.writeString(13, r), (r = e.getHasTimedOut()) && t.writeBool(14, r), 0 !== (r = e.getTmax()) && t.writeInt64(15, r), 0 !== (r = e.getSampleRate()) && t.writeDouble(16, r), (r = e.getGpid()).length > 0 && t.writeString(17, r), (r = e.getImpressionId()).length > 0 && t.writeString(18, r), (r = e.getPlacementId()).length > 0 && t.writeString(19, r), (r = e.getBidderRequestId()).length > 0 && t.writeString(20, r), null != (r = e.getTimestampPb()) && t.writeMessage(21, r, i.Timestamp.serializeBinaryToWriter), (r = e.getPlatformAccountId()).length > 0 && t.writeString(22, r), (r = e.getPbsAccountId()).length > 0 && t.writeString(23, r), (r = e.getEventSource()).length > 0 && t.writeString(24, r), (r = e.getSchainNodes0Asi()).length > 0 && t.writeString(25, r), (r = e.getSchainNodes0Sid()).length > 0 && t.writeString(26, r), 0 !== (r = e.getSchainNodes0Hp()) && t.writeInt32(27, r), (r = e.getSchainNodes1Asi()).length > 0 && t.writeString(28, r), (r = e.getSchainNodes1Sid()).length > 0 && t.writeString(29, r), 0 !== (r = e.getSchainNodes1Hp()) && t.writeInt32(30, r), 0 !== (r = e.getTimestampPbjs()) && t.writeInt64(31, r), (r = e.getPrebidSource()).length > 0 && t.writeString(32, r), (r = e.getHasError()) && t.writeBool(33, r)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getBidder = function() {
                    return s.Message.getFieldWithDefault(this, 2, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setBidder = function(e) {
                    return s.Message.setProto3StringField(this, 2, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getOrtbRequestId = function() {
                    return s.Message.getFieldWithDefault(this, 3, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setOrtbRequestId = function(e) {
                    return s.Message.setProto3StringField(this, 3, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getAppBundle = function() {
                    return s.Message.getFieldWithDefault(this, 4, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setAppBundle = function(e) {
                    return s.Message.setProto3StringField(this, 4, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getImpCount = function() {
                    return s.Message.getFieldWithDefault(this, 5, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setImpCount = function(e) {
                    return s.Message.setProto3IntField(this, 5, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getBidCount = function() {
                    return s.Message.getFieldWithDefault(this, 6, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setBidCount = function(e) {
                    return s.Message.setProto3IntField(this, 6, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getErrorsList = function() {
                    return s.Message.getRepeatedField(this, 7)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setErrorsList = function(e) {
                    return s.Message.setField(this, 7, e || [])
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.addErrors = function(e, t) {
                    return s.Message.addToRepeatedField(this, 7, e, t)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.clearErrorsList = function() {
                    return this.setErrorsList([])
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getWarningsList = function() {
                    return s.Message.getRepeatedField(this, 8)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setWarningsList = function(e) {
                    return s.Message.setField(this, 8, e || [])
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.addWarnings = function(e, t) {
                    return s.Message.addToRepeatedField(this, 8, e, t)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.clearWarningsList = function() {
                    return this.setWarningsList([])
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getChannel = function() {
                    return s.Message.getFieldWithDefault(this, 9, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setChannel = function(e) {
                    return s.Message.setProto3StringField(this, 9, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getIntegration = function() {
                    return s.Message.getFieldWithDefault(this, 10, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setIntegration = function(e) {
                    return s.Message.setProto3StringField(this, 10, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getDomain = function() {
                    return s.Message.getFieldWithDefault(this, 11, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setDomain = function(e) {
                    return s.Message.setProto3StringField(this, 11, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getPublisherId = function() {
                    return s.Message.getFieldWithDefault(this, 12, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setPublisherId = function(e) {
                    return s.Message.setProto3StringField(this, 12, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getTenantName = function() {
                    return s.Message.getFieldWithDefault(this, 13, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setTenantName = function(e) {
                    return s.Message.setProto3StringField(this, 13, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getHasTimedOut = function() {
                    return s.Message.getBooleanFieldWithDefault(this, 14, !1)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setHasTimedOut = function(e) {
                    return s.Message.setProto3BooleanField(this, 14, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getTmax = function() {
                    return s.Message.getFieldWithDefault(this, 15, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setTmax = function(e) {
                    return s.Message.setProto3IntField(this, 15, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSampleRate = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 16, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSampleRate = function(e) {
                    return s.Message.setProto3FloatField(this, 16, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getGpid = function() {
                    return s.Message.getFieldWithDefault(this, 17, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setGpid = function(e) {
                    return s.Message.setProto3StringField(this, 17, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getImpressionId = function() {
                    return s.Message.getFieldWithDefault(this, 18, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setImpressionId = function(e) {
                    return s.Message.setProto3StringField(this, 18, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getPlacementId = function() {
                    return s.Message.getFieldWithDefault(this, 19, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setPlacementId = function(e) {
                    return s.Message.setProto3StringField(this, 19, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getBidderRequestId = function() {
                    return s.Message.getFieldWithDefault(this, 20, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setBidderRequestId = function(e) {
                    return s.Message.setProto3StringField(this, 20, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getTimestampPb = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 21)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setTimestampPb = function(e) {
                    return s.Message.setWrapperField(this, 21, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.clearTimestampPb = function() {
                    return this.setTimestampPb(void 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.hasTimestampPb = function() {
                    return null != s.Message.getField(this, 21)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getPlatformAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 22, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setPlatformAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 22, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getPbsAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 23, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setPbsAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 23, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getEventSource = function() {
                    return s.Message.getFieldWithDefault(this, 24, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setEventSource = function(e) {
                    return s.Message.setProto3StringField(this, 24, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSchainNodes0Asi = function() {
                    return s.Message.getFieldWithDefault(this, 25, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSchainNodes0Asi = function(e) {
                    return s.Message.setProto3StringField(this, 25, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSchainNodes0Sid = function() {
                    return s.Message.getFieldWithDefault(this, 26, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSchainNodes0Sid = function(e) {
                    return s.Message.setProto3StringField(this, 26, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSchainNodes0Hp = function() {
                    return s.Message.getFieldWithDefault(this, 27, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSchainNodes0Hp = function(e) {
                    return s.Message.setProto3IntField(this, 27, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSchainNodes1Asi = function() {
                    return s.Message.getFieldWithDefault(this, 28, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSchainNodes1Asi = function(e) {
                    return s.Message.setProto3StringField(this, 28, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSchainNodes1Sid = function() {
                    return s.Message.getFieldWithDefault(this, 29, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSchainNodes1Sid = function(e) {
                    return s.Message.setProto3StringField(this, 29, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getSchainNodes1Hp = function() {
                    return s.Message.getFieldWithDefault(this, 30, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setSchainNodes1Hp = function(e) {
                    return s.Message.setProto3IntField(this, 30, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getTimestampPbjs = function() {
                    return s.Message.getFieldWithDefault(this, 31, 0)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setTimestampPbjs = function(e) {
                    return s.Message.setProto3IntField(this, 31, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getPrebidSource = function() {
                    return s.Message.getFieldWithDefault(this, 32, "")
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setPrebidSource = function(e) {
                    return s.Message.setProto3StringField(this, 32, e)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.getHasError = function() {
                    return s.Message.getBooleanFieldWithDefault(this, 33, !1)
                }, proto.schema_registry.prebid_js.BidderRequestJs.prototype.setHasError = function(e) {
                    return s.Message.setProto3BooleanField(this, 33, e)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            9811(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.ErrorsJs", null, n), proto.schema_registry.prebid_js.ErrorsJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.schema_registry.prebid_js.ErrorsJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.ErrorsJs.displayName = "proto.schema_registry.prebid_js.ErrorsJs"), s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.ErrorsJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.ErrorsJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.ErrorsJs.toObject = function(e, t) {
                    var r, o = {
                        id: s.Message.getFieldWithDefault(t, 1, ""),
                        timestamp: s.Message.getFieldWithDefault(t, 2, ""),
                        timestampPb: (r = t.getTimestampPb()) && i.Timestamp.toObject(e, r),
                        message: s.Message.getFieldWithDefault(t, 4, ""),
                        code: s.Message.getFieldWithDefault(t, 5, 0),
                        ortbRequestId: s.Message.getFieldWithDefault(t, 6, "")
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.ErrorsJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.ErrorsJs;
                    return proto.schema_registry.prebid_js.ErrorsJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.ErrorsJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setId(r);
                                break;
                            case 2:
                                r = t.readString();
                                e.setTimestamp(r);
                                break;
                            case 3:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestampPb(r);
                                break;
                            case 4:
                                r = t.readString();
                                e.setMessage(r);
                                break;
                            case 5:
                                r = t.readInt32();
                                e.setCode(r);
                                break;
                            case 6:
                                r = t.readString();
                                e.setOrtbRequestId(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.ErrorsJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.ErrorsJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getId()).length > 0 && t.writeString(1, r), (r = e.getTimestamp()).length > 0 && t.writeString(2, r), null != (r = e.getTimestampPb()) && t.writeMessage(3, r, i.Timestamp.serializeBinaryToWriter), (r = e.getMessage()).length > 0 && t.writeString(4, r), 0 !== (r = e.getCode()) && t.writeInt32(5, r), (r = e.getOrtbRequestId()).length > 0 && t.writeString(6, r)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.getId = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.setId = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.getTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 2, "")
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.setTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 2, e)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.getTimestampPb = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 3)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.setTimestampPb = function(e) {
                    return s.Message.setWrapperField(this, 3, e)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.clearTimestampPb = function() {
                    return this.setTimestampPb(void 0)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.hasTimestampPb = function() {
                    return null != s.Message.getField(this, 3)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.getMessage = function() {
                    return s.Message.getFieldWithDefault(this, 4, "")
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.setMessage = function(e) {
                    return s.Message.setProto3StringField(this, 4, e)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.getCode = function() {
                    return s.Message.getFieldWithDefault(this, 5, 0)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.setCode = function(e) {
                    return s.Message.setProto3IntField(this, 5, e)
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.getOrtbRequestId = function() {
                    return s.Message.getFieldWithDefault(this, 6, "")
                }, proto.schema_registry.prebid_js.ErrorsJs.prototype.setOrtbRequestId = function(e) {
                    return s.Message.setProto3StringField(this, 6, e)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            1605(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.ImpressionRequestJs", null, n), proto.schema_registry.prebid_js.ImpressionRequestJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.schema_registry.prebid_js.ImpressionRequestJs.repeatedFields_, null)
                }, o.inherits(proto.schema_registry.prebid_js.ImpressionRequestJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.ImpressionRequestJs.displayName = "proto.schema_registry.prebid_js.ImpressionRequestJs"), proto.schema_registry.prebid_js.ImpressionRequestJs.repeatedFields_ = [7], s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.ImpressionRequestJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.toObject = function(e, t) {
                    var r, o = {
                        impressionId: s.Message.getFieldWithDefault(t, 1, ""),
                        ortbRequestId: s.Message.getFieldWithDefault(t, 2, ""),
                        timestamp: s.Message.getFieldWithDefault(t, 3, ""),
                        instl: s.Message.getFieldWithDefault(t, 4, 0),
                        tagid: s.Message.getFieldWithDefault(t, 5, ""),
                        bidfloor: s.Message.getFloatingPointFieldWithDefault(t, 6, 0),
                        sizeList: null == (r = s.Message.getRepeatedField(t, 7)) ? void 0 : r,
                        videoMaxduration: s.Message.getFieldWithDefault(t, 8, 0),
                        gpid: s.Message.getFieldWithDefault(t, 9, ""),
                        adUnitCode: s.Message.getFieldWithDefault(t, 10, ""),
                        tenantName: s.Message.getFieldWithDefault(t, 11, ""),
                        sampleRate: s.Message.getFloatingPointFieldWithDefault(t, 12, 0),
                        bidFloorCurrency: s.Message.getFieldWithDefault(t, 13, ""),
                        mediaType: s.Message.getFieldWithDefault(t, 14, ""),
                        videoContext: s.Message.getFieldWithDefault(t, 15, ""),
                        videoPlcmt: s.Message.getFieldWithDefault(t, 16, ""),
                        videoSkip: s.Message.getFieldWithDefault(t, 17, ""),
                        placementId: s.Message.getFieldWithDefault(t, 18, ""),
                        accountId: s.Message.getFieldWithDefault(t, 19, ""),
                        timestampPb: (r = t.getTimestampPb()) && i.Timestamp.toObject(e, r),
                        platformAccountId: s.Message.getFieldWithDefault(t, 21, ""),
                        pbsAccountId: s.Message.getFieldWithDefault(t, 22, ""),
                        eventSource: s.Message.getFieldWithDefault(t, 23, ""),
                        timestampPbjs: s.Message.getFieldWithDefault(t, 24, 0),
                        prebidSource: s.Message.getFieldWithDefault(t, 25, "")
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.ImpressionRequestJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.ImpressionRequestJs;
                    return proto.schema_registry.prebid_js.ImpressionRequestJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setImpressionId(r);
                                break;
                            case 2:
                                r = t.readString();
                                e.setOrtbRequestId(r);
                                break;
                            case 3:
                                r = t.readString();
                                e.setTimestamp(r);
                                break;
                            case 4:
                                r = t.readInt32();
                                e.setInstl(r);
                                break;
                            case 5:
                                r = t.readString();
                                e.setTagid(r);
                                break;
                            case 6:
                                r = t.readDouble();
                                e.setBidfloor(r);
                                break;
                            case 7:
                                r = t.readString();
                                e.addSize(r);
                                break;
                            case 8:
                                r = t.readInt64();
                                e.setVideoMaxduration(r);
                                break;
                            case 9:
                                r = t.readString();
                                e.setGpid(r);
                                break;
                            case 10:
                                r = t.readString();
                                e.setAdUnitCode(r);
                                break;
                            case 11:
                                r = t.readString();
                                e.setTenantName(r);
                                break;
                            case 12:
                                r = t.readDouble();
                                e.setSampleRate(r);
                                break;
                            case 13:
                                r = t.readString();
                                e.setBidFloorCurrency(r);
                                break;
                            case 14:
                                r = t.readString();
                                e.setMediaType(r);
                                break;
                            case 15:
                                r = t.readString();
                                e.setVideoContext(r);
                                break;
                            case 16:
                                r = t.readString();
                                e.setVideoPlcmt(r);
                                break;
                            case 17:
                                r = t.readString();
                                e.setVideoSkip(r);
                                break;
                            case 18:
                                r = t.readString();
                                e.setPlacementId(r);
                                break;
                            case 19:
                                r = t.readString();
                                e.setAccountId(r);
                                break;
                            case 20:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestampPb(r);
                                break;
                            case 21:
                                r = t.readString();
                                e.setPlatformAccountId(r);
                                break;
                            case 22:
                                r = t.readString();
                                e.setPbsAccountId(r);
                                break;
                            case 23:
                                r = t.readString();
                                e.setEventSource(r);
                                break;
                            case 24:
                                r = t.readInt64();
                                e.setTimestampPbjs(r);
                                break;
                            case 25:
                                r = t.readString();
                                e.setPrebidSource(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.ImpressionRequestJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getImpressionId()).length > 0 && t.writeString(1, r), (r = e.getOrtbRequestId()).length > 0 && t.writeString(2, r), (r = e.getTimestamp()).length > 0 && t.writeString(3, r), 0 !== (r = e.getInstl()) && t.writeInt32(4, r), (r = e.getTagid()).length > 0 && t.writeString(5, r), 0 !== (r = e.getBidfloor()) && t.writeDouble(6, r), (r = e.getSizeList()).length > 0 && t.writeRepeatedString(7, r), null != (r = s.Message.getField(e, 8)) && t.writeInt64(8, r), (r = e.getGpid()).length > 0 && t.writeString(9, r), (r = e.getAdUnitCode()).length > 0 && t.writeString(10, r), (r = e.getTenantName()).length > 0 && t.writeString(11, r), 0 !== (r = e.getSampleRate()) && t.writeDouble(12, r), (r = e.getBidFloorCurrency()).length > 0 && t.writeString(13, r), (r = e.getMediaType()).length > 0 && t.writeString(14, r), (r = e.getVideoContext()).length > 0 && t.writeString(15, r), (r = e.getVideoPlcmt()).length > 0 && t.writeString(16, r), (r = e.getVideoSkip()).length > 0 && t.writeString(17, r), (r = e.getPlacementId()).length > 0 && t.writeString(18, r), (r = e.getAccountId()).length > 0 && t.writeString(19, r), null != (r = e.getTimestampPb()) && t.writeMessage(20, r, i.Timestamp.serializeBinaryToWriter), (r = e.getPlatformAccountId()).length > 0 && t.writeString(21, r), (r = e.getPbsAccountId()).length > 0 && t.writeString(22, r), (r = e.getEventSource()).length > 0 && t.writeString(23, r), 0 !== (r = e.getTimestampPbjs()) && t.writeInt64(24, r), (r = e.getPrebidSource()).length > 0 && t.writeString(25, r)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getImpressionId = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setImpressionId = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getOrtbRequestId = function() {
                    return s.Message.getFieldWithDefault(this, 2, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setOrtbRequestId = function(e) {
                    return s.Message.setProto3StringField(this, 2, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 3, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 3, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getInstl = function() {
                    return s.Message.getFieldWithDefault(this, 4, 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setInstl = function(e) {
                    return s.Message.setProto3IntField(this, 4, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getTagid = function() {
                    return s.Message.getFieldWithDefault(this, 5, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setTagid = function(e) {
                    return s.Message.setProto3StringField(this, 5, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getBidfloor = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 6, 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setBidfloor = function(e) {
                    return s.Message.setProto3FloatField(this, 6, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getSizeList = function() {
                    return s.Message.getRepeatedField(this, 7)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setSizeList = function(e) {
                    return s.Message.setField(this, 7, e || [])
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.addSize = function(e, t) {
                    return s.Message.addToRepeatedField(this, 7, e, t)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.clearSizeList = function() {
                    return this.setSizeList([])
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getVideoMaxduration = function() {
                    return s.Message.getFieldWithDefault(this, 8, 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setVideoMaxduration = function(e) {
                    return s.Message.setField(this, 8, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.clearVideoMaxduration = function() {
                    return s.Message.setField(this, 8, void 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.hasVideoMaxduration = function() {
                    return null != s.Message.getField(this, 8)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getGpid = function() {
                    return s.Message.getFieldWithDefault(this, 9, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setGpid = function(e) {
                    return s.Message.setProto3StringField(this, 9, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getAdUnitCode = function() {
                    return s.Message.getFieldWithDefault(this, 10, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setAdUnitCode = function(e) {
                    return s.Message.setProto3StringField(this, 10, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getTenantName = function() {
                    return s.Message.getFieldWithDefault(this, 11, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setTenantName = function(e) {
                    return s.Message.setProto3StringField(this, 11, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getSampleRate = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 12, 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setSampleRate = function(e) {
                    return s.Message.setProto3FloatField(this, 12, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getBidFloorCurrency = function() {
                    return s.Message.getFieldWithDefault(this, 13, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setBidFloorCurrency = function(e) {
                    return s.Message.setProto3StringField(this, 13, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getMediaType = function() {
                    return s.Message.getFieldWithDefault(this, 14, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setMediaType = function(e) {
                    return s.Message.setProto3StringField(this, 14, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getVideoContext = function() {
                    return s.Message.getFieldWithDefault(this, 15, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setVideoContext = function(e) {
                    return s.Message.setProto3StringField(this, 15, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getVideoPlcmt = function() {
                    return s.Message.getFieldWithDefault(this, 16, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setVideoPlcmt = function(e) {
                    return s.Message.setProto3StringField(this, 16, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getVideoSkip = function() {
                    return s.Message.getFieldWithDefault(this, 17, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setVideoSkip = function(e) {
                    return s.Message.setProto3StringField(this, 17, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getPlacementId = function() {
                    return s.Message.getFieldWithDefault(this, 18, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setPlacementId = function(e) {
                    return s.Message.setProto3StringField(this, 18, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 19, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 19, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getTimestampPb = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 20)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setTimestampPb = function(e) {
                    return s.Message.setWrapperField(this, 20, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.clearTimestampPb = function() {
                    return this.setTimestampPb(void 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.hasTimestampPb = function() {
                    return null != s.Message.getField(this, 20)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getPlatformAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 21, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setPlatformAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 21, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getPbsAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 22, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setPbsAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 22, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getEventSource = function() {
                    return s.Message.getFieldWithDefault(this, 23, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setEventSource = function(e) {
                    return s.Message.setProto3StringField(this, 23, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getTimestampPbjs = function() {
                    return s.Message.getFieldWithDefault(this, 24, 0)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setTimestampPbjs = function(e) {
                    return s.Message.setProto3IntField(this, 24, e)
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.getPrebidSource = function() {
                    return s.Message.getFieldWithDefault(this, 25, "")
                }, proto.schema_registry.prebid_js.ImpressionRequestJs.prototype.setPrebidSource = function(e) {
                    return s.Message.setProto3StringField(this, 25, e)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            6802(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.NotificationJs", null, n), proto.schema_registry.prebid_js.NotificationJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.schema_registry.prebid_js.NotificationJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.NotificationJs.displayName = "proto.schema_registry.prebid_js.NotificationJs"), s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.NotificationJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.NotificationJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.NotificationJs.toObject = function(e, t) {
                    var r, o = {
                        timestamp: s.Message.getFieldWithDefault(t, 1, ""),
                        type: s.Message.getFieldWithDefault(t, 2, ""),
                        bidId: s.Message.getFieldWithDefault(t, 3, ""),
                        accountId: s.Message.getFieldWithDefault(t, 4, ""),
                        bidder: s.Message.getFieldWithDefault(t, 5, ""),
                        auctionTimestamp: s.Message.getFieldWithDefault(t, 6, ""),
                        integration: s.Message.getFieldWithDefault(t, 7, ""),
                        tenantName: s.Message.getFieldWithDefault(t, 8, ""),
                        sampleRate: s.Message.getFloatingPointFieldWithDefault(t, 9, 0),
                        impId: s.Message.getFieldWithDefault(t, 10, ""),
                        price: s.Message.getFloatingPointFieldWithDefault(t, 11, 0),
                        ortbRequestId: s.Message.getFieldWithDefault(t, 12, ""),
                        priceCurrency: s.Message.getFieldWithDefault(t, 13, ""),
                        timestampPb: (r = t.getTimestampPb()) && i.Timestamp.toObject(e, r),
                        platformAccountId: s.Message.getFieldWithDefault(t, 15, ""),
                        pbsAccountId: s.Message.getFieldWithDefault(t, 16, ""),
                        eventSource: s.Message.getFieldWithDefault(t, 17, ""),
                        priceUnmodified: s.Message.getFloatingPointFieldWithDefault(t, 18, 0),
                        timestampPbjs: s.Message.getFieldWithDefault(t, 19, 0),
                        prebidSource: s.Message.getFieldWithDefault(t, 20, "")
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.NotificationJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.NotificationJs;
                    return proto.schema_registry.prebid_js.NotificationJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.NotificationJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setTimestamp(r);
                                break;
                            case 2:
                                r = t.readString();
                                e.setType(r);
                                break;
                            case 3:
                                r = t.readString();
                                e.setBidId(r);
                                break;
                            case 4:
                                r = t.readString();
                                e.setAccountId(r);
                                break;
                            case 5:
                                r = t.readString();
                                e.setBidder(r);
                                break;
                            case 6:
                                r = t.readString();
                                e.setAuctionTimestamp(r);
                                break;
                            case 7:
                                r = t.readString();
                                e.setIntegration(r);
                                break;
                            case 8:
                                r = t.readString();
                                e.setTenantName(r);
                                break;
                            case 9:
                                r = t.readDouble();
                                e.setSampleRate(r);
                                break;
                            case 10:
                                r = t.readString();
                                e.setImpId(r);
                                break;
                            case 11:
                                r = t.readDouble();
                                e.setPrice(r);
                                break;
                            case 12:
                                r = t.readString();
                                e.setOrtbRequestId(r);
                                break;
                            case 13:
                                r = t.readString();
                                e.setPriceCurrency(r);
                                break;
                            case 14:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestampPb(r);
                                break;
                            case 15:
                                r = t.readString();
                                e.setPlatformAccountId(r);
                                break;
                            case 16:
                                r = t.readString();
                                e.setPbsAccountId(r);
                                break;
                            case 17:
                                r = t.readString();
                                e.setEventSource(r);
                                break;
                            case 18:
                                r = t.readDouble();
                                e.setPriceUnmodified(r);
                                break;
                            case 19:
                                r = t.readInt64();
                                e.setTimestampPbjs(r);
                                break;
                            case 20:
                                r = t.readString();
                                e.setPrebidSource(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.NotificationJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.NotificationJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getTimestamp()).length > 0 && t.writeString(1, r), (r = e.getType()).length > 0 && t.writeString(2, r), (r = e.getBidId()).length > 0 && t.writeString(3, r), (r = e.getAccountId()).length > 0 && t.writeString(4, r), (r = e.getBidder()).length > 0 && t.writeString(5, r), (r = e.getAuctionTimestamp()).length > 0 && t.writeString(6, r), (r = e.getIntegration()).length > 0 && t.writeString(7, r), (r = e.getTenantName()).length > 0 && t.writeString(8, r), 0 !== (r = e.getSampleRate()) && t.writeDouble(9, r), (r = e.getImpId()).length > 0 && t.writeString(10, r), 0 !== (r = e.getPrice()) && t.writeDouble(11, r), (r = e.getOrtbRequestId()).length > 0 && t.writeString(12, r), (r = e.getPriceCurrency()).length > 0 && t.writeString(13, r), null != (r = e.getTimestampPb()) && t.writeMessage(14, r, i.Timestamp.serializeBinaryToWriter), (r = e.getPlatformAccountId()).length > 0 && t.writeString(15, r), (r = e.getPbsAccountId()).length > 0 && t.writeString(16, r), (r = e.getEventSource()).length > 0 && t.writeString(17, r), 0 !== (r = e.getPriceUnmodified()) && t.writeDouble(18, r), 0 !== (r = e.getTimestampPbjs()) && t.writeInt64(19, r), (r = e.getPrebidSource()).length > 0 && t.writeString(20, r)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getType = function() {
                    return s.Message.getFieldWithDefault(this, 2, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setType = function(e) {
                    return s.Message.setProto3StringField(this, 2, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getBidId = function() {
                    return s.Message.getFieldWithDefault(this, 3, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setBidId = function(e) {
                    return s.Message.setProto3StringField(this, 3, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 4, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 4, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getBidder = function() {
                    return s.Message.getFieldWithDefault(this, 5, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setBidder = function(e) {
                    return s.Message.setProto3StringField(this, 5, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getAuctionTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 6, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setAuctionTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 6, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getIntegration = function() {
                    return s.Message.getFieldWithDefault(this, 7, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setIntegration = function(e) {
                    return s.Message.setProto3StringField(this, 7, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getTenantName = function() {
                    return s.Message.getFieldWithDefault(this, 8, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setTenantName = function(e) {
                    return s.Message.setProto3StringField(this, 8, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getSampleRate = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 9, 0)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setSampleRate = function(e) {
                    return s.Message.setProto3FloatField(this, 9, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getImpId = function() {
                    return s.Message.getFieldWithDefault(this, 10, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setImpId = function(e) {
                    return s.Message.setProto3StringField(this, 10, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getPrice = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 11, 0)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setPrice = function(e) {
                    return s.Message.setProto3FloatField(this, 11, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getOrtbRequestId = function() {
                    return s.Message.getFieldWithDefault(this, 12, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setOrtbRequestId = function(e) {
                    return s.Message.setProto3StringField(this, 12, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getPriceCurrency = function() {
                    return s.Message.getFieldWithDefault(this, 13, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setPriceCurrency = function(e) {
                    return s.Message.setProto3StringField(this, 13, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getTimestampPb = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 14)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setTimestampPb = function(e) {
                    return s.Message.setWrapperField(this, 14, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.clearTimestampPb = function() {
                    return this.setTimestampPb(void 0)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.hasTimestampPb = function() {
                    return null != s.Message.getField(this, 14)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getPlatformAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 15, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setPlatformAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 15, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getPbsAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 16, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setPbsAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 16, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getEventSource = function() {
                    return s.Message.getFieldWithDefault(this, 17, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setEventSource = function(e) {
                    return s.Message.setProto3StringField(this, 17, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getPriceUnmodified = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 18, 0)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setPriceUnmodified = function(e) {
                    return s.Message.setProto3FloatField(this, 18, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getTimestampPbjs = function() {
                    return s.Message.getFieldWithDefault(this, 19, 0)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setTimestampPbjs = function(e) {
                    return s.Message.setProto3IntField(this, 19, e)
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.getPrebidSource = function() {
                    return s.Message.getFieldWithDefault(this, 20, "")
                }, proto.schema_registry.prebid_js.NotificationJs.prototype.setPrebidSource = function(e) {
                    return s.Message.setProto3StringField(this, 20, e)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            6835(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.OrtbRequestJs", null, n), proto.schema_registry.prebid_js.OrtbRequestJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, proto.schema_registry.prebid_js.OrtbRequestJs.repeatedFields_, null)
                }, o.inherits(proto.schema_registry.prebid_js.OrtbRequestJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.OrtbRequestJs.displayName = "proto.schema_registry.prebid_js.OrtbRequestJs"), proto.schema_registry.prebid_js.OrtbRequestJs.repeatedFields_ = [44, 50], s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.OrtbRequestJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.OrtbRequestJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.toObject = function(e, t) {
                    var r, o = {
                        id: s.Message.getFieldWithDefault(t, 1, ""),
                        timestamp: s.Message.getFieldWithDefault(t, 2, ""),
                        deviceGeoCountry: s.Message.getFieldWithDefault(t, 3, ""),
                        deviceGeoRegion: s.Message.getFieldWithDefault(t, 4, ""),
                        deviceGeoCity: s.Message.getFieldWithDefault(t, 5, ""),
                        deviceGeoZip: s.Message.getFieldWithDefault(t, 6, ""),
                        deviceUserAgent: s.Message.getFieldWithDefault(t, 7, ""),
                        deviceMake: s.Message.getFieldWithDefault(t, 8, ""),
                        deviceModel: s.Message.getFieldWithDefault(t, 9, ""),
                        deviceOs: s.Message.getFieldWithDefault(t, 10, ""),
                        deviceOsVersion: s.Message.getFieldWithDefault(t, 11, ""),
                        deviceType: s.Message.getFieldWithDefault(t, 12, 0),
                        deviceDisabledTracking: s.Message.getFieldWithDefault(t, 13, 0),
                        deviceLimitTracking: s.Message.getFieldWithDefault(t, 14, 0),
                        deviceIp: s.Message.getFieldWithDefault(t, 15, ""),
                        userGdpr: s.Message.getFieldWithDefault(t, 16, 0),
                        userUsPrivacy: s.Message.getFieldWithDefault(t, 17, ""),
                        siteDomain: s.Message.getFieldWithDefault(t, 18, ""),
                        sitePage: s.Message.getFieldWithDefault(t, 19, ""),
                        siteRef: s.Message.getFieldWithDefault(t, 20, ""),
                        appName: s.Message.getFieldWithDefault(t, 22, ""),
                        appDomain: s.Message.getFieldWithDefault(t, 23, ""),
                        appVer: s.Message.getFieldWithDefault(t, 24, ""),
                        channel: s.Message.getFieldWithDefault(t, 26, ""),
                        cluster: s.Message.getFieldWithDefault(t, 28, ""),
                        node: s.Message.getFieldWithDefault(t, 29, ""),
                        appBundle: s.Message.getFieldWithDefault(t, 30, ""),
                        tmax: s.Message.getFieldWithDefault(t, 31, 0),
                        deviceCarrier: s.Message.getFieldWithDefault(t, 32, ""),
                        deviceLanguage: s.Message.getFieldWithDefault(t, 33, ""),
                        deviceLanguageb: s.Message.getFieldWithDefault(t, 34, ""),
                        appExtPrebidSource: s.Message.getFieldWithDefault(t, 35, ""),
                        appExtPrebidVersion: s.Message.getFieldWithDefault(t, 36, ""),
                        hasGdprConsentString: s.Message.getBooleanFieldWithDefault(t, 37, !1),
                        accountId: s.Message.getFieldWithDefault(t, 38, ""),
                        tenantName: s.Message.getFieldWithDefault(t, 39, ""),
                        sampleRate: s.Message.getFloatingPointFieldWithDefault(t, 40, 0),
                        deviceGeoLat: s.Message.getFloatingPointFieldWithDefault(t, 41, 0),
                        deviceGeoLong: s.Message.getFloatingPointFieldWithDefault(t, 42, 0),
                        hasGpp: s.Message.getBooleanFieldWithDefault(t, 43, !1),
                        gppSidList: null == (r = s.Message.getRepeatedField(t, 44)) ? void 0 : r,
                        impReqCount: s.Message.getFieldWithDefault(t, 45, 0),
                        timestampPb: (r = t.getTimestampPb()) && i.Timestamp.toObject(e, r),
                        platformAccountId: s.Message.getFieldWithDefault(t, 47, ""),
                        pbsAccountId: s.Message.getFieldWithDefault(t, 48, ""),
                        eventSource: s.Message.getFieldWithDefault(t, 49, ""),
                        gppSectionsList: null == (r = s.Message.getRepeatedField(t, 50)) ? void 0 : r,
                        timestampPbjs: s.Message.getFieldWithDefault(t, 51, 0),
                        prebidSource: s.Message.getFieldWithDefault(t, 52, ""),
                        rawRequest: s.Message.getFieldWithDefault(t, 53, "")
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.OrtbRequestJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.OrtbRequestJs;
                    return proto.schema_registry.prebid_js.OrtbRequestJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setId(r);
                                break;
                            case 2:
                                r = t.readString();
                                e.setTimestamp(r);
                                break;
                            case 3:
                                r = t.readString();
                                e.setDeviceGeoCountry(r);
                                break;
                            case 4:
                                r = t.readString();
                                e.setDeviceGeoRegion(r);
                                break;
                            case 5:
                                r = t.readString();
                                e.setDeviceGeoCity(r);
                                break;
                            case 6:
                                r = t.readString();
                                e.setDeviceGeoZip(r);
                                break;
                            case 7:
                                r = t.readString();
                                e.setDeviceUserAgent(r);
                                break;
                            case 8:
                                r = t.readString();
                                e.setDeviceMake(r);
                                break;
                            case 9:
                                r = t.readString();
                                e.setDeviceModel(r);
                                break;
                            case 10:
                                r = t.readString();
                                e.setDeviceOs(r);
                                break;
                            case 11:
                                r = t.readString();
                                e.setDeviceOsVersion(r);
                                break;
                            case 12:
                                r = t.readInt32();
                                e.setDeviceType(r);
                                break;
                            case 13:
                                r = t.readInt32();
                                e.setDeviceDisabledTracking(r);
                                break;
                            case 14:
                                r = t.readInt32();
                                e.setDeviceLimitTracking(r);
                                break;
                            case 15:
                                r = t.readString();
                                e.setDeviceIp(r);
                                break;
                            case 16:
                                r = t.readInt32();
                                e.setUserGdpr(r);
                                break;
                            case 17:
                                r = t.readString();
                                e.setUserUsPrivacy(r);
                                break;
                            case 18:
                                r = t.readString();
                                e.setSiteDomain(r);
                                break;
                            case 19:
                                r = t.readString();
                                e.setSitePage(r);
                                break;
                            case 20:
                                r = t.readString();
                                e.setSiteRef(r);
                                break;
                            case 22:
                                r = t.readString();
                                e.setAppName(r);
                                break;
                            case 23:
                                r = t.readString();
                                e.setAppDomain(r);
                                break;
                            case 24:
                                r = t.readString();
                                e.setAppVer(r);
                                break;
                            case 26:
                                r = t.readString();
                                e.setChannel(r);
                                break;
                            case 28:
                                r = t.readString();
                                e.setCluster(r);
                                break;
                            case 29:
                                r = t.readString();
                                e.setNode(r);
                                break;
                            case 30:
                                r = t.readString();
                                e.setAppBundle(r);
                                break;
                            case 31:
                                r = t.readInt64();
                                e.setTmax(r);
                                break;
                            case 32:
                                r = t.readString();
                                e.setDeviceCarrier(r);
                                break;
                            case 33:
                                r = t.readString();
                                e.setDeviceLanguage(r);
                                break;
                            case 34:
                                r = t.readString();
                                e.setDeviceLanguageb(r);
                                break;
                            case 35:
                                r = t.readString();
                                e.setAppExtPrebidSource(r);
                                break;
                            case 36:
                                r = t.readString();
                                e.setAppExtPrebidVersion(r);
                                break;
                            case 37:
                                r = t.readBool();
                                e.setHasGdprConsentString(r);
                                break;
                            case 38:
                                r = t.readString();
                                e.setAccountId(r);
                                break;
                            case 39:
                                r = t.readString();
                                e.setTenantName(r);
                                break;
                            case 40:
                                r = t.readDouble();
                                e.setSampleRate(r);
                                break;
                            case 41:
                                r = t.readDouble();
                                e.setDeviceGeoLat(r);
                                break;
                            case 42:
                                r = t.readDouble();
                                e.setDeviceGeoLong(r);
                                break;
                            case 43:
                                r = t.readBool();
                                e.setHasGpp(r);
                                break;
                            case 44:
                                for (var s = t.isDelimited() ? t.readPackedInt32() : [t.readInt32()], o = 0; o < s.length; o++) e.addGppSid(s[o]);
                                break;
                            case 45:
                                r = t.readInt32();
                                e.setImpReqCount(r);
                                break;
                            case 46:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestampPb(r);
                                break;
                            case 47:
                                r = t.readString();
                                e.setPlatformAccountId(r);
                                break;
                            case 48:
                                r = t.readString();
                                e.setPbsAccountId(r);
                                break;
                            case 49:
                                r = t.readString();
                                e.setEventSource(r);
                                break;
                            case 50:
                                r = t.readString();
                                e.addGppSections(r);
                                break;
                            case 51:
                                r = t.readInt64();
                                e.setTimestampPbjs(r);
                                break;
                            case 52:
                                r = t.readString();
                                e.setPrebidSource(r);
                                break;
                            case 53:
                                r = t.readString();
                                e.setRawRequest(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.OrtbRequestJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.OrtbRequestJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getId()).length > 0 && t.writeString(1, r), (r = e.getTimestamp()).length > 0 && t.writeString(2, r), null != (r = s.Message.getField(e, 3)) && t.writeString(3, r), null != (r = s.Message.getField(e, 4)) && t.writeString(4, r), null != (r = s.Message.getField(e, 5)) && t.writeString(5, r), null != (r = s.Message.getField(e, 6)) && t.writeString(6, r), null != (r = s.Message.getField(e, 7)) && t.writeString(7, r), null != (r = s.Message.getField(e, 8)) && t.writeString(8, r), null != (r = s.Message.getField(e, 9)) && t.writeString(9, r), null != (r = s.Message.getField(e, 10)) && t.writeString(10, r), null != (r = s.Message.getField(e, 11)) && t.writeString(11, r), null != (r = s.Message.getField(e, 12)) && t.writeInt32(12, r), null != (r = s.Message.getField(e, 13)) && t.writeInt32(13, r), null != (r = s.Message.getField(e, 14)) && t.writeInt32(14, r), null != (r = s.Message.getField(e, 15)) && t.writeString(15, r), null != (r = s.Message.getField(e, 16)) && t.writeInt32(16, r), null != (r = s.Message.getField(e, 17)) && t.writeString(17, r), null != (r = s.Message.getField(e, 18)) && t.writeString(18, r), null != (r = s.Message.getField(e, 19)) && t.writeString(19, r), null != (r = s.Message.getField(e, 20)) && t.writeString(20, r), null != (r = s.Message.getField(e, 22)) && t.writeString(22, r), null != (r = s.Message.getField(e, 23)) && t.writeString(23, r), null != (r = s.Message.getField(e, 24)) && t.writeString(24, r), null != (r = s.Message.getField(e, 26)) && t.writeString(26, r), null != (r = s.Message.getField(e, 28)) && t.writeString(28, r), null != (r = s.Message.getField(e, 29)) && t.writeString(29, r), (r = e.getAppBundle()).length > 0 && t.writeString(30, r), 0 !== (r = e.getTmax()) && t.writeInt64(31, r), (r = e.getDeviceCarrier()).length > 0 && t.writeString(32, r), (r = e.getDeviceLanguage()).length > 0 && t.writeString(33, r), (r = e.getDeviceLanguageb()).length > 0 && t.writeString(34, r), (r = e.getAppExtPrebidSource()).length > 0 && t.writeString(35, r), (r = e.getAppExtPrebidVersion()).length > 0 && t.writeString(36, r), (r = e.getHasGdprConsentString()) && t.writeBool(37, r), (r = e.getAccountId()).length > 0 && t.writeString(38, r), (r = e.getTenantName()).length > 0 && t.writeString(39, r), 0 !== (r = e.getSampleRate()) && t.writeDouble(40, r), 0 !== (r = e.getDeviceGeoLat()) && t.writeDouble(41, r), 0 !== (r = e.getDeviceGeoLong()) && t.writeDouble(42, r), (r = e.getHasGpp()) && t.writeBool(43, r), (r = e.getGppSidList()).length > 0 && t.writePackedInt32(44, r), 0 !== (r = e.getImpReqCount()) && t.writeInt32(45, r), null != (r = e.getTimestampPb()) && t.writeMessage(46, r, i.Timestamp.serializeBinaryToWriter), (r = e.getPlatformAccountId()).length > 0 && t.writeString(47, r), (r = e.getPbsAccountId()).length > 0 && t.writeString(48, r), (r = e.getEventSource()).length > 0 && t.writeString(49, r), (r = e.getGppSectionsList()).length > 0 && t.writeRepeatedString(50, r), 0 !== (r = e.getTimestampPbjs()) && t.writeInt64(51, r), (r = e.getPrebidSource()).length > 0 && t.writeString(52, r), (r = e.getRawRequest()).length > 0 && t.writeString(53, r)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getId = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setId = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getTimestamp = function() {
                    return s.Message.getFieldWithDefault(this, 2, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setTimestamp = function(e) {
                    return s.Message.setProto3StringField(this, 2, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceGeoCountry = function() {
                    return s.Message.getFieldWithDefault(this, 3, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceGeoCountry = function(e) {
                    return s.Message.setField(this, 3, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceGeoCountry = function() {
                    return s.Message.setField(this, 3, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceGeoCountry = function() {
                    return null != s.Message.getField(this, 3)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceGeoRegion = function() {
                    return s.Message.getFieldWithDefault(this, 4, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceGeoRegion = function(e) {
                    return s.Message.setField(this, 4, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceGeoRegion = function() {
                    return s.Message.setField(this, 4, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceGeoRegion = function() {
                    return null != s.Message.getField(this, 4)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceGeoCity = function() {
                    return s.Message.getFieldWithDefault(this, 5, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceGeoCity = function(e) {
                    return s.Message.setField(this, 5, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceGeoCity = function() {
                    return s.Message.setField(this, 5, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceGeoCity = function() {
                    return null != s.Message.getField(this, 5)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceGeoZip = function() {
                    return s.Message.getFieldWithDefault(this, 6, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceGeoZip = function(e) {
                    return s.Message.setField(this, 6, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceGeoZip = function() {
                    return s.Message.setField(this, 6, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceGeoZip = function() {
                    return null != s.Message.getField(this, 6)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceUserAgent = function() {
                    return s.Message.getFieldWithDefault(this, 7, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceUserAgent = function(e) {
                    return s.Message.setField(this, 7, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceUserAgent = function() {
                    return s.Message.setField(this, 7, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceUserAgent = function() {
                    return null != s.Message.getField(this, 7)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceMake = function() {
                    return s.Message.getFieldWithDefault(this, 8, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceMake = function(e) {
                    return s.Message.setField(this, 8, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceMake = function() {
                    return s.Message.setField(this, 8, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceMake = function() {
                    return null != s.Message.getField(this, 8)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceModel = function() {
                    return s.Message.getFieldWithDefault(this, 9, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceModel = function(e) {
                    return s.Message.setField(this, 9, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceModel = function() {
                    return s.Message.setField(this, 9, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceModel = function() {
                    return null != s.Message.getField(this, 9)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceOs = function() {
                    return s.Message.getFieldWithDefault(this, 10, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceOs = function(e) {
                    return s.Message.setField(this, 10, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceOs = function() {
                    return s.Message.setField(this, 10, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceOs = function() {
                    return null != s.Message.getField(this, 10)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceOsVersion = function() {
                    return s.Message.getFieldWithDefault(this, 11, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceOsVersion = function(e) {
                    return s.Message.setField(this, 11, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceOsVersion = function() {
                    return s.Message.setField(this, 11, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceOsVersion = function() {
                    return null != s.Message.getField(this, 11)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceType = function() {
                    return s.Message.getFieldWithDefault(this, 12, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceType = function(e) {
                    return s.Message.setField(this, 12, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceType = function() {
                    return s.Message.setField(this, 12, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceType = function() {
                    return null != s.Message.getField(this, 12)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceDisabledTracking = function() {
                    return s.Message.getFieldWithDefault(this, 13, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceDisabledTracking = function(e) {
                    return s.Message.setField(this, 13, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceDisabledTracking = function() {
                    return s.Message.setField(this, 13, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceDisabledTracking = function() {
                    return null != s.Message.getField(this, 13)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceLimitTracking = function() {
                    return s.Message.getFieldWithDefault(this, 14, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceLimitTracking = function(e) {
                    return s.Message.setField(this, 14, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceLimitTracking = function() {
                    return s.Message.setField(this, 14, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceLimitTracking = function() {
                    return null != s.Message.getField(this, 14)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceIp = function() {
                    return s.Message.getFieldWithDefault(this, 15, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceIp = function(e) {
                    return s.Message.setField(this, 15, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearDeviceIp = function() {
                    return s.Message.setField(this, 15, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasDeviceIp = function() {
                    return null != s.Message.getField(this, 15)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getUserGdpr = function() {
                    return s.Message.getFieldWithDefault(this, 16, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setUserGdpr = function(e) {
                    return s.Message.setField(this, 16, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearUserGdpr = function() {
                    return s.Message.setField(this, 16, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasUserGdpr = function() {
                    return null != s.Message.getField(this, 16)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getUserUsPrivacy = function() {
                    return s.Message.getFieldWithDefault(this, 17, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setUserUsPrivacy = function(e) {
                    return s.Message.setField(this, 17, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearUserUsPrivacy = function() {
                    return s.Message.setField(this, 17, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasUserUsPrivacy = function() {
                    return null != s.Message.getField(this, 17)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getSiteDomain = function() {
                    return s.Message.getFieldWithDefault(this, 18, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setSiteDomain = function(e) {
                    return s.Message.setField(this, 18, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearSiteDomain = function() {
                    return s.Message.setField(this, 18, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasSiteDomain = function() {
                    return null != s.Message.getField(this, 18)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getSitePage = function() {
                    return s.Message.getFieldWithDefault(this, 19, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setSitePage = function(e) {
                    return s.Message.setField(this, 19, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearSitePage = function() {
                    return s.Message.setField(this, 19, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasSitePage = function() {
                    return null != s.Message.getField(this, 19)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getSiteRef = function() {
                    return s.Message.getFieldWithDefault(this, 20, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setSiteRef = function(e) {
                    return s.Message.setField(this, 20, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearSiteRef = function() {
                    return s.Message.setField(this, 20, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasSiteRef = function() {
                    return null != s.Message.getField(this, 20)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAppName = function() {
                    return s.Message.getFieldWithDefault(this, 22, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAppName = function(e) {
                    return s.Message.setField(this, 22, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearAppName = function() {
                    return s.Message.setField(this, 22, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasAppName = function() {
                    return null != s.Message.getField(this, 22)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAppDomain = function() {
                    return s.Message.getFieldWithDefault(this, 23, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAppDomain = function(e) {
                    return s.Message.setField(this, 23, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearAppDomain = function() {
                    return s.Message.setField(this, 23, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasAppDomain = function() {
                    return null != s.Message.getField(this, 23)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAppVer = function() {
                    return s.Message.getFieldWithDefault(this, 24, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAppVer = function(e) {
                    return s.Message.setField(this, 24, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearAppVer = function() {
                    return s.Message.setField(this, 24, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasAppVer = function() {
                    return null != s.Message.getField(this, 24)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getChannel = function() {
                    return s.Message.getFieldWithDefault(this, 26, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setChannel = function(e) {
                    return s.Message.setField(this, 26, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearChannel = function() {
                    return s.Message.setField(this, 26, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasChannel = function() {
                    return null != s.Message.getField(this, 26)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getCluster = function() {
                    return s.Message.getFieldWithDefault(this, 28, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setCluster = function(e) {
                    return s.Message.setField(this, 28, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearCluster = function() {
                    return s.Message.setField(this, 28, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasCluster = function() {
                    return null != s.Message.getField(this, 28)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getNode = function() {
                    return s.Message.getFieldWithDefault(this, 29, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setNode = function(e) {
                    return s.Message.setField(this, 29, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearNode = function() {
                    return s.Message.setField(this, 29, void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasNode = function() {
                    return null != s.Message.getField(this, 29)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAppBundle = function() {
                    return s.Message.getFieldWithDefault(this, 30, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAppBundle = function(e) {
                    return s.Message.setProto3StringField(this, 30, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getTmax = function() {
                    return s.Message.getFieldWithDefault(this, 31, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setTmax = function(e) {
                    return s.Message.setProto3IntField(this, 31, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceCarrier = function() {
                    return s.Message.getFieldWithDefault(this, 32, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceCarrier = function(e) {
                    return s.Message.setProto3StringField(this, 32, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceLanguage = function() {
                    return s.Message.getFieldWithDefault(this, 33, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceLanguage = function(e) {
                    return s.Message.setProto3StringField(this, 33, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceLanguageb = function() {
                    return s.Message.getFieldWithDefault(this, 34, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceLanguageb = function(e) {
                    return s.Message.setProto3StringField(this, 34, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAppExtPrebidSource = function() {
                    return s.Message.getFieldWithDefault(this, 35, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAppExtPrebidSource = function(e) {
                    return s.Message.setProto3StringField(this, 35, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAppExtPrebidVersion = function() {
                    return s.Message.getFieldWithDefault(this, 36, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAppExtPrebidVersion = function(e) {
                    return s.Message.setProto3StringField(this, 36, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getHasGdprConsentString = function() {
                    return s.Message.getBooleanFieldWithDefault(this, 37, !1)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setHasGdprConsentString = function(e) {
                    return s.Message.setProto3BooleanField(this, 37, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 38, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 38, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getTenantName = function() {
                    return s.Message.getFieldWithDefault(this, 39, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setTenantName = function(e) {
                    return s.Message.setProto3StringField(this, 39, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getSampleRate = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 40, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setSampleRate = function(e) {
                    return s.Message.setProto3FloatField(this, 40, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceGeoLat = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 41, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceGeoLat = function(e) {
                    return s.Message.setProto3FloatField(this, 41, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getDeviceGeoLong = function() {
                    return s.Message.getFloatingPointFieldWithDefault(this, 42, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setDeviceGeoLong = function(e) {
                    return s.Message.setProto3FloatField(this, 42, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getHasGpp = function() {
                    return s.Message.getBooleanFieldWithDefault(this, 43, !1)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setHasGpp = function(e) {
                    return s.Message.setProto3BooleanField(this, 43, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getGppSidList = function() {
                    return s.Message.getRepeatedField(this, 44)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setGppSidList = function(e) {
                    return s.Message.setField(this, 44, e || [])
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.addGppSid = function(e, t) {
                    return s.Message.addToRepeatedField(this, 44, e, t)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearGppSidList = function() {
                    return this.setGppSidList([])
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getImpReqCount = function() {
                    return s.Message.getFieldWithDefault(this, 45, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setImpReqCount = function(e) {
                    return s.Message.setProto3IntField(this, 45, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getTimestampPb = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 46)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setTimestampPb = function(e) {
                    return s.Message.setWrapperField(this, 46, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearTimestampPb = function() {
                    return this.setTimestampPb(void 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.hasTimestampPb = function() {
                    return null != s.Message.getField(this, 46)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getPlatformAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 47, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setPlatformAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 47, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getPbsAccountId = function() {
                    return s.Message.getFieldWithDefault(this, 48, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setPbsAccountId = function(e) {
                    return s.Message.setProto3StringField(this, 48, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getEventSource = function() {
                    return s.Message.getFieldWithDefault(this, 49, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setEventSource = function(e) {
                    return s.Message.setProto3StringField(this, 49, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getGppSectionsList = function() {
                    return s.Message.getRepeatedField(this, 50)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setGppSectionsList = function(e) {
                    return s.Message.setField(this, 50, e || [])
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.addGppSections = function(e, t) {
                    return s.Message.addToRepeatedField(this, 50, e, t)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.clearGppSectionsList = function() {
                    return this.setGppSectionsList([])
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getTimestampPbjs = function() {
                    return s.Message.getFieldWithDefault(this, 51, 0)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setTimestampPbjs = function(e) {
                    return s.Message.setProto3IntField(this, 51, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getPrebidSource = function() {
                    return s.Message.getFieldWithDefault(this, 52, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setPrebidSource = function(e) {
                    return s.Message.setProto3StringField(this, 52, e)
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.getRawRequest = function() {
                    return s.Message.getFieldWithDefault(this, 53, "")
                }, proto.schema_registry.prebid_js.OrtbRequestJs.prototype.setRawRequest = function(e) {
                    return s.Message.setProto3StringField(this, 53, e)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            3368(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = function() {
                        return this ? this : "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : Function("return this")()
                    }.call(null),
                    i = r(4764);
                o.object.extend(proto, i), o.exportSymbol("proto.schema_registry.prebid_js.TestJs", null, n), proto.schema_registry.prebid_js.TestJs = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.schema_registry.prebid_js.TestJs, s.Message), o.DEBUG && !COMPILED && (proto.schema_registry.prebid_js.TestJs.displayName = "proto.schema_registry.prebid_js.TestJs"), s.Message.GENERATE_TO_OBJECT && (proto.schema_registry.prebid_js.TestJs.prototype.toObject = function(e) {
                    return proto.schema_registry.prebid_js.TestJs.toObject(e, this)
                }, proto.schema_registry.prebid_js.TestJs.toObject = function(e, t) {
                    var r, o = {
                        id: s.Message.getFieldWithDefault(t, 1, ""),
                        timestamp: (r = t.getTimestamp()) && i.Timestamp.toObject(e, r)
                    };
                    return e && (o.$jspbMessageInstance = t), o
                }), proto.schema_registry.prebid_js.TestJs.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.schema_registry.prebid_js.TestJs;
                    return proto.schema_registry.prebid_js.TestJs.deserializeBinaryFromReader(r, t)
                }, proto.schema_registry.prebid_js.TestJs.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readString();
                                e.setId(r);
                                break;
                            case 2:
                                r = new i.Timestamp;
                                t.readMessage(r, i.Timestamp.deserializeBinaryFromReader), e.setTimestamp(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.schema_registry.prebid_js.TestJs.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.schema_registry.prebid_js.TestJs.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.schema_registry.prebid_js.TestJs.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    (r = e.getId()).length > 0 && t.writeString(1, r), null != (r = e.getTimestamp()) && t.writeMessage(2, r, i.Timestamp.serializeBinaryToWriter)
                }, proto.schema_registry.prebid_js.TestJs.prototype.getId = function() {
                    return s.Message.getFieldWithDefault(this, 1, "")
                }, proto.schema_registry.prebid_js.TestJs.prototype.setId = function(e) {
                    return s.Message.setProto3StringField(this, 1, e)
                }, proto.schema_registry.prebid_js.TestJs.prototype.getTimestamp = function() {
                    return s.Message.getWrapperField(this, i.Timestamp, 2)
                }, proto.schema_registry.prebid_js.TestJs.prototype.setTimestamp = function(e) {
                    return s.Message.setWrapperField(this, 2, e)
                }, proto.schema_registry.prebid_js.TestJs.prototype.clearTimestamp = function() {
                    return this.setTimestamp(void 0)
                }, proto.schema_registry.prebid_js.TestJs.prototype.hasTimestamp = function() {
                    return null != s.Message.getField(this, 2)
                }, o.object.extend(t, proto.schema_registry.prebid_js)
            },
            719(e, t, r) {
                "use strict";
                r.d(t, {
                    K: () => s
                });
                class s {
                    store;
                    constructor() {
                        this.store = {}
                    }
                    getAttributes() {
                        return this.store
                    }
                    setAttribute(e, t) {
                        this.store[e] = t
                    }
                    setAttributes(e) {
                        Object.keys(e).forEach(t => {
                            this.store[t] = e[t]
                        })
                    }
                    getAttribute(e) {
                        return this.store[e]
                    }
                    removeAttribute(e) {
                        delete this.store[e]
                    }
                    hasAttribute(e) {
                        return e in this.store
                    }
                    clearAttributes() {
                        this.store = {}
                    }
                }
            },
            9326(e, t, r) {
                "use strict";
                r.d(t, {
                    U: () => o,
                    m: () => n
                });
                const s = new(r(719).K),
                    o = () => s.getAttributes(),
                    n = e => s.setAttributes(e)
            },
            2407(e, t, r) {
                "use strict";
                r.d(t, {
                    Ht: () => u,
                    wz: () => g,
                    pK: () => d,
                    tr: () => c,
                    mv: () => l
                });
                let s = (e = 21) => crypto.getRandomValues(new Uint8Array(e)).reduce((e, t) => e += (t &= 63) < 36 ? t.toString(36) : t < 62 ? (t - 26).toString(36).toUpperCase() : t > 62 ? "-" : "_", "");
                var o = r(4180),
                    n = r(801);
                const i = "ditu_user",
                    a = "ditu_session",
                    g = () => {
                        let e = JSON.parse(localStorage.getItem(i) || "{}"),
                            t = !1;
                        return e ? .id || (e = {
                            id: s(12),
                            userAddedTimestamp: Date.now()
                        }, t = !0), e.lastPageload = Date.now(), (e => {
                            localStorage.setItem(i, JSON.stringify(e))
                        })(e), {
                            isNewUser: t,
                            user: e
                        }
                    },
                    u = () => {
                        let e = JSON.parse(localStorage.getItem(a) || "{}"),
                            t = !1;
                        return !e ? .id || (e ? .lastActivityTimestamp || 0) < Date.now() - 18e5 ? (e = {
                            id: s(12),
                            idInt: (0, o.cp)()
                        }, t = !0) : null == e.idInt && (e.idInt = (0, o.cp)()), e.lastActivityTimestamp = Date.now(), (e => {
                            localStorage.setItem(a, JSON.stringify(e))
                        })(e), t && n.Vs.dispatch("create", {
                            session: e
                        }), {
                            isNewSession: t,
                            session: e
                        }
                    },
                    d = async () => {
                        let e = null,
                            t = !0;
                        if ("cookieDeprecationLabel" in navigator) {
                            const r = await navigator.cookieDeprecationLabel.getValue();
                            r && (e = r, t = !1)
                        }
                        return {
                            cookieDeprecationLabel: e,
                            doNotTrack: "1" === navigator.doNotTrack || "yes" === navigator.doNotTrack,
                            thirdPartyCookies: t
                        }
                    },
                    {
                        isNewUser: l
                    } = g(),
                    {
                        isNewSession: c
                    } = u();
                n.T9.on("pushEvent", () => (() => {
                    const {
                        session: e
                    } = u();
                    n.Vs.dispatch("update", {
                        session: e
                    })
                })())
            },
            7403(e, t, r) {
                "use strict";
                r.d(t, {
                    VK: () => f,
                    iy: () => S,
                    RS: () => j
                });
                var s = r(4886),
                    o = r(274);

                function n() {
                    const e = new URL(window.location.href),
                        {
                            hash: t,
                            host: r,
                            hostname: s,
                            href: o,
                            origin: n,
                            pathname: i,
                            port: a,
                            protocol: g,
                            search: u
                        } = e;
                    return {
                        hash: t,
                        host: r,
                        hostname: s,
                        href: o,
                        origin: n,
                        pathname: i,
                        port: a,
                        protocol: g,
                        search: u,
                        searchParams: Object.fromEntries(window.location.search.substring(1).split("&").filter(e => !!e).map(e => e.split("=").map(decodeURIComponent)))
                    }
                }

                function i() {
                    const e = "ditu_utms";
                    let t = {};
                    try {
                        const {
                            utmParams: r
                        } = JSON.parse(localStorage.getItem(e) || '{ "utmParams": {} }');
                        t = {
                            utmCampaign: r ? .utmCampaign,
                            utmContent: r ? .utmContent,
                            utmMedium: r ? .utmMedium,
                            utmSource: r ? .utmSource,
                            utmTerm: r ? .utmTerm
                        }
                    } catch (e) {}
                    const r = new URL(window.location.href),
                        o = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"],
                        n = o.map(e => (0, s.x)(e));
                    let i = !1;
                    if (o.forEach((e, s) => {
                            if (r.searchParams.has(e)) {
                                const o = n[s],
                                    a = r.searchParams.get(e);
                                a !== t[o] && (i = !0, t[o] = a)
                            }
                        }), i && "undefined" != typeof Storage) try {
                        localStorage.setItem(e, JSON.stringify({
                            utmParams: t
                        }))
                    } catch (e) {}
                    return t
                }
                var a = r(2407),
                    g = r(8704);
                const u = ["fbclid", "tbclid", "gclid", "obclid", "dicbo", "ttclid", "ScCid", "twclid"],
                    d = () => {
                        window.localStorage.setItem("rcik", "null"), window.localStorage.setItem("rciv", "null")
                    },
                    l = () => {
                        const e = window.localStorage.getItem("rcik"),
                            t = window.localStorage.getItem("rciv"),
                            r = {
                                rcik: "null" === e ? null : e || null,
                                rciv: "null" === t ? null : t || null
                            };
                        return g.Ay.debug("getClickId from localstorage", {
                            clickId: r,
                            rcik: e,
                            rciv: t
                        }), r
                    };
                var c = r(8047);
                let p;
                const b = () => {
                        const {
                            screen: e
                        } = window;
                        return `${e.width.toString()}x${e.height.toString()}`
                    },
                    _ = () => {
                        const e = (new c.UAParser).getResult(),
                            {
                                browser: t,
                                cpu: r,
                                device: s,
                                os: o,
                                ua: n
                            } = e;
                        p = {
                            browser: t.name,
                            browserMajor: t.major || "",
                            browserVersion: t.version,
                            cpuArch: r.architecture || "",
                            deviceModel: s.model,
                            deviceType: s.type || "desktop",
                            deviceVendor: s.vendor,
                            os: o.name,
                            osVersion: o.version,
                            screenResolution: b(),
                            userAgent: n
                        }
                    };
                _(), window.addEventListener("resize", () => {
                    p.screenResolution = b()
                });
                var $ = r(719),
                    h = r(5810),
                    m = r(801);
                const y = new $.K,
                    f = () => h.l.cast({ ...y.getAttributes()
                    }, {
                        stripUnknown: !0
                    }),
                    j = e => y.setAttributes(e),
                    S = (e, t) => y.setAttribute(e, t);
                (() => {
                    try {
                        const e = new URL(document.location.href).searchParams;
                        let t = !1;
                        u.forEach(r => {
                            if (t) return;
                            const s = e.get(r);
                            s && (window.localStorage.setItem("rcik", r), window.localStorage.setItem("rciv", s), t = !0)
                        }), t || d()
                    } catch (e) {
                        let t = "";
                        e instanceof Error ? t = e.message : "string" == typeof e ? t = e : "object" == typeof e && (t = JSON.stringify(e)), g.Ay.error("Error occurred setting click ids", t), d()
                    }
                })(), (async () => {
                    const {
                        user: e
                    } = (0, a.wz)(), {
                        session: t
                    } = (0, a.Ht)();
                    y.setAttributes({
                        browserTzOffset: (new Date).getTimezoneOffset(),
                        sessionId: t.id,
                        sessionIdInt: t.idInt,
                        userId: e.id,
                        version: "1.20.0-69wxiu",
                        ...l(),
                        ...(p || _(), p),
                        ...i(),
                        ...n()
                    });
                    const r = await (0, a.pK)();
                    y.setAttributes(r), "true" === localStorage.getItem("ditu_identity_providers_sampled") && async function() {
                        const {
                            pbjsGlobals: e = ["pbjs"]
                        } = (0, o.Xd)(), t = e[0];
                        if (!t) return null;
                        try {
                            const e = window[t];
                            if (e ? .getUserIdsAsync) {
                                const t = await e.getUserIdsAsync();
                                return t ? JSON.stringify(t) : null
                            }
                            return null
                        } catch (e) {
                            return null
                        }
                    }().then(e => y.setAttributes({
                        identityProviders: e
                    }))
                })(), m.Vs.on("update", e => {
                    const {
                        session: t
                    } = e;
                    t && t.id && y.setAttributes({
                        sessionId: t.id,
                        sessionIdInt: t.idInt
                    })
                })
            },
            3564(e, t, r) {
                "use strict";
                r.d(t, {
                    M: () => o,
                    i: () => n
                });
                const s = new(r(719).K),
                    o = () => s.getAttributes(),
                    n = e => {
                        s.setAttributes(e)
                    }
            },
            2218(e, t, r) {
                "use strict";
                r.d(t, {
                    B: () => a
                });
                var s = r(5586),
                    o = r(739);
                class n extends o.b {
                    props;
                    constructor(e) {
                        super(), this.props = e
                    }
                    get bidMap() {
                        return this.props.bidMap
                    }
                    get id() {
                        return this.props.id
                    }
                    get sourceGamId() {
                        return this.props.sourceGamId
                    }
                    get updatedAt() {
                        return this.props.updatedAt
                    }
                }
                let i = null;
                async function a(e) {
                    if (i) return {
                        getAmazonBid: e => i ? .bidMap[e] ? ? 1e-4
                    };
                    const t = await (0, s.K)({
                            publisherId: e.publisherId
                        }),
                        {
                            amazon: r
                        } = t;
                    if (!r || 0 === r.length) return {};
                    const {
                        bidMap: o,
                        id: a,
                        sourceGamId: g,
                        updatedAt: u
                    } = r[0];
                    return i = new n({
                        bidMap: o,
                        id: a,
                        sourceGamId: g,
                        updatedAt: u
                    }), {
                        getAmazonBid: e => i ? .bidMap[e] ? ? 1e-4
                    }
                }
            },
            8481(e, t, r) {
                "use strict";
                r.d(t, {
                    i: () => s
                });
                class s {
                    static modelProvider;
                    static setModelProvider(e) {
                        this.modelProvider = e
                    }
                    static async estimateCpm(e, t) {
                        const r = await (this.modelProvider ? .getBidEstimationModel(e));
                        return r ? .estimateCpm(t)
                    }
                    static async getBidEstimationModel(e) {
                        return this.modelProvider ? .getBidEstimationModel(e)
                    }
                }
            },
            274(e, t, r) {
                "use strict";
                r.d(t, {
                    Xd: () => d,
                    qV: () => l,
                    t2: () => u
                });
                var s = r(9612),
                    o = r(8704),
                    n = r(4180);
                let i = {
                    adServers: ["googletag"],
                    pbjsGlobals: ["pbjs"],
                    primaryAdServer: "googletag",
                    ingressEndpoints: []
                };
                const a = [],
                    g = new Set,
                    u = e => {
                        const t = Object.assign({}, i);
                        i = { ...i,
                            ...e
                        }, ((e, t) => {
                            a.forEach(r => r(e, t)), t.ingressEndpoints && t.ingressEndpoints !== e.ingressEndpoints && t.ingressEndpoints.length > 0 && (g.forEach(e => {
                                try {
                                    e(t.ingressEndpoints)
                                } catch (e) {
                                    o.Ay.error("Error in endpoint update callback", {
                                        error: e
                                    }, "State")
                                }
                            }), g.size > 0 && o.Ay.debug("Processor endpoints updated", {
                                endpointCount: t.ingressEndpoints.length,
                                processorCount: g.size
                            }, "State"))
                        })(t, i), o.Ay.verbose("Global state updated", i, "State")
                    },
                    d = () => (null != i.pageviewId && null == i.pageviewIdInt && (i.pageviewIdInt = (0, n.cp)()), i),
                    l = () => {
                        const e = (0, s.A)(),
                            t = (0, n.cp)();
                        return u({
                            pageviewId: e,
                            pageviewIdInt: t
                        }), {
                            pageviewId: e,
                            pageviewIdInt: t
                        }
                    };
                l()
            },
            5500(e, t, r) {
                "use strict";
                r.d(t, {
                    A: () => s
                });
                const s = async (e, t) => (await fetch(`https://raven-edge.aditude.io/api/v1${t}`, {
                    method: e ? ? "GET",
                    mode: "cors"
                })).json()
            },
            5586(e, t, r) {
                "use strict";
                r.d(t, {
                    K: () => i
                });
                var s = r(8704),
                    o = r(5500);
                let n = null;
                const i = async e => {
                    if (n) return n;
                    try {
                        n = (0, o.A)("GET", `/revenuesourcemaps/${e.publisherId}`), n.then(e => s.Ay.debug("fetched revenue source maps from edge", e))
                    } catch (e) {
                        return (e instanceof Error || "string" == typeof e) && s.Ay.error("Failed to fetch revenue source maps from edge", e), n = null, {
                            amazon: [],
                            sources: []
                        }
                    }
                    return n
                }
            },
            2909(e, t, r) {
                "use strict";
                r.d(t, {
                    i8: () => o,
                    ow: () => s,
                    pM: () => n,
                    pX: () => i
                });
                const s = "pbjs",
                    o = "raven",
                    n = 2e3,
                    i = ["prebid_bid", "prebid_bidder_request", "prebid_errors_js", "prebid_impression_request", "prebid_notification_event", "prebid_ortb_request"]
            },
            8076(e, t, r) {
                "use strict";
                r.d(t, {
                    UF: () => c,
                    e0: () => l
                });
                var s = r(274),
                    o = r(92),
                    n = r(8704);
                const i = e => "osVersion" in e || "browserVersion" in e;
                let a = !1,
                    g = !1,
                    u = !1;
                const d = e => {
                        const t = { ...e
                        };
                        if (i(t)) {
                            const e = t.browserVersion,
                                r = (0, o.cj)({
                                    browserVersion: t.browserVersion
                                });
                            t.browserVersion = r.browserVersion, a || e === t.browserVersion || (n.Ay.debug("Applied browser version shortening to event data", {
                                original: e,
                                shortened: t.browserVersion
                            }), a = !0)
                        }
                        return t
                    },
                    l = e => {
                        if (!(0, s.Xd)().tcfConsent) return d(e);
                        return ["device_geo_city", "device_geo_lat", "device_geo_long", "device_geo_zip"].forEach(t => {
                            e[t] && (e[t] = "no consent")
                        }), e
                    },
                    c = e => {
                        const t = (0, s.Xd)().tcfConsent;
                        if (!t) return d(e);
                        if (!t.shouldScrubData) return d(e);
                        const r = { ...e
                        };
                        if (r.geo && "object" == typeof r.geo) {
                            const s = r.geo;
                            r.geo = (0, o.$R)(s), g || (n.Ay.debug("Applied GDPR geo scrubbing to event data", {
                                original: e.geo,
                                scrubbed: r.geo,
                                consentState: t
                            }), g = !0)
                        }
                        if (i(r)) {
                            const e = {
                                    osVersion: r.osVersion,
                                    browserVersion: r.browserVersion
                                },
                                s = (0, o.wK)({
                                    osVersion: r.osVersion,
                                    browserVersion: r.browserVersion
                                });
                            r.osVersion = s.osVersion, r.browserVersion = s.browserVersion, u || (n.Ay.debug("Applied GDPR device scrubbing to event data", {
                                original: e,
                                scrubbed: {
                                    osVersion: r.osVersion,
                                    browserVersion: r.browserVersion
                                },
                                consentState: t
                            }), u = !0)
                        }
                        return r
                    }
            },
            1336(e, t, r) {
                "use strict";
                r.d(t, {
                    $: () => n
                });
                var s = r(8704),
                    o = r(1169);
                const n = (e, t) => {
                    const r = o.Tz[e];
                    if (!r) return s.Ay.error(`No schema found for ${e} event`), t;
                    try {
                        r.validateSync(t)
                    } catch (r) {
                        let o = "";
                        return r instanceof Error && (o = r.message), s.Ay.error(`${e} event data failed to validate`, {
                            data: t,
                            error: o
                        }), t
                    }
                    return r.cast({ ...t
                    }, {
                        stripUnknown: !0
                    })
                }
            },
            92(e, t, r) {
                "use strict";
                r.d(t, {
                    $R: () => o,
                    cj: () => i,
                    wK: () => n
                });
                const s = e => e.includes(":") ? (e => {
                        let t = e.toLowerCase();
                        if (t.includes("::")) {
                            const e = t.split("::"),
                                r = e[0] ? e[0].split(":") : [],
                                s = e[1] ? e[1].split(":") : [],
                                o = 8 - r.length - s.length;
                            t = [...r, ...Array(o).fill("0000"), ...s].join(":")
                        }
                        const r = t.split(":");
                        return 8 !== r.length ? e : `${r.slice(0,7).join(":")}::`
                    })(e) : e.includes(".") ? (e => {
                        const t = e.split(".");
                        return 4 !== t.length ? e : `${t[0]}.${t[1]}.${t[2]}.0`
                    })(e) : e,
                    o = e => ({ ...e,
                        address: e.address ? s(e.address) : null,
                        city: "no consent",
                        "postal-code": "no consent"
                    }),
                    n = e => {
                        return { ...e,
                            osVersion: "",
                            browserVersion: (t = e.browserVersion, (r = t || void 0) && "string" == typeof r && /^\d+(\.\d+){1,3}$/.test(r.trim()) && (e => {
                                if (!e || "string" != typeof e) return e;
                                const t = e.split(".")[0];
                                return t && t.trim() ? t : ""
                            })(t || "") || "")
                        };
                        var t, r
                    },
                    i = e => {
                        return { ...e,
                            browserVersion: (t = e.browserVersion, t || "")
                        };
                        var t
                    }
            },
            4180(e, t, r) {
                "use strict";

                function s(e) {
                    if ("undefined" != typeof crypto && crypto.getRandomValues) crypto.getRandomValues(e);
                    else
                        for (let t = 0; t < e.length; t++) e[t] = Math.floor(256 * Math.random())
                }
                r.d(t, {
                    cp: () => o
                });
                const o = () => function(e) {
                    const t = new Uint8Array(e);
                    s(t);
                    const r = BigInt(8);
                    let o = BigInt(0);
                    for (let s = 0; s < e; s++) o = o << r | BigInt(t[s]);
                    return o.toString()
                }(8)
            },
            4886(e, t, r) {
                "use strict";
                r.d(t, {
                    u: () => s,
                    x: () => o
                });
                const s = e => e.replace(/\*/g, "(.*)+"),
                    o = e => e && 0 !== e.length ? e.replace(/[-_](\w)/g, (e, t) => t.toUpperCase()) : e
            },
            8386(e, t, r) {
                "use strict";
                r.d(t, {
                    $3: () => i,
                    K6: () => n,
                    fD: () => o
                });
                var s = r(8704);

                function o(e, t) {
                    s.Ay.verbose(`dispatching -> ${e}`, t ? ? {}), window.dispatchEvent(new CustomEvent(e, {
                        detail: t
                    }))
                }

                function n() {
                    const e = window.location.ancestorOrigins;
                    if (e && e.length > 0) return new URL(e[0] ? ? "").hostname;
                    const t = window.top ? .location.origin ? ? null,
                        r = new URL(window.location.href);
                    return t && t !== r.origin ? new URL(t ? ? "").hostname : r.hostname
                }
                const i = (e, t) => {
                    if ("undefined" == typeof window) return !1;
                    const r = Object.getOwnPropertyDescriptor(window, e);
                    if (r && !r.configurable) return s.Ay.warn(`Cannot watch window.${e}: property is not configurable`), !1;
                    let o = window[e];
                    return Object.defineProperty(window, e, {
                        get: () => o,
                        set(e) {
                            o = e, null != e && t(e)
                        },
                        configurable: !0
                    }), null != o && t(o), !0
                }
            },
            7551(e, t, r) {
                "use strict";
                r.d(t, {
                    J3: () => g,
                    Jf: () => u,
                    Ni: () => a
                });
                var s = r(4886),
                    o = r(8704);
                let n = [];
                const i = e => e ? "^" + (0, s.u)(e) + "$" : null,
                    a = e => {
                        const t = e.map(e => {
                            const t = ["bidder", "mediaType"].filter(t => !e[t]).length,
                                r = i(e.bidder),
                                s = i(e.mediaType);
                            return {
                                modifier: e.modifier,
                                bidder: r,
                                mediaType: s,
                                n: t
                            }
                        });
                        t.sort((e, t) => e.n - t.n), n = t, o.Ay.debug("Bidder modifiers set", t)
                    };
                const g = (e, t) => n.find(r => function(e, t, r) {
                        if (e.bidder) {
                            if (!new RegExp(e.bidder).test(t)) return !1;
                            if (e.mediaType) return new RegExp(e.mediaType).test(r)
                        }
                        return !e.mediaType || new RegExp(e.mediaType).test(r)
                    }(r, e, t)) ? .modifier,
                    u = (e, t, r) => {
                        const s = g(t, r);
                        if (s) try {
                            return e * s
                        } catch (e) {
                            o.Ay.error("Error applying bid modifier", {
                                error: e,
                                multiplier: s
                            })
                        }
                        return e
                    }
            },
            801(e, t, r) {
                "use strict";
                r.d(t, {
                    T9: () => o,
                    Vs: () => n
                });
                class s {
                    listeners = {};
                    on(e, t) {
                        this.listeners[e] && void 0 !== this.listeners[e] || (this.listeners[e] = []), this.listeners[e].push(t)
                    }
                    dispatch(e, t) {
                        (this.listeners[e] || []).forEach(e => e(t))
                    }
                    remove(e, t) {
                        const r = this.listeners[e] || [];
                        r.length > 0 && (this.listeners[e] = r.filter(e => e === t))
                    }
                }
                const o = new s,
                    n = new s
            },
            8704(e, t, r) {
                "use strict";
                r.d(t, {
                    Ay: () => c,
                    S_: () => g
                });
                var s = r(7253);
                const o = "padding:1px 3px;font-size:0.75em;color:#ffffff;",
                    n = `background-color:#000;margin-left:1px;${o}`,
                    i = `background-color:#5D3FD3;${o}`,
                    a = "font-size:0.9em;",
                    g = (e, t) => [`%craven%c${e}%c ${t}`, n, i, a],
                    u = function(e, t, r) {
                        let s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "log";
                        const o = r ? g(r, e) : (e => [`%craven%c ${e}`, n, a])(e);
                        t ? console[s](...o, t) : console[s](...o)
                    },
                    d = e => {
                        const t = new URLSearchParams(window.location.search);
                        let r = 0;
                        return t.has("ravenLogLevel") && (r = parseInt(t.get("ravenLogLevel") ? ? "0")), r >= e
                    },
                    l = (e, t, r, s, o) => d(e) && u(t, r, s, o),
                    c = {
                        always: u,
                        debug: (e, t, r) => l(3, e, t, r),
                        enabled: () => d(3),
                        error: (e, t, r) => {
                            l(1, e, t, r, "error"), ((e, t, r) => {
                                (0, s.gR)(s => {
                                    let {
                                        events: o
                                    } = s;
                                    const n = t ? "string" == typeof t ? t : JSON.stringify(t) : null;
                                    o.send("ravenError", {
                                        code: r ? ? null,
                                        message: `${e}${n||""}`
                                    })
                                })
                            })(e, t)
                        },
                        verbose: (e, t, r) => l(4, e, t, r),
                        warn: (e, t, r) => l(2, e, t, r, "warn")
                    }
            },
            739(e, t, r) {
                "use strict";
                r.d(t, {
                    b: () => s
                });
                class s {}
            },
            5019(e, t, r) {
                "use strict";
                r.d(t, {
                    G: () => o
                });
                var s = r(739);
                class o extends s.b {
                    props;
                    constructor(e) {
                        super(), this.props = e
                    }
                    get bidder() {
                        return this.props.bidder ? ? this.props.source
                    }
                    get source() {
                        return this.props.source
                    }
                    get type() {
                        return this.props.type
                    }
                    get value() {
                        return this.props ? .value ? ? 0
                    }
                    toObject() {
                        return Object.assign({}, this.props)
                    }
                }
            },
            990(e, t, r) {
                "use strict";
                r.d(t, {
                    v: () => d
                });
                var s = r(9612),
                    o = r(8704),
                    n = r(5810),
                    i = r(739),
                    a = r(801),
                    g = r(1169),
                    u = r(274);
                class d extends i.b {
                    endpoints;
                    globalAttrs = {};
                    beforeSendHandlers = [];
                    queue = [];
                    constructor(e, t) {
                        super(), this.endpoints = e, setTimeout(() => {
                            setInterval(() => {
                                this.persistEvents()
                            }, t.queueInterval ? ? 1e3)
                        }, 3e3), document.addEventListener("visibilitychange", () => {
                            o.Ay.debug("visibilitychange", document.visibilityState), "hidden" === document.visibilityState && this.flushEvents()
                        }), document.addEventListener("pagehide", () => {
                            this.flushEvents()
                        })
                    }
                    onBeforeSend(e) {
                        this.beforeSendHandlers.push(e)
                    }
                    getGlobalAttribute(e) {
                        return this.globalAttrs[e]
                    }
                    setGlobalAttribute(e, t) {
                        this.globalAttrs[e] = t
                    }
                    setGlobalAttributes(e) {
                        this.globalAttrs = { ...this.globalAttrs,
                            ...e
                        }
                    }
                    createGlobalObject() {
                        return n.l.cast({ ...this.globalAttrs
                        }, {
                            stripUnknown: !0
                        })
                    }
                    pushEvent(e, t) {
                        const {
                            pageviewId: r,
                            pageviewIdInt: n
                        } = (0, u.Xd)(), i = {
                            eventType: e,
                            data: { ...(0, g.vE)(e, t),
                                eventType: e
                            },
                            ravenId: (0, s.A)(),
                            pageviewId: r,
                            pageviewIdInt: n
                        };
                        o.Ay.debug("queued", i, e), this.queue.push(i), a.T9.dispatch("pushEvent", i)
                    }
                    flushEvents() {
                        this.persistEvents(!0)
                    }
                    persistEvents() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        const t = this.queue.splice(0, this.queue.length).map(e => {
                            const {
                                eventType: t,
                                data: r,
                                ...s
                            } = e, o = (0, g.Id)(t, r);
                            let n = Object.assign({}, o);
                            return this.beforeSendHandlers.length > 0 && this.beforeSendHandlers.forEach(e => {
                                n = { ...n,
                                    ...e(n) ? ? {}
                                }
                            }), { ...n,
                                eventType: t,
                                ...s
                            }
                        });
                        this.endpoints.forEach(r => {
                            r.batchAndSend(t, e)
                        })
                    }
                    setEndpoints(e) {
                        this.endpoints = e
                    }
                    pageview(e) {
                        e || (0, u.qV)(), this.pushEvent("pageView", {})
                    }
                }
            },
            7847(e, t, r) {
                "use strict";
                r.d(t, {
                    A: () => s
                });
                class s {
                    static defaultProcessor;
                    static eventProcessors = {};
                    static pushEvent(e, t) {
                        let r = Object.values(this.eventProcessors).find(t => t.events.includes(e));
                        if (r || (r = Object.values(this.eventProcessors).find(e => e.events.includes("*"))), !r) throw new Error(`Event processor config not found for event ${name}`);
                        const {
                            processor: s
                        } = r;
                        s.pushEvent(e, t)
                    }
                    static registerEventProcessor(e, t) {
                        this.eventProcessors[e] = t, this.defaultProcessor || (this.defaultProcessor = t)
                    }
                }
            },
            9060(e, t, r) {
                "use strict";
                r.d(t, {
                    T: () => p
                });
                var s = r(8704),
                    o = r(739),
                    n = r(6442),
                    i = r(2909);

                function a(e) {
                    return i.pX.includes(e)
                }

                function g(e, t, r) {
                    const s = e;
                    for (const [e, o] of Object.entries(r)) {
                        const r = Array.isArray(o) ? o.map(e => t[e]).find(e => null != e && "" !== e) : t[o];
                        null != r && "" !== r && s[e] ? .(String(r))
                    }
                }

                function u(e, t, r) {
                    const s = e;
                    for (const [e, o] of Object.entries(r)) {
                        const r = t[o];
                        null != r && "number" == typeof r && s[e] ? .(r)
                    }
                }

                function d(e, t, r) {
                    const s = e;
                    for (const [e, o] of Object.entries(r)) {
                        const r = t[o];
                        "boolean" == typeof r && s[e] ? .(r)
                    }
                }
                const l = {
                    setId: "id",
                    setTimestamp: "timestamp",
                    setDeviceGeoCountry: "device_geo_country",
                    setDeviceGeoRegion: "device_geo_region",
                    setDeviceGeoCity: "device_geo_city",
                    setDeviceGeoZip: "device_geo_zip",
                    setDeviceUserAgent: "device_user_agent",
                    setDeviceMake: "device_make",
                    setDeviceModel: "device_model",
                    setDeviceOs: "device_os",
                    setDeviceOsVersion: "device_os_version",
                    setDeviceIp: "device_ip",
                    setUserUsPrivacy: "user_us_privacy",
                    setSiteDomain: "site_domain",
                    setSitePage: "site_page",
                    setSiteRef: "site_ref",
                    setChannel: "channel",
                    setAppBundle: "app_bundle",
                    setDeviceCarrier: "device_carrier",
                    setDeviceLanguage: "device_language",
                    setDeviceLanguageb: "device_languageb",
                    setTenantName: "tenant_name",
                    setPlatformAccountId: "platform_account_id",
                    setEventSource: "event_source"
                };

                function c(e, t) {
                    const r = t.filter(e => "string" == typeof e.eventType && a(e.eventType));
                    if (0 === r.length) return;
                    const o = new n.PrebidJSEventsClient(e, {
                            mode: "cors",
                            "content-type": "application/grpc-web"
                        }),
                        i = new Map;
                    for (const e of r) {
                        const t = e.eventType;
                        i.has(t) || i.set(t, []), i.get(t).push(e)
                    }
                    const c = {},
                        p = {
                            prebid_bid: async e => {
                                const t = new n.LogBidJsRequest;
                                t.setBidsList(e.map(e => function(e) {
                                    const t = new n.BidJs;
                                    return g(t, e, {
                                        setTimestamp: ["timestamp", "ts"],
                                        setAuctionId: "auction_id",
                                        setImpId: "imp_id",
                                        setId: "id",
                                        setEventId: "event_id",
                                        setChannel: "channel",
                                        setIntegration: "integration",
                                        setDomain: "domain",
                                        setPublisherId: "platform_account_id",
                                        setAppBundle: "app_bundle",
                                        setBidder: "bidder",
                                        setSeat: "seat",
                                        setMediaType: "media_type",
                                        setCreativeId: "creative_id",
                                        setDealId: "deal_id",
                                        setSize: "size",
                                        setOrtbRequestId: "ortb_request_id",
                                        setTenantName: "tenant_name",
                                        setPriceCurrency: "price_currency",
                                        setGpid: "gpid",
                                        setPlacementId: "placement_id",
                                        setPlatformAccountId: "platform_account_id",
                                        setEventSource: "event_source",
                                        setPrebidSource: "prebid_source"
                                    }), u(t, e, {
                                        setBidModifier: "bid_modifier",
                                        setPrice: "price",
                                        setExpireAfterSeconds: "expire_after_seconds",
                                        setResponseTime: "response_time",
                                        setSampleRate: "sample_rate"
                                    }), Array.isArray(e.advertiser_domains) && t.setAdvertiserDomainsList(e.advertiser_domains.map(String)), Array.isArray(e.categories) && t.setCategoriesList(e.categories.map(String)), e.timestamp_pb, t
                                }(e))), await o.logBidJs(t, c)
                            },
                            prebid_notification_event: async e => {
                                const t = new n.LogNotificationJsRequest;
                                t.setNotificationsList(e.map(e => function(e) {
                                    const t = new n.NotificationJs;
                                    return g(t, e, {
                                        setTimestamp: ["timestamp", "ts", "auction_timestamp", "auction_ts"],
                                        setType: "type",
                                        setBidId: "bid_id",
                                        setAccountId: "account_id",
                                        setBidder: "bidder",
                                        setAuctionTimestamp: ["auction_timestamp", "auction_ts"],
                                        setIntegration: "integration",
                                        setTenantName: "tenant_name",
                                        setImpId: "imp_id",
                                        setOrtbRequestId: "ortb_request_id",
                                        setPriceCurrency: "price_currency",
                                        setPlatformAccountId: ["platform_accout_id", "platform_account_id"],
                                        setEventSource: "event_source"
                                    }), u(t, e, {
                                        setSampleRate: "sample_rate",
                                        setPrice: "price"
                                    }), e.timestamp_pb, t
                                }(e))), await o.logNotificationJs(t, c)
                            },
                            prebid_ortb_request: async e => {
                                const t = new n.LogOrtbRequestJsRequest;
                                t.setOrtbRequestList(e.map(e => function(e) {
                                    const t = new n.OrtbRequestJs;
                                    return g(t, e, l), u(t, e, {
                                        setDeviceType: "device_type",
                                        setDeviceDisabledTracking: "device_disabled_tracking",
                                        setDeviceLimitTracking: "device_limit_tracking",
                                        setUserGdpr: "user_gdpr",
                                        setTmax: "tmax",
                                        setImpReqCount: "imp_req_count",
                                        setSampleRate: "sample_rate"
                                    }), d(t, e, {
                                        setHasGdprConsentString: "has_gdpr_consent_string",
                                        setHasGpp: "has_gpp"
                                    }), Array.isArray(e.gpp_sid) && t.setGppSidList(e.gpp_sid.map(e => Number(e))), e.timestamp_pb, t
                                }(e))), await o.logOrtbRequestJs(t, c)
                            },
                            prebid_impression_request: async e => {
                                const t = new n.LogImpressionRequestJsRequest;
                                t.setImpressionRequestList(e.map(e => function(e) {
                                    const t = new n.ImpressionRequestJs;
                                    return g(t, e, {
                                        setImpressionId: "impression_id",
                                        setOrtbRequestId: "ortb_request_id",
                                        setTimestamp: "timestamp",
                                        setTagid: "tagid",
                                        setGpid: "gpid",
                                        setAdUnitCode: "ad_unit_code",
                                        setTenantName: "tenant_name",
                                        setBidFloorCurrency: "bid_floor_currency",
                                        setMediaType: "media_type",
                                        setPlatformAccountId: "platform_account_id",
                                        setEventSource: "event_source"
                                    }), u(t, e, {
                                        setInstl: "instl",
                                        setBidfloor: "bidfloor",
                                        setVideoMaxduration: "video_maxduration",
                                        setSampleRate: "sample_rate"
                                    }), Array.isArray(e.size) && t.setSizeList(e.size.map(String)), e.timestamp_pb, t
                                }(e))), await o.logImpressionRequestJs(t, c)
                            },
                            prebid_bidder_request: async e => {
                                const t = new n.LogBidderRequestJsRequest;
                                t.setBidderRequestList(e.map(e => function(e) {
                                    const t = new n.BidderRequestJs;
                                    g(t, e, {
                                        setTimestamp: "timestamp",
                                        setBidder: "bidder",
                                        setOrtbRequestId: "ortb_request_id",
                                        setAppBundle: "app_bundle",
                                        setChannel: "channel",
                                        setIntegration: "integration",
                                        setDomain: "domain",
                                        setPublisherId: "publisher_id",
                                        setTenantName: "tenant_name",
                                        setGpid: "gpid",
                                        setImpressionId: "impression_id",
                                        setPlacementId: "placement_id",
                                        setBidderRequestId: "bidder_request_id",
                                        setPlatformAccountId: "platform_account_id",
                                        setEventSource: "event_source",
                                        setPrebidSource: "prebid_source"
                                    }), u(t, e, {
                                        setImpCount: "imp_count",
                                        setTmax: "tmax",
                                        setSampleRate: "sample_rate"
                                    }), d(t, e, {
                                        setHasTimedOut: "has_timed_out",
                                        setHasError: "has_error"
                                    });
                                    const r = Array.isArray(e.bid_count) ? e.bid_count.length : e.bid_count;
                                    return "number" == typeof r && t.setBidCount(r), e.timestamp_pb, t
                                }(e))), await o.logBidderRequestJs(t, c)
                            },
                            prebid_errors_js: async e => {
                                const t = new n.LogErrorsJsRequest;
                                t.setErrorsList(e.map(e => function(e) {
                                    const t = new n.ErrorsJs;
                                    return g(t, e, {
                                        setId: "id",
                                        setTimestamp: ["timestamp", "ts"],
                                        setMessage: "message",
                                        setOrtbRequestId: "ortb_request_id"
                                    }), t
                                }(e))), await o.logErrorsJs(t, c)
                            }
                        },
                        b = (e, t) => {
                            const r = {
                                type: "EventStreamError",
                                subtype: "",
                                name: e,
                                endpointType: "event-stream",
                                msg: "",
                                trace: null
                            };
                            t instanceof Error ? (r.msg = t.message, r.subtype = t.name, r.trace = t ? .stack ? ? null) : (r.msg = "object" == typeof t && null !== t && "statusText" in t ? t.statusText : "Unknown error.", r.subtype = "unknown"), s.Ay.warn(`Event stream ${e} failed.`, { ...r
                            }, "prebid-js-analytics")
                        };
                    for (const [e, t] of Array.from(i)) {
                        const r = t.map(e => {
                                const {
                                    ravenId: t,
                                    pageviewId: r,
                                    pageviewIdInt: s,
                                    ...o
                                } = e;
                                return o
                            }),
                            s = p[e];
                        s && (async () => {
                            try {
                                await s(r)
                            } catch (t) {
                                b(e, t)
                            }
                        })()
                    }
                }
                class p extends o.b {
                    props;
                    onFailureHandler;
                    constructor(e) {
                        super(), this.props = e
                    }
                    async sendBatch(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        if ("event-stream" === this.ingressName) return s.Ay.debug(`sendBatch attempt to ${this.ingressName}`, {
                            batch: e,
                            endpointId: this.id
                        }), void c(this.ingressUrl, e);
                        const r = [];
                        for (const t of e) "string" == typeof t.eventType && a(t.eventType) || r.push(t);
                        if (0 !== r.length) {
                            s.Ay.debug(`sendBatch attempt to ${this.ingressName}`, {
                                batch: r,
                                endpointId: this.id
                            });
                            try {
                                let e = await fetch(this.ingressUrl, {
                                    body: JSON.stringify({
                                        batch: r
                                    }),
                                    keepalive: t,
                                    method: this.ingressMethod,
                                    mode: "cors"
                                });
                                if (!e.ok) throw {
                                    statusText: e.statusText,
                                    code: e.status
                                }
                            } catch (e) {
                                let o = !1;
                                this.onFailureHandler && (s.Ay.debug(`Endpoint ${this.ingressName} failed. Trying failover.`, {
                                    batch: r,
                                    endpointId: this.id
                                }), this.onFailureHandler(r, t), o = !0);
                                const n = {
                                    type: "EndpointError",
                                    subtype: "",
                                    id: this.id,
                                    name: this.ingressName,
                                    endpointType: this.ingressUrl.includes("judy") ? "judy" : "aws",
                                    msg: "",
                                    failedOver: o,
                                    trace: null
                                };
                                let i = 500;
                                e instanceof Error ? (n.msg = e.message, n.subtype = e.name, n.trace = e ? .stack ? ? null) : (n.msg = "object" == typeof e && null !== e && "statusText" in e ? e.statusText : "Unknown error.", n.subtype = "unknown", i = "object" == typeof e && null !== e && "code" in e ? e.code : i), s.Ay.warn(`Endpoint ${this.ingressName} failed.`, { ...n
                                })
                            }
                        }
                    }
                    batchAndSend(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        const r = [...e];
                        do {
                            const e = r.splice(0, this.batchSize);
                            e.length > 0 && this.sendBatch(e, t)
                        } while (r.length > 0)
                    }
                    onFailure(e) {
                        this.onFailureHandler = e
                    }
                    get batchSize() {
                        return this.props.batchSize
                    }
                    get id() {
                        return this.props.id
                    }
                    get ingressUrl() {
                        return this.props.ingressUrl
                    }
                    get ingressName() {
                        return this.props.ingressName
                    }
                    get ingressMethod() {
                        return this.props.ingressMethod
                    }
                }
            },
            7253(e, t, r) {
                "use strict";
                r.d(t, {
                    U8: () => a,
                    gR: () => i,
                    yQ: () => g
                });
                let s = [],
                    o = null,
                    n = !0;
                const i = e => {
                        n && o ? e(o) : s.push(e)
                    },
                    a = e => {
                        o = e
                    },
                    g = () => {
                        n = !0, o && (s.forEach(e => e(o)), s = [])
                    }
            },
            1169(e, t, r) {
                "use strict";
                r.d(t, {
                    vE: () => pe,
                    Id: () => be,
                    Tz: () => de
                });
                var s = r(9326),
                    o = r(3564),
                    n = r(7403),
                    i = r(5095),
                    a = r(7035),
                    g = r(2981),
                    u = r(6968),
                    d = r(6273),
                    l = r(9313);
                const c = "creativeHeight",
                    p = (0, l.ai)();
                var b = r(3907);
                const _ = "creativeWidth",
                    $ = (0, l.ai)();
                var h = r(8196),
                    m = r(923),
                    y = r(7127),
                    f = r(607),
                    j = r(876);
                const S = "originalCpm",
                    A = (0, l.ai)().transform((e, t) => {
                        let r = t;
                        return "string" == typeof r && (r = parseFloat(r)), r = Math.min(Math.max(r, 0), 200), r
                    }),
                    w = "revenue",
                    E = (0, l.ai)().transform((e, t) => {
                        let r = t;
                        return "string" == typeof r && (r = parseFloat(r)), r = Math.min(Math.max(r, 0), 200), r
                    });
                var v = r(2814),
                    T = r(322),
                    M = r(2187);
                const I = "outOfPage",
                    R = (0, l.zM)();
                var F = r(1038);
                const D = "slotId",
                    B = (0, l.Yj)(),
                    O = "slotSizes",
                    P = (0, l.RZ)(e => "string" == typeof e ? (0, l.Yj)() : (0, l.YO)().of((0, l.ai)()).nullable());
                var L = r(564);
                const x = (0, l.Ik)({
                        [M.Z]: M.w,
                        [I]: R.optional(),
                        [F.Z]: F.w,
                        [D]: B,
                        [O]: P,
                        [L.Z]: L.w
                    }),
                    C = x.shape({
                        [i.Z]: i.w,
                        [a.Z]: a.w.optional(),
                        [g.Z]: g.w,
                        [u.Z]: u.w.optional(),
                        [d.Z]: d.w,
                        [c]: p.required(),
                        [b.Z]: b.w.optional(),
                        [_]: $.required(),
                        [h.Z]: h.w.default("USD"),
                        [m.Z]: m.w.default("adClicked"),
                        [y.Z]: y.w.optional(),
                        [f.Z]: f.w,
                        [j.Z]: j.w.optional(),
                        [S]: A.optional(),
                        [w]: E.required(),
                        [v.Z]: v.w.optional(),
                        [T.Z]: T.w
                    }),
                    N = "bidResponseTimeMs",
                    U = (0, l.ai)(),
                    k = "bidTtl",
                    J = (0, l.ai)();
                var q = r(1665),
                    W = r(3506),
                    V = r(4172);
                const G = x.shape({
                        [i.Z]: i.w.optional(),
                        [g.Z]: g.w.required(),
                        [N]: U.nullable(),
                        [k]: J.nullable(),
                        [d.Z]: d.w.default(0),
                        [c]: p.nullable(),
                        [_]: $.nullable(),
                        [h.Z]: h.w.default("USD"),
                        [m.Z]: m.w.default("bidWon"),
                        [f.Z]: f.w.required(),
                        [q.Z]: q.w.nullable(),
                        [W.Z]: W.w.nullable(),
                        [V.Z]: V.w.nullable(),
                        [v.Z]: v.w.required(),
                        [T.Z]: T.w.required()
                    }),
                    z = x.shape({
                        [i.Z]: i.w.optional(),
                        [a.Z]: a.w.optional(),
                        [g.Z]: g.w.required(),
                        [u.Z]: u.w.optional(),
                        [d.Z]: d.w.required(),
                        [c]: p.required(),
                        [b.Z]: b.w.optional(),
                        [_]: $.required(),
                        [h.Z]: h.w.required().default("USD"),
                        [m.Z]: m.w.default("impression"),
                        [y.Z]: y.w.optional(),
                        [f.Z]: f.w.required(),
                        [j.Z]: j.w.optional(),
                        [S]: A.optional(),
                        [w]: E.required(),
                        [v.Z]: v.w.required(),
                        [T.Z]: T.w.required()
                    }),
                    H = (0, l.Ik)({
                        [i.Z]: i.w,
                        [a.Z]: a.w.optional(),
                        [g.Z]: g.w,
                        [d.Z]: d.w,
                        [h.Z]: h.w,
                        [m.Z]: m.w.default("impressionViewable"),
                        [f.Z]: f.w,
                        [j.Z]: j.w.optional(),
                        [S]: A.optional(),
                        [v.Z]: v.w.optional(),
                        [T.Z]: T.w
                    }).concat(x),
                    Y = (0, l.Ik)({
                        [m.Z]: m.w.default("newSession")
                    }),
                    Z = (0, l.Ik)({
                        [m.Z]: m.w.default("newUser")
                    }),
                    X = (0, l.Ik)({
                        [m.Z]: m.w.default("pageView")
                    });
                var K = r(7234);
                const Q = (0, l.Ik)({
                        [g.Z]: g.w.nullable(),
                        [K.Z]: K.w.nullable(),
                        [m.Z]: m.w.default("pageView"),
                        [j.Z]: j.w.required(),
                        [T.Z]: T.w.nullable()
                    }),
                    ee = "timeSinceLastRefreshMs",
                    te = (0, l.ai)().min(0),
                    re = x.shape({
                        [m.Z]: m.w.default("slotRequested"),
                        [ee]: te.optional()
                    }),
                    se = x.shape({
                        [h.Z]: h.w,
                        [m.Z]: m.w.default("unfilledImpression"),
                        [f.Z]: f.w,
                        [T.Z]: T.w
                    });
                var oe = r(383),
                    ne = r(6194),
                    ie = r(274);
                const ae = (0, l.Ik)({
                        [m.Z]: m.w.default("userFeedback"),
                        ctype: (0, l.Yj)().nullable(),
                        cid: (0, l.Yj)().nullable(),
                        subject: (0, l.Yj)().required(),
                        action: (0, l.Yj)().required(),
                        platform: (0, l.Yj)().oneOf(["web", "app", "custom"]).default("web"),
                        app: (0, l.Yj)().nullable().default(null),
                        feedbackAt: (0, l.ai)().required(),
                        feedbackData: (0, l.Ik)().default({}),
                        subjectData: (0, l.Ik)().default({}),
                        meta: (0, l.Ik)().default({})
                    }),
                    ge = ae.shape({
                        user: (0, l.Ik)({
                            browser: (0, l.Yj)().nullable(),
                            country: (0, l.Yj)().nullable(),
                            deviceType: (0, l.Yj)().nullable(),
                            os: (0, l.Yj)().nullable(),
                            sessionId: (0, l.Yj)().nullable(),
                            userId: (0, l.Yj)().nullable()
                        }).required(),
                        page: (0, l.Ik)({
                            custom: (0, l.Ik)().optional(),
                            hostname: (0, l.Yj)().default(""),
                            pageviewId: (0, l.Yj)().nullable(),
                            pathname: (0, l.Yj)().default(""),
                            url: (0, l.Yj)().nullable(),
                            ravenVersion: (0, l.Yj)().default("1.20.0-69wxiu"),
                            referrer: (0, l.Yj)().optional()
                        }).required(),
                        [oe.Z]: oe.w.required(),
                        [ne.Z]: ne.w.nullable()
                    }),
                    ue = e => (e => {
                        const {
                            browser: t,
                            custom: r,
                            deviceType: s,
                            geo: o,
                            hostname: i,
                            href: a,
                            os: g,
                            pathname: u,
                            publisher: d,
                            publisherId: l,
                            userId: c,
                            sessionId: p
                        } = (0, n.VK)(), {
                            country: b = null
                        } = o ? ? {}, {
                            pageviewId: _
                        } = (0, ie.Xd)();
                        "pageviewId" in e && delete e.pageviewId;
                        const {
                            feedbackData: $ = {},
                            meta: h = {},
                            subjectData: m = {}
                        } = e;
                        return { ...ge.cast({
                                ctype: "p",
                                cid: d ? ? l ? ? "",
                                ...e,
                                user: {
                                    browser: t,
                                    country: b,
                                    deviceType: s,
                                    os: g,
                                    userId: c,
                                    sessionId: p
                                },
                                page: {
                                    custom: r,
                                    hostname: i,
                                    pathname: u,
                                    pageviewId: _ ? ? "",
                                    url: a,
                                    referrer: document.referrer ? ? ""
                                },
                                publisher: d,
                                publisherId: l ? ? ""
                            }, {
                                stripUnknown: !0
                            }),
                            feedbackData: $,
                            meta: h,
                            subjectData: m
                        }
                    })(e),
                    de = {
                        adClicked: C,
                        bidWon: G,
                        impression: z,
                        impressionViewable: H,
                        newSession: Y,
                        newUser: Z,
                        pageView: X,
                        ravenError: Q,
                        slotRequested: re,
                        unfilledImpression: se,
                        userFeedback: ae
                    },
                    le = new Date,
                    ce = () => "true" === localStorage.getItem("ditu_tude_meta_sampled"),
                    pe = (e, t) => {
                        if ("userFeedback" === e) return ue(t);
                        const r = (0, s.U)(),
                            i = (0, n.VK)();
                        return { ...{ ...t,
                                ...i,
                                custom: r
                            },
                            tudeMeta: ce() ? JSON.stringify((0, o.M)()) : null
                        }
                    },
                    be = (e, t) => {
                        if ("userFeedback" === e) return t;
                        if ((new Date).getTime() - le.getTime() < 1e4) {
                            const e = (0, s.U)();
                            return { ...{ ...t,
                                    custom: e
                                },
                                tudeMeta: ce() ? JSON.stringify((0, o.M)()) : null
                            }
                        }
                        return t
                    }
            },
            5095(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "adId",
                    n = (0, s.Yj)()
            },
            9409(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "adServer",
                    n = (0, s.Yj)()
            },
            2187(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "adUnitPath",
                    n = (0, s.Yj)()
            },
            7035(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "advertiserId",
                    n = (0, s.ai)().nullable()
            },
            2981(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "bidder",
                    n = (0, s.Yj)()
            },
            6968(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "campaignId",
                    n = (0, s.ai)().nullable()
            },
            7234(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "code",
                    n = (0, s.ai)()
            },
            6273(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "cpm",
                    n = (0, s.ai)().transform((e, t) => {
                        let r = t;
                        return "string" == typeof r && (r = parseFloat(r)), r = Math.min(Math.max(r, 0), 200), r
                    })
            },
            3907(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "creativeId",
                    n = (0, s.ai)().nullable()
            },
            8196(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "currency",
                    n = (0, s.Yj)()
            },
            923(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "eventType",
                    n = (0, s.Yj)()
            },
            9711(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "identityProviders",
                    n = (0, s.Yj)()
            },
            7127(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "lineItemId",
                    n = (0, s.ai)().nullable()
            },
            607(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "mediaType",
                    n = (0, s.Yj)()
            },
            876(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "message",
                    n = (0, s.Yj)()
            },
            1665(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "pbCreativeId",
                    n = (0, s.Yj)()
            },
            3506(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "pbDealId",
                    n = (0, s.Yj)()
            },
            4172(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "pbTransactionId",
                    n = (0, s.Yj)()
            },
            4964(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "product",
                    n = (0, s.Yj)().default("cw")
            },
            383(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "publisher",
                    n = (0, s.Yj)()
            },
            6194(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "publisherId",
                    n = (0, s.Yj)()
            },
            2814(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "size",
                    n = (0, s.Yj)()
            },
            1038(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "slotElementId",
                    n = (0, s.Yj)()
            },
            322(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "source",
                    n = (0, s.Yj)()
            },
            564(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "targetingMap",
                    n = (0, s.Ik)()
            },
            1602(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "tudeMeta",
                    n = (0, s.Ik)().noUnknown(!1).nullable().default(null)
            },
            7725(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "tudePayload",
                    n = (0, s.Yj)()
            },
            4543(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "tudeTag",
                    n = (0, s.Yj)()
            },
            2200(e, t, r) {
                "use strict";
                r.d(t, {
                    Z: () => o,
                    w: () => n
                });
                var s = r(9313);
                const o = "wrapper",
                    n = (0, s.Yj)()
            },
            5810(e, t, r) {
                "use strict";
                r.d(t, {
                    l: () => tt,
                    Z: () => rt
                });
                var s = r(9313);
                const o = "browser",
                    n = (0, s.Yj)(),
                    i = "browserMajor",
                    a = (0, s.Yj)(),
                    g = "browserTzOffset",
                    u = (0, s.ai)(),
                    d = "browserVersion",
                    l = (0, s.Yj)(),
                    c = "cookieDeprecationLabel",
                    p = (0, s.Yj)(),
                    b = "cpuArch",
                    _ = (0, s.Yj)(),
                    $ = "deviceModel",
                    h = (0, s.Yj)(),
                    m = "deviceType",
                    y = (0, s.Yj)(),
                    f = "deviceVendor",
                    j = (0, s.Yj)(),
                    S = "doNotTrack",
                    A = (0, s.zM)().default(!1),
                    w = "geo",
                    E = (0, s.Ik)({
                        address: (0, s.Yj)().nullable().default(null),
                        asn: (0, s.Yj)().nullable().default(null),
                        city: (0, s.Yj)().nullable().default(null),
                        country: (0, s.Yj)().nullable().default(null),
                        "country-region": (0, s.Yj)().nullable().default(null),
                        "postal-code": (0, s.Yj)().nullable().default(null),
                        "time-zone": (0, s.Yj)().nullable().default(null)
                    }),
                    v = "os",
                    T = (0, s.Yj)(),
                    M = "osVersion",
                    I = (0, s.Yj)(),
                    R = "screenResolution",
                    F = (0, s.Yj)(),
                    D = "thirdPartyCookies",
                    B = (0, s.zM)(),
                    O = "userAgent",
                    P = (0, s.Yj)(),
                    L = "userId",
                    x = (0, s.Yj)(),
                    C = "rcik",
                    N = (0, s.Yj)(),
                    U = "rciv",
                    k = (0, s.Yj)(),
                    J = "sessionId",
                    q = (0, s.Yj)(),
                    W = "sessionIdInt",
                    V = (0, s.Yj)().matches(/^\d+$/, "must be a decimal integer string"),
                    G = "hash",
                    z = (0, s.Yj)().default(window.location.hash),
                    H = "host",
                    Y = (0, s.Yj)().default(window.location.host),
                    Z = "hostname",
                    X = (0, s.Yj)().default(window.location.hostname),
                    K = "href",
                    Q = (0, s.Yj)().default(window.location.href),
                    ee = "origin",
                    te = (0, s.Yj)().default(window.location.origin),
                    re = "pageviewId",
                    se = (0, s.Yj)().nullable(),
                    oe = "pageviewIdInt",
                    ne = (0, s.Yj)().matches(/^\d+$/, "must be a decimal integer string"),
                    ie = "pathname",
                    ae = (0, s.Yj)().default(window.location.pathname),
                    ge = "port",
                    ue = (0, s.Yj)().default(window.location.port),
                    de = "protocol",
                    le = (0, s.Yj)().default(window.location.protocol),
                    ce = "sampleRate",
                    pe = (0, s.ai)(),
                    be = "search",
                    _e = (0, s.Yj)().default(window.location.search),
                    $e = "searchParams",
                    he = (0, s.Ik)({}),
                    me = "utmCampaign",
                    ye = (0, s.Yj)(),
                    fe = "utmContent",
                    je = (0, s.Yj)(),
                    Se = "utmMedium",
                    Ae = (0, s.Yj)(),
                    we = "utmSource",
                    Ee = (0, s.Yj)(),
                    ve = "utmTerm",
                    Te = (0, s.Yj)();
                var Me = r(9409);
                const Ie = "browserDateBatched",
                    Re = (0, s.ai)().default(Date.now);
                var Fe = r(7234);
                const De = "custom",
                    Be = (0, s.Ik)({
                        abtest1: (0, s.Yj)().optional(),
                        abtest2: (0, s.Yj)().optional(),
                        abtest3: (0, s.Yj)().optional(),
                        abtest4: (0, s.Yj)().optional(),
                        abtest5: (0, s.Yj)().optional(),
                        param1: (0, s.Yj)().optional(),
                        param2: (0, s.Yj)().optional(),
                        param3: (0, s.Yj)().optional(),
                        param4: (0, s.Yj)().optional(),
                        param5: (0, s.Yj)().optional(),
                        param6: (0, s.Yj)().optional(),
                        param7: (0, s.Yj)().optional(),
                        param8: (0, s.Yj)().optional(),
                        param9: (0, s.Yj)().optional(),
                        param10: (0, s.Yj)().optional(),
                        param11: (0, s.Yj)().optional(),
                        param12: (0, s.Yj)().optional(),
                        param13: (0, s.Yj)().optional(),
                        param14: (0, s.Yj)().optional(),
                        param15: (0, s.Yj)().optional()
                    }).default({}),
                    Oe = "dataSource",
                    Pe = (0, s.Yj)().default("unknown");
                var Le = r(9711),
                    xe = r(4964),
                    Ce = r(383),
                    Ne = r(6194),
                    Ue = r(9612);
                const ke = "ravenId",
                    Je = (0, s.Yj)().default((0, Ue.A)());
                var qe = r(1602),
                    We = r(7725),
                    Ve = r(4543);
                const Ge = "version",
                    ze = (0, s.Yj)();
                var He = r(2200);
                const Ye = "wrapperId",
                    Ze = (0, s.Yj)(),
                    Xe = (0, s.Ik)({
                        [o]: n,
                        [i]: a,
                        [g]: u,
                        [d]: l,
                        [c]: p.nullable().default(null),
                        [b]: _.nullable(),
                        [$]: h.nullable(),
                        [m]: y,
                        [f]: j.nullable(),
                        [S]: A.default(!1),
                        [w]: E,
                        [v]: T,
                        [M]: I.nullable(),
                        [R]: F.nullable(),
                        [D]: B.default(!0),
                        [O]: P,
                        [L]: x
                    }),
                    Ke = (0, s.Ik)({
                        [C]: N.nullable(),
                        [U]: k.nullable(),
                        [J]: q,
                        [W]: V
                    }),
                    Qe = (0, s.Ik)({
                        [G]: z.nullable(),
                        [H]: Y,
                        [Z]: X,
                        [K]: Q,
                        [ee]: te.nullable(),
                        [re]: se,
                        [oe]: ne,
                        [ie]: ae,
                        [ge]: ue.nullable(),
                        [de]: le,
                        [ce]: pe.default(1),
                        [be]: _e.nullable(),
                        [$e]: he,
                        [me]: ye.nullable().default(""),
                        [fe]: je.nullable().default(""),
                        [Se]: Ae.nullable().default(""),
                        [we]: Ee.nullable().default(""),
                        [ve]: Te.nullable().default("")
                    }),
                    et = (0, s.Ik)({
                        [Me.Z]: Me.w.default("googletag"),
                        [Ie]: Re,
                        [Fe.Z]: Fe.w.nullable(),
                        [De]: Be.optional(),
                        [Oe]: Pe.nullable().default(null),
                        [Le.Z]: Le.w.nullable().default(null),
                        [xe.Z]: xe.w.default("cw"),
                        [Ce.Z]: Ce.w.required(),
                        [Ne.Z]: Ne.w.nullable(),
                        [ke]: Je.required(),
                        [qe.Z]: qe.w.nullable().default(null),
                        [We.Z]: We.w.nullable().default(null),
                        [Ve.Z]: Ve.w.nullable().default(null),
                        [Ge]: ze.nullable().default(null),
                        [He.Z]: He.w.nullable().default(null),
                        [Ye]: Ze.nullable().default(null)
                    }),
                    tt = (0, s.Ik)({}).concat(Xe).concat(Ke).concat(Qe).concat(et),
                    rt = (0, s.Ik)({
                        [Me.Z]: Me.w.default("googletag"),
                        [Ve.Z]: Ve.w.nullable().default(null),
                        [He.Z]: He.w.optional(),
                        [Ye]: Ze.optional()
                    })
            },
            7186(__unused_webpack_module, exports) {
                var COMPILED = !0,
                    goog = goog || {};
                if (goog.global = this || self, goog.exportPath_ = function(e, t, r, s) {
                        e = e.split("."), s = s || goog.global, e[0] in s || void 0 === s.execScript || s.execScript("var " + e[0]);
                        for (var o; e.length && (o = e.shift());)
                            if (e.length || void 0 === t) s = s[o] && s[o] !== Object.prototype[o] ? s[o] : s[o] = {};
                            else if (!r && goog.isObject(t) && goog.isObject(s[o]))
                            for (var n in t) t.hasOwnProperty(n) && (s[o][n] = t[n]);
                        else s[o] = t
                    }, goog.define = function(e, t) {
                        if (!COMPILED) {
                            var r = goog.global.CLOSURE_UNCOMPILED_DEFINES,
                                s = goog.global.CLOSURE_DEFINES;
                            r && void 0 === r.nodeType && Object.prototype.hasOwnProperty.call(r, e) ? t = r[e] : s && void 0 === s.nodeType && Object.prototype.hasOwnProperty.call(s, e) && (t = s[e])
                        }
                        return t
                    }, goog.FEATURESET_YEAR = 2012, goog.DEBUG = !0, goog.LOCALE = "en", goog.TRUSTED_SITE = !0, goog.DISALLOW_TEST_ONLY_CODE = COMPILED && !goog.DEBUG, goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING = !1, goog.provide = function(e) {
                        if (goog.isInModuleLoader_()) throw Error("goog.provide cannot be used within a module.");
                        if (!COMPILED && goog.isProvided_(e)) throw Error('Namespace "' + e + '" already declared.');
                        goog.constructNamespace_(e)
                    }, goog.constructNamespace_ = function(e, t, r) {
                        if (!COMPILED) {
                            delete goog.implicitNamespaces_[e];
                            for (var s = e;
                                (s = s.substring(0, s.lastIndexOf("."))) && !goog.getObjectByName(s);) goog.implicitNamespaces_[s] = !0
                        }
                        goog.exportPath_(e, t, r)
                    }, goog.NONCE_PATTERN_ = /^[\w+/_-]+[=]{0,2}$/, goog.getScriptNonce_ = function(e) {
                        return (e = (e = (e || goog.global).document).querySelector && e.querySelector("script[nonce]")) && (e = e.nonce || e.getAttribute("nonce")) && goog.NONCE_PATTERN_.test(e) ? e : ""
                    }, goog.VALID_MODULE_RE_ = /^[a-zA-Z_$][a-zA-Z0-9._$]*$/, goog.module = function(e) {
                        if ("string" != typeof e || !e || -1 == e.search(goog.VALID_MODULE_RE_)) throw Error("Invalid module identifier");
                        if (!goog.isInGoogModuleLoader_()) throw Error("Module " + e + " has been loaded incorrectly. Note, modules cannot be loaded as normal scripts. They require some kind of pre-processing step. You're likely trying to load a module via a script tag or as a part of a concatenated bundle without rewriting the module. For more info see: https://github.com/google/closure-library/wiki/goog.module:-an-ES6-module-like-alternative-to-goog.provide.");
                        if (goog.moduleLoaderState_.moduleName) throw Error("goog.module may only be called once per module.");
                        if (goog.moduleLoaderState_.moduleName = e, !COMPILED) {
                            if (goog.isProvided_(e)) throw Error('Namespace "' + e + '" already declared.');
                            delete goog.implicitNamespaces_[e]
                        }
                    }, goog.module.get = function(e) {
                        return goog.module.getInternal_(e)
                    }, goog.module.getInternal_ = function(e) {
                        if (!COMPILED) {
                            if (e in goog.loadedModules_) return goog.loadedModules_[e].exports;
                            if (!goog.implicitNamespaces_[e]) return null != (e = goog.getObjectByName(e)) ? e : null
                        }
                        return null
                    }, goog.ModuleType = {
                        ES6: "es6",
                        GOOG: "goog"
                    }, goog.moduleLoaderState_ = null, goog.isInModuleLoader_ = function() {
                        return goog.isInGoogModuleLoader_() || goog.isInEs6ModuleLoader_()
                    }, goog.isInGoogModuleLoader_ = function() {
                        return !!goog.moduleLoaderState_ && goog.moduleLoaderState_.type == goog.ModuleType.GOOG
                    }, goog.isInEs6ModuleLoader_ = function() {
                        if (goog.moduleLoaderState_ && goog.moduleLoaderState_.type == goog.ModuleType.ES6) return !0;
                        var e = goog.global.$jscomp;
                        return !!e && ("function" == typeof e.getCurrentModulePath && !!e.getCurrentModulePath())
                    }, goog.module.declareLegacyNamespace = function() {
                        if (!COMPILED && !goog.isInGoogModuleLoader_()) throw Error("goog.module.declareLegacyNamespace must be called from within a goog.module");
                        if (!COMPILED && !goog.moduleLoaderState_.moduleName) throw Error("goog.module must be called prior to goog.module.declareLegacyNamespace.");
                        goog.moduleLoaderState_.declareLegacyNamespace = !0
                    }, goog.declareModuleId = function(e) {
                        if (!COMPILED) {
                            if (!goog.isInEs6ModuleLoader_()) throw Error("goog.declareModuleId may only be called from within an ES6 module");
                            if (goog.moduleLoaderState_ && goog.moduleLoaderState_.moduleName) throw Error("goog.declareModuleId may only be called once per module.");
                            if (e in goog.loadedModules_) throw Error('Module with namespace "' + e + '" already exists.')
                        }
                        if (goog.moduleLoaderState_) goog.moduleLoaderState_.moduleName = e;
                        else {
                            var t = goog.global.$jscomp;
                            if (!t || "function" != typeof t.getCurrentModulePath) throw Error('Module with namespace "' + e + '" has been loaded incorrectly.');
                            t = t.require(t.getCurrentModulePath()), goog.loadedModules_[e] = {
                                exports: t,
                                type: goog.ModuleType.ES6,
                                moduleId: e
                            }
                        }
                    }, goog.setTestOnly = function(e) {
                        if (goog.DISALLOW_TEST_ONLY_CODE) throw e = e || "", Error("Importing test-only code into non-debug environment" + (e ? ": " + e : "."))
                    }, goog.forwardDeclare = function(e) {}, COMPILED || (goog.isProvided_ = function(e) {
                        return e in goog.loadedModules_ || !goog.implicitNamespaces_[e] && null != goog.getObjectByName(e)
                    }, goog.implicitNamespaces_ = {
                        "goog.module": !0
                    }), goog.getObjectByName = function(e, t) {
                        e = e.split("."), t = t || goog.global;
                        for (var r = 0; r < e.length; r++)
                            if (null == (t = t[e[r]])) return null;
                        return t
                    }, goog.addDependency = function(e, t, r, s) {
                        !COMPILED && goog.DEPENDENCIES_ENABLED && goog.debugLoader_.addDependency(e, t, r, s)
                    }, goog.ENABLE_DEBUG_LOADER = !1, goog.logToConsole_ = function(e) {
                        goog.global.console && goog.global.console.error(e)
                    }, goog.require = function(e) {
                        if (!COMPILED) {
                            if (goog.ENABLE_DEBUG_LOADER && goog.debugLoader_.requested(e), goog.isProvided_(e)) {
                                if (goog.isInModuleLoader_()) return goog.module.getInternal_(e)
                            } else if (goog.ENABLE_DEBUG_LOADER) {
                                var t = goog.moduleLoaderState_;
                                goog.moduleLoaderState_ = null;
                                try {
                                    goog.debugLoader_.load_(e)
                                } finally {
                                    goog.moduleLoaderState_ = t
                                }
                            }
                            return null
                        }
                    }, goog.requireType = function(e) {
                        return {}
                    }, goog.basePath = "", goog.abstractMethod = function() {
                        throw Error("unimplemented abstract method")
                    }, goog.addSingletonGetter = function(e) {
                        e.instance_ = void 0, e.getInstance = function() {
                            return e.instance_ ? e.instance_ : (goog.DEBUG && (goog.instantiatedSingletons_[goog.instantiatedSingletons_.length] = e), e.instance_ = new e)
                        }
                    }, goog.instantiatedSingletons_ = [], goog.LOAD_MODULE_USING_EVAL = !0, goog.SEAL_MODULE_EXPORTS = goog.DEBUG, goog.loadedModules_ = {}, goog.DEPENDENCIES_ENABLED = !COMPILED && goog.ENABLE_DEBUG_LOADER, goog.TRANSPILE = "detect", goog.ASSUME_ES_MODULES_TRANSPILED = !1, goog.TRUSTED_TYPES_POLICY_NAME = "goog", goog.hasBadLetScoping = null, goog.loadModule = function(e) {
                        var t = goog.moduleLoaderState_;
                        try {
                            goog.moduleLoaderState_ = {
                                moduleName: "",
                                declareLegacyNamespace: !1,
                                type: goog.ModuleType.GOOG
                            };
                            var r = {},
                                s = r;
                            if ("function" == typeof e) s = e.call(void 0, s);
                            else {
                                if ("string" != typeof e) throw Error("Invalid module definition");
                                s = goog.loadModuleFromSource_.call(void 0, s, e)
                            }
                            var o = goog.moduleLoaderState_.moduleName;
                            if ("string" != typeof o || !o) throw Error('Invalid module name "' + o + '"');
                            goog.moduleLoaderState_.declareLegacyNamespace ? goog.constructNamespace_(o, s, r !== s) : goog.SEAL_MODULE_EXPORTS && Object.seal && "object" == typeof s && null != s && Object.seal(s), goog.loadedModules_[o] = {
                                exports: s,
                                type: goog.ModuleType.GOOG,
                                moduleId: goog.moduleLoaderState_.moduleName
                            }
                        } finally {
                            goog.moduleLoaderState_ = t
                        }
                    }, goog.loadModuleFromSource_ = function(a, b) {
                        return eval(goog.CLOSURE_EVAL_PREFILTER_.createScript(b)), a
                    }, goog.normalizePath_ = function(e) {
                        e = e.split("/");
                        for (var t = 0; t < e.length;) "." == e[t] ? e.splice(t, 1) : t && ".." == e[t] && e[t - 1] && ".." != e[t - 1] ? e.splice(--t, 2) : t++;
                        return e.join("/")
                    }, goog.loadFileSync_ = function(e) {
                        if (goog.global.CLOSURE_LOAD_FILE_SYNC) return goog.global.CLOSURE_LOAD_FILE_SYNC(e);
                        try {
                            var t = new goog.global.XMLHttpRequest;
                            return t.open("get", e, !1), t.send(), 0 == t.status || 200 == t.status ? t.responseText : null
                        } catch (e) {
                            return null
                        }
                    }, goog.typeOf = function(e) {
                        var t = typeof e;
                        return "object" != t ? t : e ? Array.isArray(e) ? "array" : t : "null"
                    }, goog.isArrayLike = function(e) {
                        var t = goog.typeOf(e);
                        return "array" == t || "object" == t && "number" == typeof e.length
                    }, goog.isDateLike = function(e) {
                        return goog.isObject(e) && "function" == typeof e.getFullYear
                    }, goog.isObject = function(e) {
                        var t = typeof e;
                        return "object" == t && null != e || "function" == t
                    }, goog.getUid = function(e) {
                        return Object.prototype.hasOwnProperty.call(e, goog.UID_PROPERTY_) && e[goog.UID_PROPERTY_] || (e[goog.UID_PROPERTY_] = ++goog.uidCounter_)
                    }, goog.hasUid = function(e) {
                        return !!e[goog.UID_PROPERTY_]
                    }, goog.removeUid = function(e) {
                        null !== e && "removeAttribute" in e && e.removeAttribute(goog.UID_PROPERTY_);
                        try {
                            delete e[goog.UID_PROPERTY_]
                        } catch (e) {}
                    }, goog.UID_PROPERTY_ = "closure_uid_" + (1e9 * Math.random() >>> 0), goog.uidCounter_ = 0, goog.cloneObject = function(e) {
                        var t = goog.typeOf(e);
                        if ("object" == t || "array" == t) {
                            if ("function" == typeof e.clone) return e.clone();
                            if ("undefined" != typeof Map && e instanceof Map) return new Map(e);
                            if ("undefined" != typeof Set && e instanceof Set) return new Set(e);
                            for (var r in t = "array" == t ? [] : {}, e) t[r] = goog.cloneObject(e[r]);
                            return t
                        }
                        return e
                    }, goog.bindNative_ = function(e, t, r) {
                        return e.call.apply(e.bind, arguments)
                    }, goog.bindJs_ = function(e, t, r) {
                        if (!e) throw Error();
                        if (2 < arguments.length) {
                            var s = Array.prototype.slice.call(arguments, 2);
                            return function() {
                                var r = Array.prototype.slice.call(arguments);
                                return Array.prototype.unshift.apply(r, s), e.apply(t, r)
                            }
                        }
                        return function() {
                            return e.apply(t, arguments)
                        }
                    }, goog.bind = function(e, t, r) {
                        return Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? goog.bind = goog.bindNative_ : goog.bind = goog.bindJs_, goog.bind.apply(null, arguments)
                    }, goog.partial = function(e, t) {
                        var r = Array.prototype.slice.call(arguments, 1);
                        return function() {
                            var t = r.slice();
                            return t.push.apply(t, arguments), e.apply(this, t)
                        }
                    }, goog.now = function() {
                        return Date.now()
                    }, goog.globalEval = function(e) {
                        (0, eval)(e)
                    }, goog.getCssName = function(e, t) {
                        if ("." == String(e).charAt(0)) throw Error('className passed in goog.getCssName must not start with ".". You passed: ' + e);
                        var r = function(e) {
                                return goog.cssNameMapping_[e] || e
                            },
                            s = function(e) {
                                e = e.split("-");
                                for (var t = [], s = 0; s < e.length; s++) t.push(r(e[s]));
                                return t.join("-")
                            };
                        return s = goog.cssNameMapping_ ? "BY_WHOLE" == goog.cssNameMappingStyle_ ? r : s : function(e) {
                            return e
                        }, e = t ? e + "-" + s(t) : s(e), goog.global.CLOSURE_CSS_NAME_MAP_FN ? goog.global.CLOSURE_CSS_NAME_MAP_FN(e) : e
                    }, goog.setCssNameMapping = function(e, t) {
                        goog.cssNameMapping_ = e, goog.cssNameMappingStyle_ = t
                    }, !COMPILED && goog.global.CLOSURE_CSS_NAME_MAPPING && (goog.cssNameMapping_ = goog.global.CLOSURE_CSS_NAME_MAPPING), goog.GetMsgOptions = function() {}, goog.getMsg = function(e, t, r) {
                        return r && r.html && (e = e.replace(/</g, "&lt;")), r && r.unescapeHtmlEntities && (e = e.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&")), t && (e = e.replace(/\{\$([^}]+)}/g, function(e, r) {
                            return null != t && r in t ? t[r] : e
                        })), e
                    }, goog.getMsgWithFallback = function(e, t) {
                        return e
                    }, goog.exportSymbol = function(e, t, r) {
                        goog.exportPath_(e, t, !0, r)
                    }, goog.exportProperty = function(e, t, r) {
                        e[t] = r
                    }, goog.inherits = function(e, t) {
                        function r() {}
                        r.prototype = t.prototype, e.superClass_ = t.prototype, e.prototype = new r, e.prototype.constructor = e, e.base = function(e, r, s) {
                            for (var o = Array(arguments.length - 2), n = 2; n < arguments.length; n++) o[n - 2] = arguments[n];
                            return t.prototype[r].apply(e, o)
                        }
                    }, goog.scope = function(e) {
                        if (goog.isInModuleLoader_()) throw Error("goog.scope is not supported within a module.");
                        e.call(goog.global)
                    }, COMPILED || (goog.global.COMPILED = COMPILED), goog.defineClass = function(e, t) {
                        var r = t.constructor,
                            s = t.statics;
                        return r && r != Object.prototype.constructor || (r = function() {
                            throw Error("cannot instantiate an interface (no constructor defined).")
                        }), r = goog.defineClass.createSealingConstructor_(r, e), e && goog.inherits(r, e), delete t.constructor, delete t.statics, goog.defineClass.applyProperties_(r.prototype, t), null != s && (s instanceof Function ? s(r) : goog.defineClass.applyProperties_(r, s)), r
                    }, goog.defineClass.SEAL_CLASS_INSTANCES = goog.DEBUG, goog.defineClass.createSealingConstructor_ = function(e, t) {
                        return goog.defineClass.SEAL_CLASS_INSTANCES ? function() {
                            var t = e.apply(this, arguments) || this;
                            return t[goog.UID_PROPERTY_] = t[goog.UID_PROPERTY_], t
                        } : e
                    }, goog.defineClass.OBJECT_PROTOTYPE_FIELDS_ = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" "), goog.defineClass.applyProperties_ = function(e, t) {
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                        for (var s = 0; s < goog.defineClass.OBJECT_PROTOTYPE_FIELDS_.length; s++) r = goog.defineClass.OBJECT_PROTOTYPE_FIELDS_[s], Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }, goog.identity_ = function(e) {
                        return e
                    }, goog.createTrustedTypesPolicy = function(e) {
                        var t = null,
                            r = goog.global.trustedTypes;
                        if (!r || !r.createPolicy) return t;
                        try {
                            t = r.createPolicy(e, {
                                createHTML: goog.identity_,
                                createScript: goog.identity_,
                                createScriptURL: goog.identity_
                            })
                        } catch (e) {
                            goog.logToConsole_(e.message)
                        }
                        return t
                    }, !COMPILED && goog.DEPENDENCIES_ENABLED && (goog.isEdge_ = function() {
                        return !!(goog.global.navigator && goog.global.navigator.userAgent ? goog.global.navigator.userAgent : "").match(/Edge\/(\d+)(\.\d)*/i)
                    }, goog.inHtmlDocument_ = function() {
                        var e = goog.global.document;
                        return null != e && "write" in e
                    }, goog.isDocumentLoading_ = function() {
                        var e = goog.global.document;
                        return e.attachEvent ? "complete" != e.readyState : "loading" == e.readyState
                    }, goog.findBasePath_ = function() {
                        if (null != goog.global.CLOSURE_BASE_PATH && "string" == typeof goog.global.CLOSURE_BASE_PATH) goog.basePath = goog.global.CLOSURE_BASE_PATH;
                        else if (goog.inHtmlDocument_()) {
                            var e = goog.global.document,
                                t = e.currentScript;
                            for (t = (e = t ? [t] : e.getElementsByTagName("SCRIPT")).length - 1; 0 <= t; --t) {
                                var r = e[t].src,
                                    s = r.lastIndexOf("?");
                                if (s = -1 == s ? r.length : s, "base.js" == r.slice(s - 7, s)) {
                                    goog.basePath = r.slice(0, s - 7);
                                    break
                                }
                            }
                        }
                    }, goog.findBasePath_(), goog.protectScriptTag_ = function(e) {
                        return e.replace(/<\/(SCRIPT)/gi, "\\x3c/$1")
                    }, goog.DebugLoader_ = function() {
                        this.dependencies_ = {}, this.idToPath_ = {}, this.written_ = {}, this.loadingDeps_ = [], this.depsToLoad_ = [], this.paused_ = !1, this.factory_ = new goog.DependencyFactory, this.deferredCallbacks_ = {}, this.deferredQueue_ = []
                    }, goog.DebugLoader_.prototype.bootstrap = function(e, t) {
                        function r() {
                            s && (goog.global.setTimeout(s, 0), s = null)
                        }
                        var s = t;
                        if (e.length) {
                            t = [];
                            for (var o = 0; o < e.length; o++) {
                                var n = this.getPathFromDeps_(e[o]);
                                if (!n) throw Error("Unregonized namespace: " + e[o]);
                                t.push(this.dependencies_[n])
                            }
                            n = goog.require;
                            var i = 0;
                            for (o = 0; o < e.length; o++) n(e[o]), t[o].onLoad(function() {
                                ++i == e.length && r()
                            })
                        } else r()
                    }, goog.DebugLoader_.prototype.loadClosureDeps = function() {
                        this.depsToLoad_.push(this.factory_.createDependency(goog.normalizePath_(goog.basePath + "deps.js"), "deps.js", [], [], {})), this.loadDeps_()
                    }, goog.DebugLoader_.prototype.requested = function(e, t) {
                        (e = this.getPathFromDeps_(e)) && (t || this.areDepsLoaded_(this.dependencies_[e].requires)) && (t = this.deferredCallbacks_[e]) && (delete this.deferredCallbacks_[e], t())
                    }, goog.DebugLoader_.prototype.setDependencyFactory = function(e) {
                        this.factory_ = e
                    }, goog.DebugLoader_.prototype.load_ = function(e) {
                        if (this.getPathFromDeps_(e)) {
                            var t = this,
                                r = [],
                                s = function(e) {
                                    var o = t.getPathFromDeps_(e);
                                    if (!o) throw Error("Bad dependency path or symbol: " + e);
                                    if (!t.written_[o]) {
                                        for (t.written_[o] = !0, e = t.dependencies_[o], o = 0; o < e.requires.length; o++) goog.isProvided_(e.requires[o]) || s(e.requires[o]);
                                        r.push(e)
                                    }
                                };
                            s(e), e = !!this.depsToLoad_.length, this.depsToLoad_ = this.depsToLoad_.concat(r), this.paused_ || e || this.loadDeps_()
                        } else goog.logToConsole_("goog.require could not find: " + e)
                    }, goog.DebugLoader_.prototype.loadDeps_ = function() {
                        for (var e = this, t = this.paused_; this.depsToLoad_.length && !t;)(function() {
                            var r = !1,
                                s = e.depsToLoad_.shift(),
                                o = !1;
                            e.loading_(s);
                            var n = {
                                pause: function() {
                                    if (r) throw Error("Cannot call pause after the call to load.");
                                    t = !0
                                },
                                resume: function() {
                                    r ? e.resume_() : t = !1
                                },
                                loaded: function() {
                                    if (o) throw Error("Double call to loaded.");
                                    o = !0, e.loaded_(s)
                                },
                                pending: function() {
                                    for (var t = [], r = 0; r < e.loadingDeps_.length; r++) t.push(e.loadingDeps_[r]);
                                    return t
                                },
                                setModuleState: function(e) {
                                    goog.moduleLoaderState_ = {
                                        type: e,
                                        moduleName: "",
                                        declareLegacyNamespace: !1
                                    }
                                },
                                registerEs6ModuleExports: function(e, t, r) {
                                    r && (goog.loadedModules_[r] = {
                                        exports: t,
                                        type: goog.ModuleType.ES6,
                                        moduleId: r || ""
                                    })
                                },
                                registerGoogModuleExports: function(e, t) {
                                    goog.loadedModules_[e] = {
                                        exports: t,
                                        type: goog.ModuleType.GOOG,
                                        moduleId: e
                                    }
                                },
                                clearModuleState: function() {
                                    goog.moduleLoaderState_ = null
                                },
                                defer: function(t) {
                                    if (r) throw Error("Cannot register with defer after the call to load.");
                                    e.defer_(s, t)
                                },
                                areDepsLoaded: function() {
                                    return e.areDepsLoaded_(s.requires)
                                }
                            };
                            try {
                                s.load(n)
                            } finally {
                                r = !0
                            }
                        })();
                        t && this.pause_()
                    }, goog.DebugLoader_.prototype.pause_ = function() {
                        this.paused_ = !0
                    }, goog.DebugLoader_.prototype.resume_ = function() {
                        this.paused_ && (this.paused_ = !1, this.loadDeps_())
                    }, goog.DebugLoader_.prototype.loading_ = function(e) {
                        this.loadingDeps_.push(e)
                    }, goog.DebugLoader_.prototype.loaded_ = function(e) {
                        for (var t = 0; t < this.loadingDeps_.length; t++)
                            if (this.loadingDeps_[t] == e) {
                                this.loadingDeps_.splice(t, 1);
                                break
                            }
                        for (t = 0; t < this.deferredQueue_.length; t++)
                            if (this.deferredQueue_[t] == e.path) {
                                this.deferredQueue_.splice(t, 1);
                                break
                            }
                        if (this.loadingDeps_.length == this.deferredQueue_.length && !this.depsToLoad_.length)
                            for (; this.deferredQueue_.length;) this.requested(this.deferredQueue_.shift(), !0);
                        e.loaded()
                    }, goog.DebugLoader_.prototype.areDepsLoaded_ = function(e) {
                        for (var t = 0; t < e.length; t++) {
                            var r = this.getPathFromDeps_(e[t]);
                            if (!r || !(r in this.deferredCallbacks_) && !goog.isProvided_(e[t])) return !1
                        }
                        return !0
                    }, goog.DebugLoader_.prototype.getPathFromDeps_ = function(e) {
                        return e in this.idToPath_ ? this.idToPath_[e] : e in this.dependencies_ ? e : null
                    }, goog.DebugLoader_.prototype.defer_ = function(e, t) {
                        this.deferredCallbacks_[e.path] = t, this.deferredQueue_.push(e.path)
                    }, goog.LoadController = function() {}, goog.LoadController.prototype.pause = function() {}, goog.LoadController.prototype.resume = function() {}, goog.LoadController.prototype.loaded = function() {}, goog.LoadController.prototype.pending = function() {}, goog.LoadController.prototype.registerEs6ModuleExports = function(e, t, r) {}, goog.LoadController.prototype.setModuleState = function(e) {}, goog.LoadController.prototype.clearModuleState = function() {}, goog.LoadController.prototype.defer = function(e) {}, goog.LoadController.prototype.areDepsLoaded = function() {}, goog.Dependency = function(e, t, r, s, o) {
                        this.path = e, this.relativePath = t, this.provides = r, this.requires = s, this.loadFlags = o, this.loaded_ = !1, this.loadCallbacks_ = []
                    }, goog.Dependency.prototype.getPathName = function() {
                        var e = this.path,
                            t = e.indexOf("://");
                        return 0 <= t && (0 <= (t = (e = e.substring(t + 3)).indexOf("/")) && (e = e.substring(t + 1))), e
                    }, goog.Dependency.prototype.onLoad = function(e) {
                        this.loaded_ ? e() : this.loadCallbacks_.push(e)
                    }, goog.Dependency.prototype.loaded = function() {
                        this.loaded_ = !0;
                        var e = this.loadCallbacks_;
                        this.loadCallbacks_ = [];
                        for (var t = 0; t < e.length; t++) e[t]()
                    }, goog.Dependency.defer_ = !1, goog.Dependency.callbackMap_ = {}, goog.Dependency.registerCallback_ = function(e) {
                        var t = Math.random().toString(32);
                        return goog.Dependency.callbackMap_[t] = e, t
                    }, goog.Dependency.unregisterCallback_ = function(e) {
                        delete goog.Dependency.callbackMap_[e]
                    }, goog.Dependency.callback_ = function(e, t) {
                        if (!(e in goog.Dependency.callbackMap_)) throw Error("Callback key " + e + " does not exist (was base.js loaded more than once?).");
                        for (var r = goog.Dependency.callbackMap_[e], s = [], o = 1; o < arguments.length; o++) s.push(arguments[o]);
                        r.apply(void 0, s)
                    }, goog.Dependency.prototype.load = function(e) {
                        if (goog.global.CLOSURE_IMPORT_SCRIPT) goog.global.CLOSURE_IMPORT_SCRIPT(this.path) ? e.loaded() : e.pause();
                        else if (goog.inHtmlDocument_()) {
                            var t = goog.global.document;
                            if ("complete" == t.readyState && !goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING) {
                                if (/\bdeps.js$/.test(this.path)) return void e.loaded();
                                throw Error('Cannot write "' + this.path + '" after document load')
                            }
                            var r = goog.getScriptNonce_();
                            if (!goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING && goog.isDocumentLoading_()) {
                                var s = function(t) {
                                        t.readyState && "complete" != t.readyState ? t.onload = s : (goog.Dependency.unregisterCallback_(o), e.loaded())
                                    },
                                    o = goog.Dependency.registerCallback_(s);
                                r = r ? ' nonce="' + r + '"' : "";
                                var n = '<script src="' + this.path + '"' + r + (goog.Dependency.defer_ ? " defer" : "") + ' id="script-' + o + '"><\/script>';
                                n += "<script" + r + ">", n = goog.Dependency.defer_ ? n + "document.getElementById('script-" + o + "').onload = function() {\n  goog.Dependency.callback_('" + o + "', this);\n};\n" : n + "goog.Dependency.callback_('" + o + "', document.getElementById('script-" + o + "'));", n += "<\/script>", t.write(goog.TRUSTED_TYPES_POLICY_ ? goog.TRUSTED_TYPES_POLICY_.createHTML(n) : n)
                            } else {
                                var i = t.createElement("script");
                                i.defer = goog.Dependency.defer_, i.async = !1, r && (i.nonce = r), i.onload = function() {
                                    i.onload = null, e.loaded()
                                }, i.src = goog.TRUSTED_TYPES_POLICY_ ? goog.TRUSTED_TYPES_POLICY_.createScriptURL(this.path) : this.path, t.head.appendChild(i)
                            }
                        } else goog.logToConsole_("Cannot use default debug loader outside of HTML documents."), "deps.js" == this.relativePath ? (goog.logToConsole_("Consider setting CLOSURE_IMPORT_SCRIPT before loading base.js, or setting CLOSURE_NO_DEPS to true."), e.loaded()) : e.pause()
                    }, goog.Es6ModuleDependency = function(e, t, r, s, o) {
                        goog.Dependency.call(this, e, t, r, s, o)
                    }, goog.inherits(goog.Es6ModuleDependency, goog.Dependency), goog.Es6ModuleDependency.prototype.load = function(e) {
                        if (goog.global.CLOSURE_IMPORT_SCRIPT) goog.global.CLOSURE_IMPORT_SCRIPT(this.path) ? e.loaded() : e.pause();
                        else if (goog.inHtmlDocument_()) {
                            var t = goog.global.document,
                                r = this;
                            if (goog.isDocumentLoading_()) {
                                var s = function(e, r) {
                                    var s = "",
                                        o = goog.getScriptNonce_();
                                    o && (s = ' nonce="' + o + '"'), e = r ? '<script type="module" crossorigin' + s + ">" + r + "<\/script>" : '<script type="module" crossorigin src="' + e + '"' + s + "><\/script>", t.write(goog.TRUSTED_TYPES_POLICY_ ? goog.TRUSTED_TYPES_POLICY_.createHTML(e) : e)
                                };
                                goog.Dependency.defer_ = !0
                            } else s = function(e, r) {
                                var s = t.createElement("script");
                                s.defer = !0, s.async = !1, s.type = "module", s.setAttribute("crossorigin", !0);
                                var o = goog.getScriptNonce_();
                                o && (s.nonce = o), r ? s.text = goog.TRUSTED_TYPES_POLICY_ ? goog.TRUSTED_TYPES_POLICY_.createScript(r) : r : s.src = goog.TRUSTED_TYPES_POLICY_ ? goog.TRUSTED_TYPES_POLICY_.createScriptURL(e) : e, t.head.appendChild(s)
                            };
                            var o = goog.Dependency.registerCallback_(function() {
                                goog.Dependency.unregisterCallback_(o), e.setModuleState(goog.ModuleType.ES6)
                            });
                            s(void 0, 'goog.Dependency.callback_("' + o + '")'), s(this.path, void 0);
                            var n = goog.Dependency.registerCallback_(function(t) {
                                goog.Dependency.unregisterCallback_(n), e.registerEs6ModuleExports(r.path, t, goog.moduleLoaderState_.moduleName)
                            });
                            s(void 0, 'import * as m from "' + this.path + '"; goog.Dependency.callback_("' + n + '", m)');
                            var i = goog.Dependency.registerCallback_(function() {
                                goog.Dependency.unregisterCallback_(i), e.clearModuleState(), e.loaded()
                            });
                            s(void 0, 'goog.Dependency.callback_("' + i + '")')
                        } else goog.logToConsole_("Cannot use default debug loader outside of HTML documents."), e.pause()
                    }, goog.TransformedDependency = function(e, t, r, s, o) {
                        goog.Dependency.call(this, e, t, r, s, o), this.contents_ = null, this.lazyFetch_ = !goog.inHtmlDocument_() || !("noModule" in goog.global.document.createElement("script"))
                    }, goog.inherits(goog.TransformedDependency, goog.Dependency), goog.TransformedDependency.prototype.load = function(e) {
                        function t() {
                            i.contents_ = goog.loadFileSync_(i.path), i.contents_ && (i.contents_ = i.transform(i.contents_), i.contents_ && (i.contents_ += "\n//# sourceURL=" + i.path))
                        }

                        function r() {
                            if (i.lazyFetch_ && t(), i.contents_) {
                                a && e.setModuleState(goog.ModuleType.ES6);
                                try {
                                    var r = i.contents_;
                                    if (i.contents_ = null, goog.globalEval(goog.CLOSURE_EVAL_PREFILTER_.createScript(r)), a) var s = goog.moduleLoaderState_.moduleName
                                } finally {
                                    a && e.clearModuleState()
                                }
                                a && goog.global.$jscomp.require.ensure([i.getPathName()], function() {
                                    e.registerEs6ModuleExports(i.path, goog.global.$jscomp.require(i.getPathName()), s)
                                }), e.loaded()
                            }
                        }
                        var s, o, n, i = this;
                        if (goog.global.CLOSURE_IMPORT_SCRIPT) t(), this.contents_ && goog.global.CLOSURE_IMPORT_SCRIPT("", this.contents_) ? (this.contents_ = null, e.loaded()) : e.pause();
                        else {
                            var a = this.loadFlags.module == goog.ModuleType.ES6;
                            this.lazyFetch_ || t();
                            var g = 1 < e.pending().length;
                            if (goog.Dependency.defer_ && (g || goog.isDocumentLoading_())) e.defer(function() {
                                r()
                            });
                            else {
                                var u = goog.global.document;
                                if (g = goog.inHtmlDocument_() && ("ActiveXObject" in goog.global || goog.isEdge_()), a && goog.inHtmlDocument_() && goog.isDocumentLoading_() && !g) {
                                    goog.Dependency.defer_ = !0, e.pause();
                                    var d = u.onreadystatechange;
                                    u.onreadystatechange = function() {
                                        "interactive" == u.readyState && (u.onreadystatechange = d, r(), e.resume()), "function" == typeof d && d.apply(void 0, arguments)
                                    }
                                } else goog.inHtmlDocument_() && goog.isDocumentLoading_() ? (s = goog.global.document, o = goog.Dependency.registerCallback_(function() {
                                    goog.Dependency.unregisterCallback_(o), r()
                                }), n = "<script" + ((n = goog.getScriptNonce_()) ? ' nonce="' + n + '"' : "") + ">" + goog.protectScriptTag_('goog.Dependency.callback_("' + o + '");') + "<\/script>", s.write(goog.TRUSTED_TYPES_POLICY_ ? goog.TRUSTED_TYPES_POLICY_.createHTML(n) : n)) : r()
                            }
                        }
                    }, goog.TransformedDependency.prototype.transform = function(e) {}, goog.PreTranspiledEs6ModuleDependency = function(e, t, r, s, o) {
                        goog.TransformedDependency.call(this, e, t, r, s, o)
                    }, goog.inherits(goog.PreTranspiledEs6ModuleDependency, goog.TransformedDependency), goog.PreTranspiledEs6ModuleDependency.prototype.transform = function(e) {
                        return e
                    }, goog.GoogModuleDependency = function(e, t, r, s, o) {
                        goog.TransformedDependency.call(this, e, t, r, s, o)
                    }, goog.inherits(goog.GoogModuleDependency, goog.TransformedDependency), goog.GoogModuleDependency.prototype.transform = function(e) {
                        return goog.LOAD_MODULE_USING_EVAL && void 0 !== goog.global.JSON ? "goog.loadModule(" + goog.global.JSON.stringify(e + "\n//# sourceURL=" + this.path + "\n") + ");" : 'goog.loadModule(function(exports) {"use strict";' + e + "\n;return exports});\n//# sourceURL=" + this.path + "\n"
                    }, goog.DebugLoader_.prototype.addDependency = function(e, t, r, s) {
                        t = t || [], e = e.replace(/\\/g, "/");
                        var o = goog.normalizePath_(goog.basePath + e);
                        for (s && "boolean" != typeof s || (s = s ? {
                                module: goog.ModuleType.GOOG
                            } : {}), r = this.factory_.createDependency(o, e, t, r, s), this.dependencies_[o] = r, r = 0; r < t.length; r++) this.idToPath_[t[r]] = o;
                        this.idToPath_[e] = o
                    }, goog.DependencyFactory = function() {}, goog.DependencyFactory.prototype.createDependency = function(e, t, r, s, o) {
                        return o.module == goog.ModuleType.GOOG ? new goog.GoogModuleDependency(e, t, r, s, o) : o.module == goog.ModuleType.ES6 ? goog.ASSUME_ES_MODULES_TRANSPILED ? new goog.PreTranspiledEs6ModuleDependency(e, t, r, s, o) : new goog.Es6ModuleDependency(e, t, r, s, o) : new goog.Dependency(e, t, r, s, o)
                    }, goog.debugLoader_ = new goog.DebugLoader_, goog.loadClosureDeps = function() {
                        goog.debugLoader_.loadClosureDeps()
                    }, goog.setDependencyFactory = function(e) {
                        goog.debugLoader_.setDependencyFactory(e)
                    }, goog.TRUSTED_TYPES_POLICY_ = goog.TRUSTED_TYPES_POLICY_NAME ? goog.createTrustedTypesPolicy(goog.TRUSTED_TYPES_POLICY_NAME + "#base") : null, goog.global.CLOSURE_NO_DEPS || goog.debugLoader_.loadClosureDeps(), goog.bootstrap = function(e, t) {
                        goog.debugLoader_.bootstrap(e, t)
                    }), !COMPILED) {
                    var isChrome87 = !1;
                    try {
                        isChrome87 = eval(goog.global.trustedTypes.emptyScript) !== goog.global.trustedTypes.emptyScript
                    } catch (e) {}
                    goog.CLOSURE_EVAL_PREFILTER_ = goog.global.trustedTypes && isChrome87 && goog.createTrustedTypesPolicy("goog#base#devonly#eval") || {
                        createScript: goog.identity_
                    }
                }

                function module$contents$goog$object_forEach(e, t, r) {
                    for (const s in e) t.call(r, e[s], s, e)
                }

                function module$contents$goog$object_filter(e, t, r) {
                    const s = {};
                    for (const o in e) t.call(r, e[o], o, e) && (s[o] = e[o]);
                    return s
                }

                function module$contents$goog$object_map(e, t, r) {
                    const s = {};
                    for (const o in e) s[o] = t.call(r, e[o], o, e);
                    return s
                }

                function module$contents$goog$object_some(e, t, r) {
                    for (const s in e)
                        if (t.call(r, e[s], s, e)) return !0;
                    return !1
                }

                function module$contents$goog$object_every(e, t, r) {
                    for (const s in e)
                        if (!t.call(r, e[s], s, e)) return !1;
                    return !0
                }

                function module$contents$goog$object_getCount(e) {
                    let t = 0;
                    for (const r in e) t++;
                    return t
                }

                function module$contents$goog$object_getAnyKey(e) {
                    for (const t in e) return t
                }

                function module$contents$goog$object_getAnyValue(e) {
                    for (const t in e) return e[t]
                }

                function module$contents$goog$object_contains(e, t) {
                    return module$contents$goog$object_containsValue(e, t)
                }

                function module$contents$goog$object_getValues(e) {
                    const t = [];
                    let r = 0;
                    for (const s in e) t[r++] = e[s];
                    return t
                }

                function module$contents$goog$object_getKeys(e) {
                    const t = [];
                    let r = 0;
                    for (const s in e) t[r++] = s;
                    return t
                }

                function module$contents$goog$object_getValueByKeys(e, t) {
                    var r = goog.isArrayLike(t);
                    const s = r ? t : arguments;
                    for (r = r ? 0 : 1; r < s.length; r++) {
                        if (null == e) return;
                        e = e[s[r]]
                    }
                    return e
                }

                function module$contents$goog$object_containsKey(e, t) {
                    return null !== e && t in e
                }

                function module$contents$goog$object_containsValue(e, t) {
                    for (const r in e)
                        if (e[r] == t) return !0;
                    return !1
                }

                function module$contents$goog$object_findKey(e, t, r) {
                    for (const s in e)
                        if (t.call(r, e[s], s, e)) return s
                }

                function module$contents$goog$object_findValue(e, t, r) {
                    return (t = module$contents$goog$object_findKey(e, t, r)) && e[t]
                }

                function module$contents$goog$object_isEmpty(e) {
                    for (const t in e) return !1;
                    return !0
                }

                function module$contents$goog$object_clear(e) {
                    for (const t in e) delete e[t]
                }

                function module$contents$goog$object_remove(e, t) {
                    let r;
                    return (r = t in e) && delete e[t], r
                }

                function module$contents$goog$object_add(e, t, r) {
                    if (null !== e && t in e) throw Error(`The object already contains the key "${t}"`);
                    module$contents$goog$object_set(e, t, r)
                }

                function module$contents$goog$object_get(e, t, r) {
                    return null !== e && t in e ? e[t] : r
                }

                function module$contents$goog$object_set(e, t, r) {
                    e[t] = r
                }

                function module$contents$goog$object_setIfUndefined(e, t, r) {
                    return t in e ? e[t] : e[t] = r
                }

                function module$contents$goog$object_setWithReturnValueIfNotSet(e, t, r) {
                    return t in e ? e[t] : (r = r(), e[t] = r)
                }

                function module$contents$goog$object_equals(e, t) {
                    for (const r in e)
                        if (!(r in t) || e[r] !== t[r]) return !1;
                    for (const r in t)
                        if (!(r in e)) return !1;
                    return !0
                }

                function module$contents$goog$object_clone(e) {
                    const t = {};
                    for (const r in e) t[r] = e[r];
                    return t
                }

                function module$contents$goog$object_unsafeClone(e) {
                    if (!e || "object" != typeof e) return e;
                    if ("function" == typeof e.clone) return e.clone();
                    if ("undefined" != typeof Map && e instanceof Map) return new Map(e);
                    if ("undefined" != typeof Set && e instanceof Set) return new Set(e);
                    if (e instanceof Date) return new Date(e.getTime());
                    const t = Array.isArray(e) ? [] : "function" != typeof ArrayBuffer || "function" != typeof ArrayBuffer.isView || !ArrayBuffer.isView(e) || e instanceof DataView ? {} : new e.constructor(e.length);
                    for (const r in e) t[r] = module$contents$goog$object_unsafeClone(e[r]);
                    return t
                }

                function module$contents$goog$object_transpose(e) {
                    const t = {};
                    for (const r in e) t[e[r]] = r;
                    return t
                }
                goog.object = {};
                const module$contents$goog$object_PROTOTYPE_FIELDS = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

                function module$contents$goog$object_extend(e, t) {
                    let r, s;
                    for (let t = 1; t < arguments.length; t++) {
                        for (r in s = arguments[t], s) e[r] = s[r];
                        for (let t = 0; t < module$contents$goog$object_PROTOTYPE_FIELDS.length; t++) r = module$contents$goog$object_PROTOTYPE_FIELDS[t], Object.prototype.hasOwnProperty.call(s, r) && (e[r] = s[r])
                    }
                }

                function module$contents$goog$object_create(e) {
                    const t = arguments.length;
                    if (1 == t && Array.isArray(arguments[0])) return module$contents$goog$object_create.apply(null, arguments[0]);
                    if (t % 2) throw Error("Uneven number of arguments");
                    const r = {};
                    for (let e = 0; e < t; e += 2) r[arguments[e]] = arguments[e + 1];
                    return r
                }

                function module$contents$goog$object_createSet(e) {
                    const t = arguments.length;
                    if (1 == t && Array.isArray(arguments[0])) return module$contents$goog$object_createSet.apply(null, arguments[0]);
                    const r = {};
                    for (let e = 0; e < t; e++) r[arguments[e]] = !0;
                    return r
                }

                function module$contents$goog$object_createImmutableView(e) {
                    let t = e;
                    return Object.isFrozen && !Object.isFrozen(e) && (t = Object.create(e), Object.freeze(t)), t
                }

                function module$contents$goog$object_isImmutableView(e) {
                    return !!Object.isFrozen && Object.isFrozen(e)
                }

                function module$contents$goog$object_getAllPropertyNames(e, t, r) {
                    if (!e) return [];
                    if (!Object.getOwnPropertyNames || !Object.getPrototypeOf) return module$contents$goog$object_getKeys(e);
                    const s = {};
                    for (; e && (e !== Object.prototype || t) && (e !== Function.prototype || r);) {
                        const t = Object.getOwnPropertyNames(e);
                        for (let e = 0; e < t.length; e++) s[t[e]] = !0;
                        e = Object.getPrototypeOf(e)
                    }
                    return module$contents$goog$object_getKeys(s)
                }

                function module$contents$goog$object_getSuperClass(e) {
                    return (e = Object.getPrototypeOf(e.prototype)) && e.constructor
                }

                function module$contents$goog$debug$Error_DebugError(e, t) {
                    if (Error.captureStackTrace) Error.captureStackTrace(this, module$contents$goog$debug$Error_DebugError);
                    else {
                        const e = Error().stack;
                        e && (this.stack = e)
                    }
                    e && (this.message = String(e)), void 0 !== t && (this.cause = t), this.reportErrorToServer = !0
                }

                function module$contents$goog$asserts_AssertionError(e, t) {
                    module$contents$goog$debug$Error_DebugError.call(this, module$contents$goog$asserts_subs(e, t)), this.messagePattern = e
                }
                goog.object.add = module$contents$goog$object_add, goog.object.clear = module$contents$goog$object_clear, goog.object.clone = module$contents$goog$object_clone, goog.object.contains = module$contents$goog$object_contains, goog.object.containsKey = module$contents$goog$object_containsKey, goog.object.containsValue = module$contents$goog$object_containsValue, goog.object.create = module$contents$goog$object_create, goog.object.createImmutableView = module$contents$goog$object_createImmutableView, goog.object.createSet = module$contents$goog$object_createSet, goog.object.equals = module$contents$goog$object_equals, goog.object.every = module$contents$goog$object_every, goog.object.extend = module$contents$goog$object_extend, goog.object.filter = module$contents$goog$object_filter, goog.object.findKey = module$contents$goog$object_findKey, goog.object.findValue = module$contents$goog$object_findValue, goog.object.forEach = module$contents$goog$object_forEach, goog.object.get = module$contents$goog$object_get, goog.object.getAllPropertyNames = module$contents$goog$object_getAllPropertyNames, goog.object.getAnyKey = module$contents$goog$object_getAnyKey, goog.object.getAnyValue = module$contents$goog$object_getAnyValue, goog.object.getCount = module$contents$goog$object_getCount, goog.object.getKeys = module$contents$goog$object_getKeys, goog.object.getSuperClass = module$contents$goog$object_getSuperClass, goog.object.getValueByKeys = module$contents$goog$object_getValueByKeys, goog.object.getValues = module$contents$goog$object_getValues, goog.object.isEmpty = module$contents$goog$object_isEmpty, goog.object.isImmutableView = module$contents$goog$object_isImmutableView, goog.object.map = module$contents$goog$object_map, goog.object.remove = module$contents$goog$object_remove, goog.object.set = module$contents$goog$object_set, goog.object.setIfUndefined = module$contents$goog$object_setIfUndefined, goog.object.setWithReturnValueIfNotSet = module$contents$goog$object_setWithReturnValueIfNotSet, goog.object.some = module$contents$goog$object_some, goog.object.transpose = module$contents$goog$object_transpose, goog.object.unsafeClone = module$contents$goog$object_unsafeClone, goog.debug = {}, goog.inherits(module$contents$goog$debug$Error_DebugError, Error), module$contents$goog$debug$Error_DebugError.prototype.name = "CustomError", goog.debug.Error = module$contents$goog$debug$Error_DebugError, goog.dom = {}, goog.dom.NodeType = {
                    ELEMENT: 1,
                    ATTRIBUTE: 2,
                    TEXT: 3,
                    CDATA_SECTION: 4,
                    ENTITY_REFERENCE: 5,
                    ENTITY: 6,
                    PROCESSING_INSTRUCTION: 7,
                    COMMENT: 8,
                    DOCUMENT: 9,
                    DOCUMENT_TYPE: 10,
                    DOCUMENT_FRAGMENT: 11,
                    NOTATION: 12
                }, goog.asserts = {}, goog.asserts.ENABLE_ASSERTS = goog.DEBUG, goog.inherits(module$contents$goog$asserts_AssertionError, module$contents$goog$debug$Error_DebugError), goog.asserts.AssertionError = module$contents$goog$asserts_AssertionError, module$contents$goog$asserts_AssertionError.prototype.name = "AssertionError", goog.asserts.DEFAULT_ERROR_HANDLER = function(e) {
                    throw e
                };
                let module$contents$goog$asserts_errorHandler_ = goog.asserts.DEFAULT_ERROR_HANDLER;

                function module$contents$goog$asserts_subs(e, t) {
                    let r = "";
                    const s = (e = e.split("%s")).length - 1;
                    for (let o = 0; o < s; o++) r += e[o] + (o < t.length ? t[o] : "%s");
                    return r + e[s]
                }

                function module$contents$goog$asserts_doAssertFailure(e, t, r, s) {
                    let o, n = "Assertion failed";
                    r ? (n += ": " + r, o = s) : e && (n += ": " + e, o = t), e = new module$contents$goog$asserts_AssertionError("" + n, o || []), module$contents$goog$asserts_errorHandler_(e)
                }

                function module$contents$goog$asserts_getType(e) {
                    return e instanceof Function ? e.displayName || e.name || "unknown type name" : e instanceof Object ? e.constructor.displayName || e.constructor.name || Object.prototype.toString.call(e) : null === e ? "null" : typeof e
                }
                goog.asserts.setErrorHandler = function(e) {
                    goog.asserts.ENABLE_ASSERTS && (module$contents$goog$asserts_errorHandler_ = e)
                }, goog.asserts.assert = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && !e && module$contents$goog$asserts_doAssertFailure("", null, t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertExists = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && null == e && module$contents$goog$asserts_doAssertFailure("Expected to exist: %s.", [e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.fail = function(e, t) {
                    goog.asserts.ENABLE_ASSERTS && module$contents$goog$asserts_errorHandler_(new module$contents$goog$asserts_AssertionError("Failure" + (e ? ": " + e : ""), Array.prototype.slice.call(arguments, 1)))
                }, goog.asserts.assertNumber = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && "number" != typeof e && module$contents$goog$asserts_doAssertFailure("Expected number but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertString = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && "string" != typeof e && module$contents$goog$asserts_doAssertFailure("Expected string but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertFunction = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && "function" != typeof e && module$contents$goog$asserts_doAssertFailure("Expected function but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertObject = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && !goog.isObject(e) && module$contents$goog$asserts_doAssertFailure("Expected object but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertArray = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && !Array.isArray(e) && module$contents$goog$asserts_doAssertFailure("Expected array but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertBoolean = function(e, t, r) {
                    return goog.asserts.ENABLE_ASSERTS && "boolean" != typeof e && module$contents$goog$asserts_doAssertFailure("Expected boolean but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertElement = function(e, t, r) {
                    return !goog.asserts.ENABLE_ASSERTS || goog.isObject(e) && e.nodeType == goog.dom.NodeType.ELEMENT || module$contents$goog$asserts_doAssertFailure("Expected Element but got %s: %s.", [goog.typeOf(e), e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.asserts.assertInstanceof = function(e, t, r, s) {
                    return !goog.asserts.ENABLE_ASSERTS || e instanceof t || module$contents$goog$asserts_doAssertFailure("Expected instanceof %s but got %s.", [module$contents$goog$asserts_getType(t), module$contents$goog$asserts_getType(e)], r, Array.prototype.slice.call(arguments, 3)), e
                }, goog.asserts.assertFinite = function(e, t, r) {
                    return !goog.asserts.ENABLE_ASSERTS || "number" == typeof e && isFinite(e) || module$contents$goog$asserts_doAssertFailure("Expected %s to be a finite number but it is not.", [e], t, Array.prototype.slice.call(arguments, 2)), e
                }, goog.array = {}, goog.NATIVE_ARRAY_PROTOTYPES = goog.TRUSTED_SITE;
                const module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS = 2012 < goog.FEATURESET_YEAR;

                function module$contents$goog$array_peek(e) {
                    return e[e.length - 1]
                }
                goog.array.ASSUME_NATIVE_FUNCTIONS = module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS, goog.array.peek = module$contents$goog$array_peek, goog.array.last = module$contents$goog$array_peek;
                const module$contents$goog$array_indexOf = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.indexOf) ? function(e, t, r) {
                    return goog.asserts.assert(null != e.length), Array.prototype.indexOf.call(e, t, r)
                } : function(e, t, r) {
                    if (r = null == r ? 0 : 0 > r ? Math.max(0, e.length + r) : r, "string" == typeof e) return "string" != typeof t || 1 != t.length ? -1 : e.indexOf(t, r);
                    for (; r < e.length; r++)
                        if (r in e && e[r] === t) return r;
                    return -1
                };
                goog.array.indexOf = module$contents$goog$array_indexOf;
                const module$contents$goog$array_lastIndexOf = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.lastIndexOf) ? function(e, t, r) {
                    return goog.asserts.assert(null != e.length), Array.prototype.lastIndexOf.call(e, t, null == r ? e.length - 1 : r)
                } : function(e, t, r) {
                    if (0 > (r = null == r ? e.length - 1 : r) && (r = Math.max(0, e.length + r)), "string" == typeof e) return "string" != typeof t || 1 != t.length ? -1 : e.lastIndexOf(t, r);
                    for (; 0 <= r; r--)
                        if (r in e && e[r] === t) return r;
                    return -1
                };
                goog.array.lastIndexOf = module$contents$goog$array_lastIndexOf;
                const module$contents$goog$array_forEach = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.forEach) ? function(e, t, r) {
                    goog.asserts.assert(null != e.length), Array.prototype.forEach.call(e, t, r)
                } : function(e, t, r) {
                    const s = e.length,
                        o = "string" == typeof e ? e.split("") : e;
                    for (let n = 0; n < s; n++) n in o && t.call(r, o[n], n, e)
                };

                function module$contents$goog$array_forEachRight(e, t, r) {
                    var s = e.length;
                    const o = "string" == typeof e ? e.split("") : e;
                    for (--s; 0 <= s; --s) s in o && t.call(r, o[s], s, e)
                }
                goog.array.forEach = module$contents$goog$array_forEach, goog.array.forEachRight = module$contents$goog$array_forEachRight;
                const module$contents$goog$array_filter = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.filter) ? function(e, t, r) {
                    return goog.asserts.assert(null != e.length), Array.prototype.filter.call(e, t, r)
                } : function(e, t, r) {
                    const s = e.length,
                        o = [];
                    let n = 0;
                    const i = "string" == typeof e ? e.split("") : e;
                    for (let a = 0; a < s; a++)
                        if (a in i) {
                            const s = i[a];
                            t.call(r, s, a, e) && (o[n++] = s)
                        }
                    return o
                };
                goog.array.filter = module$contents$goog$array_filter;
                const module$contents$goog$array_map = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.map) ? function(e, t, r) {
                    return goog.asserts.assert(null != e.length), Array.prototype.map.call(e, t, r)
                } : function(e, t, r) {
                    const s = e.length,
                        o = Array(s),
                        n = "string" == typeof e ? e.split("") : e;
                    for (let i = 0; i < s; i++) i in n && (o[i] = t.call(r, n[i], i, e));
                    return o
                };
                goog.array.map = module$contents$goog$array_map;
                const module$contents$goog$array_reduce = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.reduce) ? function(e, t, r, s) {
                    return goog.asserts.assert(null != e.length), s && (t = goog.bind(t, s)), Array.prototype.reduce.call(e, t, r)
                } : function(e, t, r, s) {
                    let o = r;
                    return module$contents$goog$array_forEach(e, function(r, n) {
                        o = t.call(s, o, r, n, e)
                    }), o
                };
                goog.array.reduce = module$contents$goog$array_reduce;
                const module$contents$goog$array_reduceRight = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.reduceRight) ? function(e, t, r, s) {
                    return goog.asserts.assert(null != e.length), goog.asserts.assert(null != t), s && (t = goog.bind(t, s)), Array.prototype.reduceRight.call(e, t, r)
                } : function(e, t, r, s) {
                    let o = r;
                    return module$contents$goog$array_forEachRight(e, function(r, n) {
                        o = t.call(s, o, r, n, e)
                    }), o
                };
                goog.array.reduceRight = module$contents$goog$array_reduceRight;
                const module$contents$goog$array_some = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.some) ? function(e, t, r) {
                    return goog.asserts.assert(null != e.length), Array.prototype.some.call(e, t, r)
                } : function(e, t, r) {
                    const s = e.length,
                        o = "string" == typeof e ? e.split("") : e;
                    for (let n = 0; n < s; n++)
                        if (n in o && t.call(r, o[n], n, e)) return !0;
                    return !1
                };
                goog.array.some = module$contents$goog$array_some;
                const module$contents$goog$array_every = goog.NATIVE_ARRAY_PROTOTYPES && (module$contents$goog$array_ASSUME_NATIVE_FUNCTIONS || Array.prototype.every) ? function(e, t, r) {
                    return goog.asserts.assert(null != e.length), Array.prototype.every.call(e, t, r)
                } : function(e, t, r) {
                    const s = e.length,
                        o = "string" == typeof e ? e.split("") : e;
                    for (let n = 0; n < s; n++)
                        if (n in o && !t.call(r, o[n], n, e)) return !1;
                    return !0
                };

                function module$contents$goog$array_count(e, t, r) {
                    let s = 0;
                    return module$contents$goog$array_forEach(e, function(e, o, n) {
                        t.call(r, e, o, n) && ++s
                    }, r), s
                }

                function module$contents$goog$array_find(e, t, r) {
                    return 0 > (t = module$contents$goog$array_findIndex(e, t, r)) ? null : "string" == typeof e ? e.charAt(t) : e[t]
                }

                function module$contents$goog$array_findIndex(e, t, r) {
                    const s = e.length,
                        o = "string" == typeof e ? e.split("") : e;
                    for (let n = 0; n < s; n++)
                        if (n in o && t.call(r, o[n], n, e)) return n;
                    return -1
                }

                function module$contents$goog$array_findRight(e, t, r) {
                    return 0 > (t = module$contents$goog$array_findIndexRight(e, t, r)) ? null : "string" == typeof e ? e.charAt(t) : e[t]
                }

                function module$contents$goog$array_findIndexRight(e, t, r) {
                    var s = e.length;
                    const o = "string" == typeof e ? e.split("") : e;
                    for (--s; 0 <= s; s--)
                        if (s in o && t.call(r, o[s], s, e)) return s;
                    return -1
                }

                function module$contents$goog$array_contains(e, t) {
                    return 0 <= module$contents$goog$array_indexOf(e, t)
                }

                function module$contents$goog$array_isEmpty(e) {
                    return 0 == e.length
                }

                function module$contents$goog$array_clear(e) {
                    if (!Array.isArray(e))
                        for (let t = e.length - 1; 0 <= t; t--) delete e[t];
                    e.length = 0
                }

                function module$contents$goog$array_insert(e, t) {
                    module$contents$goog$array_contains(e, t) || e.push(t)
                }

                function module$contents$goog$array_insertAt(e, t, r) {
                    module$contents$goog$array_splice(e, r, 0, t)
                }

                function module$contents$goog$array_insertArrayAt(e, t, r) {
                    goog.partial(module$contents$goog$array_splice, e, r, 0).apply(null, t)
                }

                function module$contents$goog$array_insertBefore(e, t, r) {
                    let s;
                    2 == arguments.length || 0 > (s = module$contents$goog$array_indexOf(e, r)) ? e.push(t) : module$contents$goog$array_insertAt(e, t, s)
                }

                function module$contents$goog$array_remove(e, t) {
                    let r;
                    return (r = 0 <= (t = module$contents$goog$array_indexOf(e, t))) && module$contents$goog$array_removeAt(e, t), r
                }

                function module$contents$goog$array_removeLast(e, t) {
                    return 0 <= (t = module$contents$goog$array_lastIndexOf(e, t)) && (module$contents$goog$array_removeAt(e, t), !0)
                }

                function module$contents$goog$array_removeAt(e, t) {
                    return goog.asserts.assert(null != e.length), 1 == Array.prototype.splice.call(e, t, 1).length
                }

                function module$contents$goog$array_removeIf(e, t, r) {
                    return 0 <= (t = module$contents$goog$array_findIndex(e, t, r)) && (module$contents$goog$array_removeAt(e, t), !0)
                }

                function module$contents$goog$array_removeAllIf(e, t, r) {
                    let s = 0;
                    return module$contents$goog$array_forEachRight(e, function(o, n) {
                        t.call(r, o, n, e) && module$contents$goog$array_removeAt(e, n) && s++
                    }), s
                }

                function module$contents$goog$array_concat(e) {
                    return Array.prototype.concat.apply([], arguments)
                }

                function module$contents$goog$array_join(e) {
                    return Array.prototype.concat.apply([], arguments)
                }

                function module$contents$goog$array_toArray(e) {
                    const t = e.length;
                    if (0 < t) {
                        const r = Array(t);
                        for (let s = 0; s < t; s++) r[s] = e[s];
                        return r
                    }
                    return []
                }
                goog.array.every = module$contents$goog$array_every, goog.array.count = module$contents$goog$array_count, goog.array.find = module$contents$goog$array_find, goog.array.findIndex = module$contents$goog$array_findIndex, goog.array.findRight = module$contents$goog$array_findRight, goog.array.findIndexRight = module$contents$goog$array_findIndexRight, goog.array.contains = module$contents$goog$array_contains, goog.array.isEmpty = module$contents$goog$array_isEmpty, goog.array.clear = module$contents$goog$array_clear, goog.array.insert = module$contents$goog$array_insert, goog.array.insertAt = module$contents$goog$array_insertAt, goog.array.insertArrayAt = module$contents$goog$array_insertArrayAt, goog.array.insertBefore = module$contents$goog$array_insertBefore, goog.array.remove = module$contents$goog$array_remove, goog.array.removeLast = module$contents$goog$array_removeLast, goog.array.removeAt = module$contents$goog$array_removeAt, goog.array.removeIf = module$contents$goog$array_removeIf, goog.array.removeAllIf = module$contents$goog$array_removeAllIf, goog.array.concat = module$contents$goog$array_concat, goog.array.join = module$contents$goog$array_join;
                const module$contents$goog$array_clone = goog.array.toArray = module$contents$goog$array_toArray;

                function module$contents$goog$array_extend(e, t) {
                    for (let t = 1; t < arguments.length; t++) {
                        const r = arguments[t];
                        if (goog.isArrayLike(r)) {
                            const t = e.length || 0,
                                s = r.length || 0;
                            e.length = t + s;
                            for (let o = 0; o < s; o++) e[t + o] = r[o]
                        } else e.push(r)
                    }
                }

                function module$contents$goog$array_splice(e, t, r, s) {
                    return goog.asserts.assert(null != e.length), Array.prototype.splice.apply(e, module$contents$goog$array_slice(arguments, 1))
                }

                function module$contents$goog$array_slice(e, t, r) {
                    return goog.asserts.assert(null != e.length), 2 >= arguments.length ? Array.prototype.slice.call(e, t) : Array.prototype.slice.call(e, t, r)
                }

                function module$contents$goog$array_removeDuplicates(e, t, r) {
                    t = t || e;
                    var s = function(e) {
                        return goog.isObject(e) ? "o" + goog.getUid(e) : (typeof e).charAt(0) + e
                    };
                    r = r || s;
                    let o = s = 0;
                    const n = {};
                    for (; o < e.length;) {
                        const i = e[o++],
                            a = r(i);
                        Object.prototype.hasOwnProperty.call(n, a) || (n[a] = !0, t[s++] = i)
                    }
                    t.length = s
                }

                function module$contents$goog$array_binarySearch(e, t, r) {
                    return module$contents$goog$array_binarySearch_(e, r || module$contents$goog$array_defaultCompare, !1, t)
                }

                function module$contents$goog$array_binarySelect(e, t, r) {
                    return module$contents$goog$array_binarySearch_(e, t, !0, void 0, r)
                }

                function module$contents$goog$array_binarySearch_(e, t, r, s, o) {
                    let n, i = 0,
                        a = e.length;
                    for (; i < a;) {
                        const g = i + (a - i >>> 1);
                        let u;
                        u = r ? t.call(o, e[g], g, e) : t(s, e[g]), 0 < u ? i = g + 1 : (a = g, n = !u)
                    }
                    return n ? i : -i - 1
                }

                function module$contents$goog$array_sort(e, t) {
                    e.sort(t || module$contents$goog$array_defaultCompare)
                }

                function module$contents$goog$array_stableSort(e, t) {
                    const r = Array(e.length);
                    for (let t = 0; t < e.length; t++) r[t] = {
                        index: t,
                        value: e[t]
                    };
                    const s = t || module$contents$goog$array_defaultCompare;
                    for (module$contents$goog$array_sort(r, function(e, t) {
                            return s(e.value, t.value) || e.index - t.index
                        }), t = 0; t < e.length; t++) e[t] = r[t].value
                }

                function module$contents$goog$array_sortByKey(e, t, r) {
                    const s = r || module$contents$goog$array_defaultCompare;
                    module$contents$goog$array_sort(e, function(e, r) {
                        return s(t(e), t(r))
                    })
                }

                function module$contents$goog$array_sortObjectsByKey(e, t, r) {
                    module$contents$goog$array_sortByKey(e, function(e) {
                        return e[t]
                    }, r)
                }

                function module$contents$goog$array_isSorted(e, t, r) {
                    t = t || module$contents$goog$array_defaultCompare;
                    for (let s = 1; s < e.length; s++) {
                        const o = t(e[s - 1], e[s]);
                        if (0 < o || 0 == o && r) return !1
                    }
                    return !0
                }

                function module$contents$goog$array_equals(e, t, r) {
                    if (!goog.isArrayLike(e) || !goog.isArrayLike(t) || e.length != t.length) return !1;
                    const s = e.length;
                    r = r || module$contents$goog$array_defaultCompareEquality;
                    for (let o = 0; o < s; o++)
                        if (!r(e[o], t[o])) return !1;
                    return !0
                }

                function module$contents$goog$array_compare3(e, t, r) {
                    r = r || module$contents$goog$array_defaultCompare;
                    const s = Math.min(e.length, t.length);
                    for (let o = 0; o < s; o++) {
                        const s = r(e[o], t[o]);
                        if (0 != s) return s
                    }
                    return module$contents$goog$array_defaultCompare(e.length, t.length)
                }

                function module$contents$goog$array_defaultCompare(e, t) {
                    return e > t ? 1 : e < t ? -1 : 0
                }

                function module$contents$goog$array_inverseDefaultCompare(e, t) {
                    return -module$contents$goog$array_defaultCompare(e, t)
                }

                function module$contents$goog$array_defaultCompareEquality(e, t) {
                    return e === t
                }

                function module$contents$goog$array_binaryInsert(e, t, r) {
                    return 0 > (r = module$contents$goog$array_binarySearch(e, t, r)) && (module$contents$goog$array_insertAt(e, t, -(r + 1)), !0)
                }

                function module$contents$goog$array_binaryRemove(e, t, r) {
                    return 0 <= (t = module$contents$goog$array_binarySearch(e, t, r)) && module$contents$goog$array_removeAt(e, t)
                }

                function module$contents$goog$array_bucket(e, t, r) {
                    const s = {};
                    for (let o = 0; o < e.length; o++) {
                        const n = e[o],
                            i = t.call(r, n, o, e);
                        void 0 !== i && (s[i] || (s[i] = [])).push(n)
                    }
                    return s
                }

                function module$contents$goog$array_bucketToMap(e, t) {
                    const r = new Map;
                    for (let s = 0; s < e.length; s++) {
                        const o = e[s],
                            n = t(o, s, e);
                        if (void 0 !== n) {
                            let e = r.get(n);
                            e || (e = [], r.set(n, e)), e.push(o)
                        }
                    }
                    return r
                }

                function module$contents$goog$array_toObject(e, t, r) {
                    const s = {};
                    return module$contents$goog$array_forEach(e, function(o, n) {
                        s[t.call(r, o, n, e)] = o
                    }), s
                }

                function module$contents$goog$array_toMap(e, t) {
                    const r = new Map;
                    for (let s = 0; s < e.length; s++) {
                        const o = e[s];
                        r.set(t(o, s, e), o)
                    }
                    return r
                }

                function module$contents$goog$array_range(e, t, r) {
                    const s = [];
                    let o = 0,
                        n = e;
                    if (void 0 !== t && (o = e, n = t), 0 > (r = r || 1) * (n - o)) return [];
                    if (0 < r)
                        for (e = o; e < n; e += r) s.push(e);
                    else
                        for (e = o; e > n; e += r) s.push(e);
                    return s
                }

                function module$contents$goog$array_repeat(e, t) {
                    const r = [];
                    for (let s = 0; s < t; s++) r[s] = e;
                    return r
                }

                function module$contents$goog$array_flatten(e) {
                    const t = [];
                    for (let e = 0; e < arguments.length; e++) {
                        const s = arguments[e];
                        if (Array.isArray(s))
                            for (let e = 0; e < s.length; e += 8192) {
                                var r = module$contents$goog$array_slice(s, e, e + 8192);
                                r = module$contents$goog$array_flatten.apply(null, r);
                                for (let e = 0; e < r.length; e++) t.push(r[e])
                            } else t.push(s)
                    }
                    return t
                }

                function module$contents$goog$array_rotate(e, t) {
                    return goog.asserts.assert(null != e.length), e.length && (0 < (t %= e.length) ? Array.prototype.unshift.apply(e, e.splice(-t, t)) : 0 > t && Array.prototype.push.apply(e, e.splice(0, -t))), e
                }

                function module$contents$goog$array_moveItem(e, t, r) {
                    goog.asserts.assert(0 <= t && t < e.length), goog.asserts.assert(0 <= r && r < e.length), t = Array.prototype.splice.call(e, t, 1), Array.prototype.splice.call(e, r, 0, t[0])
                }

                function module$contents$goog$array_zip(e) {
                    if (!arguments.length) return [];
                    const t = [];
                    let r = arguments[0].length;
                    for (var s = 1; s < arguments.length; s++) arguments[s].length < r && (r = arguments[s].length);
                    for (s = 0; s < r; s++) {
                        const e = [];
                        for (let t = 0; t < arguments.length; t++) e.push(arguments[t][s]);
                        t.push(e)
                    }
                    return t
                }

                function module$contents$goog$array_shuffle(e, t) {
                    t = t || Math.random;
                    for (let r = e.length - 1; 0 < r; r--) {
                        const s = Math.floor(t() * (r + 1)),
                            o = e[r];
                        e[r] = e[s], e[s] = o
                    }
                }

                function module$contents$goog$array_copyByIndex(e, t) {
                    const r = [];
                    return module$contents$goog$array_forEach(t, function(t) {
                        r.push(e[t])
                    }), r
                }

                function module$contents$goog$array_concatMap(e, t, r) {
                    return module$contents$goog$array_concat.apply([], module$contents$goog$array_map(e, t, r))
                }
                goog.array.clone = module$contents$goog$array_toArray, goog.array.extend = module$contents$goog$array_extend, goog.array.splice = module$contents$goog$array_splice, goog.array.slice = module$contents$goog$array_slice, goog.array.removeDuplicates = module$contents$goog$array_removeDuplicates, goog.array.binarySearch = module$contents$goog$array_binarySearch, goog.array.binarySelect = module$contents$goog$array_binarySelect, goog.array.sort = module$contents$goog$array_sort, goog.array.stableSort = module$contents$goog$array_stableSort, goog.array.sortByKey = module$contents$goog$array_sortByKey, goog.array.sortObjectsByKey = module$contents$goog$array_sortObjectsByKey, goog.array.isSorted = module$contents$goog$array_isSorted, goog.array.equals = module$contents$goog$array_equals, goog.array.compare3 = module$contents$goog$array_compare3, goog.array.defaultCompare = module$contents$goog$array_defaultCompare, goog.array.inverseDefaultCompare = module$contents$goog$array_inverseDefaultCompare, goog.array.defaultCompareEquality = module$contents$goog$array_defaultCompareEquality, goog.array.binaryInsert = module$contents$goog$array_binaryInsert, goog.array.binaryRemove = module$contents$goog$array_binaryRemove, goog.array.bucket = module$contents$goog$array_bucket, goog.array.bucketToMap = module$contents$goog$array_bucketToMap, goog.array.toObject = module$contents$goog$array_toObject, goog.array.toMap = module$contents$goog$array_toMap, goog.array.range = module$contents$goog$array_range, goog.array.repeat = module$contents$goog$array_repeat, goog.array.flatten = module$contents$goog$array_flatten, goog.array.rotate = module$contents$goog$array_rotate, goog.array.moveItem = module$contents$goog$array_moveItem, goog.array.zip = module$contents$goog$array_zip, goog.array.shuffle = module$contents$goog$array_shuffle, goog.array.copyByIndex = module$contents$goog$array_copyByIndex, goog.array.concatMap = module$contents$goog$array_concatMap;
                var jspb = {
                    asserts: {}
                };

                function module$contents$goog$async$throwException_throwException(e) {
                    goog.global.setTimeout(() => {
                        throw e
                    }, 0)
                }
                jspb.asserts.doAssertFailure = function(e, t, r, s) {
                    let o, n = "Assertion failed";
                    throw r ? (n += ": " + r, o = s) : e && (n += ": " + e, o = t), Error("" + n, o || [])
                }, jspb.asserts.assert = function(e, t, ...r) {
                    return e || jspb.asserts.doAssertFailure("", null, t, r), e
                }, jspb.asserts.assertString = function(e, t, ...r) {
                    return "string" != typeof e && jspb.asserts.doAssertFailure("Expected string but got %s: %s.", [goog.typeOf(e), e], t, r), e
                }, jspb.asserts.assertArray = function(e, t, ...r) {
                    return Array.isArray(e) || jspb.asserts.doAssertFailure("Expected array but got %s: %s.", [goog.typeOf(e), e], t, r), e
                }, jspb.asserts.fail = function(e, ...t) {
                    throw Error("Failure" + (e ? ": " + e : ""), t)
                }, jspb.asserts.assertInstanceof = function(e, t, r, ...s) {
                    return e instanceof t || jspb.asserts.doAssertFailure("Expected instanceof %s but got %s.", [jspb.asserts.getType(t), jspb.asserts.getType(e)], r, s), e
                }, jspb.asserts.getType = function(e) {
                    return e instanceof Function ? e.displayName || e.name || "unknown type name" : e instanceof Object ? e.constructor.displayName || e.constructor.name || Object.prototype.toString.call(e) : null === e ? "null" : typeof e
                }, jspb.Map = function(e, t) {
                    this.arr_ = e, this.valueCtor_ = t, this.map_ = {}, this.arrClean = !0, 0 < this.arr_.length && this.loadFromArray_()
                }, goog.exportSymbol("jspb.Map", jspb.Map), jspb.Map.prototype.loadFromArray_ = function() {
                    for (var e = 0; e < this.arr_.length; e++) {
                        var t = this.arr_[e],
                            r = t[0];
                        this.map_[r.toString()] = new jspb.Map.Entry_(r, t[1])
                    }
                    this.arrClean = !0
                }, jspb.Map.prototype.toArray = function() {
                    if (this.arrClean) {
                        if (this.valueCtor_) {
                            var e, t = this.map_;
                            for (e in t)
                                if (Object.prototype.hasOwnProperty.call(t, e)) {
                                    var r = t[e].valueWrapper;
                                    r && r.toArray()
                                }
                        }
                    } else {
                        for (this.arr_.length = 0, (t = this.stringKeys_()).sort(), e = 0; e < t.length; e++) {
                            var s = this.map_[t[e]];
                            (r = s.valueWrapper) && r.toArray(), this.arr_.push([s.key, s.value])
                        }
                        this.arrClean = !0
                    }
                    return this.arr_
                }, goog.exportProperty(jspb.Map.prototype, "toArray", jspb.Map.prototype.toArray), jspb.Map.prototype.toObject = function(e, t) {
                    for (var r = this.toArray(), s = [], o = 0; o < r.length; o++) {
                        var n = this.map_[r[o][0].toString()];
                        this.wrapEntry_(n);
                        var i = n.valueWrapper;
                        i ? (jspb.asserts.assert(t), s.push([n.key, t(e, i)])) : s.push([n.key, n.value])
                    }
                    return s
                }, goog.exportProperty(jspb.Map.prototype, "toObject", jspb.Map.prototype.toObject), jspb.Map.fromObject = function(e, t, r) {
                    t = new jspb.Map([], t);
                    for (var s = 0; s < e.length; s++) {
                        var o = e[s][0],
                            n = r(e[s][1]);
                        t.set(o, n)
                    }
                    return t
                }, goog.exportProperty(jspb.Map, "fromObject", jspb.Map.fromObject), jspb.Map.ArrayIteratorIterable_ = function(e) {
                    this.idx_ = 0, this.arr_ = e
                }, jspb.Map.ArrayIteratorIterable_.prototype.next = function() {
                    return this.idx_ < this.arr_.length ? {
                        done: !1,
                        value: this.arr_[this.idx_++]
                    } : {
                        done: !0,
                        value: void 0
                    }
                }, "undefined" != typeof Symbol && (jspb.Map.ArrayIteratorIterable_.prototype[Symbol.iterator] = function() {
                    return this
                }), jspb.Map.prototype.getLength = function() {
                    return this.stringKeys_().length
                }, goog.exportProperty(jspb.Map.prototype, "getLength", jspb.Map.prototype.getLength), jspb.Map.prototype.clear = function() {
                    this.map_ = {}, this.arrClean = !1
                }, goog.exportProperty(jspb.Map.prototype, "clear", jspb.Map.prototype.clear), jspb.Map.prototype.del = function(e) {
                    e = e.toString();
                    var t = this.map_.hasOwnProperty(e);
                    return delete this.map_[e], this.arrClean = !1, t
                }, goog.exportProperty(jspb.Map.prototype, "del", jspb.Map.prototype.del), jspb.Map.prototype.getEntryList = function() {
                    var e = [],
                        t = this.stringKeys_();
                    t.sort();
                    for (var r = 0; r < t.length; r++) {
                        var s = this.map_[t[r]];
                        e.push([s.key, s.value])
                    }
                    return e
                }, goog.exportProperty(jspb.Map.prototype, "getEntryList", jspb.Map.prototype.getEntryList), jspb.Map.prototype.entries = function() {
                    var e = [],
                        t = this.stringKeys_();
                    t.sort();
                    for (var r = 0; r < t.length; r++) {
                        var s = this.map_[t[r]];
                        e.push([s.key, this.wrapEntry_(s)])
                    }
                    return new jspb.Map.ArrayIteratorIterable_(e)
                }, goog.exportProperty(jspb.Map.prototype, "entries", jspb.Map.prototype.entries), jspb.Map.prototype.keys = function() {
                    var e = [],
                        t = this.stringKeys_();
                    t.sort();
                    for (var r = 0; r < t.length; r++) e.push(this.map_[t[r]].key);
                    return new jspb.Map.ArrayIteratorIterable_(e)
                }, goog.exportProperty(jspb.Map.prototype, "keys", jspb.Map.prototype.keys), jspb.Map.prototype.values = function() {
                    var e = [],
                        t = this.stringKeys_();
                    t.sort();
                    for (var r = 0; r < t.length; r++) e.push(this.wrapEntry_(this.map_[t[r]]));
                    return new jspb.Map.ArrayIteratorIterable_(e)
                }, goog.exportProperty(jspb.Map.prototype, "values", jspb.Map.prototype.values), jspb.Map.prototype.forEach = function(e, t) {
                    var r = this.stringKeys_();
                    r.sort();
                    for (var s = 0; s < r.length; s++) {
                        var o = this.map_[r[s]];
                        e.call(t, this.wrapEntry_(o), o.key, this)
                    }
                }, goog.exportProperty(jspb.Map.prototype, "forEach", jspb.Map.prototype.forEach), jspb.Map.prototype.set = function(e, t) {
                    var r = new jspb.Map.Entry_(e);
                    return this.valueCtor_ ? (r.valueWrapper = t, r.value = t.toArray()) : r.value = t, this.map_[e.toString()] = r, this.arrClean = !1, this
                }, goog.exportProperty(jspb.Map.prototype, "set", jspb.Map.prototype.set), jspb.Map.prototype.wrapEntry_ = function(e) {
                    return this.valueCtor_ ? (e.valueWrapper || (e.valueWrapper = new this.valueCtor_(e.value)), e.valueWrapper) : e.value
                }, jspb.Map.prototype.get = function(e) {
                    if (e = this.map_[e.toString()]) return this.wrapEntry_(e)
                }, goog.exportProperty(jspb.Map.prototype, "get", jspb.Map.prototype.get), jspb.Map.prototype.has = function(e) {
                    return e.toString() in this.map_
                }, goog.exportProperty(jspb.Map.prototype, "has", jspb.Map.prototype.has), jspb.Map.deserializeBinary = function(e, t, r, s, o, n, i) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        var a = t.getFieldNumber();
                        1 == a ? n = r.call(t) : 2 == a && (e.valueCtor_ ? (jspb.asserts.assert(o), i || = new e.valueCtor_, s.call(t, i, o)) : i = s.call(t))
                    }
                    jspb.asserts.assert(null != n), jspb.asserts.assert(null != i), e.set(n, i)
                }, goog.exportProperty(jspb.Map, "deserializeBinary", jspb.Map.deserializeBinary), jspb.Map.prototype.stringKeys_ = function() {
                    var e, t = this.map_,
                        r = [];
                    for (e in t) Object.prototype.hasOwnProperty.call(t, e) && r.push(e);
                    return r
                }, jspb.Map.Entry_ = function(e, t) {
                    this.key = e, this.value = t, this.valueWrapper = void 0
                }, goog.async = {}, goog.async.throwException = module$contents$goog$async$throwException_throwException, goog.crypt = {}, goog.crypt.ASYNC_THROW_ON_UNICODE_TO_BYTE = goog.DEBUG, goog.crypt.TEST_ONLY = {}, goog.crypt.TEST_ONLY.throwException = module$contents$goog$async$throwException_throwException, goog.crypt.TEST_ONLY.alwaysThrowSynchronously = goog.DEBUG, goog.crypt.binaryStringToByteArray = function(e) {
                    return goog.crypt.stringToByteArray(e, !0)
                }, goog.crypt.stringToByteArray = function(e, t) {
                    for (var r = [], s = 0, o = 0; o < e.length; o++) {
                        var n = e.charCodeAt(o);
                        if (255 < n) {
                            var i = Error("go/unicode-to-byte-error");
                            if (goog.crypt.TEST_ONLY.alwaysThrowSynchronously || t) throw i;
                            goog.crypt.ASYNC_THROW_ON_UNICODE_TO_BYTE && goog.crypt.TEST_ONLY.throwException(i), r[s++] = 255 & n, n >>= 8
                        }
                        r[s++] = n
                    }
                    return r
                }, goog.crypt.byteArrayToString = function(e) {
                    return goog.crypt.byteArrayToBinaryString(e)
                }, goog.crypt.byteArrayToBinaryString = function(e) {
                    if (8192 >= e.length) return String.fromCharCode.apply(null, e);
                    for (var t = "", r = 0; r < e.length; r += 8192) {
                        var s = Array.prototype.slice.call(e, r, r + 8192);
                        t += String.fromCharCode.apply(null, s)
                    }
                    return t
                }, goog.crypt.byteArrayToHex = function(e, t) {
                    return Array.prototype.map.call(e, function(e) {
                        return 1 < (e = e.toString(16)).length ? e : "0" + e
                    }).join(t || "")
                }, goog.crypt.hexToByteArray = function(e) {
                    goog.asserts.assert(0 == e.length % 2, "Key string length must be multiple of 2");
                    for (var t = [], r = 0; r < e.length; r += 2) t.push(parseInt(e.substring(r, r + 2), 16));
                    return t
                }, goog.crypt.stringToUtf8ByteArray = function(e) {
                    return goog.crypt.textToByteArray(e)
                }, goog.crypt.textToByteArray = function(e) {
                    for (var t = [], r = 0, s = 0; s < e.length; s++) {
                        var o = e.charCodeAt(s);
                        128 > o ? t[r++] = o : (2048 > o ? t[r++] = o >> 6 | 192 : (55296 == (64512 & o) && s + 1 < e.length && 56320 == (64512 & e.charCodeAt(s + 1)) ? (o = 65536 + ((1023 & o) << 10) + (1023 & e.charCodeAt(++s)), t[r++] = o >> 18 | 240, t[r++] = o >> 12 & 63 | 128) : t[r++] = o >> 12 | 224, t[r++] = o >> 6 & 63 | 128), t[r++] = 63 & o | 128)
                    }
                    return t
                }, goog.crypt.utf8ByteArrayToString = function(e) {
                    return goog.crypt.byteArrayToText(e)
                }, goog.crypt.byteArrayToText = function(e) {
                    for (var t = [], r = 0, s = 0; r < e.length;) {
                        var o = e[r++];
                        if (128 > o) t[s++] = String.fromCharCode(o);
                        else if (191 < o && 224 > o) {
                            var n = e[r++];
                            t[s++] = String.fromCharCode((31 & o) << 6 | 63 & n)
                        } else if (239 < o && 365 > o) {
                            n = e[r++];
                            var i = e[r++];
                            o = ((7 & o) << 18 | (63 & n) << 12 | (63 & i) << 6 | 63 & e[r++]) - 65536, t[s++] = String.fromCharCode(55296 + (o >> 10)), t[s++] = String.fromCharCode(56320 + (1023 & o))
                        } else n = e[r++], i = e[r++], t[s++] = String.fromCharCode((15 & o) << 12 | (63 & n) << 6 | 63 & i)
                    }
                    return t.join("")
                }, goog.crypt.xorByteArray = function(e, t) {
                    goog.asserts.assert(e.length == t.length, "XOR array lengths must match");
                    for (var r = [], s = 0; s < e.length; s++) r.push(e[s] ^ t[s]);
                    return r
                }, goog.string = {}, goog.string.internal = {}, goog.string.internal.startsWith = function(e, t) {
                    return 0 == e.lastIndexOf(t, 0)
                }, goog.string.internal.endsWith = function(e, t) {
                    const r = e.length - t.length;
                    return 0 <= r && e.indexOf(t, r) == r
                }, goog.string.internal.caseInsensitiveStartsWith = function(e, t) {
                    return 0 == goog.string.internal.caseInsensitiveCompare(t, e.slice(0, t.length))
                }, goog.string.internal.caseInsensitiveEndsWith = function(e, t) {
                    return 0 == goog.string.internal.caseInsensitiveCompare(t, e.slice(e.length - t.length))
                }, goog.string.internal.caseInsensitiveEquals = function(e, t) {
                    return e.toLowerCase() == t.toLowerCase()
                }, goog.string.internal.isEmptyOrWhitespace = function(e) {
                    return /^[\s\xa0]*$/.test(e)
                }, goog.string.internal.trim = goog.TRUSTED_SITE && String.prototype.trim ? function(e) {
                    return e.trim()
                } : function(e) {
                    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(e)[1]
                }, goog.string.internal.caseInsensitiveCompare = function(e, t) {
                    return (e = String(e).toLowerCase()) < (t = String(t).toLowerCase()) ? -1 : e == t ? 0 : 1
                }, goog.string.internal.newLineToBr = function(e, t) {
                    return e.replace(/(\r\n|\r|\n)/g, t ? "<br />" : "<br>")
                }, goog.string.internal.htmlEscape = function(e, t) {
                    if (t) e = e.replace(goog.string.internal.AMP_RE_, "&amp;").replace(goog.string.internal.LT_RE_, "&lt;").replace(goog.string.internal.GT_RE_, "&gt;").replace(goog.string.internal.QUOT_RE_, "&quot;").replace(goog.string.internal.SINGLE_QUOTE_RE_, "&#39;").replace(goog.string.internal.NULL_RE_, "&#0;");
                    else {
                        if (!goog.string.internal.ALL_RE_.test(e)) return e; - 1 != e.indexOf("&") && (e = e.replace(goog.string.internal.AMP_RE_, "&amp;")), -1 != e.indexOf("<") && (e = e.replace(goog.string.internal.LT_RE_, "&lt;")), -1 != e.indexOf(">") && (e = e.replace(goog.string.internal.GT_RE_, "&gt;")), -1 != e.indexOf('"') && (e = e.replace(goog.string.internal.QUOT_RE_, "&quot;")), -1 != e.indexOf("'") && (e = e.replace(goog.string.internal.SINGLE_QUOTE_RE_, "&#39;")), -1 != e.indexOf("\0") && (e = e.replace(goog.string.internal.NULL_RE_, "&#0;"))
                    }
                    return e
                }, goog.string.internal.AMP_RE_ = /&/g, goog.string.internal.LT_RE_ = /</g, goog.string.internal.GT_RE_ = />/g, goog.string.internal.QUOT_RE_ = /"/g, goog.string.internal.SINGLE_QUOTE_RE_ = /'/g, goog.string.internal.NULL_RE_ = /\x00/g, goog.string.internal.ALL_RE_ = /[\x00&<>"']/, goog.string.internal.whitespaceEscape = function(e, t) {
                    return goog.string.internal.newLineToBr(e.replace(/  /g, " &#160;"), t)
                }, goog.string.internal.contains = function(e, t) {
                    return -1 != e.indexOf(t)
                }, goog.string.internal.caseInsensitiveContains = function(e, t) {
                    return goog.string.internal.contains(e.toLowerCase(), t.toLowerCase())
                }, goog.string.internal.compareVersions = function(e, t) {
                    var r = 0;
                    e = goog.string.internal.trim(String(e)).split("."), t = goog.string.internal.trim(String(t)).split(".");
                    const s = Math.max(e.length, t.length);
                    for (let i = 0; 0 == r && i < s; i++) {
                        var o = e[i] || "",
                            n = t[i] || "";
                        do {
                            if (o = /(\d*)(\D*)(.*)/.exec(o) || ["", "", "", ""], n = /(\d*)(\D*)(.*)/.exec(n) || ["", "", "", ""], 0 == o[0].length && 0 == n[0].length) break;
                            r = 0 == o[1].length ? 0 : parseInt(o[1], 10);
                            const e = 0 == n[1].length ? 0 : parseInt(n[1], 10);
                            r = goog.string.internal.compareElements_(r, e) || goog.string.internal.compareElements_(0 == o[2].length, 0 == n[2].length) || goog.string.internal.compareElements_(o[2], n[2]), o = o[3], n = n[3]
                        } while (0 == r)
                    }
                    return r
                }, goog.string.internal.compareElements_ = function(e, t) {
                    return e < t ? -1 : e > t ? 1 : 0
                }, goog.flags = {}, goog.flags.USE_USER_AGENT_CLIENT_HINTS = !1, goog.flags.ASYNC_THROW_ON_UNICODE_TO_BYTE = !1, goog.labs = {}, goog.labs.userAgent = {};
                const module$contents$goog$labs$userAgent_USE_CLIENT_HINTS_OVERRIDE = "",
                    module$contents$goog$labs$userAgent_USE_CLIENT_HINTS = !1;
                let module$contents$goog$labs$userAgent_forceClientHintsInTests = !1;
                goog.labs.userAgent.setUseClientHintsForTesting = e => {
                    module$contents$goog$labs$userAgent_forceClientHintsInTests = e
                };
                const module$contents$goog$labs$userAgent_useClientHintsRuntimeOverride = !!module$contents$goog$labs$userAgent_USE_CLIENT_HINTS_OVERRIDE && !!goog.getObjectByName(module$contents$goog$labs$userAgent_USE_CLIENT_HINTS_OVERRIDE);
                goog.labs.userAgent.useClientHints = () => goog.flags.USE_USER_AGENT_CLIENT_HINTS || module$contents$goog$labs$userAgent_USE_CLIENT_HINTS || module$contents$goog$labs$userAgent_useClientHintsRuntimeOverride || module$contents$goog$labs$userAgent_forceClientHintsInTests, goog.labs.userAgent.util = {};
                const module$contents$goog$labs$userAgent$util_ASSUME_CLIENT_HINTS_SUPPORT = !1;

                function module$contents$goog$labs$userAgent$util_getNativeUserAgentString() {
                    var e = module$contents$goog$labs$userAgent$util_getNavigator();
                    return e && (e = e.userAgent) ? e : ""
                }

                function module$contents$goog$labs$userAgent$util_getNativeUserAgentData() {
                    const e = module$contents$goog$labs$userAgent$util_getNavigator();
                    return e && e.userAgentData || null
                }

                function module$contents$goog$labs$userAgent$util_getNavigator() {
                    return goog.global.navigator
                }
                let module$contents$goog$labs$userAgent$util_userAgentInternal = null,
                    module$contents$goog$labs$userAgent$util_userAgentDataInternal = module$contents$goog$labs$userAgent$util_getNativeUserAgentData();

                function module$contents$goog$labs$userAgent$util_setUserAgent(e) {
                    module$contents$goog$labs$userAgent$util_userAgentInternal = "string" == typeof e ? e : module$contents$goog$labs$userAgent$util_getNativeUserAgentString()
                }

                function module$contents$goog$labs$userAgent$util_getUserAgent() {
                    return null == module$contents$goog$labs$userAgent$util_userAgentInternal ? module$contents$goog$labs$userAgent$util_getNativeUserAgentString() : module$contents$goog$labs$userAgent$util_userAgentInternal
                }

                function module$contents$goog$labs$userAgent$util_setUserAgentData(e) {
                    module$contents$goog$labs$userAgent$util_userAgentDataInternal = e
                }

                function module$contents$goog$labs$userAgent$util_resetUserAgentData() {
                    module$contents$goog$labs$userAgent$util_userAgentDataInternal = module$contents$goog$labs$userAgent$util_getNativeUserAgentData()
                }

                function module$contents$goog$labs$userAgent$util_getUserAgentData() {
                    return module$contents$goog$labs$userAgent$util_userAgentDataInternal
                }

                function module$contents$goog$labs$userAgent$util_matchUserAgentDataBrand(e) {
                    if (!(0, goog.labs.userAgent.useClientHints)()) return !1;
                    const t = module$contents$goog$labs$userAgent$util_getUserAgentData();
                    return !!t && t.brands.some(({
                        brand: t
                    }) => t && (0, goog.string.internal.contains)(t, e))
                }

                function module$contents$goog$labs$userAgent$util_matchUserAgent(e) {
                    const t = module$contents$goog$labs$userAgent$util_getUserAgent();
                    return (0, goog.string.internal.contains)(t, e)
                }

                function module$contents$goog$labs$userAgent$util_matchUserAgentIgnoreCase(e) {
                    const t = module$contents$goog$labs$userAgent$util_getUserAgent();
                    return (0, goog.string.internal.caseInsensitiveContains)(t, e)
                }

                function module$contents$goog$labs$userAgent$util_extractVersionTuples(e) {
                    const t = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"),
                        r = [];
                    let s;
                    for (; s = t.exec(e);) r.push([s[1], s[2], s[3] || void 0]);
                    return r
                }
                goog.labs.userAgent.util.ASSUME_CLIENT_HINTS_SUPPORT = module$contents$goog$labs$userAgent$util_ASSUME_CLIENT_HINTS_SUPPORT, goog.labs.userAgent.util.extractVersionTuples = module$contents$goog$labs$userAgent$util_extractVersionTuples, goog.labs.userAgent.util.getNativeUserAgentString = module$contents$goog$labs$userAgent$util_getNativeUserAgentString, goog.labs.userAgent.util.getUserAgent = module$contents$goog$labs$userAgent$util_getUserAgent, goog.labs.userAgent.util.getUserAgentData = module$contents$goog$labs$userAgent$util_getUserAgentData, goog.labs.userAgent.util.matchUserAgent = module$contents$goog$labs$userAgent$util_matchUserAgent, goog.labs.userAgent.util.matchUserAgentDataBrand = module$contents$goog$labs$userAgent$util_matchUserAgentDataBrand, goog.labs.userAgent.util.matchUserAgentIgnoreCase = module$contents$goog$labs$userAgent$util_matchUserAgentIgnoreCase, goog.labs.userAgent.util.resetUserAgentData = module$contents$goog$labs$userAgent$util_resetUserAgentData, goog.labs.userAgent.util.setUserAgent = module$contents$goog$labs$userAgent$util_setUserAgent, goog.labs.userAgent.util.setUserAgentData = module$contents$goog$labs$userAgent$util_setUserAgentData;
                var module$exports$goog$labs$userAgent$highEntropy$highEntropyValue = {
                        AsyncValue: class {
                            getIfLoaded() {}
                            load() {}
                        },
                        HighEntropyValue: class {
                            constructor(e) {
                                this.key_ = e, this.promise_ = this.value_ = void 0, this.pending_ = !1
                            }
                            getIfLoaded() {
                                if (module$contents$goog$labs$userAgent$util_getUserAgentData()) return this.value_
                            }
                            async load() {
                                const e = module$contents$goog$labs$userAgent$util_getUserAgentData();
                                if (e) return this.promise_ || (this.pending_ = !0, this.promise_ = (async () => {
                                    try {
                                        return this.value_ = (await e.getHighEntropyValues([this.key_]))[this.key_]
                                    } finally {
                                        this.pending_ = !1
                                    }
                                })()), await this.promise_
                            }
                            resetForTesting() {
                                if (this.pending_) throw Error("Unsafe call to resetForTesting");
                                this.value_ = this.promise_ = void 0, this.pending_ = !1
                            }
                        },
                        Version: class {
                            constructor(e) {
                                this.versionString_ = e
                            }
                            toVersionStringForLogging() {
                                return this.versionString_
                            }
                            isAtLeast(e) {
                                return 0 <= (0, goog.string.internal.compareVersions)(this.versionString_, e)
                            }
                        }
                    },
                    module$exports$goog$labs$userAgent$highEntropy$highEntropyData = {};
                module$exports$goog$labs$userAgent$highEntropy$highEntropyData.fullVersionList = new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.HighEntropyValue("fullVersionList"), module$exports$goog$labs$userAgent$highEntropy$highEntropyData.platformVersion = new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.HighEntropyValue("platformVersion"), goog.labs.userAgent.browser = {};
                const module$contents$goog$labs$userAgent$browser_Brand = {
                    ANDROID_BROWSER: "Android Browser",
                    CHROMIUM: "Chromium",
                    EDGE: "Microsoft Edge",
                    FIREFOX: "Firefox",
                    IE: "Internet Explorer",
                    OPERA: "Opera",
                    SAFARI: "Safari",
                    SILK: "Silk"
                };

                function module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand(e = !1) {
                    return !!module$contents$goog$labs$userAgent$util_ASSUME_CLIENT_HINTS_SUPPORT || !(!e && !(0, goog.labs.userAgent.useClientHints)()) && (!!(e = module$contents$goog$labs$userAgent$util_getUserAgentData()) && 0 < e.brands.length)
                }

                function module$contents$goog$labs$userAgent$browser_hasFullVersionList() {
                    return module$contents$goog$labs$userAgent$browser_isAtLeast(module$contents$goog$labs$userAgent$browser_Brand.CHROMIUM, 98)
                }

                function module$contents$goog$labs$userAgent$browser_matchOpera() {
                    return !module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() && module$contents$goog$labs$userAgent$util_matchUserAgent("Opera")
                }

                function module$contents$goog$labs$userAgent$browser_matchIE() {
                    return !module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() && (module$contents$goog$labs$userAgent$util_matchUserAgent("Trident") || module$contents$goog$labs$userAgent$util_matchUserAgent("MSIE"))
                }

                function module$contents$goog$labs$userAgent$browser_matchEdgeHtml() {
                    return !module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() && module$contents$goog$labs$userAgent$util_matchUserAgent("Edge")
                }

                function module$contents$goog$labs$userAgent$browser_matchEdgeChromium() {
                    return module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() ? module$contents$goog$labs$userAgent$util_matchUserAgentDataBrand(module$contents$goog$labs$userAgent$browser_Brand.EDGE) : module$contents$goog$labs$userAgent$util_matchUserAgent("Edg/")
                }

                function module$contents$goog$labs$userAgent$browser_matchOperaChromium() {
                    return module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() ? module$contents$goog$labs$userAgent$util_matchUserAgentDataBrand(module$contents$goog$labs$userAgent$browser_Brand.OPERA) : module$contents$goog$labs$userAgent$util_matchUserAgent("OPR")
                }

                function module$contents$goog$labs$userAgent$browser_matchFirefox() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Firefox") || module$contents$goog$labs$userAgent$util_matchUserAgent("FxiOS")
                }

                function module$contents$goog$labs$userAgent$browser_matchSafari() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Safari") && !(module$contents$goog$labs$userAgent$browser_matchChrome() || module$contents$goog$labs$userAgent$browser_matchCoast() || module$contents$goog$labs$userAgent$browser_matchOpera() || module$contents$goog$labs$userAgent$browser_matchEdgeHtml() || module$contents$goog$labs$userAgent$browser_matchEdgeChromium() || module$contents$goog$labs$userAgent$browser_matchOperaChromium() || module$contents$goog$labs$userAgent$browser_matchFirefox() || module$contents$goog$labs$userAgent$browser_isSilk() || module$contents$goog$labs$userAgent$util_matchUserAgent("Android"))
                }

                function module$contents$goog$labs$userAgent$browser_matchCoast() {
                    return !module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() && module$contents$goog$labs$userAgent$util_matchUserAgent("Coast")
                }

                function module$contents$goog$labs$userAgent$browser_matchIosWebview() {
                    return (module$contents$goog$labs$userAgent$util_matchUserAgent("iPad") || module$contents$goog$labs$userAgent$util_matchUserAgent("iPhone")) && !module$contents$goog$labs$userAgent$browser_matchSafari() && !module$contents$goog$labs$userAgent$browser_matchChrome() && !module$contents$goog$labs$userAgent$browser_matchCoast() && !module$contents$goog$labs$userAgent$browser_matchFirefox() && module$contents$goog$labs$userAgent$util_matchUserAgent("AppleWebKit")
                }

                function module$contents$goog$labs$userAgent$browser_matchChrome() {
                    return module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() ? module$contents$goog$labs$userAgent$util_matchUserAgentDataBrand(module$contents$goog$labs$userAgent$browser_Brand.CHROMIUM) : (module$contents$goog$labs$userAgent$util_matchUserAgent("Chrome") || module$contents$goog$labs$userAgent$util_matchUserAgent("CriOS")) && !module$contents$goog$labs$userAgent$browser_matchEdgeHtml() || module$contents$goog$labs$userAgent$browser_isSilk()
                }

                function module$contents$goog$labs$userAgent$browser_matchAndroidBrowser() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Android") && !(module$contents$goog$labs$userAgent$browser_matchChrome() || module$contents$goog$labs$userAgent$browser_matchFirefox() || module$contents$goog$labs$userAgent$browser_matchOpera() || module$contents$goog$labs$userAgent$browser_isSilk())
                }
                goog.labs.userAgent.browser.Brand = module$contents$goog$labs$userAgent$browser_Brand;
                const module$contents$goog$labs$userAgent$browser_isOpera = module$contents$goog$labs$userAgent$browser_matchOpera;
                goog.labs.userAgent.browser.isOpera = module$contents$goog$labs$userAgent$browser_matchOpera;
                const module$contents$goog$labs$userAgent$browser_isIE = module$contents$goog$labs$userAgent$browser_matchIE;
                goog.labs.userAgent.browser.isIE = module$contents$goog$labs$userAgent$browser_matchIE;
                const module$contents$goog$labs$userAgent$browser_isEdge = module$contents$goog$labs$userAgent$browser_matchEdgeHtml;
                goog.labs.userAgent.browser.isEdge = module$contents$goog$labs$userAgent$browser_matchEdgeHtml;
                const module$contents$goog$labs$userAgent$browser_isEdgeChromium = module$contents$goog$labs$userAgent$browser_matchEdgeChromium;
                goog.labs.userAgent.browser.isEdgeChromium = module$contents$goog$labs$userAgent$browser_matchEdgeChromium;
                const module$contents$goog$labs$userAgent$browser_isOperaChromium = module$contents$goog$labs$userAgent$browser_matchOperaChromium;
                goog.labs.userAgent.browser.isOperaChromium = module$contents$goog$labs$userAgent$browser_matchOperaChromium;
                const module$contents$goog$labs$userAgent$browser_isFirefox = module$contents$goog$labs$userAgent$browser_matchFirefox;
                goog.labs.userAgent.browser.isFirefox = module$contents$goog$labs$userAgent$browser_matchFirefox;
                const module$contents$goog$labs$userAgent$browser_isSafari = module$contents$goog$labs$userAgent$browser_matchSafari;
                goog.labs.userAgent.browser.isSafari = module$contents$goog$labs$userAgent$browser_matchSafari;
                const module$contents$goog$labs$userAgent$browser_isCoast = module$contents$goog$labs$userAgent$browser_matchCoast;
                goog.labs.userAgent.browser.isCoast = module$contents$goog$labs$userAgent$browser_matchCoast;
                const module$contents$goog$labs$userAgent$browser_isIosWebview = module$contents$goog$labs$userAgent$browser_matchIosWebview;
                goog.labs.userAgent.browser.isIosWebview = module$contents$goog$labs$userAgent$browser_matchIosWebview;
                const module$contents$goog$labs$userAgent$browser_isChrome = module$contents$goog$labs$userAgent$browser_matchChrome;
                goog.labs.userAgent.browser.isChrome = module$contents$goog$labs$userAgent$browser_matchChrome;
                const module$contents$goog$labs$userAgent$browser_isAndroidBrowser = module$contents$goog$labs$userAgent$browser_matchAndroidBrowser;

                function module$contents$goog$labs$userAgent$browser_isSilk() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Silk")
                }

                function module$contents$goog$labs$userAgent$browser_createVersionMap(e) {
                    const t = {};
                    return e.forEach(e => {
                        t[e[0]] = e[1]
                    }), e => t[e.find(e => e in t)] || ""
                }

                function module$contents$goog$labs$userAgent$browser_getVersion() {
                    var e = module$contents$goog$labs$userAgent$util_getUserAgent();
                    if (module$contents$goog$labs$userAgent$browser_matchIE()) return module$contents$goog$labs$userAgent$browser_getIEVersion(e);
                    const t = module$contents$goog$labs$userAgent$browser_createVersionMap(e = module$contents$goog$labs$userAgent$util_extractVersionTuples(e));
                    return module$contents$goog$labs$userAgent$browser_matchOpera() ? t(["Version", "Opera"]) : module$contents$goog$labs$userAgent$browser_matchEdgeHtml() ? t(["Edge"]) : module$contents$goog$labs$userAgent$browser_matchEdgeChromium() ? t(["Edg"]) : module$contents$goog$labs$userAgent$browser_isSilk() ? t(["Silk"]) : module$contents$goog$labs$userAgent$browser_matchChrome() ? t(["Chrome", "CriOS", "HeadlessChrome"]) : (e = e[2]) && e[1] || ""
                }

                function module$contents$goog$labs$userAgent$browser_isVersionOrHigher(e) {
                    return 0 <= (0, goog.string.internal.compareVersions)(module$contents$goog$labs$userAgent$browser_getVersion(), e)
                }

                function module$contents$goog$labs$userAgent$browser_getIEVersion(e) {
                    var t = /rv: *([\d\.]*)/.exec(e);
                    if (t && t[1]) return t[1];
                    t = "";
                    const r = /MSIE +([\d\.]+)/.exec(e);
                    if (r && r[1])
                        if (e = /Trident\/(\d.\d)/.exec(e), "7.0" == r[1])
                            if (e && e[1]) switch (e[1]) {
                                case "4.0":
                                    t = "8.0";
                                    break;
                                case "5.0":
                                    t = "9.0";
                                    break;
                                case "6.0":
                                    t = "10.0";
                                    break;
                                case "7.0":
                                    t = "11.0"
                            } else t = "7.0";
                            else t = r[1];
                    return t
                }

                function module$contents$goog$labs$userAgent$browser_getFullVersionFromUserAgentString(e) {
                    var t = module$contents$goog$labs$userAgent$util_getUserAgent();
                    if (e === module$contents$goog$labs$userAgent$browser_Brand.IE) return module$contents$goog$labs$userAgent$browser_matchIE() ? module$contents$goog$labs$userAgent$browser_getIEVersion(t) : "";
                    const r = module$contents$goog$labs$userAgent$browser_createVersionMap(t = module$contents$goog$labs$userAgent$util_extractVersionTuples(t));
                    switch (e) {
                        case module$contents$goog$labs$userAgent$browser_Brand.OPERA:
                            if (module$contents$goog$labs$userAgent$browser_matchOpera()) return r(["Version", "Opera"]);
                            if (module$contents$goog$labs$userAgent$browser_matchOperaChromium()) return r(["OPR"]);
                            break;
                        case module$contents$goog$labs$userAgent$browser_Brand.EDGE:
                            if (module$contents$goog$labs$userAgent$browser_matchEdgeHtml()) return r(["Edge"]);
                            if (module$contents$goog$labs$userAgent$browser_matchEdgeChromium()) return r(["Edg"]);
                            break;
                        case module$contents$goog$labs$userAgent$browser_Brand.CHROMIUM:
                            if (module$contents$goog$labs$userAgent$browser_matchChrome()) return r(["Chrome", "CriOS", "HeadlessChrome"])
                    }
                    return (e === module$contents$goog$labs$userAgent$browser_Brand.FIREFOX && module$contents$goog$labs$userAgent$browser_matchFirefox() || e === module$contents$goog$labs$userAgent$browser_Brand.SAFARI && module$contents$goog$labs$userAgent$browser_matchSafari() || e === module$contents$goog$labs$userAgent$browser_Brand.ANDROID_BROWSER && module$contents$goog$labs$userAgent$browser_matchAndroidBrowser() || e === module$contents$goog$labs$userAgent$browser_Brand.SILK && module$contents$goog$labs$userAgent$browser_isSilk()) && (e = t[2]) && e[1] || ""
                }

                function module$contents$goog$labs$userAgent$browser_versionOf_(e) {
                    if (module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand() && e !== module$contents$goog$labs$userAgent$browser_Brand.SILK) {
                        var t = module$contents$goog$labs$userAgent$util_getUserAgentData().brands.find(({
                            brand: t
                        }) => t === e);
                        if (!t || !t.version) return NaN;
                        t = t.version.split(".")
                    } else {
                        if ("" === (t = module$contents$goog$labs$userAgent$browser_getFullVersionFromUserAgentString(e))) return NaN;
                        t = t.split(".")
                    }
                    return 0 === t.length ? NaN : Number(t[0])
                }

                function module$contents$goog$labs$userAgent$browser_isAtLeast(e, t) {
                    return (0, goog.asserts.assert)(Math.floor(t) === t, "Major version must be an integer"), module$contents$goog$labs$userAgent$browser_versionOf_(e) >= t
                }

                function module$contents$goog$labs$userAgent$browser_isAtMost(e, t) {
                    return (0, goog.asserts.assert)(Math.floor(t) === t, "Major version must be an integer"), module$contents$goog$labs$userAgent$browser_versionOf_(e) <= t
                }
                goog.labs.userAgent.browser.isAndroidBrowser = module$contents$goog$labs$userAgent$browser_matchAndroidBrowser, goog.labs.userAgent.browser.isSilk = module$contents$goog$labs$userAgent$browser_isSilk, goog.labs.userAgent.browser.getVersion = module$contents$goog$labs$userAgent$browser_getVersion, goog.labs.userAgent.browser.isVersionOrHigher = module$contents$goog$labs$userAgent$browser_isVersionOrHigher, goog.labs.userAgent.browser.isAtLeast = module$contents$goog$labs$userAgent$browser_isAtLeast, goog.labs.userAgent.browser.isAtMost = module$contents$goog$labs$userAgent$browser_isAtMost;
                class module$contents$goog$labs$userAgent$browser_HighEntropyBrandVersion {
                    constructor(e, t, r) {
                        this.brand_ = e, this.version_ = new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(r), this.useUach_ = t
                    }
                    getIfLoaded() {
                        if (this.useUach_) {
                            var e = module$exports$goog$labs$userAgent$highEntropy$highEntropyData.fullVersionList.getIfLoaded();
                            if (void 0 !== e) return e = e.find(({
                                brand: e
                            }) => this.brand_ === e), (0, goog.asserts.assertExists)(e), new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(e.version)
                        }
                        if (module$contents$goog$labs$userAgent$browser_preUachHasLoaded) return this.version_
                    }
                    async load() {
                        if (this.useUach_) {
                            var e = await module$exports$goog$labs$userAgent$highEntropy$highEntropyData.fullVersionList.load();
                            if (void 0 !== e) return e = e.find(({
                                brand: e
                            }) => this.brand_ === e), (0, goog.asserts.assertExists)(e), new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(e.version)
                        } else await 0;
                        return module$contents$goog$labs$userAgent$browser_preUachHasLoaded = !0, this.version_
                    }
                }
                let module$contents$goog$labs$userAgent$browser_preUachHasLoaded = !1;
                async function module$contents$goog$labs$userAgent$browser_loadFullVersions() {
                    module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand(!0) && await module$exports$goog$labs$userAgent$highEntropy$highEntropyData.fullVersionList.load(), module$contents$goog$labs$userAgent$browser_preUachHasLoaded = !0
                }

                function module$contents$goog$labs$userAgent$browser_fullVersionOf(e) {
                    let t = "";
                    module$contents$goog$labs$userAgent$browser_hasFullVersionList() || (t = module$contents$goog$labs$userAgent$browser_getFullVersionFromUserAgentString(e));
                    const r = e !== module$contents$goog$labs$userAgent$browser_Brand.SILK && module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand(!0);
                    if (r) {
                        if (!module$contents$goog$labs$userAgent$util_getUserAgentData().brands.find(({
                                brand: t
                            }) => t === e)) return
                    } else if ("" === t) return;
                    return new module$contents$goog$labs$userAgent$browser_HighEntropyBrandVersion(e, r, t)
                }

                function module$contents$goog$labs$userAgent$browser_getVersionStringForLogging(e) {
                    if (module$contents$goog$labs$userAgent$browser_useUserAgentDataBrand(!0)) {
                        var t = module$contents$goog$labs$userAgent$browser_fullVersionOf(e);
                        return t ? (t = t.getIfLoaded()) ? t.toVersionStringForLogging() : (t = module$contents$goog$labs$userAgent$util_getUserAgentData().brands.find(({
                            brand: t
                        }) => t === e), (0, goog.asserts.assertExists)(t), t.version) : ""
                    }
                    return module$contents$goog$labs$userAgent$browser_getFullVersionFromUserAgentString(e)
                }

                function module$contents$goog$labs$userAgent$engine_isPresto() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Presto")
                }

                function module$contents$goog$labs$userAgent$engine_isTrident() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Trident") || module$contents$goog$labs$userAgent$util_matchUserAgent("MSIE")
                }

                function module$contents$goog$labs$userAgent$engine_isEdge() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Edge")
                }

                function module$contents$goog$labs$userAgent$engine_isWebKit() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgentIgnoreCase("WebKit") && !module$contents$goog$labs$userAgent$engine_isEdge()
                }

                function module$contents$goog$labs$userAgent$engine_isGecko() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("Gecko") && !module$contents$goog$labs$userAgent$engine_isWebKit() && !module$contents$goog$labs$userAgent$engine_isTrident() && !module$contents$goog$labs$userAgent$engine_isEdge()
                }

                function module$contents$goog$labs$userAgent$engine_getVersion() {
                    var e = module$contents$goog$labs$userAgent$util_getUserAgent();
                    if (e) {
                        const r = module$contents$goog$labs$userAgent$engine_getEngineTuple(e = module$contents$goog$labs$userAgent$util_extractVersionTuples(e));
                        if (r) return "Gecko" == r[0] ? module$contents$goog$labs$userAgent$engine_getVersionForKey(e, "Firefox") : r[1];
                        var t;
                        if ((e = e[0]) && (t = e[2]) && (t = /Trident\/([^\s;]+)/.exec(t))) return t[1]
                    }
                    return ""
                }

                function module$contents$goog$labs$userAgent$engine_getEngineTuple(e) {
                    if (!module$contents$goog$labs$userAgent$engine_isEdge()) return e[1];
                    for (let t = 0; t < e.length; t++) {
                        const r = e[t];
                        if ("Edge" == r[0]) return r
                    }
                }

                function module$contents$goog$labs$userAgent$engine_isVersionOrHigher(e) {
                    return 0 <= goog.string.internal.compareVersions(module$contents$goog$labs$userAgent$engine_getVersion(), e)
                }

                function module$contents$goog$labs$userAgent$engine_getVersionForKey(e, t) {
                    return (e = module$contents$goog$array_find(e, function(e) {
                        return t == e[0]
                    })) && e[1] || ""
                }

                function module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform(e = !1) {
                    return !!module$contents$goog$labs$userAgent$util_ASSUME_CLIENT_HINTS_SUPPORT || !(!e && !(0, goog.labs.userAgent.useClientHints)()) && (!!(e = module$contents$goog$labs$userAgent$util_getUserAgentData()) && !!e.platform)
                }

                function module$contents$goog$labs$userAgent$platform_isAndroid() {
                    return module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform() ? "Android" === module$contents$goog$labs$userAgent$util_getUserAgentData().platform : module$contents$goog$labs$userAgent$util_matchUserAgent("Android")
                }

                function module$contents$goog$labs$userAgent$platform_isIpod() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("iPod")
                }

                function module$contents$goog$labs$userAgent$platform_isIphone() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("iPhone") && !module$contents$goog$labs$userAgent$util_matchUserAgent("iPod") && !module$contents$goog$labs$userAgent$util_matchUserAgent("iPad")
                }

                function module$contents$goog$labs$userAgent$platform_isIpad() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("iPad")
                }

                function module$contents$goog$labs$userAgent$platform_isIos() {
                    return module$contents$goog$labs$userAgent$platform_isIphone() || module$contents$goog$labs$userAgent$platform_isIpad() || module$contents$goog$labs$userAgent$platform_isIpod()
                }

                function module$contents$goog$labs$userAgent$platform_isMacintosh() {
                    return module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform() ? "macOS" === module$contents$goog$labs$userAgent$util_getUserAgentData().platform : module$contents$goog$labs$userAgent$util_matchUserAgent("Macintosh")
                }

                function module$contents$goog$labs$userAgent$platform_isLinux() {
                    return module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform() ? "Linux" === module$contents$goog$labs$userAgent$util_getUserAgentData().platform : module$contents$goog$labs$userAgent$util_matchUserAgent("Linux")
                }

                function module$contents$goog$labs$userAgent$platform_isWindows() {
                    return module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform() ? "Windows" === module$contents$goog$labs$userAgent$util_getUserAgentData().platform : module$contents$goog$labs$userAgent$util_matchUserAgent("Windows")
                }

                function module$contents$goog$labs$userAgent$platform_isChromeOS() {
                    return module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform() ? "Chrome OS" === module$contents$goog$labs$userAgent$util_getUserAgentData().platform : module$contents$goog$labs$userAgent$util_matchUserAgent("CrOS")
                }

                function module$contents$goog$labs$userAgent$platform_isChromecast() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgent("CrKey")
                }

                function module$contents$goog$labs$userAgent$platform_isKaiOS() {
                    return module$contents$goog$labs$userAgent$util_matchUserAgentIgnoreCase("KaiOS")
                }

                function module$contents$goog$labs$userAgent$platform_getVersion() {
                    var e = module$contents$goog$labs$userAgent$util_getUserAgent(),
                        t = "";
                    return module$contents$goog$labs$userAgent$platform_isWindows() ? t = (e = (t = /Windows (?:NT|Phone) ([0-9.]+)/).exec(e)) ? e[1] : "0.0" : module$contents$goog$labs$userAgent$platform_isIos() ? t = (e = (t = /(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/).exec(e)) && e[1].replace(/_/g, ".") : module$contents$goog$labs$userAgent$platform_isMacintosh() ? t = (e = (t = /Mac OS X ([0-9_.]+)/).exec(e)) ? e[1].replace(/_/g, ".") : "10" : module$contents$goog$labs$userAgent$platform_isKaiOS() ? t = (e = (t = /(?:KaiOS)\/(\S+)/i).exec(e)) && e[1] : module$contents$goog$labs$userAgent$platform_isAndroid() ? t = (e = (t = /Android\s+([^\);]+)(\)|;)/).exec(e)) && e[1] : module$contents$goog$labs$userAgent$platform_isChromeOS() && (t = (e = (t = /(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/).exec(e)) && e[1]), t || ""
                }

                function module$contents$goog$labs$userAgent$platform_isVersionOrHigher(e) {
                    return 0 <= goog.string.internal.compareVersions(module$contents$goog$labs$userAgent$platform_getVersion(), e)
                }
                goog.labs.userAgent.browser.loadFullVersions = module$contents$goog$labs$userAgent$browser_loadFullVersions, goog.labs.userAgent.browser.resetForTesting = () => {
                    module$contents$goog$labs$userAgent$browser_preUachHasLoaded = !1, module$exports$goog$labs$userAgent$highEntropy$highEntropyData.fullVersionList.resetForTesting()
                }, goog.labs.userAgent.browser.fullVersionOf = module$contents$goog$labs$userAgent$browser_fullVersionOf, goog.labs.userAgent.browser.getVersionStringForLogging = module$contents$goog$labs$userAgent$browser_getVersionStringForLogging, goog.labs.userAgent.engine = {}, goog.labs.userAgent.engine.getVersion = module$contents$goog$labs$userAgent$engine_getVersion, goog.labs.userAgent.engine.isEdge = module$contents$goog$labs$userAgent$engine_isEdge, goog.labs.userAgent.engine.isGecko = module$contents$goog$labs$userAgent$engine_isGecko, goog.labs.userAgent.engine.isPresto = module$contents$goog$labs$userAgent$engine_isPresto, goog.labs.userAgent.engine.isTrident = module$contents$goog$labs$userAgent$engine_isTrident, goog.labs.userAgent.engine.isVersionOrHigher = module$contents$goog$labs$userAgent$engine_isVersionOrHigher, goog.labs.userAgent.engine.isWebKit = module$contents$goog$labs$userAgent$engine_isWebKit, goog.labs.userAgent.platform = {};
                class module$contents$goog$labs$userAgent$platform_PlatformVersion {
                    constructor() {
                        this.preUachHasLoaded_ = !1
                    }
                    getIfLoaded() {
                        if (module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform(!0)) {
                            const e = module$exports$goog$labs$userAgent$highEntropy$highEntropyData.platformVersion.getIfLoaded();
                            return void 0 === e ? void 0 : new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(e)
                        }
                        if (this.preUachHasLoaded_) return new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(module$contents$goog$labs$userAgent$platform_getVersion())
                    }
                    async load() {
                        return module$contents$goog$labs$userAgent$platform_useUserAgentDataPlatform(!0) ? new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(await module$exports$goog$labs$userAgent$highEntropy$highEntropyData.platformVersion.load()) : (this.preUachHasLoaded_ = !0, new module$exports$goog$labs$userAgent$highEntropy$highEntropyValue.Version(module$contents$goog$labs$userAgent$platform_getVersion()))
                    }
                    resetForTesting() {
                        module$exports$goog$labs$userAgent$highEntropy$highEntropyData.platformVersion.resetForTesting(), this.preUachHasLoaded_ = !1
                    }
                }
                const module$contents$goog$labs$userAgent$platform_version = new module$contents$goog$labs$userAgent$platform_PlatformVersion;
                goog.labs.userAgent.platform.getVersion = module$contents$goog$labs$userAgent$platform_getVersion, goog.labs.userAgent.platform.isAndroid = module$contents$goog$labs$userAgent$platform_isAndroid, goog.labs.userAgent.platform.isChromeOS = module$contents$goog$labs$userAgent$platform_isChromeOS, goog.labs.userAgent.platform.isChromecast = module$contents$goog$labs$userAgent$platform_isChromecast, goog.labs.userAgent.platform.isIos = module$contents$goog$labs$userAgent$platform_isIos, goog.labs.userAgent.platform.isIpad = module$contents$goog$labs$userAgent$platform_isIpad, goog.labs.userAgent.platform.isIphone = module$contents$goog$labs$userAgent$platform_isIphone, goog.labs.userAgent.platform.isIpod = module$contents$goog$labs$userAgent$platform_isIpod, goog.labs.userAgent.platform.isKaiOS = module$contents$goog$labs$userAgent$platform_isKaiOS, goog.labs.userAgent.platform.isLinux = module$contents$goog$labs$userAgent$platform_isLinux, goog.labs.userAgent.platform.isMacintosh = module$contents$goog$labs$userAgent$platform_isMacintosh, goog.labs.userAgent.platform.isVersionOrHigher = module$contents$goog$labs$userAgent$platform_isVersionOrHigher, goog.labs.userAgent.platform.isWindows = module$contents$goog$labs$userAgent$platform_isWindows, goog.labs.userAgent.platform.version = module$contents$goog$labs$userAgent$platform_version, goog.reflect = {}, goog.reflect.object = function(e, t) {
                    return t
                }, goog.reflect.objectProperty = function(e, t) {
                    return e
                }, goog.reflect.sinkValue = function(e) {
                    return goog.reflect.sinkValue[" "](e), e
                }, goog.reflect.sinkValue[" "] = function() {}, goog.reflect.canAccessProperty = function(e, t) {
                    try {
                        return goog.reflect.sinkValue(e[t]), !0
                    } catch (e) {}
                    return !1
                }, goog.reflect.cache = function(e, t, r, s) {
                    return s = s ? s(t) : t, Object.prototype.hasOwnProperty.call(e, s) ? e[s] : e[s] = r(t)
                }, goog.userAgent = {}, goog.userAgent.ASSUME_IE = !1, goog.userAgent.ASSUME_EDGE = !1, goog.userAgent.ASSUME_GECKO = !1, goog.userAgent.ASSUME_WEBKIT = !1, goog.userAgent.ASSUME_MOBILE_WEBKIT = !1, goog.userAgent.ASSUME_OPERA = !1, goog.userAgent.ASSUME_ANY_VERSION = !1, goog.userAgent.BROWSER_KNOWN_ = goog.userAgent.ASSUME_IE || goog.userAgent.ASSUME_EDGE || goog.userAgent.ASSUME_GECKO || goog.userAgent.ASSUME_MOBILE_WEBKIT || goog.userAgent.ASSUME_WEBKIT || goog.userAgent.ASSUME_OPERA, goog.userAgent.getUserAgentString = function() {
                    return module$contents$goog$labs$userAgent$util_getUserAgent()
                }, goog.userAgent.getNavigatorTyped = function() {
                    return goog.global.navigator || null
                }, goog.userAgent.getNavigator = function() {
                    return goog.userAgent.getNavigatorTyped()
                }, goog.userAgent.OPERA = goog.userAgent.BROWSER_KNOWN_ ? goog.userAgent.ASSUME_OPERA : module$contents$goog$labs$userAgent$browser_matchOpera(), goog.userAgent.IE = goog.userAgent.BROWSER_KNOWN_ ? goog.userAgent.ASSUME_IE : module$contents$goog$labs$userAgent$browser_matchIE(), goog.userAgent.EDGE = goog.userAgent.BROWSER_KNOWN_ ? goog.userAgent.ASSUME_EDGE : module$contents$goog$labs$userAgent$engine_isEdge(), goog.userAgent.EDGE_OR_IE = goog.userAgent.EDGE || goog.userAgent.IE, goog.userAgent.GECKO = goog.userAgent.BROWSER_KNOWN_ ? goog.userAgent.ASSUME_GECKO : module$contents$goog$labs$userAgent$engine_isGecko(), goog.userAgent.WEBKIT = goog.userAgent.BROWSER_KNOWN_ ? goog.userAgent.ASSUME_WEBKIT || goog.userAgent.ASSUME_MOBILE_WEBKIT : module$contents$goog$labs$userAgent$engine_isWebKit(), goog.userAgent.isMobile_ = function() {
                    return goog.userAgent.WEBKIT && module$contents$goog$labs$userAgent$util_matchUserAgent("Mobile")
                }, goog.userAgent.MOBILE = goog.userAgent.ASSUME_MOBILE_WEBKIT || goog.userAgent.isMobile_(), goog.userAgent.SAFARI = goog.userAgent.WEBKIT, goog.userAgent.determinePlatform_ = function() {
                    var e = goog.userAgent.getNavigatorTyped();
                    return e && e.platform || ""
                }, goog.userAgent.PLATFORM = goog.userAgent.determinePlatform_(), goog.userAgent.ASSUME_MAC = !1, goog.userAgent.ASSUME_WINDOWS = !1, goog.userAgent.ASSUME_LINUX = !1, goog.userAgent.ASSUME_X11 = !1, goog.userAgent.ASSUME_ANDROID = !1, goog.userAgent.ASSUME_IPHONE = !1, goog.userAgent.ASSUME_IPAD = !1, goog.userAgent.ASSUME_IPOD = !1, goog.userAgent.ASSUME_KAIOS = !1, goog.userAgent.PLATFORM_KNOWN_ = goog.userAgent.ASSUME_MAC || goog.userAgent.ASSUME_WINDOWS || goog.userAgent.ASSUME_LINUX || goog.userAgent.ASSUME_X11 || goog.userAgent.ASSUME_ANDROID || goog.userAgent.ASSUME_IPHONE || goog.userAgent.ASSUME_IPAD || goog.userAgent.ASSUME_IPOD, goog.userAgent.MAC = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_MAC : module$contents$goog$labs$userAgent$platform_isMacintosh(), goog.userAgent.WINDOWS = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_WINDOWS : module$contents$goog$labs$userAgent$platform_isWindows(), goog.userAgent.isLegacyLinux_ = function() {
                    return module$contents$goog$labs$userAgent$platform_isLinux() || module$contents$goog$labs$userAgent$platform_isChromeOS()
                }, goog.userAgent.LINUX = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_LINUX : goog.userAgent.isLegacyLinux_(), goog.userAgent.isX11_ = function() {
                    var e = goog.userAgent.getNavigatorTyped();
                    return !!e && goog.string.internal.contains(e.appVersion || "", "X11")
                }, goog.userAgent.X11 = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_X11 : goog.userAgent.isX11_(), goog.userAgent.ANDROID = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_ANDROID : module$contents$goog$labs$userAgent$platform_isAndroid(), goog.userAgent.IPHONE = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_IPHONE : module$contents$goog$labs$userAgent$platform_isIphone(), goog.userAgent.IPAD = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_IPAD : module$contents$goog$labs$userAgent$platform_isIpad(), goog.userAgent.IPOD = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_IPOD : module$contents$goog$labs$userAgent$platform_isIpod(), goog.userAgent.IOS = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_IPHONE || goog.userAgent.ASSUME_IPAD || goog.userAgent.ASSUME_IPOD : module$contents$goog$labs$userAgent$platform_isIos(), goog.userAgent.KAIOS = goog.userAgent.PLATFORM_KNOWN_ ? goog.userAgent.ASSUME_KAIOS : module$contents$goog$labs$userAgent$platform_isKaiOS(), goog.userAgent.determineVersion_ = function() {
                    var e = "",
                        t = goog.userAgent.getVersionRegexResult_();
                    return t && (e = t ? t[1] : ""), goog.userAgent.IE && (null != (t = goog.userAgent.getDocumentMode_()) && t > parseFloat(e)) ? String(t) : e
                }, goog.userAgent.getVersionRegexResult_ = function() {
                    var e = goog.userAgent.getUserAgentString();
                    return goog.userAgent.GECKO ? /rv:([^\);]+)(\)|;)/.exec(e) : goog.userAgent.EDGE ? /Edge\/([\d\.]+)/.exec(e) : goog.userAgent.IE ? /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(e) : goog.userAgent.WEBKIT ? /WebKit\/(\S+)/.exec(e) : goog.userAgent.OPERA ? /(?:Version)[ \/]?(\S+)/.exec(e) : void 0
                }, goog.userAgent.getDocumentMode_ = function() {
                    var e = goog.global.document;
                    return e ? e.documentMode : void 0
                }, goog.userAgent.VERSION = goog.userAgent.determineVersion_(), goog.userAgent.compare = function(e, t) {
                    return goog.string.internal.compareVersions(e, t)
                }, goog.userAgent.isVersionOrHigherCache_ = {}, goog.userAgent.isVersionOrHigher = function(e) {
                    return goog.userAgent.ASSUME_ANY_VERSION || goog.reflect.cache(goog.userAgent.isVersionOrHigherCache_, e, function() {
                        return 0 <= goog.string.internal.compareVersions(goog.userAgent.VERSION, e)
                    })
                }, goog.userAgent.isDocumentModeOrHigher = function(e) {
                    return Number(goog.userAgent.DOCUMENT_MODE) >= e
                }, goog.userAgent.isDocumentMode = goog.userAgent.isDocumentModeOrHigher, goog.userAgent.DOCUMENT_MODE = function() {
                    if (goog.global.document && goog.userAgent.IE) {
                        var e = goog.userAgent.getDocumentMode_();
                        return e || (parseInt(goog.userAgent.VERSION, 10) || void 0)
                    }
                }(), goog.userAgent.product = {}, goog.userAgent.product.ASSUME_FIREFOX = !1, goog.userAgent.product.ASSUME_IPHONE = !1, goog.userAgent.product.ASSUME_IPAD = !1, goog.userAgent.product.ASSUME_ANDROID = !1, goog.userAgent.product.ASSUME_CHROME = !1, goog.userAgent.product.ASSUME_SAFARI = !1, goog.userAgent.product.PRODUCT_KNOWN_ = goog.userAgent.ASSUME_IE || goog.userAgent.ASSUME_EDGE || goog.userAgent.ASSUME_OPERA || goog.userAgent.product.ASSUME_FIREFOX || goog.userAgent.product.ASSUME_IPHONE || goog.userAgent.product.ASSUME_IPAD || goog.userAgent.product.ASSUME_ANDROID || goog.userAgent.product.ASSUME_CHROME || goog.userAgent.product.ASSUME_SAFARI, goog.userAgent.product.OPERA = goog.userAgent.OPERA, goog.userAgent.product.IE = goog.userAgent.IE, goog.userAgent.product.EDGE = goog.userAgent.EDGE, goog.userAgent.product.FIREFOX = goog.userAgent.product.PRODUCT_KNOWN_ ? goog.userAgent.product.ASSUME_FIREFOX : module$contents$goog$labs$userAgent$browser_matchFirefox(), goog.userAgent.product.isIphoneOrIpod_ = function() {
                    return module$contents$goog$labs$userAgent$platform_isIphone() || module$contents$goog$labs$userAgent$platform_isIpod()
                }, goog.userAgent.product.IPHONE = goog.userAgent.product.PRODUCT_KNOWN_ ? goog.userAgent.product.ASSUME_IPHONE : goog.userAgent.product.isIphoneOrIpod_(), goog.userAgent.product.IPAD = goog.userAgent.product.PRODUCT_KNOWN_ ? goog.userAgent.product.ASSUME_IPAD : module$contents$goog$labs$userAgent$platform_isIpad(), goog.userAgent.product.ANDROID = goog.userAgent.product.PRODUCT_KNOWN_ ? goog.userAgent.product.ASSUME_ANDROID : module$contents$goog$labs$userAgent$browser_matchAndroidBrowser(), goog.userAgent.product.CHROME = goog.userAgent.product.PRODUCT_KNOWN_ ? goog.userAgent.product.ASSUME_CHROME : module$contents$goog$labs$userAgent$browser_matchChrome(), goog.userAgent.product.isSafariDesktop_ = function() {
                    return module$contents$goog$labs$userAgent$browser_matchSafari() && !module$contents$goog$labs$userAgent$platform_isIos()
                }, goog.userAgent.product.SAFARI = goog.userAgent.product.PRODUCT_KNOWN_ ? goog.userAgent.product.ASSUME_SAFARI : goog.userAgent.product.isSafariDesktop_(), goog.crypt.base64 = {}, goog.crypt.base64.DEFAULT_ALPHABET_COMMON_ = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", goog.crypt.base64.ENCODED_VALS = goog.crypt.base64.DEFAULT_ALPHABET_COMMON_ + "+/=", goog.crypt.base64.ENCODED_VALS_WEBSAFE = goog.crypt.base64.DEFAULT_ALPHABET_COMMON_ + "-_.", goog.crypt.base64.Alphabet = {
                    DEFAULT: 0,
                    NO_PADDING: 1,
                    WEBSAFE: 2,
                    WEBSAFE_DOT_PADDING: 3,
                    WEBSAFE_NO_PADDING: 4
                }, goog.crypt.base64.paddingChars_ = "=.", goog.crypt.base64.isPadding_ = function(e) {
                    return goog.string.internal.contains(goog.crypt.base64.paddingChars_, e)
                }, goog.crypt.base64.byteToCharMaps_ = {}, goog.crypt.base64.charToByteMap_ = null, goog.crypt.base64.ASSUME_NATIVE_SUPPORT_ = goog.userAgent.GECKO || goog.userAgent.WEBKIT, goog.crypt.base64.HAS_NATIVE_ENCODE_ = goog.crypt.base64.ASSUME_NATIVE_SUPPORT_ || "function" == typeof goog.global.btoa, goog.crypt.base64.HAS_NATIVE_DECODE_ = goog.crypt.base64.ASSUME_NATIVE_SUPPORT_ || !goog.userAgent.product.SAFARI && !goog.userAgent.IE && "function" == typeof goog.global.atob, goog.crypt.base64.encodeByteArray = function(e, t) {
                    goog.asserts.assert(goog.isArrayLike(e), "encodeByteArray takes an array as a parameter"), void 0 === t && (t = goog.crypt.base64.Alphabet.DEFAULT), goog.crypt.base64.init_(), t = goog.crypt.base64.byteToCharMaps_[t];
                    const r = Array(Math.floor(e.length / 3)),
                        s = t[64] || "";
                    let o = 0,
                        n = 0;
                    for (; o < e.length - 2; o += 3) {
                        var i = e[o],
                            a = e[o + 1],
                            g = e[o + 2],
                            u = t[i >> 2];
                        i = t[(3 & i) << 4 | a >> 4], a = t[(15 & a) << 2 | g >> 6], g = t[63 & g], r[n++] = "" + u + i + a + g
                    }
                    switch (u = 0, g = s, e.length - o) {
                        case 2:
                            g = t[(15 & (u = e[o + 1])) << 2] || s;
                        case 1:
                            e = e[o], r[n] = "" + t[e >> 2] + t[(3 & e) << 4 | u >> 4] + g + s
                    }
                    return r.join("")
                }, goog.crypt.base64.encodeBinaryString = function(e, t) {
                    return goog.crypt.base64.encodeString(e, t, !0)
                }, goog.crypt.base64.encodeString = function(e, t, r) {
                    return goog.crypt.base64.HAS_NATIVE_ENCODE_ && !t ? goog.global.btoa(e) : goog.crypt.base64.encodeByteArray(goog.crypt.stringToByteArray(e, r), t)
                }, goog.crypt.base64.encodeStringUtf8 = function(e, t) {
                    return goog.crypt.base64.encodeText(e, t)
                }, goog.crypt.base64.encodeText = function(e, t) {
                    return goog.crypt.base64.HAS_NATIVE_ENCODE_ && !t ? goog.global.btoa(unescape(encodeURIComponent(e))) : goog.crypt.base64.encodeByteArray(goog.crypt.stringToUtf8ByteArray(e), t)
                }, goog.crypt.base64.decodeToBinaryString = function(e, t) {
                    if (goog.crypt.base64.HAS_NATIVE_DECODE_ && !t) return goog.global.atob(e);
                    var r = "";
                    return goog.crypt.base64.decodeStringInternal_(e, function(e) {
                        r += String.fromCharCode(e)
                    }), r
                }, goog.crypt.base64.decodeString = goog.crypt.base64.decodeToBinaryString, goog.crypt.base64.decodeStringUtf8 = function(e, t) {
                    return goog.crypt.base64.decodeToText(e, t)
                }, goog.crypt.base64.decodeToText = function(e, t) {
                    return decodeURIComponent(escape(goog.crypt.base64.decodeString(e, t)))
                }, goog.crypt.base64.decodeStringToByteArray = function(e, t) {
                    var r = [];
                    return goog.crypt.base64.decodeStringInternal_(e, function(e) {
                        r.push(e)
                    }), r
                }, goog.crypt.base64.decodeStringToUint8Array = function(e) {
                    var t = e.length,
                        r = 3 * t / 4;
                    r % 3 ? r = Math.floor(r) : goog.crypt.base64.isPadding_(e[t - 1]) && (r = goog.crypt.base64.isPadding_(e[t - 2]) ? r - 2 : r - 1);
                    var s = new Uint8Array(r),
                        o = 0;
                    return goog.crypt.base64.decodeStringInternal_(e, function(e) {
                        s[o++] = e
                    }), o !== r ? s.subarray(0, o) : s
                }, goog.crypt.base64.decodeStringInternal_ = function(e, t) {
                    function r(t) {
                        for (; s < e.length;) {
                            var r = e.charAt(s++),
                                o = goog.crypt.base64.charToByteMap_[r];
                            if (null != o) return o;
                            if (!goog.string.internal.isEmptyOrWhitespace(r)) throw Error("Unknown base64 encoding at char: " + r)
                        }
                        return t
                    }
                    goog.crypt.base64.init_();
                    for (var s = 0;;) {
                        var o = r(-1),
                            n = r(0),
                            i = r(64),
                            a = r(64);
                        if (64 === a && -1 === o) break;
                        t(o << 2 | n >> 4), 64 != i && (t(n << 4 & 240 | i >> 2), 64 != a && t(i << 6 & 192 | a))
                    }
                }, goog.crypt.base64.init_ = function() {
                    if (!goog.crypt.base64.charToByteMap_) {
                        goog.crypt.base64.charToByteMap_ = {};
                        for (var e = goog.crypt.base64.DEFAULT_ALPHABET_COMMON_.split(""), t = ["+/=", "+/", "-_=", "-_.", "-_"], r = 0; 5 > r; r++) {
                            var s = e.concat(t[r].split(""));
                            goog.crypt.base64.byteToCharMaps_[r] = s;
                            for (var o = 0; o < s.length; o++) {
                                var n = s[o],
                                    i = goog.crypt.base64.charToByteMap_[n];
                                void 0 === i ? goog.crypt.base64.charToByteMap_[n] = o : goog.asserts.assert(i === o)
                            }
                        }
                    }
                }, jspb.BinaryConstants = {};
                const module$contents$jspb$BinaryConstants_FieldType = {
                        INVALID: -1,
                        DOUBLE: 1,
                        FLOAT: 2,
                        INT64: 3,
                        UINT64: 4,
                        INT32: 5,
                        FIXED64: 6,
                        FIXED32: 7,
                        BOOL: 8,
                        STRING: 9,
                        GROUP: 10,
                        MESSAGE: 11,
                        BYTES: 12,
                        UINT32: 13,
                        ENUM: 14,
                        SFIXED32: 15,
                        SFIXED64: 16,
                        SINT32: 17,
                        SINT64: 18
                    },
                    module$contents$jspb$BinaryConstants_WireType = {
                        INVALID: -1,
                        VARINT: 0,
                        FIXED64: 1,
                        DELIMITED: 2,
                        START_GROUP: 3,
                        END_GROUP: 4,
                        FIXED32: 5
                    };

                function module$contents$jspb$BinaryConstants_isValidWireType(e) {
                    return 0 <= e && 5 >= e
                }

                function module$contents$jspb$BinaryConstants_FieldTypeToWireType(e) {
                    switch (e) {
                        case module$contents$jspb$BinaryConstants_FieldType.INT32:
                        case module$contents$jspb$BinaryConstants_FieldType.INT64:
                        case module$contents$jspb$BinaryConstants_FieldType.UINT32:
                        case module$contents$jspb$BinaryConstants_FieldType.UINT64:
                        case module$contents$jspb$BinaryConstants_FieldType.SINT32:
                        case module$contents$jspb$BinaryConstants_FieldType.SINT64:
                        case module$contents$jspb$BinaryConstants_FieldType.BOOL:
                        case module$contents$jspb$BinaryConstants_FieldType.ENUM:
                            return module$contents$jspb$BinaryConstants_WireType.VARINT;
                        case module$contents$jspb$BinaryConstants_FieldType.DOUBLE:
                        case module$contents$jspb$BinaryConstants_FieldType.FIXED64:
                        case module$contents$jspb$BinaryConstants_FieldType.SFIXED64:
                            return module$contents$jspb$BinaryConstants_WireType.FIXED64;
                        case module$contents$jspb$BinaryConstants_FieldType.STRING:
                        case module$contents$jspb$BinaryConstants_FieldType.MESSAGE:
                        case module$contents$jspb$BinaryConstants_FieldType.BYTES:
                            return module$contents$jspb$BinaryConstants_WireType.DELIMITED;
                        case module$contents$jspb$BinaryConstants_FieldType.FLOAT:
                        case module$contents$jspb$BinaryConstants_FieldType.FIXED32:
                        case module$contents$jspb$BinaryConstants_FieldType.SFIXED32:
                            return module$contents$jspb$BinaryConstants_WireType.FIXED32;
                        default:
                            return module$contents$jspb$BinaryConstants_WireType.INVALID
                    }
                }
                const module$contents$jspb$BinaryConstants_INVALID_FIELD_NUMBER = -1,
                    module$contents$jspb$BinaryConstants_INVALID_TAG = -1,
                    module$contents$jspb$BinaryConstants_FLOAT32_EPS = 1401298464324817e-60,
                    module$contents$jspb$BinaryConstants_FLOAT32_MIN = 11754943508222875e-54,
                    module$contents$jspb$BinaryConstants_FLOAT32_MAX = 34028234663852886e22,
                    module$contents$jspb$BinaryConstants_FLOAT64_EPS = 5e-324,
                    module$contents$jspb$BinaryConstants_FLOAT64_MIN = 22250738585072014e-324,
                    module$contents$jspb$BinaryConstants_FLOAT64_MAX = 17976931348623157e292,
                    module$contents$jspb$BinaryConstants_TWO_TO_20 = 1048576,
                    module$contents$jspb$BinaryConstants_TWO_TO_23 = 8388608,
                    module$contents$jspb$BinaryConstants_TWO_TO_31 = 2147483648,
                    module$contents$jspb$BinaryConstants_TWO_TO_32 = 4294967296,
                    module$contents$jspb$BinaryConstants_TWO_TO_52 = 4503599627370496,
                    module$contents$jspb$BinaryConstants_TWO_TO_63 = 0x8000000000000000,
                    module$contents$jspb$BinaryConstants_TWO_TO_64 = 0x10000000000000000,
                    module$contents$jspb$BinaryConstants_ZERO_HASH = "\0\0\0\0\0\0\0\0",
                    module$contents$jspb$BinaryConstants_MESSAGE_SET_GROUP_NUMBER = 1,
                    module$contents$jspb$BinaryConstants_MESSAGE_SET_TYPE_ID_FIELD_NUMBER = 2,
                    module$contents$jspb$BinaryConstants_MESSAGE_SET_MESSAGE_FIELD_NUMBER = 3,
                    module$contents$jspb$BinaryConstants_MESSAGE_SET_MAX_TYPE_ID = 4294967294;
                jspb.BinaryConstants.FieldType = module$contents$jspb$BinaryConstants_FieldType, jspb.BinaryConstants.FieldTypeToWireType = module$contents$jspb$BinaryConstants_FieldTypeToWireType, jspb.BinaryConstants.FLOAT32_EPS = module$contents$jspb$BinaryConstants_FLOAT32_EPS, jspb.BinaryConstants.FLOAT32_MIN = module$contents$jspb$BinaryConstants_FLOAT32_MIN, jspb.BinaryConstants.FLOAT32_MAX = module$contents$jspb$BinaryConstants_FLOAT32_MAX, jspb.BinaryConstants.FLOAT64_EPS = module$contents$jspb$BinaryConstants_FLOAT64_EPS, jspb.BinaryConstants.FLOAT64_MIN = module$contents$jspb$BinaryConstants_FLOAT64_MIN, jspb.BinaryConstants.FLOAT64_MAX = module$contents$jspb$BinaryConstants_FLOAT64_MAX, jspb.BinaryConstants.INVALID_FIELD_NUMBER = module$contents$jspb$BinaryConstants_INVALID_FIELD_NUMBER, jspb.BinaryConstants.INVALID_TAG = module$contents$jspb$BinaryConstants_INVALID_TAG, jspb.BinaryConstants.MESSAGE_SET_GROUP_NUMBER = module$contents$jspb$BinaryConstants_MESSAGE_SET_GROUP_NUMBER, jspb.BinaryConstants.MESSAGE_SET_MAX_TYPE_ID = module$contents$jspb$BinaryConstants_MESSAGE_SET_MAX_TYPE_ID, jspb.BinaryConstants.MESSAGE_SET_MESSAGE_FIELD_NUMBER = module$contents$jspb$BinaryConstants_MESSAGE_SET_MESSAGE_FIELD_NUMBER, jspb.BinaryConstants.MESSAGE_SET_TYPE_ID_FIELD_NUMBER = module$contents$jspb$BinaryConstants_MESSAGE_SET_TYPE_ID_FIELD_NUMBER, jspb.BinaryConstants.TWO_TO_20 = module$contents$jspb$BinaryConstants_TWO_TO_20, jspb.BinaryConstants.TWO_TO_23 = module$contents$jspb$BinaryConstants_TWO_TO_23, jspb.BinaryConstants.TWO_TO_31 = module$contents$jspb$BinaryConstants_TWO_TO_31, jspb.BinaryConstants.TWO_TO_32 = module$contents$jspb$BinaryConstants_TWO_TO_32, jspb.BinaryConstants.TWO_TO_52 = module$contents$jspb$BinaryConstants_TWO_TO_52, jspb.BinaryConstants.TWO_TO_63 = module$contents$jspb$BinaryConstants_TWO_TO_63, jspb.BinaryConstants.TWO_TO_64 = module$contents$jspb$BinaryConstants_TWO_TO_64, jspb.BinaryConstants.WireType = module$contents$jspb$BinaryConstants_WireType, jspb.BinaryConstants.ZERO_HASH = module$contents$jspb$BinaryConstants_ZERO_HASH, jspb.BinaryConstants.isValidWireType = module$contents$jspb$BinaryConstants_isValidWireType;
                var module$exports$jspb$binary$errors = {};

                function module$contents$jspb$binary$errors_messageLengthMismatchError(e, t) {
                    return Error(`Message parsing ended unexpectedly. Expected to read ${e} bytes, instead read ${t} bytes, either the data ended unexpectedly or the message misreported its own length`)
                }

                function module$contents$jspb$binary$errors_invalidWireTypeError(e, t) {
                    return Error(`Invalid wire type: ${e} (at position ${t})`)
                }

                function module$contents$jspb$binary$errors_invalidFieldNumberError(e, t) {
                    return Error(`Invalid field number: ${e} (at position ${t})`)
                }

                function module$contents$jspb$binary$errors_malformedBinaryBytesForMessageSet() {
                    return Error("Malformed binary bytes for message set")
                }

                function module$contents$jspb$binary$errors_unmatchedStartGroupEofError() {
                    return Error("Unmatched start-group tag: stream EOF")
                }

                function module$contents$jspb$binary$errors_unmatchedStartGroupError() {
                    return Error("Unmatched end-group tag")
                }

                function module$contents$jspb$binary$errors_groupDidNotEndWithEndGroupError() {
                    return Error("Group submessage did not end with an END_GROUP tag")
                }

                function module$contents$jspb$binary$errors_invalidVarintError() {
                    return Error("Failed to read varint, encoding is invalid.")
                }

                function module$contents$jspb$binary$errors_readTooFarError(e, t) {
                    return Error(`Tried to read past the end of the data ${t} > ${e}`)
                }

                function module$contents$jspb$binary$errors_negativeByteLengthError(e) {
                    return Error(`Tried to read a negative byte length: ${e}`)
                }
                module$exports$jspb$binary$errors.messageLengthMismatchError = module$contents$jspb$binary$errors_messageLengthMismatchError, module$exports$jspb$binary$errors.groupDidNotEndWithEndGroupError = module$contents$jspb$binary$errors_groupDidNotEndWithEndGroupError, module$exports$jspb$binary$errors.invalidFieldNumberError = module$contents$jspb$binary$errors_invalidFieldNumberError, module$exports$jspb$binary$errors.invalidVarintError = module$contents$jspb$binary$errors_invalidVarintError, module$exports$jspb$binary$errors.invalidWireTypeError = module$contents$jspb$binary$errors_invalidWireTypeError, module$exports$jspb$binary$errors.malformedBinaryBytesForMessageSet = module$contents$jspb$binary$errors_malformedBinaryBytesForMessageSet, module$exports$jspb$binary$errors.negativeByteLengthError = module$contents$jspb$binary$errors_negativeByteLengthError, module$exports$jspb$binary$errors.readTooFarError = module$contents$jspb$binary$errors_readTooFarError, module$exports$jspb$binary$errors.unmatchedStartGroupError = module$contents$jspb$binary$errors_unmatchedStartGroupError, module$exports$jspb$binary$errors.unmatchedStartGroupEofError = module$contents$jspb$binary$errors_unmatchedStartGroupEofError;
                var module$exports$jspb$internal_options = {};

                function module$contents$jspb$internal_options_isBigIntAvailable() {
                    return 2021 <= goog.FEATURESET_YEAR || "function" == typeof BigInt
                }
                module$exports$jspb$internal_options.isBigIntAvailable = module$contents$jspb$internal_options_isBigIntAvailable;
                var module$exports$jspb$binary$bytesource = {},
                    module$exports$jspb$internal_bytes = {};
                module$exports$jspb$internal_bytes.SUPPORTS_UINT8ARRAY = 2018 <= goog.FEATURESET_YEAR || "undefined" != typeof Uint8Array;
                const module$contents$jspb$internal_bytes_HANDLE_WEB_SAFE_ENCODINGS_WITH_ATOB_AND_BTOA = !0,
                    module$contents$jspb$internal_bytes_CAN_USE_ATOB_AND_BTOA = !0,
                    module$contents$jspb$internal_bytes_ASSUME_ATOB_AND_BTOA_AVAILABLE = 2018 <= goog.FEATURESET_YEAR;
                module$exports$jspb$internal_bytes.USE_ATOB_BTOA = module$contents$jspb$internal_bytes_CAN_USE_ATOB_AND_BTOA && (module$contents$jspb$internal_bytes_ASSUME_ATOB_AND_BTOA_AVAILABLE || !goog.userAgent.IE && "function" == typeof btoa);
                const module$contents$jspb$internal_bytes_UINT8ARRAY_MAX_SIZE_FOR_SPREAD = 10240;

                function module$contents$jspb$internal_bytes_encodeByteArray(e) {
                    if (!module$exports$jspb$internal_bytes.USE_ATOB_BTOA) return goog.crypt.base64.encodeByteArray(e);
                    let t = "",
                        r = 0;
                    const s = e.length - module$contents$jspb$internal_bytes_UINT8ARRAY_MAX_SIZE_FOR_SPREAD;
                    for (; r < s;) t += String.fromCharCode.apply(null, e.subarray(r, r += module$contents$jspb$internal_bytes_UINT8ARRAY_MAX_SIZE_FOR_SPREAD));
                    return t += String.fromCharCode.apply(null, r ? e.subarray(r) : e), btoa(t)
                }
                const module$contents$jspb$internal_bytes_WEBSAFE_BASE64_CHARS = /[-_.]/g,
                    module$contents$jspb$internal_bytes_websafeReplacer = {
                        "-": "+",
                        _: "/",
                        ".": "="
                    };

                function module$contents$jspb$internal_bytes_replaceWebsafe(e) {
                    return module$contents$jspb$internal_bytes_websafeReplacer[e] || ""
                }

                function module$contents$jspb$internal_bytes_replaceWebsafeString(e) {
                    return module$contents$jspb$internal_bytes_WEBSAFE_BASE64_CHARS.test(e) ? e.replace(module$contents$jspb$internal_bytes_WEBSAFE_BASE64_CHARS, module$contents$jspb$internal_bytes_replaceWebsafe) : e
                }

                function module$contents$jspb$internal_bytes_decodeByteArray(e) {
                    if (!module$exports$jspb$internal_bytes.USE_ATOB_BTOA) return goog.crypt.base64.decodeStringToUint8Array(e);
                    var t = e;
                    let r;
                    if (module$contents$jspb$internal_bytes_HANDLE_WEB_SAFE_ENCODINGS_WITH_ATOB_AND_BTOA && (t = module$contents$jspb$internal_bytes_replaceWebsafeString(t)), goog.DEBUG) try {
                        r = atob(t)
                    } catch (t) {
                        throw Error(`invalid encoding '${e}': ${t}`)
                    } else r = atob(t);
                    for (e = new Uint8Array(r.length), t = 0; t < r.length; t++) e[t] = r.charCodeAt(t);
                    return e
                }

                function module$contents$jspb$internal_bytes_dataAsU8(e) {
                    return null == e || module$contents$jspb$internal_bytes_isU8(e) ? e : "string" == typeof e ? module$contents$jspb$internal_bytes_decodeByteArray(e) : ((0, goog.asserts.fail)("Cannot coerce to Uint8Array: " + goog.typeOf(e)), null)
                }

                function module$contents$jspb$internal_bytes_isU8(e) {
                    return module$exports$jspb$internal_bytes.SUPPORTS_UINT8ARRAY && null != e && e instanceof Uint8Array
                }

                function module$contents$jspb$internal_bytes_uint8ArrayEquals(e, t) {
                    const r = e.length;
                    if (r !== t.length) return !1;
                    for (let s = 0; s < r; s++)
                        if (e[s] !== t[s]) return !1;
                    return !0
                }
                module$exports$jspb$internal_bytes.I_AM_INTERNAL = {}, module$exports$jspb$internal_bytes.encodeByteArray = module$contents$jspb$internal_bytes_encodeByteArray, module$exports$jspb$internal_bytes.decodeByteArray = module$contents$jspb$internal_bytes_decodeByteArray, module$exports$jspb$internal_bytes.dataAsU8 = module$contents$jspb$internal_bytes_dataAsU8, module$exports$jspb$internal_bytes.isU8 = module$contents$jspb$internal_bytes_isU8, module$exports$jspb$internal_bytes.replaceWebsafeString = module$contents$jspb$internal_bytes_replaceWebsafeString, module$exports$jspb$internal_bytes.uint8ArrayEquals = module$contents$jspb$internal_bytes_uint8ArrayEquals, jspb.binary = {}, jspb.binary.utf8 = {};
                const module$contents$jspb$binary$utf8_USE_TEXT_ENCODING = !0,
                    module$contents$jspb$binary$utf8_ASSUME_TEXT_ENCODING_AVAILABLE = 2020 <= goog.FEATURESET_YEAR,
                    module$contents$jspb$binary$utf8_MIN_SURROGATE = 55296,
                    module$contents$jspb$binary$utf8_MIN_HIGH_SURROGATE = module$contents$jspb$binary$utf8_MIN_SURROGATE,
                    module$contents$jspb$binary$utf8_MAX_HIGH_SURROGATE = 56319,
                    module$contents$jspb$binary$utf8_MIN_LOW_SURROGATE = 56320,
                    module$contents$jspb$binary$utf8_MAX_LOW_SURROGATE = 57343,
                    module$contents$jspb$binary$utf8_MAX_SURROGATE = module$contents$jspb$binary$utf8_MAX_LOW_SURROGATE;

                function module$contents$jspb$binary$utf8_isNotTrailingByte(e) {
                    return 128 != (192 & e)
                }

                function module$contents$jspb$binary$utf8_invalid(e, t) {
                    if (e) throw Error("Invalid UTF8");
                    t.push(65533)
                }

                function module$contents$jspb$binary$utf8_codeUnitsToString(e, t) {
                    return t = String.fromCharCode.apply(null, t), null == e ? t : e + t
                }

                function module$contents$jspb$binary$utf8_polyfillDecodeUtf8(e, t, r, s) {
                    r = t + r;
                    const o = [];
                    let n, i, a, g = null;
                    for (; t < r;) {
                        var u = e[t++];
                        128 > u ? o.push(u) : 224 > u ? t >= r ? module$contents$jspb$binary$utf8_invalid(s, o) : (n = e[t++], 194 > u || module$contents$jspb$binary$utf8_isNotTrailingByte(n) ? (t--, module$contents$jspb$binary$utf8_invalid(s, o)) : (u = (31 & u) << 6 | 63 & n, (0, goog.asserts.assert)(128 <= u && 2047 >= u), o.push(u))) : 240 > u ? t >= r - 1 ? module$contents$jspb$binary$utf8_invalid(s, o) : (n = e[t++], module$contents$jspb$binary$utf8_isNotTrailingByte(n) || 224 === u && 160 > n || 237 === u && 160 <= n || module$contents$jspb$binary$utf8_isNotTrailingByte(i = e[t++]) ? (t--, module$contents$jspb$binary$utf8_invalid(s, o)) : (u = (15 & u) << 12 | (63 & n) << 6 | 63 & i, (0, goog.asserts.assert)(2048 <= u && 65535 >= u), (0, goog.asserts.assert)(u < module$contents$jspb$binary$utf8_MIN_SURROGATE || u > module$contents$jspb$binary$utf8_MAX_LOW_SURROGATE), o.push(u))) : 244 >= u ? t >= r - 2 ? module$contents$jspb$binary$utf8_invalid(s, o) : (n = e[t++], module$contents$jspb$binary$utf8_isNotTrailingByte(n) || n - 144 + (u << 28) >> 30 || module$contents$jspb$binary$utf8_isNotTrailingByte(i = e[t++]) || module$contents$jspb$binary$utf8_isNotTrailingByte(a = e[t++]) ? (t--, module$contents$jspb$binary$utf8_invalid(s, o)) : (u = (7 & u) << 18 | (63 & n) << 12 | (63 & i) << 6 | 63 & a, (0, goog.asserts.assert)(65536 <= u && 1114111 >= u), u -= 65536, o.push((u >> 10 & 1023) + module$contents$jspb$binary$utf8_MIN_SURROGATE, (1023 & u) + module$contents$jspb$binary$utf8_MIN_LOW_SURROGATE))) : module$contents$jspb$binary$utf8_invalid(s, o), 8192 <= o.length && (g = module$contents$jspb$binary$utf8_codeUnitsToString(g, o), o.length = 0)
                    }
                    return (0, goog.asserts.assert)(t === r, `expected ${t} === ${r}`), module$contents$jspb$binary$utf8_codeUnitsToString(g, o)
                }
                let module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing_ = 2020 <= goog.FEATURESET_YEAR || void 0,
                    module$contents$jspb$binary$utf8_fatalDecoderInstance, module$contents$jspb$binary$utf8_nonFatalDecoderInstance;

                function module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing(e) {
                    if (void 0 === module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing_) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (e) {}
                        try {
                            e.decode(new Uint8Array([97])), module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing_ = !0
                        } catch (e) {
                            module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing_ = !1
                        }
                    }
                    return module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing_
                }

                function module$contents$jspb$binary$utf8_getFatalDecoderInstance() {
                    let e = module$contents$jspb$binary$utf8_fatalDecoderInstance;
                    return e || = module$contents$jspb$binary$utf8_fatalDecoderInstance = new TextDecoder("utf-8", {
                        fatal: !0
                    }), e
                }

                function module$contents$jspb$binary$utf8_getNonFatalDecoderInstance() {
                    let e = module$contents$jspb$binary$utf8_nonFatalDecoderInstance;
                    return e || = module$contents$jspb$binary$utf8_nonFatalDecoderInstance = new TextDecoder("utf-8", {
                        fatal: !1
                    }), e
                }

                function module$contents$jspb$binary$utf8_subarray(e, t, r) {
                    return 0 === t && r === e.length ? e : e.subarray(t, r)
                }

                function module$contents$jspb$binary$utf8_textDecoderDecodeUtf8(e, t, r, s) {
                    const o = s ? module$contents$jspb$binary$utf8_getFatalDecoderInstance() : module$contents$jspb$binary$utf8_getNonFatalDecoderInstance();
                    e = module$contents$jspb$binary$utf8_subarray(e, t, t + r);
                    try {
                        return o.decode(e)
                    } catch (e) {
                        throw s && !module$contents$jspb$binary$utf8_isFatalTextDecoderCachableAfterThrowing(o) && (module$contents$jspb$binary$utf8_fatalDecoderInstance = void 0), e
                    }
                }
                const module$contents$jspb$binary$utf8_useTextDecoderDecode = module$contents$jspb$binary$utf8_USE_TEXT_ENCODING && (module$contents$jspb$binary$utf8_ASSUME_TEXT_ENCODING_AVAILABLE || "undefined" != typeof TextDecoder);

                function module$contents$jspb$binary$utf8_decodeUtf8(e, t, r, s) {
                    return module$contents$jspb$binary$utf8_useTextDecoderDecode ? module$contents$jspb$binary$utf8_textDecoderDecodeUtf8(e, t, r, s) : module$contents$jspb$binary$utf8_polyfillDecodeUtf8(e, t, r, s)
                }
                let module$contents$jspb$binary$utf8_textEncoderInstance;

                function module$contents$jspb$binary$utf8_textEncoderEncode(e, t) {
                    return t && module$contents$jspb$binary$utf8_checkWellFormed(e), (module$contents$jspb$binary$utf8_textEncoderInstance || = new TextEncoder).encode(e)
                }
                const module$contents$jspb$binary$utf8_IS_WELL_FORMED = "isWellFormed",
                    module$contents$jspb$binary$utf8_HAS_WELL_FORMED_METHOD = 2023 < goog.FEATURESET_YEAR || "function" == typeof String.prototype[module$contents$jspb$binary$utf8_IS_WELL_FORMED];

                function module$contents$jspb$binary$utf8_checkWellFormed(e) {
                    if (module$contents$jspb$binary$utf8_HAS_WELL_FORMED_METHOD ? !e[module$contents$jspb$binary$utf8_IS_WELL_FORMED]() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(e)) throw Error("Found an unpaired surrogate")
                }

                function module$contents$jspb$binary$utf8_polyfillEncode(e, t) {
                    let r = 0;
                    const s = new Uint8Array(3 * e.length);
                    for (let n = 0; n < e.length; n++) {
                        var o = e.charCodeAt(n);
                        if (128 > o) s[r++] = o;
                        else {
                            if (2048 > o) s[r++] = o >> 6 | 192;
                            else {
                                if ((0, goog.asserts.assert)(65536 > o), o >= module$contents$jspb$binary$utf8_MIN_SURROGATE && o <= module$contents$jspb$binary$utf8_MAX_LOW_SURROGATE) {
                                    if (o <= module$contents$jspb$binary$utf8_MAX_HIGH_SURROGATE && n < e.length) {
                                        const t = e.charCodeAt(++n);
                                        if (t >= module$contents$jspb$binary$utf8_MIN_LOW_SURROGATE && t <= module$contents$jspb$binary$utf8_MAX_LOW_SURROGATE) {
                                            o = 1024 * (o - module$contents$jspb$binary$utf8_MIN_SURROGATE) + t - module$contents$jspb$binary$utf8_MIN_LOW_SURROGATE + 65536, s[r++] = o >> 18 | 240, s[r++] = o >> 12 & 63 | 128, s[r++] = o >> 6 & 63 | 128, s[r++] = 63 & o | 128;
                                            continue
                                        }
                                        n--
                                    }
                                    if (t) throw Error("Found an unpaired surrogate");
                                    o = 65533
                                }
                                s[r++] = o >> 12 | 224, s[r++] = o >> 6 & 63 | 128
                            }
                            s[r++] = 63 & o | 128
                        }
                    }
                    return module$contents$jspb$binary$utf8_subarray(s, 0, r)
                }
                const module$contents$jspb$binary$utf8_useTextEncoderEncode = module$contents$jspb$binary$utf8_USE_TEXT_ENCODING && (module$contents$jspb$binary$utf8_ASSUME_TEXT_ENCODING_AVAILABLE || "undefined" != typeof TextEncoder);

                function module$contents$jspb$binary$utf8_encodeUtf8(e, t = !1) {
                    return (0, goog.asserts.assertString)(e), module$contents$jspb$binary$utf8_useTextEncoderEncode ? module$contents$jspb$binary$utf8_textEncoderEncode(e, t) : module$contents$jspb$binary$utf8_polyfillEncode(e, t)
                }
                jspb.binary.utf8.decodeUtf8 = module$contents$jspb$binary$utf8_decodeUtf8, jspb.binary.utf8.encodeUtf8 = module$contents$jspb$binary$utf8_encodeUtf8, jspb.binary.utf8.checkWellFormed = module$contents$jspb$binary$utf8_checkWellFormed, jspb.binary.utf8.textDecoderDecodeUtf8 = module$contents$jspb$binary$utf8_textDecoderDecodeUtf8, jspb.binary.utf8.polyfillDecodeUtf8 = module$contents$jspb$binary$utf8_polyfillDecodeUtf8, jspb.binary.utf8.textEncoderEncode = module$contents$jspb$binary$utf8_textEncoderEncode, jspb.binary.utf8.polyfillEncode = module$contents$jspb$binary$utf8_polyfillEncode, jspb.bytestring = {};
                class module$contents$jspb$bytestring_ByteString {
                    static fromBase64(e) {
                        return (0, goog.asserts.assertString)(e), e ? new module$contents$jspb$bytestring_ByteString(e, module$exports$jspb$internal_bytes.I_AM_INTERNAL) : module$contents$jspb$bytestring_ByteString.empty()
                    }
                    static fromUint8Array(e) {
                        return (0, goog.asserts.assert)(e instanceof Uint8Array || Array.isArray(e)), e.length ? new module$contents$jspb$bytestring_ByteString(new Uint8Array(e), module$exports$jspb$internal_bytes.I_AM_INTERNAL) : module$contents$jspb$bytestring_ByteString.empty()
                    }
                    static fromStringUtf8(e) {
                        return (0, goog.asserts.assertString)(e), e.length ? new module$contents$jspb$bytestring_ByteString(module$contents$jspb$binary$utf8_encodeUtf8(e, !0), module$exports$jspb$internal_bytes.I_AM_INTERNAL) : module$contents$jspb$bytestring_ByteString.empty()
                    }
                    static async fromBlob(e) {
                        return (0, goog.asserts.assertInstanceof)(e, Blob), 0 === e.size ? module$contents$jspb$bytestring_ByteString.empty() : (e = await e.arrayBuffer(), new module$contents$jspb$bytestring_ByteString(new Uint8Array(e), module$exports$jspb$internal_bytes.I_AM_INTERNAL))
                    }
                    static empty() {
                        return module$contents$jspb$bytestring_emptyByteString || = new module$contents$jspb$bytestring_ByteString(null, module$exports$jspb$internal_bytes.I_AM_INTERNAL)
                    }
                    asBase64() {
                        const e = this.value_;
                        return null == e ? "" : "string" == typeof e ? e : this.value_ = module$contents$jspb$internal_bytes_encodeByteArray(e)
                    }
                    asUint8Array() {
                        return new Uint8Array(this.internalBytesUnsafe(module$exports$jspb$internal_bytes.I_AM_INTERNAL) || 0)
                    }
                    isEmpty() {
                        return null == this.value_
                    }
                    sizeBytes() {
                        const e = this.internalBytesUnsafe(module$exports$jspb$internal_bytes.I_AM_INTERNAL);
                        return e ? e.length : 0
                    }
                    unsignedByteAt(e) {
                        (0, goog.asserts.assertNumber)(e), (0, goog.asserts.assert)(0 <= e, "index %s should be non-negative", e);
                        const t = this.internalBytesUnsafe(module$exports$jspb$internal_bytes.I_AM_INTERNAL);
                        return (0, goog.asserts.assert)(e < t.length, "index %s must be less than %s", e, t.length), t[e]
                    }
                    signedByteAt(e) {
                        return this.unsignedByteAt(e) << 24 >> 24
                    }
                    asStringUtf8({
                        parsingErrorsAreFatal: e = !0
                    } = {}) {
                        const t = this.internalBytesUnsafe(module$exports$jspb$internal_bytes.I_AM_INTERNAL);
                        return t ? module$contents$jspb$binary$utf8_decodeUtf8(t, 0, t.length, e) : ""
                    }
                    asBlob(e) {
                        const t = this.internalBytesUnsafe(module$exports$jspb$internal_bytes.I_AM_INTERNAL);
                        return t ? new Blob([t], e) : new Blob([], e)
                    }
                    internalBytesUnsafe(e) {
                        return module$contents$jspb$bytestring_checkAllowedCaller(e), null == (e = module$contents$jspb$internal_bytes_dataAsU8(this.value_)) ? e : this.value_ = e
                    }
                    internalUnwrap(e) {
                        return module$contents$jspb$bytestring_checkAllowedCaller(e), this.value_ || ""
                    }
                    constructor(e, t) {
                        if (module$contents$jspb$bytestring_checkAllowedCaller(t), this.value_ = e, null != e && 0 === e.length) throw Error("ByteString should be constructed with non-empty values")
                    }
                }
                let module$contents$jspb$bytestring_emptyByteString;

                function module$contents$jspb$bytestring_checkAllowedCaller(e) {
                    if (e !== module$exports$jspb$internal_bytes.I_AM_INTERNAL) throw Error("illegal external caller")
                }
                jspb.bytestring.ByteString = module$contents$jspb$bytestring_ByteString;
                var module$exports$jspb$unsafe_bytestring = {};

                function module$contents$jspb$unsafe_bytestring_unsafeByteStringFromUint8Array(e) {
                    return (0, goog.asserts.assertInstanceof)(e, Uint8Array), 0 == e.length ? module$contents$jspb$bytestring_ByteString.empty() : new module$contents$jspb$bytestring_ByteString(e, module$exports$jspb$internal_bytes.I_AM_INTERNAL)
                }

                function module$contents$jspb$unsafe_bytestring_unsafeUint8ArrayFromByteString(e) {
                    return (0, goog.asserts.assertInstanceof)(e, module$contents$jspb$bytestring_ByteString), e.internalBytesUnsafe(module$exports$jspb$internal_bytes.I_AM_INTERNAL) || new Uint8Array(0)
                }

                function module$contents$jspb$unsafe_bytestring_unsafeUnwrapByteString(e) {
                    return (0, goog.asserts.assertInstanceof)(e, module$contents$jspb$bytestring_ByteString), e.internalUnwrap(module$exports$jspb$internal_bytes.I_AM_INTERNAL)
                }
                module$exports$jspb$unsafe_bytestring.unsafeByteStringFromUint8Array = module$contents$jspb$unsafe_bytestring_unsafeByteStringFromUint8Array, module$exports$jspb$unsafe_bytestring.unsafeUint8ArrayFromByteString = module$contents$jspb$unsafe_bytestring_unsafeUint8ArrayFromByteString, module$exports$jspb$unsafe_bytestring.unsafeUnwrapByteString = module$contents$jspb$unsafe_bytestring_unsafeUnwrapByteString, jspb.utils = {};
                const module$contents$jspb$utils_SUPPORTS_UINT8ARRAY_SLICING = 2018 <= goog.FEATURESET_YEAR || "function" == typeof Uint8Array.prototype.slice,
                    module$contents$jspb$utils_MAX_SCRATCHPAD_BYTES = 8;

                function module$contents$jspb$utils_sliceUint8Array(e, t, r) {
                    return t === r ? new Uint8Array(0) : module$contents$jspb$utils_SUPPORTS_UINT8ARRAY_SLICING ? e.slice(t, r) : new Uint8Array(e.subarray(t, r))
                }
                let module$contents$jspb$utils_split64Low = 0,
                    module$contents$jspb$utils_split64High = 0,
                    module$contents$jspb$utils_scratchpad;

                function module$contents$jspb$utils_splitUint64(e) {
                    const t = e >>> 0;
                    module$contents$jspb$utils_split64Low = t, module$contents$jspb$utils_split64High = e = (e - t) / module$contents$jspb$BinaryConstants_TWO_TO_32 >>> 0
                }

                function module$contents$jspb$utils_splitInt64(e) {
                    if (0 > e) {
                        module$contents$jspb$utils_splitUint64(0 - e);
                        const [t, r] = module$contents$jspb$utils_negate(module$contents$jspb$utils_split64Low, module$contents$jspb$utils_split64High);
                        module$contents$jspb$utils_split64Low = t >>> 0, module$contents$jspb$utils_split64High = r >>> 0
                    } else module$contents$jspb$utils_splitUint64(e)
                }

                function module$contents$jspb$utils_splitZigzag64(e) {
                    const t = 0 > e;
                    module$contents$jspb$utils_splitUint64(e = 2 * Math.abs(e)), e = module$contents$jspb$utils_split64Low;
                    let r = module$contents$jspb$utils_split64High;
                    t && (0 == e ? 0 == r ? r = e = 4294967295 : (r--, e = 4294967295) : e--), module$contents$jspb$utils_split64Low = e, module$contents$jspb$utils_split64High = r
                }

                function module$contents$jspb$utils_getScratchpad(e) {
                    return (0, goog.asserts.assert)(e <= module$contents$jspb$utils_MAX_SCRATCHPAD_BYTES), module$contents$jspb$utils_scratchpad || = new DataView(new ArrayBuffer(module$contents$jspb$utils_MAX_SCRATCHPAD_BYTES))
                }

                function module$contents$jspb$utils_splitFloat32(e) {
                    const t = module$contents$jspb$utils_getScratchpad(4);
                    t.setFloat32(0, +e, !0), module$contents$jspb$utils_split64High = 0, module$contents$jspb$utils_split64Low = t.getUint32(0, !0)
                }

                function module$contents$jspb$utils_splitFloat64(e) {
                    const t = module$contents$jspb$utils_getScratchpad(8);
                    t.setFloat64(0, +e, !0), module$contents$jspb$utils_split64Low = t.getUint32(0, !0), module$contents$jspb$utils_split64High = t.getUint32(4, !0)
                }

                function module$contents$jspb$utils_splitBytes64(e) {
                    const [t, r, s, o, n, i, a, g] = e;
                    module$contents$jspb$utils_split64Low = t + (r << 8) + (s << 16) + (o << 24) >>> 0, module$contents$jspb$utils_split64High = n + (i << 8) + (a << 16) + (g << 24) >>> 0
                }

                function module$contents$jspb$utils_joinUint64(e, t) {
                    const r = t * module$contents$jspb$BinaryConstants_TWO_TO_32 + (e >>> 0);
                    return Number.isSafeInteger(r) ? r : module$contents$jspb$utils_joinUnsignedDecimalString(e, t)
                }

                function module$contents$jspb$utils_joinInt64(e, t) {
                    const r = 2147483648 & t;
                    return r && (t = ~t >>> 0, 0 == (e = 1 + ~e >>> 0) && (t = t + 1 >>> 0)), "number" == typeof(e = module$contents$jspb$utils_joinUint64(e, t)) ? r ? -e : e : r ? "-" + e : e
                }

                function module$contents$jspb$utils_toZigzag32(e) {
                    return (e << 1 ^ e >> 31) >>> 0
                }

                function module$contents$jspb$utils_toZigzag64(e, t, r) {
                    const s = t >> 31;
                    return t = (t << 1 | e >>> 31) ^ s, r(e = e << 1 ^ s, t)
                }

                function module$contents$jspb$utils_joinZigzag64(e, t) {
                    return module$contents$jspb$utils_fromZigzag64(e, t, module$contents$jspb$utils_joinInt64)
                }

                function module$contents$jspb$utils_fromZigzag32(e) {
                    return e >>> 1 ^ -(1 & e)
                }

                function module$contents$jspb$utils_fromZigzag64(e, t, r) {
                    const s = -(1 & e);
                    return r(e = (e >>> 1 | t << 31) ^ s, t = t >>> 1 ^ s)
                }

                function module$contents$jspb$utils_joinFloat32(e, t) {
                    t = 2 * (e >> 31) + 1;
                    const r = e >>> 23 & 255;
                    return e &= 8388607, 255 == r ? e ? NaN : 1 / 0 * t : 0 == r ? t * Math.pow(2, -149) * e : t * Math.pow(2, r - 150) * (e + Math.pow(2, 23))
                }

                function module$contents$jspb$utils_joinFloat64(e, t) {
                    const r = 2 * (t >> 31) + 1,
                        s = t >>> 20 & 2047;
                    return e = module$contents$jspb$BinaryConstants_TWO_TO_32 * (1048575 & t) + e, 2047 == s ? e ? NaN : 1 / 0 * r : 0 == s ? r * Math.pow(2, -1074) * e : r * Math.pow(2, s - 1075) * (e + module$contents$jspb$BinaryConstants_TWO_TO_52)
                }

                function module$contents$jspb$utils_joinUnsignedDecimalString(e, t) {
                    return e >>>= 0, 2097151 >= (t >>>= 0) ? "" + (module$contents$jspb$BinaryConstants_TWO_TO_32 * t + e) : module$contents$jspb$internal_options_isBigIntAvailable() ? "" + (BigInt(t) << BigInt(32) | BigInt(e)) : module$contents$jspb$utils_joinUnsignedDecimalStringFallback(e, t)
                }

                function module$contents$jspb$utils_joinUnsignedDecimalStringFallback(e, t) {
                    var r = (e >>> 24 | t << 8) & module$contents$jspb$utils_LOW_24_BITS;
                    return e = (e & module$contents$jspb$utils_LOW_24_BITS) + 6777216 * r + 6710656 * (t = t >> 16 & module$contents$jspb$utils_LOW_16_BITS), r += 8147497 * t, t *= 2, 1e7 <= e && (r += e / 1e7 >>> 0, e %= 1e7), 1e7 <= r && (t += r / 1e7 >>> 0, r %= 1e7), (0, goog.asserts.assert)(t), t + module$contents$jspb$utils_decimalFrom1e7WithLeadingZeros(r) + module$contents$jspb$utils_decimalFrom1e7WithLeadingZeros(e)
                }

                function module$contents$jspb$utils_decimalFrom1e7WithLeadingZeros(e) {
                    return e = String(e), "0000000".slice(e.length) + e
                }

                function module$contents$jspb$utils_joinSignedDecimalString(e, t) {
                    return 2147483648 & t ? module$contents$jspb$internal_options_isBigIntAvailable() ? "" + (BigInt(0 | t) << BigInt(32) | BigInt(e >>> 0)) : module$contents$jspb$utils_joinNegativeDecimalStringFallback(e, t) : module$contents$jspb$utils_joinUnsignedDecimalString(e, t)
                }

                function module$contents$jspb$utils_joinSignedNumberOrDecimalString(e, t) {
                    const r = module$contents$jspb$utils_joinInt64(e, t);
                    return Number.isSafeInteger(r) ? r : module$contents$jspb$utils_joinSignedDecimalString(e, t)
                }

                function module$contents$jspb$utils_joinUnsignedNumberOrDecimalString(e, t) {
                    const r = module$contents$jspb$utils_joinUint64(e, t >>>= 0);
                    return Number.isSafeInteger(r) ? r : module$contents$jspb$utils_joinUnsignedDecimalString(e, t)
                }

                function module$contents$jspb$utils_joinNegativeDecimalStringFallback(e, t) {
                    const [r, s] = module$contents$jspb$utils_negate(e, t);
                    return "-" + module$contents$jspb$utils_joinUnsignedDecimalString(e = r, t = s)
                }

                function module$contents$jspb$utils_splitDecimalString(e) {
                    (0, goog.asserts.assert)(0 < e.length), e.length < module$contents$jspb$utils_MAX_SAFE_INTEGER_DECIMAL_LENGTH ? module$contents$jspb$utils_splitInt64(Number(e)) : module$contents$jspb$internal_options_isBigIntAvailable() ? (e = BigInt(e), module$contents$jspb$utils_split64Low = Number(e & BigInt(module$contents$jspb$utils_ALL_32_BITS)) >>> 0, module$contents$jspb$utils_split64High = Number(e >> BigInt(32) & BigInt(module$contents$jspb$utils_ALL_32_BITS))) : module$contents$jspb$utils_splitDecimalStringFallback(e)
                }

                function module$contents$jspb$utils_splitDecimalStringFallback(e) {
                    (0, goog.asserts.assert)(0 < e.length);
                    const t = +("-" === e[0]);
                    module$contents$jspb$utils_split64High = module$contents$jspb$utils_split64Low = 0;
                    const r = e.length;
                    for (let s = 0 + t, o = (r - t) % 6 + t; o <= r; s = o, o += 6) {
                        const t = Number(e.slice(s, o));
                        module$contents$jspb$utils_split64High *= 1e6, module$contents$jspb$utils_split64Low = 1e6 * module$contents$jspb$utils_split64Low + t, module$contents$jspb$utils_split64Low >= module$contents$jspb$BinaryConstants_TWO_TO_32 && (module$contents$jspb$utils_split64High += Math.trunc(module$contents$jspb$utils_split64Low / module$contents$jspb$BinaryConstants_TWO_TO_32), module$contents$jspb$utils_split64High >>>= 0, module$contents$jspb$utils_split64Low >>>= 0)
                    }
                    if (t) {
                        const [e, t] = module$contents$jspb$utils_negate(module$contents$jspb$utils_split64Low, module$contents$jspb$utils_split64High);
                        module$contents$jspb$utils_split64Low = e, module$contents$jspb$utils_split64High = t
                    }
                }

                function module$contents$jspb$utils_negate(e, t) {
                    return t = ~t, e ? e = 1 + ~e : t += 1, [e, t]
                }

                function module$contents$jspb$utils_countVarints(e, t, r) {
                    let s = 0;
                    for (let o = t; o < r; o++) s += e[o] >> 7;
                    return r - t - s
                }

                function module$contents$jspb$utils_countVarintFields(e, t, r, s) {
                    let o = 0;
                    if (128 > (s = 8 * s + module$contents$jspb$BinaryConstants_WireType.VARINT))
                        for (; t < r && e[t++] == s;)
                            for (o++; 128 & e[t++];);
                    else
                        for (; t < r;) {
                            let r = s;
                            for (; 128 < r;) {
                                if (e[t] != (127 & r | 128)) return o;
                                t++, r >>= 7
                            }
                            if (e[t++] != r) break;
                            for (o++; 128 & e[t++];);
                        }
                    return o
                }

                function module$contents$jspb$utils_countFixedFields_(e, t, r, s, o) {
                    let n = 0;
                    if (128 > s)
                        for (; t < r && e[t++] == s;) n++, t += o;
                    else
                        for (; t < r;) {
                            let r = s;
                            for (; 128 < r;) {
                                if (e[t++] != (127 & r | 128)) return n;
                                r >>= 7
                            }
                            if (e[t++] != r) break;
                            n++, t += o
                        }
                    return n
                }

                function module$contents$jspb$utils_countFixed32Fields(e, t, r, s) {
                    return module$contents$jspb$utils_countFixedFields_(e, t, r, 8 * s + module$contents$jspb$BinaryConstants_WireType.FIXED32, 4)
                }

                function module$contents$jspb$utils_countFixed64Fields(e, t, r, s) {
                    return module$contents$jspb$utils_countFixedFields_(e, t, r, 8 * s + module$contents$jspb$BinaryConstants_WireType.FIXED64, 8)
                }

                function module$contents$jspb$utils_countDelimitedFields(e, t, r, s) {
                    let o = 0;
                    for (s = 8 * s + module$contents$jspb$BinaryConstants_WireType.DELIMITED; t < r;) {
                        let r = s;
                        for (; 128 < r;) {
                            if (e[t++] != (127 & r | 128)) return o;
                            r >>= 7
                        }
                        if (e[t++] != r) break;
                        o++;
                        let n = 0,
                            i = 1;
                        for (; r = e[t++], n += (127 & r) * i, i *= 128, 128 & r;);
                        t += n
                    }
                    return o
                }

                function module$contents$jspb$utils_byteSourceToUint8Array(e, t) {
                    if (e.constructor === Uint8Array) return e;
                    if (e.constructor === ArrayBuffer || e.constructor === Array) return new Uint8Array(e);
                    if (e.constructor === String) return (0, goog.crypt.base64.decodeStringToUint8Array)(e);
                    if (e.constructor === module$contents$jspb$bytestring_ByteString) return t ? e.asUint8Array() : module$contents$jspb$unsafe_bytestring_unsafeUint8ArrayFromByteString(e);
                    if (e instanceof Uint8Array) return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
                    throw Error("Type not convertible to a Uint8Array, expected a Uint8Array, an ArrayBuffer, a base64 encoded string, or Array of numbers")
                }

                function module$contents$jspb$utils_getSplit64Low() {
                    return module$contents$jspb$utils_split64Low
                }

                function module$contents$jspb$utils_getSplit64High() {
                    return module$contents$jspb$utils_split64High
                }

                function module$contents$jspb$utils_makeTag(e, t) {
                    return 8 * e + t
                }
                const module$contents$jspb$utils_LOW_16_BITS = 65535,
                    module$contents$jspb$utils_LOW_24_BITS = 16777215,
                    module$contents$jspb$utils_ALL_32_BITS = 4294967295,
                    module$contents$jspb$utils_MAX_SAFE_INTEGER_DECIMAL_LENGTH = 16;
                jspb.utils.byteSourceToUint8Array = module$contents$jspb$utils_byteSourceToUint8Array, jspb.utils.countDelimitedFields = module$contents$jspb$utils_countDelimitedFields, jspb.utils.countFixed32Fields = module$contents$jspb$utils_countFixed32Fields, jspb.utils.countFixed64Fields = module$contents$jspb$utils_countFixed64Fields, jspb.utils.countVarintFields = module$contents$jspb$utils_countVarintFields, jspb.utils.countVarints = module$contents$jspb$utils_countVarints, jspb.utils.fromZigzag32 = module$contents$jspb$utils_fromZigzag32, jspb.utils.fromZigzag64 = module$contents$jspb$utils_fromZigzag64, jspb.utils.getSplit64High = module$contents$jspb$utils_getSplit64High, jspb.utils.getSplit64Low = module$contents$jspb$utils_getSplit64Low, jspb.utils.joinFloat32 = module$contents$jspb$utils_joinFloat32, jspb.utils.joinFloat64 = module$contents$jspb$utils_joinFloat64, jspb.utils.joinInt64 = module$contents$jspb$utils_joinInt64, jspb.utils.joinNegativeDecimalStringFallback = module$contents$jspb$utils_joinNegativeDecimalStringFallback, jspb.utils.joinSignedDecimalString = module$contents$jspb$utils_joinSignedDecimalString, jspb.utils.joinSignedNumberOrDecimalString = module$contents$jspb$utils_joinSignedNumberOrDecimalString, jspb.utils.joinUint64 = module$contents$jspb$utils_joinUint64, jspb.utils.joinUnsignedDecimalString = module$contents$jspb$utils_joinUnsignedDecimalString, jspb.utils.joinUnsignedDecimalStringFallback = module$contents$jspb$utils_joinUnsignedDecimalStringFallback, jspb.utils.joinUnsignedNumberOrDecimalString = module$contents$jspb$utils_joinUnsignedNumberOrDecimalString, jspb.utils.joinZigzag64 = module$contents$jspb$utils_joinZigzag64, jspb.utils.makeTag = module$contents$jspb$utils_makeTag, jspb.utils.sliceUint8Array = module$contents$jspb$utils_sliceUint8Array, jspb.utils.splitDecimalString = module$contents$jspb$utils_splitDecimalString, jspb.utils.splitDecimalStringFallback = module$contents$jspb$utils_splitDecimalStringFallback, jspb.utils.splitFloat32 = module$contents$jspb$utils_splitFloat32, jspb.utils.splitFloat64 = module$contents$jspb$utils_splitFloat64, jspb.utils.splitInt64 = module$contents$jspb$utils_splitInt64, jspb.utils.splitUint64 = module$contents$jspb$utils_splitUint64, jspb.utils.splitZigzag64 = module$contents$jspb$utils_splitZigzag64, jspb.utils.toZigzag32 = module$contents$jspb$utils_toZigzag32, jspb.utils.toZigzag64 = module$contents$jspb$utils_toZigzag64;
                var module$exports$jspb$binary$internal_buffer = {
                    Buffer: class {
                        constructor(e, t, r) {
                            if (this.buffer = e, (this.bufferAsByteStringInternal = r) && !t) throw goog.DEBUG ? Error("Buffer must be immutable if a ByteString is provided.") : Error();
                            this.isImmutable = t
                        }
                        getBufferAsByteStringIfImmutable() {
                            if (!this.isImmutable) throw goog.DEBUG ? Error("Cannot get ByteString from mutable buffer.") : Error();
                            return null == this.buffer ? null : this.bufferAsByteStringInternal ? ? (this.bufferAsByteStringInternal = module$contents$jspb$unsafe_bytestring_unsafeByteStringFromUint8Array(this.buffer))
                        }
                    }
                };

                function module$contents$jspb$binary$internal_buffer_bufferFromSource(e, t) {
                    if ("string" == typeof e) return new module$exports$jspb$binary$internal_buffer.Buffer(module$contents$jspb$internal_bytes_decodeByteArray(e), t);
                    if (Array.isArray(e)) return new module$exports$jspb$binary$internal_buffer.Buffer(new Uint8Array(e), t);
                    if (e.constructor === Uint8Array) return new module$exports$jspb$binary$internal_buffer.Buffer(e, !1);
                    if (e.constructor === ArrayBuffer) return e = new Uint8Array(e), new module$exports$jspb$binary$internal_buffer.Buffer(e, !1);
                    if (e.constructor === module$contents$jspb$bytestring_ByteString) return t = module$contents$jspb$unsafe_bytestring_unsafeUint8ArrayFromByteString(e), new module$exports$jspb$binary$internal_buffer.Buffer(t, !0, e);
                    if (e instanceof Uint8Array) return e = e.constructor === Uint8Array ? e : new Uint8Array(e.buffer, e.byteOffset, e.byteLength), new module$exports$jspb$binary$internal_buffer.Buffer(e, !1);
                    throw goog.DEBUG ? Error("Type not convertible to a Uint8Array, expected a Uint8Array, an ArrayBuffer, a base64 encoded string, a ByteString or an Array of numbers") : Error()
                }
                module$exports$jspb$binary$internal_buffer.bufferFromSource = module$contents$jspb$binary$internal_buffer_bufferFromSource, jspb.binary.decoder = {};
                const module$contents$jspb$binary$decoder_MAX_VARINT_SIZE = 10;
                class module$contents$jspb$binary$decoder_BinaryDecoder {
                    constructor(e, t, r, s) {
                        this.buffer_ = this.bytes_ = null, this.bytesAreImmutable_ = !1, module$contents$jspb$binary$decoder_ASSUME_DATAVIEW_IS_FAST && (this.dataView_ = null), this.cursor_ = this.end_ = this.start_ = 0, this.init(e, t, r, s)
                    }
                    init(e, t, r, {
                        aliasBytesFields: s = !1,
                        treatNewDataAsImmutable: o = !1
                    } = {}) {
                        this.aliasBytesFields = s, this.treatNewDataAsImmutable = o, e && this.setBlock(e, t, r)
                    }
                    static alloc(e, t, r, s) {
                        if (module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_.length) {
                            const o = module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_.pop();
                            return o.init(e, t, r, s), o
                        }
                        return new module$contents$jspb$binary$decoder_BinaryDecoder(e, t, r, s)
                    }
                    free() {
                        this.clear(), 100 > module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_.length && module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_.push(this)
                    }
                    clear() {
                        this.buffer_ = this.bytes_ = null, this.bytesAreImmutable_ = !1, module$contents$jspb$binary$decoder_ASSUME_DATAVIEW_IS_FAST && (this.dataView_ = null), this.cursor_ = this.end_ = this.start_ = 0, this.aliasBytesFields = !1
                    }
                    dataIsImmutable() {
                        return this.bytesAreImmutable_
                    }
                    getBuffer() {
                        if (this.bytesAreImmutable_) throw goog.DEBUG ? Error("cannot access the buffer of decoders over immutable data.") : Error();
                        return this.bytes_
                    }
                    getBufferAsByteString() {
                        if (null == this.buffer_) return null;
                        if (!this.bytesAreImmutable_) throw goog.DEBUG ? Error("cannot access the buffer of decoders over immutable data.") : Error();
                        return this.buffer_.getBufferAsByteStringIfImmutable()
                    }
                    setBlock(e, t, r) {
                        this.buffer_ = e = module$contents$jspb$binary$internal_buffer_bufferFromSource(e, this.treatNewDataAsImmutable), this.bytes_ = e.buffer, this.bytesAreImmutable_ = e.isImmutable, module$contents$jspb$binary$decoder_ASSUME_DATAVIEW_IS_FAST && (this.dataView_ = null), this.start_ = t || 0, this.end_ = void 0 !== r ? this.start_ + r : this.bytes_.length, this.cursor_ = this.start_
                    }
                    getEnd() {
                        return this.end_
                    }
                    setEnd(e) {
                        this.end_ = e
                    }
                    reset() {
                        this.cursor_ = this.start_
                    }
                    getCursor() {
                        return this.cursor_
                    }
                    setCursor(e) {
                        this.cursor_ = e
                    }
                    advance(e) {
                        this.setCursorAndCheck(this.cursor_ + e)
                    }
                    atEnd() {
                        return this.cursor_ == this.end_
                    }
                    pastEnd() {
                        return this.cursor_ > this.end_
                    }
                    static readSplitVarint64(e, t) {
                        let r, s = 0,
                            o = 0,
                            n = 0;
                        const i = e.bytes_;
                        let a = e.cursor_;
                        do {
                            r = i[a++], s |= (127 & r) << n, n += 7
                        } while (32 > n && 128 & r);
                        for (32 < n && (o |= (127 & r) >> 4), n = 3; 32 > n && 128 & r; n += 7) r = i[a++], o |= (127 & r) << n;
                        if (e.setCursorAndCheck(a), 128 > r) return t(s >>> 0, o >>> 0);
                        throw module$contents$jspb$binary$errors_invalidVarintError()
                    }
                    static readSplitZigzagVarint64(e, t) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(e, (e, r) => module$contents$jspb$utils_fromZigzag64(e, r, t))
                    }
                    static readSplitFixed64(e, t) {
                        const r = e.bytes_,
                            s = e.cursor_;
                        e.advance(8);
                        let o = e = 0;
                        for (let t = s + 7; t >= s; t--) e = e << 8 | r[t], o = o << 8 | r[t + 4];
                        return t(e, o)
                    }
                    skipVarint() {
                        module$contents$jspb$binary$decoder_BinaryDecoder.readBool(this)
                    }
                    setCursorAndCheck(e) {
                        if (this.cursor_ = e, e > this.end_) throw module$contents$jspb$binary$errors_readTooFarError(this.end_, e)
                    }
                    static readSignedVarint32(e) {
                        const t = e.bytes_;
                        let r = e.cursor_,
                            s = t[r++],
                            o = 127 & s;
                        if (128 & s && (s = t[r++], o |= (127 & s) << 7, 128 & s && (s = t[r++], o |= (127 & s) << 14, 128 & s && (s = t[r++], o |= (127 & s) << 21, 128 & s && (s = t[r++], o |= s << 28, 128 & s && 128 & t[r++] && 128 & t[r++] && 128 & t[r++] && 128 & t[r++] && 128 & t[r++]))))) throw module$contents$jspb$binary$errors_invalidVarintError();
                        return e.setCursorAndCheck(r), o
                    }
                    static readUnsignedVarint32(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint32(e) >>> 0
                    }
                    readUnsignedVarint32IfEqualTo(e) {
                        goog.asserts.assert(e === e >>> 0);
                        const t = this.cursor_;
                        let r = t;
                        const s = this.end_,
                            o = this.bytes_;
                        for (; r < s;) {
                            if (!(127 < e)) {
                                if (o[r++] === e) return this.cursor_ = r, t;
                                break
                            } {
                                const t = 128 | 127 & e;
                                if (o[r++] !== t) break;
                                e >>>= 7
                            }
                        }
                        return -1
                    }
                    static readZigzagVarint32(e) {
                        return module$contents$jspb$utils_fromZigzag32(module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(e))
                    }
                    static readUnsignedVarint64(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(e, module$contents$jspb$utils_joinUint64)
                    }
                    static readUnsignedVarint64String(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(e, module$contents$jspb$utils_joinUnsignedDecimalString)
                    }
                    static readSignedVarint64(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(e, module$contents$jspb$utils_joinInt64)
                    }
                    static readSignedVarint64String(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(e, module$contents$jspb$utils_joinSignedDecimalString)
                    }
                    static readZigzagVarint64(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(e, module$contents$jspb$utils_joinZigzag64)
                    }
                    static readZigzagVarint64String(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSplitZigzagVarint64(e, module$contents$jspb$utils_joinSignedDecimalString)
                    }
                    static readUint8(e) {
                        const t = e.bytes_[e.cursor_ + 0];
                        return e.advance(1), t
                    }
                    static readUint16(e) {
                        const t = e.bytes_[e.cursor_ + 0],
                            r = e.bytes_[e.cursor_ + 1];
                        return e.advance(2), t | r << 8
                    }
                    static readUint32(e) {
                        var t = e.bytes_;
                        const r = e.cursor_,
                            s = t[r + 0],
                            o = t[r + 1],
                            n = t[r + 2];
                        return t = t[r + 3], e.advance(4), (s | o << 8 | n << 16 | t << 24) >>> 0
                    }
                    static readUint64(e) {
                        return module$contents$jspb$utils_joinUint64(module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e), e = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e))
                    }
                    static readUint64String(e) {
                        return module$contents$jspb$utils_joinUnsignedDecimalString(module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e), e = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e))
                    }
                    static readInt8(e) {
                        const t = e.bytes_[e.cursor_ + 0];
                        return e.advance(1), t << 24 >> 24
                    }
                    static readInt16(e) {
                        const t = e.bytes_[e.cursor_ + 0],
                            r = e.bytes_[e.cursor_ + 1];
                        return e.advance(2), (t | r << 8) << 16 >> 16
                    }
                    static readInt32(e) {
                        var t = e.bytes_;
                        const r = e.cursor_,
                            s = t[r + 0],
                            o = t[r + 1],
                            n = t[r + 2];
                        return t = t[r + 3], e.advance(4), s | o << 8 | n << 16 | t << 24
                    }
                    static readInt64(e) {
                        return module$contents$jspb$utils_joinInt64(module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e), e = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e))
                    }
                    static readInt64String(e) {
                        return module$contents$jspb$utils_joinSignedDecimalString(module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e), e = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e))
                    }
                    static readFloat(e) {
                        return module$contents$jspb$utils_joinFloat32(e = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e), 0)
                    }
                    static readDouble(e) {
                        if (module$contents$jspb$binary$decoder_ASSUME_DATAVIEW_IS_FAST) {
                            var t = e.getDataView().getFloat64(e.cursor_, !0);
                            return e.advance(8), t
                        }
                        return module$contents$jspb$utils_joinFloat64(t = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e), e = module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(e))
                    }
                    readDoubleArrayInto(e, t) {
                        var r = this.cursor_,
                            s = 8 * e;
                        if (r + s > this.end_) throw module$contents$jspb$binary$errors_readTooFarError(s, this.end_ - r);
                        var o = this.bytes_;
                        if (r += o.byteOffset, module$contents$jspb$binary$decoder_ASSUME_DATAVIEW_IS_FAST)
                            for (this.cursor_ += s, e = new DataView(o.buffer, r, s), s = 0; !((o = s + 8) > e.byteLength);) t.push(e.getFloat64(s, !0)), s = o;
                        else if (module$contents$jspb$binary$decoder_OPTIMIZE_LITTLE_ENDIAN_MACHINES && module$contents$jspb$binary$decoder_isLittleEndian())
                            for (this.cursor_ += s, e = new Float64Array(o.buffer.slice(r, r + s)), s = 0; s < e.length; s++) t.push(e[s]);
                        else
                            for (s = 0; s < e; s++) t.push(module$contents$jspb$binary$decoder_BinaryDecoder.readDouble(this))
                    }
                    static readBool(e) {
                        let t = 0,
                            r = e.cursor_;
                        const s = r + module$contents$jspb$binary$decoder_MAX_VARINT_SIZE,
                            o = e.bytes_;
                        for (; r < s;) {
                            const s = o[r++];
                            if (t |= s, !(128 & s)) return e.setCursorAndCheck(r), !!(127 & t)
                        }
                        throw module$contents$jspb$binary$errors_invalidVarintError()
                    }
                    static readEnum(e) {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint32(e)
                    }
                    checkReadLengthAndAdvance(e) {
                        if (0 > e) throw module$contents$jspb$binary$errors_negativeByteLengthError(e);
                        const t = this.cursor_,
                            r = t + e;
                        if (r > this.end_) throw module$contents$jspb$binary$errors_readTooFarError(e, this.end_ - t);
                        return this.cursor_ = r, t
                    }
                    readString(e, t) {
                        const r = this.checkReadLengthAndAdvance(e);
                        return module$contents$jspb$binary$utf8_decodeUtf8(goog.asserts.assert(this.bytes_), r, e, t)
                    }
                    readBytes(e) {
                        const t = this.checkReadLengthAndAdvance(e);
                        return this.aliasBytesFields && !this.bytesAreImmutable_ ? this.bytes_.subarray(t, t + e) : module$contents$jspb$utils_sliceUint8Array(goog.asserts.assert(this.bytes_), t, t + e)
                    }
                    readByteString(e) {
                        if (0 == e) return module$contents$jspb$bytestring_ByteString.empty();
                        const t = this.checkReadLengthAndAdvance(e);
                        return module$contents$jspb$unsafe_bytestring_unsafeByteStringFromUint8Array(e = this.aliasBytesFields && this.bytesAreImmutable_ ? this.bytes_.subarray(t, t + e) : module$contents$jspb$utils_sliceUint8Array(goog.asserts.assert(this.bytes_), t, t + e))
                    }
                    getDataView() {
                        var e = this.dataView_;
                        return e || (e = this.bytes_, e = this.dataView_ = new DataView(e.buffer, e.byteOffset, e.byteLength)), e
                    }
                    static resetInstanceCache() {
                        module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_ = []
                    }
                    static getInstanceCache() {
                        return module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_
                    }
                }

                function module$contents$jspb$binary$decoder_isLittleEndian() {
                    return void 0 === module$contents$jspb$binary$decoder_isLittleEndianCache && (module$contents$jspb$binary$decoder_isLittleEndianCache = 513 == new Uint16Array(new Uint8Array([1, 2]).buffer)[0]), goog.asserts.assertBoolean(module$contents$jspb$binary$decoder_isLittleEndianCache)
                }
                let module$contents$jspb$binary$decoder_isLittleEndianCache;
                goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "getInstanceCache", module$contents$jspb$binary$decoder_BinaryDecoder.getInstanceCache), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "resetInstanceCache", module$contents$jspb$binary$decoder_BinaryDecoder.resetInstanceCache), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "readByteString", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.readByteString), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "readBytes", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.readBytes), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "readString", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.readString), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readEnum", module$contents$jspb$binary$decoder_BinaryDecoder.readEnum), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readBool", module$contents$jspb$binary$decoder_BinaryDecoder.readBool), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "readDoubleArrayInto", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.readDoubleArrayInto), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readDouble", module$contents$jspb$binary$decoder_BinaryDecoder.readDouble), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readFloat", module$contents$jspb$binary$decoder_BinaryDecoder.readFloat), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readInt64String", module$contents$jspb$binary$decoder_BinaryDecoder.readInt64String), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readInt64", module$contents$jspb$binary$decoder_BinaryDecoder.readInt64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readInt32", module$contents$jspb$binary$decoder_BinaryDecoder.readInt32), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readInt16", module$contents$jspb$binary$decoder_BinaryDecoder.readInt16), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readInt8", module$contents$jspb$binary$decoder_BinaryDecoder.readInt8), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUint64String", module$contents$jspb$binary$decoder_BinaryDecoder.readUint64String), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUint64", module$contents$jspb$binary$decoder_BinaryDecoder.readUint64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUint32", module$contents$jspb$binary$decoder_BinaryDecoder.readUint32), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUint16", module$contents$jspb$binary$decoder_BinaryDecoder.readUint16), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUint8", module$contents$jspb$binary$decoder_BinaryDecoder.readUint8), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readZigzagVarint64String", module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint64String), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readZigzagVarint64", module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readSignedVarint64String", module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint64String), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readSignedVarint64", module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUnsignedVarint64String", module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint64String), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUnsignedVarint64", module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readZigzagVarint32", module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint32), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "readUnsignedVarint32IfEqualTo", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.readUnsignedVarint32IfEqualTo), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readUnsignedVarint32", module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readSignedVarint32", module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint32), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "skipVarint", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.skipVarint), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readSplitFixed64", module$contents$jspb$binary$decoder_BinaryDecoder.readSplitFixed64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readSplitZigzagVarint64", module$contents$jspb$binary$decoder_BinaryDecoder.readSplitZigzagVarint64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "readSplitVarint64", module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "pastEnd", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.pastEnd), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "atEnd", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.atEnd), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "advance", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.advance), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "setCursor", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.setCursor), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "getCursor", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.getCursor), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "reset", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.reset), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "setEnd", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.setEnd), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "getEnd", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.getEnd), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "setBlock", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.setBlock), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "getBufferAsByteString", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.getBufferAsByteString), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "getBuffer", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.getBuffer), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "dataIsImmutable", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.dataIsImmutable), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "clear", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.clear), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder.prototype, "free", module$contents$jspb$binary$decoder_BinaryDecoder.prototype.free), goog.exportProperty(module$contents$jspb$binary$decoder_BinaryDecoder, "alloc", module$contents$jspb$binary$decoder_BinaryDecoder.alloc), module$contents$jspb$binary$decoder_BinaryDecoder.instanceCache_ = [];
                const module$contents$jspb$binary$decoder_ASSUME_DATAVIEW_IS_FAST = 2019 <= goog.FEATURESET_YEAR,
                    module$contents$jspb$binary$decoder_OPTIMIZE_LITTLE_ENDIAN_MACHINES = !0;
                jspb.binary.decoder.BinaryDecoder = module$contents$jspb$binary$decoder_BinaryDecoder, jspb.binary.reader = {};
                const module$contents$jspb$binary$reader_ENFORCE_UTF8 = "ALWAYS";
                goog.asserts.assert("DEPRECATED_PROTO3_ONLY" === module$contents$jspb$binary$reader_ENFORCE_UTF8 || "ALWAYS" === module$contents$jspb$binary$reader_ENFORCE_UTF8);
                const module$contents$jspb$binary$reader_UTF8_PARSING_ERRORS_ARE_FATAL = "ALWAYS" === module$contents$jspb$binary$reader_ENFORCE_UTF8;
                class module$contents$jspb$binary$reader_BinaryReaderOptions {
                    constructor() {}
                }
                class module$contents$jspb$binary$reader_BinaryReader {
                    constructor(e, t, r, s) {
                        this.decoder_ = module$contents$jspb$binary$decoder_BinaryDecoder.alloc(e, t, r, s), this.fieldCursor_ = this.decoder_.getCursor(), this.nextField_ = module$contents$jspb$BinaryConstants_INVALID_FIELD_NUMBER, this.nextTag_ = module$contents$jspb$BinaryConstants_INVALID_TAG, this.nextWireType_ = module$contents$jspb$BinaryConstants_WireType.INVALID, this.setOptions(s)
                    }
                    setOptions({
                        discardUnknownFields: e = !1
                    } = {}) {
                        this.discardUnknownFields = e
                    }
                    static alloc(e, t, r, s) {
                        if (module$contents$jspb$binary$reader_BinaryReader.instanceCache_.length) {
                            const o = module$contents$jspb$binary$reader_BinaryReader.instanceCache_.pop();
                            return o.setOptions(s), o.decoder_.init(e, t, r, s), o
                        }
                        return new module$contents$jspb$binary$reader_BinaryReader(e, t, r, s)
                    }
                    free() {
                        this.decoder_.clear(), this.nextTag_ = module$contents$jspb$BinaryConstants_INVALID_TAG, this.nextField_ = module$contents$jspb$BinaryConstants_INVALID_FIELD_NUMBER, this.nextWireType_ = module$contents$jspb$BinaryConstants_WireType.INVALID, 100 > module$contents$jspb$binary$reader_BinaryReader.instanceCache_.length && module$contents$jspb$binary$reader_BinaryReader.instanceCache_.push(this)
                    }
                    getFieldCursor() {
                        return this.fieldCursor_
                    }
                    getCursor() {
                        return this.decoder_.getCursor()
                    }
                    dataIsImmutable() {
                        return this.decoder_.dataIsImmutable()
                    }
                    getBuffer() {
                        return this.decoder_.getBuffer()
                    }
                    getBufferAsByteString() {
                        return this.decoder_.getBufferAsByteString()
                    }
                    getTag() {
                        return this.nextTag_
                    }
                    getFieldNumber() {
                        return this.nextField_
                    }
                    getWireType() {
                        return this.nextWireType_
                    }
                    isEndGroup() {
                        return this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.END_GROUP
                    }
                    isDelimited() {
                        return this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED
                    }
                    reset() {
                        this.decoder_.reset(), this.fieldCursor_ = this.decoder_.getCursor(), this.nextTag_ = module$contents$jspb$BinaryConstants_INVALID_TAG, this.nextField_ = module$contents$jspb$BinaryConstants_INVALID_FIELD_NUMBER, this.nextWireType_ = module$contents$jspb$BinaryConstants_WireType.INVALID
                    }
                    advance(e) {
                        this.decoder_.advance(e)
                    }
                    nextField() {
                        if (this.decoder_.atEnd()) return !1;
                        this.assertPriorFieldWasRead(), this.fieldCursor_ = this.decoder_.getCursor();
                        const e = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_),
                            t = module$contents$jspb$binary$reader_parseFieldNumber(e),
                            r = module$contents$jspb$binary$reader_parseWireType(e);
                        if (!module$contents$jspb$BinaryConstants_isValidWireType(r)) throw module$contents$jspb$binary$errors_invalidWireTypeError(r, this.fieldCursor_);
                        if (1 > t) throw module$contents$jspb$binary$errors_invalidFieldNumberError(t, this.fieldCursor_);
                        return this.nextTag_ = e, this.nextField_ = t, this.nextWireType_ = r, !0
                    }
                    nextFieldIfTagEqualTo(e) {
                        this.assertPriorFieldWasRead(), goog.asserts.assert(module$contents$jspb$BinaryConstants_isValidWireType(module$contents$jspb$binary$reader_parseWireType(e)) && 0 < module$contents$jspb$binary$reader_parseFieldNumber(e), "Must pass a valid tag.");
                        const t = this.decoder_.readUnsignedVarint32IfEqualTo(e),
                            r = 0 <= t;
                        return r && (this.fieldCursor_ = t, this.nextTag_ = e, this.nextField_ = module$contents$jspb$binary$reader_parseFieldNumber(e), this.nextWireType_ = module$contents$jspb$binary$reader_parseWireType(e)), r
                    }
                    assertPriorFieldWasRead() {
                        if (goog.asserts.ENABLE_ASSERTS && this.nextTag_ !== module$contents$jspb$BinaryConstants_INVALID_TAG) {
                            const e = this.decoder_.getCursor();
                            this.decoder_.setCursor(this.fieldCursor_), module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_), this.nextWireType_ === module$contents$jspb$BinaryConstants_WireType.END_GROUP || this.nextWireType_ === module$contents$jspb$BinaryConstants_WireType.START_GROUP ? goog.asserts.assert(e === this.decoder_.getCursor(), "Expected to not advance the cursor.  Group tags do not have values.") : goog.asserts.assert(e > this.decoder_.getCursor(), "Expected to read the field, did you forget to call a read or skip method?"), this.decoder_.setCursor(e)
                        }
                    }
                    skipVarintField() {
                        this.nextWireType_ != module$contents$jspb$BinaryConstants_WireType.VARINT ? (goog.asserts.fail("Invalid wire type for skipVarintField"), this.skipField()) : this.decoder_.skipVarint()
                    }
                    skipDelimitedField() {
                        if (this.nextWireType_ != module$contents$jspb$BinaryConstants_WireType.DELIMITED) return goog.asserts.fail("Invalid wire type for skipDelimitedField"), this.skipField(), 0;
                        const e = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_);
                        return this.decoder_.advance(e), e
                    }
                    skipFixed32Field() {
                        goog.asserts.assert(this.nextWireType_ === module$contents$jspb$BinaryConstants_WireType.FIXED32), this.decoder_.advance(4)
                    }
                    skipFixed64Field() {
                        goog.asserts.assert(this.nextWireType_ === module$contents$jspb$BinaryConstants_WireType.FIXED64), this.decoder_.advance(8)
                    }
                    skipGroup() {
                        const e = this.nextField_;
                        for (;;) {
                            if (!this.nextField()) throw module$contents$jspb$binary$errors_unmatchedStartGroupEofError();
                            if (this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.END_GROUP) {
                                if (this.nextField_ != e) throw module$contents$jspb$binary$errors_unmatchedStartGroupError();
                                break
                            }
                            this.skipField()
                        }
                    }
                    skipField() {
                        switch (this.nextWireType_) {
                            case module$contents$jspb$BinaryConstants_WireType.VARINT:
                                this.skipVarintField();
                                break;
                            case module$contents$jspb$BinaryConstants_WireType.FIXED64:
                                this.skipFixed64Field();
                                break;
                            case module$contents$jspb$BinaryConstants_WireType.DELIMITED:
                                this.skipDelimitedField();
                                break;
                            case module$contents$jspb$BinaryConstants_WireType.FIXED32:
                                this.skipFixed32Field();
                                break;
                            case module$contents$jspb$BinaryConstants_WireType.START_GROUP:
                                this.skipGroup();
                                break;
                            default:
                                throw module$contents$jspb$binary$errors_invalidWireTypeError(this.nextWireType_, this.fieldCursor_)
                        }
                    }
                    skipToEnd() {
                        this.decoder_.setCursor(this.decoder_.getEnd())
                    }
                    readUnknownField() {
                        const e = this.getFieldCursor();
                        return this.skipField(), this.readUnknownFieldsStartingFrom(e)
                    }
                    readUnknownFieldsStartingFrom(e) {
                        if (!this.discardUnknownFields) {
                            const t = this.decoder_.getCursor(),
                                r = t - e;
                            return this.decoder_.setCursor(e), e = this.decoder_.readByteString(r), goog.asserts.assert(t == this.decoder_.getCursor()), e
                        }
                    }
                    readAny(e) {
                        if (module$contents$jspb$BinaryConstants_FieldTypeToWireType(e) !== this.nextWireType_) return null;
                        const t = module$contents$jspb$BinaryConstants_FieldType;
                        switch (e) {
                            case t.DOUBLE:
                                return this.readDouble();
                            case t.FLOAT:
                                return this.readFloat();
                            case t.INT64:
                                return this.readInt64();
                            case t.UINT64:
                                return this.readUint64();
                            case t.INT32:
                                return this.readInt32();
                            case t.FIXED64:
                                return this.readFixed64();
                            case t.FIXED32:
                                return this.readFixed32();
                            case t.BOOL:
                                return this.readBool();
                            case t.STRING:
                                return this.readString();
                            case t.GROUP:
                                goog.asserts.fail("Group field type not supported in readAny()");
                            case t.MESSAGE:
                                goog.asserts.fail("Message field type not supported in readAny()");
                            case t.BYTES:
                                return this.readBytes();
                            case t.UINT32:
                                return this.readUint32();
                            case t.ENUM:
                                return this.readEnum();
                            case t.SFIXED32:
                                return this.readSfixed32();
                            case t.SFIXED64:
                                return this.readSfixed64();
                            case t.SINT32:
                                return this.readSint32();
                            case t.SINT64:
                                return this.readSint64();
                            default:
                                goog.asserts.fail("Invalid field type in readAny()")
                        }
                        return null
                    }
                    readMessage(e, t, r, s, o) {
                        goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED);
                        const n = this.decoder_.getEnd(),
                            i = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_),
                            a = this.decoder_.getCursor() + i;
                        let g = a - n;
                        if (0 >= g && (this.decoder_.setEnd(a), t(e, this, r, s, o), g = a - this.decoder_.getCursor()), g) throw module$contents$jspb$binary$errors_messageLengthMismatchError(i, i - g);
                        return this.decoder_.setCursor(a), this.decoder_.setEnd(n), e
                    }
                    readGroup(e, t, r) {
                        if (goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.START_GROUP), goog.asserts.assert(this.nextField_ == e), r(t, this), this.nextWireType_ !== module$contents$jspb$BinaryConstants_WireType.END_GROUP) throw module$contents$jspb$binary$errors_groupDidNotEndWithEndGroupError();
                        if (this.nextField_ !== e) throw module$contents$jspb$binary$errors_unmatchedStartGroupError();
                        return t
                    }
                    isMessageSetGroup() {
                        return this.getTag() === module$contents$jspb$binary$reader_MESSAGE_SET_START_GROUP_TAG
                    }
                    readMessageSetGroup(e) {
                        goog.asserts.assert(this.isMessageSetGroup());
                        let t = 0,
                            r = 0;
                        for (; this.nextField() && !this.isEndGroup();) this.getTag() !== module$contents$jspb$binary$reader_MESSAGE_SET_TYPE_ID_TAG || t ? this.getTag() !== module$contents$jspb$binary$reader_MESSAGE_SET_MESSAGE_TAG || r ? this.skipField() : t ? (r = -1, this.readMessage(t, e)) : (r = this.getFieldCursor(), this.skipDelimitedField()) : (t = this.readUint32(), r && (goog.asserts.assert(0 < r), goog.asserts.ENABLE_ASSERTS && (this.nextTag_ = module$contents$jspb$BinaryConstants_INVALID_TAG, this.nextWireType_ = module$contents$jspb$BinaryConstants_WireType.INVALID), this.decoder_.setCursor(r), r = 0));
                        if (this.getTag() !== module$contents$jspb$binary$reader_MESSAGE_SET_END_TAG || !r || !t) throw module$contents$jspb$binary$errors_malformedBinaryBytesForMessageSet()
                    }
                    readInt32() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint32(this.decoder_)
                    }
                    readInt64() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint64(this.decoder_)
                    }
                    readInt64String() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint64String(this.decoder_)
                    }
                    readUint32() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_)
                    }
                    readUint64() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint64(this.decoder_)
                    }
                    readUint64String() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint64String(this.decoder_)
                    }
                    readSint32() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint32(this.decoder_)
                    }
                    readSint64() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint64(this.decoder_)
                    }
                    readSint64String() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint64String(this.decoder_)
                    }
                    readFixed32() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED32), module$contents$jspb$binary$decoder_BinaryDecoder.readUint32(this.decoder_)
                    }
                    readFixed64() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED64), module$contents$jspb$binary$decoder_BinaryDecoder.readUint64(this.decoder_)
                    }
                    readFixed64String() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED64), module$contents$jspb$binary$decoder_BinaryDecoder.readUint64String(this.decoder_)
                    }
                    readSfixed32() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED32), module$contents$jspb$binary$decoder_BinaryDecoder.readInt32(this.decoder_)
                    }
                    readSfixed32String() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED32), module$contents$jspb$binary$decoder_BinaryDecoder.readInt32(this.decoder_).toString()
                    }
                    readSfixed64() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED64), module$contents$jspb$binary$decoder_BinaryDecoder.readInt64(this.decoder_)
                    }
                    readSfixed64String() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED64), module$contents$jspb$binary$decoder_BinaryDecoder.readInt64String(this.decoder_)
                    }
                    readFloat() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED32), module$contents$jspb$binary$decoder_BinaryDecoder.readFloat(this.decoder_)
                    }
                    readDouble() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED64), module$contents$jspb$binary$decoder_BinaryDecoder.readDouble(this.decoder_)
                    }
                    readBool() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readBool(this.decoder_)
                    }
                    readEnum() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint32(this.decoder_)
                    }
                    readString() {
                        if (module$contents$jspb$binary$reader_UTF8_PARSING_ERRORS_ARE_FATAL) return this.readStringRequireUtf8();
                        goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED);
                        const e = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_);
                        return this.decoder_.readString(e, !1)
                    }
                    readStringRequireUtf8() {
                        goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED);
                        const e = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_);
                        return this.decoder_.readString(e, !0)
                    }
                    readBytes() {
                        goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED);
                        const e = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_);
                        return this.decoder_.readBytes(e)
                    }
                    readByteString() {
                        goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED);
                        const e = module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_);
                        return this.decoder_.readByteString(e)
                    }
                    readSplitVarint64(e) {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(this.decoder_, e)
                    }
                    readSplitZigzagVarint64(e) {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.VARINT), module$contents$jspb$binary$decoder_BinaryDecoder.readSplitVarint64(this.decoder_, (t, r) => module$contents$jspb$utils_fromZigzag64(t, r, e))
                    }
                    readSplitFixed64(e) {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.FIXED64), module$contents$jspb$binary$decoder_BinaryDecoder.readSplitFixed64(this.decoder_, e)
                    }
                    readPackedFieldInto_(e, t) {
                        var r = this.readPackedFieldLength_();
                        for (r = this.decoder_.getCursor() + r; this.decoder_.getCursor() < r;) t.push(e(this.decoder_))
                    }
                    readPackedFieldLength_() {
                        return goog.asserts.assert(this.nextWireType_ == module$contents$jspb$BinaryConstants_WireType.DELIMITED), module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32(this.decoder_)
                    }
                    readPackableInt32Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint32, e) : e.push(this.readInt32())
                    }
                    readPackableInt64Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint64, e) : e.push(this.readInt64())
                    }
                    readPackableInt64StringInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readSignedVarint64String, e) : e.push(this.readInt64String())
                    }
                    readPackableUint32Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint32, e) : e.push(this.readUint32())
                    }
                    readPackableUint64Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint64, e) : e.push(this.readUint64())
                    }
                    readPackableUint64StringInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readUnsignedVarint64String, e) : e.push(this.readUint64String())
                    }
                    readPackableSint32Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint32, e) : e.push(this.readSint32())
                    }
                    readPackableSint64Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint64, e) : e.push(this.readSint64())
                    }
                    readPackableSint64StringInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readZigzagVarint64String, e) : e.push(this.readSint64String())
                    }
                    readPackableFixed32Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readUint32, e) : e.push(this.readFixed32())
                    }
                    readPackableFixed64Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readUint64, e) : e.push(this.readFixed64())
                    }
                    readPackableFixed64StringInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readUint64String, e) : e.push(this.readFixed64String())
                    }
                    readPackableSfixed32Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readInt32, e) : e.push(this.readSfixed32())
                    }
                    readPackableSfixed64Into(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readInt64, e) : e.push(this.readSfixed64())
                    }
                    readPackableSfixed64StringInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readInt64String, e) : e.push(this.readSfixed64String())
                    }
                    readPackedFixed32() {
                        const e = [];
                        return this.readPackableFixed32Into(e), e
                    }
                    readPackedFixed64() {
                        const e = [];
                        return this.readPackableFixed64Into(e), e
                    }
                    readPackedFixed64String() {
                        const e = [];
                        return this.readPackableFixed64StringInto(e), e
                    }
                    readPackedSfixed32() {
                        const e = [];
                        return this.readPackableSfixed32Into(e), e
                    }
                    readPackedSfixed64String() {
                        const e = [];
                        return this.readPackableSfixed64StringInto(e), e
                    }
                    readPackableFloatInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readFloat, e) : e.push(this.readFloat())
                    }
                    readPackableDoubleInto(e) {
                        this.isDelimited() ? this.decoder_.readDoubleArrayInto(this.readPackedFieldLength_() / 8, e) : e.push(this.readDouble())
                    }
                    readPackableBoolInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readBool, e) : e.push(this.readBool())
                    }
                    readPackableEnumInto(e) {
                        this.isDelimited() ? this.readPackedFieldInto_(module$contents$jspb$binary$decoder_BinaryDecoder.readEnum, e) : e.push(this.readEnum())
                    }
                    static resetInstanceCache() {
                        module$contents$jspb$binary$reader_BinaryReader.instanceCache_ = []
                    }
                    static getInstanceCache() {
                        return module$contents$jspb$binary$reader_BinaryReader.instanceCache_
                    }
                }

                function module$contents$jspb$binary$reader_parseWireType(e) {
                    return 7 & e
                }

                function module$contents$jspb$binary$reader_parseFieldNumber(e) {
                    return e >>> 3
                }
                goog.exportProperty(module$contents$jspb$binary$reader_BinaryReader.prototype, "readPackedSfixed64String", module$contents$jspb$binary$reader_BinaryReader.prototype.readPackedSfixed64String), goog.exportProperty(module$contents$jspb$binary$reader_BinaryReader.prototype, "readPackedSfixed32", module$contents$jspb$binary$reader_BinaryReader.prototype.readPackedSfixed32), goog.exportProperty(module$contents$jspb$binary$reader_BinaryReader.prototype, "readPackedFixed64String", module$contents$jspb$binary$reader_BinaryReader.prototype.readPackedFixed64String), goog.exportProperty(module$contents$jspb$binary$reader_BinaryReader.prototype, "readPackedFixed64", module$contents$jspb$binary$reader_BinaryReader.prototype.readPackedFixed64), goog.exportProperty(module$contents$jspb$binary$reader_BinaryReader.prototype, "readPackedFixed32", module$contents$jspb$binary$reader_BinaryReader.prototype.readPackedFixed32), module$contents$jspb$binary$reader_BinaryReader.instanceCache_ = [];
                const module$contents$jspb$binary$reader_MESSAGE_SET_START_GROUP_TAG = module$contents$jspb$utils_makeTag(module$contents$jspb$BinaryConstants_MESSAGE_SET_GROUP_NUMBER, module$contents$jspb$BinaryConstants_WireType.START_GROUP),
                    module$contents$jspb$binary$reader_MESSAGE_SET_TYPE_ID_TAG = module$contents$jspb$utils_makeTag(module$contents$jspb$BinaryConstants_MESSAGE_SET_TYPE_ID_FIELD_NUMBER, module$contents$jspb$BinaryConstants_WireType.VARINT),
                    module$contents$jspb$binary$reader_MESSAGE_SET_MESSAGE_TAG = module$contents$jspb$utils_makeTag(module$contents$jspb$BinaryConstants_MESSAGE_SET_MESSAGE_FIELD_NUMBER, module$contents$jspb$BinaryConstants_WireType.DELIMITED),
                    module$contents$jspb$binary$reader_MESSAGE_SET_END_TAG = module$contents$jspb$utils_makeTag(module$contents$jspb$BinaryConstants_MESSAGE_SET_GROUP_NUMBER, module$contents$jspb$BinaryConstants_WireType.END_GROUP);
                jspb.binary.reader.BinaryReader = module$contents$jspb$binary$reader_BinaryReader, jspb.binary.reader.BinaryReaderOptions = module$contents$jspb$binary$reader_BinaryReaderOptions, jspb.binary.reader.UTF8_PARSING_ERRORS_ARE_FATAL = module$contents$jspb$binary$reader_UTF8_PARSING_ERRORS_ARE_FATAL, jspb.ExtensionFieldInfo = function(e, t, r, s, o) {
                    this.fieldIndex = e, this.fieldName = t, this.ctor = r, this.toObjectFn = s, this.isRepeated = o
                }, goog.exportSymbol("jspb.ExtensionFieldInfo", jspb.ExtensionFieldInfo), jspb.ExtensionFieldBinaryInfo = function(e, t, r, s, o, n) {
                    this.fieldInfo = e, this.binaryReaderFn = t, this.binaryWriterFn = r, this.binaryMessageSerializeFn = s, this.binaryMessageDeserializeFn = o, this.isPacked = n
                }, goog.exportSymbol("jspb.ExtensionFieldBinaryInfo", jspb.ExtensionFieldBinaryInfo), jspb.ExtensionFieldInfo.prototype.isMessageType = function() {
                    return !!this.ctor
                }, goog.exportProperty(jspb.ExtensionFieldInfo.prototype, "isMessageType", jspb.ExtensionFieldInfo.prototype.isMessageType), jspb.Message = function() {}, goog.exportSymbol("jspb.Message", jspb.Message), jspb.Message.GENERATE_TO_OBJECT = !0, goog.exportProperty(jspb.Message, "GENERATE_TO_OBJECT", jspb.Message.GENERATE_TO_OBJECT), jspb.Message.GENERATE_FROM_OBJECT = !goog.DISALLOW_TEST_ONLY_CODE, goog.exportProperty(jspb.Message, "GENERATE_FROM_OBJECT", jspb.Message.GENERATE_FROM_OBJECT), jspb.Message.GENERATE_TO_STRING = !0, jspb.Message.ASSUME_LOCAL_ARRAYS = !1, jspb.Message.SERIALIZE_EMPTY_TRAILING_FIELDS = !0, jspb.Message.SUPPORTS_UINT8ARRAY_ = "function" == typeof Uint8Array, jspb.Message.prototype.getJsPbMessageId = function() {
                    return this.messageId_
                }, goog.exportProperty(jspb.Message.prototype, "getJsPbMessageId", jspb.Message.prototype.getJsPbMessageId), jspb.Message.getIndex_ = function(e, t) {
                    return t + e.arrayIndexOffset_
                }, jspb.Message.hiddenES6Property_ = class {}, jspb.Message.getFieldNumber_ = function(e, t) {
                    return t - e.arrayIndexOffset_
                }, jspb.Message.initialize = function(e, t, r, s, o, n) {
                    if (e.wrappers_ = null, t || = r ? [r] : [], e.messageId_ = r ? String(r) : void 0, e.arrayIndexOffset_ = 0 === r ? -1 : 0, e.array = t, jspb.Message.initPivotAndExtensionObject_(e, s), e.convertedPrimitiveFields_ = {}, jspb.Message.SERIALIZE_EMPTY_TRAILING_FIELDS || (e.repeatedFields = o), o)
                        for (t = 0; t < o.length; t++)(r = o[t]) < e.pivot_ ? (r = jspb.Message.getIndex_(e, r), e.array[r] = e.array[r] || jspb.Message.EMPTY_LIST_SENTINEL_) : (jspb.Message.maybeInitEmptyExtensionObject_(e), e.extensionObject_[r] = e.extensionObject_[r] || jspb.Message.EMPTY_LIST_SENTINEL_);
                    if (n && n.length)
                        for (t = 0; t < n.length; t++) jspb.Message.computeOneofCase(e, n[t])
                }, goog.exportProperty(jspb.Message, "initialize", jspb.Message.initialize), jspb.Message.EMPTY_LIST_SENTINEL_ = goog.DEBUG && Object.freeze ? Object.freeze([]) : [], jspb.Message.isArray_ = function(e) {
                    return jspb.Message.ASSUME_LOCAL_ARRAYS ? e instanceof Array : Array.isArray(e)
                }, jspb.Message.isExtensionObject_ = function(e) {
                    return !(null === e || "object" != typeof e || jspb.Message.isArray_(e) || jspb.Message.SUPPORTS_UINT8ARRAY_ && e instanceof Uint8Array)
                }, jspb.Message.initPivotAndExtensionObject_ = function(e, t) {
                    var r = e.array.length,
                        s = -1;
                    if (r && (s = r - 1, r = e.array[s], jspb.Message.isExtensionObject_(r))) return e.pivot_ = jspb.Message.getFieldNumber_(e, s), void(e.extensionObject_ = r); - 1 < t ? (e.pivot_ = Math.max(t, jspb.Message.getFieldNumber_(e, s + 1)), e.extensionObject_ = null) : e.pivot_ = Number.MAX_VALUE
                }, jspb.Message.maybeInitEmptyExtensionObject_ = function(e) {
                    var t = jspb.Message.getIndex_(e, e.pivot_);
                    e.array[t] || (e.extensionObject_ = e.array[t] = {})
                }, jspb.Message.toObjectList = function(e, t, r) {
                    for (var s = [], o = 0; o < e.length; o++) s[o] = t.call(e[o], r, e[o]);
                    return s
                }, goog.exportProperty(jspb.Message, "toObjectList", jspb.Message.toObjectList), jspb.Message.toObjectExtension = function(e, t, r, s, o) {
                    for (var n in r) {
                        var i = r[n],
                            a = s.call(e, i);
                        if (null != a) {
                            for (var g in i.fieldName)
                                if (i.fieldName.hasOwnProperty(g)) break;
                            t[g] = i.toObjectFn ? i.isRepeated ? jspb.Message.toObjectList(a, i.toObjectFn, o) : i.toObjectFn(o, a) : a
                        }
                    }
                }, goog.exportProperty(jspb.Message, "toObjectExtension", jspb.Message.toObjectExtension), jspb.Message.serializeBinaryExtensions = function(e, t, r, s) {
                    for (var o in r) {
                        var n = r[o],
                            i = n.fieldInfo;
                        if (!n.binaryWriterFn) throw Error("Message extension present that was generated without binary serialization support");
                        var a = s.call(e, i);
                        if (null != a)
                            if (i.isMessageType()) {
                                if (!n.binaryMessageSerializeFn) throw Error("Message extension present holding submessage without binary support enabled, and message is being serialized to binary format");
                                n.binaryWriterFn.call(t, i.fieldIndex, a, n.binaryMessageSerializeFn)
                            } else n.binaryWriterFn.call(t, i.fieldIndex, a)
                    }
                }, goog.exportProperty(jspb.Message, "serializeBinaryExtensions", jspb.Message.serializeBinaryExtensions), jspb.Message.readBinaryExtension = function(e, t, r, s, o) {
                    var n = r[t.getFieldNumber()];
                    if (n) {
                        if (r = n.fieldInfo, !n.binaryReaderFn) throw Error("Deserializing extension whose generated code does not support binary format");
                        if (r.isMessageType()) {
                            var i = new r.ctor;
                            n.binaryReaderFn.call(t, i, n.binaryMessageDeserializeFn)
                        } else {
                            if (r.isRepeated && n.isPacked) return i = s.call(e, r) ? ? [], n.binaryReaderFn.call(t, i), void o.call(e, r, i);
                            i = n.binaryReaderFn.call(t)
                        }
                        r.isRepeated && !n.isPacked ? (t = s.call(e, r)) ? t.push(i) : o.call(e, r, [i]) : o.call(e, r, i)
                    } else t.skipField()
                }, goog.exportProperty(jspb.Message, "readBinaryExtension", jspb.Message.readBinaryExtension), jspb.Message.getField = function(e, t) {
                    if (t < e.pivot_) {
                        t = jspb.Message.getIndex_(e, t);
                        var r = e.array[t];
                        return r === jspb.Message.EMPTY_LIST_SENTINEL_ ? e.array[t] = [] : r
                    }
                    if (e.extensionObject_) return (r = e.extensionObject_[t]) === jspb.Message.EMPTY_LIST_SENTINEL_ ? e.extensionObject_[t] = [] : r
                }, goog.exportProperty(jspb.Message, "getField", jspb.Message.getField), jspb.Message.getRepeatedField = function(e, t) {
                    return jspb.Message.getField(e, t)
                }, goog.exportProperty(jspb.Message, "getRepeatedField", jspb.Message.getRepeatedField), jspb.Message.getOptionalFloatingPointField = function(e, t) {
                    return null == (e = jspb.Message.getField(e, t)) ? e : +e
                }, goog.exportProperty(jspb.Message, "getOptionalFloatingPointField", jspb.Message.getOptionalFloatingPointField), jspb.Message.getBooleanField = function(e, t) {
                    return null == (e = jspb.Message.getField(e, t)) ? e : !!e
                }, goog.exportProperty(jspb.Message, "getBooleanField", jspb.Message.getBooleanField), jspb.Message.getRepeatedFloatingPointField = function(e, t) {
                    var r = jspb.Message.getRepeatedField(e, t);
                    if (e.convertedPrimitiveFields_ || (e.convertedPrimitiveFields_ = {}), !e.convertedPrimitiveFields_[t]) {
                        for (var s = 0; s < r.length; s++) r[s] = +r[s];
                        e.convertedPrimitiveFields_[t] = !0
                    }
                    return r
                }, goog.exportProperty(jspb.Message, "getRepeatedFloatingPointField", jspb.Message.getRepeatedFloatingPointField), jspb.Message.getRepeatedBooleanField = function(e, t) {
                    var r = jspb.Message.getRepeatedField(e, t);
                    if (e.convertedPrimitiveFields_ || (e.convertedPrimitiveFields_ = {}), !e.convertedPrimitiveFields_[t]) {
                        for (var s = 0; s < r.length; s++) r[s] = !!r[s];
                        e.convertedPrimitiveFields_[t] = !0
                    }
                    return r
                }, goog.exportProperty(jspb.Message, "getRepeatedBooleanField", jspb.Message.getRepeatedBooleanField), jspb.Message.bytesAsB64 = function(e) {
                    return null == e || "string" == typeof e ? e : jspb.Message.SUPPORTS_UINT8ARRAY_ && e instanceof Uint8Array ? goog.crypt.base64.encodeByteArray(e) : (jspb.asserts.fail("Cannot coerce to b64 string: " + goog.typeOf(e)), null)
                }, goog.exportProperty(jspb.Message, "bytesAsB64", jspb.Message.bytesAsB64), jspb.Message.bytesAsU8 = function(e) {
                    return null == e || e instanceof Uint8Array ? e : "string" == typeof e ? goog.crypt.base64.decodeStringToUint8Array(e) : (jspb.asserts.fail("Cannot coerce to Uint8Array: " + goog.typeOf(e)), null)
                }, goog.exportProperty(jspb.Message, "bytesAsU8", jspb.Message.bytesAsU8), jspb.Message.bytesListAsB64 = function(e) {
                    return jspb.Message.assertConsistentTypes_(e), e.length && "string" != typeof e[0] ? module$contents$goog$array_map(e, jspb.Message.bytesAsB64) : e
                }, goog.exportProperty(jspb.Message, "bytesListAsB64", jspb.Message.bytesListAsB64), jspb.Message.bytesListAsU8 = function(e) {
                    return jspb.Message.assertConsistentTypes_(e), !e.length || e[0] instanceof Uint8Array ? e : module$contents$goog$array_map(e, jspb.Message.bytesAsU8)
                }, goog.exportProperty(jspb.Message, "bytesListAsU8", jspb.Message.bytesListAsU8), jspb.Message.assertConsistentTypes_ = function(e) {
                    if (goog.DEBUG && e && 1 < e.length) {
                        var t = goog.typeOf(e[0]);
                        module$contents$goog$array_forEach(e, function(e) {
                            goog.typeOf(e) != t && jspb.asserts.fail("Inconsistent type in JSPB repeated field array. Got " + goog.typeOf(e) + " expected " + t)
                        })
                    }
                }, jspb.Message.getFieldWithDefault = function(e, t, r) {
                    return null == (e = jspb.Message.getField(e, t)) ? r : e
                }, goog.exportProperty(jspb.Message, "getFieldWithDefault", jspb.Message.getFieldWithDefault), jspb.Message.getBooleanFieldWithDefault = function(e, t, r) {
                    return null == (e = jspb.Message.getBooleanField(e, t)) ? r : e
                }, goog.exportProperty(jspb.Message, "getBooleanFieldWithDefault", jspb.Message.getBooleanFieldWithDefault), jspb.Message.getFloatingPointFieldWithDefault = function(e, t, r) {
                    return null == (e = jspb.Message.getOptionalFloatingPointField(e, t)) ? r : e
                }, goog.exportProperty(jspb.Message, "getFloatingPointFieldWithDefault", jspb.Message.getFloatingPointFieldWithDefault), jspb.Message.getFieldProto3 = jspb.Message.getFieldWithDefault, goog.exportProperty(jspb.Message, "getFieldProto3", jspb.Message.getFieldProto3), jspb.Message.getMapField = function(e, t, r, s) {
                    if (e.wrappers_ || (e.wrappers_ = {}), t in e.wrappers_) return e.wrappers_[t];
                    var o = jspb.Message.getField(e, t);
                    if (!o) {
                        if (r) return;
                        o = [], jspb.Message.setField(e, t, o)
                    }
                    return e.wrappers_[t] = new jspb.Map(o, s)
                }, goog.exportProperty(jspb.Message, "getMapField", jspb.Message.getMapField), jspb.Message.setField = function(e, t, r) {
                    return jspb.asserts.assertInstanceof(e, jspb.Message), t < e.pivot_ ? e.array[jspb.Message.getIndex_(e, t)] = r : (jspb.Message.maybeInitEmptyExtensionObject_(e), e.extensionObject_[t] = r), e
                }, goog.exportProperty(jspb.Message, "setField", jspb.Message.setField), jspb.Message.setProto3IntField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, 0)
                }, goog.exportProperty(jspb.Message, "setProto3IntField", jspb.Message.setProto3IntField), jspb.Message.setProto3FloatField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, 0)
                }, goog.exportProperty(jspb.Message, "setProto3FloatField", jspb.Message.setProto3FloatField), jspb.Message.setProto3BooleanField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, !1)
                }, goog.exportProperty(jspb.Message, "setProto3BooleanField", jspb.Message.setProto3BooleanField), jspb.Message.setProto3StringField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, "")
                }, goog.exportProperty(jspb.Message, "setProto3StringField", jspb.Message.setProto3StringField), jspb.Message.setProto3BytesField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, "")
                }, goog.exportProperty(jspb.Message, "setProto3BytesField", jspb.Message.setProto3BytesField), jspb.Message.setProto3EnumField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, 0)
                }, goog.exportProperty(jspb.Message, "setProto3EnumField", jspb.Message.setProto3EnumField), jspb.Message.setProto3StringIntField = function(e, t, r) {
                    return jspb.Message.setFieldIgnoringDefault_(e, t, r, "0")
                }, goog.exportProperty(jspb.Message, "setProto3StringIntField", jspb.Message.setProto3StringIntField), jspb.Message.setFieldIgnoringDefault_ = function(e, t, r, s) {
                    return jspb.asserts.assertInstanceof(e, jspb.Message), r !== s ? jspb.Message.setField(e, t, r) : t < e.pivot_ ? e.array[jspb.Message.getIndex_(e, t)] = null : (jspb.Message.maybeInitEmptyExtensionObject_(e), delete e.extensionObject_[t]), e
                }, jspb.Message.addToRepeatedField = function(e, t, r, s) {
                    return jspb.asserts.assertInstanceof(e, jspb.Message), t = jspb.Message.getRepeatedField(e, t), null != s ? t.splice(s, 0, r) : t.push(r), e
                }, goog.exportProperty(jspb.Message, "addToRepeatedField", jspb.Message.addToRepeatedField), jspb.Message.setOneofField = function(e, t, r, s) {
                    return jspb.asserts.assertInstanceof(e, jspb.Message), (r = jspb.Message.computeOneofCase(e, r)) && r !== t && void 0 !== s && (e.wrappers_ && r in e.wrappers_ && (e.wrappers_[r] = void 0), jspb.Message.setField(e, r, void 0)), jspb.Message.setField(e, t, s)
                }, goog.exportProperty(jspb.Message, "setOneofField", jspb.Message.setOneofField), jspb.Message.computeOneofCase = function(e, t) {
                    for (var r, s, o = 0; o < t.length; o++) {
                        var n = t[o],
                            i = jspb.Message.getField(e, n);
                        null != i && (r = n, s = i, jspb.Message.setField(e, n, void 0))
                    }
                    return r ? (jspb.Message.setField(e, r, s), r) : 0
                }, goog.exportProperty(jspb.Message, "computeOneofCase", jspb.Message.computeOneofCase), jspb.Message.getWrapperField = function(e, t, r, s) {
                    if (e.wrappers_ || (e.wrappers_ = {}), !e.wrappers_[r]) {
                        var o = jspb.Message.getField(e, r);
                        (s || o) && (e.wrappers_[r] = new t(o))
                    }
                    return e.wrappers_[r]
                }, goog.exportProperty(jspb.Message, "getWrapperField", jspb.Message.getWrapperField), jspb.Message.getRepeatedWrapperField = function(e, t, r) {
                    return jspb.Message.wrapRepeatedField_(e, t, r), (t = e.wrappers_[r]) == jspb.Message.EMPTY_LIST_SENTINEL_ && (t = e.wrappers_[r] = []), t
                }, goog.exportProperty(jspb.Message, "getRepeatedWrapperField", jspb.Message.getRepeatedWrapperField), jspb.Message.wrapRepeatedField_ = function(e, t, r) {
                    if (e.wrappers_ || (e.wrappers_ = {}), !e.wrappers_[r]) {
                        for (var s = jspb.Message.getRepeatedField(e, r), o = [], n = 0; n < s.length; n++) o[n] = new t(s[n]);
                        e.wrappers_[r] = o
                    }
                }, jspb.Message.setWrapperField = function(e, t, r) {
                    jspb.asserts.assertInstanceof(e, jspb.Message), e.wrappers_ || (e.wrappers_ = {});
                    var s = r ? r.toArray() : r;
                    return e.wrappers_[t] = r, jspb.Message.setField(e, t, s)
                }, goog.exportProperty(jspb.Message, "setWrapperField", jspb.Message.setWrapperField), jspb.Message.setOneofWrapperField = function(e, t, r, s) {
                    jspb.asserts.assertInstanceof(e, jspb.Message), e.wrappers_ || (e.wrappers_ = {});
                    var o = s ? s.toArray() : s;
                    return e.wrappers_[t] = s, jspb.Message.setOneofField(e, t, r, o)
                }, goog.exportProperty(jspb.Message, "setOneofWrapperField", jspb.Message.setOneofWrapperField), jspb.Message.setRepeatedWrapperField = function(e, t, r) {
                    jspb.asserts.assertInstanceof(e, jspb.Message), e.wrappers_ || (e.wrappers_ = {}), r = r || [];
                    for (var s = [], o = 0; o < r.length; o++) s[o] = r[o].toArray();
                    return e.wrappers_[t] = r, jspb.Message.setField(e, t, s)
                }, goog.exportProperty(jspb.Message, "setRepeatedWrapperField", jspb.Message.setRepeatedWrapperField), jspb.Message.addToRepeatedWrapperField = function(e, t, r, s, o) {
                    jspb.Message.wrapRepeatedField_(e, s, t);
                    var n = e.wrappers_[t];
                    return n || = e.wrappers_[t] = [], r = r || new s, e = jspb.Message.getRepeatedField(e, t), null != o ? (n.splice(o, 0, r), e.splice(o, 0, r.toArray())) : (n.push(r), e.push(r.toArray())), r
                }, goog.exportProperty(jspb.Message, "addToRepeatedWrapperField", jspb.Message.addToRepeatedWrapperField), jspb.Message.toMap = function(e, t, r, s) {
                    for (var o = {}, n = 0; n < e.length; n++) o[t.call(e[n])] = r ? r.call(e[n], s, e[n]) : e[n];
                    return o
                }, goog.exportProperty(jspb.Message, "toMap", jspb.Message.toMap), jspb.Message.prototype.syncMapFields_ = function() {
                    if (this.wrappers_)
                        for (var e in this.wrappers_) {
                            var t = this.wrappers_[e];
                            if (Array.isArray(t))
                                for (var r = 0; r < t.length; r++) t[r] && t[r].toArray();
                            else t && t.toArray()
                        }
                }, jspb.Message.prototype.toArray = function() {
                    return this.syncMapFields_(), this.array
                }, goog.exportProperty(jspb.Message.prototype, "toArray", jspb.Message.prototype.toArray), jspb.Message.GENERATE_TO_STRING && (jspb.Message.prototype.toString = function() {
                    return this.syncMapFields_(), this.array.toString()
                }), jspb.Message.prototype.getExtension = function(e) {
                    if (this.extensionObject_) {
                        this.wrappers_ || (this.wrappers_ = {});
                        var t = e.fieldIndex;
                        if (e.isRepeated) {
                            if (e.isMessageType()) return this.wrappers_[t] || (this.wrappers_[t] = module$contents$goog$array_map(this.extensionObject_[t] || [], function(t) {
                                return new e.ctor(t)
                            })), this.wrappers_[t]
                        } else if (e.isMessageType()) return !this.wrappers_[t] && this.extensionObject_[t] && (this.wrappers_[t] = new e.ctor(this.extensionObject_[t])), this.wrappers_[t];
                        return this.extensionObject_[t]
                    }
                }, goog.exportProperty(jspb.Message.prototype, "getExtension", jspb.Message.prototype.getExtension), jspb.Message.prototype.setExtension = function(e, t) {
                    this.wrappers_ || (this.wrappers_ = {}), jspb.Message.maybeInitEmptyExtensionObject_(this);
                    var r = e.fieldIndex;
                    return e.isRepeated ? (t = t || [], e.isMessageType() ? (this.wrappers_[r] = t, this.extensionObject_[r] = module$contents$goog$array_map(t, function(e) {
                        return e.toArray()
                    })) : this.extensionObject_[r] = t) : e.isMessageType() ? (this.wrappers_[r] = t, this.extensionObject_[r] = t ? t.toArray() : t) : this.extensionObject_[r] = t, this
                }, goog.exportProperty(jspb.Message.prototype, "setExtension", jspb.Message.prototype.setExtension), jspb.Message.difference = function(e, t) {
                    if (!(e instanceof t.constructor)) throw Error("Messages have different types.");
                    var r = e.toArray();
                    t = t.toArray();
                    var s = [],
                        o = 0,
                        n = r.length > t.length ? r.length : t.length;
                    for (e.getJsPbMessageId() && (s[0] = e.getJsPbMessageId(), o = 1); o < n; o++) jspb.Message.compareFields(r[o], t[o]) || (s[o] = t[o]);
                    return new e.constructor(s)
                }, goog.exportProperty(jspb.Message, "difference", jspb.Message.difference), jspb.Message.equals = function(e, t) {
                    return e == t || !(!e || !t) && e instanceof t.constructor && jspb.Message.compareFields(e.toArray(), t.toArray())
                }, goog.exportProperty(jspb.Message, "equals", jspb.Message.equals), jspb.Message.compareExtensions = function(e, t) {
                    e = e || {}, t = t || {};
                    var r, s = {};
                    for (r in e) s[r] = 0;
                    for (r in t) s[r] = 0;
                    for (r in s)
                        if (!jspb.Message.compareFields(e[r], t[r])) return !1;
                    return !0
                }, goog.exportProperty(jspb.Message, "compareExtensions", jspb.Message.compareExtensions), jspb.Message.compareFields = function(e, t) {
                    if (e == t) return !0;
                    if (!goog.isObject(e) || !goog.isObject(t)) return !!("number" == typeof e && isNaN(e) || "number" == typeof t && isNaN(t)) && String(e) == String(t);
                    if (e.constructor != t.constructor) return !1;
                    if (jspb.Message.SUPPORTS_UINT8ARRAY_ && e.constructor === Uint8Array) {
                        if (e.length != t.length) return !1;
                        for (var r = 0; r < e.length; r++)
                            if (e[r] != t[r]) return !1;
                        return !0
                    }
                    if (e.constructor === Array) {
                        var s = void 0,
                            o = void 0,
                            n = Math.max(e.length, t.length);
                        for (r = 0; r < n; r++) {
                            var i = e[r],
                                a = t[r];
                            if (i && i.constructor == Object && (jspb.asserts.assert(void 0 === s), jspb.asserts.assert(r === e.length - 1), s = i, i = void 0), a && a.constructor == Object && (jspb.asserts.assert(void 0 === o), jspb.asserts.assert(r === t.length - 1), o = a, a = void 0), !jspb.Message.compareFields(i, a)) return !1
                        }
                        return !s && !o || (s = s || {}, o = o || {}, jspb.Message.compareExtensions(s, o))
                    }
                    if (e.constructor === Object) return jspb.Message.compareExtensions(e, t);
                    throw Error("Invalid type in JSPB array")
                }, goog.exportProperty(jspb.Message, "compareFields", jspb.Message.compareFields), jspb.Message.prototype.cloneMessage = function() {
                    return jspb.Message.cloneMessage(this)
                }, goog.exportProperty(jspb.Message.prototype, "cloneMessage", jspb.Message.prototype.cloneMessage), jspb.Message.prototype.clone = function() {
                    return jspb.Message.cloneMessage(this)
                }, goog.exportProperty(jspb.Message.prototype, "clone", jspb.Message.prototype.clone), jspb.Message.clone = function(e) {
                    return jspb.Message.cloneMessage(e)
                }, goog.exportProperty(jspb.Message, "clone", jspb.Message.clone), jspb.Message.cloneMessage = function(e) {
                    return new e.constructor(jspb.Message.clone_(e.toArray()))
                }, jspb.Message.copyInto = function(e, t) {
                    jspb.asserts.assertInstanceof(e, jspb.Message), jspb.asserts.assertInstanceof(t, jspb.Message), jspb.asserts.assert(e.constructor == t.constructor, "Copy source and target message should have the same type."), e = jspb.Message.clone(e);
                    for (var r = t.toArray(), s = e.toArray(), o = r.length = 0; o < s.length; o++) r[o] = s[o];
                    t.wrappers_ = e.wrappers_, t.extensionObject_ = e.extensionObject_
                }, goog.exportProperty(jspb.Message, "copyInto", jspb.Message.copyInto), jspb.Message.clone_ = function(e) {
                    if (Array.isArray(e)) {
                        for (var t = Array(e.length), r = 0; r < e.length; r++) {
                            var s = e[r];
                            null != s && (t[r] = "object" == typeof s ? jspb.Message.clone_(jspb.asserts.assert(s)) : s)
                        }
                        return t
                    }
                    if (jspb.Message.SUPPORTS_UINT8ARRAY_ && e instanceof Uint8Array) return new Uint8Array(e);
                    for (r in t = {}, e) null != (s = e[r]) && (t[r] = "object" == typeof s ? jspb.Message.clone_(jspb.asserts.assert(s)) : s);
                    return t
                }, jspb.Message.registerMessageType = function(e, t) {
                    t.messageId = e
                }, goog.exportProperty(jspb.Message, "registerMessageType", jspb.Message.registerMessageType), jspb.Message.messageSetExtensions = {}, jspb.Message.messageSetExtensionsBinary = {}, jspb.debug = {}, jspb.debug.dump = function(e) {
                    return goog.DEBUG ? (jspb.asserts.assertInstanceof(e, jspb.Message, "jspb.Message instance expected"), jspb.asserts.assert(e.getExtension, "Only unobfuscated and unoptimized compilation modes supported."), jspb.debug.dump_(e)) : null
                }, goog.exportSymbol("jspb.debug.dump", jspb.debug.dump), jspb.debug.dump_ = function(e) {
                    var t = goog.typeOf(e);
                    if ("number" == t || "string" == t || "boolean" == t || "null" == t || "undefined" == t || "undefined" != typeof Uint8Array && e instanceof Uint8Array) return e;
                    if ("array" == t) return jspb.asserts.assertArray(e), module$contents$goog$array_map(e, jspb.debug.dump_);
                    if (e instanceof jspb.Map) {
                        for (var r = {}, s = (e = e.entries()).next(); !s.done; s = e.next()) r[s.value[0]] = jspb.debug.dump_(s.value[1]);
                        return r
                    }
                    jspb.asserts.assertInstanceof(e, jspb.Message, "Only messages expected: " + e);
                    var o = {
                        $name: (t = e.constructor).name || t.displayName
                    };
                    for (a in t.prototype) {
                        var n = /^get([A-Z]\w*)/.exec(a);
                        if (n && "getExtension" != a && "getJsPbMessageId" != a) {
                            var i = "has" + n[1];
                            e[i] && !e[i]() || (i = e[a](), o[jspb.debug.formatFieldName_(n[1])] = jspb.debug.dump_(i))
                        }
                    }
                    if (COMPILED && e.extensionObject_) return o.$extensions = "Recursive dumping of extensions not supported in compiled code. Switch to uncompiled or dump extension object directly", o;
                    for (s in t.extensions)
                        if (/^\d+$/.test(s)) {
                            n = t.extensions[s];
                            var a = e.getExtension(n);
                            n = module$contents$goog$object_getKeys(n.fieldName)[0], null != a && (r || = o.$extensions = {}, r[jspb.debug.formatFieldName_(n)] = jspb.debug.dump_(a))
                        }
                    return o
                }, jspb.debug.formatFieldName_ = function(e) {
                    return e.replace(/^[A-Z]/, function(e) {
                        return e.toLowerCase()
                    })
                }, jspb.BinaryReader = module$contents$jspb$binary$reader_BinaryReader, jspb.binary.encoder = {};
                const module$contents$jspb$binary$encoder_MAX_PUSH = 8192;
                class module$contents$jspb$binary$encoder_BinaryEncoder {
                    constructor() {
                        this.buffer_ = []
                    }
                    length() {
                        return this.buffer_.length
                    }
                    end() {
                        const e = this.buffer_;
                        return this.buffer_ = [], e
                    }
                    writeSplitVarint64(e, t) {
                        for (goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(t == Math.floor(t)), goog.asserts.assert(0 <= e && e < module$contents$jspb$BinaryConstants_TWO_TO_32), goog.asserts.assert(0 <= t && t < module$contents$jspb$BinaryConstants_TWO_TO_32); 0 < t || 127 < e;) this.buffer_.push(127 & e | 128), e = (e >>> 7 | t << 25) >>> 0, t >>>= 7;
                        this.buffer_.push(e)
                    }
                    writeSplitFixed64(e, t) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(t == Math.floor(t)), goog.asserts.assert(0 <= e && e < module$contents$jspb$BinaryConstants_TWO_TO_32), goog.asserts.assert(0 <= t && t < module$contents$jspb$BinaryConstants_TWO_TO_32), this.writeUint32(e), this.writeUint32(t)
                    }
                    writeSplitZigzagVarint64(e, t) {
                        module$contents$jspb$utils_toZigzag64(e, t, (e, t) => {
                            this.writeSplitVarint64(e >>> 0, t >>> 0)
                        })
                    }
                    writeUnsignedVarint32(e) {
                        for (goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(0 <= e && e < module$contents$jspb$BinaryConstants_TWO_TO_32); 127 < e;) this.buffer_.push(127 & e | 128), e >>>= 7;
                        this.buffer_.push(e)
                    }
                    writeSignedVarint32(e) {
                        if (goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && e < module$contents$jspb$BinaryConstants_TWO_TO_31), 0 <= e) this.writeUnsignedVarint32(e);
                        else {
                            for (let t = 0; 9 > t; t++) this.buffer_.push(127 & e | 128), e >>= 7;
                            this.buffer_.push(1)
                        }
                    }
                    writeUnsignedVarint64(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(0 <= e && e < module$contents$jspb$BinaryConstants_TWO_TO_64), module$contents$jspb$utils_splitInt64(e), this.writeSplitVarint64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High())
                    }
                    writeSignedVarint64(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_63 && e < module$contents$jspb$BinaryConstants_TWO_TO_63), module$contents$jspb$utils_splitInt64(e), this.writeSplitVarint64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High())
                    }
                    writeZigzagVarint32(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && e < module$contents$jspb$BinaryConstants_TWO_TO_31), this.writeUnsignedVarint32(module$contents$jspb$utils_toZigzag32(e))
                    }
                    writeZigzagVarint64(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_63 && e < module$contents$jspb$BinaryConstants_TWO_TO_63), module$contents$jspb$utils_splitZigzag64(e), this.writeSplitVarint64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High())
                    }
                    writeZigzagVarint64String(e) {
                        module$contents$jspb$utils_splitDecimalString(e), module$contents$jspb$utils_toZigzag64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High(), (e, t) => {
                            this.writeSplitVarint64(e >>> 0, t >>> 0)
                        })
                    }
                    writeUint8(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(0 <= e && 256 > e), this.buffer_.push(e >>> 0 & 255)
                    }
                    writeUint16(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(0 <= e && 65536 > e), this.buffer_.push(e >>> 0 & 255), this.buffer_.push(e >>> 8 & 255)
                    }
                    writeUint32(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(0 <= e && e < module$contents$jspb$BinaryConstants_TWO_TO_32), this.buffer_.push(e >>> 0 & 255), this.buffer_.push(e >>> 8 & 255), this.buffer_.push(e >>> 16 & 255), this.buffer_.push(e >>> 24 & 255)
                    }
                    writeUint64(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(0 <= e && e < module$contents$jspb$BinaryConstants_TWO_TO_64), module$contents$jspb$utils_splitUint64(e), this.writeUint32(module$contents$jspb$utils_getSplit64Low()), this.writeUint32(module$contents$jspb$utils_getSplit64High())
                    }
                    writeInt8(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(-128 <= e && 128 > e), this.buffer_.push(e >>> 0 & 255)
                    }
                    writeInt16(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(-32768 <= e && 32768 > e), this.buffer_.push(e >>> 0 & 255), this.buffer_.push(e >>> 8 & 255)
                    }
                    writeInt32(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && e < module$contents$jspb$BinaryConstants_TWO_TO_31), this.buffer_.push(e >>> 0 & 255), this.buffer_.push(e >>> 8 & 255), this.buffer_.push(e >>> 16 & 255), this.buffer_.push(e >>> 24 & 255)
                    }
                    writeInt64(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_63 && e < module$contents$jspb$BinaryConstants_TWO_TO_63), module$contents$jspb$utils_splitInt64(e), this.writeSplitFixed64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High())
                    }
                    writeFloat(e) {
                        goog.asserts.assert(1 / 0 == e || -1 / 0 == e || isNaN(e) || "number" == typeof e && e >= -module$contents$jspb$BinaryConstants_FLOAT32_MAX && e <= module$contents$jspb$BinaryConstants_FLOAT32_MAX), module$contents$jspb$utils_splitFloat32(e), this.writeUint32(module$contents$jspb$utils_getSplit64Low())
                    }
                    writeDouble(e) {
                        goog.asserts.assert("number" == typeof e || "Infinity" === e || "-Infinity" === e || "NaN" === e), module$contents$jspb$utils_splitFloat64(e), this.writeUint32(module$contents$jspb$utils_getSplit64Low()), this.writeUint32(module$contents$jspb$utils_getSplit64High())
                    }
                    writeBool(e) {
                        goog.asserts.assert("boolean" == typeof e || "number" == typeof e), this.buffer_.push(e ? 1 : 0)
                    }
                    writeEnum(e) {
                        goog.asserts.assert(e == Math.floor(e)), goog.asserts.assert(e >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && e < module$contents$jspb$BinaryConstants_TWO_TO_31), this.writeSignedVarint32(e)
                    }
                    writeBytes(e) {
                        for (; e.length > module$contents$jspb$binary$encoder_MAX_PUSH;) Array.prototype.push.apply(this.buffer_, e.subarray(0, module$contents$jspb$binary$encoder_MAX_PUSH)), e = e.subarray(module$contents$jspb$binary$encoder_MAX_PUSH);
                        Array.prototype.push.apply(this.buffer_, e)
                    }
                }
                jspb.binary.encoder.BinaryEncoder = module$contents$jspb$binary$encoder_BinaryEncoder, jspb.arith = {};
                class module$contents$jspb$arith_UInt64 {
                    constructor(e, t) {
                        this.lo = e >>> 0, this.hi = t >>> 0
                    }
                    toDecimalString() {
                        return module$contents$jspb$utils_joinUnsignedDecimalString(this.lo, this.hi)
                    }
                    negateInTwosComplement() {
                        return 0 === this.lo ? new module$contents$jspb$arith_UInt64(0, 1 + ~this.hi) : new module$contents$jspb$arith_UInt64(1 + ~this.lo, ~this.hi)
                    }
                    static fromBigInt(e) {
                        return e = BigInt.asUintN(64, e), new module$contents$jspb$arith_UInt64(Number(e & BigInt(4294967295)), Number(e >> BigInt(32)))
                    }
                    static fromString(e) {
                        return e ? /^\d+$/.test(e) ? (module$contents$jspb$utils_splitDecimalString(e), new module$contents$jspb$arith_UInt64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High())) : null : module$contents$jspb$arith_UInt64.getZero()
                    }
                    static fromNumber(e) {
                        return new module$contents$jspb$arith_UInt64(e & module$contents$jspb$arith_ALL_32_BITS, e / module$contents$jspb$arith_TWO_PWR_32_DBL)
                    }
                    static getZero() {
                        return module$contents$jspb$arith_uint64Zero || = new module$contents$jspb$arith_UInt64(0, 0)
                    }
                }
                let module$contents$jspb$arith_uint64Zero, module$contents$jspb$arith_int64Zero;
                class module$contents$jspb$arith_Int64 {
                    constructor(e, t) {
                        this.lo = e >>> 0, this.hi = t >>> 0
                    }
                    toDecimalString() {
                        return module$contents$jspb$utils_joinSignedDecimalString(this.lo, this.hi)
                    }
                    static fromBigInt(e) {
                        return e = BigInt.asUintN(64, e), new module$contents$jspb$arith_Int64(Number(e & BigInt(4294967295)), Number(e >> BigInt(32)))
                    }
                    static fromString(e) {
                        return e ? /^-?\d+$/.test(e) ? (module$contents$jspb$utils_splitDecimalString(e), new module$contents$jspb$arith_Int64(module$contents$jspb$utils_getSplit64Low(), module$contents$jspb$utils_getSplit64High())) : null : module$contents$jspb$arith_Int64.getZero()
                    }
                    static fromNumber(e) {
                        return new module$contents$jspb$arith_Int64(e & module$contents$jspb$arith_ALL_32_BITS, e / module$contents$jspb$arith_TWO_PWR_32_DBL)
                    }
                    static getZero() {
                        return module$contents$jspb$arith_int64Zero || = new module$contents$jspb$arith_Int64(0, 0)
                    }
                }
                const module$contents$jspb$arith_ALL_32_BITS = 4294967295,
                    module$contents$jspb$arith_TWO_PWR_32_DBL = 4294967296;
                jspb.arith.UInt64 = module$contents$jspb$arith_UInt64, jspb.arith.Int64 = module$contents$jspb$arith_Int64, jspb.binary.writer = {};
                const module$contents$jspb$binary$writer_REJECT_UNPAIRED_SURROGATES = goog.DEBUG;
                class module$contents$jspb$binary$writer_BinaryWriter {
                    constructor() {
                        this.blocks_ = [], this.totalLength_ = 0, this.encoder_ = new module$contents$jspb$binary$encoder_BinaryEncoder
                    }
                    pushBlock(e) {
                        0 !== e.length && (this.blocks_.push(e), this.totalLength_ += e.length)
                    }
                    appendUint8Array_(e) {
                        this.pushBlock(this.encoder_.end()), this.pushBlock(e)
                    }
                    beginDelimited_(e) {
                        return this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), e = this.encoder_.end(), this.pushBlock(e), e.push(this.totalLength_), e
                    }
                    endDelimited_(e) {
                        var t = e.pop();
                        for (t = this.totalLength_ + this.encoder_.length() - t, (0, goog.asserts.assert)(0 <= t); 127 < t;) e.push(127 & t | 128), t >>>= 7, this.totalLength_++;
                        e.push(t), this.totalLength_++
                    }
                    writeUnknownFields(e) {
                        this.pushBlock(this.encoder_.end());
                        for (let t = 0; t < e.length; t++) this.pushBlock(module$contents$jspb$unsafe_bytestring_unsafeUint8ArrayFromByteString(e[t]))
                    }
                    writeSerializedMessage(e, t, r) {
                        this.appendUint8Array_(e.subarray(t, r))
                    }
                    maybeWriteSerializedMessage(e, t, r) {
                        null != e && null != t && null != r && this.writeSerializedMessage(e, t, r)
                    }
                    reset() {
                        this.blocks_ = [], this.encoder_.end(), this.totalLength_ = 0
                    }
                    getResultBuffer() {
                        this.pushBlock(this.encoder_.end());
                        const e = new Uint8Array(this.totalLength_),
                            t = this.blocks_,
                            r = t.length;
                        let s = 0;
                        for (let o = 0; o < r; o++) {
                            const r = t[o];
                            e.set(r, s), s += r.length
                        }
                        return (0, goog.asserts.assert)(s == e.length), this.blocks_ = [e], e
                    }
                    getResultBufferAsByteString() {
                        return module$contents$jspb$unsafe_bytestring_unsafeByteStringFromUint8Array(this.getResultBuffer())
                    }
                    getResultBase64String(e) {
                        return void 0 === e ? module$contents$jspb$internal_bytes_encodeByteArray(this.getResultBuffer()) : (0, goog.crypt.base64.encodeByteArray)(this.getResultBuffer(), e)
                    }
                    writeFieldHeader_(e, t) {
                        (0, goog.asserts.assert)(1 <= e && e == Math.floor(e)), this.encoder_.writeUnsignedVarint32(module$contents$jspb$utils_makeTag(e, t))
                    }
                    writeAny(e, t, r) {
                        switch (e) {
                            case module$contents$jspb$BinaryConstants_FieldType.DOUBLE:
                                this.writeDouble(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.FLOAT:
                                this.writeFloat(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.INT64:
                                this.writeInt64(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.UINT64:
                                this.writeUint64(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.INT32:
                                this.writeInt32(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.FIXED64:
                                this.writeFixed64(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.FIXED32:
                                this.writeFixed32(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.BOOL:
                                this.writeBool(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.STRING:
                                this.writeString(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.GROUP:
                                (0, goog.asserts.fail)("Group field type not supported in writeAny()");
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.MESSAGE:
                                (0, goog.asserts.fail)("Message field type not supported in writeAny()");
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.BYTES:
                                this.writeBytes(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.UINT32:
                                this.writeUint32(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.ENUM:
                                this.writeEnum(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.SFIXED32:
                                this.writeSfixed32(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.SFIXED64:
                                this.writeSfixed64(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.SINT32:
                                this.writeSint32(t, r);
                                break;
                            case module$contents$jspb$BinaryConstants_FieldType.SINT64:
                                this.writeSint64(t, r);
                                break;
                            default:
                                (0, goog.asserts.fail)("Invalid field type in writeAny()")
                        }
                    }
                    writeUnsignedVarint32_(e, t) {
                        null != t && (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeUnsignedVarint32(t))
                    }
                    writeSignedVarint32_(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertSignedInteger(e, t), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeSignedVarint32(t))
                    }
                    writeUnsignedVarint64_(e, t) {
                        if (null != t) switch (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), typeof t) {
                            case "number":
                                this.encoder_.writeUnsignedVarint64(t);
                                break;
                            case "bigint":
                                e = module$contents$jspb$arith_UInt64.fromBigInt(t), this.encoder_.writeSplitVarint64(e.lo, e.hi);
                                break;
                            default:
                                e = module$contents$jspb$arith_UInt64.fromString(t), this.encoder_.writeSplitVarint64(e.lo, e.hi)
                        }
                    }
                    writeSignedVarint64_(e, t) {
                        if (null != t) switch (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), typeof t) {
                            case "number":
                                this.encoder_.writeSignedVarint64(t);
                                break;
                            case "bigint":
                                e = module$contents$jspb$arith_Int64.fromBigInt(t), this.encoder_.writeSplitVarint64(e.lo, e.hi);
                                break;
                            default:
                                e = module$contents$jspb$arith_Int64.fromString(t), this.encoder_.writeSplitVarint64(e.lo, e.hi)
                        }
                    }
                    writeZigzagVarint32_(e, t) {
                        null != t && (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeZigzagVarint32(t))
                    }
                    writeZigzagVarint64_(e, t) {
                        if (null != t)
                            if ("number" == (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), typeof t)) this.encoder_.writeZigzagVarint64(t);
                            else this.encoder_.writeZigzagVarint64String(t)
                    }
                    writeInt32(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertThat(e, t, t >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && t < module$contents$jspb$BinaryConstants_TWO_TO_31), this.writeSignedVarint32_(e, t))
                    }
                    writeInt64(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertSignedInt64(e, t), this.writeSignedVarint64_(e, t))
                    }
                    writeInt64String(e, t) {
                        this.writeInt64(e, t)
                    }
                    writeUint32(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertThat(e, t, 0 <= t && t < module$contents$jspb$BinaryConstants_TWO_TO_32), this.writeUnsignedVarint32_(e, t))
                    }
                    writeUint64(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertUnsignedInt64(e, t), this.writeUnsignedVarint64_(e, t))
                    }
                    writeUint64String(e, t) {
                        this.writeUint64(e, t)
                    }
                    writeSint32(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertThat(e, t, t >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && t < module$contents$jspb$BinaryConstants_TWO_TO_31), this.writeZigzagVarint32_(e, t))
                    }
                    writeSint64(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertSignedInt64(e, t), this.writeZigzagVarint64_(e, t))
                    }
                    writeSint64String(e, t) {
                        this.writeSint64(e, t)
                    }
                    writeFixed32(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertThat(e, t, 0 <= t && t < module$contents$jspb$BinaryConstants_TWO_TO_32), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED32), this.encoder_.writeUint32(t))
                    }
                    writeFixed64(e, t) {
                        if (null != t) switch (module$contents$jspb$binary$writer_assertUnsignedInt64(e, t), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED64), typeof t) {
                            case "number":
                                this.encoder_.writeUint64(t);
                                break;
                            case "bigint":
                                e = module$contents$jspb$arith_UInt64.fromBigInt(t), this.encoder_.writeSplitFixed64(e.lo, e.hi);
                                break;
                            default:
                                e = module$contents$jspb$arith_UInt64.fromString(t), this.encoder_.writeSplitFixed64(e.lo, e.hi)
                        }
                    }
                    writeFixed64String(e, t) {
                        this.writeFixed64(e, t)
                    }
                    writeSfixed32(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertThat(e, t, t >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && t < module$contents$jspb$BinaryConstants_TWO_TO_31), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED32), this.encoder_.writeInt32(t))
                    }
                    writeSfixed64(e, t) {
                        if (null != t) switch (module$contents$jspb$binary$writer_assertSignedInt64(e, t), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED64), typeof t) {
                            case "number":
                                this.encoder_.writeInt64(t);
                                break;
                            case "bigint":
                                e = module$contents$jspb$arith_Int64.fromBigInt(t), this.encoder_.writeSplitFixed64(e.lo, e.hi);
                                break;
                            default:
                                e = module$contents$jspb$arith_Int64.fromString(t), this.encoder_.writeSplitFixed64(e.lo, e.hi)
                        }
                    }
                    writeSfixed64String(e, t) {
                        this.writeSfixed64(e, t)
                    }
                    writeFloat(e, t) {
                        null != t && (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED32), this.encoder_.writeFloat(t))
                    }
                    writeDouble(e, t) {
                        null != t && (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED64), this.encoder_.writeDouble(t))
                    }
                    writeBool(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertThat(e, t, "boolean" == typeof t || "number" == typeof t), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeBool(t))
                    }
                    writeEnum(e, t) {
                        null != t && (module$contents$jspb$binary$writer_assertSignedInteger(e, t = parseInt(t, 10)), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeSignedVarint32(t))
                    }
                    writeString(e, t) {
                        null != t && this.writeUint8Array(e, module$contents$jspb$binary$utf8_encodeUtf8(t, module$contents$jspb$binary$writer_REJECT_UNPAIRED_SURROGATES))
                    }
                    writeBytes(e, t) {
                        null != t && this.writeUint8Array(e, module$contents$jspb$binary$internal_buffer_bufferFromSource(t, !0).buffer)
                    }
                    writeUint8Array(e, t) {
                        this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(t.length), this.appendUint8Array_(t)
                    }
                    writeMessage(e, t, r) {
                        null != t && (e = this.beginDelimited_(e), r(t, this), this.endDelimited_(e))
                    }
                    writeMessageSet(e, t, r) {
                        null != t && (this.writeFieldHeader_(1, module$contents$jspb$BinaryConstants_WireType.START_GROUP), this.writeFieldHeader_(2, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeSignedVarint32(e), e = this.beginDelimited_(3), r(t, this), this.endDelimited_(e), this.writeFieldHeader_(1, module$contents$jspb$BinaryConstants_WireType.END_GROUP))
                    }
                    writeGroup(e, t, r) {
                        null != t && (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.START_GROUP), r(t, this), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.END_GROUP))
                    }
                    writeSplitFixed64(e, t, r) {
                        this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.FIXED64), this.encoder_.writeSplitFixed64(t, r)
                    }
                    writeSplitVarint64(e, t, r) {
                        this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeSplitVarint64(t, r)
                    }
                    writeSplitZigzagVarint64(e, t, r) {
                        this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.VARINT), this.encoder_.writeSplitZigzagVarint64(t >>> 0, r >>> 0)
                    }
                    writeRepeatedInt32(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeSignedVarint32_(e, t[r])
                    }
                    writeRepeatedInt64(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeSignedVarint64_(e, t[r])
                    }
                    writeRepeatedSplitFixed64(e, t, r, s) {
                        if (null != t)
                            for (let o = 0; o < t.length; o++) this.writeSplitFixed64(e, r(t[o]), s(t[o]))
                    }
                    writeRepeatedSplitVarint64(e, t, r, s) {
                        if (null != t)
                            for (let o = 0; o < t.length; o++) this.writeSplitVarint64(e, r(t[o]), s(t[o]))
                    }
                    writeRepeatedSplitZigzagVarint64(e, t, r, s) {
                        if (null != t)
                            for (let o = 0; o < t.length; o++) this.writeSplitZigzagVarint64(e, r(t[o]), s(t[o]))
                    }
                    writeRepeatedInt64String(e, t) {
                        this.writeRepeatedInt64(e, t)
                    }
                    writeRepeatedUint32(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeUnsignedVarint32_(e, t[r])
                    }
                    writeRepeatedUint64(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeUnsignedVarint64_(e, t[r])
                    }
                    writeRepeatedUint64String(e, t) {
                        this.writeRepeatedUint64(e, t)
                    }
                    writeRepeatedSint32(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeZigzagVarint32_(e, t[r])
                    }
                    writeRepeatedSint64(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeZigzagVarint64_(e, t[r])
                    }
                    writeRepeatedSint64String(e, t) {
                        this.writeRepeatedSint64(e, t)
                    }
                    writeRepeatedFixed32(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeFixed32(e, t[r])
                    }
                    writeRepeatedFixed64(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeFixed64(e, t[r])
                    }
                    writeRepeatedFixed64String(e, t) {
                        this.writeRepeatedFixed64(e, t)
                    }
                    writeRepeatedSfixed32(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeSfixed32(e, t[r])
                    }
                    writeRepeatedSfixed64(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeSfixed64(e, t[r])
                    }
                    writeRepeatedSfixed64String(e, t) {
                        this.writeRepeatedSfixed64(e, t)
                    }
                    writeRepeatedFloat(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeFloat(e, t[r])
                    }
                    writeRepeatedDouble(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeDouble(e, t[r])
                    }
                    writeRepeatedBool(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeBool(e, t[r])
                    }
                    writeRepeatedEnum(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeEnum(e, t[r])
                    }
                    writeRepeatedString(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeString(e, t[r])
                    }
                    writeRepeatedBytes(e, t) {
                        if (null != t)
                            for (let r = 0; r < t.length; r++) this.writeBytes(e, t[r])
                    }
                    writeRepeatedMessage(e, t, r) {
                        if (null != t)
                            for (let s = 0; s < t.length; s++) {
                                const o = this.beginDelimited_(e);
                                r(t[s], this), this.endDelimited_(o)
                            }
                    }
                    writeRepeatedGroup(e, t, r) {
                        if (null != t)
                            for (let s = 0; s < t.length; s++) this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.START_GROUP), r(t[s], this), this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.END_GROUP)
                    }
                    writePackedInt32(e, t) {
                        if (null != t && t.length) {
                            var r = this.beginDelimited_(e);
                            for (let r = 0; r < t.length; r++) module$contents$jspb$binary$writer_assertSignedInteger(e, t[r]), this.encoder_.writeSignedVarint32(t[r]);
                            this.endDelimited_(r)
                        }
                    }
                    writePackedInt32String(e, t) {
                        if (null != t && t.length) {
                            var r = this.beginDelimited_(e);
                            for (let r = 0; r < t.length; r++) {
                                const s = parseInt(t[r], 10);
                                module$contents$jspb$binary$writer_assertSignedInteger(e, s), this.encoder_.writeSignedVarint32(s)
                            }
                            this.endDelimited_(r)
                        }
                    }
                    writePackedInt64(e, t) {
                        if (null != t && t.length) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) {
                                var r = t[e];
                                switch (typeof r) {
                                    case "number":
                                        this.encoder_.writeSignedVarint64(r);
                                        break;
                                    case "bigint":
                                        r = module$contents$jspb$arith_Int64.fromBigInt(r), this.encoder_.writeSplitVarint64(r.lo, r.hi);
                                        break;
                                    default:
                                        r = module$contents$jspb$arith_Int64.fromString(r), this.encoder_.writeSplitVarint64(r.lo, r.hi)
                                }
                            }
                            this.endDelimited_(e)
                        }
                    }
                    writePackedSplitFixed64(e, t, r, s) {
                        if (null != t) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) this.encoder_.writeSplitFixed64(r(t[e]), s(t[e]));
                            this.endDelimited_(e)
                        }
                    }
                    writePackedSplitVarint64(e, t, r, s) {
                        if (null != t) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) this.encoder_.writeSplitVarint64(r(t[e]), s(t[e]));
                            this.endDelimited_(e)
                        }
                    }
                    writePackedSplitZigzagVarint64(e, t, r, s) {
                        if (null != t) {
                            e = this.beginDelimited_(e);
                            var o = this.encoder_;
                            for (let e = 0; e < t.length; e++) o.writeSplitZigzagVarint64(r(t[e]), s(t[e]));
                            this.endDelimited_(e)
                        }
                    }
                    writePackedInt64String(e, t) {
                        this.writePackedInt64(e, t)
                    }
                    writePackedUint32(e, t) {
                        if (null != t && t.length) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) this.encoder_.writeUnsignedVarint32(t[e]);
                            this.endDelimited_(e)
                        }
                    }
                    writePackedUint64(e, t) {
                        if (null != t && t.length) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) {
                                var r = t[e];
                                switch (typeof r) {
                                    case "number":
                                        this.encoder_.writeUnsignedVarint64(r);
                                        break;
                                    case "bigint":
                                        const e = Number(r);
                                        Number.isSafeInteger(e) ? this.encoder_.writeUnsignedVarint64(e) : (r = module$contents$jspb$arith_UInt64.fromBigInt(r), this.encoder_.writeSplitVarint64(r.lo, r.hi));
                                        break;
                                    default:
                                        r = module$contents$jspb$arith_UInt64.fromString(r), this.encoder_.writeSplitVarint64(r.lo, r.hi)
                                }
                            }
                            this.endDelimited_(e)
                        }
                    }
                    writePackedUint64String(e, t) {
                        this.writePackedUint64(e, t)
                    }
                    writePackedSint32(e, t) {
                        if (null != t && t.length) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) this.encoder_.writeZigzagVarint32(t[e]);
                            this.endDelimited_(e)
                        }
                    }
                    writePackedSint64(e, t) {
                        if (null != t && t.length) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) {
                                const r = t[e];
                                if ("number" == typeof r) this.encoder_.writeZigzagVarint64(r);
                                else this.encoder_.writeZigzagVarint64String(r)
                            }
                            this.endDelimited_(e)
                        }
                    }
                    writePackedSint64String(e, t) {
                        this.writePackedSint64(e, t)
                    }
                    writePackedFixed32(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(4 * t.length), e = 0; e < t.length; e++) this.encoder_.writeUint32(t[e])
                    }
                    writePackedFixed64(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(8 * t.length), e = 0; e < t.length; e++) {
                                var r = t[e];
                                switch (typeof r) {
                                    case "number":
                                        this.encoder_.writeUint64(r);
                                        break;
                                    case "bigint":
                                        r = module$contents$jspb$arith_UInt64.fromBigInt(r), this.encoder_.writeSplitFixed64(r.lo, r.hi);
                                        break;
                                    default:
                                        r = module$contents$jspb$arith_UInt64.fromString(r), this.encoder_.writeSplitFixed64(r.lo, r.hi)
                                }
                            }
                    }
                    writePackedFixed64String(e, t) {
                        this.writePackedFixed64(e, t)
                    }
                    writePackedSfixed32(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(4 * t.length), e = 0; e < t.length; e++) this.encoder_.writeInt32(t[e])
                    }
                    writePackedSfixed64(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(8 * t.length), e = 0; e < t.length; e++) {
                                var r = t[e];
                                switch (typeof r) {
                                    case "number":
                                        this.encoder_.writeInt64(r);
                                        break;
                                    case "bigint":
                                        r = module$contents$jspb$arith_Int64.fromBigInt(r), this.encoder_.writeSplitFixed64(r.lo, r.hi);
                                        break;
                                    default:
                                        r = module$contents$jspb$arith_Int64.fromString(r), this.encoder_.writeSplitFixed64(r.lo, r.hi)
                                }
                            }
                    }
                    writePackedSfixed64String(e, t) {
                        this.writePackedSfixed64(e, t)
                    }
                    writePackedFloat(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(4 * t.length), e = 0; e < t.length; e++) this.encoder_.writeFloat(t[e])
                    }
                    writePackedDouble(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(8 * t.length), e = 0; e < t.length; e++) this.encoder_.writeDouble(t[e])
                    }
                    writePackedBool(e, t) {
                        if (null != t && t.length)
                            for (this.writeFieldHeader_(e, module$contents$jspb$BinaryConstants_WireType.DELIMITED), this.encoder_.writeUnsignedVarint32(t.length), e = 0; e < t.length; e++) this.encoder_.writeBool(t[e])
                    }
                    writePackedEnum(e, t) {
                        if (null != t && t.length) {
                            e = this.beginDelimited_(e);
                            for (let e = 0; e < t.length; e++) this.encoder_.writeEnum(t[e]);
                            this.endDelimited_(e)
                        }
                    }
                }

                function module$contents$jspb$binary$writer_assertSignedInteger(e, t) {
                    module$contents$jspb$binary$writer_assertThat(e, t, t === Math.floor(t)), module$contents$jspb$binary$writer_assertThat(e, t, t >= -module$contents$jspb$BinaryConstants_TWO_TO_31 && t < module$contents$jspb$BinaryConstants_TWO_TO_31)
                }

                function module$contents$jspb$binary$writer_assertSignedInt64(e, t) {
                    switch (typeof t) {
                        case "string":
                            module$contents$jspb$binary$writer_assertThat(e, t, module$contents$jspb$arith_Int64.fromString(t));
                            break;
                        case "number":
                            module$contents$jspb$binary$writer_assertThat(e, t, t >= -module$contents$jspb$BinaryConstants_TWO_TO_63 && t < module$contents$jspb$BinaryConstants_TWO_TO_63);
                            break;
                        default:
                            module$contents$jspb$binary$writer_assertThat(e, t, t >= BigInt(-module$contents$jspb$BinaryConstants_TWO_TO_63) && t < BigInt(module$contents$jspb$BinaryConstants_TWO_TO_63))
                    }
                }

                function module$contents$jspb$binary$writer_assertUnsignedInt64(e, t) {
                    switch (typeof t) {
                        case "string":
                            module$contents$jspb$binary$writer_assertThat(e, t, module$contents$jspb$arith_UInt64.fromString(t));
                            break;
                        case "number":
                            module$contents$jspb$binary$writer_assertThat(e, t, 0 <= t && t < module$contents$jspb$BinaryConstants_TWO_TO_64);
                            break;
                        default:
                            module$contents$jspb$binary$writer_assertThat(e, t, t >= BigInt(0) && t < BigInt(module$contents$jspb$BinaryConstants_TWO_TO_64))
                    }
                }

                function module$contents$jspb$binary$writer_assertThat(e, t, r) {
                    r || (0, goog.asserts.fail)(`for [${t}] at [${e}]`)
                }

                function module$contents$jspb$internal$public_for_gencode_serializeMapToBinary(e, t, r, s, o, n) {
                    e && e.forEach((i, a) => {
                        r.writeMessage(t, e, (e, t) => {
                            s.call(t, 1, a), o.call(t, 2, i, n)
                        })
                    })
                }

                function module$contents$jspb$internal$public_for_gencode_deserializeMapFromBinary(e, t, r, s, o, n) {
                    t.readMessage(e, (t, i) => {
                        t = s;
                        let a = n;
                        for (; i.nextField() && !i.isEndGroup();) {
                            const s = i.getFieldNumber();
                            1 == s ? t = r.call(i) : 2 == s && (e.valueCtor ? i.readMessage(a, o) : a = o.call(i))
                        }
                        goog.asserts.assert(null != t), goog.asserts.assert(null != a), e.set(t, a)
                    })
                }
                jspb.binary.writer.BinaryWriter = module$contents$jspb$binary$writer_BinaryWriter, jspb.BinaryWriter = module$contents$jspb$binary$writer_BinaryWriter, jspb.internal = {}, jspb.internal.public_for_gencode = {}, jspb.internal.public_for_gencode.deserializeMapFromBinary = module$contents$jspb$internal$public_for_gencode_deserializeMapFromBinary, jspb.internal.public_for_gencode.serializeMapToBinary = module$contents$jspb$internal$public_for_gencode_serializeMapToBinary, jspb.Export = {}, exports.debug = jspb.debug, exports.Map = jspb.Map, exports.Message = jspb.Message, exports.BinaryReader = module$contents$jspb$binary$reader_BinaryReader, exports.BinaryWriter = module$contents$jspb$binary$writer_BinaryWriter, exports.ExtensionFieldInfo = jspb.ExtensionFieldInfo, exports.ExtensionFieldBinaryInfo = jspb.ExtensionFieldBinaryInfo, exports.internal = {
                    public_for_gencode: jspb.internal.public_for_gencode
                }, exports.exportSymbol = goog.exportSymbol, exports.inherits = goog.inherits, exports.object = {
                    extend: module$contents$goog$object_extend
                }, exports.typeOf = goog.typeOf
            },
            4764(e, t, r) {
                var s = r(7186),
                    o = s,
                    n = globalThis;
                o.exportSymbol("proto.google.protobuf.Timestamp", null, n), proto.google.protobuf.Timestamp = function(e) {
                    s.Message.initialize(this, e, 0, -1, null, null)
                }, o.inherits(proto.google.protobuf.Timestamp, s.Message), o.DEBUG && !COMPILED && (proto.google.protobuf.Timestamp.displayName = "proto.google.protobuf.Timestamp"), s.Message.GENERATE_TO_OBJECT && (proto.google.protobuf.Timestamp.prototype.toObject = function(e) {
                    return proto.google.protobuf.Timestamp.toObject(e, this)
                }, proto.google.protobuf.Timestamp.toObject = function(e, t) {
                    var r = {
                        seconds: s.Message.getFieldWithDefault(t, 1, 0),
                        nanos: s.Message.getFieldWithDefault(t, 2, 0)
                    };
                    return e && (r.$jspbMessageInstance = t), r
                }), proto.google.protobuf.Timestamp.deserializeBinary = function(e) {
                    var t = new s.BinaryReader(e),
                        r = new proto.google.protobuf.Timestamp;
                    return proto.google.protobuf.Timestamp.deserializeBinaryFromReader(r, t)
                }, proto.google.protobuf.Timestamp.deserializeBinaryFromReader = function(e, t) {
                    for (; t.nextField() && !t.isEndGroup();) {
                        switch (t.getFieldNumber()) {
                            case 1:
                                var r = t.readInt64();
                                e.setSeconds(r);
                                break;
                            case 2:
                                r = t.readInt32();
                                e.setNanos(r);
                                break;
                            default:
                                t.skipField()
                        }
                    }
                    return e
                }, proto.google.protobuf.Timestamp.prototype.serializeBinary = function() {
                    var e = new s.BinaryWriter;
                    return proto.google.protobuf.Timestamp.serializeBinaryToWriter(this, e), e.getResultBuffer()
                }, proto.google.protobuf.Timestamp.serializeBinaryToWriter = function(e, t) {
                    var r = void 0;
                    0 !== (r = e.getSeconds()) && t.writeInt64(1, r), 0 !== (r = e.getNanos()) && t.writeInt32(2, r)
                }, proto.google.protobuf.Timestamp.prototype.getSeconds = function() {
                    return s.Message.getFieldWithDefault(this, 1, 0)
                }, proto.google.protobuf.Timestamp.prototype.setSeconds = function(e) {
                    return s.Message.setProto3IntField(this, 1, e)
                }, proto.google.protobuf.Timestamp.prototype.getNanos = function() {
                    return s.Message.getFieldWithDefault(this, 2, 0)
                }, proto.google.protobuf.Timestamp.prototype.setNanos = function(e) {
                    return s.Message.setProto3IntField(this, 2, e)
                }, o.object.extend(t, proto.google.protobuf), proto.google.protobuf.Timestamp.prototype.toDate = function() {
                    var e = this.getSeconds(),
                        t = this.getNanos();
                    return new Date(1e3 * e + t / 1e6)
                }, proto.google.protobuf.Timestamp.prototype.fromDate = function(e) {
                    this.setSeconds(Math.floor(e.getTime() / 1e3)), this.setNanos(1e6 * e.getMilliseconds())
                }, proto.google.protobuf.Timestamp.fromDate = function(e) {
                    var t = new proto.google.protobuf.Timestamp;
                    return t.fromDate(e), t
                }
            },
            5949(e) {
                var t, r = r || {},
                    s = this || self;

                function o(e, t) {
                    e = e.split("."), t = t || s;
                    for (var r = 0; r < e.length; r++)
                        if (null == (t = t[e[r]])) return null;
                    return t
                }

                function n(e) {
                    var t = typeof e;
                    return "object" == t && null != e || "function" == t
                }

                function i(e) {
                    return Object.prototype.hasOwnProperty.call(e, a) && e[a] || (e[a] = ++g)
                }
                var a = "closure_uid_" + (1e9 * Math.random() >>> 0),
                    g = 0;

                function u(e, t, r) {
                    return e.call.apply(e.bind, arguments)
                }

                function d(e, t, r) {
                    if (!e) throw Error();
                    if (arguments.length > 2) {
                        var s = Array.prototype.slice.call(arguments, 2);
                        return function() {
                            var r = Array.prototype.slice.call(arguments);
                            return Array.prototype.unshift.apply(r, s), e.apply(t, r)
                        }
                    }
                    return function() {
                        return e.apply(t, arguments)
                    }
                }

                function l(e, t, r) {
                    return (l = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? u : d).apply(null, arguments)
                }

                function c(e, t) {
                    function r() {}
                    r.prototype = t.prototype, e.N = t.prototype, e.prototype = new r, e.prototype.constructor = e, e.aa = function(e, r, s) {
                        for (var o = Array(arguments.length - 2), n = 2; n < arguments.length; n++) o[n - 2] = arguments[n];
                        return t.prototype[r].apply(e, o)
                    }
                }
                class p {
                    constructor(e) {
                        this.g = e || {}
                    }
                    get(e) {
                        return this.g[e]
                    }
                }
                class b {
                    constructor(e, t, r) {
                        var s = new p;
                        this.j = e, this.h = t, this.g = r, this.i = s
                    }
                    getRequestMessage() {
                        return this.j
                    }
                    getMethodDescriptor() {
                        return this.h
                    }
                    getMetadata() {
                        return this.g
                    }
                    getCallOptions() {
                        return this.i
                    }
                }
                class _ {
                    constructor(e, t, r = {}, s = null) {
                        this.i = e, this.g = r, this.h = t, this.j = s
                    }
                    getResponseMessage() {
                        return this.i
                    }
                    getMetadata() {
                        return this.g
                    }
                    getMethodDescriptor() {
                        return this.h
                    }
                    getStatus() {
                        return this.j
                    }
                }

                function $(e, t, r = {}) {
                    return new b(t, e, r)
                }
                const h = class {
                    constructor(e, t, r, s, o, n) {
                        this.name = e, this.g = o, this.h = n
                    }
                    getName() {
                        return this.name
                    }
                };
                h.prototype.getName = h.prototype.getName;
                class m {
                    constructor(e) {
                        this.g = e
                    }
                    on(e, t) {
                        return "data" == e || "error" == e ? this : this.g.on(e, t)
                    }
                    removeListener(e, t) {
                        return this.g.removeListener(e, t)
                    }
                    cancel() {
                        this.g.cancel()
                    }
                }

                function y(e, t) {
                    if (Error.captureStackTrace) Error.captureStackTrace(this, y);
                    else {
                        const e = Error().stack;
                        e && (this.stack = e)
                    }
                    e && (this.message = String(e)), void 0 !== t && (this.cause = t)
                }

                function f(e, t) {
                    let r = "";
                    const s = (e = e.split("%s")).length - 1;
                    for (let o = 0; o < s; o++) r += e[o] + (o < t.length ? t[o] : "%s");
                    y.call(this, r + e[s])
                }
                c(y, Error), y.prototype.name = "CustomError", c(f, y), f.prototype.name = "AssertionError";
                class j {
                    constructor() {
                        this.u = null, this.j = [], this.v = 0, this.h = S, this.l = this.g = this.o = 0, this.i = null, this.m = 0
                    }
                }
                var S = 0,
                    A = 1,
                    w = 2,
                    E = 3,
                    v = 0,
                    T = 128;

                function M(e, t, r, s) {
                    throw e.h = E, e.u = "The stream is broken @" + e.v + "/" + r + ". Error: " + s + ". With input:\n" + t, Error(e.u)
                }
                class I extends Error {
                    constructor(e, t, r = {}) {
                        super(t), this.code = e, this.metadata = r
                    }
                    toString() {
                        let e = `RpcError(${function(e){switch(e){case 0:return"OK";case 1:return"CANCELLED";case 2:return"UNKNOWN";case 3:return"INVALID_ARGUMENT";case 4:return"DEADLINE_EXCEEDED";case 5:return"NOT_FOUND";case 6:return"ALREADY_EXISTS";case 7:return"PERMISSION_DENIED";case 16:return"UNAUTHENTICATED";case 8:return"RESOURCE_EXHAUSTED";case 9:return"FAILED_PRECONDITION";case 10:return"ABORTED";case 11:return"OUT_OF_RANGE";case 12:return"UNIMPLEMENTED";case 13:return"INTERNAL";case 14:return"UNAVAILABLE";case 15:return"DATA_LOSS";default:return""}}(this.code)||String(this.code)})`;
                        return this.message && (e += ": " + this.message), e
                    }
                }
                I.prototype.name = "RpcError";
                const R = Array.prototype.indexOf ? function(e, t) {
                    return Array.prototype.indexOf.call(e, t, void 0)
                } : function(e, t) {
                    if ("string" == typeof e) return "string" != typeof t || 1 != t.length ? -1 : e.indexOf(t, 0);
                    for (let r = 0; r < e.length; r++)
                        if (r in e && e[r] === t) return r;
                    return -1
                };

                function F() {
                    var e = s.navigator;
                    return e && (e = e.userAgent) ? e : ""
                }

                function D(e) {
                    return -1 != F().indexOf(e)
                }

                function B(e) {
                    return B[" "](e), e
                }
                B[" "] = function() {};
                var O = D("Trident") || D("MSIE"),
                    P = D("Gecko") && !(-1 != F().toLowerCase().indexOf("webkit") && !D("Edge")) && !(D("Trident") || D("MSIE")) && !D("Edge"),
                    L = class {
                        constructor(e) {
                            if (x != x) throw Error("SafeUrl is not meant to be built directly");
                            this.g = e
                        }
                        toString() {
                            return this.g.toString()
                        }
                    },
                    x = {};
                new L("about:invalid#zClosurez"), new L("about:blank");
                new class {
                    constructor() {
                        false
                    }
                    toString() {
                        return "".toString()
                    }
                };
                const C = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
                new class {
                    constructor() {
                        false
                    }
                    toString() {
                        return "".toString()
                    }
                };

                function N(e) {
                    var t = 1;
                    e = e.split(":");
                    const r = [];
                    for (; t > 0 && e.length;) r.push(e.shift()), t--;
                    return e.length && r.push(e.join(":")), r
                }

                function U() {
                    0 != k && (J[i(this)] = this), this.v = this.v, this.o = this.o
                }
                new class {
                    constructor() {
                        var e = s.trustedTypes && s.trustedTypes.emptyHTML || "";
                        this.g = e
                    }
                    toString() {
                        return this.g.toString()
                    }
                };
                var k = 0,
                    J = {};
                U.prototype.v = !1, U.prototype.dispose = function() {
                    if (!this.v && (this.v = !0, this.C(), 0 != k)) {
                        var e = i(this);
                        if (0 != k && this.o && this.o.length > 0) throw Error(this + " did not empty its onDisposeCallbacks queue. This probably means it overrode dispose() or disposeInternal() without calling the superclass' method.");
                        delete J[e]
                    }
                }, U.prototype.C = function() {
                    if (this.o)
                        for (; this.o.length;) this.o.shift()()
                };
                var q = Object.freeze || function(e) {
                    return e
                };

                function W(e, t) {
                    this.type = e, this.g = this.target = t, this.defaultPrevented = !1
                }
                W.prototype.h = function() {
                    this.defaultPrevented = !0
                };
                var V = function() {
                    if (!s.addEventListener || !Object.defineProperty) return !1;
                    var e = !1,
                        t = Object.defineProperty({}, "passive", {
                            get: function() {
                                e = !0
                            }
                        });
                    try {
                        const e = () => {};
                        s.addEventListener("test", e, t), s.removeEventListener("test", e, t)
                    } catch (e) {}
                    return e
                }();

                function G(e, t) {
                    W.call(this, e ? e.type : ""), this.relatedTarget = this.g = this.target = null, this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0, this.key = "", this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1, this.state = null, this.pointerId = 0, this.pointerType = "", this.i = null, e && this.init(e, t)
                }
                c(G, W);
                var z = q({
                    2: "touch",
                    3: "pen",
                    4: "mouse"
                });
                G.prototype.init = function(e, t) {
                    var r = this.type = e.type,
                        s = e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : null;
                    if (this.target = e.target || e.srcElement, this.g = t, t = e.relatedTarget) {
                        if (P) {
                            e: {
                                try {
                                    B(t.nodeName);
                                    var o = !0;
                                    break e
                                } catch (e) {}
                                o = !1
                            }
                            o || (t = null)
                        }
                    } else "mouseover" == r ? t = e.fromElement : "mouseout" == r && (t = e.toElement);
                    this.relatedTarget = t, s ? (this.clientX = void 0 !== s.clientX ? s.clientX : s.pageX, this.clientY = void 0 !== s.clientY ? s.clientY : s.pageY, this.screenX = s.screenX || 0, this.screenY = s.screenY || 0) : (this.clientX = void 0 !== e.clientX ? e.clientX : e.pageX, this.clientY = void 0 !== e.clientY ? e.clientY : e.pageY, this.screenX = e.screenX || 0, this.screenY = e.screenY || 0), this.button = e.button, this.key = e.key || "", this.ctrlKey = e.ctrlKey, this.altKey = e.altKey, this.shiftKey = e.shiftKey, this.metaKey = e.metaKey, this.pointerId = e.pointerId || 0, this.pointerType = "string" == typeof e.pointerType ? e.pointerType : z[e.pointerType] || "", this.state = e.state, this.i = e, e.defaultPrevented && G.N.h.call(this)
                }, G.prototype.h = function() {
                    G.N.h.call(this);
                    var e = this.i;
                    e.preventDefault ? e.preventDefault() : e.returnValue = !1
                };
                var H = "closure_listenable_" + (1e6 * Math.random() | 0),
                    Y = 0;

                function Z(e, t, r, s, o) {
                    this.listener = e, this.proxy = null, this.src = t, this.type = r, this.capture = !!s, this.M = o, this.key = ++Y, this.D = this.L = !1
                }

                function X(e) {
                    e.D = !0, e.listener = null, e.proxy = null, e.src = null, e.M = null
                }

                function K(e) {
                    this.src = e, this.g = {}, this.h = 0
                }

                function Q(e, t) {
                    var r = t.type;
                    if (r in e.g) {
                        var s, o = e.g[r],
                            n = R(o, t);
                        (s = n >= 0) && Array.prototype.splice.call(o, n, 1), s && (X(t), 0 == e.g[r].length && (delete e.g[r], e.h--))
                    }
                }

                function ee(e, t, r, s) {
                    for (var o = 0; o < e.length; ++o) {
                        var n = e[o];
                        if (!n.D && n.listener == t && n.capture == !!r && n.M == s) return o
                    }
                    return -1
                }
                K.prototype.add = function(e, t, r, s, o) {
                    var n = e.toString();
                    (e = this.g[n]) || (e = this.g[n] = [], this.h++);
                    var i = ee(e, t, s, o);
                    return i > -1 ? (t = e[i], r || (t.L = !1)) : ((t = new Z(t, this.src, n, !!s, o)).L = r, e.push(t)), t
                };
                var te = "closure_lm_" + (1e6 * Math.random() | 0),
                    re = {};

                function se(e, t, r, s, o) {
                    if (s && s.once) ne(e, t, r, s, o);
                    else if (Array.isArray(t))
                        for (var i = 0; i < t.length; i++) se(e, t[i], r, s, o);
                    else r = ce(r), e && e[H] ? e.j.add(String(t), r, !1, n(s) ? !!s.capture : !!s, o) : oe(e, t, r, !1, s, o)
                }

                function oe(e, t, r, s, o, i) {
                    if (!t) throw Error("Invalid event type");
                    var a = n(o) ? !!o.capture : !!o,
                        g = de(e);
                    if (g || (e[te] = g = new K(e)), !(r = g.add(t, r, s, a, i)).proxy) {
                        if (s = function() {
                                function e(r) {
                                    return t.call(e.src, e.listener, r)
                                }
                                const t = ue;
                                return e
                            }(), r.proxy = s, s.src = e, s.listener = r, e.addEventListener) V || (o = a), void 0 === o && (o = !1), e.addEventListener(t.toString(), s, o);
                        else if (e.attachEvent) e.attachEvent(ge(t.toString()), s);
                        else {
                            if (!e.addListener || !e.removeListener) throw Error("addEventListener and attachEvent are unavailable.");
                            e.addListener(s)
                        }
                        0
                    }
                }

                function ne(e, t, r, s, o) {
                    if (Array.isArray(t))
                        for (var i = 0; i < t.length; i++) ne(e, t[i], r, s, o);
                    else r = ce(r), e && e[H] ? e.j.add(String(t), r, !0, n(s) ? !!s.capture : !!s, o) : oe(e, t, r, !0, s, o)
                }

                function ie(e, t, r, s, o) {
                    if (Array.isArray(t))
                        for (var i = 0; i < t.length; i++) ie(e, t[i], r, s, o);
                    else s = n(s) ? !!s.capture : !!s, r = ce(r), e && e[H] ? (e = e.j, (t = String(t).toString()) in e.g && ((r = ee(i = e.g[t], r, s, o)) > -1 && (X(i[r]), Array.prototype.splice.call(i, r, 1), 0 == i.length && (delete e.g[t], e.h--)))) : e && (e = de(e)) && (t = e.g[t.toString()], e = -1, t && (e = ee(t, r, s, o)), (r = e > -1 ? t[e] : null) && ae(r))
                }

                function ae(e) {
                    if ("number" != typeof e && e && !e.D) {
                        var t = e.src;
                        if (t && t[H]) Q(t.j, e);
                        else {
                            var r = e.type,
                                s = e.proxy;
                            t.removeEventListener ? t.removeEventListener(r, s, e.capture) : t.detachEvent ? t.detachEvent(ge(r), s) : t.addListener && t.removeListener && t.removeListener(s), (r = de(t)) ? (Q(r, e), 0 == r.h && (r.src = null, t[te] = null)) : X(e)
                        }
                    }
                }

                function ge(e) {
                    return e in re ? re[e] : re[e] = "on" + e
                }

                function ue(e, t) {
                    if (e.D) e = !0;
                    else {
                        t = new G(t, this);
                        var r = e.listener,
                            s = e.M || e.src;
                        e.L && ae(e), e = r.call(s, t)
                    }
                    return e
                }

                function de(e) {
                    return (e = e[te]) instanceof K ? e : null
                }
                var le = "__closure_events_fn_" + (1e9 * Math.random() >>> 0);

                function ce(e) {
                    return "function" == typeof e ? e : (e[le] || (e[le] = function(t) {
                        return e.handleEvent(t)
                    }), e[le])
                }

                function pe() {
                    U.call(this), this.j = new K(this), this.W = this, this.S = null
                }

                function be(e, t) {
                    var r, s = e.S;
                    if (s)
                        for (r = []; s; s = s.S) r.push(s);
                    if (e = e.W, s = t.type || t, "string" == typeof t) t = new W(t, e);
                    else if (t instanceof W) t.target = t.target || e;
                    else {
                        var o = t;
                        (function(e, t) {
                            let r, s;
                            for (let t = 1; t < arguments.length; t++) {
                                for (r in s = arguments[t], s) e[r] = s[r];
                                for (let t = 0; t < C.length; t++) r = C[t], Object.prototype.hasOwnProperty.call(s, r) && (e[r] = s[r])
                            }
                        })(t = new W(s, e), o)
                    }
                    if (o = !0, r)
                        for (var n = r.length - 1; n >= 0; n--) {
                            var i = t.g = r[n];
                            o = _e(i, s, !0, t) && o
                        }
                    if (o = _e(i = t.g = e, s, !0, t) && o, o = _e(i, s, !1, t) && o, r)
                        for (n = 0; n < r.length; n++) o = _e(i = t.g = r[n], s, !1, t) && o
                }

                function _e(e, t, r, s) {
                    if (!(t = e.j.g[String(t)])) return !0;
                    t = t.concat();
                    for (var o = !0, n = 0; n < t.length; ++n) {
                        var i = t[n];
                        if (i && !i.D && i.capture == r) {
                            var a = i.listener,
                                g = i.M || i.src;
                            i.L && Q(e.j, i), o = !1 !== a.call(g, s) && o
                        }
                    }
                    return o && !s.defaultPrevented
                }
                c(pe, U), pe.prototype[H] = !0, pe.prototype.removeEventListener = function(e, t, r, s) {
                    ie(this, e, t, r, s)
                }, pe.prototype.C = function() {
                    if (pe.N.C.call(this), this.j) {
                        var e, t = this.j;
                        for (e in t.g) {
                            for (var r = t.g[e], s = 0; s < r.length; s++) X(r[s]);
                            delete t.g[e], t.h--
                        }
                    }
                    this.S = null
                };
                var $e = s;

                function he(e, t, r) {
                    if ("function" == typeof e) r && (e = l(e, r));
                    else {
                        if (!e || "function" != typeof e.handleEvent) throw Error("Invalid listener argument");
                        e = l(e.handleEvent, e)
                    }
                    return Number(t) > 2147483647 ? -1 : $e.setTimeout(e, t || 0)
                }
                var me, ye = class {
                        constructor(e, t) {
                            this.name = e, this.value = t
                        }
                        toString() {
                            return this.name
                        }
                    },
                    fe = new ye("OFF", 1 / 0),
                    je = new ye("SEVERE", 1e3),
                    Se = new ye("CONFIG", 700),
                    Ae = new ye("FINE", 500),
                    we = class {},
                    Ee = class {
                        constructor(e, t, r) {
                            this.reset(e || fe, t, r, void 0, void 0)
                        }
                        reset() {}
                    };

                function ve(e) {
                    return e.g ? e.g : e.h ? ve(e.h) : (function(e, t) {
                        throw new f("Failure" + (e ? ": " + e : ""), Array.prototype.slice.call(arguments, 1))
                    }("Root logger has no level set."), fe)
                }
                var Te = class {
                    constructor(e, t = null) {
                        this.g = null, this.j = [], this.h = t || null, this.i = [], this.l = {
                            getName: () => e
                        }
                    }
                };

                function Me(e, t) {
                    var r = e.entries[t];
                    if (r) return r;
                    r = Me(e, t.slice(0, Math.max(t.lastIndexOf("."), 0)));
                    const s = new Te(t, r);
                    return e.entries[t] = s, r.i.push(s), s
                }
                var Ie, Re, Fe = class {
                    constructor() {
                        this.entries = {};
                        const e = new Te("");
                        e.g = Se, this.entries[""] = e
                    }
                };

                function De() {
                    return Ie || = new Fe, Ie
                }

                function Be(e, t, r) {
                    var s;
                    (s = e) && (s = e && t) && (s = (s = t.value) >= (e ? ve(Me(De(), e.getName())) : fe).value);
                    s && (t = t || fe, s = Me(De(), e.getName()), "function" == typeof r && (r = r()), me || = new we, e = e.getName(), function(e, t) {
                        for (; e;) e.j.forEach(e => {
                            e(t)
                        }), e = e.h
                    }(s, e = new Ee(t, r, e)))
                }

                function Oe(e, t) {
                    e && Be(e, je, t)
                }

                function Pe(e, t) {
                    e && Be(e, Ae, t)
                }

                function Le() {}

                function xe(e) {
                    var t;
                    return (t = e.g) || (t = {}, Ue(e) && (t[0] = !0, t[1] = !0), t = e.g = t), t
                }

                function Ce() {}

                function Ne(e) {
                    return (e = Ue(e)) ? new ActiveXObject(e) : new XMLHttpRequest
                }

                function Ue(e) {
                    if (!e.h && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
                        const t = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];
                        for (let r = 0; r < t.length; r++) {
                            const s = t[r];
                            try {
                                return new ActiveXObject(s), e.h = s
                            } catch (e) {}
                        }
                        throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed")
                    }
                    return e.h
                }
                Le.prototype.g = null, c(Ce, Le), Re = new Ce;
                var ke = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

                function Je(e) {
                    pe.call(this), this.headers = new Map, this.K = e || null, this.i = !1, this.J = this.g = null, this.T = this.G = "", this.m = 0, this.A = "", this.l = this.R = this.F = this.P = !1, this.u = 0, this.H = null, this.B = qe, this.I = this.O = !1
                }
                c(Je, pe);
                var qe = "";
                Je.prototype.h = Me(De(), "goog.net.XhrIo").l;
                var We = /^https?$/i,
                    Ve = ["POST", "PUT"];

                function Ge(e, t, r) {
                    if (e.g) throw Error("[goog.net.XhrIo] Object is active with another request=" + e.G + "; newUri=" + t);
                    e.G = t, e.A = "", e.m = 0, e.T = "POST", e.P = !1, e.i = !0, e.g = e.K ? Ne(e.K) : Ne(Re), e.J = e.K ? xe(e.K) : xe(Re), e.g.onreadystatechange = l(e.U, e);
                    try {
                        Pe(e.h, Qe(e, "Opening Xhr")), e.R = !0, e.g.open("POST", String(t), !0), e.R = !1
                    } catch (t) {
                        return Pe(e.h, Qe(e, "Error opening Xhr: " + t.message)), void ze(e, t)
                    }
                    t = r || "", r = new Map(e.headers);
                    const o = Array.from(r.keys()).find(e => "content-type" == e.toLowerCase()),
                        n = s.FormData && t instanceof s.FormData;
                    !(R(Ve, "POST") >= 0) || o || n || r.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
                    for (const [t, s] of r) e.g.setRequestHeader(t, s);
                    e.B && (e.g.responseType = e.B), "withCredentials" in e.g && e.g.withCredentials !== e.O && (e.g.withCredentials = e.O);
                    try {
                        Xe(e), e.u > 0 && (e.I = function(e) {
                            return O && "number" == typeof e.timeout && void 0 !== e.ontimeout
                        }(e.g), Pe(e.h, Qe(e, "Will abort after " + e.u + "ms if incomplete, xhr2 " + e.I)), e.I ? (e.g.timeout = e.u, e.g.ontimeout = l(e.V, e)) : e.H = he(e.V, e.u, e)), Pe(e.h, Qe(e, "Sending request")), e.F = !0, e.g.send(t), e.F = !1
                    } catch (t) {
                        Pe(e.h, Qe(e, "Send error: " + t.message)), ze(e, t)
                    }
                }

                function ze(e, t) {
                    e.i = !1, e.g && (e.l = !0, e.g.abort(), e.l = !1), e.A = t, e.m = 5, He(e), Ze(e)
                }

                function He(e) {
                    e.P || (e.P = !0, be(e, "complete"), be(e, "error"))
                }

                function Ye(e) {
                    if (e.i && void 0 !== r)
                        if (e.J[1] && 4 == Ke(e) && 2 == e.getStatus()) Pe(e.h, Qe(e, "Local request error detected and ignored"));
                        else if (e.F && 4 == Ke(e)) he(e.U, 0, e);
                    else if (be(e, "readystatechange"), 4 == Ke(e)) {
                        Pe(e.h, Qe(e, "Request complete")), e.i = !1;
                        try {
                            const r = e.getStatus();
                            e: switch (r) {
                                case 200:
                                case 201:
                                case 202:
                                case 204:
                                case 206:
                                case 304:
                                case 1223:
                                    var t = !0;
                                    break e;
                                default:
                                    t = !1
                            }
                            var o;
                            if (!(o = t)) {
                                var n;
                                if (n = 0 === r) {
                                    var i = String(e.G).match(ke)[1] || null;
                                    !i && s.self && s.self.location && (i = s.self.location.protocol.slice(0, -1)), n = !We.test(i ? i.toLowerCase() : "")
                                }
                                o = n
                            }
                            if (o) be(e, "complete"), be(e, "success");
                            else {
                                e.m = 6;
                                try {
                                    var a = Ke(e) > 2 ? e.g.statusText : ""
                                } catch (t) {
                                    Pe(e.h, "Can not get status: " + t.message), a = ""
                                }
                                e.A = a + " [" + e.getStatus() + "]", He(e)
                            }
                        } finally {
                            Ze(e)
                        }
                    }
                }

                function Ze(e, t) {
                    if (e.g) {
                        Xe(e);
                        const r = e.g,
                            s = e.J[0] ? () => {} : null;
                        e.g = null, e.J = null, t || be(e, "ready");
                        try {
                            r.onreadystatechange = s
                        } catch (t) {
                            Oe(e.h, "Problem encountered resetting onreadystatechange: " + t.message)
                        }
                    }
                }

                function Xe(e) {
                    e.g && e.I && (e.g.ontimeout = null), e.H && ($e.clearTimeout(e.H), e.H = null)
                }

                function Ke(e) {
                    return e.g ? e.g.readyState : 0
                }

                function Qe(e, t) {
                    return t + " [" + e.T + " " + e.G + " " + e.getStatus() + "]"
                }(t = Je.prototype).V = function() {
                    void 0 !== r && this.g && (this.A = "Timed out after " + this.u + "ms, aborting", this.m = 8, Pe(this.h, Qe(this, this.A)), be(this, "timeout"), this.abort(8))
                }, t.abort = function(e) {
                    this.g && this.i && (Pe(this.h, Qe(this, "Aborting")), this.i = !1, this.l = !0, this.g.abort(), this.l = !1, this.m = e || 7, be(this, "complete"), be(this, "abort"), Ze(this))
                }, t.C = function() {
                    this.g && (this.i && (this.i = !1, this.l = !0, this.g.abort(), this.l = !1), Ze(this, !0)), Je.N.C.call(this)
                }, t.U = function() {
                    this.v || (this.R || this.F || this.l ? Ye(this) : this.X())
                }, t.X = function() {
                    Ye(this)
                }, t.isActive = function() {
                    return !!this.g
                }, t.getStatus = function() {
                    try {
                        return Ke(this) > 2 ? this.g.status : -1
                    } catch (e) {
                        return -1
                    }
                };
                var et = {},
                    tt = null;

                function rt(e) {
                    var t = e.length,
                        r = 3 * t / 4;
                    r % 3 ? r = Math.floor(r) : -1 != "=.".indexOf(e[t - 1]) && (r = -1 != "=.".indexOf(e[t - 2]) ? r - 2 : r - 1);
                    var s = new Uint8Array(r),
                        o = 0;
                    return function(e, t) {
                        function r(t) {
                            for (; s < e.length;) {
                                var r = e.charAt(s++),
                                    o = tt[r];
                                if (null != o) return o;
                                if (!/^[\s\xa0]*$/.test(r)) throw Error("Unknown base64 encoding at char: " + r)
                            }
                            return t
                        }
                        st();
                        for (var s = 0;;) {
                            var o = r(-1),
                                n = r(0),
                                i = r(64),
                                a = r(64);
                            if (64 === a && -1 === o) break;
                            t(o << 2 | n >> 4), 64 != i && (t(n << 4 & 240 | i >> 2), 64 != a && t(i << 6 & 192 | a))
                        }
                    }(e, function(e) {
                        s[o++] = e
                    }), o !== r ? s.subarray(0, o) : s
                }

                function st() {
                    if (!tt) {
                        tt = {};
                        for (var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), t = ["+/=", "+/", "-_=", "-_.", "-_"], r = 0; r < 5; r++) {
                            var s = e.concat(t[r].split(""));
                            et[r] = s;
                            for (var o = 0; o < s.length; o++) {
                                var n = s[o];
                                void 0 === tt[n] && (tt[n] = o)
                            }
                        }
                    }
                }
                const ot = ["content-type", "grpc-status", "grpc-message"];

                function nt(e, t) {
                    if (0 != t.code) {
                        var r = new I(t.code, decodeURIComponent(t.message || ""), t.metadata);
                        for (let t = 0; t < e.j.length; t++) e.j[t](r)
                    }
                    for (t = {
                            code: t.code,
                            details: decodeURIComponent(t.message || ""),
                            metadata: t.metadata
                        }, r = 0; r < e.m.length; r++) e.m[r](t)
                }

                function it(e, t) {
                    (t = e.indexOf(t)) > -1 && e.splice(t, 1)
                }
                class at {
                    constructor(e) {
                        this.g = e.$, this.v = null, this.h = [], this.m = [], this.l = [], this.j = [], this.i = [], this.u = !1, this.o = 0, this.A = new j;
                        const t = this;
                        se(this.g, "readystatechange", function() {
                            var e = t.g;
                            if (e = e.g ? e.g.getResponseHeader("Content-Type") : null) {
                                if (0 == (e = e.toLowerCase()).lastIndexOf("application/grpc-web-text", 0)) {
                                    e = t.g;
                                    try {
                                        var r = e.g ? e.g.responseText : ""
                                    } catch (t) {
                                        Pe(e.h, "Can not get responseText: " + t.message), r = ""
                                    }
                                    if (r = (e = r || "").length - e.length % 4, 0 == (e = e.substr(t.o, r - t.o)).length) return;
                                    t.o = r, e = rt(e)
                                } else {
                                    if (0 != e.lastIndexOf("application/grpc", 0)) return void nt(t, new I(2, "Unknown Content-type received."));
                                    e = new Uint8Array(function(e) {
                                        try {
                                            if (!e.g) return null;
                                            if ("response" in e.g) return e.g.response;
                                            switch (e.B) {
                                                case qe:
                                                case "text":
                                                    return e.g.responseText;
                                                case "arraybuffer":
                                                    if ("mozResponseArrayBuffer" in e.g) return e.g.mozResponseArrayBuffer
                                            }
                                            return Oe(e.h, "Response type " + e.B + " is not supported on this browser"), null
                                        } catch (t) {
                                            return Pe(e.h, "Can not get response: " + t.message), null
                                        }
                                    }(t.g))
                                }
                                r = null;
                                try {
                                    r = function(e, t) {
                                        function r(e) {
                                            e == v || e == T ? a.o = e : M(a, i, g, "invalid frame byte"), a.h = A, a.g = 0, a.l = 0
                                        }

                                        function s(e) {
                                            a.l++, a.g = (a.g << 8) + e, 4 == a.l && (a.h = w, a.m = 0, "undefined" != typeof Uint8Array ? a.i = new Uint8Array(a.g) : a.i = Array(a.g), 0 == a.g && n())
                                        }

                                        function o(e) {
                                            a.i[a.m++] = e, a.m == a.g && n()
                                        }

                                        function n() {
                                            var e = {};
                                            e[a.o] = a.i, a.j.push(e), a.h = S
                                        }
                                        var i, a = e,
                                            g = 0;
                                        for (i = t instanceof Uint8Array || t instanceof Array ? t : new Uint8Array(t); g < i.length;) {
                                            switch (a.h) {
                                                case E:
                                                    M(a, i, g, "stream already broken");
                                                    break;
                                                case S:
                                                    r(i[g]);
                                                    break;
                                                case A:
                                                    s(i[g]);
                                                    break;
                                                case w:
                                                    o(i[g]);
                                                    break;
                                                default:
                                                    throw Error("unexpected parser state: " + a.h)
                                            }
                                            a.v++, g++
                                        }
                                        return e = a.j, a.j = [], e.length > 0 ? e : null
                                    }(t.A, e)
                                } catch (e) {
                                    nt(t, new I(2, "Error in parsing response body"))
                                }
                                if (r)
                                    for (e = 0; e < r.length; e++) {
                                        if (v in r[e]) {
                                            var s = r[e][v];
                                            if (s) {
                                                var o = !1;
                                                let e;
                                                try {
                                                    e = t.v(s), o = !0
                                                } catch (r) {
                                                    nt(t, new I(13, `Error when deserializing response data; error: ${r}, response: ${e}`))
                                                }
                                                if (o) {
                                                    s = t, o = e;
                                                    for (var n = 0; n < s.h.length; n++) s.h[n](o)
                                                }
                                            }
                                        }
                                        if (T in r[e] && r[e][T].length > 0) {
                                            for (s = "", o = 0; o < r[e][T].length; o++) s += String.fromCharCode(r[e][T][o]);
                                            for (s = s.trim().split("\r\n"), o = {}, n = 0; n < s.length; n++) {
                                                const e = s[n].indexOf(":");
                                                o[s[n].substring(0, e).trim()] = s[n].substring(e + 1).trim()
                                            }
                                            s = o, o = 0, n = "", "grpc-status" in s && (o = Number(s["grpc-status"]), delete s["grpc-status"]), "grpc-message" in s && (n = s["grpc-message"], delete s["grpc-message"]), nt(t, new I(o, n, s))
                                        }
                                    }
                            }
                        }), se(this.g, "complete", function() {
                            var e = t.g.m,
                                r = 2,
                                s = "";
                            const o = {};
                            r = function(e) {
                                const t = {};
                                e = (e.g && Ke(e) >= 2 && e.g.getAllResponseHeaders() || "").split("\r\n");
                                for (let s = 0; s < e.length; s++) {
                                    if (/^[\s\xa0]*$/.test(e[s])) continue;
                                    var r = N(e[s]);
                                    const o = r[0];
                                    if ("string" != typeof(r = r[1])) continue;
                                    r = r.trim();
                                    const n = t[o] || [];
                                    t[o] = n, n.push(r)
                                }
                                return function(e, t) {
                                    const r = {};
                                    for (const s in e) r[s] = t.call(void 0, e[s], s, e);
                                    return r
                                }(t, function(e) {
                                    return e.join(", ")
                                })
                            }(t.g);
                            const n = {};
                            for (var i in r) r.hasOwnProperty(i) && (n[i.toLowerCase()] = r[i]);
                            if (Object.keys(n).forEach(e => {
                                    ot.includes(e) || (o[e] = n[e])
                                }), function(e, t) {
                                    for (let r = 0; r < e.l.length; r++) e.l[r](t)
                                }(t, o), i = -1, 0 != e) {
                                switch (e) {
                                    case 7:
                                        r = 10;
                                        break;
                                    case 8:
                                        r = 4;
                                        break;
                                    case 6:
                                        r = function(e) {
                                            switch (e) {
                                                case 200:
                                                    return 0;
                                                case 400:
                                                    return 3;
                                                case 401:
                                                    return 16;
                                                case 403:
                                                    return 7;
                                                case 404:
                                                    return 5;
                                                case 409:
                                                    return 10;
                                                case 412:
                                                    return 9;
                                                case 429:
                                                    return 8;
                                                case 499:
                                                    return 1;
                                                case 500:
                                                default:
                                                    return 2;
                                                case 501:
                                                    return 12;
                                                case 503:
                                                    return 14;
                                                case 504:
                                                    return 4
                                            }
                                        }(i = t.g.getStatus());
                                        break;
                                    default:
                                        r = 14
                                }
                                10 == r && t.u || (s = function(e) {
                                    switch (e) {
                                        case 0:
                                            return "No Error";
                                        case 1:
                                            return "Access denied to content document";
                                        case 2:
                                            return "File not found";
                                        case 3:
                                            return "Firefox silently errored";
                                        case 4:
                                            return "Application custom error";
                                        case 5:
                                            return "An exception occurred";
                                        case 6:
                                            return "Http response at 400 or 500 level";
                                        case 7:
                                            return "Request was aborted";
                                        case 8:
                                            return "Request timed out";
                                        case 9:
                                            return "The resource is not available offline";
                                        default:
                                            return "Unrecognized error code"
                                    }
                                }(e), -1 != i && (s += ", http status code: " + i), nt(t, new I(r, s)))
                            } else e = !1, "grpc-status" in n && (r = Number(n["grpc-status"]), "grpc-message" in n && (s = n["grpc-message"]), 0 != r && (nt(t, new I(r, s || "", n)), e = !0)), e || function(e) {
                                for (let t = 0; t < e.i.length; t++) e.i[t]()
                            }(t)
                        })
                    }
                    on(e, t) {
                        return "data" == e ? this.h.push(t) : "status" == e ? this.m.push(t) : "metadata" == e ? this.l.push(t) : "end" == e ? this.i.push(t) : "error" == e && this.j.push(t), this
                    }
                    removeListener(e, t) {
                        return "data" == e ? it(this.h, t) : "status" == e ? it(this.m, t) : "metadata" == e ? it(this.l, t) : "end" == e ? it(this.i, t) : "error" == e && it(this.j, t), this
                    }
                    cancel() {
                        this.u = !0, this.g.abort()
                    }
                }

                function gt(e, t) {
                    return t.reduce((e, t) => r => t.intercept(r, e), e)
                }

                function ut(e, t, r) {
                    let s = !1,
                        o = null,
                        n = !1;
                    e.on("data", function(e) {
                        s = !0, o = e
                    }), e.on("error", function(e) {
                        0 == e.code || n || (n = !0, t(e, null))
                    }), e.on("status", function(e) {
                        0 == e.code || n ? r && t(null, null, e) : (n = !0, t({
                            code: e.code,
                            message: e.details,
                            metadata: e.metadata
                        }, null))
                    }), r && e.on("metadata", function(e) {
                        t(null, null, null, e)
                    }), e.on("end", function() {
                        n || (s ? r ? t(null, o, null, null, !0) : t(null, o) : t({
                            code: 2,
                            message: "Incomplete response"
                        })), r && t(null, null)
                    })
                }

                function dt(e, t, r) {
                    var s = t.getMethodDescriptor(),
                        o = r + s.getName();
                    (r = e.i ? e.i : new Je).O = e.j;
                    const n = new at({
                        $: r
                    });
                    n.v = s.h;
                    var i = t.getMetadata();
                    for (var a in i) r.headers.set(a, i[a]);
                    if ("text" == e.g ? (r.headers.set("Content-Type", "application/grpc-web-text"), r.headers.set("Accept", "application/grpc-web-text")) : r.headers.set("Content-Type", "application/grpc-web+proto"), r.headers.set("X-User-Agent", "grpc-web-javascript/0.1"), r.headers.set("X-Grpc-Web", "1"), r.headers.has("deadline") && (a = Number(r.headers.get("deadline")), a = Math.ceil(a - (new Date).getTime()), r.headers.delete("deadline"), a === 1 / 0 && (a = 0), a > 0 && (r.headers.set("grpc-timeout", a + "m"), r.u = Math.max(0, Math.max(1e3, Math.ceil(1.1 * a))))), e.l) {
                        for (g of (i = {}, (a = r.headers).keys())) i[g] = a.get(g);
                        var g = i;
                        r.headers.clear();
                        e: {
                            for (u in g) {
                                var u = !1;
                                break e
                            }
                            u = !0
                        }
                        u || (g = function(e) {
                            let t = "";
                            return function(e, t) {
                                for (const r in e) t.call(void 0, e[r], r, e)
                            }(e, function(e, r) {
                                t += r, t += ":", t += e, t += "\r\n"
                            }), t
                        }(g), "string" == typeof o ? (u = encodeURIComponent("$httpHeaders"), (u += g = null != g ? "=" + encodeURIComponent(String(g)) : "") && ((g = o.indexOf("#")) < 0 && (g = o.length), (a = o.indexOf("?")) < 0 || a > g ? (a = g, i = "") : i = o.substring(a + 1, g), g = (o = [o.slice(0, a), i, o.slice(g)])[1], o[1] = u ? g ? g + "&" + u : u : g, o = o[0] + (o[1] ? "?" + o[1] : "") + o[2])) : o.g("$httpHeaders", g))
                    }
                    for (s = (t = (0, s.g)(t.getRequestMessage())).length, u = [0, 0, 0, 0], g = new Uint8Array(5 + s), a = 3; a >= 0; a--) u[a] = s % 256, s >>>= 8;
                    if (g.set(new Uint8Array(u), 1), g.set(t, 5), t = g, "text" == e.g) {
                        var d;
                        for (e = t, void 0 === d && (d = 0), st(), d = et[d], t = Array(Math.floor(e.length / 3)), s = d[64] || "", u = g = 0; g < e.length - 2; g += 3) {
                            var l = e[g],
                                c = e[g + 1];
                            i = e[g + 2], a = d[l >> 2], l = d[(3 & l) << 4 | c >> 4], c = d[(15 & c) << 2 | i >> 6], i = d[63 & i], t[u++] = a + l + c + i
                        }
                        switch (a = 0, i = s, e.length - g) {
                            case 2:
                                i = d[(15 & (a = e[g + 1])) << 2] || s;
                            case 1:
                                e = e[g], t[u] = d[e >> 2] + d[(3 & e) << 4 | a >> 4] + i + s
                        }
                        t = t.join("")
                    } else "binary" == e.g && (r.B = "arraybuffer");
                    return Ge(r, o, t), n
                }

                function lt(e, t, r, s, o, n = {}) {
                    const i = t.substr(0, t.length - o.name.length),
                        a = n && n.signal;
                    return gt(t => new Promise((r, s) => {
                        if (a && a.aborted) {
                            const e = new I(1, "Aborted");
                            e.cause = a.reason, s(e)
                        } else {
                            var o, n, g, u = dt(e, t, i);
                            ut(u, (e, i, a, u, d) => {
                                e ? s(e) : d ? g = i : a ? n = a : u ? o = u : r(function(e, t, r = {}, s = null) {
                                    return new _(t, e, r, s)
                                }(t.getMethodDescriptor(), g, o, n))
                            }, !0), a && a.addEventListener("abort", () => {
                                u.cancel();
                                const e = new I(1, "Aborted");
                                e.cause = a.reason, s(e)
                            })
                        }
                    }), e.m).call(e, $(o, r, s)).then(e => e.getResponseMessage())
                }
                at.prototype.cancel = at.prototype.cancel, at.prototype.removeListener = at.prototype.removeListener, at.prototype.on = at.prototype.on;
                class ct {
                    constructor(e = {}, t) {
                        this.g = e.format || o("format", e) || "text", this.l = e.ca || o("suppressCorsPreflight", e) || !1, this.j = e.withCredentials || o("withCredentials", e) || !1, this.h = e.ba || o("streamInterceptors", e) || [], this.m = e.da || o("unaryInterceptors", e) || [], this.i = t || null
                    }
                    Y(e, t, r, s, o) {
                        const n = e.substr(0, e.length - s.name.length);
                        return ut(e = gt(e => dt(this, e, n), this.h).call(this, $(s, t, r)), o, !1), new m(e)
                    }
                    unaryCall(e, t, r, s, o = {}) {
                        return lt(this, e, t, r, s, o)
                    }
                    Z(e, t, r, s) {
                        const o = e.substr(0, e.length - s.name.length);
                        return gt(e => dt(this, e, o), this.h).call(this, $(s, t, r))
                    }
                }
                ct.prototype.serverStreaming = ct.prototype.Z, ct.prototype.unaryCall = ct.prototype.unaryCall, ct.prototype.rpcCall = ct.prototype.Y, e.exports.CallOptions = p, e.exports.MethodDescriptor = h, e.exports.GrpcWebClientBase = ct, e.exports.RpcError = I, e.exports.StatusCode = {
                    OK: 0,
                    CANCELLED: 1,
                    UNKNOWN: 2,
                    INVALID_ARGUMENT: 3,
                    DEADLINE_EXCEEDED: 4,
                    NOT_FOUND: 5,
                    ALREADY_EXISTS: 6,
                    PERMISSION_DENIED: 7,
                    UNAUTHENTICATED: 16,
                    RESOURCE_EXHAUSTED: 8,
                    FAILED_PRECONDITION: 9,
                    ABORTED: 10,
                    OUT_OF_RANGE: 11,
                    UNIMPLEMENTED: 12,
                    INTERNAL: 13,
                    UNAVAILABLE: 14,
                    DATA_LOSS: 15
                }, e.exports.MethodType = {
                    UNARY: "unary",
                    SERVER_STREAMING: "server_streaming",
                    BIDI_STREAMING: "bidi_streaming"
                }, $e = "undefined" != typeof globalThis && globalThis || self
            },
            1293(e) {
                "use strict";

                function t(e) {
                    this._maxSize = e, this.clear()
                }
                t.prototype.clear = function() {
                    this._size = 0, this._values = Object.create(null)
                }, t.prototype.get = function(e) {
                    return this._values[e]
                }, t.prototype.set = function(e, t) {
                    return this._size >= this._maxSize && this.clear(), e in this._values || this._size++, this._values[e] = t
                };
                var r = /[^.^\]^[]+|(?=\[\]|\.\.)/g,
                    s = /^\d+$/,
                    o = /^\d/,
                    n = /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g,
                    i = /^\s*(['"]?)(.*?)(\1)\s*$/,
                    a = new t(512),
                    g = new t(512),
                    u = new t(512);

                function d(e) {
                    return a.get(e) || a.set(e, l(e).map(function(e) {
                        return e.replace(i, "$2")
                    }))
                }

                function l(e) {
                    return e.match(r) || [""]
                }

                function c(e) {
                    return "string" == typeof e && e && -1 !== ["'", '"'].indexOf(e.charAt(0))
                }

                function p(e) {
                    return !c(e) && (function(e) {
                        return e.match(o) && !e.match(s)
                    }(e) || function(e) {
                        return n.test(e)
                    }(e))
                }
                e.exports = {
                    Cache: t,
                    split: l,
                    normalizePath: d,
                    setter: function(e) {
                        var t = d(e);
                        return g.get(e) || g.set(e, function(e, r) {
                            for (var s = 0, o = t.length, n = e; s < o - 1;) {
                                var i = t[s];
                                if ("__proto__" === i || "constructor" === i || "prototype" === i) return e;
                                n = n[t[s++]]
                            }
                            n[t[s]] = r
                        })
                    },
                    getter: function(e, t) {
                        var r = d(e);
                        return u.get(e) || u.set(e, function(e) {
                            for (var s = 0, o = r.length; s < o;) {
                                if (null == e && t) return;
                                e = e[r[s++]]
                            }
                            return e
                        })
                    },
                    join: function(e) {
                        return e.reduce(function(e, t) {
                            return e + (c(t) || s.test(t) ? "[" + t + "]" : (e ? "." : "") + t)
                        }, "")
                    },
                    forEach: function(e, t, r) {
                        ! function(e, t, r) {
                            var s, o, n, i, a = e.length;
                            for (o = 0; o < a; o++)(s = e[o]) && (p(s) && (s = '"' + s + '"'), n = !(i = c(s)) && /^\d+$/.test(s), t.call(r, s, i, n, o, e))
                        }(Array.isArray(e) ? e : l(e), t, r)
                    }
                }
            },
            5855(e) {
                const t = /[A-Z\xc0-\xd6\xd8-\xde]?[a-z\xdf-\xf6\xf8-\xff]+(?:['’](?:d|ll|m|re|s|t|ve))?(?=[\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000]|[A-Z\xc0-\xd6\xd8-\xde]|$)|(?:[A-Z\xc0-\xd6\xd8-\xde]|[^\ud800-\udfff\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\d+\u2700-\u27bfa-z\xdf-\xf6\xf8-\xffA-Z\xc0-\xd6\xd8-\xde])+(?:['’](?:D|LL|M|RE|S|T|VE))?(?=[\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000]|[A-Z\xc0-\xd6\xd8-\xde](?:[a-z\xdf-\xf6\xf8-\xff]|[^\ud800-\udfff\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\d+\u2700-\u27bfa-z\xdf-\xf6\xf8-\xffA-Z\xc0-\xd6\xd8-\xde])|$)|[A-Z\xc0-\xd6\xd8-\xde]?(?:[a-z\xdf-\xf6\xf8-\xff]|[^\ud800-\udfff\xac\xb1\xd7\xf7\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\xbf\u2000-\u206f \t\x0b\f\xa0\ufeff\n\r\u2028\u2029\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\d+\u2700-\u27bfa-z\xdf-\xf6\xf8-\xffA-Z\xc0-\xd6\xd8-\xde])+(?:['’](?:d|ll|m|re|s|t|ve))?|[A-Z\xc0-\xd6\xd8-\xde]+(?:['’](?:D|LL|M|RE|S|T|VE))?|\d*(?:1ST|2ND|3RD|(?![123])\dTH)(?=\b|[a-z_])|\d*(?:1st|2nd|3rd|(?![123])\dth)(?=\b|[A-Z_])|\d+|(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe2f\u20d0-\u20ff]|\ud83c[\udffb-\udfff])?(?:\u200d(?:[^\ud800-\udfff]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe2f\u20d0-\u20ff]|\ud83c[\udffb-\udfff])?)*/g,
                    r = e => e.match(t) || [],
                    s = e => e[0].toUpperCase() + e.slice(1),
                    o = (e, t) => r(e).join(t).toLowerCase(),
                    n = e => r(e).reduce((e, t) => `${e}${e?t[0].toUpperCase()+t.slice(1).toLowerCase():t.toLowerCase()}`, "");
                e.exports = {
                    words: r,
                    upperFirst: s,
                    camelCase: n,
                    pascalCase: e => s(n(e)),
                    snakeCase: e => o(e, "_"),
                    kebabCase: e => o(e, "-"),
                    sentenceCase: e => s(o(e, " ")),
                    titleCase: e => r(e).map(s).join(" ")
                }
            },
            2702(e) {
                function t(e, t) {
                    var r = e.length,
                        s = new Array(r),
                        o = {},
                        n = r,
                        i = function(e) {
                            for (var t = new Map, r = 0, s = e.length; r < s; r++) {
                                var o = e[r];
                                t.has(o[0]) || t.set(o[0], new Set), t.has(o[1]) || t.set(o[1], new Set), t.get(o[0]).add(o[1])
                            }
                            return t
                        }(t),
                        a = function(e) {
                            for (var t = new Map, r = 0, s = e.length; r < s; r++) t.set(e[r], r);
                            return t
                        }(e);
                    for (t.forEach(function(e) {
                            if (!a.has(e[0]) || !a.has(e[1])) throw new Error("Unknown node. There is an unknown node in the supplied edges.")
                        }); n--;) o[n] || g(e[n], n, new Set);
                    return s;

                    function g(e, t, n) {
                        if (n.has(e)) {
                            var u;
                            try {
                                u = ", node was:" + JSON.stringify(e)
                            } catch (e) {
                                u = ""
                            }
                            throw new Error("Cyclic dependency" + u)
                        }
                        if (!a.has(e)) throw new Error("Found unknown node. Make sure to provided all involved nodes. Unknown node: " + JSON.stringify(e));
                        if (!o[t]) {
                            o[t] = !0;
                            var d = i.get(e) || new Set;
                            if (t = (d = Array.from(d)).length) {
                                n.add(e);
                                do {
                                    var l = d[--t];
                                    g(l, a.get(l), n)
                                } while (t);
                                n.delete(e)
                            }
                            s[--r] = e
                        }
                    }
                }
                e.exports = function(e) {
                    return t(function(e) {
                        for (var t = new Set, r = 0, s = e.length; r < s; r++) {
                            var o = e[r];
                            t.add(o[0]), t.add(o[1])
                        }
                        return Array.from(t)
                    }(e), e)
                }, e.exports.array = t
            },
            8047(e, t, r) {
                var s;
                ! function(o, n) {
                    "use strict";
                    var i = "function",
                        a = "undefined",
                        g = "object",
                        u = "string",
                        d = "major",
                        l = "model",
                        c = "name",
                        p = "type",
                        b = "vendor",
                        _ = "version",
                        $ = "architecture",
                        h = "console",
                        m = "mobile",
                        y = "tablet",
                        f = "smarttv",
                        j = "wearable",
                        S = "embedded",
                        A = "Amazon",
                        w = "Apple",
                        E = "ASUS",
                        v = "BlackBerry",
                        T = "Browser",
                        M = "Chrome",
                        I = "Firefox",
                        R = "Google",
                        F = "Huawei",
                        D = "LG",
                        B = "Microsoft",
                        O = "Motorola",
                        P = "Opera",
                        L = "Samsung",
                        x = "Sharp",
                        C = "Sony",
                        N = "Xiaomi",
                        U = "Zebra",
                        k = "Facebook",
                        J = "Chromium OS",
                        q = "Mac OS",
                        W = " Browser",
                        V = function(e) {
                            for (var t = {}, r = 0; r < e.length; r++) t[e[r].toUpperCase()] = e[r];
                            return t
                        },
                        G = function(e, t) {
                            return typeof e === u && -1 !== z(t).indexOf(z(e))
                        },
                        z = function(e) {
                            return e.toLowerCase()
                        },
                        H = function(e, t) {
                            if (typeof e === u) return e = e.replace(/^\s\s*/, ""), typeof t === a ? e : e.substring(0, 500)
                        },
                        Y = function(e, t) {
                            for (var r, s, o, a, u, d, l = 0; l < t.length && !u;) {
                                var c = t[l],
                                    p = t[l + 1];
                                for (r = s = 0; r < c.length && !u && c[r];)
                                    if (u = c[r++].exec(e))
                                        for (o = 0; o < p.length; o++) d = u[++s], typeof(a = p[o]) === g && a.length > 0 ? 2 === a.length ? typeof a[1] == i ? this[a[0]] = a[1].call(this, d) : this[a[0]] = a[1] : 3 === a.length ? typeof a[1] !== i || a[1].exec && a[1].test ? this[a[0]] = d ? d.replace(a[1], a[2]) : n : this[a[0]] = d ? a[1].call(this, d, a[2]) : n : 4 === a.length && (this[a[0]] = d ? a[3].call(this, d.replace(a[1], a[2])) : n) : this[a] = d || n;
                                l += 2
                            }
                        },
                        Z = function(e, t) {
                            for (var r in t)
                                if (typeof t[r] === g && t[r].length > 0) {
                                    for (var s = 0; s < t[r].length; s++)
                                        if (G(t[r][s], e)) return "?" === r ? n : r
                                } else if (G(t[r], e)) return "?" === r ? n : r;
                            return t.hasOwnProperty("*") ? t["*"] : e
                        },
                        X = {
                            ME: "4.90",
                            "NT 3.11": "NT3.51",
                            "NT 4.0": "NT4.0",
                            2e3: "NT 5.0",
                            XP: ["NT 5.1", "NT 5.2"],
                            Vista: "NT 6.0",
                            7: "NT 6.1",
                            8: "NT 6.2",
                            8.1: "NT 6.3",
                            10: ["NT 6.4", "NT 10.0"],
                            RT: "ARM"
                        },
                        K = {
                            browser: [
                                [/\b(?:crmo|crios)\/([\w\.]+)/i],
                                [_, [c, "Chrome"]],
                                [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                                [_, [c, "Edge"]],
                                [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],
                                [c, _],
                                [/opios[\/ ]+([\w\.]+)/i],
                                [_, [c, P + " Mini"]],
                                [/\bop(?:rg)?x\/([\w\.]+)/i],
                                [_, [c, P + " GX"]],
                                [/\bopr\/([\w\.]+)/i],
                                [_, [c, P]],
                                [/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],
                                [_, [c, "Baidu"]],
                                [/\b(?:mxbrowser|mxios|myie2)\/?([-\w\.]*)\b/i],
                                [_, [c, "Maxthon"]],
                                [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer|sleipnir)[\/ ]?([\w\.]*)/i, /(avant|iemobile|slim(?:browser|boat|jet))[\/ ]?([\d\.]*)/i, /(?:ms|\()(ie) ([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|duckduckgo|klar|helio|(?=comodo_)?dragon)\/([-\w\.]+)/i, /(heytap|ovi|115)browser\/([\d\.]+)/i, /(weibo)__([\d\.]+)/i],
                                [c, _],
                                [/quark(?:pc)?\/([-\w\.]+)/i],
                                [_, [c, "Quark"]],
                                [/\bddg\/([\w\.]+)/i],
                                [_, [c, "DuckDuckGo"]],
                                [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                                [_, [c, "UC" + T]],
                                [/microm.+\bqbcore\/([\w\.]+)/i, /\bqbcore\/([\w\.]+).+microm/i, /micromessenger\/([\w\.]+)/i],
                                [_, [c, "WeChat"]],
                                [/konqueror\/([\w\.]+)/i],
                                [_, [c, "Konqueror"]],
                                [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                                [_, [c, "IE"]],
                                [/ya(?:search)?browser\/([\w\.]+)/i],
                                [_, [c, "Yandex"]],
                                [/slbrowser\/([\w\.]+)/i],
                                [_, [c, "Smart Lenovo " + T]],
                                [/(avast|avg)\/([\w\.]+)/i],
                                [
                                    [c, /(.+)/, "$1 Secure " + T], _
                                ],
                                [/\bfocus\/([\w\.]+)/i],
                                [_, [c, I + " Focus"]],
                                [/\bopt\/([\w\.]+)/i],
                                [_, [c, P + " Touch"]],
                                [/coc_coc\w+\/([\w\.]+)/i],
                                [_, [c, "Coc Coc"]],
                                [/dolfin\/([\w\.]+)/i],
                                [_, [c, "Dolphin"]],
                                [/coast\/([\w\.]+)/i],
                                [_, [c, P + " Coast"]],
                                [/miuibrowser\/([\w\.]+)/i],
                                [_, [c, "MIUI" + W]],
                                [/fxios\/([\w\.-]+)/i],
                                [_, [c, I]],
                                [/\bqihoobrowser\/?([\w\.]*)/i],
                                [_, [c, "360"]],
                                [/\b(qq)\/([\w\.]+)/i],
                                [
                                    [c, /(.+)/, "$1Browser"], _
                                ],
                                [/(oculus|sailfish|huawei|vivo|pico)browser\/([\w\.]+)/i],
                                [
                                    [c, /(.+)/, "$1" + W], _
                                ],
                                [/samsungbrowser\/([\w\.]+)/i],
                                [_, [c, L + " Internet"]],
                                [/metasr[\/ ]?([\d\.]+)/i],
                                [_, [c, "Sogou Explorer"]],
                                [/(sogou)mo\w+\/([\d\.]+)/i],
                                [
                                    [c, "Sogou Mobile"], _
                                ],
                                [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|2345(?=browser|chrome|explorer))\w*[\/ ]?v?([\w\.]+)/i],
                                [c, _],
                                [/(lbbrowser|rekonq)/i, /\[(linkedin)app\]/i],
                                [c],
                                [/ome\/([\w\.]+) \w* ?(iron) saf/i, /ome\/([\w\.]+).+qihu (360)[es]e/i],
                                [_, c],
                                [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                                [
                                    [c, k], _
                                ],
                                [/(Klarna)\/([\w\.]+)/i, /(kakao(?:talk|story))[\/ ]([\w\.]+)/i, /(naver)\(.*?(\d+\.[\w\.]+).*\)/i, /safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(alipay)client\/([\w\.]+)/i, /(twitter)(?:and| f.+e\/([\w\.]+))/i, /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i],
                                [c, _],
                                [/\bgsa\/([\w\.]+) .*safari\//i],
                                [_, [c, "GSA"]],
                                [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
                                [_, [c, "TikTok"]],
                                [/headlesschrome(?:\/([\w\.]+)| )/i],
                                [_, [c, M + " Headless"]],
                                [/ wv\).+(chrome)\/([\w\.]+)/i],
                                [
                                    [c, M + " WebView"], _
                                ],
                                [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                                [_, [c, "Android " + T]],
                                [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                                [c, _],
                                [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                                [_, [c, "Mobile Safari"]],
                                [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                                [_, c],
                                [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                                [c, [_, Z, {
                                    "1.0": "/8",
                                    1.2: "/1",
                                    1.3: "/3",
                                    "2.0": "/412",
                                    "2.0.2": "/416",
                                    "2.0.3": "/417",
                                    "2.0.4": "/419",
                                    "?": "/"
                                }]],
                                [/(webkit|khtml)\/([\w\.]+)/i],
                                [c, _],
                                [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                                [
                                    [c, "Netscape"], _
                                ],
                                [/(wolvic|librewolf)\/([\w\.]+)/i],
                                [c, _],
                                [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                                [_, [c, I + " Reality"]],
                                [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i, /(links) \(([\w\.]+)/i],
                                [c, [_, /_/g, "."]],
                                [/(cobalt)\/([\w\.]+)/i],
                                [c, [_, /master.|lts./, ""]]
                            ],
                            cpu: [
                                [/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],
                                [
                                    [$, "amd64"]
                                ],
                                [/(ia32(?=;))/i],
                                [
                                    [$, z]
                                ],
                                [/((?:i[346]|x)86)[;\)]/i],
                                [
                                    [$, "ia32"]
                                ],
                                [/\b(aarch64|arm(v?8e?l?|_?64))\b/i],
                                [
                                    [$, "arm64"]
                                ],
                                [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                                [
                                    [$, "armhf"]
                                ],
                                [/windows (ce|mobile); ppc;/i],
                                [
                                    [$, "arm"]
                                ],
                                [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],
                                [
                                    [$, /ower/, "", z]
                                ],
                                [/(sun4\w)[;\)]/i],
                                [
                                    [$, "sparc"]
                                ],
                                [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],
                                [
                                    [$, z]
                                ]
                            ],
                            device: [
                                [/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],
                                [l, [b, L],
                                    [p, y]
                                ],
                                [/\b((?:s[cgp]h|gt|sm)-(?![lr])\w+|sc[g-]?[\d]+a?|galaxy nexus)/i, /samsung[- ]((?!sm-[lr])[-\w]+)/i, /sec-(sgh\w+)/i],
                                [l, [b, L],
                                    [p, m]
                                ],
                                [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
                                [l, [b, w],
                                    [p, m]
                                ],
                                [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                                [l, [b, w],
                                    [p, y]
                                ],
                                [/(macintosh);/i],
                                [l, [b, w]],
                                [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                                [l, [b, x],
                                    [p, m]
                                ],
                                [/(?:honor)([-\w ]+)[;\)]/i],
                                [l, [b, "Honor"],
                                    [p, m]
                                ],
                                [/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i],
                                [l, [b, F],
                                    [p, y]
                                ],
                                [/(?:huawei)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],
                                [l, [b, F],
                                    [p, m]
                                ],
                                [/\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite|pro)?)(?: bui|\))/i],
                                [
                                    [l, /_/g, " "],
                                    [b, N],
                                    [p, m]
                                ],
                                [/oid[^\)]+; (2\d{4}(283|rpbf)[cgl])( bui|\))/i, /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i],
                                [
                                    [l, /_/g, " "],
                                    [b, N],
                                    [p, y]
                                ],
                                [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],
                                [l, [b, "OPPO"],
                                    [p, m]
                                ],
                                [/\b(opd2\d{3}a?) bui/i],
                                [l, [b, "OPPO"],
                                    [p, y]
                                ],
                                [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                                [l, [b, "Vivo"],
                                    [p, m]
                                ],
                                [/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],
                                [l, [b, "Realme"],
                                    [p, m]
                                ],
                                [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],
                                [l, [b, O],
                                    [p, m]
                                ],
                                [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                                [l, [b, O],
                                    [p, y]
                                ],
                                [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],
                                [l, [b, D],
                                    [p, y]
                                ],
                                [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i, /\blg-?([\d\w]+) bui/i],
                                [l, [b, D],
                                    [p, m]
                                ],
                                [/(ideatab[-\w ]+)/i, /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i],
                                [l, [b, "Lenovo"],
                                    [p, y]
                                ],
                                [/(?:maemo|nokia).*(n900|lumia \d+)/i, /nokia[-_ ]?([-\w\.]*)/i],
                                [
                                    [l, /_/g, " "],
                                    [b, "Nokia"],
                                    [p, m]
                                ],
                                [/(pixel c)\b/i],
                                [l, [b, R],
                                    [p, y]
                                ],
                                [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                                [l, [b, R],
                                    [p, m]
                                ],
                                [/droid.+; (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                                [l, [b, C],
                                    [p, m]
                                ],
                                [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                                [
                                    [l, "Xperia Tablet"],
                                    [b, C],
                                    [p, y]
                                ],
                                [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],
                                [l, [b, "OnePlus"],
                                    [p, m]
                                ],
                                [/(alexa)webm/i, /(kf[a-z]{2}wi|aeo(?!bc)\w\w)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
                                [l, [b, A],
                                    [p, y]
                                ],
                                [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                                [
                                    [l, /(.+)/g, "Fire Phone $1"],
                                    [b, A],
                                    [p, m]
                                ],
                                [/(playbook);[-\w\),; ]+(rim)/i],
                                [l, b, [p, y]],
                                [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                                [l, [b, v],
                                    [p, m]
                                ],
                                [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],
                                [l, [b, E],
                                    [p, y]
                                ],
                                [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                                [l, [b, E],
                                    [p, m]
                                ],
                                [/(nexus 9)/i],
                                [l, [b, "HTC"],
                                    [p, y]
                                ],
                                [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],
                                [b, [l, /_/g, " "],
                                    [p, m]
                                ],
                                [/droid [\w\.]+; ((?:8[14]9[16]|9(?:0(?:48|60|8[01])|1(?:3[27]|66)|2(?:6[69]|9[56])|466))[gqswx])\w*(\)| bui)/i],
                                [l, [b, "TCL"],
                                    [p, y]
                                ],
                                [/(itel) ((\w+))/i],
                                [
                                    [b, z], l, [p, Z, {
                                        tablet: ["p10001l", "w7001"],
                                        "*": "mobile"
                                    }]
                                ],
                                [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                                [l, [b, "Acer"],
                                    [p, y]
                                ],
                                [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                                [l, [b, "Meizu"],
                                    [p, m]
                                ],
                                [/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],
                                [l, [b, "Ulefone"],
                                    [p, m]
                                ],
                                [/; (energy ?\w+)(?: bui|\))/i, /; energizer ([\w ]+)(?: bui|\))/i],
                                [l, [b, "Energizer"],
                                    [p, m]
                                ],
                                [/; cat (b35);/i, /; (b15q?|s22 flip|s48c|s62 pro)(?: bui|\))/i],
                                [l, [b, "Cat"],
                                    [p, m]
                                ],
                                [/((?:new )?andromax[\w- ]+)(?: bui|\))/i],
                                [l, [b, "Smartfren"],
                                    [p, m]
                                ],
                                [/droid.+; (a(?:015|06[35]|142p?))/i],
                                [l, [b, "Nothing"],
                                    [p, m]
                                ],
                                [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron|infinix|tecno|micromax|advan)[-_ ]?([-\w]*)/i, /; (imo) ((?!tab)[\w ]+?)(?: bui|\))/i, /(hp) ([\w ]+\w)/i, /(asus)-?(\w+)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w]+)/i, /(jolla)/i, /(oppo) ?([\w ]+) bui/i],
                                [b, l, [p, m]],
                                [/(imo) (tab \w+)/i, /(kobo)\s(ereader|touch)/i, /(archos) (gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i],
                                [b, l, [p, y]],
                                [/(surface duo)/i],
                                [l, [b, B],
                                    [p, y]
                                ],
                                [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                                [l, [b, "Fairphone"],
                                    [p, m]
                                ],
                                [/(u304aa)/i],
                                [l, [b, "AT&T"],
                                    [p, m]
                                ],
                                [/\bsie-(\w*)/i],
                                [l, [b, "Siemens"],
                                    [p, m]
                                ],
                                [/\b(rct\w+) b/i],
                                [l, [b, "RCA"],
                                    [p, y]
                                ],
                                [/\b(venue[\d ]{2,7}) b/i],
                                [l, [b, "Dell"],
                                    [p, y]
                                ],
                                [/\b(q(?:mv|ta)\w+) b/i],
                                [l, [b, "Verizon"],
                                    [p, y]
                                ],
                                [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                                [l, [b, "Barnes & Noble"],
                                    [p, y]
                                ],
                                [/\b(tm\d{3}\w+) b/i],
                                [l, [b, "NuVision"],
                                    [p, y]
                                ],
                                [/\b(k88) b/i],
                                [l, [b, "ZTE"],
                                    [p, y]
                                ],
                                [/\b(nx\d{3}j) b/i],
                                [l, [b, "ZTE"],
                                    [p, m]
                                ],
                                [/\b(gen\d{3}) b.+49h/i],
                                [l, [b, "Swiss"],
                                    [p, m]
                                ],
                                [/\b(zur\d{3}) b/i],
                                [l, [b, "Swiss"],
                                    [p, y]
                                ],
                                [/\b((zeki)?tb.*\b) b/i],
                                [l, [b, "Zeki"],
                                    [p, y]
                                ],
                                [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                                [
                                    [b, "Dragon Touch"], l, [p, y]
                                ],
                                [/\b(ns-?\w{0,9}) b/i],
                                [l, [b, "Insignia"],
                                    [p, y]
                                ],
                                [/\b((nxa|next)-?\w{0,9}) b/i],
                                [l, [b, "NextBook"],
                                    [p, y]
                                ],
                                [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                                [
                                    [b, "Voice"], l, [p, m]
                                ],
                                [/\b(lvtel\-)?(v1[12]) b/i],
                                [
                                    [b, "LvTel"], l, [p, m]
                                ],
                                [/\b(ph-1) /i],
                                [l, [b, "Essential"],
                                    [p, m]
                                ],
                                [/\b(v(100md|700na|7011|917g).*\b) b/i],
                                [l, [b, "Envizen"],
                                    [p, y]
                                ],
                                [/\b(trio[-\w\. ]+) b/i],
                                [l, [b, "MachSpeed"],
                                    [p, y]
                                ],
                                [/\btu_(1491) b/i],
                                [l, [b, "Rotor"],
                                    [p, y]
                                ],
                                [/(shield[\w ]+) b/i],
                                [l, [b, "Nvidia"],
                                    [p, y]
                                ],
                                [/(sprint) (\w+)/i],
                                [b, l, [p, m]],
                                [/(kin\.[onetw]{3})/i],
                                [
                                    [l, /\./g, " "],
                                    [b, B],
                                    [p, m]
                                ],
                                [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                                [l, [b, U],
                                    [p, y]
                                ],
                                [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                                [l, [b, U],
                                    [p, m]
                                ],
                                [/smart-tv.+(samsung)/i],
                                [b, [p, f]],
                                [/hbbtv.+maple;(\d+)/i],
                                [
                                    [l, /^/, "SmartTV"],
                                    [b, L],
                                    [p, f]
                                ],
                                [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                                [
                                    [b, D],
                                    [p, f]
                                ],
                                [/(apple) ?tv/i],
                                [b, [l, w + " TV"],
                                    [p, f]
                                ],
                                [/crkey/i],
                                [
                                    [l, M + "cast"],
                                    [b, R],
                                    [p, f]
                                ],
                                [/droid.+aft(\w+)( bui|\))/i],
                                [l, [b, A],
                                    [p, f]
                                ],
                                [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                                [l, [b, x],
                                    [p, f]
                                ],
                                [/(bravia[\w ]+)( bui|\))/i],
                                [l, [b, C],
                                    [p, f]
                                ],
                                [/(mitv-\w{5}) bui/i],
                                [l, [b, N],
                                    [p, f]
                                ],
                                [/Hbbtv.*(technisat) (.*);/i],
                                [b, l, [p, f]],
                                [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],
                                [
                                    [b, H],
                                    [l, H],
                                    [p, f]
                                ],
                                [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                                [
                                    [p, f]
                                ],
                                [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                                [b, l, [p, h]],
                                [/droid.+; (shield) bui/i],
                                [l, [b, "Nvidia"],
                                    [p, h]
                                ],
                                [/(playstation [345portablevi]+)/i],
                                [l, [b, C],
                                    [p, h]
                                ],
                                [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                                [l, [b, B],
                                    [p, h]
                                ],
                                [/\b(sm-[lr]\d\d[05][fnuw]?s?)\b/i],
                                [l, [b, L],
                                    [p, j]
                                ],
                                [/((pebble))app/i],
                                [b, l, [p, j]],
                                [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
                                [l, [b, w],
                                    [p, j]
                                ],
                                [/droid.+; (glass) \d/i],
                                [l, [b, R],
                                    [p, j]
                                ],
                                [/droid.+; (wt63?0{2,3})\)/i],
                                [l, [b, U],
                                    [p, j]
                                ],
                                [/droid.+; (glass) \d/i],
                                [l, [b, R],
                                    [p, j]
                                ],
                                [/(pico) (4|neo3(?: link|pro)?)/i],
                                [b, l, [p, j]],
                                [/; (quest( \d| pro)?)/i],
                                [l, [b, k],
                                    [p, j]
                                ],
                                [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                                [b, [p, S]],
                                [/(aeobc)\b/i],
                                [l, [b, A],
                                    [p, S]
                                ],
                                [/droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i],
                                [l, [p, m]],
                                [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                                [l, [p, y]],
                                [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                                [
                                    [p, y]
                                ],
                                [/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],
                                [
                                    [p, m]
                                ],
                                [/(android[-\w\. ]{0,9});.+buil/i],
                                [l, [b, "Generic"]]
                            ],
                            engine: [
                                [/windows.+ edge\/([\w\.]+)/i],
                                [_, [c, "EdgeHTML"]],
                                [/(arkweb)\/([\w\.]+)/i],
                                [c, _],
                                [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                                [_, [c, "Blink"]],
                                [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna|servo)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i, /\b(libweb)/i],
                                [c, _],
                                [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                                [_, c]
                            ],
                            os: [
                                [/microsoft (windows) (vista|xp)/i],
                                [c, _],
                                [/(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i],
                                [c, [_, Z, X]],
                                [/windows nt 6\.2; (arm)/i, /windows[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i, /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
                                [
                                    [_, Z, X],
                                    [c, "Windows"]
                                ],
                                [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, /cfnetwork\/.+darwin/i],
                                [
                                    [_, /_/g, "."],
                                    [c, "iOS"]
                                ],
                                [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i],
                                [
                                    [c, q],
                                    [_, /_/g, "."]
                                ],
                                [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                                [_, c],
                                [/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish|openharmony)[-\/ ]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/ ]([\w\.]+)/i, /\((series40);/i],
                                [c, _],
                                [/\(bb(10);/i],
                                [_, [c, v]],
                                [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],
                                [_, [c, "Symbian"]],
                                [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],
                                [_, [c, I + " OS"]],
                                [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                                [_, [c, "webOS"]],
                                [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
                                [_, [c, "watchOS"]],
                                [/crkey\/([\d\.]+)/i],
                                [_, [c, M + "cast"]],
                                [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
                                [
                                    [c, J], _
                                ],
                                [/panasonic;(viera)/i, /(netrange)mmh/i, /(nettv)\/(\d+\.[\w\.]+)/i, /(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i],
                                [c, _],
                                [/(sunos) ?([\w\.\d]*)/i],
                                [
                                    [c, "Solaris"], _
                                ],
                                [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i, /(unix) ?([\w\.]*)/i],
                                [c, _]
                            ]
                        },
                        Q = function(e, t) {
                            if (typeof e === g && (t = e, e = n), !(this instanceof Q)) return new Q(e, t).getResult();
                            var r = typeof o !== a && o.navigator ? o.navigator : n,
                                s = e || (r && r.userAgent ? r.userAgent : ""),
                                h = r && r.userAgentData ? r.userAgentData : n,
                                f = t ? function(e, t) {
                                    var r = {};
                                    for (var s in e) t[s] && t[s].length % 2 == 0 ? r[s] = t[s].concat(e[s]) : r[s] = e[s];
                                    return r
                                }(K, t) : K,
                                j = r && r.userAgent == s;
                            return this.getBrowser = function() {
                                var e, t = {};
                                return t[c] = n, t[_] = n, Y.call(t, s, f.browser), t[d] = typeof(e = t[_]) === u ? e.replace(/[^\d\.]/g, "").split(".")[0] : n, j && r && r.brave && typeof r.brave.isBrave == i && (t[c] = "Brave"), t
                            }, this.getCPU = function() {
                                var e = {};
                                return e[$] = n, Y.call(e, s, f.cpu), e
                            }, this.getDevice = function() {
                                var e = {};
                                return e[b] = n, e[l] = n, e[p] = n, Y.call(e, s, f.device), j && !e[p] && h && h.mobile && (e[p] = m), j && "Macintosh" == e[l] && r && typeof r.standalone !== a && r.maxTouchPoints && r.maxTouchPoints > 2 && (e[l] = "iPad", e[p] = y), e
                            }, this.getEngine = function() {
                                var e = {};
                                return e[c] = n, e[_] = n, Y.call(e, s, f.engine), e
                            }, this.getOS = function() {
                                var e = {};
                                return e[c] = n, e[_] = n, Y.call(e, s, f.os), j && !e[c] && h && h.platform && "Unknown" != h.platform && (e[c] = h.platform.replace(/chrome os/i, J).replace(/macos/i, q)), e
                            }, this.getResult = function() {
                                return {
                                    ua: this.getUA(),
                                    browser: this.getBrowser(),
                                    engine: this.getEngine(),
                                    os: this.getOS(),
                                    device: this.getDevice(),
                                    cpu: this.getCPU()
                                }
                            }, this.getUA = function() {
                                return s
                            }, this.setUA = function(e) {
                                return s = typeof e === u && e.length > 500 ? H(e, 500) : e, this
                            }, this.setUA(s), this
                        };
                    Q.VERSION = "1.0.40", Q.BROWSER = V([c, _, d]), Q.CPU = V([$]), Q.DEVICE = V([l, b, p, h, m, f, y, j, S]), Q.ENGINE = Q.OS = V([c, _]), typeof t !== a ? (e.exports && (t = e.exports = Q), t.UAParser = Q) : r.amdO ? (s = function() {
                        return Q
                    }.call(t, r, t, e)) === n || (e.exports = s) : typeof o !== a && (o.UAParser = Q);
                    var ee = typeof o !== a && (o.jQuery || o.Zepto);
                    if (ee && !ee.ua) {
                        var te = new Q;
                        ee.ua = te.getResult(), ee.ua.get = function() {
                            return te.getUA()
                        }, ee.ua.set = function(e) {
                            te.setUA(e);
                            var t = te.getResult();
                            for (var r in t) ee.ua[r] = t[r]
                        }
                    }
                }("object" == typeof window ? window : this)
            },
            9313(e, t, r) {
                "use strict";
                r.d(t, {
                    Ik: () => be,
                    RZ: () => me,
                    YO: () => $e,
                    Yj: () => ee,
                    ai: () => re,
                    gl: () => k,
                    zM: () => q
                });
                var s = r(1293),
                    o = r(5855),
                    n = r(2702),
                    i = r.n(n);
                const a = Object.prototype.toString,
                    g = Error.prototype.toString,
                    u = RegExp.prototype.toString,
                    d = "undefined" != typeof Symbol ? Symbol.prototype.toString : () => "",
                    l = /^Symbol\((.*)\)(.*)$/;

                function c(e, t = !1) {
                    if (null == e || !0 === e || !1 === e) return "" + e;
                    const r = typeof e;
                    if ("number" === r) return function(e) {
                        return e != +e ? "NaN" : 0 === e && 1 / e < 0 ? "-0" : "" + e
                    }(e);
                    if ("string" === r) return t ? `"${e}"` : e;
                    if ("function" === r) return "[Function " + (e.name || "anonymous") + "]";
                    if ("symbol" === r) return d.call(e).replace(l, "Symbol($1)");
                    const s = a.call(e).slice(8, -1);
                    return "Date" === s ? isNaN(e.getTime()) ? "" + e : e.toISOString(e) : "Error" === s || e instanceof Error ? "[" + g.call(e) + "]" : "RegExp" === s ? u.call(e) : null
                }

                function p(e, t) {
                    let r = c(e, t);
                    return null !== r ? r : JSON.stringify(e, function(e, r) {
                        let s = c(this[e], t);
                        return null !== s ? s : r
                    }, 2)
                }

                function b(e) {
                    return null == e ? [] : [].concat(e)
                }
                let _, $, h, m = /\$\{\s*(\w+)\s*\}/g;
                _ = Symbol.toStringTag;
                class y {
                    constructor(e, t, r, s) {
                        this.name = void 0, this.message = void 0, this.value = void 0, this.path = void 0, this.type = void 0, this.params = void 0, this.errors = void 0, this.inner = void 0, this[_] = "Error", this.name = "ValidationError", this.value = t, this.path = r, this.type = s, this.errors = [], this.inner = [], b(e).forEach(e => {
                            if (f.isError(e)) {
                                this.errors.push(...e.errors);
                                const t = e.inner.length ? e.inner : [e];
                                this.inner.push(...t)
                            } else this.errors.push(e)
                        }), this.message = this.errors.length > 1 ? `${this.errors.length} errors occurred` : this.errors[0]
                    }
                }
                $ = Symbol.hasInstance, h = Symbol.toStringTag;
                class f extends Error {
                    static formatError(e, t) {
                        const r = t.label || t.path || "this";
                        return t = Object.assign({}, t, {
                            path: r,
                            originalPath: t.path
                        }), "string" == typeof e ? e.replace(m, (e, r) => p(t[r])) : "function" == typeof e ? e(t) : e
                    }
                    static isError(e) {
                        return e && "ValidationError" === e.name
                    }
                    constructor(e, t, r, s, o) {
                        const n = new y(e, t, r, s);
                        if (o) return n;
                        super(), this.value = void 0, this.path = void 0, this.type = void 0, this.params = void 0, this.errors = [], this.inner = [], this[h] = "Error", this.name = n.name, this.message = n.message, this.type = n.type, this.value = n.value, this.path = n.path, this.errors = n.errors, this.inner = n.inner, Error.captureStackTrace && Error.captureStackTrace(this, f)
                    }
                    static[$](e) {
                        return y[Symbol.hasInstance](e) || super[Symbol.hasInstance](e)
                    }
                }
                let j = {
                        default: "${path} is invalid",
                        required: "${path} is a required field",
                        defined: "${path} must be defined",
                        notNull: "${path} cannot be null",
                        oneOf: "${path} must be one of the following values: ${values}",
                        notOneOf: "${path} must not be one of the following values: ${values}",
                        notType: ({
                            path: e,
                            type: t,
                            value: r,
                            originalValue: s
                        }) => {
                            const o = null != s && s !== r ? ` (cast from the value \`${p(s,!0)}\`).` : ".";
                            return "mixed" !== t ? `${e} must be a \`${t}\` type, but the final value was: \`${p(r,!0)}\`` + o : `${e} must match the configured type. The validated value was: \`${p(r,!0)}\`` + o
                        }
                    },
                    S = {
                        length: "${path} must be exactly ${length} characters",
                        min: "${path} must be at least ${min} characters",
                        max: "${path} must be at most ${max} characters",
                        matches: '${path} must match the following: "${regex}"',
                        email: "${path} must be a valid email",
                        url: "${path} must be a valid URL",
                        uuid: "${path} must be a valid UUID",
                        datetime: "${path} must be a valid ISO date-time",
                        datetime_precision: "${path} must be a valid ISO date-time with a sub-second precision of exactly ${precision} digits",
                        datetime_offset: '${path} must be a valid ISO date-time with UTC "Z" timezone',
                        trim: "${path} must be a trimmed string",
                        lowercase: "${path} must be a lowercase string",
                        uppercase: "${path} must be a upper case string"
                    },
                    A = {
                        min: "${path} must be greater than or equal to ${min}",
                        max: "${path} must be less than or equal to ${max}",
                        lessThan: "${path} must be less than ${less}",
                        moreThan: "${path} must be greater than ${more}",
                        positive: "${path} must be a positive number",
                        negative: "${path} must be a negative number",
                        integer: "${path} must be an integer"
                    },
                    w = {
                        min: "${path} field must be later than ${min}",
                        max: "${path} field must be at earlier than ${max}"
                    },
                    E = {
                        isValue: "${path} field must be ${value}"
                    },
                    v = {
                        noUnknown: "${path} field has unspecified keys: ${unknown}",
                        exact: "${path} object contains unknown properties: ${properties}"
                    },
                    T = {
                        min: "${path} field must have at least ${min} items",
                        max: "${path} field must have less than or equal to ${max} items",
                        length: "${path} must have ${length} items"
                    },
                    M = {
                        notType: e => {
                            const {
                                path: t,
                                value: r,
                                spec: s
                            } = e, o = s.types.length;
                            if (Array.isArray(r)) {
                                if (r.length < o) return `${t} tuple value has too few items, expected a length of ${o} but got ${r.length} for value: \`${p(r,!0)}\``;
                                if (r.length > o) return `${t} tuple value has too many items, expected a length of ${o} but got ${r.length} for value: \`${p(r,!0)}\``
                            }
                            return f.formatError(j.notType, e)
                        }
                    };
                Object.assign(Object.create(null), {
                    mixed: j,
                    string: S,
                    number: A,
                    date: w,
                    object: v,
                    array: T,
                    boolean: E,
                    tuple: M
                });
                const I = e => e && e.__isYupSchema__;
                class R {
                    static fromOptions(e, t) {
                        if (!t.then && !t.otherwise) throw new TypeError("either `then:` or `otherwise:` is required for `when()` conditions");
                        let {
                            is: r,
                            then: s,
                            otherwise: o
                        } = t, n = "function" == typeof r ? r : (...e) => e.every(e => e === r);
                        return new R(e, (e, t) => {
                            var r;
                            let i = n(...e) ? s : o;
                            return null != (r = null == i ? void 0 : i(t)) ? r : t
                        })
                    }
                    constructor(e, t) {
                        this.fn = void 0, this.refs = e, this.refs = e, this.fn = t
                    }
                    resolve(e, t) {
                        let r = this.refs.map(e => e.getValue(null == t ? void 0 : t.value, null == t ? void 0 : t.parent, null == t ? void 0 : t.context)),
                            s = this.fn(r, e, t);
                        if (void 0 === s || s === e) return e;
                        if (!I(s)) throw new TypeError("conditions must return a schema object");
                        return s.resolve(t)
                    }
                }
                const F = "$",
                    D = ".";
                class B {
                    constructor(e, t = {}) {
                        if (this.key = void 0, this.isContext = void 0, this.isValue = void 0, this.isSibling = void 0, this.path = void 0, this.getter = void 0, this.map = void 0, "string" != typeof e) throw new TypeError("ref must be a string, got: " + e);
                        if (this.key = e.trim(), "" === e) throw new TypeError("ref must be a non-empty string");
                        this.isContext = this.key[0] === F, this.isValue = this.key[0] === D, this.isSibling = !this.isContext && !this.isValue;
                        let r = this.isContext ? F : this.isValue ? D : "";
                        this.path = this.key.slice(r.length), this.getter = this.path && (0, s.getter)(this.path, !0), this.map = t.map
                    }
                    getValue(e, t, r) {
                        let s = this.isContext ? r : this.isValue ? e : t;
                        return this.getter && (s = this.getter(s || {})), this.map && (s = this.map(s)), s
                    }
                    cast(e, t) {
                        return this.getValue(e, null == t ? void 0 : t.parent, null == t ? void 0 : t.context)
                    }
                    resolve() {
                        return this
                    }
                    describe() {
                        return {
                            type: "ref",
                            key: this.key
                        }
                    }
                    toString() {
                        return `Ref(${this.key})`
                    }
                    static isRef(e) {
                        return e && e.__isYupRef
                    }
                }
                B.prototype.__isYupRef = !0;
                const O = e => null == e;

                function P(e) {
                    function t({
                        value: t,
                        path: r = "",
                        options: s,
                        originalValue: o,
                        schema: n
                    }, i, a) {
                        const {
                            name: g,
                            test: u,
                            params: d,
                            message: l,
                            skipAbsent: c
                        } = e;
                        let {
                            parent: p,
                            context: b,
                            abortEarly: _ = n.spec.abortEarly,
                            disableStackTrace: $ = n.spec.disableStackTrace
                        } = s;

                        function h(e) {
                            return B.isRef(e) ? e.getValue(t, p, b) : e
                        }

                        function m(e = {}) {
                            const s = Object.assign({
                                value: t,
                                originalValue: o,
                                label: n.spec.label,
                                path: e.path || r,
                                spec: n.spec,
                                disableStackTrace: e.disableStackTrace || $
                            }, d, e.params);
                            for (const e of Object.keys(s)) s[e] = h(s[e]);
                            const i = new f(f.formatError(e.message || l, s), t, s.path, e.type || g, s.disableStackTrace);
                            return i.params = s, i
                        }
                        const y = _ ? i : a;
                        let j = {
                            path: r,
                            parent: p,
                            type: g,
                            from: s.from,
                            createError: m,
                            resolve: h,
                            options: s,
                            originalValue: o,
                            schema: n
                        };
                        const S = e => {
                                f.isError(e) ? y(e) : e ? a(null) : y(m())
                            },
                            A = e => {
                                f.isError(e) ? y(e) : i(e)
                            };
                        if (c && O(t)) return S(!0);
                        let w;
                        try {
                            var E;
                            if (w = u.call(j, t, j), "function" == typeof(null == (E = w) ? void 0 : E.then)) {
                                if (s.sync) throw new Error(`Validation test of type: "${j.type}" returned a Promise during a synchronous validate. This test will finish after the validate call has returned`);
                                return Promise.resolve(w).then(S, A)
                            }
                        } catch (e) {
                            return void A(e)
                        }
                        S(w)
                    }
                    return t.OPTIONS = e, t
                }

                function L(e, t, r, o = r) {
                    let n, i, a;
                    return t ? ((0, s.forEach)(t, (s, g, u) => {
                        let d = g ? s.slice(1, s.length - 1) : s,
                            l = "tuple" === (e = e.resolve({
                                context: o,
                                parent: n,
                                value: r
                            })).type,
                            c = u ? parseInt(d, 10) : 0;
                        if (e.innerType || l) {
                            if (l && !u) throw new Error(`Yup.reach cannot implicitly index into a tuple type. the path part "${a}" must contain an index to the tuple element, e.g. "${a}[0]"`);
                            if (r && c >= r.length) throw new Error(`Yup.reach cannot resolve an array item at index: ${s}, in the path: ${t}. because there is no value at that index. `);
                            n = r, r = r && r[c], e = l ? e.spec.types[c] : e.innerType
                        }
                        if (!u) {
                            if (!e.fields || !e.fields[d]) throw new Error(`The schema does not contain the path: ${t}. (failed at: ${a} which is a type: "${e.type}")`);
                            n = r, r = r && r[d], e = e.fields[d]
                        }
                        i = d, a = g ? "[" + s + "]" : "." + s
                    }), {
                        schema: e,
                        parent: n,
                        parentPath: i
                    }) : {
                        parent: n,
                        parentPath: t,
                        schema: e
                    }
                }
                class x extends Set {
                    describe() {
                        const e = [];
                        for (const t of this.values()) e.push(B.isRef(t) ? t.describe() : t);
                        return e
                    }
                    resolveAll(e) {
                        let t = [];
                        for (const r of this.values()) t.push(e(r));
                        return t
                    }
                    clone() {
                        return new x(this.values())
                    }
                    merge(e, t) {
                        const r = this.clone();
                        return e.forEach(e => r.add(e)), t.forEach(e => r.delete(e)), r
                    }
                }

                function C(e, t = new Map) {
                    if (I(e) || !e || "object" != typeof e) return e;
                    if (t.has(e)) return t.get(e);
                    let r;
                    if (e instanceof Date) r = new Date(e.getTime()), t.set(e, r);
                    else if (e instanceof RegExp) r = new RegExp(e), t.set(e, r);
                    else if (Array.isArray(e)) {
                        r = new Array(e.length), t.set(e, r);
                        for (let s = 0; s < e.length; s++) r[s] = C(e[s], t)
                    } else if (e instanceof Map) {
                        r = new Map, t.set(e, r);
                        for (const [s, o] of e.entries()) r.set(s, C(o, t))
                    } else if (e instanceof Set) {
                        r = new Set, t.set(e, r);
                        for (const s of e) r.add(C(s, t))
                    } else {
                        if (!(e instanceof Object)) throw Error(`Unable to clone ${e}`);
                        r = {}, t.set(e, r);
                        for (const [s, o] of Object.entries(e)) r[s] = C(o, t)
                    }
                    return r
                }
                class N {
                    constructor(e) {
                        this.type = void 0, this.deps = [], this.tests = void 0, this.transforms = void 0, this.conditions = [], this._mutate = void 0, this.internalTests = {}, this._whitelist = new x, this._blacklist = new x, this.exclusiveTests = Object.create(null), this._typeCheck = void 0, this.spec = void 0, this.tests = [], this.transforms = [], this.withMutation(() => {
                            this.typeError(j.notType)
                        }), this.type = e.type, this._typeCheck = e.check, this.spec = Object.assign({
                            strip: !1,
                            strict: !1,
                            abortEarly: !0,
                            recursive: !0,
                            disableStackTrace: !1,
                            nullable: !1,
                            optional: !0,
                            coerce: !0
                        }, null == e ? void 0 : e.spec), this.withMutation(e => {
                            e.nonNullable()
                        })
                    }
                    get _type() {
                        return this.type
                    }
                    clone(e) {
                        if (this._mutate) return e && Object.assign(this.spec, e), this;
                        const t = Object.create(Object.getPrototypeOf(this));
                        return t.type = this.type, t._typeCheck = this._typeCheck, t._whitelist = this._whitelist.clone(), t._blacklist = this._blacklist.clone(), t.internalTests = Object.assign({}, this.internalTests), t.exclusiveTests = Object.assign({}, this.exclusiveTests), t.deps = [...this.deps], t.conditions = [...this.conditions], t.tests = [...this.tests], t.transforms = [...this.transforms], t.spec = C(Object.assign({}, this.spec, e)), t
                    }
                    label(e) {
                        let t = this.clone();
                        return t.spec.label = e, t
                    }
                    meta(...e) {
                        if (0 === e.length) return this.spec.meta;
                        let t = this.clone();
                        return t.spec.meta = Object.assign(t.spec.meta || {}, e[0]), t
                    }
                    withMutation(e) {
                        let t = this._mutate;
                        this._mutate = !0;
                        let r = e(this);
                        return this._mutate = t, r
                    }
                    concat(e) {
                        if (!e || e === this) return this;
                        if (e.type !== this.type && "mixed" !== this.type) throw new TypeError(`You cannot \`concat()\` schema's of different types: ${this.type} and ${e.type}`);
                        let t = this,
                            r = e.clone();
                        const s = Object.assign({}, t.spec, r.spec);
                        return r.spec = s, r.internalTests = Object.assign({}, t.internalTests, r.internalTests), r._whitelist = t._whitelist.merge(e._whitelist, e._blacklist), r._blacklist = t._blacklist.merge(e._blacklist, e._whitelist), r.tests = t.tests, r.exclusiveTests = t.exclusiveTests, r.withMutation(t => {
                            e.tests.forEach(e => {
                                t.test(e.OPTIONS)
                            })
                        }), r.transforms = [...t.transforms, ...r.transforms], r
                    }
                    isType(e) {
                        return null == e ? !(!this.spec.nullable || null !== e) || !(!this.spec.optional || void 0 !== e) : this._typeCheck(e)
                    }
                    resolve(e) {
                        let t = this;
                        if (t.conditions.length) {
                            let r = t.conditions;
                            t = t.clone(), t.conditions = [], t = r.reduce((t, r) => r.resolve(t, e), t), t = t.resolve(e)
                        }
                        return t
                    }
                    resolveOptions(e) {
                        var t, r, s, o;
                        return Object.assign({}, e, {
                            from: e.from || [],
                            strict: null != (t = e.strict) ? t : this.spec.strict,
                            abortEarly: null != (r = e.abortEarly) ? r : this.spec.abortEarly,
                            recursive: null != (s = e.recursive) ? s : this.spec.recursive,
                            disableStackTrace: null != (o = e.disableStackTrace) ? o : this.spec.disableStackTrace
                        })
                    }
                    cast(e, t = {}) {
                        let r = this.resolve(Object.assign({
                                value: e
                            }, t)),
                            s = "ignore-optionality" === t.assert,
                            o = r._cast(e, t);
                        if (!1 !== t.assert && !r.isType(o)) {
                            if (s && O(o)) return o;
                            let n = p(e),
                                i = p(o);
                            throw new TypeError(`The value of ${t.path||"field"} could not be cast to a value that satisfies the schema type: "${r.type}". \n\nattempted value: ${n} \n` + (i !== n ? `result of cast: ${i}` : ""))
                        }
                        return o
                    }
                    _cast(e, t) {
                        let r = void 0 === e ? e : this.transforms.reduce((t, r) => r.call(this, t, e, this), e);
                        return void 0 === r && (r = this.getDefault(t)), r
                    }
                    _validate(e, t = {}, r, s) {
                        let {
                            path: o,
                            originalValue: n = e,
                            strict: i = this.spec.strict
                        } = t, a = e;
                        i || (a = this._cast(a, Object.assign({
                            assert: !1
                        }, t)));
                        let g = [];
                        for (let e of Object.values(this.internalTests)) e && g.push(e);
                        this.runTests({
                            path: o,
                            value: a,
                            originalValue: n,
                            options: t,
                            tests: g
                        }, r, e => {
                            if (e.length) return s(e, a);
                            this.runTests({
                                path: o,
                                value: a,
                                originalValue: n,
                                options: t,
                                tests: this.tests
                            }, r, s)
                        })
                    }
                    runTests(e, t, r) {
                        let s = !1,
                            {
                                tests: o,
                                value: n,
                                originalValue: i,
                                path: a,
                                options: g
                            } = e,
                            u = e => {
                                s || (s = !0, t(e, n))
                            },
                            d = e => {
                                s || (s = !0, r(e, n))
                            },
                            l = o.length,
                            c = [];
                        if (!l) return d([]);
                        let p = {
                            value: n,
                            originalValue: i,
                            path: a,
                            options: g,
                            schema: this
                        };
                        for (let e = 0; e < o.length; e++) {
                            (0, o[e])(p, u, function(e) {
                                e && (Array.isArray(e) ? c.push(...e) : c.push(e)), --l <= 0 && d(c)
                            })
                        }
                    }
                    asNestedTest({
                        key: e,
                        index: t,
                        parent: r,
                        parentPath: s,
                        originalParent: o,
                        options: n
                    }) {
                        const i = null != e ? e : t;
                        if (null == i) throw TypeError("Must include `key` or `index` for nested validations");
                        const a = "number" == typeof i;
                        let g = r[i];
                        const u = Object.assign({}, n, {
                            strict: !0,
                            parent: r,
                            value: g,
                            originalValue: o[i],
                            key: void 0,
                            [a ? "index" : "key"]: i,
                            path: a || i.includes(".") ? `${s||""}[${a?i:`"${i}"`}]` : (s ? `${s}.` : "") + e
                        });
                        return (e, t, r) => this.resolve(u)._validate(g, u, t, r)
                    }
                    validate(e, t) {
                        var r;
                        let s = this.resolve(Object.assign({}, t, {
                                value: e
                            })),
                            o = null != (r = null == t ? void 0 : t.disableStackTrace) ? r : s.spec.disableStackTrace;
                        return new Promise((r, n) => s._validate(e, t, (e, t) => {
                            f.isError(e) && (e.value = t), n(e)
                        }, (e, t) => {
                            e.length ? n(new f(e, t, void 0, void 0, o)) : r(t)
                        }))
                    }
                    validateSync(e, t) {
                        var r;
                        let s, o = this.resolve(Object.assign({}, t, {
                                value: e
                            })),
                            n = null != (r = null == t ? void 0 : t.disableStackTrace) ? r : o.spec.disableStackTrace;
                        return o._validate(e, Object.assign({}, t, {
                            sync: !0
                        }), (e, t) => {
                            throw f.isError(e) && (e.value = t), e
                        }, (t, r) => {
                            if (t.length) throw new f(t, e, void 0, void 0, n);
                            s = r
                        }), s
                    }
                    isValid(e, t) {
                        return this.validate(e, t).then(() => !0, e => {
                            if (f.isError(e)) return !1;
                            throw e
                        })
                    }
                    isValidSync(e, t) {
                        try {
                            return this.validateSync(e, t), !0
                        } catch (e) {
                            if (f.isError(e)) return !1;
                            throw e
                        }
                    }
                    _getDefault(e) {
                        let t = this.spec.default;
                        return null == t ? t : "function" == typeof t ? t.call(this, e) : C(t)
                    }
                    getDefault(e) {
                        return this.resolve(e || {})._getDefault(e)
                    }
                    default (e) {
                        if (0 === arguments.length) return this._getDefault();
                        return this.clone({
                            default: e
                        })
                    }
                    strict(e = !0) {
                        return this.clone({
                            strict: e
                        })
                    }
                    nullability(e, t) {
                        const r = this.clone({
                            nullable: e
                        });
                        return r.internalTests.nullable = P({
                            message: t,
                            name: "nullable",
                            test(e) {
                                return null !== e || this.schema.spec.nullable
                            }
                        }), r
                    }
                    optionality(e, t) {
                        const r = this.clone({
                            optional: e
                        });
                        return r.internalTests.optionality = P({
                            message: t,
                            name: "optionality",
                            test(e) {
                                return void 0 !== e || this.schema.spec.optional
                            }
                        }), r
                    }
                    optional() {
                        return this.optionality(!0)
                    }
                    defined(e = j.defined) {
                        return this.optionality(!1, e)
                    }
                    nullable() {
                        return this.nullability(!0)
                    }
                    nonNullable(e = j.notNull) {
                        return this.nullability(!1, e)
                    }
                    required(e = j.required) {
                        return this.clone().withMutation(t => t.nonNullable(e).defined(e))
                    }
                    notRequired() {
                        return this.clone().withMutation(e => e.nullable().optional())
                    }
                    transform(e) {
                        let t = this.clone();
                        return t.transforms.push(e), t
                    }
                    test(...e) {
                        let t;
                        if (t = 1 === e.length ? "function" == typeof e[0] ? {
                                test: e[0]
                            } : e[0] : 2 === e.length ? {
                                name: e[0],
                                test: e[1]
                            } : {
                                name: e[0],
                                message: e[1],
                                test: e[2]
                            }, void 0 === t.message && (t.message = j.default), "function" != typeof t.test) throw new TypeError("`test` is a required parameters");
                        let r = this.clone(),
                            s = P(t),
                            o = t.exclusive || t.name && !0 === r.exclusiveTests[t.name];
                        if (t.exclusive && !t.name) throw new TypeError("Exclusive tests must provide a unique `name` identifying the test");
                        return t.name && (r.exclusiveTests[t.name] = !!t.exclusive), r.tests = r.tests.filter(e => {
                            if (e.OPTIONS.name === t.name) {
                                if (o) return !1;
                                if (e.OPTIONS.test === s.OPTIONS.test) return !1
                            }
                            return !0
                        }), r.tests.push(s), r
                    }
                    when(e, t) {
                        Array.isArray(e) || "string" == typeof e || (t = e, e = ".");
                        let r = this.clone(),
                            s = b(e).map(e => new B(e));
                        return s.forEach(e => {
                            e.isSibling && r.deps.push(e.key)
                        }), r.conditions.push("function" == typeof t ? new R(s, t) : R.fromOptions(s, t)), r
                    }
                    typeError(e) {
                        let t = this.clone();
                        return t.internalTests.typeError = P({
                            message: e,
                            name: "typeError",
                            skipAbsent: !0,
                            test(e) {
                                return !!this.schema._typeCheck(e) || this.createError({
                                    params: {
                                        type: this.schema.type
                                    }
                                })
                            }
                        }), t
                    }
                    oneOf(e, t = j.oneOf) {
                        let r = this.clone();
                        return e.forEach(e => {
                            r._whitelist.add(e), r._blacklist.delete(e)
                        }), r.internalTests.whiteList = P({
                            message: t,
                            name: "oneOf",
                            skipAbsent: !0,
                            test(e) {
                                let t = this.schema._whitelist,
                                    r = t.resolveAll(this.resolve);
                                return !!r.includes(e) || this.createError({
                                    params: {
                                        values: Array.from(t).join(", "),
                                        resolved: r
                                    }
                                })
                            }
                        }), r
                    }
                    notOneOf(e, t = j.notOneOf) {
                        let r = this.clone();
                        return e.forEach(e => {
                            r._blacklist.add(e), r._whitelist.delete(e)
                        }), r.internalTests.blacklist = P({
                            message: t,
                            name: "notOneOf",
                            test(e) {
                                let t = this.schema._blacklist,
                                    r = t.resolveAll(this.resolve);
                                return !r.includes(e) || this.createError({
                                    params: {
                                        values: Array.from(t).join(", "),
                                        resolved: r
                                    }
                                })
                            }
                        }), r
                    }
                    strip(e = !0) {
                        let t = this.clone();
                        return t.spec.strip = e, t
                    }
                    describe(e) {
                        const t = (e ? this.resolve(e) : this).clone(),
                            {
                                label: r,
                                meta: s,
                                optional: o,
                                nullable: n
                            } = t.spec;
                        return {
                            meta: s,
                            label: r,
                            optional: o,
                            nullable: n,
                            default: t.getDefault(e),
                            type: t.type,
                            oneOf: t._whitelist.describe(),
                            notOneOf: t._blacklist.describe(),
                            tests: t.tests.map(e => ({
                                name: e.OPTIONS.name,
                                params: e.OPTIONS.params
                            })).filter((e, t, r) => r.findIndex(t => t.name === e.name) === t)
                        }
                    }
                }
                N.prototype.__isYupSchema__ = !0;
                for (const e of ["validate", "validateSync"]) N.prototype[`${e}At`] = function(t, r, s = {}) {
                    const {
                        parent: o,
                        parentPath: n,
                        schema: i
                    } = L(this, t, r, s.context);
                    return i[e](o && o[n], Object.assign({}, s, {
                        parent: o,
                        path: t
                    }))
                };
                for (const e of ["equals", "is"]) N.prototype[e] = N.prototype.oneOf;
                for (const e of ["not", "nope"]) N.prototype[e] = N.prototype.notOneOf;
                const U = () => !0;

                function k(e) {
                    return new J(e)
                }
                class J extends N {
                    constructor(e) {
                        super("function" == typeof e ? {
                            type: "mixed",
                            check: e
                        } : Object.assign({
                            type: "mixed",
                            check: U
                        }, e))
                    }
                }

                function q() {
                    return new W
                }
                k.prototype = J.prototype;
                class W extends N {
                    constructor() {
                        super({
                            type: "boolean",
                            check: e => (e instanceof Boolean && (e = e.valueOf()), "boolean" == typeof e)
                        }), this.withMutation(() => {
                            this.transform((e, t, r) => {
                                if (r.spec.coerce && !r.isType(e)) {
                                    if (/^(true|1)$/i.test(String(e))) return !0;
                                    if (/^(false|0)$/i.test(String(e))) return !1
                                }
                                return e
                            })
                        })
                    }
                    isTrue(e = E.isValue) {
                        return this.test({
                            message: e,
                            name: "is-value",
                            exclusive: !0,
                            params: {
                                value: "true"
                            },
                            test: e => O(e) || !0 === e
                        })
                    }
                    isFalse(e = E.isValue) {
                        return this.test({
                            message: e,
                            name: "is-value",
                            exclusive: !0,
                            params: {
                                value: "false"
                            },
                            test: e => O(e) || !1 === e
                        })
                    }
                    default (e) {
                        return super.default(e)
                    }
                    defined(e) {
                        return super.defined(e)
                    }
                    optional() {
                        return super.optional()
                    }
                    required(e) {
                        return super.required(e)
                    }
                    notRequired() {
                        return super.notRequired()
                    }
                    nullable() {
                        return super.nullable()
                    }
                    nonNullable(e) {
                        return super.nonNullable(e)
                    }
                    strip(e) {
                        return super.strip(e)
                    }
                }
                q.prototype = W.prototype;
                const V = /^(\d{4}|[+-]\d{6})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2})(?:[,.](\d{1,}))?)?(?:(Z)|([+-])(\d{2})(?::?(\d{2}))?)?)?$/;

                function G(e) {
                    var t, r;
                    const s = V.exec(e);
                    return s ? {
                        year: z(s[1]),
                        month: z(s[2], 1) - 1,
                        day: z(s[3], 1),
                        hour: z(s[4]),
                        minute: z(s[5]),
                        second: z(s[6]),
                        millisecond: s[7] ? z(s[7].substring(0, 3)) : 0,
                        precision: null != (t = null == (r = s[7]) ? void 0 : r.length) ? t : void 0,
                        z: s[8] || void 0,
                        plusMinus: s[9] || void 0,
                        hourOffset: z(s[10]),
                        minuteOffset: z(s[11])
                    } : null
                }

                function z(e, t = 0) {
                    return Number(e) || t
                }
                let H = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
                    Y = /^((https?|ftp):)?\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i,
                    Z = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i,
                    X = new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(([+-]\\d{2}(:?\\d{2})?)|Z)$"),
                    K = e => O(e) || e === e.trim(),
                    Q = {}.toString();

                function ee() {
                    return new te
                }
                class te extends N {
                    constructor() {
                        super({
                            type: "string",
                            check: e => (e instanceof String && (e = e.valueOf()), "string" == typeof e)
                        }), this.withMutation(() => {
                            this.transform((e, t, r) => {
                                if (!r.spec.coerce || r.isType(e)) return e;
                                if (Array.isArray(e)) return e;
                                const s = null != e && e.toString ? e.toString() : e;
                                return s === Q ? e : s
                            })
                        })
                    }
                    required(e) {
                        return super.required(e).withMutation(t => t.test({
                            message: e || j.required,
                            name: "required",
                            skipAbsent: !0,
                            test: e => !!e.length
                        }))
                    }
                    notRequired() {
                        return super.notRequired().withMutation(e => (e.tests = e.tests.filter(e => "required" !== e.OPTIONS.name), e))
                    }
                    length(e, t = S.length) {
                        return this.test({
                            message: t,
                            name: "length",
                            exclusive: !0,
                            params: {
                                length: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t.length === this.resolve(e)
                            }
                        })
                    }
                    min(e, t = S.min) {
                        return this.test({
                            message: t,
                            name: "min",
                            exclusive: !0,
                            params: {
                                min: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t.length >= this.resolve(e)
                            }
                        })
                    }
                    max(e, t = S.max) {
                        return this.test({
                            name: "max",
                            exclusive: !0,
                            message: t,
                            params: {
                                max: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t.length <= this.resolve(e)
                            }
                        })
                    }
                    matches(e, t) {
                        let r, s, o = !1;
                        return t && ("object" == typeof t ? ({
                            excludeEmptyString: o = !1,
                            message: r,
                            name: s
                        } = t) : r = t), this.test({
                            name: s || "matches",
                            message: r || S.matches,
                            params: {
                                regex: e
                            },
                            skipAbsent: !0,
                            test: t => "" === t && o || -1 !== t.search(e)
                        })
                    }
                    email(e = S.email) {
                        return this.matches(H, {
                            name: "email",
                            message: e,
                            excludeEmptyString: !0
                        })
                    }
                    url(e = S.url) {
                        return this.matches(Y, {
                            name: "url",
                            message: e,
                            excludeEmptyString: !0
                        })
                    }
                    uuid(e = S.uuid) {
                        return this.matches(Z, {
                            name: "uuid",
                            message: e,
                            excludeEmptyString: !1
                        })
                    }
                    datetime(e) {
                        let t, r, s = "";
                        return e && ("object" == typeof e ? ({
                            message: s = "",
                            allowOffset: t = !1,
                            precision: r
                        } = e) : s = e), this.matches(X, {
                            name: "datetime",
                            message: s || S.datetime,
                            excludeEmptyString: !0
                        }).test({
                            name: "datetime_offset",
                            message: s || S.datetime_offset,
                            params: {
                                allowOffset: t
                            },
                            skipAbsent: !0,
                            test: e => {
                                if (!e || t) return !0;
                                const r = G(e);
                                return !!r && !!r.z
                            }
                        }).test({
                            name: "datetime_precision",
                            message: s || S.datetime_precision,
                            params: {
                                precision: r
                            },
                            skipAbsent: !0,
                            test: e => {
                                if (!e || null == r) return !0;
                                const t = G(e);
                                return !!t && t.precision === r
                            }
                        })
                    }
                    ensure() {
                        return this.default("").transform(e => null === e ? "" : e)
                    }
                    trim(e = S.trim) {
                        return this.transform(e => null != e ? e.trim() : e).test({
                            message: e,
                            name: "trim",
                            test: K
                        })
                    }
                    lowercase(e = S.lowercase) {
                        return this.transform(e => O(e) ? e : e.toLowerCase()).test({
                            message: e,
                            name: "string_case",
                            exclusive: !0,
                            skipAbsent: !0,
                            test: e => O(e) || e === e.toLowerCase()
                        })
                    }
                    uppercase(e = S.uppercase) {
                        return this.transform(e => O(e) ? e : e.toUpperCase()).test({
                            message: e,
                            name: "string_case",
                            exclusive: !0,
                            skipAbsent: !0,
                            test: e => O(e) || e === e.toUpperCase()
                        })
                    }
                }
                ee.prototype = te.prototype;

                function re() {
                    return new se
                }
                class se extends N {
                    constructor() {
                        super({
                            type: "number",
                            check: e => (e instanceof Number && (e = e.valueOf()), "number" == typeof e && !(e => e != +e)(e))
                        }), this.withMutation(() => {
                            this.transform((e, t, r) => {
                                if (!r.spec.coerce) return e;
                                let s = e;
                                if ("string" == typeof s) {
                                    if (s = s.replace(/\s/g, ""), "" === s) return NaN;
                                    s = +s
                                }
                                return r.isType(s) || null === s ? s : parseFloat(s)
                            })
                        })
                    }
                    min(e, t = A.min) {
                        return this.test({
                            message: t,
                            name: "min",
                            exclusive: !0,
                            params: {
                                min: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t >= this.resolve(e)
                            }
                        })
                    }
                    max(e, t = A.max) {
                        return this.test({
                            message: t,
                            name: "max",
                            exclusive: !0,
                            params: {
                                max: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t <= this.resolve(e)
                            }
                        })
                    }
                    lessThan(e, t = A.lessThan) {
                        return this.test({
                            message: t,
                            name: "max",
                            exclusive: !0,
                            params: {
                                less: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t < this.resolve(e)
                            }
                        })
                    }
                    moreThan(e, t = A.moreThan) {
                        return this.test({
                            message: t,
                            name: "min",
                            exclusive: !0,
                            params: {
                                more: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t > this.resolve(e)
                            }
                        })
                    }
                    positive(e = A.positive) {
                        return this.moreThan(0, e)
                    }
                    negative(e = A.negative) {
                        return this.lessThan(0, e)
                    }
                    integer(e = A.integer) {
                        return this.test({
                            name: "integer",
                            message: e,
                            skipAbsent: !0,
                            test: e => Number.isInteger(e)
                        })
                    }
                    truncate() {
                        return this.transform(e => O(e) ? e : 0 | e)
                    }
                    round(e) {
                        var t;
                        let r = ["ceil", "floor", "round", "trunc"];
                        if ("trunc" === (e = (null == (t = e) ? void 0 : t.toLowerCase()) || "round")) return this.truncate();
                        if (-1 === r.indexOf(e.toLowerCase())) throw new TypeError("Only valid options for round() are: " + r.join(", "));
                        return this.transform(t => O(t) ? t : Math[e](t))
                    }
                }
                re.prototype = se.prototype;
                let oe = new Date("");

                function ne() {
                    return new ie
                }
                class ie extends N {
                    constructor() {
                        super({
                            type: "date",
                            check(e) {
                                return t = e, "[object Date]" === Object.prototype.toString.call(t) && !isNaN(e.getTime());
                                var t
                            }
                        }), this.withMutation(() => {
                            this.transform((e, t, r) => !r.spec.coerce || r.isType(e) || null === e ? e : (e = function(e) {
                                const t = G(e);
                                if (!t) return Date.parse ? Date.parse(e) : Number.NaN;
                                if (void 0 === t.z && void 0 === t.plusMinus) return new Date(t.year, t.month, t.day, t.hour, t.minute, t.second, t.millisecond).valueOf();
                                let r = 0;
                                return "Z" !== t.z && void 0 !== t.plusMinus && (r = 60 * t.hourOffset + t.minuteOffset, "+" === t.plusMinus && (r = 0 - r)), Date.UTC(t.year, t.month, t.day, t.hour, t.minute + r, t.second, t.millisecond)
                            }(e), isNaN(e) ? ie.INVALID_DATE : new Date(e)))
                        })
                    }
                    prepareParam(e, t) {
                        let r;
                        if (B.isRef(e)) r = e;
                        else {
                            let s = this.cast(e);
                            if (!this._typeCheck(s)) throw new TypeError(`\`${t}\` must be a Date or a value that can be \`cast()\` to a Date`);
                            r = s
                        }
                        return r
                    }
                    min(e, t = w.min) {
                        let r = this.prepareParam(e, "min");
                        return this.test({
                            message: t,
                            name: "min",
                            exclusive: !0,
                            params: {
                                min: e
                            },
                            skipAbsent: !0,
                            test(e) {
                                return e >= this.resolve(r)
                            }
                        })
                    }
                    max(e, t = w.max) {
                        let r = this.prepareParam(e, "max");
                        return this.test({
                            message: t,
                            name: "max",
                            exclusive: !0,
                            params: {
                                max: e
                            },
                            skipAbsent: !0,
                            test(e) {
                                return e <= this.resolve(r)
                            }
                        })
                    }
                }

                function ae(e, t) {
                    let r = 1 / 0;
                    return e.some((e, s) => {
                        var o;
                        if (null != (o = t.path) && o.includes(e)) return r = s, !0
                    }), r
                }

                function ge(e) {
                    return (t, r) => ae(e, t) - ae(e, r)
                }
                ie.INVALID_DATE = oe, ne.prototype = ie.prototype, ne.INVALID_DATE = oe;
                const ue = (e, t, r) => {
                    if ("string" != typeof e) return e;
                    let s = e;
                    try {
                        s = JSON.parse(e)
                    } catch (e) {}
                    return r.isType(s) ? s : e
                };

                function de(e) {
                    if ("fields" in e) {
                        const t = {};
                        for (const [r, s] of Object.entries(e.fields)) t[r] = de(s);
                        return e.setFields(t)
                    }
                    if ("array" === e.type) {
                        const t = e.optional();
                        return t.innerType && (t.innerType = de(t.innerType)), t
                    }
                    return "tuple" === e.type ? e.optional().clone({
                        types: e.spec.types.map(de)
                    }) : "optional" in e ? e.optional() : e
                }
                let le = e => "[object Object]" === Object.prototype.toString.call(e);

                function ce(e, t) {
                    let r = Object.keys(e.fields);
                    return Object.keys(t).filter(e => -1 === r.indexOf(e))
                }
                const pe = ge([]);

                function be(e) {
                    return new _e(e)
                }
                class _e extends N {
                    constructor(e) {
                        super({
                            type: "object",
                            check: e => le(e) || "function" == typeof e
                        }), this.fields = Object.create(null), this._sortErrors = pe, this._nodes = [], this._excludedEdges = [], this.withMutation(() => {
                            e && this.shape(e)
                        })
                    }
                    _cast(e, t = {}) {
                        var r;
                        let s = super._cast(e, t);
                        if (void 0 === s) return this.getDefault(t);
                        if (!this._typeCheck(s)) return s;
                        let o = this.fields,
                            n = null != (r = t.stripUnknown) ? r : this.spec.noUnknown,
                            i = [].concat(this._nodes, Object.keys(s).filter(e => !this._nodes.includes(e))),
                            a = {},
                            g = Object.assign({}, t, {
                                parent: a,
                                __validating: t.__validating || !1
                            }),
                            u = !1;
                        for (const e of i) {
                            let r = o[e],
                                i = e in s;
                            if (r) {
                                let o, n = s[e];
                                g.path = (t.path ? `${t.path}.` : "") + e, r = r.resolve({
                                    value: n,
                                    context: t.context,
                                    parent: a
                                });
                                let i = r instanceof N ? r.spec : void 0,
                                    d = null == i ? void 0 : i.strict;
                                if (null != i && i.strip) {
                                    u = u || e in s;
                                    continue
                                }
                                o = t.__validating && d ? s[e] : r.cast(s[e], g), void 0 !== o && (a[e] = o)
                            } else i && !n && (a[e] = s[e]);
                            i === e in a && a[e] === s[e] || (u = !0)
                        }
                        return u ? a : s
                    }
                    _validate(e, t = {}, r, s) {
                        let {
                            from: o = [],
                            originalValue: n = e,
                            recursive: i = this.spec.recursive
                        } = t;
                        t.from = [{
                            schema: this,
                            value: n
                        }, ...o], t.__validating = !0, t.originalValue = n, super._validate(e, t, r, (e, o) => {
                            if (!i || !le(o)) return void s(e, o);
                            n = n || o;
                            let a = [];
                            for (let e of this._nodes) {
                                let r = this.fields[e];
                                r && !B.isRef(r) && a.push(r.asNestedTest({
                                    options: t,
                                    key: e,
                                    parent: o,
                                    parentPath: t.path,
                                    originalParent: n
                                }))
                            }
                            this.runTests({
                                tests: a,
                                value: o,
                                originalValue: n,
                                options: t
                            }, r, t => {
                                s(t.sort(this._sortErrors).concat(e), o)
                            })
                        })
                    }
                    clone(e) {
                        const t = super.clone(e);
                        return t.fields = Object.assign({}, this.fields), t._nodes = this._nodes, t._excludedEdges = this._excludedEdges, t._sortErrors = this._sortErrors, t
                    }
                    concat(e) {
                        let t = super.concat(e),
                            r = t.fields;
                        for (let [e, t] of Object.entries(this.fields)) {
                            const s = r[e];
                            r[e] = void 0 === s ? t : s
                        }
                        return t.withMutation(t => t.setFields(r, [...this._excludedEdges, ...e._excludedEdges]))
                    }
                    _getDefault(e) {
                        if ("default" in this.spec) return super._getDefault(e);
                        if (!this._nodes.length) return;
                        let t = {};
                        return this._nodes.forEach(r => {
                            var s;
                            const o = this.fields[r];
                            let n = e;
                            null != (s = n) && s.value && (n = Object.assign({}, n, {
                                parent: n.value,
                                value: n.value[r]
                            })), t[r] = o && "getDefault" in o ? o.getDefault(n) : void 0
                        }), t
                    }
                    setFields(e, t) {
                        let r = this.clone();
                        return r.fields = e, r._nodes = function(e, t = []) {
                            let r = [],
                                o = new Set,
                                n = new Set(t.map(([e, t]) => `${e}-${t}`));

                            function a(e, t) {
                                let i = (0, s.split)(e)[0];
                                o.add(i), n.has(`${t}-${i}`) || r.push([t, i])
                            }
                            for (const t of Object.keys(e)) {
                                let r = e[t];
                                o.add(t), B.isRef(r) && r.isSibling ? a(r.path, t) : I(r) && "deps" in r && r.deps.forEach(e => a(e, t))
                            }
                            return i().array(Array.from(o), r).reverse()
                        }(e, t), r._sortErrors = ge(Object.keys(e)), t && (r._excludedEdges = t), r
                    }
                    shape(e, t = []) {
                        return this.clone().withMutation(r => {
                            let s = r._excludedEdges;
                            return t.length && (Array.isArray(t[0]) || (t = [t]), s = [...r._excludedEdges, ...t]), r.setFields(Object.assign(r.fields, e), s)
                        })
                    }
                    partial() {
                        const e = {};
                        for (const [t, r] of Object.entries(this.fields)) e[t] = "optional" in r && r.optional instanceof Function ? r.optional() : r;
                        return this.setFields(e)
                    }
                    deepPartial() {
                        return de(this)
                    }
                    pick(e) {
                        const t = {};
                        for (const r of e) this.fields[r] && (t[r] = this.fields[r]);
                        return this.setFields(t, this._excludedEdges.filter(([t, r]) => e.includes(t) && e.includes(r)))
                    }
                    omit(e) {
                        const t = [];
                        for (const r of Object.keys(this.fields)) e.includes(r) || t.push(r);
                        return this.pick(t)
                    }
                    from(e, t, r) {
                        let o = (0, s.getter)(e, !0);
                        return this.transform(n => {
                            if (!n) return n;
                            let i = n;
                            return ((e, t) => {
                                const r = [...(0, s.normalizePath)(t)];
                                if (1 === r.length) return r[0] in e;
                                let o = r.pop(),
                                    n = (0, s.getter)((0, s.join)(r), !0)(e);
                                return !(!n || !(o in n))
                            })(n, e) && (i = Object.assign({}, n), r || delete i[e], i[t] = o(n)), i
                        })
                    }
                    json() {
                        return this.transform(ue)
                    }
                    exact(e) {
                        return this.test({
                            name: "exact",
                            exclusive: !0,
                            message: e || v.exact,
                            test(e) {
                                if (null == e) return !0;
                                const t = ce(this.schema, e);
                                return 0 === t.length || this.createError({
                                    params: {
                                        properties: t.join(", ")
                                    }
                                })
                            }
                        })
                    }
                    stripUnknown() {
                        return this.clone({
                            noUnknown: !0
                        })
                    }
                    noUnknown(e = !0, t = v.noUnknown) {
                        "boolean" != typeof e && (t = e, e = !0);
                        let r = this.test({
                            name: "noUnknown",
                            exclusive: !0,
                            message: t,
                            test(t) {
                                if (null == t) return !0;
                                const r = ce(this.schema, t);
                                return !e || 0 === r.length || this.createError({
                                    params: {
                                        unknown: r.join(", ")
                                    }
                                })
                            }
                        });
                        return r.spec.noUnknown = e, r
                    }
                    unknown(e = !0, t = v.noUnknown) {
                        return this.noUnknown(!e, t)
                    }
                    transformKeys(e) {
                        return this.transform(t => {
                            if (!t) return t;
                            const r = {};
                            for (const s of Object.keys(t)) r[e(s)] = t[s];
                            return r
                        })
                    }
                    camelCase() {
                        return this.transformKeys(o.camelCase)
                    }
                    snakeCase() {
                        return this.transformKeys(o.snakeCase)
                    }
                    constantCase() {
                        return this.transformKeys(e => (0, o.snakeCase)(e).toUpperCase())
                    }
                    describe(e) {
                        const t = (e ? this.resolve(e) : this).clone(),
                            r = super.describe(e);
                        r.fields = {};
                        for (const [o, n] of Object.entries(t.fields)) {
                            var s;
                            let t = e;
                            null != (s = t) && s.value && (t = Object.assign({}, t, {
                                parent: t.value,
                                value: t.value[o]
                            })), r.fields[o] = n.describe(t)
                        }
                        return r
                    }
                }

                function $e(e) {
                    return new he(e)
                }
                be.prototype = _e.prototype;
                class he extends N {
                    constructor(e) {
                        super({
                            type: "array",
                            spec: {
                                types: e
                            },
                            check: e => Array.isArray(e)
                        }), this.innerType = void 0, this.innerType = e
                    }
                    _cast(e, t) {
                        const r = super._cast(e, t);
                        if (!this._typeCheck(r) || !this.innerType) return r;
                        let s = !1;
                        const o = r.map((e, r) => {
                            const o = this.innerType.cast(e, Object.assign({}, t, {
                                path: `${t.path||""}[${r}]`
                            }));
                            return o !== e && (s = !0), o
                        });
                        return s ? o : r
                    }
                    _validate(e, t = {}, r, s) {
                        var o;
                        let n = this.innerType,
                            i = null != (o = t.recursive) ? o : this.spec.recursive;
                        null != t.originalValue && t.originalValue, super._validate(e, t, r, (o, a) => {
                            var g;
                            if (!i || !n || !this._typeCheck(a)) return void s(o, a);
                            let u = new Array(a.length);
                            for (let r = 0; r < a.length; r++) {
                                var d;
                                u[r] = n.asNestedTest({
                                    options: t,
                                    index: r,
                                    parent: a,
                                    parentPath: t.path,
                                    originalParent: null != (d = t.originalValue) ? d : e
                                })
                            }
                            this.runTests({
                                value: a,
                                tests: u,
                                originalValue: null != (g = t.originalValue) ? g : e,
                                options: t
                            }, r, e => s(e.concat(o), a))
                        })
                    }
                    clone(e) {
                        const t = super.clone(e);
                        return t.innerType = this.innerType, t
                    }
                    json() {
                        return this.transform(ue)
                    }
                    concat(e) {
                        let t = super.concat(e);
                        return t.innerType = this.innerType, e.innerType && (t.innerType = t.innerType ? t.innerType.concat(e.innerType) : e.innerType), t
                    } of (e) {
                        let t = this.clone();
                        if (!I(e)) throw new TypeError("`array.of()` sub-schema must be a valid yup schema not: " + p(e));
                        return t.innerType = e, t.spec = Object.assign({}, t.spec, {
                            types: e
                        }), t
                    }
                    length(e, t = T.length) {
                        return this.test({
                            message: t,
                            name: "length",
                            exclusive: !0,
                            params: {
                                length: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t.length === this.resolve(e)
                            }
                        })
                    }
                    min(e, t) {
                        return t = t || T.min, this.test({
                            message: t,
                            name: "min",
                            exclusive: !0,
                            params: {
                                min: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t.length >= this.resolve(e)
                            }
                        })
                    }
                    max(e, t) {
                        return t = t || T.max, this.test({
                            message: t,
                            name: "max",
                            exclusive: !0,
                            params: {
                                max: e
                            },
                            skipAbsent: !0,
                            test(t) {
                                return t.length <= this.resolve(e)
                            }
                        })
                    }
                    ensure() {
                        return this.default(() => []).transform((e, t) => this._typeCheck(e) ? e : null == t ? [] : [].concat(t))
                    }
                    compact(e) {
                        let t = e ? (t, r, s) => !e(t, r, s) : e => !!e;
                        return this.transform(e => null != e ? e.filter(t) : e)
                    }
                    describe(e) {
                        const t = (e ? this.resolve(e) : this).clone(),
                            r = super.describe(e);
                        if (t.innerType) {
                            var s;
                            let o = e;
                            null != (s = o) && s.value && (o = Object.assign({}, o, {
                                parent: o.value,
                                value: o.value[0]
                            })), r.innerType = t.innerType.describe(o)
                        }
                        return r
                    }
                }
                $e.prototype = he.prototype;

                function me(e) {
                    return new fe(e)
                }

                function ye(e) {
                    try {
                        return e()
                    } catch (e) {
                        if (f.isError(e)) return Promise.reject(e);
                        throw e
                    }
                }
                class fe {
                    constructor(e) {
                        this.type = "lazy", this.__isYupSchema__ = !0, this.spec = void 0, this._resolve = (e, t = {}) => {
                            let r = this.builder(e, t);
                            if (!I(r)) throw new TypeError("lazy() functions must return a valid schema");
                            return this.spec.optional && (r = r.optional()), r.resolve(t)
                        }, this.builder = e, this.spec = {
                            meta: void 0,
                            optional: !1
                        }
                    }
                    clone(e) {
                        const t = new fe(this.builder);
                        return t.spec = Object.assign({}, this.spec, e), t
                    }
                    optionality(e) {
                        return this.clone({
                            optional: e
                        })
                    }
                    optional() {
                        return this.optionality(!0)
                    }
                    resolve(e) {
                        return this._resolve(e.value, e)
                    }
                    cast(e, t) {
                        return this._resolve(e, t).cast(e, t)
                    }
                    asNestedTest(e) {
                        let {
                            key: t,
                            index: r,
                            parent: s,
                            options: o
                        } = e, n = s[null != r ? r : t];
                        return this._resolve(n, Object.assign({}, o, {
                            value: n,
                            parent: s
                        })).asNestedTest(e)
                    }
                    validate(e, t) {
                        return ye(() => this._resolve(e, t).validate(e, t))
                    }
                    validateSync(e, t) {
                        return this._resolve(e, t).validateSync(e, t)
                    }
                    validateAt(e, t, r) {
                        return ye(() => this._resolve(t, r).validateAt(e, t, r))
                    }
                    validateSyncAt(e, t, r) {
                        return this._resolve(t, r).validateSyncAt(e, t, r)
                    }
                    isValid(e, t) {
                        try {
                            return this._resolve(e, t).isValid(e, t)
                        } catch (e) {
                            if (f.isError(e)) return Promise.resolve(!1);
                            throw e
                        }
                    }
                    isValidSync(e, t) {
                        return this._resolve(e, t).isValidSync(e, t)
                    }
                    describe(e) {
                        return e ? this.resolve(e).describe(e) : {
                            type: "lazy",
                            meta: this.spec.meta,
                            label: void 0
                        }
                    }
                    meta(...e) {
                        if (0 === e.length) return this.spec.meta;
                        let t = this.clone();
                        return t.spec.meta = Object.assign(t.spec.meta || {}, e[0]), t
                    }
                }
            },
            9612(e, t, r) {
                "use strict";
                r.d(t, {
                    A: () => i
                });
                const s = new Uint8Array(16);
                const o = [];
                for (let e = 0; e < 256; ++e) o.push((e + 256).toString(16).slice(1));

                function n(e, t = 0) {
                    return (o[e[t + 0]] + o[e[t + 1]] + o[e[t + 2]] + o[e[t + 3]] + "-" + o[e[t + 4]] + o[e[t + 5]] + "-" + o[e[t + 6]] + o[e[t + 7]] + "-" + o[e[t + 8]] + o[e[t + 9]] + "-" + o[e[t + 10]] + o[e[t + 11]] + o[e[t + 12]] + o[e[t + 13]] + o[e[t + 14]] + o[e[t + 15]]).toLowerCase()
                }
                const i = function(e, t, r) {
                    return t || e || !crypto.randomUUID ? function(e, t, r) {
                        e = e || {};
                        const o = e.random ? ? e.rng ? .() ? ? crypto.getRandomValues(s);
                        if (o.length < 16) throw new Error("Random bytes length must be >= 16");
                        if (o[6] = 15 & o[6] | 64, o[8] = 63 & o[8] | 128, t) {
                            if ((r = r || 0) < 0 || r + 16 > t.length) throw new RangeError(`UUID byte range ${r}:${r+15} is out of buffer bounds`);
                            for (let e = 0; e < 16; ++e) t[r + e] = o[e];
                            return t
                        }
                        return n(o)
                    }(e, t, r) : crypto.randomUUID()
                }
            }
        },
        __webpack_module_cache__ = {},
        inProgress, dataWebpackPrefix;

    function __webpack_require__(e) {
        var t = __webpack_module_cache__[e];
        if (void 0 !== t) return t.exports;
        var r = __webpack_module_cache__[e] = {
            exports: {}
        };
        return __webpack_modules__[e].call(r.exports, r, r.exports, __webpack_require__), r.exports
    }
    __webpack_require__.m = __webpack_modules__, __webpack_require__.amdO = {}, __webpack_require__.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return __webpack_require__.d(t, {
            a: t
        }), t
    }, __webpack_require__.d = (e, t) => {
        for (var r in t) __webpack_require__.o(t, r) && !__webpack_require__.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, __webpack_require__.f = {}, __webpack_require__.e = e => Promise.all(Object.keys(__webpack_require__.f).reduce((t, r) => (__webpack_require__.f[r](e, t), t), [])), __webpack_require__.u = e => ({
        12: "prebid-analytics",
        511: "finst",
        972: "fcnx-sr-tracking"
    }[e] + "." + {
        12: "1d629f71b0308758a727",
        511: "0d42f29cc392a19f6127",
        972: "9639e1c1af9e3be67ba9"
    }[e] + ".module.js"), __webpack_require__.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), inProgress = {}, dataWebpackPrefix = "@aditudeinc/raven:", __webpack_require__.l = (e, t, r, s) => {
        if (inProgress[e]) inProgress[e].push(t);
        else {
            var o, n;
            if (void 0 !== r)
                for (var i = document.getElementsByTagName("script"), a = 0; a < i.length; a++) {
                    var g = i[a];
                    if (g.getAttribute("src") == e || g.getAttribute("data-webpack") == dataWebpackPrefix + r) {
                        o = g;
                        break
                    }
                }
            o || (n = !0, (o = document.createElement("script")).charset = "utf-8", __webpack_require__.nc && o.setAttribute("nonce", __webpack_require__.nc), o.setAttribute("data-webpack", dataWebpackPrefix + r), o.src = e), inProgress[e] = [t];
            var u = (t, r) => {
                    o.onerror = o.onload = null, clearTimeout(d);
                    var s = inProgress[e];
                    if (delete inProgress[e], o.parentNode && o.parentNode.removeChild(o), s && s.forEach(e => e(r)), t) return t(r)
                },
                d = setTimeout(u.bind(null, void 0, {
                    type: "timeout",
                    target: o
                }), 12e4);
            o.onerror = u.bind(null, o.onerror), o.onload = u.bind(null, o.onload), n && document.head.appendChild(o)
        }
    }, (() => {
        var e;
        globalThis.importScripts && (e = globalThis.location + "");
        var t = globalThis.document;
        if (!e && t && (t.currentScript && "SCRIPT" === t.currentScript.tagName.toUpperCase() && (e = t.currentScript.src), !e)) {
            var r = t.getElementsByTagName("script");
            if (r.length)
                for (var s = r.length - 1; s > -1 && (!e || !/^http(s?):/.test(e));) e = r[s--].src
        }
        if (!e) throw new Error("Automatic publicPath is not supported in this browser");
        e = e.replace(/^blob:/, "").replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/"), __webpack_require__.p = e
    })(), (() => {
        var e = {
            792: 0
        };
        __webpack_require__.f.j = (t, r) => {
            var s = __webpack_require__.o(e, t) ? e[t] : void 0;
            if (0 !== s)
                if (s) r.push(s[2]);
                else {
                    var o = new Promise((r, o) => s = e[t] = [r, o]);
                    r.push(s[2] = o);
                    var n = __webpack_require__.p + __webpack_require__.u(t),
                        i = new Error;
                    __webpack_require__.l(n, r => {
                        if (__webpack_require__.o(e, t) && (0 !== (s = e[t]) && (e[t] = void 0), s)) {
                            var o = r && ("load" === r.type ? "missing" : r.type),
                                n = r && r.target && r.target.src;
                            i.message = "Loading chunk " + t + " failed.\n(" + o + ": " + n + ")", i.name = "ChunkLoadError", i.type = o, i.request = n, s[1](i)
                        }
                    }, "chunk-" + t, t)
                }
        };
        var t = (t, r) => {
                var s, o, [n, i, a] = r,
                    g = 0;
                if (n.some(t => 0 !== e[t])) {
                    for (s in i) __webpack_require__.o(i, s) && (__webpack_require__.m[s] = i[s]);
                    if (a) a(__webpack_require__)
                }
                for (t && t(r); g < n.length; g++) o = n[g], __webpack_require__.o(e, o) && e[o] && e[o][0](), e[o] = 0
            },
            r = this.webpackChunk_aditudeinc_raven = this.webpackChunk_aditudeinc_raven || [];
        r.forEach(t.bind(null, 0)), r.push = t.bind(null, r.push.bind(r))
    })();
    var __webpack_exports__ = {};
    (() => {
        "use strict";
        var e = __webpack_require__(5500);
        const t = async t => {
            const r = t.geo ? `&geo=${encodeURIComponent(t.geo)}` : "";
            return await (0, e.A)("GET", `/ravenconfig?ppid=${encodeURIComponent(t.propertyId)}${r}`)
        };
        var r = __webpack_require__(8704);
        class s {
            groupName;
            events;
            startTime;
            constructor(e) {
                this.groupName = e, this.events = [], this.startTime = new Date
            }
            getPrefix() {
                return `${this.groupName}`
            }
            addEvent(e, t) {
                let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "log";
                r.Ay.enabled() && ("function" == typeof t && (t = t()), this.events.push({
                    data: t,
                    event: e,
                    type: s
                }))
            }
            flush(e) {
                if (!r.Ay.enabled()) return;
                const t = this.getPrefix();
                console.groupCollapsed(...(0, r.S_)(t, e)), console.count(t), this.events.forEach(e => {
                    let {
                        type: t
                    } = e;
                    const r = [];
                    if (r.push(`%c${e.event}`), r.push("font-weight: bold;"), e.data && ("table" !== t || !Array.isArray(e.data) || e.data.length < 1) && (t = "log", r.push(e.data)), "table" === t && Array.isArray(e.data) && e.data.length > 0) {
                        const t = Object.keys(e.data[0]);
                        console.log(...r), console.table(e.data, t)
                    } else console.log(...r)
                }), console.log("%cDuration:", "font-weight:bold;", (new Date).getTime() - this.startTime.getTime() + "ms"), console.groupEnd(), this.events = []
            }
        }
        var o = __webpack_require__(274),
            n = __webpack_require__(1336);
        const i = e => {
                if ("string" != typeof e) return null;
                const [t, r] = e.split("x");
                return isNaN(Number(t)) || isNaN(Number(r)) ? null : e
            },
            a = (e, t) => {
                if (Array.isArray(e) && 2 === e.length) {
                    const [t, r] = e;
                    return {
                        width: t,
                        height: r
                    }
                }
                if ("string" == typeof e) {
                    const [t, r] = e.split("x"), s = parseInt(t), o = parseInt(r);
                    if (!isNaN(s) && !isNaN(o)) return {
                        width: s,
                        height: o
                    }
                }
                const r = t ? .offsetWidth ? ? 0,
                    s = t ? .offsetHeight ? ? 0;
                return r <= 1 || s <= 1 ? {
                    width: 0,
                    height: 0
                } : {
                    width: r,
                    height: s
                }
            },
            g = e => {
                const {
                    width: t,
                    height: r
                } = e;
                return 0 === t && 0 === r ? "unknown" : `${t}x${r}`
            };
        var u = __webpack_require__(5019);
        const d = e => {
                const {
                    initialEvents: t = []
                } = e || {};
                let r = t;
                return {
                    add(e) {
                        r.push(e)
                    },
                    filter: e => r.filter(e),
                    find: e => r.find(e),
                    getEvents: () => r,
                    setEvents(e) {
                        r = e
                    },
                    update(e) {
                        r = e(r)
                    }
                }
            },
            l = d({}),
            c = d({}),
            p = e => {
                let {
                    slot: t
                } = e;
                return (e => ({
                    adUnitPath: e.getAdUnitPath(),
                    contentUrl: e.getContentUrl(),
                    escapedQemQueryId: e.getEscapedQemQueryId(),
                    outOfPage: e.getOutOfPage(),
                    responseInformation: e.getResponseInformation(),
                    sizes: e.getSizes(),
                    slotElementId: e.getSlotElementId(),
                    slotId: e.getSlotId() ? .getDomId(),
                    targetingKeys: e.getTargetingKeys(),
                    targetingMap: e.getTargetingMap()
                }))(t)
            },
            b = (e, t) => {
                window.googletag = window.googletag || {
                    cmd: []
                };
                let r = t[e];
                if (!r) {
                    if (!window.googletag || !window.googletag.apiReady) return;
                    if (r = window.googletag.pubads().getTargeting(e), !r) return
                }
                return Array.isArray(r) ? r.length > 0 ? r[0] : void 0 : r
            },
            _ = e => {
                const t = e.getTargetingMap() || {},
                    r = ["cw_floor"];
                for (const e of r) {
                    const r = b(e, t);
                    if (r) return parseFloat(r)
                }
                return 0
            },
            $ = e => {
                const t = {};
                return Object.keys(e).forEach(r => {
                    const s = e[r];
                    Array.isArray(s) ? s.length > 0 && (t[r] = s[0]) : t[r] = s
                }), t
            };
        var h = __webpack_require__(7551),
            m = __webpack_require__(8481),
            y = __webpack_require__(5586),
            f = __webpack_require__(739);
        class j extends f.b {
            props;
            constructor(e) {
                super(), this.props = e
            }
            get advertiserIds() {
                return this.props.advertiserIds
            }
            get name() {
                return this.props.name
            }
            get type() {
                return this.props.type
            }
        }
        let S = [];

        function A(e) {
            const t = S.find(t => {
                let {
                    advertiserIds: r
                } = t;
                return (r || []).includes(e.toString())
            });
            return t ? {
                name: t.name,
                type: t.type
            } : null
        }
        var w = __webpack_require__(2218);
        const E = new Map,
            v = new Map;
        var T = __webpack_require__(7847);
        window.googletag = window.googletag || {
            cmd: []
        }, window.googletag.cmd = window.googletag.cmd || [];
        const M = {
                bidder: "",
                cpm: 0,
                creativeHeight: 0,
                creativeWidth: 0,
                currency: "USD",
                mediaType: "",
                revenue: 0,
                size: "",
                source: ""
            },
            I = e => {
                const t = p(e),
                    r = c.find(e => e.slotElementId === t.slotElementId),
                    s = r ? ? M,
                    o = (0, n.$)("impressionViewable", { ...t,
                        ...s
                    });
                T.A.pushEvent("impressionViewable", { ...o,
                    adServer: "googletag",
                    dataSource: "gpt",
                    ...r ? .message ? {
                        message: r.message
                    } : {}
                })
            },
            R = (e, t) => {
                const r = p(e);
                var s;
                s = r.slotElementId, l.update(e => e.filter(e => e.slotElementId !== s)), (e => {
                    c.update(t => t.filter(t => t.slotElementId !== e))
                })(r.slotElementId);
                const o = ((e, t) => {
                        const r = E.get(e),
                            s = v.get(e);
                        s && clearTimeout(s);
                        const o = void 0 !== r ? t - r : void 0;
                        E.set(e, t);
                        const n = setTimeout(() => {
                            E.delete(e), v.delete(e)
                        }, 6e4);
                        return v.set(e, n), o
                    })(r.slotElementId, t ? ? Date.now()),
                    i = (0, n.$)("slotRequested", { ...r,
                        timeSinceLastRefreshMs: o
                    });
                T.A.pushEvent("slotRequested", { ...i,
                    adServer: "googletag",
                    dataSource: "gpt"
                }), l.add({
                    adUnitPath: r.adUnitPath,
                    slotElementId: r.slotElementId,
                    targetingMap: r.targetingMap
                })
            };
        let F = !1;
        const D = async (e, t, i) => {
                const d = new s("googletag.slotRenderEnded"),
                    y = p(e),
                    {
                        advertiserId: f,
                        isEmpty: j
                    } = e;
                if (j) return d.addEvent("slotFields", y), void d.flush("unfilledImpression");
                let S = "openbidding",
                    A = "openbidding";
                if (f && -1 !== f) {
                    const e = (await t) ? .getRevenueSourceByAdvertiserId(f.toString());
                    S = e ? .name || "unmapped", A = e ? .type || "other"
                }
                const {
                    slot: E
                } = e, v = (e => {
                    const t = l.find(t => t.slotElementId === e);
                    return t && l.update(t => t.filter(t => t.slotElementId !== e)), t
                })(y.slotElementId), M = v && v.targetingMap ? v.targetingMap : y.targetingMap || {}, I = [];
                let R = S;
                if ("prebid" === S) R = M ? .hb_bidder ? .[0] ? ? R;
                d.addEvent("advertiserId", f), d.addEvent("adUnitPath", y.adUnitPath), d.addEvent("slotElementId", y.slotElementId), d.addEvent("targetingMap", () => Object.keys(M).map(e => ({
                    key: e,
                    value: M[e][0]
                })), "table"), d.addEvent("source", S), d.addEvent("bidder", R);
                let F = {},
                    D = null;
                const B = b("hb_adid", M);
                if (B) {
                    D = ((e, t, r) => {
                        const {
                            pbjsGlobals: s = ["pbjs"]
                        } = (0, o.Xd)();
                        if (r) {
                            const t = [];
                            s.forEach(e => {
                                const r = window[e].getAllWinningBids ? .();
                                r && t.push(...r)
                            });
                            const r = t.find(t => t.adId === e);
                            if (r) return r
                        }
                        const n = s.find(e => window[e].getBidResponsesForAdUnitCode ? .(t));
                        if (!n) return;
                        const i = window[n].getBidResponsesForAdUnitCode ? .(t);
                        if (i && i.bids) {
                            const t = i.bids.find(t => t.adId === e);
                            if (t) return t
                        }
                        let a;
                        return s.forEach(t => {
                            const r = window[t].getAllBidResponses ? .();
                            if (r && Array.isArray(r) && (a = r.find(t => t.adId === e)), a) return !0
                        }), a
                    })(B, E.getSlotElementId(), "prebid" === S), D ? .meta && (F = D.meta);
                    const e = D && D.cpm ? D.cpm : parseFloat(b("hb_pb", M) || "0");
                    I.push(new u.G({
                        source: "prebid",
                        type: "prebid",
                        value: e
                    }))
                }
                const O = b("amznbid", M);
                if (O) {
                    const {
                        getAmazonBid: e
                    } = await (0, w.B)(i), t = e ? e(O) : 1e-4;
                    I.push(new u.G({
                        source: "amazon",
                        type: "amazon",
                        value: t
                    }))
                }
                d.addEvent("competing bids", () => I.map(e => e.toObject()), "table");
                const {
                    pbjsGlobals: P
                } = (0, o.Xd)();
                P.forEach(e => {
                    const t = e;
                    window[t] = window[t] || {}, window[t].que = window[t].que || []
                });
                const L = E.getSlotElementId() || "",
                    x = P.find(e => window[e] ? .adUnits ? .find(e => e.code === L)),
                    C = x ? window[x] ? .adUnits ? .filter(e => e.code === L) : [],
                    N = C.reduce((e, t) => (Object.entries(t.mediaTypes).forEach(t => {
                        let [r, s] = t;
                        e.set(r, s)
                    }), e), new Map),
                    U = N.has("video") && N.has("banner");
                d.addEvent("isMultiFormat", U), d.addEvent("prebidAdUnit", C);
                let k = "banner";
                switch (A) {
                    case "amazon":
                        k = M ? .amzn_format ? .[0] || k, "video" === k && (k = "video_outstream_multiformat");
                        break;
                    case "prebid":
                        k = M ? .hb_format ? .[0] || k, "video" === k && U && (k = "video_outstream_multiformat")
                }
                d.addEvent("mediaType", k);
                const J = await m.i.getBidEstimationModel(k);
                if (!J) return void r.Ay.error("no bid estimation model found for media type", {
                    mediaType: k
                });
                const q = await J.estimateCpm({
                        competingBids: I,
                        googleDemandFloor: _(e.slot),
                        mediaType: k,
                        wonSourceType: A
                    }),
                    W = (0, h.Jf)(q, R, k);
                d.addEvent("cpm", q), W !== q && d.addEvent("cpm (modified)", W);
                const V = document.getElementById(E.getSlotElementId());
                let G = a(e ? .size, V);
                "prebid" === S && 1 === G.width && 1 === G.height && (r.Ay.verbose("detected 1x1 size", {
                    creativeDimensions: G
                }), D ? .width && D ? .height && (r.Ay.verbose("detected 1x1 size using prebid bid response size", {
                    prebidBidResp: D
                }), G = {
                    width: D.width,
                    height: D.height
                }));
                const z = g(G);
                d.addEvent("size", z), d.flush("impression");
                const H = { ...y,
                        adId: B,
                        advertiserId: f,
                        bidder: R,
                        campaignId: y.responseInformation ? .campaignId,
                        cpm: W,
                        originalCpm: q,
                        creativeHeight: G.height,
                        creativeId: y.responseInformation ? .creativeId,
                        creativeWidth: G.width,
                        currency: "USD",
                        lineItemId: y.responseInformation ? .lineItemId,
                        mediaType: k,
                        meta: F,
                        revenue: W / 1e3,
                        size: z,
                        source: S,
                        targetingMap: $(M)
                    },
                    {
                        configId: Y,
                        googleFloorsEnabled: Z
                    } = J.config,
                    {
                        bmin: X,
                        bmax: K,
                        bmult: Q
                    } = J.config.bidValueInputs ? ? {
                        bmax: .01,
                        bmin: .01,
                        bmult: 1
                    },
                    ee = JSON.stringify({
                        cid: Y,
                        creativeId: H.creativeId,
                        bmin: X,
                        bmax: K,
                        bmult: Q,
                        gf: Z ? 1 : 0,
                        meta: H.meta
                    }),
                    te = (0, n.$)("impression", H);
                c.add({ ...H,
                    message: ee
                }), T.A.pushEvent("impression", { ...te,
                    adServer: "googletag",
                    dataSource: "gpt",
                    message: ee
                })
            },
            B = async e => {
                e.trackGoogletag && googletag.cmd.push(() => {
                    r.Ay.debug("adding event listeners", void 0, "googletag");
                    const t = async function(e) {
                            if (S && S.length > 0) return {
                                getRevenueSourceByAdvertiserId: A
                            };
                            const t = await (0, y.K)({
                                    publisherId: e.publisherId
                                }),
                                {
                                    sources: r
                                } = t;
                            return r ? (S = r.map(e => new j({
                                advertiserIds: e.advertiserIds,
                                name: e.name,
                                type: e.type
                            })), {
                                getRevenueSourceByAdvertiserId: A
                            }) : null
                        }(e),
                        s = window.__ravenEarlyGptEvents;
                    if (s && s.length > 0) {
                        r.Ay.debug(`replaying ${s.length} early GPT event(s)`, void 0, "googletag");
                        for (const r of s) "slotRequested" === r.eventType ? R(r.event, r.timestamp) : "slotRenderEnded" === r.eventType ? D(r.event, t, e) : "impressionViewable" === r.eventType && I(r.event)
                    }
                    window.__ravenEarlyGptEvents = null, document.addEventListener("visibilitychange", () => {
                        if (document.hidden && "IFRAME" === document.activeElement ? .tagName && document.activeElement ? .id.startsWith("google_ads_iframe")) {
                            if (Math.random() > 1) return;
                            if (F) return;
                            const e = document.activeElement,
                                t = e.parentElement ? .parentElement ? .id;
                            if (t) {
                                F = !0, setTimeout(() => {
                                    F = !1
                                }, 5e3);
                                const e = googletag.pubads().getSlots().find(e => e.getSlotElementId() === t);
                                if (!e) return;
                                const r = p({
                                        slot: e
                                    }),
                                    s = c.find(e => e.slotElementId === r.slotElementId);
                                if (s) {
                                    const e = (0, n.$)("adClicked", { ...r,
                                        ...s
                                    });
                                    T.A.pushEvent("adClicked", { ...e,
                                        adServer: "googletag",
                                        dataSource: "gpt",
                                        ...s.message ? {
                                            message: s.message
                                        } : {}
                                    })
                                }
                            }
                        }
                    }), googletag.pubads().addEventListener("impressionViewable", e => I(e)), googletag.pubads().addEventListener("slotRequested", e => R(e)), ((e, t) => {
                        googletag.pubads().addEventListener("slotRenderEnded", r => {
                            D(r, t, e)
                        })
                    })(e, t), r.Ay.debug("added event listeners", void 0, "googletag")
                })
            },
            O = d({}),
            P = {
                adServer: "tudeserve",
                dataSource: "tudeserve"
            };
        let L = !1;
        const x = new Map,
            C = new Map,
            N = async e => {
                e.trackTudeserve && (r.Ay.debug("tracking", void 0, "tudeserve"), window.tudeserve = window.tudeserve || {
                    cmd: []
                }, window.tudeserve.cmd.push(e => {
                    e.events().on("viewable", e => {
                        let {
                            bid: t,
                            slot: r
                        } = e;
                        const s = t.amount,
                            o = (0, h.Jf)(s, t.bidder, t.mediaType),
                            i = O.find(e => e.slotElementId === r.elementId),
                            a = (0, n.$)("impressionViewable", {
                                adUnitPath: r.adUnit,
                                bidder: t.bidder,
                                cpm: o,
                                currency: t.currency,
                                mediaType: t.mediaType,
                                originalCpm: s,
                                slotElementId: r.elementId,
                                source: t.source,
                                targetingMap: {}
                            });
                        T.A.pushEvent("impressionViewable", { ...a,
                            ...P,
                            ...i ? .message ? {
                                message: i.message
                            } : {}
                        })
                    }), e.events().on("no_bid", e => {
                        let {
                            slot: t
                        } = e;
                        r.Ay.debug("no_bid event (unfilledImpression)", t, "tudeserve")
                    }), e.events().on("bid_won", e => {
                        let {
                            bid: t,
                            slot: r
                        } = e;
                        if ("prebid" === t.source) return;
                        const s = (0, h.Jf)(t.amount, t.bidder, t.mediaType),
                            o = r.getElement(),
                            u = a(null, o),
                            d = t.sourceData,
                            l = i(d ? .size) ? ? i(d ? .amznsz) ? ? g(u),
                            c = (0, n.$)("bidWon", {
                                adUnitPath: r.adUnit,
                                bidder: t.bidder,
                                cpm: s,
                                currency: t.currency,
                                mediaType: t.mediaType,
                                size: l,
                                slotElementId: r.elementId,
                                source: t.source,
                                targetingMap: {}
                            });
                        T.A.pushEvent("bidWon", { ...c,
                            ...P
                        })
                    }), e.events().on("request", e => {
                        let {
                            slot: t
                        } = e;
                        const r = ((e, t) => {
                                const r = x.get(e),
                                    s = C.get(e);
                                s && clearTimeout(s);
                                const o = void 0 !== r ? t - r : void 0;
                                x.set(e, t);
                                const n = setTimeout(() => {
                                    x.delete(e), C.delete(e)
                                }, 6e4);
                                return C.set(e, n), o
                            })(t.elementId, Date.now()),
                            s = {
                                adUnitPath: t.adUnit,
                                slotElementId: t.elementId,
                                targetingMap: {},
                                timeSinceLastRefreshMs: r
                            },
                            o = (0, n.$)("slotRequested", s);
                        T.A.pushEvent("slotRequested", { ...o,
                            ...P
                        })
                    }), e.events().on("impression", e => {
                        let {
                            bid: t,
                            slot: r
                        } = e;
                        const s = t.amount,
                            o = (0, h.Jf)(s, t.bidder, t.mediaType),
                            u = r.getElement(),
                            d = t.sourceData,
                            l = JSON.stringify({
                                adId: d ? .adId ? ? null,
                                creativeId: d ? .creativeId ? ? null,
                                meta: d ? .meta ? ? {}
                            }),
                            c = i(d ? .size) ? ? i(d ? .amznsz),
                            p = a(c, u),
                            b = g(p),
                            _ = {
                                adId: d ? .adId,
                                adUnitPath: r.adUnit,
                                bidder: t.bidder,
                                cpm: o,
                                creativeHeight: p.height,
                                creativeWidth: p.width,
                                currency: t.currency,
                                mediaType: t.mediaType,
                                message: l,
                                originalCpm: s,
                                revenue: o / 1e3,
                                size: b,
                                slotElementId: r.elementId,
                                source: t.source,
                                targetingMap: {}
                            },
                            $ = (0, n.$)("impression", _);
                        T.A.pushEvent("impression", { ...$,
                            ...P
                        }), O.add(_)
                    }), document.addEventListener("visibilitychange", () => {
                        if (document.hidden && "IFRAME" === document.activeElement ? .tagName && document.activeElement ? .id.startsWith("tudeserve-frame")) {
                            if (Math.random() > 1) return;
                            if (L) return;
                            const e = document.activeElement,
                                t = e.closest(".tudeserve-wrap") ? .parentElement ? .id;
                            t && (L = !0, setTimeout(() => {
                                L = !1
                            }, 5e3), window.tudeserve = window.tudeserve || {
                                cmd: []
                            }, window.tudeserve.cmd = window.tudeserve.cmd || [], window.tudeserve.cmd.push(e => {
                                if (!e.ads().slots.getSlotByElementId(t)) return;
                                const r = O.find(e => e.slotElementId === t);
                                if (r) {
                                    const e = (0, n.$)("adClicked", { ...r
                                    });
                                    T.A.pushEvent("adClicked", { ...e,
                                        ...P,
                                        ...r.message ? {
                                            message: r.message
                                        } : {}
                                    })
                                }
                            }))
                        }
                    })
                }))
            };
        var U = __webpack_require__(9313),
            k = __webpack_require__(5095),
            J = __webpack_require__(9409),
            q = __webpack_require__(2187),
            W = __webpack_require__(7035),
            V = __webpack_require__(2981),
            G = __webpack_require__(6968),
            z = __webpack_require__(7234),
            H = __webpack_require__(6273),
            Y = __webpack_require__(3907),
            Z = __webpack_require__(8196),
            X = __webpack_require__(923),
            K = __webpack_require__(9711),
            Q = __webpack_require__(7127),
            ee = __webpack_require__(607),
            te = __webpack_require__(876),
            re = __webpack_require__(1665),
            se = __webpack_require__(3506),
            oe = __webpack_require__(4172),
            ne = __webpack_require__(4964),
            ie = __webpack_require__(2814),
            ae = __webpack_require__(1038),
            ge = __webpack_require__(322),
            ue = __webpack_require__(564),
            de = __webpack_require__(1602),
            le = __webpack_require__(7725),
            ce = __webpack_require__(4543),
            pe = __webpack_require__(2200);
        const be = (0, U.Ik)({
            [k.Z]: k.w.optional(),
            [J.Z]: J.w.default("googletag"),
            [q.Z]: q.w.optional(),
            [W.Z]: W.w.optional(),
            [V.Z]: V.w.optional(),
            [G.Z]: G.w.optional(),
            [z.Z]: z.w.optional(),
            [H.Z]: H.w.optional(),
            [Y.Z]: Y.w.optional(),
            [Z.Z]: Z.w.optional(),
            [X.Z]: X.w.default("customEvent"),
            [K.Z]: K.w.optional(),
            [Q.Z]: Q.w.optional(),
            [ee.Z]: ee.w.optional(),
            [te.Z]: te.w.optional(),
            [re.Z]: re.w.optional(),
            [se.Z]: se.w.optional(),
            [oe.Z]: oe.w.optional(),
            [ne.Z]: ne.w.optional(),
            [ie.Z]: ie.w.optional(),
            [ae.Z]: ae.w.optional(),
            [ge.Z]: ge.w.optional(),
            [ue.Z]: ue.w.optional(),
            [de.Z]: de.w.optional(),
            [le.Z]: le.w.optional(),
            [ce.Z]: ce.w.optional(),
            [pe.Z]: pe.w.optional()
        });
        var _e = __webpack_require__(9060);
        class $e extends f.b {
            props;
            constructor(e) {
                super(), this.props = e
            }
            get id() {
                return this.props.id
            }
            get publisherId() {
                return this.props.publisherId
            }
            get matchEnabled() {
                return this.props.matchEnabled ? ? !1
            }
            get name() {
                return this.props.name
            }
            get eventPublisherValue() {
                return this.props.eventPublisherValue
            }
            get identityProvidersSampleRate() {
                const e = this.props.identityProvidersSampleRate ? ? 0;
                return Math.max(0, Math.min(e, 1))
            }
            get prebidAuctionSampleRate() {
                const e = this.props.prebidAuctionSampleRate ? ? 0;
                return Math.max(0, Math.min(e, 1))
            }
            get sampleRate() {
                const e = this.props.sampleRate ? ? 1;
                return Math.max(0, Math.min(e, 1))
            }
            get trackConnatix() {
                return this.props.trackConnatix
            }
            get trackGoogletag() {
                return this.props.trackGoogletag
            }
            get trackInstream() {
                return this.props.trackInstream
            }
            get trackPrebid() {
                return this.props.trackPrebid
            }
            get trackPrimis() {
                return this.props.trackPrimis
            }
            get trackSession() {
                return this.props.trackSession
            }
            get trackTudeserve() {
                return this.props.trackTudeserve
            }
            get tudeMetaSampleRate() {
                const e = this.props.tudeMetaSampleRate ? ? 0;
                return Math.max(0, Math.min(e, 1))
            }
        }
        class he extends f.b {
            props;
            constructor(e) {
                super(), this.props = e
            }
            get bidValueInputs() {
                return this.props.bval
            }
            get googleFloorsEnabled() {
                return this.props.gflr
            }
            get mediaType() {
                return this.props.mt
            }
            get model() {
                return this.props.mid
            }
            get configId() {
                return this.props.cid
            }
            get pctTraffic() {
                return this.props.pct / 100
            }
        }
        var me = __webpack_require__(5810);
        const ye = async () => (await fetch("https://geo.aditude.io/raven", {
            method: "GET",
            mode: "cors"
        })).json();
        var fe = __webpack_require__(8386),
            je = __webpack_require__(801);
        const Se = "raven-rps",
            Ae = {
                count: 0,
                cumulativeValue: 0,
                currency: "USD",
                value: 0
            },
            we = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "USD";
                const {
                    count: r,
                    cumulativeValue: s
                } = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "USD",
                        t = Ae;
                    if (!window.sessionStorage) return t;
                    let r = window.sessionStorage.getItem(Se);
                    if (!r) return t;
                    try {
                        const s = JSON.parse(r);
                        if (!s.t || !s.n || !s.c || s.c !== e) return t;
                        t = {
                            count: s.n,
                            cumulativeValue: s.t,
                            currency: s.c,
                            value: 0
                        }
                    } catch (e) {}
                    return t
                }(t), o = r + 1, n = s + e;
                return window.sessionStorage ? .setItem(Se, JSON.stringify({
                    c: t,
                    h: 100 * Math.random(),
                    n: o,
                    t: n,
                    x: Math.random()
                })), {
                    count: o,
                    cumulativeValue: n,
                    currency: t,
                    value: e
                }
            };

        function Ee(e, t) {
            e.forEach(e => {
                switch (r.Ay.debug("feature enabled", void 0, e), e) {
                    case "CLIENT_RPS_EVENTS":
                        !async function() {
                            window.sessionStorage ? je.T9.on("pushEvent", e => {
                                const {
                                    data: t,
                                    eventType: r
                                } = e;
                                if ("impression" === r) {
                                    const {
                                        cpm: e,
                                        currency: r = "USD",
                                        adUnitPath: s,
                                        slotElementId: o
                                    } = t;
                                    if ("number" == typeof e) {
                                        const t = we(e / 1e3, r);
                                        t && (0, fe.fD)("tudeSessionValueEstimate", { ...t,
                                            adUnit: s,
                                            slotElementId: o
                                        })
                                    }
                                }
                                "newSession" === r && we(0)
                            }) : r.Ay.warn("Session storage is not available", void 0, "CLIENT_RPS_EVENTS")
                        }();
                        break;
                    case "INSTREAM_TRACKING":
                        __webpack_require__.e(511).then(__webpack_require__.bind(__webpack_require__, 8645));
                        break;
                    case "PREBID_ANALYTICS":
                        __webpack_require__.e(12).then(__webpack_require__.bind(__webpack_require__, 4225)).then(e => {
                            let {
                                initPrebidAnalytics: r
                            } = e;
                            return r(t)
                        });
                        break;
                    case "CONNATIX_SR_TRACKING":
                        __webpack_require__.e(972).then(__webpack_require__.bind(__webpack_require__, 9225))
                }
            })
        }
        var ve = __webpack_require__(7403),
            Te = __webpack_require__(2407),
            Me = __webpack_require__(9326),
            Ie = __webpack_require__(3564),
            Re = __webpack_require__(92);
        const Fe = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "GB", "IS", "LI", "NO"],
            De = e => !!e && Fe.includes(e.toUpperCase()),
            Be = () => "undefined" != typeof window && "function" == typeof window.__tcfapi,
            Oe = async function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1317;
                try {
                    const t = await new Promise((e, t) => {
                            Be() ? window.__tcfapi("getTCData", 2, (r, s) => {
                                s ? e(r) : t(new Error("Failed to get TCF consent data"))
                            }) : t(new Error("TCF API not available"))
                        }),
                        r = !0 === t.vendor ? .consents ? .[e],
                        s = !0 === t.vendor ? .legitimateInterests ? .[e],
                        o = !0 === t.purpose ? .consents ? .[1],
                        n = !0 === t.purpose ? .consents ? .[10];
                    return {
                        hasConsent: r || s,
                        canCollectPII: (r || s) && (o || n),
                        consentString: t.tcString,
                        tcData: t
                    }
                } catch (e) {
                    return {
                        hasConsent: !1,
                        canCollectPII: !1
                    }
                }
            },
            Pe = async function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1317;
                if (!De(e.country)) return e;
                try {
                    return (await Oe(t)).canCollectPII ? e : { ...e,
                        ...(0, Re.$R)(e)
                    }
                } catch (t) {
                    return { ...e,
                        ...(0, Re.$R)(e)
                    }
                }
            };
        class Le {
            consentStateListeners = [];
            isListening = !1;
            vendorId;
            geo;
            constructor(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1317;
                this.vendorId = t, this.geo = e
            }
            async initialize() {
                await this.updateConsentState(), this.startListening(), r.Ay.debug("TCF Event Manager initialized", {
                    vendorId: this.vendorId,
                    consentState: (0, o.Xd)().tcfConsent
                })
            }
            notifyConsentStateListeners() {
                this.consentStateListeners.forEach(e => e())
            }
            onConsentStateChange(e) {
                this.consentStateListeners.push(e)
            }
            async updateConsentState() {
                try {
                    const e = await async function(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1317;
                        const s = De(e.country),
                            o = Be();
                        let n = null;
                        if (o) try {
                            n = await Oe(t)
                        } catch (e) {
                            r.Ay.debug("TCF check failed", {
                                error: e
                            }, "tcf-consent")
                        }
                        return {
                            userInEU: s,
                            tcfApiAvailable: o,
                            hasConsent: n ? .hasConsent ? ? !1,
                            canCollectPII: n ? .canCollectPII ? ? !1,
                            shouldScrubData: s && (!o || !n ? .canCollectPII),
                            consentString: n ? .consentString
                        }
                    }(this.geo, this.vendorId);
                    (0, o.t2)({
                        tcfConsent: { ...e,
                            lastUpdated: Date.now()
                        }
                    }), r.Ay.debug("TCF consent state updated", e)
                } catch (e) {
                    const t = {
                        userInEU: !1,
                        tcfApiAvailable: !1,
                        hasConsent: !1,
                        canCollectPII: !1,
                        shouldScrubData: !1,
                        lastUpdated: Date.now()
                    };
                    (0, o.t2)({
                        tcfConsent: t
                    }), r.Ay.warn("TCF consent state update failed, using fallback", {
                        error: e,
                        fallbackState: t
                    })
                }
                this.notifyConsentStateListeners()
            }
            startListening() {
                !this.isListening && Be() && (this.isListening = !0, window.__tcfapi && window.__tcfapi("addEventListener", 2, (e, t) => {
                    t && e && (r.Ay.debug("TCF event received", {
                        eventStatus: e.eventStatus,
                        tcData: e
                    }), "useractioncomplete" !== e.eventStatus && "tcloaded" !== e.eventStatus || this.updateConsentState())
                }), window.addEventListener("tcfapi_ready", () => {
                    r.Ay.debug("TCF API ready event received"), this.updateConsentState()
                }), window.addEventListener("tcfapi_consent_changed", () => {
                    r.Ay.debug("TCF consent changed event received"), this.updateConsentState()
                }))
            }
            stopListening() {
                this.isListening && (this.isListening = !1, window.__tcfapi && window.__tcfapi("removeEventListener", 2, () => {
                    r.Ay.debug("TCF event listener removed")
                }))
            }
            async refreshConsentState() {
                await this.updateConsentState()
            }
            getCurrentConsentState() {
                return (0, o.Xd)().tcfConsent
            }
            updateGeoData(e) {
                this.geo = e, this.updateConsentState()
            }
        }
        var xe = __webpack_require__(7253);
        class Ce {
            modelName;
            config;
            constructor(e, t) {
                this.modelName = e, this.config = t
            }
            async onLoad() {
                return new Promise(() => ({}))
            }
        }
        class Ne extends Ce {
            constructor(e) {
                super("adx-ranger-v1", e)
            }
            async onLoad() {
                return new Promise(() => ({}))
            }
            async estimateCpm(e) {
                const {
                    competingBids: t,
                    googleDemandFloor: s,
                    wonSourceType: o
                } = e;
                t.sort((e, t) => (t ? .value ? ? 0) - (e ? .value ? ? 0));
                const {
                    googleFloorsEnabled: n
                } = this.config, i = Math.max(n ? s ? ? 0 : 0, t.length > 0 ? t[0] ? .value : 0);
                if ("adsense" === o || "adx" === o || "openbidding" === o) {
                    const {
                        bmin: e,
                        bmax: t,
                        bmult: s
                    } = this.config.bidValueInputs ? ? {
                        bmax: .01,
                        bmin: .01,
                        bmult: 1
                    };
                    if (i > t) return r.Ay.verbose(`${this.modelName}: highestOtherValue ${i} is greater than bmax ${t}`), i + .01; {
                        const o = Math.random(),
                            n = (e + Math.max(t - e, 0) * o) * s;
                        return r.Ay.verbose(`${this.modelName}: picked ${n} from range ${e} to ${t}`), n
                    }
                }
                let a;
                switch (o) {
                    case "house":
                        return 0;
                    case "other":
                    case "unmapped":
                        return i + .01;
                    default:
                        return a = t.find(e => e.source === o), a ? .value ? ? .01
                }
            }
        }
        class Ue extends Ce {
            constructor(e) {
                super("one-cent-fallback", e)
            }
            async onLoad() {
                return new Promise(() => ({}))
            }
            async estimateCpm(e) {
                const {
                    competingBids: t,
                    googleDemandFloor: r,
                    wonSourceType: s
                } = e;
                t.sort((e, t) => (t ? .value ? ? 0) - (e ? .value ? ? 0));
                const {
                    googleFloorsEnabled: o
                } = this.config, n = Math.max(o ? r ? ? 0 : 0, t.length > 0 ? t[0].value : 0);
                let i;
                switch (s) {
                    case "house":
                        return 0;
                    case "adsense":
                    case "adx":
                    case "openbidding":
                    case "other":
                    case "unmapped":
                        return n + .01;
                    default:
                        return i = t.find(e => e.source === s), i ? .value ? ? .01
                }
            }
        }
        const ke = {
            "adx-ranger-v1": async e => new Ne(e),
            "one-cent-fallback": async e => new Ue(e)
        };
        async function Je(e, t) {
            if (ke[e]) return ke[e](t)
        }
        class qe {
            bidModelConfigs;
            constructor(e) {
                this.bidModelConfigs = e
            }
            async getBidEstimationModel(e) {
                let t = this.bidModelConfigs.filter(t => t.mediaType === e);
                0 === t.length && (t = this.bidModelConfigs.filter(e => null === e.mediaType));
                const r = Math.random();
                let s = 0;
                for (const e of t)
                    if (s += e.pctTraffic, r < s) return await Je(e.model, e) ? ? await Je("one-cent-fallback", e);
                return await Je("one-cent-fallback", new he({
                    cid: "fallback",
                    gflr: !1,
                    mt: null,
                    mid: "one-cent-fallback",
                    bval: {
                        bmin: .01,
                        bmax: .01,
                        bmult: 1,
                        mt: "COND_0"
                    },
                    cpk: 100,
                    pid: null,
                    ppid: null,
                    pct: 100
                }))
            }
        }
        var We = __webpack_require__(990),
            Ve = __webpack_require__(8076);

        function Ge(e) {
            return (0, Ve.UF)(e)
        }
        async function ze(e) {
            const t = new We.v(e, {
                queueInterval: 1e3
            });
            t.onBeforeSend(e => Ge(e));
            const r = new We.v(e, {
                queueInterval: 2e3
            });
            r.onBeforeSend(e => Ge(e)), T.A.registerEventProcessor("primary", {
                events: ["*"],
                processor: t
            }), T.A.registerEventProcessor("userFeedback", {
                events: ["userFeedback"],
                processor: r
            })
        }
        const He = function(e) {
            let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [];
            const o = document.createElement("script");
            o.async = !!t, r && (o.defer = !0), s.forEach(e => {
                o.setAttribute(`data-${e.key}`, e.value)
            }), o.src = e, document.head.appendChild(o)
        };
        r.Ay.always("Raven v1.20.0-69wxiu");
        const Ye = {
            batchSize: 20,
            strategyId: "fallback-aws-go",
            ingressMethod: "POST",
            ingressName: "fallback-aws-go",
            ingressUrl: "https://fixnlntptgvuwqeaqv7ij3bgoy0fyiho.lambda-url.us-east-1.on.aws/",
            failoverMethod: null,
            failoverName: null,
            failoverUrl: null,
            pagingInterval: 1e3
        };
        let Ze = !1,
            Xe = !1,
            Ke = "",
            Qe = null;
        window.addEventListener("beforeunload", () => {
            Qe && Qe.stopListening()
        });
        const et = e => e.map(e => {
                const t = new _e.T({
                    batchSize: e.batchSize,
                    id: e.strategyId,
                    ingressMethod: e.ingressMethod,
                    ingressName: e.ingressName,
                    ingressUrl: e.ingressUrl
                });
                if (e.failoverUrl) {
                    const {
                        failoverUrl: r,
                        failoverMethod: s,
                        failoverName: o
                    } = e, n = new _e.T({
                        batchSize: e.batchSize,
                        id: e.strategyId,
                        ingressMethod: s ? ? "POST",
                        ingressName: o ? ? "failover",
                        ingressUrl: r
                    });
                    t.onFailure((e, t) => n.sendBatch(e, t))
                }
                return t
            }),
            tt = async function(e) {
                let s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if (Xe || Ze) return;
                Xe = !0, r.Ay.debug("Raven booting", {
                    propertyId: e
                });
                let i = 0,
                    a = {
                        address: null,
                        asn: null,
                        city: null,
                        country: null,
                        "country-region": null,
                        "postal-code": null,
                        "time-zone": null
                    },
                    g = null;
                for (; i < 2;) try {
                    const e = await ye();
                    e && (a = e.geo, g = e), r.Ay.debug("geo fetched", e ? .geo);
                    break
                } catch (e) {
                    i++, r.Ay.error("GeoFetchError: failed", {
                        e,
                        geoTries: i
                    })
                }
                try {
                    Qe = new Le(a), await Qe.initialize();
                    const e = { ...a
                    };
                    Qe.onConsentStateChange(async () => {
                        const t = await Pe(e),
                            r = { ...e,
                                ...t
                            };
                        (0, ve.RS)({
                            geo: r
                        })
                    });
                    const t = await Pe(a);
                    a = { ...a,
                        ...t
                    }, r.Ay.debug("TCF consent management initialized", {
                        originalGeo: g ? .geo,
                        processedGeo: a,
                        consentState: Qe.getCurrentConsentState()
                    })
                } catch (e) {
                    r.Ay.warn("TCF initialization failed, continuing without consent management", {
                        error: e
                    })
                }
                const u = await t({
                    geo: a.country ? ? void 0,
                    propertyId: e
                }).catch(e => r.Ay.error("Raven config fetch failed", e.toString()));
                if (!u) return;
                if (u.error) return void r.Ay.error("Raven config error", u.error);
                r.Ay.debug("Raven config fetched", u);
                const {
                    endpoints: d
                } = u, l = et(d), {
                    property: c
                } = u, p = new $e(c);
                p.matchEnabled && ((0, fe.$3)("__tudepayload", e => {
                    "string" == typeof e && ((0, ve.iy)("tudePayload", e), r.Ay.debug("tudePayload set from window.__tudepayload", {
                        payload: e
                    }))
                }), He("https://match.aditude.cloud/loader.js", !0), r.Ay.debug("Match script injected", {
                    propertyId: p.id
                }));
                if (!(p.trackConnatix || p.trackGoogletag || p.trackPrebid || p.trackPrimis || p.trackSession || p.trackTudeserve)) return r.Ay.debug("No tracking is enabled for property", {
                    propertyId: p.id
                }), void(Xe = !1);
                const b = ["CLIENT_RPS_EVENTS"];
                p.trackConnatix && b.push("CONNATIX_SR_TRACKING"), p.trackInstream && b.push("INSTREAM_TRACKING"), p.trackPrebid && b.push("PREBID_ANALYTICS"), Ee(b, p);
                const {
                    sampleRate: _
                } = p, $ = (() => {
                    if (!Ke) {
                        const e = localStorage.getItem("tude-raven-sampling-bucket");
                        e ? Ke = e : (Ke = Math.random().toString(), localStorage.setItem("tude-raven-sampling-bucket", Ke))
                    }
                    return parseFloat(Ke)
                })();
                Ke = $.toString();
                const y = $ <= _;
                y || r.Ay.debug("User not in current sample. Tracking disabled.", {
                    sampleRate: _,
                    userSampleRate: $
                }), (0, o.t2)({
                    pbjsGlobals: s ? .pbjsGlobals ? ? ["pbjs"],
                    property: p,
                    ingressEndpoints: l
                }), Ze = !0, ze(l), (0, ve.RS)({
                    adServer: "googletag",
                    geo: a,
                    publisher: p.eventPublisherValue,
                    publisherId: p.publisherId
                }), window.tudeserve = window.tudeserve || {
                    cmd: []
                }, window.tudeserve.cmd = window.tudeserve.cmd || [], window.tudeserve.cmd.push(() => {
                    (0, o.t2)({
                        adServers: ["tudeserve"],
                        primaryAdServer: "tudeserve"
                    }), (0, ve.iy)("adServer", "tudeserve")
                });
                const {
                    pageviewId: f
                } = (0, o.Xd)();
                if (setTimeout(() => {
                        if (y) {
                            if (Te.mv && T.A.pushEvent("newUser", {}), Te.tr && p.trackSession) {
                                T.A.pushEvent("newSession", {});
                                const {
                                    tudeMetaSampleRate: e
                                } = p, t = Math.random() < e;
                                localStorage.setItem("ditu_tude_meta_sampled", t.toString());
                                const {
                                    identityProvidersSampleRate: r
                                } = p, s = Math.random() < r;
                                localStorage.setItem("ditu_identity_providers_sampled", s.toString())
                            }
                            T.A.pushEvent("pageView", {
                                pageviewId: f
                            })
                        }
                    }, 2e3), je.Vs.on("create", e => {
                        let {
                            session: t
                        } = e;
                        t && T.A.pushEvent("newSession", {})
                    }), u.customModifiers) {
                    const {
                        customModifiers: e
                    } = u;
                    (0, h.Ni)(e)
                }
                if ((p.trackGoogletag || p.trackInstream) && y) {
                    const {
                        modelConfigs: e
                    } = u, t = e.bid.models.map(e => new he(e)), r = new qe(t);
                    m.i.setModelProvider(r)
                }
                if (p.trackGoogletag && y && await B(p), p.trackTudeserve && await N(p), p.trackPrimis && y && await (async e => {
                        e.trackPrimis && (r.Ay.debug("tracking", void 0, "primis"), window.addEventListener("primisPlayerInit", e => {
                            if (r.Ay.debug("primisPlayerInit", {
                                    e
                                }), "detail" in e) {
                                const t = e.detail;
                                t.addEventListener("adStarted", e => {
                                    const r = e,
                                        s = Math.min(Math.max(0, r.impValue ? ? 0), 200) - Math.min(Math.max(0, r.servingFee ? ? 0), 200),
                                        o = (0, n.$)("impression", {
                                            adUnitPath: "primis_video",
                                            bidder: "primis",
                                            cpm: s,
                                            creativeHeight: r.playerHeight ? ? t ? .offsetHeight ? ? 0,
                                            creativeWidth: r.playerWidth ? ? t ? .offsetWidth ? ? 0,
                                            currency: "USD",
                                            mediaType: "video_primis",
                                            revenue: s / 1e3,
                                            size: `${r.playerWidth}x${r.playerHeight}`,
                                            slotElementId: t.id ? ? t.playerApiId ? ? "primis",
                                            source: "primis",
                                            targetingMap: {}
                                        });
                                    T.A.pushEvent("impression", { ...o,
                                        adServer: "primis",
                                        message: JSON.stringify({
                                            height: r.playerHeight,
                                            servingFee: r.servingFee,
                                            width: r.playerWidth
                                        })
                                    })
                                })
                            }
                        }))
                    })(p), void 0 !== window.Raven && "object" == typeof window.Raven && !Array.isArray(window.Raven) && void 0 !== window.Raven.cmd && Array.isArray(window.Raven.cmd)) {
                    const e = [...window.Raven.cmd];
                    for (const t of e)(0, xe.gR)(t)
                }(() => {
                    const e = {
                        config: {
                            setCustom: e => {
                                r.Ay.debug("setCustom received", e);
                                const t = (0, Me.U)();
                                (0, Me.m)({ ...t,
                                    ...e
                                })
                            },
                            setTudeMeta: e => {
                                r.Ay.debug("setTudeMeta received", e);
                                const t = (0, Ie.M)();
                                (0, Ie.i)({ ...t,
                                    ...e
                                })
                            },
                            setGlobalParams: e => {
                                try {
                                    const t = me.Z.cast(e, {
                                        stripUnknown: !0
                                    });
                                    (0, ve.RS)(t)
                                } catch (e) {
                                    if (e instanceof Error) r.Ay.error(`SetGlobalParams: ${e.message}`, e.toString());
                                    else {
                                        let t = "unknown";
                                        "string" == typeof e ? t = e : "object" == typeof e && (t = JSON.stringify(e)), r.Ay.error("SetGlobalParams: unknown", t)
                                    }
                                }
                            }
                        },
                        events: {
                            pageview: () => {
                                T.A.pushEvent("pageView", {})
                            },
                            send: (e, t) => {
                                T.A.pushEvent(e, t)
                            },
                            sendCustomEvent: (e, t) => {
                                r.Ay.debug(`sendCustomEvent.${e} received`, {
                                    eventData: t
                                });
                                try {
                                    const r = be.cast({ ...t,
                                        eventType: e
                                    });
                                    T.A.pushEvent(e, r)
                                } catch (e) {
                                    if (e instanceof Error) r.Ay.error(`SendCustomEventError: ${e.message}`, e.toString());
                                    else {
                                        let t = "unknown";
                                        "string" == typeof e ? t = e : "object" == typeof e && (t = JSON.stringify(e)), r.Ay.error("SendCustomEventError: unknown", t)
                                    }
                                }
                            }
                        },
                        consent: {
                            refresh: async () => {
                                Qe ? (await Qe.refreshConsentState(), r.Ay.debug("Consent state refreshed", Qe.getCurrentConsentState())) : r.Ay.warn("TCF manager not initialized, cannot refresh consent state")
                            },
                            getState: () => Qe && Qe.getCurrentConsentState() || null
                        }
                    };
                    (0, xe.U8)(e);
                    const t = {
                        cmd: {
                            push: xe.gR
                        }
                    };
                    window.Raven = t
                })(), (0, xe.yQ)(), setInterval(async () => {
                    if (document.hidden) return;
                    let s = await t({
                        geo: a.country ? ? void 0,
                        propertyId: e
                    }).catch(e => r.Ay.error("Raven config fetch failed", e.toString()));
                    if (!s) return;
                    const {
                        endpoints: n
                    } = s, i = et(n && n.length ? n : [Ye]);
                    (0, o.t2)({
                        ingressEndpoints: i
                    }), ze(i)
                }, 18e5), Xe = !1
            };
        if (window.Raven = window.Raven || {
                cmd: {
                    push: () => {}
                }
            }, window.Raven ? .initialConfig) {
            const {
                propertyId: e,
                pbjsGlobals: t
            } = window.Raven.initialConfig;
            tt(e, {
                pbjsGlobals: t
            })
        }
    })()
})();