/** 
 * onetrust-banner-sdk
 * v202604.2.0
 * by OneTrust LLC
 * Copyright 2026 
 */
(() => {
    var G = function(e, t) {
        return (G = Object.setPrototypeOf || ({
                __proto__: []
            }
            instanceof Array ? function(e, t) {
                e.__proto__ = t
            } : function(e, t) {
                for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o])
            }))(e, t)
    };

    function x(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

        function o() {
            this.constructor = e
        }
        G(e, t), e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o)
    }
    var H, R = function() {
        return (R = Object.assign || function(e) {
            for (var t, o = 1, n = arguments.length; o < n; o++)
                for (var r in t = arguments[o]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e
        }).apply(this, arguments)
    };

    function F(e, s, a, l) {
        return new(a = a || Promise)(function(o, t) {
            function n(e) {
                try {
                    i(l.next(e))
                } catch (e) {
                    t(e)
                }
            }

            function r(e) {
                try {
                    i(l.throw(e))
                } catch (e) {
                    t(e)
                }
            }

            function i(e) {
                var t;
                e.done ? o(e.value) : ((t = e.value) instanceof a ? t : new a(function(e) {
                    e(t)
                })).then(n, r)
            }
            i((l = l.apply(e, s || [])).next())
        })
    }

    function M(n, r) {
        var i, s, a, l = {
                label: 0,
                sent: function() {
                    if (1 & a[0]) throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            },
            c = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
        return c.next = e(0), c.throw = e(1), c.return = e(2), "function" == typeof Symbol && (c[Symbol.iterator] = function() {
            return this
        }), c;

        function e(o) {
            return function(e) {
                var t = [o, e];
                if (i) throw new TypeError("Generator is already executing.");
                for (; l = c && t[c = 0] ? 0 : l;) try {
                    if (i = 1, s && (a = 2 & t[0] ? s.return : t[0] ? s.throw || ((a = s.return) && a.call(s), 0) : s.next) && !(a = a.call(s, t[1])).done) return a;
                    switch (s = 0, (t = a ? [2 & t[0], a.value] : t)[0]) {
                        case 0:
                        case 1:
                            a = t;
                            break;
                        case 4:
                            return l.label++, {
                                value: t[1],
                                done: !1
                            };
                        case 5:
                            l.label++, s = t[1], t = [0];
                            continue;
                        case 7:
                            t = l.ops.pop(), l.trys.pop();
                            continue;
                        default:
                            if (!(a = 0 < (a = l.trys).length && a[a.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                l = 0;
                                continue
                            }
                            if (3 === t[0] && (!a || t[1] > a[0] && t[1] < a[3])) l.label = t[1];
                            else if (6 === t[0] && l.label < a[1]) l.label = a[1], a = t;
                            else {
                                if (!(a && l.label < a[2])) {
                                    a[2] && l.ops.pop(), l.trys.pop();
                                    continue
                                }
                                l.label = a[2], l.ops.push(t)
                            }
                    }
                    t = r.call(n, l)
                } catch (e) {
                    t = [6, e], s = 0
                } finally {
                    i = a = 0
                }
                if (5 & t[0]) throw t[1];
                return {
                    value: t[0] ? t[1] : void 0,
                    done: !0
                }
            }
        }
    }

    function U() {
        for (var e = 0, t = 0, o = arguments.length; t < o; t++) e += arguments[t].length;
        for (var n = Array(e), r = 0, t = 0; t < o; t++)
            for (var i = arguments[t], s = 0, a = i.length; s < a; s++, r++) n[r] = i[s];
        return n
    }(t = H = H || {})[t.ACTIVE = 0] = "ACTIVE", t[t.ALWAYS_ACTIVE = 1] = "ALWAYS_ACTIVE", t[t.EXPIRED = 2] = "EXPIRED", t[t.NO_CONSENT = 3] = "NO_CONSENT", t[t.OPT_OUT = 4] = "OPT_OUT", t[t.PENDING = 5] = "PENDING", t[t.WITHDRAWN = 6] = "WITHDRAWN";
    var q = setTimeout;

    function j(e) {
        return Boolean(e && void 0 !== e.length)
    }

    function K() {}

    function z(e) {
        if (!(this instanceof z)) throw new TypeError("Promises must be constructed via new");
        if ("function" != typeof e) throw new TypeError("not a function");
        this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], Z(e, this)
    }

    function W(o, n) {
        for (; 3 === o._state;) o = o._value;
        0 === o._state ? o._deferreds.push(n) : (o._handled = !0, z._immediateFn(function() {
            var e, t = 1 === o._state ? n.onFulfilled : n.onRejected;
            if (null === t)(1 === o._state ? Y : J)(n.promise, o._value);
            else {
                try {
                    e = t(o._value)
                } catch (e) {
                    return void J(n.promise, e)
                }
                Y(n.promise, e)
            }
        }))
    }

    function Y(t, e) {
        try {
            if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
            if (e && ("object" == typeof e || "function" == typeof e)) {
                var o = e.then;
                if (e instanceof z) return t._state = 3, t._value = e, void X(t);
                if ("function" == typeof o) return void Z((n = o, r = e, function() {
                    n.apply(r, arguments)
                }), t)
            }
            t._state = 1, t._value = e, X(t)
        } catch (e) {
            J(t, e)
        }
        var n, r
    }

    function J(e, t) {
        e._state = 2, e._value = t, X(e)
    }

    function X(e) {
        2 === e._state && 0 === e._deferreds.length && z._immediateFn(function() {
            e._handled || z._unhandledRejectionFn(e._value)
        });
        for (var t = 0, o = e._deferreds.length; t < o; t++) W(e, e._deferreds[t]);
        e._deferreds = null
    }

    function Q(e, t, o) {
        this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = o
    }

    function Z(e, t) {
        var o = !1;
        try {
            e(function(e) {
                o || (o = !0, Y(t, e))
            }, function(e) {
                o || (o = !0, J(t, e))
            })
        } catch (e) {
            o || (o = !0, J(t, e))
        }
    }

    function $() {}
    z.prototype.catch = function(e) {
        return this.then(null, e)
    }, z.prototype.then = function(e, t) {
        var o = new this.constructor(K);
        return W(this, new Q(e, t, o)), o
    }, z.prototype.finally = function(t) {
        var o = this.constructor;
        return this.then(function(e) {
            return o.resolve(t()).then(function() {
                return e
            })
        }, function(e) {
            return o.resolve(t()).then(function() {
                return o.reject(e)
            })
        })
    }, z.all = function(t) {
        return new z(function(r, i) {
            if (!j(t)) return i(new TypeError("Promise.all accepts an array"));
            var s = Array.prototype.slice.call(t);
            if (0 === s.length) return r([]);
            var a = s.length;
            for (var e = 0; e < s.length; e++) ! function t(o, e) {
                try {
                    if (e && ("object" == typeof e || "function" == typeof e)) {
                        var n = e.then;
                        if ("function" == typeof n) return void n.call(e, function(e) {
                            t(o, e)
                        }, i)
                    }
                    s[o] = e, 0 == --a && r(s)
                } catch (e) {
                    i(e)
                }
            }(e, s[e])
        })
    }, z.resolve = function(t) {
        return t && "object" == typeof t && t.constructor === z ? t : new z(function(e) {
            e(t)
        })
    }, z.reject = function(o) {
        return new z(function(e, t) {
            t(o)
        })
    }, z.race = function(r) {
        return new z(function(e, t) {
            if (!j(r)) return t(new TypeError("Promise.race accepts an array"));
            for (var o = 0, n = r.length; o < n; o++) z.resolve(r[o]).then(e, t)
        })
    }, z._immediateFn = "function" == typeof setImmediate ? function(e) {
        setImmediate(e)
    } : function(e) {
        q(e, 0)
    }, z._unhandledRejectionFn = function(e) {
        "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
    }, $.prototype.initPolyfill = function() {
        this.initArrayIncludesPolyfill(), this.initObjectAssignPolyfill(), this.initArrayFillPolyfill(), this.initClosestPolyfill(), this.initIncludesPolyfill(), this.initEndsWithPoly(), this.initCustomEventPolyfill(), this.promisesPolyfil()
    }, $.prototype.initArrayIncludesPolyfill = function() {
        Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", {
            value: function(e) {
                for (var t = [], o = 1; o < arguments.length; o++) t[o - 1] = arguments[o];
                if (null == this) throw new TypeError("Array.prototype.includes called on null or undefined");
                var n = Object(this),
                    r = parseInt(n.length, 10) || 0;
                if (0 !== r) {
                    var i, s, a = t[1] || 0;
                    for (0 <= a ? i = a : (i = r + a) < 0 && (i = 0); i < r;) {
                        if (e === (s = n[i]) || e != e && s != s) return !0;
                        i++
                    }
                }
                return !1
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initEndsWithPoly = function() {
        String.prototype.endsWith || Object.defineProperty(String.prototype, "endsWith", {
            value: function(e, t) {
                return (void 0 === t || t > this.length) && (t = this.length), this.substring(t - e.length, t) === e
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initClosestPolyfill = function() {
        Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector), Element.prototype.closest || Object.defineProperty(Element.prototype, "closest", {
            value: function(e) {
                var t = this;
                do {
                    if (t.matches(e)) return t
                } while (null !== (t = t.parentElement || t.parentNode) && 1 === t.nodeType);
                return null
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initIncludesPolyfill = function() {
        String.prototype.includes || Object.defineProperty(String.prototype, "includes", {
            value: function(e, t) {
                return !((t = "number" != typeof t ? 0 : t) + e.length > this.length) && -1 !== this.indexOf(e, t)
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initObjectAssignPolyfill = function() {
        "function" != typeof Object.assign && Object.defineProperty(Object, "assign", {
            value: function(e, t) {
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                for (var o = Object(e), n = 1; n < arguments.length; n++) {
                    var r = arguments[n];
                    if (null != r)
                        for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (o[i] = r[i])
                }
                return o
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initArrayFillPolyfill = function() {
        Array.prototype.fill || Object.defineProperty(Array.prototype, "fill", {
            value: function(e) {
                if (null == this) throw new TypeError("this is null or not defined");
                for (var t = Object(this), o = t.length >>> 0, n = arguments[1] >> 0, r = n < 0 ? Math.max(o + n, 0) : Math.min(n, o), n = arguments[2], n = void 0 === n ? o : n >> 0, i = n < 0 ? Math.max(o + n, 0) : Math.min(n, o); r < i;) t[r] = e, r++;
                return t
            }
        })
    }, $.prototype.initCustomEventPolyfill = function() {
        if ("function" == typeof window.CustomEvent) return !1;

        function e(e, t) {
            t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            };
            var o = document.createEvent("CustomEvent");
            return o.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), o
        }
        e.prototype = window.Event.prototype, window.CustomEvent = e
    }, $.prototype.insertViewPortTag = function() {
        var e = document.querySelector('meta[name="viewport"]'),
            t = document.createElement("meta");
        t.name = "viewport", t.content = "width=device-width, initial-scale=1", e || document.head.appendChild(t)
    }, $.prototype.promisesPolyfil = function() {
        "undefined" == typeof Promise && (window.Promise = z)
    };
    var ee, te, oe, ne, re, ie, se, ae, le, ce, de, ue, pe, Ce, ge, he, ye, fe, Se, me, ve, Te, Ae, Pe, ke, Ie, be, Le, Ee, Oe, _e, De, Ne, we, Be, Ve, Ge, xe = new $,
        He = ((t = ee = ee || {})[t.Unknown = 0] = "Unknown", t[t.BannerCloseButton = 1] = "BannerCloseButton", t[t.ConfirmChoiceButton = 2] = "ConfirmChoiceButton", t[t.AcceptAll = 3] = "AcceptAll", t[t.RejectAll = 4] = "RejectAll", t[t.BannerSaveSettings = 5] = "BannerSaveSettings", t[t.ContinueWithoutAcceptingButton = 6] = "ContinueWithoutAcceptingButton", (t = te = te || {})[t.Banner = 1] = "Banner", t[t.PC = 2] = "PC", t[t.API = 3] = "API", (t = oe = oe || {}).AcceptAll = "AcceptAll", t.RejectAll = "RejectAll", t.UpdateConsent = "UpdateConsent", (t = ne = ne || {})[t.Purpose = 1] = "Purpose", t[t.SpecialFeature = 2] = "SpecialFeature", (t = re = re || {}).Legal = "legal", t.UserFriendly = "user_friendly", (t = ie = ie || {}).Top = "top", t.Bottom = "bottom", (t = se = se || {})[t.Banner = 0] = "Banner", t[t.PrefCenterHome = 1] = "PrefCenterHome", t[t.VendorList = 2] = "VendorList", t[t.CookieList = 3] = "CookieList", t[t.IabIllustrations = 4] = "IabIllustrations", (t = ae = ae || {})[t.RightArrow = 39] = "RightArrow", t[t.LeftArrow = 37] = "LeftArrow", t[t.UpArrow = 38] = "UpArrow", t[t.DownArrow = 40] = "DownArrow", (t = le = le || {}).AfterTitle = "AfterTitle", t.AfterDescription = "AfterDescription", t.AfterDPD = "AfterDPD", (t = ce = ce || {}).PlusMinus = "Plusminus", t.Caret = "Caret", t.NoAccordion = "NoAccordion", (t = de = de || {}).Consent = "Consent", t.LI = "LI", t.AddtlConsent = "AddtlConsent", (t = ue = ue || {}).Iab1Pub = "eupubconsent", t.Iab2Pub = "eupubconsent-v2", t.Iab1Eu = "euconsent", t.Iab2Eu = "euconsent-v2", (t = pe = pe || {})[t.Disabled = 0] = "Disabled", t[t.Consent = 1] = "Consent", t[t.LegInt = 2] = "LegInt", (t = Ce = Ce || {})[t["Banner - Allow All"] = 1] = "Banner - Allow All", t[t["Banner - Reject All"] = 2] = "Banner - Reject All", t[t["Banner - Close"] = 3] = "Banner - Close", t[t["No Banner - Close"] = 13] = "No Banner - Close", t[t["Banner - Continue without Accepting"] = 8] = "Banner - Continue without Accepting", t[t["Preference Center - Allow All"] = 4] = "Preference Center - Allow All", t[t["Preference Center - Reject All"] = 5] = "Preference Center - Reject All", t[t["Preference Center - Confirm"] = 6] = "Preference Center - Confirm", t[t["GPC value changed"] = 7] = "GPC value changed", t[t["API - Allow All"] = 9] = "API - Allow All", t[t["API - Reject All"] = 10] = "API - Reject All", t[t["API - UpdateConsent"] = 11] = "API - UpdateConsent", t[t["Anonymous - Logged Out Consent"] = 12] = "Anonymous - Logged Out Consent", (t = ge = ge || {}).Active = "1", t.InActive = "0", (t = he = he || {}).Host = "Host", t.GenVendor = "GenVen", (t = ye = ye || {})[t.Host = 1] = "Host", t[t.GenVen = 2] = "GenVen", t[t.HostAndGenVen = 3] = "HostAndGenVen", (t = fe = fe || {})[t.minDays = 1] = "minDays", t[t.maxDays = 30] = "maxDays", t[t.maxYear = 31536e3] = "maxYear", t[t.maxSecToDays = 86400] = "maxSecToDays", (t = Se = Se || {})[t.RTL = 0] = "RTL", t[t.LTR = 1] = "LTR", (t = me = me || {})[t.GoogleVendor = 1] = "GoogleVendor", t[t.GeneralVendor = 2] = "GeneralVendor", (t = e = e || {})[t.Days = 1] = "Days", t[t.Weeks = 7] = "Weeks", t[t.Months = 30] = "Months", t[t.Years = 365] = "Years", (t = ve = ve || {}).Checkbox = "Checkbox", t.Toggle = "Toggle", (t = Te = Te || {}).SlideIn = "Slide_In", t.FadeIn = "Fade_In", t.RemoveAnimation = "Remove_Animation", (t = Ae = Ae || {}).Link = "Link", t.Icon = "Icon", (t = Pe = Pe || {}).consent = "consent", t.set = "set", (t = ke = ke || {}).update = "update", t.default = "default", t.ads_data_redaction = "ads_data_redaction", (t = Ie = Ie || {}).analytics_storage = "analytics_storage", t.ad_storage = "ad_storage", t.functionality_storage = "functionality_storage", t.personalization_storage = "personalization_storage", t.security_storage = "security_storage", t.ad_user_data = "ad_user_data", t.ad_personalization = "ad_personalization", t.region = "region", t.wait_for_update = "wait_for_update", (t = be = be || {}).granted = "granted", t.denied = "denied", 0, (t = Le = Le || {}).OBJECT_TO_LI = "ObjectToLI", t.LI_ACTIVE_IF_LEGAL_BASIS = "LIActiveIfLegalBasis", (t = Ee = Ee || {}).cookies = "cookies", t.vendors = "vendors", (t = Oe = Oe || {}).GDPR = "GDPR", t.CCPA = "CCPA", t.IAB2 = "IAB2", t.IAB2V2 = "IAB2V2", t.GENERIC = "GENERIC", t.LGPD = "LGPD", t.GENERIC_PROMPT = "GENERIC_PROMPT", t.CPRA = "CPRA", t.CDPA = "CDPA", t.DELAWARE = "DELAWARE", t.IOWA = "IOWA", t.NEBRASKA = "NEBRASKA", t.USNATIONAL = "USNATIONAL", t.CUSTOM = "CUSTOM", t.FLORIDA = "FLORIDA", t.COLORADO = "COLORADO", t.CONNECTICUT = "CTDPA", t.MONTANA = "MONTANA", t.TEXAS = "TEXAS", t.OREGON = "OREGON", t.TENNESSEE = "TENNESSEE", t.NEWJERSEY = "NEWJERSEY", t.NEWHAMPSHIRE = "NEWHAMPSHIRE", t.UCPA = "UCPA", t.VIRGINIA = "VIRGINIA", {
            ca: Oe.CPRA,
            va: Oe.CDPA,
            co: Oe.COLORADO,
            or: Oe.OREGON,
            ct: Oe.CONNECTICUT,
            fl: Oe.FLORIDA,
            mt: Oe.MONTANA,
            tx: Oe.TEXAS,
            de: Oe.DELAWARE,
            ia: Oe.IOWA,
            ne: Oe.NEBRASKA,
            tn: Oe.TENNESSEE,
            nj: Oe.NEWJERSEY,
            nh: Oe.NEWHAMPSHIRE,
            ut: Oe.UCPA
        }),
        A = ((t = _e = _e || {}).ACCEPT_ALL = "ACCEPT_ALL", t.REJECT_ALL = "REJECT_ALL", t.SAVE_PREFERENCE = "SAVE_PREFERENCE", (t = De = De || {}).Name = "OTGPPConsent", t[t.ChunkSize = 4e3] = "ChunkSize", t.ChunkCountParam = "GPPCookiesCount", t.gppSid = "gppSid", (t = Ne = Ne || {}).MspaCoveredTransaction = "IsMSPAEnabled", t.MspaOptOutOptionMode = "Opt-Out", t.MspaServiceProviderMode = "Service Provider", 0, (t = we = we || {}).GpcSegmentType = "GpcSegmentType", t.Gpc = "Gpc", (t = Be = Be || {}).SensitiveDataProcessing = "SensitiveDataProcessing", t.KnownChildSensitiveDataConsents = "KnownChildSensitiveDataConsents", (t = Ve = Ve || {}).CPRA = "usca", t.CCPA = "usca", t.CDPA = "usva", t.OREGON = "usor", t.USNATIONAL = "usnat", t.COLORADO = "usco", t.FLORIDA = "usfl", t.CTDPA = "usct", t.MONTANA = "usmt", t.TEXAS = "ustx", t.DELAWARE = "usde", t.IOWA = "usia", t.NEBRASKA = "usne", t.TENNESSEE = "ustn", t.NEWJERSEY = "usnj", t.NEWHAMPSHIRE = "usnh", t.UCPA = "usut", t.VIRGINIA = "usva", t.IAB2V2 = "tcfeuv2", (t = Ge = Ge || {})[t.CPRA = 8] = "CPRA", t[t.CCPA = 8] = "CCPA", t[t.CDPA = 9] = "CDPA", t[t.OREGON = 15] = "OREGON", t[t.USNATIONAL = 7] = "USNATIONAL", t[t.COLORADO = 10] = "COLORADO", t[t.FLORIDA = 13] = "FLORIDA", t[t.MONTANA = 14] = "MONTANA", t[t.TEXAS = 16] = "TEXAS", t[t.DELAWARE = 17] = "DELAWARE", t[t.IOWA = 18] = "IOWA", t[t.NEBRASKA = 19] = "NEBRASKA", t[t.NEWHAMPSHIRE = 20] = "NEWHAMPSHIRE", t[t.NEWJERSEY = 21] = "NEWJERSEY", t[t.TENNESSEE = 22] = "TENNESSEE", t[t.UCPA = 11] = "UCPA", t[t.VIRGINIA = 9] = "VIRGINIA", t[t.CTDPA = 12] = "CTDPA", t[t.IAB2V2 = 2] = "IAB2V2", 0, 0, 0, 0, 0, {
            AWAITING_RE_CONSENT: "AwaitingReconsent",
            CONSENT_ID: "consentId",
            GEO_LOCATION: "geolocation",
            INTERACTION_COUNT: "interactionCount",
            IS_IAB_GLOBAL: "isIABGlobal",
            NOT_LANDING_PAGE: "NotLandingPage",
            GEO: "geo",
            GPC_ENABLED: "isGpcEnabled",
            GPC_Browser_Flag: "browserGpcFlag",
            DNT_ENABLED: "isDntEnabled",
            IS_ANONYMOUS_CONSENT: "isAnonUser",
            IDENTIFIER_TYPE: "identifierType",
            PREV_USER_CONSENT: "iType",
            INTERACTION_TYPE: "intType",
            GROUPS: "groups",
            HEALTH_SIGNATURE_AUTHORIZATION: "healthAuth",
            LAST_CONSENT_RECEIPT: "crTime",
            PREV_USER_HAD_TOKEN: "prevHadToken",
            FORCE_CONSENT_COOLOFF: "fclco"
        }),
        P = {
            ADDITIONAL_CONSENT_STRING: "OTAdditionalConsentString",
            ALERT_BOX_CLOSED: "OptanonAlertBoxClosed",
            OPTANON_CONSENT: "OptanonConsent",
            EU_PUB_CONSENT: "eupubconsent-v2",
            EU_CONSENT: "euconsent-v2",
            SELECTED_VARIANT: "OTVariant",
            OT_PREVIEW: "otpreview",
            GPP_CONSENT: De.Name,
            SESSION_TRACKING: "OTSessionTracking"
        },
        Re = "CONFIRMED",
        Fe = "OPT_OUT",
        Me = "NO_CHOICE",
        Ue = "NOTGIVEN",
        qe = "NO_OPT_OUT",
        f = {
            ALWAYS_INACTIVE: "always inactive",
            ALWAYS_ACTIVE: "always active",
            ACTIVE: "active",
            INACTIVE_LANDING_PAGE: "inactive landingpage",
            INACTIVE: "inactive",
            IMPLIED_CONSENT: "implied consent",
            GPC: "gpc",
            DNT: "dnt"
        },
        je = {
            LOCAL: "LOCAL",
            TEST: "TEST",
            LOCAL_TEST: "LOCAL_TEST",
            PRODUCTION: "PRODUCTION"
        },
        Ke = "data-document-language",
        ze = "data-language",
        We = "otCookieSettingsButton.json",
        Ye = "otCookieSettingsButtonRtl.json",
        Je = "otCenterRounded",
        Xe = "otFlat",
        Qe = "otFloatingRoundedCorner",
        Ze = "otFloatingFlat",
        $e = "otFloatingRoundedIcon",
        et = "otFloatingRounded",
        tt = "otChoicesBanner",
        ot = "otNoBanner",
        nt = "otPcCenter",
        rt = "otPcList",
        it = "otPcPanel",
        st = "otPcPopup",
        at = "otPcTab",
        lt = "hidebanner",
        ct = 210,
        dt = 160,
        ut = 105,
        pt = 30,
        Ct = "--ot-footer-space",
        gt = ((t = {})[e.Days] = "PCenterVendorListLifespanDay", t[e.Weeks] = "LfSpnWk", t[e.Months] = "PCenterVendorListLifespanMonth", t[e.Years] = "LfSpnYr", t),
        ht = "DNAC",
        yt = "Category",
        ft = "Host",
        St = "General Vendor",
        mt = "VendorService",
        vt = "aria-label",
        Tt = "aria-hidden",
        At = "aria-describedby",
        Pt = "aria-labelledby",
        kt = "ad_storage",
        It = "user_data",
        bt = "BRANCH",
        Lt = "COOKIE",
        Et = "IAB2V2_SPL_PURPOSE",
        Ot = "IAB2V2_FEATURE",
        _t = "IAB2V2_SPL_FEATURE",
        Dt = ["IAB2_PURPOSE", "IAB2_STACK", "IAB2_FEATURE", "IAB2_SPL_PURPOSE", "IAB2_SPL_FEATURE", "IAB2V2_PURPOSE", "IAB2V2_SPL_PURPOSE", "IAB2V2_FEATURE", "IAB2V2_SPL_FEATURE", "IAB2V2_STACK"],
        Nt = ["COOKIE", "BRANCH", "IAB2_STACK", "IAB2V2_STACK"],
        wt = ["IAB2_PURPOSE", "IAB2_SPL_FEATURE", "IAB2V2_PURPOSE", "IAB2V2_SPL_FEATURE"],
        Bt = ["IAB2_FEATURE", "IAB2_SPL_PURPOSE", "IAB2V2_FEATURE", "IAB2V2_SPL_PURPOSE"],
        Vt = ["IAB2_PURPOSE", "IAB2_SPL_PURPOSE", "IAB2_FEATURE", "IAB2_SPL_FEATURE"],
        Gt = {
            IAB2V2: "pur",
            IFE2V2: "ft",
            ISP2V2: "spl_pur",
            ISF2V2: "spl_ft"
        },
        xt = {
            pur: "purposes",
            ft: "features",
            spl_pur: "specialPurposes",
            spl_ft: "specialFeatures"
        },
        k = new function() {};

    function Ht(e, t, o) {
        void 0 === o && (o = !1);

        function n(e) {
            return e ? (";" !== (e = e.trim()).charAt(e.length - 1) && (e += ";"), e.trim()) : null
        }
        var i = n(e.getAttribute("style")),
            s = n(t),
            t = "",
            t = o && i ? (() => {
                for (var e = i.split(";").concat(s.split(";")).filter(function(e) {
                        return 0 !== e.length
                    }), t = "", o = "", n = e.length - 1; 0 <= n; n--) {
                    var r = e[n].substring(0, e[n].indexOf(":") + 1).trim();
                    t.indexOf(r) < 0 && (t += r, o += e[n] + ";")
                }
                return o
            })() : s;
        e.setAttribute("style", t)
    }
    a.insertAfter = function(e, t) {
        t.parentNode.insertBefore(e, t.nextSibling)
    }, a.insertBefore = function(e, t) {
        t.parentNode.insertBefore(e, t)
    }, a.inArray = function(e, t) {
        return t.indexOf(e)
    }, a.ajax = function(e) {
        var t = null,
            o = new XMLHttpRequest,
            n = e.type,
            r = e.contentType,
            i = e.data,
            s = e.success,
            a = e.token,
            t = e.error;
        o.open(n, e.url, !e.sync), o.setRequestHeader("Content-Type", r), a && o.setRequestHeader("Authorization", a), o.withCredentials = !1, o.onload = function() {
            var e;
            200 <= this.status && this.status < 400 ? (e = JSON.parse(this.responseText), s(e)) : t({
                message: "Error Loading Data",
                statusCode: this.status
            })
        }, o.onerror = function(e) {
            t(e)
        }, "post" === n.toLowerCase() || "put" === n.toLowerCase() ? o.send(i) : o.send()
    }, a.prevNextHelper = function(o, e, n) {
        var r = [];

        function i(e, t, o) {
            t[e] && o ? o.includes(".") ? (t[e].classList[0] || t[e].classList.value && t[e].classList.value.includes(o.split(".")[1])) && r.push(t[e]) : o.includes("#") ? t[e].id === o.split("#")[1] && r.push(t[e]) : t[e].tagName === document.createElement(o.trim()).tagName && r.push(t[e]) : t[e] && r.push(t[e])
        }
        return "string" == typeof e ? Array.prototype.forEach.call(document.querySelectorAll(e), function(e, t) {
            i(o, e, n)
        }) : i(o, e, n), r
    }, a.browser = function() {
        var e, t, o;
        return navigator.sayswho = (o = (t = navigator.userAgent).match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [], /trident/i.test(o[1]) ? "IE " + ((e = /\brv[ :]+(\d+)/g.exec(t) || [])[1] || "") : "Chrome" === o[1] && null != (e = t.match(/\b(OPR|Edge)\/(\d+)/)) ? e.slice(1).join(" ").replace("OPR", "Opera") : (o = o[2] ? [o[1], o[2]] : [navigator.appName, navigator.appVersion, "-?"], null != (e = t.match(/version\/(\d+)/i)) && o.splice(1, 1, e[1]), o.join(" "))), {
            version: parseInt(navigator.sayswho.split(" ")[1]),
            type: navigator.sayswho.split(" ")[0],
            userAgent: navigator.userAgent
        }
    }, a.isNodeList = function(e) {
        e = Object.prototype.toString.call(e);
        return "[object NodeList]" === e || "[object Array]" === e
    }, a.getInnerHtmlContent = function(e) {
        return a.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createHTML(e) : e
    }, a.getScriptUrl = function(e) {
        return a.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createScriptURL(e) : e
    }, a.isCspTrustedType = function() {
        var e;
        return (null == (e = window.OtTrustedType) ? void 0 : e.isCspTrustedTypeEnabled) && (null == (e = window.OtTrustedType) ? void 0 : e.TrustedTypePolicy)
    }, a.prototype.fadeOut = function(e) {
        var t = this;
        if (void 0 === e && (e = 60), 1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) Ht(this.el[o], "\n                    visibility: hidden;\n                    opacity: 0;\n                    transition: visibility 0s " + e + "ms, opacity " + e + "ms linear;\n                ", !0);
        var n = setInterval(function() {
            if (1 <= t.el.length)
                for (var e = 0; e < t.el.length; e++) t.el[e].style.opacity <= 0 && (Ht(t.el[e], "display: none;", !0), clearInterval(n), "optanon-popup-bg" === t.el[e].id) && t.el[e].removeAttribute("style")
        }, e);
        return this
    }, a.prototype.hide = function() {
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) Ht(this.el[e], "display: none;", !0), this.el[e].setAttribute(Tt, !0);
        else a.isNodeList(this.el) || (Ht(this.el, "display: none;", !0), this.el.setAttribute(Tt, !0));
        return this
    }, a.prototype.show = function(e) {
        if (void 0 === e && (e = "block"), 1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) Ht(this.el[t], "display: " + e + ";", !0), this.el[t].removeAttribute(Tt);
        else a.isNodeList(this.el) || (Ht(this.el, "display: " + e + ";", !0), this.el.removeAttribute(Tt));
        return this
    }, a.prototype.remove = function() {
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) this.el[e].parentNode.removeChild(this.el[e]);
        else this.el.parentNode.removeChild(this.el);
        return this
    }, a.prototype.css = function(e) {
        if (e)
            if (1 <= this.el.length) {
                if (!e.includes(":")) return this.el[0].style[e];
                for (var t = 0; t < this.el.length; t++) Ht(this.el[t], e)
            } else {
                if (!e.includes(":")) return this.el.style[e];
                Ht(this.el, e)
            }
        return this
    }, a.prototype.removeClass = function(e) {
        if (1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) this.el[t].classList ? this.el[t].classList.remove(e) : this.el[t].className = this.el[t].className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ");
        else this.el.classList ? this.el.classList.remove(e) : this.el.className = this.el.className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ");
        return this
    }, a.prototype.addClass = function(e) {
        if (1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) this.el[t].classList ? this.el[t].classList.add(e) : this.el[t].className += " " + e;
        else this.el.classList ? this.el.classList.add(e) : this.el.className += " " + e;
        return this
    }, a.prototype.on = function(r, i, s) {
        var e = this;
        if ("string" != typeof i)
            if (this.el && "HTML" === this.el.nodeName && "load" === r || "resize" === r || "scroll" === r) switch (r) {
                    case "load":
                        window.onload = i;
                        break;
                    case "resize":
                        window.onresize = i;
                        break;
                    case "scroll":
                        window.onscroll = i
                } else if (this.el && 1 <= this.el.length)
                    for (var t = 0; t < this.el.length; t++) this.el[t].addEventListener(r, i);
                else this.el && this.el instanceof Element && this.el.addEventListener(r, i);
        else if (this.el && "HTML" === this.el.nodeName && "load" === r || "resize" === r || "scroll" === r) switch (r) {
            case "load":
                window.onload = s;
                break;
            case "resize":
                window.onresize = s;
                break;
            case "scroll":
                window.onscroll = s
        } else {
            var a = function(o) {
                var n = o.target;
                e.el.eventExecuted = !0, Array.prototype.forEach.call(document.querySelectorAll(i), function(e, t) {
                    Rt["" + r + i] && delete Rt["" + r + i], e.addEventListener(r, s), e === n && s && s.call(e, o)
                }), e.el && e.el[0] ? e.el[0].removeEventListener(r, a) : e.el && e.el instanceof Element && e.el.removeEventListener(r, a)
            };
            if (this.el && 1 <= this.el.length)
                for (t = 0; t < this.el.length; t++) this.el[t].eventExecuted = !1, this.el[t].eventExecuted || this.el[t].addEventListener(r, a);
            else this.el && (this.el.eventExecuted = !1, !this.el.eventExecuted) && this.el instanceof Element && (Rt["" + r + i] || (Rt["" + r + i] = !0, this.el.addEventListener(r, a)))
        }
        return this
    }, a.prototype.off = function(e, t) {
        if (1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) this.el[o].removeEventListener(e, t);
        else this.el.removeEventListener(e, t);
        return this
    }, a.prototype.one = function(t, o) {
        var n = this;
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) this.el[e].addEventListener(t, function(e) {
                e.stopPropagation(), e.currentTarget.dataset.triggered || (o(), e.currentTarget.dataset.triggered = !0)
            });
        else {
            var r = function(e) {
                e.stopPropagation(), o(), n.off(t, r)
            };
            this.el.addEventListener(t, r)
        }
        return this
    }, a.prototype.trigger = function(e) {
        e = new CustomEvent(e, {
            customEvent: "yes"
        });
        return this.el.dispatchEvent(e), this
    }, a.prototype.focus = function() {
        return this.el && (1 <= this.el.length ? this.el[0].focus() : this.el.focus && this.el.focus()), this
    }, a.prototype.attr = function(e, t) {
        return this.el && 1 <= this.el.length ? t ? ("class" === e ? this.addClass(t) : this.el[0].setAttribute(e, t), this) : this.el[0].getAttribute(e) : t && this.el ? ("class" === e ? this.addClass(t) : this.el.setAttribute(e, t), this) : this.el && this.el.getAttribute(e)
    }, a.prototype.html = function(e) {
        if (null == e) return (1 <= this.el.length ? this.el[0] : this.el).innerHTML;
        var t = a.getInnerHtmlContent(e);
        if (1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) this.el[o].innerHTML = t;
        else this.el.innerHTML = t;
        return this
    }, a.prototype.append = function(e) {
        if ("string" != typeof e || e.includes("<") || e.includes(">"))
            if (Array.isArray(e)) {
                var o = this;
                Array.prototype.forEach.call(e, function(e, t) {
                    document.querySelector(o.selector).appendChild(new a(e, "ce").el)
                })
            } else {
                if ("string" == typeof e || Array.isArray(e)) return this.appendHtmlElement(e);
                if ("string" == typeof this.selector) document.querySelector(this.selector).appendChild(e);
                else if (1 <= e.length)
                    for (var t = 0; t < e.length; t++) this.selector.appendChild(e[t]);
                else this.selector.appendChild(e)
            }
        else this.el.insertAdjacentText("beforeend", e);
        return this
    }, a.prototype.text = function(o) {
        if (this.el) {
            if (1 <= this.el.length) {
                if (!o) return this.el[0].textContent;
                Array.prototype.forEach.call(this.el, function(e, t) {
                    e.textContent = o
                })
            } else {
                if (!o) return this.el.textContent;
                this.el.textContent = o
            }
            return this
        }
    }, a.prototype.data = function(o, n) {
        if (!(this.el.length < 1)) {
            if (!(1 <= this.el.length)) return r(this.el, n);
            Array.prototype.forEach.call(this.el, function(e, t) {
                r(e, n)
            })
        }
        return this;

        function r(e, t) {
            if (!t) return JSON.parse(e.getAttribute("data-" + o));
            "object" == typeof t ? e.setAttribute("data-" + o, JSON.stringify(t)) : e.setAttribute("data-" + o, t)
        }
    }, a.prototype.height = function(e) {
        this.el.length && (this.el = this.el[0]);
        for (var t = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("padding-top").split("px")[0]), o = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("padding-bottom").split("px")[0]), n = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("margin-top").split("px")[0]), r = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("margin-bottom").split("px")[0]), i = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("height").split("px")[0]), s = [t, o, n, r], a = 0, l = 0; l < s.length; l++) 0 < s[l] && (a += s[l]);
        return e ? (t = e.toString().split(parseInt(e))[1] ? e.toString().split(parseInt(e))[1] : "px", o = "number" == typeof e ? e : parseInt(e.toString().split(t)[0]), (t && "px" === t || "%" === t || "em" === t || "rem" === t) && (0 < o ? Ht(this.el, "height: " + (a + o + t) + ";", !0) : "auto" === e && Ht(this.el, "height: " + e + ";", !0)), this) : this.selector === document ? i : this.el.clientHeight - a
    }, a.prototype.each = function(e) {
        var t = !1;
        return void 0 === this.el.length && (this.el = [this.el], t = !0), Array.prototype.forEach.call(this.el, e), t && (this.el = this.el[0]), this
    }, a.prototype.is = function(e) {
        return this.el.length ? (this.el[0].matches || this.el[0].matchesSelector || this.el[0].msMatchesSelector || this.el[0].mozMatchesSelector || this.el[0].webkitMatchesSelector || this.el[0].oMatchesSelector).call(this.el[0], e) : (this.el.matches || this.el.matchesSelector || this.el.msMatchesSelector || this.el.mozMatchesSelector || this.el.webkitMatchesSelector || this.el.oMatchesSelector).call(this.el, e)
    }, a.prototype.filter = function(e) {
        return this.el = Array.prototype.filter.call(document.querySelectorAll(this.selector), e), this
    }, a.prototype.animate = function(e, t) {
        var o, n, r, i, s = this;
        this.el = document.querySelector(this.selector);
        for (o in e) n = o, i = r = void 0, r = parseInt(e[n]), i = e[n].split(parseInt(e[n]))[1] ? e[n].split(parseInt(e[n]))[1] : "px", r = s.createKeyFrameAnimation(n, s.el, r, i), (i = document.head.querySelector("#onetrust-style")) ? i.innerHTML = a.getInnerHtmlContent(i.innerHTML + r) : ((i = document.createElement("style")).id = "onetrust-legacy-style", i.type = "text/css", i.innerHTML = a.getInnerHtmlContent(r), document.head.appendChild(i)), s.addWebKitAnimation(n, t);
        return this
    }, a.prototype.scrollTop = function() {
        return this.el.scrollTop
    }, a.prototype.appendHtmlElement = function(o) {
        var n, r, e;
        return "string" == typeof this.selector ? document.querySelector(this.selector).appendChild(new a(o, "ce").el) : this.useEl ? (n = document.createDocumentFragment(), (r = !(!o.includes("<th") && !o.includes("<td"))) && (e = o.split(" ")[0].split("<")[1], n.appendChild(document.createElement(e)), n.firstChild.innerHTML = a.getInnerHtmlContent(o)), Array.prototype.forEach.call(this.el, function(e, t) {
            r ? e.appendChild(n.firstChild) : e.appendChild(new a(o, "ce").el)
        })) : this.selector.appendChild(new a(o, "ce").el), this
    }, a.prototype.createKeyFrameAnimation = function(e, t, o, n) {
        return "\n        @keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        @-webkit-keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        @-moz-keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        "
    }, a.prototype.addWebKitAnimation = function(e, t) {
        (a.browser().type = a.browser().version <= 8) ? Ht(this.el, "top" === e ? "-webkit-animation: slide-up-custom " : "-webkit-animation: slide-down-custom " + t + "ms ease-out forwards;"): Ht(this.el, "\n                animation-name: " + ("top" === e ? "slide-up-custom" : "slide-down-custom") + ";\n                animation-duration: " + t + "ms;\n                animation-fill-mode: forwards;\n                animation-timing-function: ease-out;\n            ", !0)
    };
    var S = a;

    function a(e, t) {
        switch (void 0 === t && (t = ""), this.selector = e, this.useEl = !1, t) {
            case "ce":
                var o = a.browser().type.toLowerCase(),
                    n = a.browser().version;
                n < 10 && "safari" === o || "chrome" === o && n <= 44 || n <= 40 && "firefox" === o ? ((n = document.implementation.createHTMLDocument()).body.innerHTML = a.getInnerHtmlContent(e), this.el = n.body.children[0]) : (o = document.createRange().createContextualFragment(a.getInnerHtmlContent(e)), this.el = o.firstChild), this.length = 1;
                break;
            case "":
                this.el = e === document || e === window ? document.documentElement : "string" != typeof e ? e : document.querySelectorAll(e), this.length = e === document || e === window || "string" != typeof e ? 1 : this.el.length;
                break;
            default:
                this.length = 0
        }
    }

    function m(e, t) {
        return new S(e, t = void 0 === t ? "" : t)
    }
    var Rt = {};

    function Ft() {}
    Ft.prototype.convertKeyValueLowerCase = function(e) {
        for (var t in e) e[t.toLowerCase()] ? e[t.toLowerCase()] = e[t].toLowerCase() : (e[t] && (e[t.toLowerCase()] = e[t].toLowerCase()), delete e[t]);
        return e
    }, Ft.prototype.arrToStr = function(e) {
        return e.toString()
    }, Ft.prototype.strToArr = function(e) {
        return e ? e.split(",") : []
    }, Ft.prototype.strToMap = function(e) {
        if (!e) return new Map;
        for (var t = new Map, o = 0, n = this.strToArr(e); o < n.length; o++) {
            var r = n[o].split(":");
            t.set(r[0], "1" === r[1])
        }
        return t
    }, Ft.prototype.empty = function(e) {
        var t = document.getElementById(e);
        if (t)
            for (; t.hasChildNodes();) t.removeChild(t.lastChild)
    }, Ft.prototype.show = function(e) {
        e = document.getElementById(e);
        e && Ht(e, "display: block;", !0)
    }, Ft.prototype.remove = function(e) {
        e = document.getElementById(e);
        e && e.parentNode && e.parentNode.removeChild(e)
    }, Ft.prototype.appendTo = function(e, t) {
        var o, e = document.getElementById(e);
        e && ((o = document.createElement("div")).innerHTML = S.getInnerHtmlContent(t), e.appendChild(o))
    }, Ft.prototype.contains = function(e, t) {
        for (var o = 0; o < e.length; o += 1)
            if (e[o].toString().toLowerCase() === t.toString().toLowerCase()) return !0;
        return !1
    }, Ft.prototype.indexOf = function(e, t) {
        for (var o = 0; o < e.length; o += 1)
            if (e[o] === t) return o;
        return -1
    }, Ft.prototype.endsWith = function(e, t) {
        return -1 !== e.indexOf(t, e.length - t.length)
    }, Ft.prototype.generateUUID = function() {
        var o = (new Date).getTime();
        return "undefined" != typeof performance && "function" == typeof performance.now && (o += performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var t = (o + 16 * Math.random()) % 16 | 0;
            return o = Math.floor(o / 16), ("x" === e ? t : 3 & t | 8).toString(16)
        })
    }, Ft.prototype.getActiveIdArray = function(e) {
        return e.filter(function(e) {
            return "true" === e.split(":")[1]
        }).map(function(e) {
            return parseInt(e.split(":")[0])
        })
    }, Ft.prototype.distinctArray = function(e) {
        var t = new Array;
        return e.forEach(function(e) {
            t.indexOf(e) < 0 && t.push(e)
        }), t
    }, Ft.prototype.findIndex = function(e, t) {
        for (var o = -1, n = 0; n < e.length; n++)
            if (void 0 !== e[n] && t(e[n], n)) {
                o = n;
                break
            }
        return o
    }, Ft.prototype.getURL = function(e) {
        var t = document.createElement("a");
        return t.href = e, t
    }, Ft.prototype.removeURLPrefixes = function(e) {
        return e.toLowerCase().replace(/(^\w+:|^)\/\//, "").replace("www.", "")
    }, Ft.prototype.removeChild = function(e) {
        if (e)
            if (e instanceof NodeList || e instanceof Array)
                for (var t = 0; t < e.length; t++) e[t].parentElement.removeChild(e[t]);
            else e.parentElement.removeChild(e)
    }, Ft.prototype.getRelativeURL = function(e, t, o) {
        return void 0 === o && (o = !1), t ? (t = "./" + e.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/").replace(".json", ""), o ? t : t + ".js") : e
    }, Ft.prototype.setCheckedAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && (o ? t.setAttribute("checked", "") : t.removeAttribute("checked"), t.checked = o)
    }, Ft.prototype.setAriaCheckedAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && t.setAttribute("aria-checked", o)
    }, Ft.prototype.setDisabledAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && (o ? t.setAttribute("aria-disabled", "true") : t.removeAttribute("aria-disabled"))
    }, Ft.prototype.setHtmlAttributes = function(e, t) {
        for (var o in t) e.setAttribute(o, t[o]), e[o] = t[o]
    }, Ft.prototype.calculateCookieLifespan = function(e) {
        return e < 0 ? N.LifespanTypeText : (e = Math.floor(e / fe.maxSecToDays)) < fe.minDays ? "< 1 " + N.PCenterVendorListLifespanDay : e < fe.maxDays ? e + " " + N.PCenterVendorListLifespanDays : 1 === (e = Math.floor(e / fe.maxDays)) ? e + " " + N.PCenterVendorListLifespanMonth : e + " " + N.PCenterVendorListLifespanMonths
    }, Ft.prototype.insertElement = function(e, t, o) {
        e && t && e.insertAdjacentElement(o, t)
    }, Ft.prototype.customQuerySelector = function(t) {
        return function(e) {
            return t.querySelector(e)
        }
    }, Ft.prototype.customQuerySelectorAll = function(t) {
        return function(e) {
            return t.querySelectorAll(e)
        }
    };
    var I, v = new Ft,
        e = (Mt.prototype.removeAlertBox = function() {
            null !== this.getCookie(P.ALERT_BOX_CLOSED) && this.setCookie(P.ALERT_BOX_CLOSED, "", 0, !0)
        }, Mt.prototype.removeIab1 = function() {
            null !== this.getCookie(ue.Iab1Pub) && this.setCookie(ue.Iab1Pub, "", 0, !0)
        }, Mt.prototype.removeIab2 = function() {
            null !== this.getCookie(ue.Iab2Pub) && this.setCookie(ue.Iab2Pub, "", 0, !0)
        }, Mt.prototype.removeAddtlStr = function() {
            null !== this.getCookie(P.ADDITIONAL_CONSENT_STRING) && this.setCookie(P.ADDITIONAL_CONSENT_STRING, "", 0, !0)
        }, Mt.prototype.removeVariant = function() {
            null !== this.getCookie(P.SELECTED_VARIANT) && this.setCookie(P.SELECTED_VARIANT, "", 0, !0)
        }, Mt.prototype.removeOptanon = function() {
            null !== this.getCookie(P.OPTANON_CONSENT) && this.setCookie(P.OPTANON_CONSENT, "", 0, !0)
        }, Mt.prototype.removePreview = function() {
            null !== this.getCookie(P.OT_PREVIEW) && this.setCookie(P.OT_PREVIEW, "", 0, !0)
        }, Mt.prototype.removeAllCookies = function() {
            this.removeIab1(), this.removeIab2(), this.removePreview(), this.removeOptanon(), this.removeVariant(), this.removeAlertBox(), this.removeAddtlStr(), this.removeAmpStorage()
        }, Mt.prototype.writeCookieParam = function(e, t, o, n) {
            var r, i, s, a = {},
                l = this.getCookie(e);
            if (l)
                for (i = l.split("&"), r = 0; r < i.length; r += 1) s = i[r].split("="), a[decodeURIComponent(s[0])] = s[0] === t && n ? decodeURIComponent(s[1]) : decodeURIComponent(s[1]).replace(/\+/g, " ");
            a[t] = o;
            l = k.moduleInitializer.TenantFeatures;
            l && l.CookieV2CookieDateTimeInISO ? a.datestamp = (new Date).toISOString() : a.datestamp = (new Date).toString(), a.version = w.otSDKVersion, o = this.param(a), this.setCookie(e, o, N.ReconsentFrequencyDays)
        }, Mt.prototype.readCookieParam = function(e, t, o) {
            var n, r, i, s, e = this.getCookie(e);
            if (e) {
                for (r = {}, i = e.split("&"), n = 0; n < i.length; n += 1) s = i[n].split("="), r[decodeURIComponent(s[0])] = o ? decodeURIComponent(s[1]) : decodeURIComponent(s[1]).replace(/\+/g, " ");
                return t && r[t] ? r[t] : t && !r[t] ? "" : r
            }
            return ""
        }, Mt.prototype.getCookie = function(e) {
            var t = null == (t = k) ? void 0 : t.moduleInitializer;
            if (t && t.MobileSDK) {
                var o = e + this.getCookieNameSuffix(e),
                    o = this.getCookieDataObj(o);
                if (o) return o.value;
                if (!t.SubDomainEnabled) {
                    o = this.getCookieDataObj(e);
                    if (o) return o.value
                }
            } else {
                if (w.isAMP && (w.ampData = JSON.parse(localStorage.getItem(w.dataDomainId)) || {}, w.ampData)) return w.ampData[e] || null;
                for (var n = "" + e + this.getCookieNameSuffix(e) + "=", r = 0, i = document.cookie.split(";"); r < i.length; r++) {
                    var s = i[r].trim();
                    if (0 === s.indexOf(n)) return s.substring(n.length)
                }
            }
            return null
        }, Mt.prototype.setAmpStorage = function() {
            window.localStorage.setItem(w.dataDomainId, JSON.stringify(w.ampData))
        }, Mt.prototype.removeAmpStorage = function() {
            window.localStorage.removeItem(w.dataDomainId)
        }, Mt.prototype.handleAmp = function(e, t) {
            "" !== t ? w.ampData[e] = t : delete w.ampData[e], 0 === Object.keys(w.ampData).length ? this.removeAmpStorage() : this.setAmpStorage()
        }, Mt.prototype.getExpiryValue = function(e, t, o) {
            return void 0 === t && (t = !1), void 0 === o && (o = new Date), e ? (o.setTime(o.getTime() + 24 * e * 60 * 60 * 1e3), "; expires=" + o.toUTCString()) : t ? "; expires=" + new Date(0).toUTCString() : ""
        }, Mt.prototype.getDomainUrl = function() {
            var e, t = k.moduleInitializer;
            return t && t.RootDomainConsentEnabled ? e = t.RootDomainUrl : t && t.Domain && (e = t.Domain), e
        }, Mt.prototype.getCookieNameSuffix = function(e) {
            var t;
            return e !== P.OT_PREVIEW && ((null == (t = e = k.moduleInitializer) ? void 0 : t.ScriptType) === je.PRODUCTION || (null == (t = e) ? void 0 : t.ScriptType) === je.LOCAL) && e.SubDomainEnabled && e.DomainHashValue ? "_" + e.DomainHashValue : ""
        }, Mt.prototype.setCookie = function(e, t, o, n, r) {
            var i, s, a, l, c, d;
            void 0 === n && (n = !1), void 0 === r && (r = new Date), w.isAMP ? this.handleAmp(e, t) : (o = this.getExpiryValue(o, n, r), n = k.moduleInitializer, s = "", (i = (i = this.getDomainUrl()) ? i.split("/") : []).length <= 1 ? i[1] = "" : s = i.slice(1).join("/"), a = "Samesite=Lax", n.CookieSameSiteNoneEnabled && (a = "Samesite=None; Secure", n.PartitionedCookieEnabled) && (a += "; Partitioned"), l = k.moduleInitializer.TenantFeatures, c = n.ScriptType === je.TEST || n.ScriptType === je.LOCAL_TEST, e = e + this.getCookieNameSuffix(e), w.isPreview || !c && !n.MobileSDK ? (d = t + o + "; path=/" + s + "; domain=." + i[0] + "; " + a, l && l.CookieV2CookiePriority && (d += ";Priority=High;"), document.cookie = e + "=" + d) : (d = t + o + "; path=/; " + a, l && l.CookieV2CookiePriority && (d += ";Priority=High;"), n.MobileSDK ? this.setCookieDataObj({
                name: e,
                value: t,
                expires: o,
                date: r,
                domainAndPath: i
            }) : document.cookie = e + "=" + d))
        }, Mt.prototype.setCookieDataObj = function(t) {
            var e;
            t && (w.otCookieData || (window.OneTrust && window.OneTrust.otCookieData ? w.otCookieData = window.OneTrust.otCookieData : w.otCookieData = []), -1 < (e = v.findIndex(w.otCookieData, function(e) {
                return e.name === t.name
            })) ? w.otCookieData[e] = t : w.otCookieData.push(t))
        }, Mt.prototype.getCookieDataObj = function(t) {
            w.otCookieData && 0 !== w.otCookieData.length || (window.OneTrust && window.OneTrust.otCookieData ? w.otCookieData = window.OneTrust.otCookieData : w.otCookieData = []);
            var e = v.findIndex(w.otCookieData, function(e) {
                return e.name === t
            });
            if (0 <= e) {
                var o = w.otCookieData[e];
                if (o.date) return new Date(o.date) < new Date ? (w.otCookieData.splice(e, 1), null) : o
            }
            return null
        }, Mt.prototype.getCookiesChunk = function(e, t) {
            var o = {};
            if (e.length <= 4e3) o[t] = e;
            else
                for (var n = 0, r = 0; n < e.length;) {
                    var i = e.slice(n, n + 4e3);
                    0 === r ? o[t] = i : o[t + "_" + r] = i, n += 4e3, r++
                }
            return o
        }, Mt.prototype.getMergedCookieByName = function(e) {
            var t = "",
                o = this.getCookie(e);
            if (!o) return "";
            t += o;
            for (var n = 1;;) {
                var r = this.getCookie(e + "_" + n);
                if (!r) break;
                t += r, n++
            }
            return t
        }, Mt.prototype.param = function(e) {
            var t, o = "";
            for (t in e) e.hasOwnProperty(t) && ("" !== o && (o += "&"), o += t + "=" + encodeURIComponent(e[t]).replace(/%20/g, "+"));
            return o
        }, Mt);

    function Mt() {}
    var T, b, Ut = {
            P_Content: "#ot-pc-content",
            P_Logo: ".ot-pc-logo",
            P_Title: "#ot-pc-title",
            P_Title_Mobile: "#ot-pc-title-mobile",
            P_Policy_Txt: "#ot-pc-desc",
            P_Vendor_Title_Elm: "#ot-lst-title",
            P_Vendor_Title: "#ot-lst-title h3",
            P_Manage_Cookies_Txt: "#ot-category-title",
            P_Label_Txt: ".ot-label-txt",
            P_Category_Header: ".ot-cat-header",
            P_Category_Grp: ".ot-cat-grp",
            P_Category_Item: ".ot-cat-item",
            P_Vendor_List: "#ot-pc-lst",
            P_Vendor_Content: "#ot-lst-cnt",
            P_Vendor_Container: "#ot-ven-lst",
            P_Ven_Bx: "ot-ven-box",
            P_Ven_Name: ".ot-ven-name",
            P_Ven_Link: ".ot-ven-link",
            P_Ven_Leg_Claim: ".ot-ven-legclaim-link",
            P_Ven_Ctgl: "ot-ven-ctgl",
            P_Ven_Ltgl: "ot-ven-litgl",
            P_Ven_Ltgl_Only: "ot-ven-litgl-only",
            P_Ven_Opts: ".ot-ven-opts",
            P_Triangle: "#ot-anchor",
            P_Fltr_Modal: "#ot-fltr-modal",
            P_Fltr_Options: ".ot-fltr-opts",
            P_Fltr_Option: ".ot-fltr-opt",
            P_Select_Cntr: "#ot-sel-blk",
            P_Host_Cntr: "#ot-host-lst",
            P_Host_Hdr: ".ot-host-hdr",
            P_Host_Desc: ".ot-host-desc",
            P_Li_Hdr: ".ot-pli-hdr",
            P_Li_Title: ".ot-li-title",
            P_Sel_All_Vendor_Consent_Handler: "#select-all-vendor-leg-handler",
            P_Sel_All_Vendor_Leg_Handler: "#select-all-vendor-groups-handler",
            P_Sel_All_Host_Handler: "#select-all-hosts-groups-handler",
            P_Host_Title: ".ot-host-name",
            P_Leg_Select_All: ".ot-sel-all-hdr",
            P_Leg_Header: ".ot-li-hdr",
            P_Acc_Header: ".ot-acc-hdr",
            P_Cnsnt_Header: ".ot-consent-hdr",
            P_Tgl_Cntr: ".ot-tgl-cntr",
            P_CBx_Cntr: ".ot-chkbox",
            P_Sel_All_Host_El: "ot-selall-hostcntr",
            P_Sel_All_Vendor_Consent_El: "ot-selall-vencntr",
            P_Sel_All_Vendor_Leg_El: "ot-selall-licntr",
            P_c_Name: "ot-c-name",
            P_c_Host: "ot-c-host",
            P_c_Duration: "ot-c-duration",
            P_c_Type: "ot-c-type",
            P_c_Category: "ot-c-category",
            P_c_Desc: "ot-c-description",
            P_Host_View_Cookies: ".ot-host-expand",
            P_Host_Opt: ".ot-host-opt",
            P_Host_Info: ".ot-host-info",
            P_Arrw_Cntr: ".ot-arw-cntr",
            P_Acc_Txt: ".ot-acc-txt",
            P_Vendor_CheckBx: "ot-ven-chkbox",
            P_Vendor_LegCheckBx: "ot-ven-leg-chkbox",
            P_Host_UI: "ot-hosts-ui",
            P_Host_Cnt: "ot-host-cnt",
            P_Host_Bx: "ot-host-box",
            P_Ven_Dets: ".ot-ven-dets",
            P_Ven_Disc: ".ot-ven-disc",
            P_Gven_List: "#ot-gn-venlst",
            P_Close_Btn: ".ot-close-icon",
            P_Ven_Lst_Cntr: ".ot-vlst-cntr",
            P_Host_Lst_cntr: ".ot-hlst-cntr",
            P_Sub_Grp_Cntr: ".ot-subgrp-cntr",
            P_Subgrp_Desc: ".ot-subgrp-desc",
            P_Subgp_ul: ".ot-subgrps",
            P_Subgrp_li: ".ot-subgrp",
            P_Subgrp_Tgl_Cntr: ".ot-subgrp-tgl",
            P_Grp_Container: ".ot-grps-cntr",
            P_Privacy_Txt: "#ot-pvcy-txt",
            P_Privacy_Hdr: "#ot-pvcy-hdr",
            P_Active_Menu: "ot-active-menu",
            P_Desc_Container: ".ot-desc-cntr",
            P_Tab_Grp_Hdr: "ot-grp-hdr1",
            P_Search_Cntr: "#ot-search-cntr",
            P_Clr_Fltr_Txt: "#clear-filters-handler",
            P_Acc_Grp_Desc: ".ot-acc-grpdesc",
            P_Acc_Container: ".ot-acc-grpcntr",
            P_Line_Through: "line-through",
            P_Vendor_Search_Input: "#vendor-search-handler"
        },
        qt = {
            P_Grp_Container: ".groups-container",
            P_Content: "#ot-content",
            P_Category_Header: ".category-header",
            P_Desc_Container: ".description-container",
            P_Label_Txt: ".label-text",
            P_Acc_Grp_Desc: ".ot-accordion-group-pc-container",
            P_Leg_Int_Hdr: ".leg-int-header",
            P_Not_Always_Active: "p:not(.ot-always-active)",
            P_Category_Grp: ".category-group",
            P_Category_Item: ".category-item",
            P_Sub_Grp_Cntr: ".cookie-subgroups-container",
            P_Acc_Container: ".ot-accordion-pc-container",
            P_Close_Btn: ".pc-close-button",
            P_Logo: ".pc-logo",
            P_Title: "#pc-title",
            P_Title_Mobile: "#pc-title-mobile",
            P_Privacy_Txt: "#privacy-text",
            P_Privacy_Hdr: "#pc-privacy-header",
            P_Policy_Txt: "#pc-policy-text",
            P_Manage_Cookies_Txt: "#manage-cookies-text",
            P_Vendor_Title: "#vendors-list-title",
            P_Vendor_Title_Elm: "#vendors-list-title",
            P_Vendor_List: "#vendors-list",
            P_Vendor_Content: "#vendor-list-content",
            P_Vendor_Container: "#vendors-list-container",
            P_Ven_Bx: "vendor-box",
            P_Ven_Name: ".vendor-title",
            P_Ven_Link: ".vendor-privacy-notice",
            P_Ven_Leg_Claim: ".vendor-legclaim-link",
            P_Ven_Ctgl: "ot-vendor-consent-tgl",
            P_Ven_Ltgl: "ot-leg-int-tgl",
            P_Ven_Ltgl_Only: "ot-leg-int-tgl-only",
            P_Ven_Opts: ".vendor-options",
            P_Triangle: "#ot-triangle",
            P_Fltr_Modal: "#ot-filter-modal",
            P_Fltr_Options: ".ot-group-options",
            P_Fltr_Option: ".ot-group-option",
            P_Select_Cntr: "#select-all-container",
            P_Host_Cntr: "#hosts-list-container",
            P_Host_Hdr: ".host-info",
            P_Host_Desc: ".host-description",
            P_Host_Opt: ".host-option-group",
            P_Host_Info: ".vendor-host",
            P_Ven_Dets: ".vendor-purpose-groups",
            P_Ven_Disc: ".ot-ven-disc",
            P_Gven_List: "#ot-gn-venlst",
            P_Arrw_Cntr: ".ot-arrow-container",
            P_Li_Hdr: ".leg-int-header",
            P_Li_Title: ".leg-int-title",
            P_Acc_Txt: ".accordion-text",
            P_Tgl_Cntr: ".ot-toggle-group",
            P_CBx_Cntr: ".ot-chkbox-container",
            P_Host_Title: ".host-title",
            P_Leg_Select_All: ".leg-int-sel-all-hdr",
            P_Leg_Header: ".leg-int-hdr",
            P_Cnsnt_Header: ".consent-hdr",
            P_Acc_Header: ".accordion-header",
            P_Sel_All_Vendor_Consent_Handler: "#select-all-vendor-leg-handler",
            P_Sel_All_Vendor_Leg_Handler: "#select-all-vendor-groups-handler",
            P_Sel_All_Host_Handler: "#select-all-hosts-groups-handler",
            P_Sel_All_Host_El: "select-all-hosts-input-container",
            P_Sel_All_Vendor_Consent_El: "select-all-vendors-input-container",
            P_Sel_All_Vendor_Leg_El: "select-all-vendors-leg-input-container",
            P_c_Name: "cookie-name-container",
            P_c_Host: "cookie-host-container",
            P_c_Duration: "cookie-duration-container",
            P_c_Type: "cookie-type-container",
            P_c_Category: "cookie-category-container",
            P_c_Desc: "cookie-description-container",
            P_Host_View_Cookies: ".host-view-cookies",
            P_Vendor_CheckBx: "vendor-chkbox",
            P_Vendor_LegCheckBx: "vendor-leg-chkbox",
            P_Host_UI: "hosts-list",
            P_Host_Cnt: "host-list-content",
            P_Host_Bx: "host-box",
            P_Ven_Lst_Cntr: ".category-vendors-list-container",
            P_Host_Lst_cntr: ".category-host-list-container",
            P_Subgrp_Desc: ".cookie-subgroups-description-legal",
            P_Subgp_ul: ".cookie-subgroups",
            P_Subgrp_li: ".cookie-subgroup",
            P_Subgrp_Tgl_Cntr: ".cookie-subgroup-toggle",
            P_Active_Menu: "active-group",
            P_Tab_Grp_Hdr: "group-toggle",
            P_Search_Cntr: "#search-container",
            P_Clr_Fltr_Txt: "#clear-filters-handler p",
            P_Vendor_Search_Input: "#vendor-search-handler"
        },
        jt = {
            GroupTypes: {
                Cookie: "COOKIE",
                Bundle: "BRANCH",
                Ft: "IAB2_FEATURE",
                Pur: "IAB2_PURPOSE",
                Spl_Ft: "IAB2_SPL_FEATURE",
                Spl_Pur: "IAB2_SPL_PURPOSE",
                Stack: "IAB2_STACK"
            },
            IdPatterns: {
                Pur: "IABV2_",
                Ft: "IFEV2_",
                Spl_Pur: "ISPV2_",
                Spl_Ft: "ISFV2_"
            }
        },
        Kt = {
            GroupTypes: {
                Cookie: "COOKIE",
                Bundle: "BRANCH",
                Ft: "IAB2V2_FEATURE",
                Pur: "IAB2V2_PURPOSE",
                Spl_Ft: "IAB2V2_SPL_FEATURE",
                Spl_Pur: "IAB2V2_SPL_PURPOSE",
                Stack: "IAB2V2_STACK"
            },
            IdPatterns: {
                Pur: "IAB2V2_",
                Ft: "IFE2V2_",
                Spl_Pur: "ISP2V2_",
                Spl_Ft: "ISF2V2_"
            }
        };
    Wt.prototype.getDataLanguageCulture = function() {
        var e = h.getStubAttr(ze) || k.moduleInitializer.DataLanguage;
        return e ? this.checkAndTansformLangCodeWithUnderdscore(e.toLowerCase()) : this.detectDocumentOrBrowserLanguage().toLowerCase()
    }, Wt.prototype.checkAndTansformLangCodeWithUnderdscore = function(e) {
        return e.replace(/\_/, "-")
    }, Wt.prototype.detectDocumentOrBrowserLanguage = function() {
        var e, t = "";
        if (D.langSwitcherPldr) {
            var o = v.convertKeyValueLowerCase(D.langSwitcherPldr),
                n = this.getUserLanguage().toLowerCase();
            if (!(t = o[n] || o[n + "-" + n] || (o.default === n || o.default === (null == (e = n) ? void 0 : e.split("-")[0]) ? o.default : null) || o[null == (e = n) ? void 0 : e.split("-")[0]]))
                for (var r = Object.keys(o), i = -1 === n.indexOf("-") ? n : n.substring(0, n.indexOf("-")), s = 0; s < r.length; s += 1) {
                    var a = r[s];
                    if ((-1 === a.indexOf("-") ? a : a.substring(0, a.indexOf("-"))) === i) {
                        t = o[a];
                        break
                    }
                }
            t = t || o.default
        }
        return t
    }, Wt.prototype.getUserLanguage = function() {
        return D.useDocumentLanguage ? this.checkAndTansformLangCodeWithUnderdscore(document.documentElement.lang) : navigator.languages && navigator.languages.length ? navigator.languages[0] : navigator.language || navigator.userLanguage
    }, Wt.prototype.isValidLanguage = function(e, t) {
        var o = v.convertKeyValueLowerCase(D.langSwitcherPldr);
        return !(!o || !o[t] && !o[t + "-" + t] && o.default !== t)
    }, Wt.prototype.getLangJsonUrl = function(e) {
        void 0 === e && (e = null);
        var t, o = D.getRegionRule();
        if (e) {
            if (e = e.toLowerCase(), !this.isValidLanguage(o, e)) return null
        } else e = this.getDataLanguageCulture();
        return p.lang = e, p.consentLanguage = -1 === e.indexOf("-") ? e : e.substring(0, e.indexOf("-")), t = D.canUseConditionalLogic ? D.bannerDataParentURL + "/" + o.Id + "/" + D.Condition.Id + "/" + e : D.bannerDataParentURL + "/" + o.Id + "/" + e, t = D.multiVariantTestingEnabled ? D.bannerDataParentURL + "/" + o.Id + "/variants/" + D.selectedVariant.Id + "/" + e : t
    }, Wt.prototype.populateLangSwitcherPlhdr = function() {
        var e, t, o, n = D.getRegionRule();
        n && (e = n.Variants, D.multiVariantTestingEnabled && e ? (o = void 0, (t = I.getCookie(P.SELECTED_VARIANT)) && (o = e[v.findIndex(e, function(e) {
            return e.Id === t
        })]), t && o || (o = e[Math.floor(Math.random() * e.length)]), D.langSwitcherPldr = o.LanguageSwitcherPlaceholder, D.selectedVariant = o) : D.canUseConditionalLogic ? D.langSwitcherPldr = D.Condition.LanguageSwitcherPlaceholder : D.langSwitcherPldr = n.LanguageSwitcherPlaceholder)
    };
    var zt, t = Wt;

    function Wt() {}
    Xt.prototype.getLangJson = function(e) {
        var t;
        return void 0 === e && (e = null), D.previewMode ? (t = JSON.parse(window.sessionStorage.getItem("otPreviewData")), Promise.resolve(t.langJson)) : (t = zt.getLangJsonUrl(e)) ? Yt.otFetch(t + ".json", !1, !1, !0) : Promise.resolve(null)
    }, Xt.prototype.getPersistentCookieSvg = function(e) {
        e = e || N.cookiePersistentLogo;
        return e ? Yt.otFetch(e, !0) : Promise.resolve(null)
    }, Xt.prototype.getSpriteSvg = function(e) {
        return e ? Yt.otFetch(e, !0) : Promise.resolve(null)
    }, Xt.prototype.fetchGvlObj = function() {
        var e = k.moduleInitializer.IabV2Data.globalVendorListUrl;
        return "IAB2V2" === D.getRegionRuleType() && (e = k.moduleInitializer.Iab2V2Data.globalVendorListUrl), this.otFetch(e)
    }, Xt.prototype.fetchGoogleVendors = function() {
        var e = h.updateCorrectIABUrl(k.moduleInitializer.GoogleData.googleVendorListUrl);
        return h.checkMobileOfflineRequest(h.getBannerVersionUrl()) ? h.otFetchOfflineFile(v.getRelativeURL(e, !0)) : (D.mobileOnlineURL.push(e), this.otFetch(e))
    }, Xt.prototype.getStorageDisclosure = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                return [2, this.otFetch(t, !1, !0)]
            })
        })
    }, Xt.prototype.loadCMP = function() {
        var o = this;
        return new Promise(function(e) {
            var t = o.checkIfRequiresPollyfill() ? "otTCF-ie" : "otTCF";
            h.jsonp(h.getBannerVersionUrl() + "/" + t + ".js", e, e)
        })
    }, Xt.prototype.loadGPP = function() {
        return new Promise(function(e) {
            h.jsonp(h.getBannerVersionUrl() + "/otGPP.js", e, e)
        })
    }, Xt.prototype.loadConfirmDialog = function() {
        var e = document.createElement("link");
        return e.rel = "stylesheet", e.href = h.getBannerSDKAssestsUrl() + "/otConfirmDialog" + (N.useRTL ? "Rtl" : "") + ".css", k.moduleInitializer.CookieV2CSPEnabled && p.nonce && e.setAttribute("nonce", p.nonce), document.head.appendChild(e), new Promise(function(e) {
            h.jsonp(h.getBannerVersionUrl() + "/otConfirmDialog.js", e, e)
        })
    }, Xt.prototype.getCSBtnContent = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = N.useRTL ? Se.RTL : Se.LTR, p.csBtnAsset[t]) ? [3, 2] : (o = h.getBannerSDKAssestsUrl() + "/" + (N.useRTL ? Ye : We), n = p.csBtnAsset, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, p.csBtnAsset[t]]
                }
            })
        })
    }, Xt.prototype.getPcContent = function(i) {
        return void 0 === i && (i = !1), F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = N.useRTL ? Se.RTL : Se.LTR, p.pcAsset[t] && !i) ? [3, 2] : (o = h.getBannerSDKAssestsUrl(), N.PCTemplateUpgrade && (o += "/v2"), o = o + "/" + D.pcName + (N.useRTL ? "Rtl" : "") + ".json", n = p.pcAsset, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, p.pcAsset[t]]
                }
            })
        })
    }, Xt.prototype.getBannerContent = function(s, a) {
        return void 0 === s && (s = !1), void 0 === a && (a = null), F(this, void 0, void 0, function() {
            var t, o, n, r, i;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (t = N.useRTL ? Se.RTL : Se.LTR, o = a || zt.getDataLanguageCulture(), p.bAsset[t] && !s) return [3, 2];
                        if (i = D.getRegionRule(), n = void 0, k.fp.CookieV2SSR) {
                            if (D.previewMode) return r = JSON.parse(window.sessionStorage.getItem("otPreviewData")), [2, Promise.resolve(r.bLayout)];
                            n = D.bannerDataParentURL + "/" + i.Id, D.canUseConditionalLogic && (n += "/" + D.Condition.Id), n += "/bLayout-" + o + ".json"
                        } else n = h.getBannerSDKAssestsUrl() + ("/" + D.bannerName + (N.useRTL ? "Rtl" : "")) + ".json";
                        return r = p.bAsset, i = t, [4, this.otFetch(n)];
                    case 1:
                        r[i] = e.sent(), e.label = 2;
                    case 2:
                        return [2, p.bAsset[t]]
                }
            })
        })
    }, Xt.prototype.getCommonStyles = function(i) {
        return void 0 === i && (i = !1), F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = N.useRTL ? Se.RTL : Se.LTR, p.cStyles[t] && !i) ? [3, 2] : (o = h.getBannerSDKAssestsUrl() + "/otCommonStyles" + (N.useRTL ? "Rtl" : "") + ".css", n = p.cStyles, r = t, [4, this.otFetch(o, !0)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, p.cStyles[t]]
                }
            })
        })
    }, Xt.prototype.getSyncNtfyContent = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = N.useRTL ? Se.RTL : Se.LTR, p.syncNtfyContent[t]) ? [3, 2] : (o = h.getBannerSDKAssestsUrl() + "/otSyncNotification" + (N.useRTL ? "Rtl" : "") + ".json", n = p.syncNtfyContent, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, p.syncNtfyContent[t]]
                }
            })
        })
    }, Xt.prototype.getConsentProfile = function(e, t) {
        var o = this,
            n = {
                Identifier: e,
                TenantId: p.tenantId,
                Authorization: t
            };
        return new Promise(function(e) {
            o.getJSON(p.consentApi, n, e, e)
        })
    }, Xt.prototype.checkIfRequiresPollyfill = function() {
        var e = window.navigator.userAgent;
        return 0 < e.indexOf("MSIE ") || 0 < e.indexOf("Trident/") || "undefined" == typeof Set
    }, Xt.prototype.otFetch = function(r, i, s, a) {
        return void 0 === i && (i = !1), void 0 === s && (s = !1), void 0 === a && (a = !1), F(this, void 0, void 0, function() {
            var t, o, n = this;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return h.checkMobileOfflineRequest(r) ? [4, h.otFetchOfflineFile(r)] : [3, 2];
                    case 1:
                        return [2, e.sent()];
                    case 2:
                        return e.trys.push([2, 9, , 10]), D.mobileOnlineURL.push(r), "undefined" != typeof fetch ? [3, 3] : [2, new Promise(function(e) {
                            n.getJSON(r, null, e, e, i)
                        })];
                    case 3:
                        return [4, fetch(r)];
                    case 4:
                        return (t = e.sent(), s && t.headers.get("Access-Control-Allow-Credentials")) ? [2, Promise.resolve()] : (a && t.headers.get("X-OneTrust-IsBot") && (p.isBotHeader = "true" === t.headers.get("X-OneTrust-IsBot").toLowerCase()), i ? [4, t.text()] : [3, 6]);
                    case 5:
                        return [2, e.sent()];
                    case 6:
                        return [4, t.json()];
                    case 7:
                        return [2, e.sent()];
                    case 8:
                        return [3, 10];
                    case 9:
                        return o = e.sent(), console.log("Error in fetch URL : " + r + " Exception :" + o), [3, 10];
                    case 10:
                        return [2]
                }
            })
        })
    }, Xt.prototype.getJSON = function(e, t, o, n, r) {
        void 0 === t && (t = null), void 0 === r && (r = !1);
        var i = new XMLHttpRequest;
        if (i.open("GET", e, !0), i.withCredentials = !1, t)
            for (var s in t) i.setRequestHeader(s, t[s]);
        i.onload = function() {
            var e;
            200 <= this.status && this.status < 400 && this.responseText ? (e = void 0, e = r ? this.responseText : JSON.parse(this.responseText), o(e)) : n({
                message: "Error Loading Data",
                statusCode: this.status
            })
        }, i.onerror = function(e) {
            n(e)
        }, i.send()
    }, Xt.prototype.getGeolocation = function(t) {
        return F(this, void 0, void 0, function() {
            var o, n = this;
            return M(this, function(e) {
                return o = this.getGeolocationURL(t), [2, new Promise(function(e, t) {
                    n.getJSON(o, {
                        accept: "application/json"
                    }, e, t)
                })]
            })
        })
    }, Xt.prototype.getGeolocationURL = function(e) {
        var t = p.storageBaseURL + "/scripttemplates/" + e.Version;
        return new RegExp("^file://", "i").test(t) && e.MobileSDK ? "./" + e.GeolocationUrl.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/") + ".js" : e.GeolocationUrl
    };
    var Yt, Jt = Xt;

    function Xt() {}
    var Qt, Zt = "groups",
        $t = "hosts",
        eo = "genVendors",
        to = "vs",
        oo = (no.prototype.getAllowAllButton = function() {
            return m("#onetrust-pc-sdk #accept-recommended-btn-handler")
        }, no.prototype.getSelectedVendors = function() {
            return m("#onetrust-pc-sdk " + T.P_Tgl_Cntr + " .ot-checkbox input:checked")
        }, no);

    function no() {}

    function ro(e, t) {
        var e = e || [],
            t = t || [],
            o = new Set(e);
        return t.some(function(e) {
            return o.has(e)
        }) ? io(e, t.filter(function(e) {
            return !o.has(e)
        })) : io(e, t)
    }

    function io(e, t) {
        e = 0 < e.length ? e.join(".") : "", t = 0 < t.length ? t.join(".") : "";
        return "2~" + e + "~" + (t ? "dv." + t : "dv")
    }

    function so(e) {
        var t, o;
        if ((e => {
                if (e && "string" == typeof e && e.startsWith("2~") && e.includes("~dv")) {
                    e = e.split("~");
                    if (3 === e.length) {
                        var t = e[0],
                            o = e[1],
                            e = e[2];
                        if ("2" === t)
                            if (e.startsWith("dv")) return (t = function(e) {
                                return "" === e || e.split(".").every(function(e) {
                                    return /^\d+$/.test(e) && 0 < parseInt(e, 10)
                                })
                            })(o) && ("dv" === e || e.startsWith("dv.") && !!t(e.substring(3)))
                    }
                }
            })(e)) return o = (t = e.split("~"))[1], t = t[2], o = "" === o ? [] : o.split(".").map(function(e) {
            return parseInt(e, 10)
        }), "dv" === t ? {
            consented: o,
            disclosed: []
        } : {
            consented: o,
            disclosed: "" === (o = t.substring(3)) ? [] : o.split(".").map(function(e) {
                return parseInt(e, 10)
            })
        };
        throw new Error("[AC v2] Invalid AC v2 string format: " + e)
    }
    co.prototype.isIabCookieValid = function() {
        var e = null;
        return null !== (e = D.isIab2orv2Template ? I.getCookie("eupubconsent-v2") : e)
    }, co.prototype.iabTypeIsChanged = function() {
        this.isIabCookieValid() || (I.removeAlertBox(), I.removeIab1())
    }, co.prototype.initializeIABModule = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return N.IsIabEnabled ? (k.moduleInitializer.otIABModuleData = window.otIabModule, B.setIabData(), [4, B.populateVendorListTCF()]) : [3, 2];
                    case 1:
                        return e.sent(), B.isIABCrossConsentEnabled() || this.iabTypeIsChanged(), B.populateIABCookies(), N.UseGoogleVendors && (N.NewVendorsInactiveEnabled && this.removeATPListVendors(), this.removeInActiveAddtlVendors()), [3, 3];
                    case 2:
                        I.removeIab1(), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, co.prototype.removeATPListVendors = function() {
        var e, t, o = k.moduleInitializer.GoogleData.vendorListVersion;
        for (t in w.addtlVendorsList)(null == (e = w.addtlVendorsList[t]) ? void 0 : e.gvlVersion) > o && (w.deletedGoogleVendors[t] = w.addtlVendorsList[t], delete w.addtlVendorsList[t])
    }, co.prototype.removeInActiveAddtlVendors = function() {
        var e, t = N.OverridenGoogleVendors;
        for (e in t) t[e].active || delete w.addtlVendorsList[e]
    }, co.prototype.getIABConsentData = function() {
        var e = w.oneTrustIABConsent,
            t = B.iabStringSDK().tcString(),
            o = (w.tcModel.unsetAllPurposeConsents(), w.tcModel.unsetAllVendorConsents(), w.tcModel.unsetAllVendorLegitimateInterests(), w.tcModel.unsetAllSpecialFeatureOptins(), w.tcModel.unsetAllPurposeLegitimateInterests(), w.tcModel.publisherConsents.empty(), w.tcModel.publisherLegitimateInterests.empty(), w.tcModel.purposeConsents.set(v.getActiveIdArray(e.purpose)), w.tcModel.publisherConsents.set(v.getActiveIdArray(e.purpose)), D.legIntSettings.PAllowLI ? v.getActiveIdArray(e.legimateInterest) : []),
            o = (w.tcModel.purposeLegitimateInterests.set(o), w.tcModel.publisherLegitimateInterests.set(o), w.tcModel.vendorConsents.set(v.getActiveIdArray(v.distinctArray(e.vendors))), D.legIntSettings.PAllowLI && this.shouldSetVendorLegitimateInterest(e) && (e.legIntVendors = []), w.tcModel.vendorLegitimateInterests.set(v.getActiveIdArray(v.distinctArray(e.legIntVendors))), w.tcModel.specialFeatureOptins.set(v.getActiveIdArray(e.specialFeatures)), new Date),
            e = new Date(Date.UTC(o.getUTCFullYear(), o.getUTCMonth(), o.getUTCDate())),
            o = (w.tcModel.lastUpdated = e, w.tcModel.created = e, t.encode(w.tcModel));
        return w.cmpApi.update(o, !1), o
    }, co.prototype.shouldSetVendorLegitimateInterest = function(e) {
        return !w.anyVendorHasOnlySplPur && !v.getActiveIdArray(e.legimateInterest)
    }, co.prototype.decodeTCString = function(e) {
        return B.iabStringSDK().tcString().decode(e)
    }, co.prototype.getVendorConsentsRequestV2 = function(e) {
        var o;
        return window.__tcfapi("getInAppTCData", 2, function(e, t) {
            o = [e, t]
        }), e.apply(this, o)
    }, co.prototype.getPingRequestForTcf = function(e) {
        var t;
        return window.__tcfapi("ping", 2, function(e) {
            t = [e]
        }), e.apply(this, t)
    }, co.prototype.populateVendorAndPurposeFromCookieData = function() {
        var e, n = w.oneTrustIABConsent,
            t = ao.decodeTCString(n.IABCookieValue),
            o = !t.vendorsDisclosed || 0 === t.vendorsDisclosed.size,
            r = b.GroupTypes,
            i = {},
            s = {},
            a = (D.iabGrps.forEach(function(e) {
                e.Type === r.Pur ? i[D.iabGrpIdMap[e.CustomGroupId]] = e : e.Type === r.Spl_Ft && (s[D.iabGrpIdMap[e.CustomGroupId]] = e)
            }), []),
            l = (this.syncVendorConsent(t), a = [], t.vendorLegitimateInterests.forEach(function(e, t) {
                var o = e;
                w.vendorsSetting[t] && w.vendorsSetting[t].legInt || !e || (a.push(t), o = !1), n.legIntVendors.push(t + ":" + o)
            }), t.vendorLegitimateInterests.unset(a), a = [], t.purposeConsents.forEach(function(e, o) {
                var t = e,
                    e = (!(i[o] && i[o].HasConsentOptOut) && e && (a.push(o), t = !1), v.findIndex(n.purpose, function(e, t) {
                        return e.split(":")[0] === o.toString()
                    })); - 1 === e ? n.purpose.push(o + ":" + t) : n.purpose[e] = o + ":" + t
            }), t.purposeConsents.unset(a), t.publisherConsents.unset(a), a = [], t.specialFeatureOptins.forEach(function(e, o) {
                var t = e,
                    e = (!(s[o] && s[o].HasConsentOptOut) && e && (a.push(o), t = !1), v.findIndex(n.specialFeatures, function(e, t) {
                        return e.split(":")[0] === o.toString()
                    })); - 1 === e ? n.specialFeatures.push(o + ":" + t) : n.specialFeatures[e] = o + ":" + t
            }), t.specialFeatureOptins.unset(a), this.syncPurAndPubLegInt(t, i), this.syncBundleAndStack(), t.gvl = w.tcModel.gvl, t.gvl && t.gvl.vendors);
        l && t.vendorsDisclosed && "function" == typeof t.vendorsDisclosed.set && (e = Object.keys(l).map(Number)).length && t.vendorsDisclosed.set(e), t.isServiceSpecific = !B.isIABCrossConsentEnabled(), w.tcModel = t, B.isAlertBoxClosedAndValid() ? o && l ? ((e = ao.decodeTCString(n.IABCookieValue)).gvl = w.tcModel.gvl, o = Object.keys(l).map(Number), e.vendorsDisclosed && "function" == typeof e.vendorsDisclosed.set && o.length && e.vendorsDisclosed.set(o), e.isServiceSpecific = t.isServiceSpecific, l = B.iabStringSDK().tcString().encode(e), n.IABCookieValue = l, w.cmpApi.update(l, !1)) : w.cmpApi.update(n.IABCookieValue, !1) : B.resetTCModel()
    }, co.prototype.syncVendorConsent = function(e) {
        var n = [],
            r = [];
        e.vendorConsents.forEach(function(e, t) {
            var o = e;
            w.vendorsSetting[t] && w.vendorsSetting[t].consent || !e || (n.push(t), o = !1), r.push(t + ":" + o)
        }), w.oneTrustIABConsent.vendors = r, e.vendorConsents.unset(n)
    }, co.prototype.syncPurAndPubLegInt = function(e, n) {
        var r = [],
            i = w.oneTrustIABConsent;
        e.purposeLegitimateInterests.forEach(function(e, o) {
            var t = e,
                e = (!(n[o] && n[o].HasLegIntOptOut && D.legIntSettings.PAllowLI) && e && (r.push(o), t = !1), v.findIndex(i.legimateInterest, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? i.legimateInterest.push(o + ":" + t) : i.legimateInterest[e] = o + ":" + t
        }), e.purposeLegitimateInterests.unset(r), e.publisherLegitimateInterests.unset(r)
    }, co.prototype.syncBundleAndStack = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, "groups"),
            n = (w.groupsConsent = v.strToArr(e), b.GroupTypes);
        N.Groups.forEach(function(t) {
            var e, o;
            t.Type !== n.Bundle && t.Type !== n.Stack || (o = h.isBundleOrStackActive(t), e = v.findIndex(w.groupsConsent, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            }), o = t.CustomGroupId + ":" + Number(o), -1 < e ? w.groupsConsent[e] = o : w.groupsConsent.push(o))
        }), I.writeCookieParam(P.OPTANON_CONSENT, "groups", w.groupsConsent.join(","))
    }, co.prototype.populateGoogleConsent = function() {
        if (N.UseGoogleVendors) {
            var t = I.getCookie(P.ADDITIONAL_CONSENT_STRING);
            if (t) {
                if (w.isAddtlConsent = !0, 2 === ((o = t) && "string" == typeof o ? o.startsWith("1~") ? 1 : o.startsWith("2~") && o.includes("~dv") ? 2 : null : null)) try {
                    var e = so(t).consented;
                    w.addtlVendors.vendorConsent = e.map(function(e) {
                        return e.toString()
                    })
                } catch (e) {
                    console.error("[AC v2] Failed to parse AC string, falling back to legacy parsing:", e), w.addtlVendors.vendorConsent = t.replace(w.addtlConsentVersion, "").split("~")[0].split(".")
                } else {
                    o = t.split("~"), e = 1 < o.length ? o[1] : o[0];
                    w.addtlVendors.vendorConsent = e.split(".").filter(function(e) {
                        return "" !== e
                    })
                }
                w.addtlVendors.vendorSelected = {}, w.addtlVendors.vendorConsent.forEach(function(e) {
                    w.addtlVendors.vendorSelected[e] = !0
                })
            }
        }
        var o
    }, co.prototype.isInitIABCookieData = function(e) {
        return "init" === e || B.needReconsent()
    }, co.prototype.updateFromGlobalConsent = function(e) {
        var t = w.oneTrustIABConsent;
        t.IABCookieValue = e, t.purpose = t.purpose || [], t.specialFeatures = t.specialFeatures || [], t.legIntVendors = [], t.legimateInterest = t.legimateInterest || [], t.vendors = [], ao.populateVendorAndPurposeFromCookieData(), I.setCookie(P.EU_PUB_CONSENT, "", -1)
    };
    var ao, lo = co;

    function co() {}
    Co.prototype.loadBanner = function() {
        k.moduleInitializer.ScriptDynamicLoadEnabled ? "complete" === document.readyState ? m(window).trigger("otloadbanner") : window.addEventListener("load", function(e) {
            m(window).trigger("otloadbanner")
        }) : "loading" !== document.readyState ? m(window).trigger("otloadbanner") : window.addEventListener("DOMContentLoaded", function(e) {
            m(window).trigger("otloadbanner")
        }), D.pubDomainData.IsBannerLoaded = !0
    }, Co.prototype.OnConsentChanged = function(e) {
        var t = e.toString();
        uo.consentChangedEventMap[t] || (uo.consentChangedEventMap[t] = !0, window.addEventListener("consent.onetrust", e))
    }, Co.prototype.triggerGoogleAnalyticsEvent = function(e, t, o, n) {
        var r = !1;
        k.moduleInitializer.GATrackToggle && ("AS" === k.moduleInitializer.GATrackAssignedCategory || "" === k.moduleInitializer.GATrackAssignedCategory || window.OnetrustActiveGroups.includes("," + k.moduleInitializer.GATrackAssignedCategory + ",")) && (r = !0), !D.ignoreGoogleAnlyticsCall && r && (void 0 !== window._gaq && window._gaq.push(["_trackEvent", e, t, o, n]), "function" == typeof window.ga && window.ga("send", "event", e, t, o, n), r = window[D.otDataLayer.name], !D.otDataLayer.ignore) && void 0 !== r && r && r.constructor === Array && ("function" == typeof window.gtag ? window.gtag("event", "trackOptanonEvent", {
            optanonCategory: e,
            optanonAction: t,
            optanonLabel: o,
            optanonValue: n
        }) : r.push({
            event: "trackOptanonEvent",
            optanonCategory: e,
            optanonAction: t,
            optanonLabel: o,
            optanonValue: n
        }))
    }, Co.prototype.setAlertBoxClosed = function(e) {
        var t = (new Date).toISOString(),
            e = (e ? I.setCookie(P.ALERT_BOX_CLOSED, t, N.ReconsentFrequencyDays) : I.setCookie(P.ALERT_BOX_CLOSED, t, 0), m(".onetrust-pc-dark-filter").el[0]);
        e && "none" !== getComputedStyle(e).getPropertyValue("display") && m(".onetrust-pc-dark-filter").fadeOut(400)
    }, Co.prototype.updateConsentFromCookie = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                return t ? (ao.isInitIABCookieData(t) || ao.updateFromGlobalConsent(t), "init" === t && (I.removeIab1(), B.isAlertBoxClosedAndValid() && B.resetTCModel(), I.removeAlertBox())) : (B.resetTCModel(), B.updateCrossConsentCookie(!1), B.setIABCookieData()), uo.assetPromise.then(function() {
                    uo.loadBanner()
                }), [2]
            })
        })
    };
    var uo, po = Co;

    function Co() {
        var t = this;
        this.consentChangedEventMap = {}, this.assetResolve = null, this.assetPromise = new Promise(function(e) {
            t.assetResolve = e
        })
    }
    yo.prototype.writeHstParam = function(e, t) {
        I.writeCookieParam(e, "hosts", v.arrToStr((t = void 0 === t ? null : t) || w.hostsConsent))
    }, yo.prototype.writeGenVenCookieParam = function(e) {
        var t = N.GeneralVendors,
            o = w.genVendorsConsent,
            n = "";
        t.forEach(function(e) {
            n += e.VendorCustomId + ":" + (o[e.VendorCustomId] ? "1" : "0") + ","
        }), I.writeCookieParam(e, "genVendors", n)
    }, yo.prototype.writeVSConsentCookieParam = function(e) {
        var o = "";
        w.vsConsent.forEach(function(e, t) {
            return o += t + ":" + (e ? "1" : "0") + ","
        }), o = o.slice(0, -1), I.writeCookieParam(e, to, o)
    }, yo.prototype.updateGroupsInCookie = function(e, t) {
        I.writeCookieParam(e, "groups", v.arrToStr((t = void 0 === t ? null : t) || w.groupsConsent))
    }, yo.prototype.writeGrpParam = function(e, t) {
        this.updateGroupsInCookie(e, t = void 0 === t ? null : t), N.IsIabEnabled && B.isAlertBoxClosedAndValid() && this.insertOrUpdateIabCookies()
    }, yo.prototype.insertOrUpdateIabCookies = function() {
        var e = w.oneTrustIABConsent;
        if (e.purpose && e.vendors) {
            w.isAddtlConsent = N.UseGoogleVendors, e.IABCookieValue = ao.getIABConsentData();
            var t = N.ReconsentFrequencyDays;
            if (B.isIABCrossConsentEnabled()) B.setIAB3rdPartyCookie(P.EU_CONSENT, e.IABCookieValue, t, !1);
            else {
                for (var o, n = I.getCookiesChunk(e.IABCookieValue, P.EU_PUB_CONSENT), r = 0, i = Object.keys(n); r < i.length; r++) {
                    var s = i[r];
                    I.setCookie(s, n[s], t)
                }
                N.UseGoogleVendors && (o = w.addtlVendors.vendorConsent.map(function(e) {
                    return parseInt(e, 10)
                }), e = Object.keys(w.addtlVendorsList || {}).map(function(e) {
                    return parseInt(e, 10)
                }).filter(function(e) {
                    return !o.includes(e)
                }), e = ro(o, e), I.setCookie(P.ADDITIONAL_CONSENT_STRING, e, t))
            }
        }
    };
    var go, ho = yo;

    function yo() {}
    So.prototype.isAlwaysActiveGroup = function(e) {
        var t;
        return !this.getGrpStatus(e) || (t = this.getGrpStatus(e).toLowerCase(), (t = e.Parent && t !== f.ALWAYS_ACTIVE ? this.getGrpStatus(this.getParentGroup(e.Parent)).toLowerCase() : t) === f.ALWAYS_ACTIVE)
    }, So.prototype.getGrpStatus = function(e) {
        return e && e.Status ? D.DNTEnabled && e.IsDntEnabled && e.Status.toLowerCase() !== f.ALWAYS_INACTIVE.toLowerCase() ? f.DNT : e.Status : ""
    }, So.prototype.getParentGroup = function(t) {
        var e;
        return t && 0 < (e = N.Groups.filter(function(e) {
            return e.OptanonGroupId === t
        })).length ? e[0] : null
    }, So.prototype.checkIfGroupHasConsent = function(t) {
        var e = p.groupsConsent,
            o = v.findIndex(e, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            });
        return -1 < o && "1" === e[o].split(":")[1]
    }, So.prototype.checkIsActiveByDefault = function(e) {
        var t;
        return !this.getGrpStatus(e) || (t = this.getGrpStatus(e).toLowerCase(), (t = e.Parent && t !== f.ALWAYS_ACTIVE ? this.getGrpStatus(this.getParentGroup(e.Parent)).toLowerCase() : t) === f.ALWAYS_ACTIVE) || t === f.INACTIVE_LANDING_PAGE || t === f.ACTIVE || t === f.DNT && !D.DNTEnabled
    }, So.prototype.getGroupById = function(e) {
        for (var t = null, o = 0, n = N.Groups; o < n.length; o++) {
            for (var r = n[o], i = 0, s = U(r.SubGroups, [r]); i < s.length; i++) {
                var a = s[i];
                if (a.CustomGroupId === e) {
                    t = a;
                    break
                }
            }
            if (t) break
        }
        return t
    }, So.prototype.isSoftOptInGrp = function(e) {
        return !!e && (e = e && !e.Parent ? e : L.getParentGroup(e.Parent), "inactive landingpage" === L.getGrpStatus(e).toLowerCase())
    }, So.prototype.isOptInGrp = function(e) {
        return !!e && "inactive" === L.getGrpStatus(e).toLowerCase()
    }, So.prototype.getParentByGrp = function(e) {
        return e.Parent ? this.getGroupById(e.Parent) : null
    }, So.prototype.getVSById = function(e) {
        return p.getVendorsInDomain().get(e)
    }, So.prototype.getGrpByVendorId = function(e) {
        var t = null;
        return t = p.getVendorsInDomain().has(e) ? p.getVendorsInDomain().get(e).groupRef : t
    };
    var L, fo = So;

    function So() {}
    To.prototype.initGenVendorConsent = function() {
        var e, t, n = this;
        N.GenVenOptOut ? (e = D.consentableGrps, (t = I.readCookieParam(P.OPTANON_CONSENT, "genVendors")) ? (w.genVendorsConsent = {}, t.split(",").forEach(function(e) {
            e && "1" === (e = e.split(":"))[1] && (w.genVendorsConsent[e[0]] = !0)
        })) : (w.genVendorsConsent = {}, e.forEach(function(e) {
            var o = w.syncRequired ? L.checkIfGroupHasConsent(e) : L.checkIsActiveByDefault(e);
            e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                var t = n.isGenVenPartOfAlwaysActiveGroup(e);
                w.genVendorsConsent[e] = t || o
            })
        }))) : (w.genVendorsConsent = {}, go.writeGenVenCookieParam(P.OPTANON_CONSENT))
    }, To.prototype.populateGenVendorLists = function() {
        D.consentableGrps.forEach(function(e) {
            e.GeneralVendorsIds && (L.isAlwaysActiveGroup(e) ? e.GeneralVendorsIds.forEach(function(e) {
                w.alwaysActiveGenVendors.push(e)
            }) : L.isOptInGrp(e) ? e.GeneralVendorsIds.forEach(function(e) {
                w.optInGenVendors.push(e)
            }) : L.isSoftOptInGrp(e) && e.GeneralVendorsIds.forEach(function(e) {
                w.optInGenVendors.includes(e) || w.softOptInGenVendors.push(e)
            }))
        })
    }, To.prototype.updateGenVendorStatus = function(e, t) {
        w.genVendorsConsent[e] = t || this.isGenVenPartOfAlwaysActiveGroup(e)
    }, To.prototype.isGenVenPartOfAlwaysActiveGroup = function(e) {
        return w.alwaysActiveGenVendors.includes(e)
    };
    var mo, vo = To;

    function To() {}
    ko.prototype.isLandingPage = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, "landingPath"),
            t = this.sanitizeLandingPath(location.href);
        return !e || e === t
    }, ko.prototype.sanitizeLandingPath = function(e) {
        try {
            var t, o;
            return e === A.NOT_LANDING_PAGE ? A.NOT_LANDING_PAGE : "string" == typeof e && e.length ? ((t = new URL(e, window.location.href)).origin !== window.location.origin && (t.href = window.location.href), (o = "" + t.origin + t.pathname).length > this.MAX_LEN ? o.slice(0, this.MAX_LEN) : o) : ""
        } catch (e) {
            return ""
        }
    }, ko.prototype.setLandingPathParam = function(e) {
        e = this.sanitizeLandingPath(e);
        e && I.writeCookieParam(P.OPTANON_CONSENT, "landingPath", e)
    };
    var Ao, Po = ko;

    function ko() {
        this.MAX_LEN = 1024
    }
    Do.prototype.synchroniseCookieGroupData = function(e) {
        var r = this,
            t = I.readCookieParam(P.OPTANON_CONSENT, "groups"),
            i = v.strToArr(t),
            s = v.strToArr(t.replace(/:0|:1/g, "")),
            t = B.needReconsent(),
            a = !1,
            l = !1,
            c = b.GroupTypes;
        e.forEach(function(e) {
            var t, o, n = e.CustomGroupId;
            e.Type !== c.Bundle && e.Type !== c.Stack && (-1 === v.indexOf(s, n) ? (a = !0, t = L.checkIsActiveByDefault(e), l = !0, i.push(n + (t ? ":1" : ":0"))) : l = r.updateImpliedConsentGroup(e, i, n, l), D.DNTEnabled && e.IsDntEnabled && D.dntValueChanged && (null == (t = e.Status) ? void 0 : t.toLowerCase()) !== f.ALWAYS_INACTIVE && (null == (t = e.Status) ? void 0 : t.toLowerCase()) !== f.ALWAYS_ACTIVE && -1 < i.indexOf(n + ":1") && (o = i.indexOf(n + ":1"), l = !0, w.dntConsentTxn = !0, i[o] = n + ":0", e.isDeniedByDNT = !0), D.gpcEnabled && e.IsGpcEnabled && D.gpcValueChanged && -1 < (o = i.indexOf(n + ":1"))) && (l = !0, w.gpcConsentTxn = !0, i[o] = n + ":0", e.isDeniedByGPC = !0)
        }), l = this.updateConsentForBundleGrps(e, i, s, l, t), (l = this.removeRedundantGrpsFromCookie(i, t, l)) && (w.fireOnetrustGrp = !0, go.updateGroupsInCookie(P.OPTANON_CONSENT, i), w.syncRequired) && a && I.removeAlertBox()
    }, Do.prototype.updateImpliedConsentGroup = function(e, t, o, n) {
        return e.Status !== f.INACTIVE_LANDING_PAGE || B.isAlertBoxClosedAndValid() || Ao.isLandingPage() || 0 <= (e = t.indexOf(o + ":0")) && (n = !0, t[e] = o + ":1"), n
    }, Do.prototype.removeRedundantGrpsFromCookie = function(e, o, t) {
        for (var n = e.length, r = t; n--;)(() => {
            var t = e[n].replace(/:0|:1/g, "");
            N.Groups.some(function(e) {
                return (!o || e.Type !== b.GroupTypes.Stack) && (e.CustomGroupId === t || e.SubGroups.some(function(e) {
                    return e.CustomGroupId === t
                }))
            }) || (r = !0, e.splice(n, 1))
        })();
        return r
    }, Do.prototype.updateConsentForBundleGrps = function(e, r, i, t, s) {
        var a = this,
            l = t,
            c = b.GroupTypes;
        return e.forEach(function(e) {
            var t, o = e.Type === c.Bundle || e.Type === c.Stack,
                n = e.CustomGroupId;
            o && (-1 === v.indexOf(i, n) ? (o = h.isBundleOrStackActive(e, r), l = !0, r.push(n + (o ? ":1" : ":0"))) : s && "false" === B.getIABCrossConsentflagData() || D.gpcEnabled && D.gpcValueChanged || w.syncRequired ? (o = h.isBundleOrStackActive(e, r), -1 < (t = r.indexOf(n + ":" + (o ? "0" : "1"))) && (l = !0, r[t] = n + (o ? ":1" : ":0"))) : l = a.updateImpliedConsentGroup(e, r, n, l))
        }), l
    }, Do.prototype.groupHasConsent = function(t) {
        var e = v.strToArr(I.readCookieParam(P.OPTANON_CONSENT, "groups")),
            o = v.findIndex(e, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            });
        return -1 < o && "1" === e[o].split(":")[1]
    }, Do.prototype.synchroniseCookieHostData = function() {
        for (var n = this, e = I.readCookieParam(P.OPTANON_CONSENT, "hosts"), r = v.strToArr(e), i = v.strToArr(e.replace(/:0|:1/g, "")), s = !1, o = (N.Groups.forEach(function(e) {
                U(e.SubGroups, [e]).forEach(function(o) {
                    o.Hosts.length && o.Hosts.forEach(function(e) {
                        var t; - 1 === v.indexOf(i, e.HostId) && (s = !0, t = w.syncRequired ? n.groupHasConsent(o) : L.checkIsActiveByDefault(o), r.push(e.HostId + (t ? ":1" : ":0")))
                    })
                })
            }), r.length); o--;)(() => {
            var t = r[o].replace(/:0|:1/g, "");
            N.Groups.some(function(e) {
                return U(e.SubGroups, [e]).some(function(e) {
                    return e.Hosts.some(function(e) {
                        return e.HostId === t
                    })
                })
            }) || (s = !0, r.splice(o, 1))
        })();
        s && (w.fireOnetrustGrp = !0, go.writeHstParam(P.OPTANON_CONSENT, r))
    }, Do.prototype.toggleGroupHosts = function(e, t) {
        var o = this;
        e.Hosts.forEach(function(e) {
            o.updateHostStatus(e, t)
        })
    }, Do.prototype.toggleGroupGenVendors = function(e, t) {
        e.GeneralVendorsIds.forEach(function(e) {
            mo.updateGenVendorStatus(e, t)
        })
    }, Do.prototype.updateHostStatus = function(t, e) {
        var o = v.findIndex(w.hostsConsent, function(e) {
            return !t.isActive && t.HostId === e.replace(/:0|:1/g, "")
        }); - 1 < o && (e = e || this.isHostPartOfAlwaysActiveGroup(t.HostId), w.hostsConsent[o] = t.HostId + ":" + (e ? "1" : "0"))
    }, Do.prototype.isHostPartOfAlwaysActiveGroup = function(e) {
        return w.oneTrustAlwaysActiveHosts.includes(e)
    };
    var Io, bo, Lo, Eo, Oo, _o = Do;

    function Do() {}(V = bo = bo || {}).SaleOptOut = "SaleOptOutCID", V.SharingOptOut = "SharingOptOutCID", V.PersonalDataConsents = "PersonalDataCID", (V = Lo = Lo || {}).SharingOptOutNotice = "SharingOptOutCID", V.SaleOptOutNotice = "SaleOptOutCID", V.SensitiveDataLimitUseNotice = "SensitivePICID || SensitiveSICID || GeolocationCID || RREPInfoCID || CommunicationCID || GeneticCID|| BiometricCID || HealthCID || SexualOrientationCID", (V = Eo = Eo || {}).KnownChildSensitiveDataConsents1 = "KnownChildSellPICID", V.KnownChildSensitiveDataConsents2 = "KnownChildSharePICID", (V = Oo = Oo || {}).SensitiveDataProcessing1 = "SensitivePICID", V.SensitiveDataProcessing2 = "SensitiveSICID", V.SensitiveDataProcessing3 = "GeolocationCID", V.SensitiveDataProcessing4 = "RREPInfoCID", V.SensitiveDataProcessing5 = "CommunicationCID", V.SensitiveDataProcessing6 = "GeneticCID", V.SensitiveDataProcessing7 = "BiometricCID", V.SensitiveDataProcessing8 = "HealthCID", V.SensitiveDataProcessing9 = "SexualOrientationCID", Bo.prototype.initialiseCssReferences = function() {
        var e, t = "";
        document.getElementById("onetrust-style") ? e = document.getElementById("onetrust-style") : ((e = document.createElement("style")).id = "onetrust-style", k.moduleInitializer.CookieV2CSPEnabled && w.nonce && e.setAttribute("nonce", w.nonce)), js.commonStyles && (t += js.commonStyles), js.bannerGroup && (t += js.bannerGroup.css, k.fp.CookieV2SSR || (t += this.addCustomBannerCSS()), N.bannerCustomCSS) && (t += N.bannerCustomCSS), js.preferenceCenterGroup && (t = (t += js.preferenceCenterGroup.css) + this.addCustomPreferenceCenterCSS()), js.cookieListGroup && !k.fp.CookieV2TrackingTechnologies && (t = (t += js.cookieListGroup.css) + this.addCustomCookieListCSS()), t += this.addPersistentLogoCSS(), this.processedCSS = t, D.ignoreInjectingHtmlCss || (e.textContent = t, m(document.head).append(e))
    }, Bo.prototype.addPersistentLogoCSS = function() {
        if (N.cookiePersistentLogo) {
            var e = h.updateCorrectUrl(N.cookiePersistentLogo),
                t = new URL(e, window.location.origin).pathname;
            if (!(k.fp.CMPIconSprite && (k.fp.CMPIconSprite, t.includes("/logos/static/")) && (t.includes("src/assets/images/") || new URL(e, window.location.origin).host.includes("localhost")) || N.cookiePersistentLogo.includes("ot_guard_logo.svg"))) return ".ot-floating-button__front{background-image:url('" + e + "')}"
        }
        return ""
    }, Bo.prototype.shouldAddExtIconCss = function() {
        return N.BannerRequireExternalLinks && (!k.fp.CMPIconSprite || (k.fp.CMPIconSprite, N.BannerExternalLinksLogo))
    }, Bo.prototype.setToggleColor = function() {
        var e = N.PCenterToggleInActiveColor,
            t = N.PCenterToggleActiveColor,
            t = t ? "#onetrust-consent-sdk #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {\n                background-color: " + t + ";\n            }" : "";
        return e && (t += "\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch-nob {\n                    background-color: " + e + ";\n                }"), t
    }, Bo.prototype.setButonColor = function() {
        var e, t = N.pcButtonColor,
            o = N.pcButtonTextColor,
            n = N.pcLegIntButtonColor,
            r = N.pcLegIntButtonTextColor,
            i = "";
        return (t || o) && (e = D.pcName === rt ? "#onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Category_Item + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk.ot-leg-opt-out " + T.P_Li_Hdr + "{\n                    border-color: " + t + ";\n                }" : "", i = "#onetrust-consent-sdk #onetrust-pc-sdk\n            button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {\n                " + (t ? "background-color: " + t + ";border-color: " + t + ";" : "") + "\n                " + (o ? "color: " + o + ";" : "") + "\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk ." + T.P_Active_Menu + " {\n                " + (t ? "border-color: " + t + ";" : "") + "\n            }\n            " + e + "\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler{\n                background-color: transparent;\n                border: 1px solid transparent;\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {\n                " + (n ? "background-color: " + n + ";" : "") + "\n                " + (r ? "color: " + r + "; border-color: " + r + ";" : "") + "\n            }"), i
    }, Bo.prototype.setFocusBorderColor = function() {
        var e = "",
            t = N.PCFocusBorderColor;
        return t && (e += '\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-tgl input:focus + .ot-switch, .ot-switch .ot-switch-nob, .ot-switch .ot-switch-nob:before,\n            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"]:focus + label::before,\n            #onetrust-pc-sdk .ot-chkbox input[type="checkbox"]:focus + label::before {\n                outline-color: ' + t + ";\n                outline-width: 1px;\n                outline-offset: 1px;\n            }\n            #onetrust-pc-sdk .ot-host-item > button:focus, #onetrust-pc-sdk .ot-ven-item > button:focus {\n                border: 1px solid " + t + ";\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk *:focus,\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-vlst-cntr > a:focus {\n               outline: 1px solid " + t + ";\n               outline-offset: 1px;\n            }"), e
    }, Bo.prototype.setCloseIconColor = function() {
        var e = "";
        return N.PCCloseButtonType === Ae.Link && (e += "#onetrust-pc-sdk.ot-close-btn-link .ot-close-icon {color: " + N.PCContinueColor + "}"), e
    }, Bo.prototype.setTabLayoutStyles = function() {
        var e = "",
            t = N.pcMenuColor,
            o = N.pcMenuHighLightColor;
        return D.pcName === at && (t && (e += "#onetrust-consent-sdk #onetrust-pc-sdk .category-menu-switch-handler {\n                    background-color: " + t + "\n                }"), o) && (e += "#onetrust-consent-sdk #onetrust-pc-sdk ." + T.P_Active_Menu + " {\n                    background-color: " + o + "\n                }"), e
    }, Bo.prototype.setFocusIfTemplateUpgrade = function() {
        var e = "",
            t = N.PCFocusBorderColor;
        return !N.PCTemplateUpgrade && t && (e += '\n            #onetrust-pc-sdk input[type="checkbox"]:focus + .accordion-header,\n            #onetrust-pc-sdk .category-item .ot-switch.ot-toggle input:focus + .ot-switch-label,\n            #onetrust-pc-sdk .checkbox input:focus + label::after {\n                outline-color: ' + t + ";\n                outline-width: 1px;\n            }"), e
    }, Bo.prototype.setExtLnkUrl = function() {
        var e = "",
            t = h.updateCorrectUrl(N.OTExternalLinkLogo);
        return t && (e += "a.ot-ext-lnk:after {\n                    content: '';\n                    background-image: url('" + (N.BannerExternalLinksLogo ? h.updateCorrectUrl(N.BannerExternalLinksLogo) : t) + "');\n                    display: inline-block;\n                    width: 13px;\n                    height: 13px;\n                    background-size: contain;\n                    background-repeat: no-repeat;\n                    margin-bottom: -2px;\n                    margin-left: 2px;\n                }\n            "), e
    }, Bo.prototype.setBannerLinkMargins = function() {
        return "#onetrust-banner-sdk #onetrust-policy-text a.ot-cookie-policy-link,\n                         #onetrust-banner-sdk #onetrust-policy-text a.ot-imprint-link {\n                    margin-left: 5px;\n                }"
    }, Bo.prototype.setCustomCss = function() {
        var e = "";
        return N.pcCustomCSS && (e += N.pcCustomCSS), e
    };
    var No, wo = Bo;

    function Bo() {
        this.processedCSS = "", this.addCustomBannerCSS = function() {
            var e = N.backgroundColor,
                t = N.buttonColor,
                o = N.textColor,
                n = N.buttonTextColor,
                r = N.bannerMPButtonColor,
                i = N.bannerMPButtonTextColor,
                s = N.bannerAccordionBackgroundColor,
                a = N.BSaveBtnColor,
                l = N.BCategoryContainerColor,
                c = N.BLineBreakColor,
                d = N.BCategoryStyleColor,
                u = N.bannerLinksTextColor,
                p = N.BFocusBorderColor,
                o = "\n        " + (D.bannerName === Ze ? e ? "#onetrust-consent-sdk #onetrust-banner-sdk .ot-sdk-container {\n                    background-color: " + e + ";}" : "" : e ? "#onetrust-consent-sdk #onetrust-banner-sdk {background-color: " + e + ";}" : "") + "\n            " + (o ? "#onetrust-consent-sdk #onetrust-policy-title,\n                    #onetrust-consent-sdk #onetrust-policy-text,\n                    #onetrust-consent-sdk .ot-b-addl-desc,\n                    #onetrust-consent-sdk .ot-dpd-desc,\n                    #onetrust-consent-sdk .ot-dpd-title,\n                    #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),\n                    #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),\n                    #onetrust-consent-sdk #onetrust-banner-sdk #banner-options *,\n                    #onetrust-banner-sdk .ot-cat-header,\n                    #onetrust-banner-sdk .ot-optout-signal\n                    {\n                        color: " + o + ";\n                    }" : "") + "\n            " + (s ? "#onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {\n                    background-color: " + s + ";}" : "") + "\n            " + (u ? " #onetrust-consent-sdk #onetrust-banner-sdk a[href],\n                    #onetrust-consent-sdk #onetrust-banner-sdk a[href] font,\n                    #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn\n                        {\n                            color: " + u + ";\n                        }" : "");
            return (t || n) && (o += "#onetrust-consent-sdk #onetrust-accept-btn-handler,\n                         #onetrust-banner-sdk #onetrust-reject-all-handler,\n                         #onetrust-banner-sdk #ot-dialog-confirm-handler {\n                            " + (t ? "background-color: " + t + ";border-color: " + t + ";" : "") + "\n                " + (n ? "color: " + n + ";" : "") + "\n            }"), p && (o += "\n            #onetrust-consent-sdk #onetrust-banner-sdk *:focus,\n            #onetrust-consent-sdk #onetrust-banner-sdk:focus {\n               outline-color: " + p + ";\n               outline-width: 1px;\n            }"), (i || r) && (o += "\n            #onetrust-consent-sdk #onetrust-pc-btn-handler,\n            #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link,\n            #onetrust-consent-sdk #ot-dialog-cancel-handler {\n                " + (i ? "color: " + i + "; border-color: " + i + ";" : "") + "\n                background-color:\n                " + (r && !N.BannerSettingsButtonDisplayLink ? r : e) + ";\n            }"), D.bannerName === tt && (r = i = t = u = s = void 0, d && (i = "background-color: " + d + ";", r = "border-color: " + d + ";"), p && (o += "\n                #onetrust-consent-sdk #onetrust-banner-sdk .ot-tgl input:focus+.ot-switch .ot-switch-nob,\n                #onetrust-consent-sdk #onetrust-banner-sdk .ot-chkbox input:focus + label::before {\n                    outline-color: " + p + ";\n                    outline-width: 1px;\n                }"), o += "#onetrust-banner-sdk .ot-bnr-save-handler {" + (s = a ? "color: " + n + ";border-color: " + n + ";background-color: " + a + ";" : s) + "}#onetrust-banner-sdk .ot-cat-lst {" + (u = l ? "background-color: " + l + ";" : u) + "}#onetrust-banner-sdk .ot-cat-bdr {" + (t = c ? "border-color: " + c + ";" : t) + "}#onetrust-banner-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before,#onetrust-banner-sdk .ot-chkbox input:checked~label::before {" + i + "}#onetrust-banner-sdk .ot-chkbox label::before,#onetrust-banner-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {" + r + "}#onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {background: inherit}"), N.BCloseButtonType === Ae.Link && (o += "#onetrust-banner-sdk.ot-close-btn-link .banner-close-button {color: " + N.BContinueColor + "}"), o += No.setBannerLinkMargins()
        }, this.addCustomPreferenceCenterCSS = function() {
            var e = N.pcBackgroundColor,
                t = N.pcTextColor,
                o = N.pcLinksTextColor,
                n = N.PCenterEnableAccordion,
                r = N.pcAccordionBackgroundColor,
                e = "\n            " + (e ? (D.pcName === rt ? "#onetrust-consent-sdk #onetrust-pc-sdk .group-parent-container,\n                        #onetrust-consent-sdk #onetrust-pc-sdk .manage-pc-container,\n                        #onetrust-pc-sdk " + T.P_Vendor_List : "#onetrust-consent-sdk #onetrust-pc-sdk") + ",\n                #onetrust-consent-sdk " + T.P_Search_Cntr + ",\n                " + (n && D.pcName === rt ? "#onetrust-consent-sdk #onetrust-pc-sdk .ot-accordion-layout" + T.P_Category_Item : "#onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle") + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Tab_Grp_Hdr + " .checkbox,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Title + ":after\n                " + (k.isV2Template ? ",#onetrust-consent-sdk #onetrust-pc-sdk #ot-sel-blk,\n                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-cnt,\n                        #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Triangle : "") + " {\n                    background-color: " + e + ";\n                }\n               " : "") + "\n            " + (t ? '#onetrust-consent-sdk #onetrust-pc-sdk h3,\n                #onetrust-consent-sdk #onetrust-pc-sdk h4,\n                #onetrust-consent-sdk #onetrust-pc-sdk h5,\n                #onetrust-consent-sdk #onetrust-pc-sdk h6,\n                #onetrust-consent-sdk #onetrust-pc-sdk p,\n                #onetrust-consent-sdk #onetrust-pc-sdk span[id^="ot-header-id"],\n                #onetrust-consent-sdk #onetrust-pc-sdk #ot-pvcy-txt,\n                #onetrust-consent-sdk #onetrust-pc-sdk #privacy-text,\n                #onetrust-consent-sdk #onetrust-pc-sdk ' + T.P_Vendor_Container + " " + T.P_Ven_Opts + " p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Policy_Txt + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Title_Mobile + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Li_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Leg_Select_All + " span,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Host_Cntr + " " + T.P_Host_Info + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Fltr_Modal + " #modal-header,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Vendor_List + " " + T.P_Select_Cntr + " p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Vendor_List + " " + T.P_Vendor_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Vendor_List + ' #ot-lst-title p[aria-level="3"],\n                #onetrust-consent-sdk #onetrust-pc-sdk ' + T.P_Vendor_List + " .back-btn-handler p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Vendor_List + " " + T.P_Ven_Name + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Vendor_List + " " + T.P_Vendor_Container + " .consent-category,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,\n                #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-optout-signal\n                {\n                    color: " + t + ";\n                }" : "") + "\n            " + (o ? " #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-pgph-link,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Ven_Link + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Ven_Leg_Claim + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Host_Cntr + " " + T.P_Host_Title + " a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Host_Cntr + " " + T.P_Acc_Header + " " + T.P_Host_View_Cookies + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Host_Cntr + " " + T.P_Host_Info + " a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Content + " " + T.P_Policy_Txt + " .ot-link-btn,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-vnd-serv .ot-vnd-item .ot-vnd-info a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-lst-cnt .ot-vnd-info a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-desc a\n                    {\n                        color: " + o + ";\n                    }" : "") + "\n            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover { text-decoration: underline;}\n            " + (n && r ? "#onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Acc_Container + T.P_Acc_Txt + ",\n            #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Acc_Txt + " " + T.P_Subgrp_Tgl_Cntr + " .ot-switch.ot-toggle\n             {\n                background-color: " + r + ";\n            }" : "") + "\n            " + (r ? " #onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Host_Cntr + " " + T.P_Host_Info + ",\n                    " + (k.isV2Template ? "#onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Acc_Txt + " .ot-ven-dets" : "#onetrust-consent-sdk #onetrust-pc-sdk " + T.P_Acc_Txt + " " + T.P_Ven_Opts) + "\n                            {\n                                background-color: " + r + ";\n                            }" : "") + "\n        ",
                e = (e = (e = (e = (e = (e = (e += No.setButonColor()) + No.setToggleColor()) + No.setFocusBorderColor()) + No.setCloseIconColor()) + No.setTabLayoutStyles()) + No.setTabLayoutStyles()) + No.setFocusIfTemplateUpgrade();
            return No.shouldAddExtIconCss() && (e += No.setExtLnkUrl()), e += No.setCustomCss()
        }, this.addCustomCookieListCSS = function() {
            var e = N.CookiesV2NewCookiePolicy ? "-v2.ot-sdk-cookie-policy" : "",
                e = "\n                " + (N.cookieListPrimaryColor ? "\n                    #ot-sdk-cookie-policy" + e + " h5,\n                    #ot-sdk-cookie-policy" + e + " h6,\n                    #ot-sdk-cookie-policy" + e + " li,\n                    #ot-sdk-cookie-policy" + e + " p,\n                    #ot-sdk-cookie-policy" + e + " a,\n                    #ot-sdk-cookie-policy" + e + " span,\n                    #ot-sdk-cookie-policy" + e + " td,\n                    #ot-sdk-cookie-policy" + e + " #cookie-policy-description {\n                        color: " + N.cookieListPrimaryColor + ";\n                    }" : "") + "\n                    " + (N.cookieListTableHeaderColor ? "#ot-sdk-cookie-policy" + e + " th {\n                        color: " + N.cookieListTableHeaderColor + ";\n                    }" : "") + "\n                    " + (N.cookieListGroupNameColor ? "#ot-sdk-cookie-policy" + e + " .ot-sdk-cookie-policy-group {\n                        color: " + N.cookieListGroupNameColor + ";\n                    }" : "") + "\n                    " + (N.cookieListTitleColor ? "\n                    #ot-sdk-cookie-policy" + e + " #cookie-policy-title {\n                            color: " + N.cookieListTitleColor + ";\n                        }\n                    " : "") + "\n            " + (e && N.CookieListTableHeaderBackgroundColor ? "\n                    #ot-sdk-cookie-policy" + e + " table th {\n                            background-color: " + N.CookieListTableHeaderBackgroundColor + ";\n                        }\n                    " : "") + "\n            ";
            return N.cookieListCustomCss && (e += N.cookieListCustomCss), e
        }
    }
    xo.prototype.setBannerFocus = function() {
        var e = this,
            t = Array.prototype.slice.call(m("#onetrust-banner-sdk .onetrust-vendors-list-handler").el),
            o = Array.prototype.slice.call(m('#onetrust-banner-sdk #onetrust-policy-text a,#onetrust-banner-sdk #onetrust-policy-text button,#onetrust-banner-sdk #onetrust-policy-text [tabindex]:not([tabindex="-1"])').el),
            n = Array.prototype.slice.call(m("#onetrust-banner-sdk .ot-bnr-save-handler").el),
            r = Array.prototype.slice.call(m("#onetrust-banner-sdk #onetrust-pc-btn-handler").el),
            i = Array.prototype.concat.call(Array.prototype.slice.call(m("#onetrust-banner-sdk .category-switch-handler:not([disabled])").el), Array.prototype.slice.call(m("#onetrust-banner-sdk .ot-cat-lst button").el), t),
            i = Array.prototype.concat.call(o, i),
            s = Array.prototype.slice.call(m("#onetrust-banner-sdk .onetrust-close-btn-handler").el),
            t = (D.bannerName === Ze && (i = Array.prototype.concat.call(t, o)), Array.prototype.slice.call(m("#onetrust-banner-sdk #onetrust-accept-btn-handler").el)),
            o = Array.prototype.slice.call(m("#onetrust-banner-sdk #onetrust-reject-all-handler").el),
            n = Array.prototype.concat.call(n, t, o, r),
            r = ((D.bannerName !== Xe || N.IsIabEnabled) && D.bannerName !== Je && D.bannerName !== et || (n = Array.prototype.concat.call(r, o, t)), Array.prototype.slice.call(m("#onetrust-banner-sdk .ot-gv-list-handler").el)),
            o = (D.bannerName === tt ? (i = Array.prototype.concat.call(r, i), n = Array.prototype.slice.call(m("#onetrust-banner-sdk #onetrust-button-group button").el)) : i = Array.prototype.concat.call(i, r), this.rearrangeInButtonOrder(n), m("#onetrust-banner-sdk .ot-b-addl-desc").el[0]),
            t = this.getTabbableElements(o),
            i = N.BannerAdditionalDescPlacement === le.AfterTitle ? Array.prototype.concat.call(t, i) : Array.prototype.concat.call(i, t),
            r = new Set(Array.prototype.concat.call(Array.prototype.slice.call(m("#onetrust-banner-sdk #onetrust-cookie-btn").el), i, Array.prototype.slice.call(m("#onetrust-banner-sdk .banner-option-input").el), n, Array.prototype.slice.call(m("#onetrust-banner-sdk .ot-bnr-footer-logo a").el), s));
        this.bannerEl = Array.from(r), this.banner = m("#onetrust-banner-sdk").el[0], (N.BInitialFocus || N.BInitialFocusLinkAndButton || N.ForceConsent) && (N.BInitialFocus ? setTimeout(function() {
            e.banner.focus()
        }, 1e3) : setTimeout(function() {
            e.bannerEl[0].focus()
        }, 1e3))
    }, xo.prototype.handleBannerFocus = function(e, t) {
        var o = e.target,
            n = Vo.bannerEl,
            r = n.indexOf(o),
            i = n.length - 1,
            s = null;
        if (this.handleBannerFocusBodyReset(t, r, i)) h.resetFocusToBody();
        else if (this.banner === o) s = this.handleInitialBannerFocus(t, n, i, s);
        else
            for (; !s;) {
                var a = void 0;
                0 !== (a = t ? r <= 0 ? n[i] : n[r - 1] : r === i ? n[0] : n[r + 1]).clientHeight || 0 !== a.offsetHeight ? s = a : t ? r-- : r++
            }
        s && (e.preventDefault(), s.focus())
    }, xo.prototype.rearrangeInButtonOrder = function(e) {
        N.PCTemplateUpgrade && k.fp.WebButtonCustomisations && e && e.sort(function(e, t) {
            function o(e) {
                return (e = Array.from(e.classList).find(function(e) {
                    return e.startsWith("ot-button-order-")
                })) ? parseInt(e.replace("ot-button-order-", "")) : 1 / 0
            }
            return o(e) - o(t)
        })
    }, xo.prototype.handleBannerFocusBodyReset = function(e, t, o) {
        return !(N.ForceConsent || !N.BInitialFocus && !N.BInitialFocusLinkAndButton || !(e && 0 === t || !e && t === o))
    }, xo.prototype.handleInitialBannerFocus = function(e, t, o, n) {
        return e && N.ForceConsent ? n = t[o] : e || (n = t[0]), n
    }, xo.prototype.setPCFocus = function(e) {
        if (e && !(e.length <= 0)) {
            for (var t = 0; t < e.length; t++) e[t].setAttribute("tabindex", "0");
            this.setFirstAndLast(e);
            this.firstItem ? this.firstItem.focus({
                preventScroll: !0
            }) : e[0].focus(), this.firstItem && m(this.firstItem).on("keydown", Vo.firstItemHandler), this.lastItem && m(this.lastItem).on("keydown", Vo.lastItemHandler)
        }
    }, xo.prototype.setFirstAndLast = function(e) {
        this.firstItem = this.getElementForFocus(e, 0, !0), this.lastItem = this.firstItem ? this.getElementForFocus(e, e.length - 1, !1) : null
    }, xo.prototype.setLastItem = function() {
        var e = this.getPCElements(),
            e = this.getElementForFocus(e, e.length - 1, !1);
        e !== this.lastItem && (m(this.lastItem).off("keydown", Vo.lastItemHandler), this.lastItem = e, m(e).on("keydown", Vo.lastItemHandler))
    }, xo.prototype.getPCElements = function() {
        var e = "#onetrust-pc-sdk #close-pc-btn-handler,\n            #onetrust-pc-sdk .back-btn-handler,\n            #onetrust-pc-sdk ." + T.P_Active_Menu + ',\n            #onetrust-pc-sdk input,\n            #onetrust-pc-sdk a,\n            #onetrust-pc-sdk [tabindex="0"] button,\n            #onetrust-pc-sdk .save-preference-btn-handler,\n            #onetrust-pc-sdk .ot-pc-refuse-all-handler,\n            #onetrust-pc-sdk #accept-recommended-btn-handler';
        return w.pcLayer === se.CookieList ? e += " ,#onetrust-pc-sdk " + T.P_Content + " .powered-by-logo" : e += ",#onetrust-pc-sdk #vendor-list-save-btn .powered-by-logo", Array.prototype.slice.call(m(e).el)
    }, xo.prototype.getActiveTab = function() {
        return document.querySelector('#onetrust-pc-sdk .category-menu-switch-handler[tabindex="0"]')
    }, xo.prototype.getElementForFocus = function(e, t, o) {
        for (var n = e[t]; o ? n && null === n.offsetParent && t < e.length - 1 : n && null === n.offsetParent && 0 < t;) n = e[t], o ? ++t : --t;
        return n
    }, xo.prototype.handleFocusTabLayoutExceptClosePC = function(e) {
        var t = "close-pc-btn-handler" === e.target.id && (13 === e.keyCode || 32 === e.keyCode || "Enter" === e.code || "Space" === e.code);
        N.PCLayout.Tab && w.pcLayer === se.PrefCenterHome && !t && (t = Vo.getActiveTab()) && (e.preventDefault(), t.focus())
    }, xo.prototype.firstItemHandler = function(e) {
        var t = document.getElementById("onetrust-banner-sdk");
        9 === e.keyCode && e.shiftKey && Vo.firstItem !== t ? (e.preventDefault(), Vo.lastItem.focus()) : N.ShowPreferenceCenterCloseButton ? Vo.handleFocusTabLayoutExceptClosePC(e) : !N.PCLayout.Tab || w.pcLayer !== se.PrefCenterHome || 37 !== e.keyCode && 39 !== e.keyCode || (t = Vo.getActiveTab()) && m(t).on("keydown", Vo.firstItemHandler)
    }, xo.prototype.lastItemHandler = function(e) {
        9 !== e.keyCode || e.shiftKey || (e.preventDefault(), e = w.pcLayer === se.VendorList || w.pcLayer === se.CookieList, (N.PCLayout.Tab && w.isPCVisible && !N.ShowPreferenceCenterCloseButton && !e ? Vo.getActiveTab() : Vo.firstItem).focus())
    }, xo.prototype.getTabbableElements = function(e) {
        return e ? Array.from(e.querySelectorAll(["a[href]", "area[href]", "input:not([disabled])", "select:not([disabled])", "textarea:not([disabled])", "button:not([disabled])", '[tabindex]:not([tabindex="-1"])', "[contenteditable]"].join(","))).filter(function(e) {
            return !e.hasAttribute("disabled")
        }) : []
    }, xo.prototype.focusFirstTabbableElement = function() {
        var e = this.getTabbableElements(document.body).find(function(e) {
            return !e.closest("#onetrust-consent-sdk") && !e.closest("#onetrust-banner-sdk") && !e.closest("#onetrust-pc-sdk") && null !== e.offsetParent
        });
        e && e.focus()
    };
    var Vo, Go = xo;

    function xo() {
        this.bannerEl = []
    }
    var Ho, Ro, Fo = "#onetrust-banner-sdk",
        Mo = ".banner_logo",
        Uo = "#onetrust-pc-sdk",
        qo = "#onetrust-accept-btn-handler",
        jo = "#onetrust-reject-all-handler",
        Ko = "#onetrust-pc-btn-handler",
        zo = "#accept-recommended-btn-handler",
        Wo = (Yo.prototype.BannerPushDownHandler = function() {
            this.checkIsBrowserIE11OrBelow() || (Ro.pushPageDown(Fo), m(window).on("resize", function() {
                "none" !== m(Fo).css("display") && Ro.pushPageDown(Fo)
            }))
        }, Yo.prototype.checkIsBrowserIE11OrBelow = function() {
            var e = window.navigator.userAgent;
            return 0 < e.indexOf("MSIE ") || 0 < e.indexOf("Trident/")
        }, Yo.prototype.addOTCssPropertiesToBody = function(e, t) {
            var o = Ro.getCssData(e, t);
            p.customerStyles.set(e, o), Ro.setStylesOnBody(t)
        }, Yo.prototype.removeAddedOTCssStyles = function(e) {
            void 0 === e && (e = Ho.Banner);
            var t = p.customerStyles.get(e);
            t ? (Ro.setStylesOnBody(t.customerBodyCSS), Ro.setStylesOnHtml(t.customerHtmlCSS), p.customerStyles.delete(e)) : 0 < p.customerStyles.size && p.customerStyles.forEach(function(e, t) {
                return Ro.removeAddedOTCssStyles(t)
            })
        }, Yo.prototype.getCssData = function(e, t) {
            var o = m("body").el[0],
                n = m("html").el[0],
                e = p.customerStyles.get(e);
            return e ? this.getUpdatedCssData(e, t, o, n) : {
                scriptBodyCSS: R({}, t),
                customerBodyCSS: {
                    top: o.style.top,
                    position: o.style.position,
                    overflow: o.style.overflow
                },
                customerHtmlCSS: {
                    overflow: n.style.overflow
                }
            }
        }, Yo.prototype.getUpdatedCssData = function(e, t, o, n) {
            var r = e.scriptBodyCSS,
                i = e.customerBodyCSS,
                e = e.customerHtmlCSS,
                s = this.mergeScriptCss(r, t);
            return this.updateCustomerBodyCss(i, r, t, o), this.updateCustomerHtmlCss(e, r, t, n), {
                scriptBodyCSS: s,
                customerBodyCSS: i,
                customerHtmlCSS: e
            }
        }, Yo.prototype.mergeScriptCss = function(e, t) {
            var o = R({}, t);
            return void 0 !== e.top && void 0 === t.top && (o.top = e.top), void 0 !== e.position && void 0 === t.position && (o.position = e.position), void 0 !== e.overflow && void 0 === t.overflow && (o.overflow = e.overflow), o
        }, Yo.prototype.updateCustomerBodyCss = function(e, t, o, n) {
            n.style.top !== t.top && n.style.top !== o.top && n.style.top !== e.top && (e.top = n.style.top), n.style.position !== t.position && n.style.position !== o.position && n.style.position !== e.position && (e.position = n.style.position), n.style.overflow !== t.overflow && n.style.overflow !== o.overflow && n.style.overflow !== e.overflow && (e.overflow = n.style.overflow)
        }, Yo.prototype.updateCustomerHtmlCss = function(e, t, o, n) {
            n = n.style.overflow;
            n !== t.overflow && n !== o.overflow && n !== e.overflow && (e.overflow = n)
        }, Yo.prototype.setStylesOnBody = function(e) {
            var t = m("body").el[0];
            Ro.setStylesOnHtmlElement(t, e)
        }, Yo.prototype.setStylesOnHtml = function(e) {
            var t = m("html").el[0];
            Ro.setStylesOnHtmlElement(t, {
                overflow: e.overflow
            })
        }, Yo.prototype.setStylesOnHtmlElement = function(e, t) {
            for (var o = "", n = 0, r = Object.entries(t); n < r.length; n++) {
                var i = r[n],
                    s = i[0],
                    i = i[1];
                i ? o += s + ": " + i + ";" : e.style.removeProperty(s)
            }
            o && Ht(e, o, !0)
        }, Yo.prototype.pushPageDown = function(e) {
            var t = m(e).height() + "px",
                e = (m(e).show().css("\n            bottom: auto;\n            position: absolute;\n            top: -" + t + ";\n        "), p.isPCVisible ? Ho.PC : Ho.Banner),
                t = {
                    position: "relative",
                    top: t
                };
            p.isPCVisible && (t.overflow = "hidden"), Ro.addOTCssPropertiesToBody(e, t)
        }, Yo);

    function Yo() {}(V = Ho = Ho || {}).Banner = "Banner", V.PC = "PC", Qo.prototype.showConsentNotice = function() {
        p.pcClosedFromCloseBtn = !1;
        var e = this.shouldHideDarkFilterOnCookiePolicyPage();
        this.updateDarkFilterVisibility(e), m(this.ONETRUST_PC_SDK).removeClass("ot-hide"), k.isV2Template && this.closePCText(!0), this.handlePanelAnimation(), k.fp.WebButtonCustomisations || y.setAllowAllButton(), Vo.setPCFocus(Vo.getPCElements()), this.shouldApplyScrollLock(e) && this.pcHasScroll(), this.handleBodyStylesForBannerPushdown()
    }, Qo.prototype.hideConsentNoticeV2 = function() {
        0 === m(this.ONETRUST_PC_SDK).length ? this.setFocusOnPage() : (k.isV2Template && this.closePCText(), this.handleDarkFilterOnHide(), this.handlePanelSlideOut(), this.hidePcWithAnimation(), this.handleDarkFilterOnCookiePolicyPage(), p.isPCVisible = !1, p.pcLayer = se.Banner, this.setFocus())
    }, Qo.prototype.setFocus = function() {
        var e;
        p.wasBannerVisible && !p.pcClosedFromCloseBtn ? (Vo.focusFirstTabbableElement(), p.wasBannerVisible = !1, p.pcClosedFromCloseBtn = !1) : p.pcSource || ta.isAlertBoxClosedAndValid() ? p.pcSource ? ((e = p.pcSource).getAttribute("tabindex") || "A" !== e.tagName || e.getAttribute("href") || e.setAttribute("tabindex", "-1"), e.focus(), p.pcSource = null) : this.setFocusOnPage() : (e = m("#onetrust-banner-sdk #onetrust-pc-btn-handler").el[0]) && e.focus()
    }, Qo.prototype.shouldHideDarkFilterOnCookiePolicyPage = function() {
        return this.isBannerNotShown() && h.isCookiePolicyPage(N.MainInfoText)
    }, Qo.prototype.updateDarkFilterVisibility = function(e) {
        var t = !N.NoBanner || N.ForceConsent;
        !e && t ? m(this.ONETRUST_PC_DARK_FILTER).removeClass("ot-hide") : m(this.ONETRUST_PC_DARK_FILTER).addClass("ot-hide")
    }, Qo.prototype.handlePanelAnimation = function() {
        var e, t, o;
        D.pcName === it && ((e = m(this.ONETRUST_PC_SDK)).el[0].classList.contains("ot-animated") || e.addClass("ot-animated"), o = "ot-slide-in-" + (t = this.getSlideDirection()), e.el[0].classList.contains(t = "ot-slide-out-" + t) && e.removeClass(t), e.addClass(o))
    }, Qo.prototype.shouldApplyScrollLock = function(e) {
        return !(N.NoBanner && N.ScrollCloseBanner || e)
    }, Qo.prototype.handleDarkFilterOnHide = function() {
        N.ForceConsent && !h.isCookiePolicyPage(N.AlertNoticeText) && !ta.isAlertBoxClosedAndValid() && N.ShowAlertNotice ? m(this.ONETRUST_PC_DARK_FILTER).css("z-index: 2147483645;").show() : m(this.ONETRUST_PC_DARK_FILTER).fadeOut(this.getAnimationDuration())
    }, Qo.prototype.handlePanelSlideOut = function() {
        var e;
        N.PCLayout.Panel && (e = this.getSlideDirection(), m(this.ONETRUST_PC_SDK).removeClass("ot-slide-in-" + e), m(this.ONETRUST_PC_SDK).addClass("ot-slide-out-" + e))
    }, Qo.prototype.hidePcWithAnimation = function() {
        m(this.ONETRUST_PC_SDK).fadeOut(this.getAnimationDuration())
    }, Qo.prototype.handleDarkFilterOnCookiePolicyPage = function() {
        this.shouldHideDarkFilterOnCookiePolicyPage() && (m(this.ONETRUST_PC_DARK_FILTER).addClass("ot-hide"), Ro.removeAddedOTCssStyles(Ho.PC))
    }, Qo.prototype.getSlideDirection = function() {
        var e = N.PreferenceCenterPosition,
            t = N.useRTL;
        return "right" === e ? t ? "left" : "right" : t ? "right" : "left"
    }, Qo.prototype.getAnimationDuration = function() {
        return N.PCLayout.Panel ? 500 : 400
    }, Qo.prototype.handleBodyStylesForBannerPushdown = function() {
        D.pcName === at && D.pagePushedDown && "top" === N.BannerPosition && Ro.addOTCssPropertiesToBody(Ho.PC, {})
    }, Qo.prototype.setFocusOnPage = function() {
        var e = document.querySelectorAll('button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])');
        p.isKeyboardUser && e.length && e[0].focus()
    }, Qo.prototype.closePCText = function(e) {
        void 0 === e && (e = !1);
        var t = document.querySelector("#onetrust-pc-sdk span[aria-live]"),
            o = N.AboutCookiesText;
        t && (t.innerText = e ? "" : o + (" " + N.pcDialogClose))
    }, Qo.prototype.pcHasScroll = function() {
        this.bodyStyleChanged = !0;
        var e = m("body");
        e && e.length && Ro.addOTCssPropertiesToBody(Ho.PC, {
            overflow: "hidden"
        })
    }, Qo.prototype.checkIfPcSdkContainerExist = function() {
        return !m("" + Jo.ONETRUST_PC_SDK).length
    }, Qo.prototype.isBannerNotShown = function() {
        var e = ta.isAlertBoxClosedAndValid();
        return !N.ShowAlertNotice || e || N.NoBanner || p.hideBanner
    };
    var Jo, Xo = Qo;

    function Qo() {
        this.ONETRUST_PC_SDK = "#onetrust-pc-sdk", this.ONETRUST_PC_DARK_FILTER = ".onetrust-pc-dark-filter", this.bodyStyleChanged = !1
    }
    en.prototype.updateGtmMacros = function(e) {
        void 0 === e && (e = !0);
        var n = [];
        w.groupsConsent.forEach(function(e) {
            var t = e.replace(":1", ""),
                o = L.getGrpStatus(L.getGroupById(t)).toLowerCase() === f.ALWAYS_ACTIVE;
            v.endsWith(e, ":1") && (js.canSoftOptInInsertForGroup(t) || o) && n.push(t)
        }), w.hostsConsent.forEach(function(e) {
            v.endsWith(e, ":1") && n.push(e.replace(":1", ""))
        }), w.showGeneralVendors && N.GenVenOptOut && N.GeneralVendors.forEach(function(e) {
            !w.genVendorsConsent[e.VendorCustomId] || w.softOptInGenVendors.includes(e.VendorCustomId) && Ao.isLandingPage() || n.push(e.VendorCustomId)
        });
        w.vsIsActiveAndOptOut && w.getVendorsInDomain().forEach(function(e) {
            w.vsConsent.get(e.CustomVendorServiceId) && n.push(e.CustomVendorServiceId)
        });
        var t = "," + v.arrToStr(n) + ",",
            o = this.includeAllActiveIABData();
        N.GoogleConsent.GCEnable && !D.otDataLayer.ignore && this.updateGCMTags(U(n, o)), N.MCMData && N.MCMData.Enabled && (this.updateMCMTags(U(n, o)), this.updateClarityTags(U(n, o))), this.updateACMTags(U(n, o)), window.OnetrustActiveGroups = t, window.OptanonActiveGroups = t, D.gcmUpdateCallback && D.gcmUpdateCallback(), D.otDataLayer.ignore || void 0 === this._window[D.otDataLayer.name] || this._window[D.otDataLayer.name].constructor !== Array ? !D.otDataLayer.ignore && D.otDataLayer.name && (this._window[D.otDataLayer.name] = [{
            event: "OneTrustLoaded",
            OnetrustActiveGroups: t
        }, {
            event: "OptanonLoaded",
            OptanonActiveGroups: t
        }]) : (this._window[D.otDataLayer.name].push({
            event: "OneTrustLoaded",
            OnetrustActiveGroups: t
        }), this._window[D.otDataLayer.name].push({
            event: "OptanonLoaded",
            OptanonActiveGroups: t
        })), this.dispatchEvents(e, n, t)
    }, en.prototype.includeAllActiveIABData = function() {
        try {
            for (var n = [], e = 0, t = ["purpose", "features", "specialFeatures", "specialPurposes"]; e < t.length; e++)(o => {
                var t, e = w.oneTrustIABConsent[o];
                "purpose" === o || "specialFeatures" === o ? e.forEach(function(e) {
                    var t = "purpose" === o ? "IAB2V2" : "ISF2V2",
                        e = e.split(":");
                    "true" === e[1] && n.push(t + "_" + e[0])
                }) : (t = [], e.forEach(function(e) {
                    e.value && t.push(e.groupId.toString())
                }), n = U(n, t))
            })(t[e]);
            return n
        } catch (e) {
            return []
        }
    }, en.prototype.dispatchEvents = function(e, t, o) {
        !e && D.gtmUpdatedinStub || (n = new CustomEvent("consent.onetrust", {
            detail: t
        }));
        var n, r, i = I.readCookieParam(P.OPTANON_CONSENT, "groups"),
            s = w.fireOnetrustGrp || !i || e || !D.gtmUpdatedinStub;
        s && (w.fireOnetrustGrp = !1, !D.otDataLayer.ignore && this._window[D.otDataLayer.name] && this._window[D.otDataLayer.name].constructor === Array && this._window[D.otDataLayer.name].push({
            event: "OneTrustGroupsUpdated",
            OnetrustActiveGroups: o
        }), r = new CustomEvent("OneTrustGroupsUpdated", {
            detail: t
        })), setTimeout(function() {
            n && s && window.dispatchEvent(n), r && window.dispatchEvent(r)
        })
    }, en.prototype.isCategoryMapped = function(e) {
        return e !== ht && "" !== e
    }, en.prototype.updateGCMTags = function(o) {
        var n, r = this,
            i = {},
            e = (this.canUpdateGCMCategories() && (e = [
                [N.GoogleConsent.GCAdStorage, Ie.ad_storage],
                [N.GoogleConsent.GCAnalyticsStorage, Ie.analytics_storage],
                [N.GoogleConsent.GCFunctionalityStorage, Ie.functionality_storage],
                [N.GoogleConsent.GCPersonalizationStorage, Ie.personalization_storage],
                [N.GoogleConsent.GCSecurityStorage, Ie.security_storage]
            ], k.fp.CookieV2GCMDMA && (e.push([N.GoogleConsent.GCAdUserData, Ie.ad_user_data]), e.push([N.GoogleConsent.GCAdPersonalization, Ie.ad_personalization])), e.forEach(function(e) {
                var t;
                r.isCategoryMapped(e[0]) && (t = o.includes(e[0]) ? be.granted : be.denied, i[e[1]] = t)
            })), I.getCookie(P.ALERT_BOX_CLOSED));
        D.getRegionRule().Global, "function" != typeof window.gtag && (n = this._window, window.gtag = function(e, t, o) {
            D.otDataLayer.ignore || (n[D.otDataLayer.name] ? n[D.otDataLayer.name].push(arguments) : n[D.otDataLayer.name] = [arguments])
        }), "function" == typeof window.gtag && (D.gcmDevIdSet || (window.gtag(Pe.set, "developer_id.dYWJhMj", !0), D.gcmDevIdSet = !0), e) && 0 !== Object.keys(i).length && window.gtag(Pe.consent, ke.update, i)
    }, en.prototype.updateMCMTags = function(e) {
        for (var t = "uetq", o = {}, n = 0, r = Object.entries(N.MCMData.StorageTypes); n < r.length; n++) {
            var i = r[n],
                s = i[0],
                i = i[1];
            this.isCategoryMapped(i) && (i = e.includes(i) ? be.granted : be.denied, o[s] = i)
        }
        this._window[t] = this._window[t] || [], this._window[t].push("consent", "update", o)
    }, en.prototype.updateClarityTags = function(e) {
        var t = "clarity",
            o = {};
        try {
            if (N.MCMData && N.MCMData.Enabled) {
                for (var n, r = N.MCMData.StorageTypes || {}, i = 0, s = Object.entries(r); i < s.length; i++) {
                    var a, l = s[i],
                        c = l[0],
                        d = l[1];
                    this.isCategoryMapped(d) && (a = e.includes(d) ? be.granted : be.denied, o["analytics_storage" === c ? "analytics_Storage" : "ad_storage" === c ? "ad_Storage" : c] = a)
                }
                "function" != typeof this._window[t] && ((n = this._window)[t] = function() {
                    (n[t].q = n[t].q || []).push(arguments)
                }), Object.keys(o).length && this._window[t]("consentv2", o)
            }
        } catch (e) {
            console.error("Error updating Clarity tags:", e)
        }
    }, en.prototype.updateACMTags = function(e) {
        var t, o;
        N.ACMData && N.ACMData.Enabled && ((o = {}).countryCode = null == (t = w.userLocation) ? void 0 : t.country, this.setConsentOnMode(o, It, e), this.setConsentOnMode(o, kt, e), this.pollForAmazonConsent(o))
    }, en.prototype.pollForAmazonConsent = function(e) {
        var t = this,
            o = 0,
            n = setInterval(function() {
                o++;
                try {
                    t._window.amznConsent && "function" == typeof t._window.amznConsent ? (t._window.amznConsent().setCountryCode(e.countryCode).setEnableAdStorage(e[kt]).setEnableUserData(e[It]).build(), clearInterval(n)) : 50 <= o && (clearInterval(n), console.warn("OneTrust: Amazon Consent JS not available after timeout. ACM consent not set."))
                } catch (e) {
                    clearInterval(n), console.warn("OneTrust: Error setting Amazon Consent. ACM consent not set.", e)
                }
            }, 100)
    }, en.prototype.setConsentOnMode = function(e, t, o) {
        var n = N.ACMData.StorageTypes[t],
            o = !(!this.isCategoryMapped(n) || !o.includes(n));
        e[t] = o
    }, en.prototype.canUpdateGCMCategories = function() {
        return N.GoogleConsent.GCAdStorage !== ht || N.GoogleConsent.GCAnalyticsStorage !== ht || N.GoogleConsent.GCFunctionalityStorage !== ht || N.GoogleConsent.GCPersonalizationStorage !== ht || N.GoogleConsent.GCSecurityStorage !== ht || N.GoogleConsent.GCAdUserData !== ht || N.GoogleConsent.GCAdPersonalization !== ht
    }, en.prototype.checkAndWarnGCMConfig = function() {
        var e = 0,
            t = 0,
            o = 0,
            n = 0;
        if (N.GoogleConsent.GCEnable && !D.otDataLayer.ignore) {
            for (var r = this._window[D.otDataLayer.name], i = 0, s = Object.keys(r); i < s.length; i++) {
                var a = s[i];
                n++, this.isObjectTypeArgs(r[a]) && ("consent" === r[a][0] && "default" === r[a][1] ? t = n : "consent" === r[a][0] && "update" === r[a][1] ? o = n : 0 === e && "config" === r[a][0] && this.isGoogleTag(r[a][1]) && (e = n))
            }
            this.addGCMConfigStatus(e, t, o)
        }
    }, en.prototype.addGCMConfigStatus = function(e, t, o) {
        0 !== e && (e < t ? console.warn("Google Consent mode default value is set after the Google tags were loaded.") : 0 === t ? console.warn("Google Consent mode default or consent value has not been set but the Google tags were loaded.") : (t < e || o < e) && console.info("Google Consent mode is properly configured."))
    }, en.prototype.isGoogleTag = function(e) {
        return e && (-1 < e.indexOf("GT-") || -1 < e.indexOf("G-") || -1 < e.indexOf("AW-"))
    }, en.prototype.isObjectTypeArgs = function(e) {
        return "[object Arguments]" === Object.prototype.toString.call(e)
    };
    var Zo, $o = en;

    function en() {
        this._window = window
    }
    var E, tn = function() {};
    rn.prototype.updateFilterSelection = function(e) {
        o = (e = void 0 === e ? !1 : e) ? (t = w.filterByCategories, "data-optanongroupid") : (t = w.filterByIABCategories, "data-purposeid");
        for (var t, o, n = m("#onetrust-pc-sdk .category-filter-handler").el, r = 0; r < n.length; r++) {
            var i = n[r].getAttribute(o),
                i = -1 < t.indexOf(i);
            v.setCheckedAttribute(null, n[r], i)
        }
    }, rn.prototype.cancelHostFilter = function() {
        for (var e = m("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o = e[t].getAttribute("data-optanongroupid"),
                o = 0 <= w.filterByCategories.indexOf(o);
            v.setCheckedAttribute(null, e[t], o)
        }
    }, rn.prototype.updateHostFilterList = function() {
        for (var e = m("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o, n = e[t].getAttribute("data-optanongroupid");
            e[t].checked && w.filterByCategories.indexOf(n) < 0 ? w.filterByCategories.push(n) : !e[t].checked && -1 < w.filterByCategories.indexOf(n) && (o = w.filterByCategories, w.filterByCategories.splice(o.indexOf(n), 1))
        }
        return w.filterByCategories
    }, rn.prototype.InitializeHostList = function() {
        var e = T.P_Vendor_List + " " + T.P_Host_Cntr + " li";
        w.hosts.hostTemplate = m(e).el[0].cloneNode(!0), w.hosts.hostCookieTemplate = m(T.P_Vendor_List + " " + T.P_Host_Cntr + " " + T.P_Host_Opt + " li").el[0].cloneNode(!0)
    }, rn.prototype.getCookiesForGroup = function(t) {
        var o = [],
            n = [];
        return t.FirstPartyCookies.length && t.FirstPartyCookies.forEach(function(e) {
            n.push(R(R({}, e), {
                groupName: t.GroupName
            }))
        }), t.Hosts.length && t.Hosts.forEach(function(e) {
            o.push(R(R({}, e), {
                isActive: "always active" === L.getGrpStatus(t).toLowerCase(),
                groupName: t.GroupName,
                Type: he.Host
            }))
        }), {
            firstPartyCookiesList: n,
            thirdPartyCookiesList: o
        }
    }, rn.prototype.reactivateSrcTag = function(e) {
        var t = ["src"];
        e.setAttribute(t[0], e.getAttribute("data-" + t[0])), e.removeAttribute("data-src")
    }, rn.prototype.reactivateScriptTag = function(e) {
        var t = e.parentNode,
            o = document.createElement(e.tagName),
            n = (o.innerHTML = S.getInnerHtmlContent(S.getInnerHtmlContent(e.innerHTML)), e.attributes);
        if (0 < n.length)
            for (var r = 0; r < n.length; r++) "type" !== n[r].name ? o.setAttribute(n[r].name, n[r].value, !0) : o.setAttribute("type", "text/javascript", !0);
        t.appendChild(o), t.removeChild(e)
    }, rn.prototype.reactivateTag = function(e, t) {
        var o, n = 0 <= e.className.indexOf("ot-vscat"),
            r = 0 <= e.className.indexOf("optanon-category"),
            i = (n && r ? o = this.getGroupElements(e.className, w.showVendorService) : n ? w.showVendorService ? o = this.getGroupElements(e.className, !0) : this.unBlockTag(t, e) : r && (w.showVendorService ? this.unBlockTag(t, e) : o = this.getGroupElements(e.className, !1)), !0);
        if (o && 0 < o.length) {
            for (var s = 0; s < o.length; s++)
                if (!y.canInsertForGroup(o[s].trim())) {
                    i = !1;
                    break
                }
            i && this.unBlockTag(t, e)
        }
    }, rn.prototype.unBlockTag = function(e, t) {
        e ? this.reactivateSrcTag(t) : this.reactivateScriptTag(t)
    }, rn.prototype.getGroupElements = function(e, t) {
        return t ? null == (t = e.match(/ot-vscat(-[a-zA-Z0-9,]+)+/)) ? void 0 : t[0].split(/ot-vscat-/i)[1].split("-") : null == (t = e.match(/optanon-category(-[a-zA-Z0-9,]+)+/)) ? void 0 : t[0].split(/optanon-category-/i)[1].split("-")
    }, rn.prototype.substitutePlainTextScriptTags = function() {
        var t = this,
            e = [].slice.call(document.querySelectorAll('script[class*="optanon-category"]')),
            o = [].slice.call(document.querySelectorAll('*[class*="optanon-category"]')),
            e = Array.from(new Set(e.concat([].slice.call(document.querySelectorAll('script[class*="ot-vscat"]') || [])))),
            o = Array.from(new Set(o.concat([].slice.call(document.querySelectorAll('*[class*="ot-vscat"]') || []))));
        Array.prototype.forEach.call(o, function(e) {
            "SCRIPT" !== e.tagName && e.hasAttribute("data-src") && t.reactivateTag(e, !0)
        }), Array.prototype.forEach.call(e, function(e) {
            e.hasAttribute("type") && "text/plain" === e.getAttribute("type") && t.reactivateTag(e, !1)
        })
    };
    var on, nn = rn;

    function rn() {}
    o.prototype.getSearchQuery = function(e) {
        var t = this,
            e = e.trim().split(/\s+/g);
        return new RegExp(e.map(function(e) {
            return t.escapeRegExp(e)
        }).join("|") + "(.+)?", "gi")
    }, o.prototype.escapeRegExp = function(e) {
        return e.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")
    }, o.prototype.setGlobalFilteredList = function(e) {
        return w.currentGlobalFilteredList = e
    }, o.prototype.vendorHasPurpose = function(e, t) {
        var o = !1,
            n = parseInt(D.iabGrpIdMap[t]);
        return -1 < t.indexOf(b.IdPatterns.Ft) ? (e.features || []).forEach(function(e) {
            e.featureId === n && (o = !0)
        }) : -1 < t.indexOf(b.IdPatterns.Spl_Ft) ? e.specialFeatures.forEach(function(e) {
            e.featureId === n && (o = !0)
        }) : -1 < t.indexOf(b.IdPatterns.Spl_Pur) ? (e.specialPurposes || []).forEach(function(e) {
            e.purposeId === n && (o = !0)
        }) : (e.purposes.forEach(function(e) {
            e.purposeId === n && (o = !0)
        }), e.legIntPurposes.forEach(function(e) {
            e.purposeId === n && (o = !0)
        })), o
    }, o.prototype.filterList = function(t, e, o) {
        var n, r, i = o && o.length;
        return "" !== t || i ? (i && (i = m("#onetrust-pc-sdk " + T.P_Fltr_Options + " input").el.length, r = !(n = []), i !== o.length ? e.forEach(function(t) {
            r = !0, t.vendorName && o.forEach(function(e) {
                C.vendorHasPurpose(t, e) && n.push(t)
            })
        }) : n = e, r && (n = n.filter(function(e, t, o) {
            return o.indexOf(e) === t
        })), this.setGlobalFilteredList(n)), "" === t ? w.currentGlobalFilteredList : w.currentGlobalFilteredList.filter(function(e) {
            if (e.vendorName) return e.vendorName.toLowerCase().includes(t.toLowerCase())
        })) : this.setGlobalFilteredList(e)
    }, o.prototype.loadVendorList = function(e, t) {
        void 0 === e && (e = "");
        var o = w.vendors,
            o = (w.currentGlobalFilteredList = o.list, e ? (o.searchParam = e, w.filterByIABCategories = [], on.updateFilterSelection(!1)) : o.searchParam !== e ? o.searchParam = "" : t = w.filterByIABCategories, this.filterList(o.searchParam, o.list, t));
        m("#onetrust-pc-sdk " + T.P_Vendor_Content).el[0].scrollTop = 0, w.addtlVendorsList && 0 < Object.keys(w.addtlVendorsList).length && (this.hasGoogleVendors = !0), this.initVendorsData(e, o)
    }, o.prototype.searchVendors = function(e, t, o, n) {
        if (n) {
            var r, i, s = this.getSearchQuery(n),
                a = 0;
            for (r in t) r && (i = o === me.GoogleVendor ? r : t[r].VendorCustomId, i = m("" + e.vendorAccBtn + i).el[0].parentElement, s.lastIndex = 0, s.test(t[r][e.name]) ? (Ht(i, this._displayNull, !0), a++) : Ht(i, "display: none;", !0));
            0 === a ? (m(e.accId).hide(), o === me.GoogleVendor ? this.hasGoogleVendors = !1 : this.hasGenVendors = !1) : (o === me.GoogleVendor ? this.hasGoogleVendors = !0 : this.hasGenVendors = !0, m(e.accId).show()), this.showEmptyResults(!this.hasGoogleVendors && !this.hasIabVendors && !this.hasGenVendors, n)
        } else
            for (var l = m(" " + e.venListId + ' li[style^="display: none"]').el, c = 0; c < l.length; c++) Ht(l[c], this._displayNull, !0);
        n = m("#onetrust-pc-sdk " + e.selectAllEvntHndlr).el[0];
        document.querySelector(e.venListId + ' li:not([style^="display: none"]) ' + e.ctgl + " > input[checked]") ? v.setCheckedAttribute("", n, !0) : v.setCheckedAttribute("", n, !1), document.querySelector(e.venListId + ' li:not([style^="display: none"]) ' + e.ctgl + " > input:not([checked])") ? n.parentElement.classList.add(this.LINE_THROUGH_CLASS) : n.parentElement.classList.remove(this.LINE_THROUGH_CLASS)
    }, o.prototype.initGoogleVendors = function() {
        this.populateAddtlVendors(w.addtlVendorsList), this.venAdtlSelAllTglEvent()
    }, o.prototype.initGenVendors = function() {
        this.populateGeneralVendors(), N.GenVenOptOut && N.GeneralVendors && N.GeneralVendors.length && this.genVenSelectAllTglEvent()
    }, o.prototype.resetAddtlVendors = function() {
        C.searchVendors(C.googleSearchSelectors, w.addtlVendorsList, me.GoogleVendor), this.showConsentHeader()
    }, o.prototype.venAdtlSelAllTglEvent = function() {
        C.selectAllEventHandler({
            vendorsList: '#ot-addtl-venlst li:not([style^="display: none"]) .ot-ven-adtlctgl input',
            selAllCntr: "#onetrust-pc-sdk #ot-selall-adtlvencntr",
            selAllChkbox: "#onetrust-pc-sdk #ot-selall-adtlven-handler"
        })
    }, o.prototype.genVenSelectAllTglEvent = function() {
        var e = {
            vendorsList: T.P_Gven_List + ' li:not([style^="display: none"]) .ot-ven-gvctgl input',
            selAllCntr: "#onetrust-pc-sdk #ot-selall-gnvencntr",
            selAllChkbox: "#onetrust-pc-sdk #ot-selall-gnven-handler"
        };
        C.selectAllEventHandler(e)
    }, o.prototype.handleSelectAllChboxSelection = function(e, t, o) {
        for (var n = !0, r = !0, i = 0; i < e.length && (e[i].checked ? r = !1 : n = !1, n || r); i++);
        n || r ? o.classList.remove(this.LINE_THROUGH_CLASS) : (o.classList.add(this.LINE_THROUGH_CLASS), v.setAriaCheckedAttribute("", t, "mixed")), t.checked = !1, n ? (t.checked = !0, v.setAriaCheckedAttribute("", t, t.checked)) : r && v.setAriaCheckedAttribute("", t, t.checked), v.setCheckedAttribute("", t, t.checked)
    }, o.prototype.selectAllEventHandler = function(e) {
        var t = m(e.vendorsList).el,
            o = m(e.selAllCntr).el[0],
            e = m(e.selAllChkbox).el[0];
        C.handleSelectAllChboxSelection(t, e, o)
    }, o.prototype.vendorLegIntToggleEvent = function() {
        var e = m(T.P_Vendor_Container + ' li:not([style^="display: none"]) .' + T.P_Ven_Ltgl + " input").el,
            t = m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).el[0],
            o = m("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0];
        C.handleSelectAllChboxSelection(e, o, t)
    }, o.prototype.vendorsListEvent = function() {
        var e = m(T.P_Vendor_Container + ' li:not([style^="display: none"]) .' + T.P_Ven_Ctgl + " input").el,
            t = m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Consent_El).el[0],
            o = m("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0];
        C.handleSelectAllChboxSelection(e, o, t)
    }, o.prototype.showEmptyResults = function(e, t, o) {
        void 0 === o && (o = !1);
        var n = m("#onetrust-pc-sdk #no-results");
        e ? this.setNoResultsContent(t, o) : (m("#onetrust-pc-sdk " + T.P_Vendor_Content).removeClass("no-results"), n.length && n.remove())
    }, o.prototype.playSearchStatus = function(e) {
        var t = e ? document.querySelectorAll(T.P_Host_Cntr + " > li") : document.querySelectorAll(T.P_Vendor_Container + ' > li:not([style$="none;"]),' + T.P_Gven_List + ' > li:not([style$="none;"])'),
            o = t.length,
            n = m('#onetrust-pc-sdk [role="status"]');
        o ? n.text(t.length + " " + (e ? "host" : "vendor") + (1 < o ? "s" : "") + " returned.") : n.el[0].textContent = ""
    }, o.prototype.setNoResultsContent = function(e, t) {
        void 0 === t && (t = !1);
        var o, n, r, i = m("#onetrust-pc-sdk #no-results").el[0];
        if (!i) return t = C.getNoResultsFound(t), o = document.createElement("div"), n = document.createElement("p"), t = document.createTextNode(t), r = document.createElement("span"), o.id = "no-results", o.setAttribute("aria-live", "assertive"), o.setAttribute("aria-atomic", "true"), r.id = "user-text", r.innerText = e, n.appendChild(r), n.appendChild(t), o.appendChild(n), m("#onetrust-pc-sdk " + T.P_Vendor_Content).addClass("no-results"), m("#vendor-search-handler").el[0].setAttribute("aria-describedby", o.id), m("#onetrust-pc-sdk " + T.P_Vendor_Content).append(o);
        i.querySelector("span").innerText = e
    }, o.prototype.searchHostList = function(e) {
        var t = {},
            o = [];
        w.showTrackingTech ? (t = w.currentTrackingTech, o = (t = e ? C.getFilteredAdditionaTechtData(e, t) : t).Cookies) : (o = w.currentGlobalFilteredList, e && (o = this.searchList(e, o))), this.initHostData({
            searchString: e,
            cookiesList: o,
            addTechData: t
        })
    }, o.prototype.searchList = function(e, t) {
        var o = this.getSearchQuery(e);
        return t.filter(function(e) {
            return o.lastIndex = 0, o.test(e.DisplayName || e.HostName)
        })
    }, o.prototype.setListSearchValues = function(e) {
        var t = N.PCenterVendorSearchAriaLabel,
            o = N.PCenterVendorListSearch,
            n = N.PCenterVendorsListText,
            r = N.PCenterVendorListFilterAria;
        e === Ee.cookies && (t = N.PCenterCookieSearchAriaLabel, o = N.PCenterCookieListSearch, n = N.PCenterCookiesListText, r = N.PCenterCookieListFilterAria), w.cookieListType !== ye.HostAndGenVen && w.cookieListType !== ye.Host || !w.showTrackingTech || (n = N.AdditionalTechnologiesConfig.PCTrackingTechTitle), document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]').innerText = n;
        m("#filter-btn-handler").el[0].setAttribute(this.ARIA_LABEL_ATTRIBUTE, r + " " + n);
        e = m("#onetrust-pc-sdk " + T.P_Vendor_Search_Input);
        e.el[0].placeholder = o, e.attr("aria-label", t)
    }, o.prototype.initHostData = function(e) {
        var t = e.searchString,
            o = e.cookiesList,
            e = e.addTechData,
            n = (w.optanonHostList = o, !1),
            r = (this.setBackBtnTxt(), m(T.P_Vendor_List + " #select-all-text-container p").html(N.PCenterAllowAllConsentText), C.getHostParentContainer()),
            i = o && 0 === o.length,
            s = (w.showTrackingTech && (i = 0 === e.LocalStorages.length && 0 === e.SessionStorages.length && (0 === e.Cookies.length || 0 === e.Cookies[0].Cookies.length)), w.cookieListType === ye.Host),
            i = (this.showEmptyResults(i, t, s), this.setHostListSearchValues(), m("#filter-btn-handler").el[0]),
            t = h.getVendorPageHeaderText();
        i.setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCenterCookieListFilterAria + " " + t);
        m("#filter-btn-handler title").html(N.PCenterCookieListFilterAria), k.isV2Template && m("#ot-sel-blk span:first-child").html(N.PCenterAllowAllConsentText || N.ConsentText);
        for (var a = document.createDocumentFragment(), l = 0; l < o.length; l++) {
            var c = w.hosts.hostTemplate.cloneNode(!0),
                d = o[l].DisplayName || o[l].HostName;
            this.createHostAccordions(d, c, l), n = this.createHostCheckboxes(d, o, l, c, n), this.populateHostDataIntoDOMElements(c, o, d, l, a)
        }
        C.setCookiesInsideHostContainer(r, a, e);
        s = 1 === o.length && o[0].HostName === N.PCFirstPartyCookieListText;
        if (h.isOptOutEnabled() && !s) {
            for (var i = !n, u = (v.setDisabledAttribute("#onetrust-pc-sdk #select-all-hosts-groups-handler", null, !1), this.applyAriaDisabledToSelectAllCheckbox(i), m("#onetrust-pc-sdk " + T.P_Host_Cntr + " .ot-host-tgl input").el), p = 0; p < u.length; p++) u[p].addEventListener("click", this.hostsListEvent);
            m("#onetrust-pc-sdk " + T.P_Select_Cntr).removeClass("ot-hide"), this.hostsListEvent()
        } else m("#onetrust-pc-sdk " + T.P_Select_Cntr).addClass("ot-hide")
    }, o.prototype.applyAriaDisabledToSelectAllCheckbox = function(e) {
        void 0 === e && (e = !1);
        var t, o = document.querySelector("#onetrust-pc-sdk #select-all-hosts-groups-handler");
        o && (t = null == (t = o.parentElement) ? void 0 : t.querySelector("label"), e ? (o.setAttribute("aria-disabled", "true"), t && (t.style.opacity = "0.8")) : (o.removeAttribute("aria-disabled"), t && (t.style.opacity = "")))
    }, o.prototype.setCookiesInsideHostContainer = function(e, t, o) {
        var n, r;
        w.showTrackingTech && o ? 0 < (o = C.getAdditionalTechnologiesHtml(o)).children.length && ((n = o.querySelector("." + this.TECH_COOKIES_SELECTOR + " " + this.ACC_TXT)) && ((r = e.querySelector("ul" + T.P_Host_Cntr)).appendChild(t), n.appendChild(r)), e.appendChild(o)) : e.appendChild(t)
    }, o.prototype.getHostParentContainer = function() {
        var e = null;
        return w.showTrackingTech ? (e = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Content + " .ot-sdk-column"), C.removeTrackingTechAccorions()) : (e = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Content + " ul" + T.P_Host_Cntr)).innerHTML = S.getInnerHtmlContent(""), e
    }, o.prototype.removeTrackingTechAccorions = function() {
        var e = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Content + " .ot-sdk-column"),
            t = e.querySelector("." + this.TECH_COOKIES_SELECTOR + " ul" + T.P_Host_Cntr);
        if (t ? (t.innerHTML = S.getInnerHtmlContent(""), e.appendChild(t)) : (t = e.querySelector("ul" + T.P_Host_Cntr)).innerHTML = S.getInnerHtmlContent(""), e)
            for (var o = e.querySelectorAll(".ot-add-tech"), n = o.length - 1; 0 <= n; n--) {
                var r = o.item(n);
                e.removeChild(r)
            }
    }, o.prototype.setHostListSearchValues = function() {
        var e = D.pcName;
        N.GeneralVendorsEnabled && (k.isV2Template || e !== at) && this.setListSearchValues(Ee.vendors), N.GeneralVendorsEnabled || !k.isV2Template && e === at || this.setListSearchValues(Ee.cookies)
    }, o.prototype.createHostAccordions = function(e, t, o) {
        var n = t.querySelector("." + T.P_Host_Bx),
            e = (n && v.setHtmlAttributes(n, {
                id: "host-" + o,
                name: "host-" + o,
                "aria-label": e + " " + N.PCViewCookiesText,
                "aria-controls": "ot-host-acc-txt-" + o
            }), t.querySelector(T.P_Acc_Txt));
        e && v.setHtmlAttributes(e, {
            id: "ot-host-acc-txt-" + o,
            role: "region",
            "aria-labelledby": n.id
        })
    }, o.prototype.createHostCheckboxes = function(e, t, o, n, r) {
        var i = h.isOptOutEnabled(),
            s = k.isV2Template,
            a = D.pcName;
        return !i || t[o].isFirstParty ? (i = n.querySelector(".ot-host-tgl")) && i.parentElement.removeChild(i) : (i = void 0, s ? ((i = E.chkboxEl.cloneNode(!0)).classList.add("ot-host-tgl"), i.querySelector("input").classList.add("host-checkbox-handler"), a === at ? n.querySelector(T.P_Host_Hdr).insertAdjacentElement("beforebegin", i) : n.querySelector(T.P_Tgl_Cntr).insertAdjacentElement("beforeend", i)) : i = n.querySelector(".ot-host-tgl"), v.setHtmlAttributes(i.querySelector("input"), {
            id: "ot-host-chkbox-" + o,
            "aria-label": e,
            hostId: t[o].HostId,
            ckType: t[o].Type
        }), i.querySelector("label").setAttribute("for", "ot-host-chkbox-" + o), (t[o].Type === he.GenVendor ? w.genVendorsConsent[t[o].HostId] : -1 !== w.hostsConsent.indexOf(t[o].HostId + ":1")) ? (v.setCheckedAttribute(null, i.querySelector("input"), !0), t[o].isActive ? v.setDisabledAttribute(null, i.querySelector("input"), !0) : r = r || !0) : (r = !0, v.setCheckedAttribute(null, i.querySelector("input"), !1)), t[o].isAlwaysInactive && (i.querySelector("input").style.pointerEvents = "none"), i.querySelector(T.P_Label_Txt).innerText = e), r
    }, o.prototype.populateHostDataIntoDOMElements = function(t, o, e, n, r) {
        var i, s = this,
            a = k.isV2Template,
            l = D.pcName,
            l = (N.PCAccordionStyle === ce.PlusMinus ? t.querySelector(T.P_Acc_Header).insertAdjacentElement("afterbegin", E.plusMinusEl.cloneNode(!0)) : a && (i = E.arrowEl.cloneNode(!0), l === at ? t.querySelector(T.P_Host_View_Cookies).insertAdjacentElement("afterend", i) : t.querySelector(T.P_Tgl_Cntr).insertAdjacentElement("beforeend", i)), N.AddLinksToCookiepedia && !o[n].isFirstParty && (e = '\n                            <a  class="cookie-label"\n                                href="https://cookiepedia.co.uk/host/' + o[n].HostName + '"\n                                rel="noopener noreferrer"\n                                target="_blank"\n                            >\n                                ' + e + '&nbsp;<span class="ot-scrn-rdr">' + N.NewWinTxt + "</span>\n                            </a>\n                        "), t.querySelector(T.P_Host_Title).innerHTML = S.getInnerHtmlContent(e), t.querySelector(T.P_Host_Desc).innerHTML = S.getInnerHtmlContent(o[n].Description), o[n].PrivacyPolicy && N.pcShowCookieHost && t.querySelector(T.P_Host_Desc).insertAdjacentHTML("afterend", S.getInnerHtmlContent('<a href="' + o[n].PrivacyPolicy + '" rel="noopener noreferrer" target="_blank">' + (a ? N.PCGVenPolicyTxt : N.PCCookiePolicyText) + '&nbsp;<span class="ot-scrn-rdr">' + N.NewWinTxt + "</span></a>")), t.querySelector(T.P_Host_View_Cookies));
        !w.showGeneralVendors || o[n].Cookies && o[n].Cookies.length ? N.PCViewCookiesText && (l.innerHTML = S.getInnerHtmlContent(N.PCViewCookiesText)) : (v.removeChild(l), m(t).addClass("ot-hide-acc")), o[n].Description && N.pcShowCookieHost || (i = t.querySelector(T.P_Host_Desc)).parentElement.removeChild(i), m(t.querySelector(T.P_Host_Opt)).html("");
        return h.addExternalIconForLinks(function(e) {
            return t.querySelectorAll(e)
        }), null != (a = o[n].Cookies) && a.forEach(function(e) {
            e = s.getCookieElement(e, o[n]);
            m(t.querySelector(T.P_Host_Opt)).append(e)
        }), r.append(t), e
    }, o.prototype.hostsListEvent = function() {
        var e = m("#onetrust-pc-sdk " + T.P_Host_Cntr + " .ot-host-tgl input").el,
            t = m("#onetrust-pc-sdk #" + T.P_Sel_All_Host_El).el[0],
            o = m("#onetrust-pc-sdk #select-all-hosts-groups-handler").el[0],
            n = m("#onetrust-pc-sdk " + T.P_Cnsnt_Header).el[0];
        C.handleSelectAllChboxSelection(e, o, t), o && n && o.setAttribute(this.ARIA_LABEL_ATTRIBUTE, n.textContent + " " + N.PCenterSelectAllVendorsText)
    }, o.prototype.loadHostList = function(e, t) {
        var o = {},
            n = [],
            n = w.showTrackingTech ? (o = C.getAdditionalTechnologiesDataFromGroup(t), (w.currentTrackingTech = o).Cookies) : C.getCombinedCookieList(t);
        w.currentGlobalFilteredList = n, this.initHostData({
            searchString: e,
            cookiesList: n,
            addTechData: o
        })
    }, o.prototype.getCombinedCookieList = function(e) {
        var t, o = [],
            n = [];
        return w.cookieListType !== ye.GenVen && (n = (t = C.getFirstsAndThirdCookisFromGroups(e)).firstPartyCookiesList, o = t.thirdPartyCookiesList, n.length) && o.unshift({
            HostName: N.PCFirstPartyCookieListText,
            DisplayName: N.PCFirstPartyCookieListText,
            HostId: this.FIRST_PARTY_COOKIES_GROUP_NAME,
            isFirstParty: !0,
            Cookies: n,
            Description: ""
        }), w.showGeneralVendors ? (n = this.getFilteredGenVendorsList(e, t = []), U(o, this.mapGenVendorListToHostFormat(n, t))) : o
    }, o.prototype.mapGenVendorListToHostFormat = function(e, t) {
        return void 0 === t && (t = []), e.map(function(e) {
            return {
                Cookies: e.Cookies,
                DisplayName: e.Name,
                HostName: e.Name,
                HostId: e.VendorCustomId,
                Description: e.Description,
                Type: he.GenVendor,
                PrivacyPolicy: e.PrivacyPolicyUrl,
                isActive: -1 < w.alwaysActiveGenVendors.indexOf(e.VendorCustomId),
                isAlwaysInactive: -1 < t.indexOf(e.VendorCustomId)
            }
        })
    }, o.prototype.mapGenVendorToHostFormat = function(e) {
        return {
            Cookies: e.Cookies,
            DisplayName: e.Name,
            HostName: e.Name,
            HostId: e.VendorCustomId,
            Description: e.Description,
            Type: he.GenVendor
        }
    }, o.prototype.getFilteredGenVendorsList = function(o, t) {
        void 0 === t && (t = []);
        var e, n = [],
            r = [],
            i = [],
            s = [];
        return o.length ? (N.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                var t; - 1 !== o.indexOf(e.CustomGroupId) && (t = L.getGrpStatus(e).toLowerCase(), e.GeneralVendorsIds) && e.GeneralVendorsIds.forEach(function(e) {
                    n.push(e), (t === f.ALWAYS_INACTIVE ? r : i).push(e)
                })
            })
        }), r.forEach(function(e) {
            -1 === i.indexOf(e) && t.push(e)
        }), e = N.GeneralVendors, n.length ? e.filter(function(e) {
            if (-1 < n.indexOf(e.VendorCustomId)) return e
        }) : s) : N.GeneralVendors
    }, o.prototype.initVendorsData = function(e, t) {
        var o = this,
            n = t,
            t = w.vendors.list,
            r = (this.setBackBtnTxt(), m(T.P_Vendor_List + " #select-all-text-container p").html(N.PCenterAllowAllConsentText), C.setConsentLegIntAndHeaderText(), h.getVendorPageHeaderText());
        if (m("#onetrust-pc-sdk #filter-btn-handler").el[0].setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCenterVendorListFilterAria + " " + r), m("#onetrust-pc-sdk #filter-btn-handler title").html(N.PCenterVendorListFilterAria), this.hasIabVendors = 0 < n.length, this.showEmptyResults(!this.hasGoogleVendors && !this.hasIabVendors && !this.hasGenVendors, e, !1), C.hideOrShowVendorList(n), m("#onetrust-pc-sdk " + T.P_Vendor_Container + " ." + T.P_Ven_Bx).length !== t.length && this.attachVendorsToDOM(), n.length !== t.length) t.forEach(function(e) {
            var t = m(T.P_Vendor_Container + " #IAB" + e.vendorId).el[0].parentElement; - 1 === n.indexOf(e) ? Ht(t, "display: none;", !0) : Ht(t, o._displayNull, !0)
        });
        else
            for (var i = m(T.P_Vendor_Container + ' li[style^="display: none"]').el, s = 0; s < i.length; s++) Ht(i[s], this._displayNull, !0);
        !k.isV2Template && D.pcName === at || this.setListSearchValues(Ee.vendors);
        r = document.querySelector("#vdr-lst-dsc");
        !r && N.PCenterVendorListDescText && ((r = document.createElement("p")).id = "vdr-lst-dsc", m(r).html(N.PCenterVendorListDescText), D.pcName !== at && D.pcName !== rt ? (e = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Title_Elm)) && e.insertAdjacentElement("afterend", r) : (t = document.querySelector(T.P_Vendor_Content + " .ot-sdk-row")) && t.insertAdjacentElement("beforebegin", r)), m("#onetrust-pc-sdk " + T.P_Select_Cntr).removeClass("ot-hide"), this.vendorsListEvent(), D.legIntSettings.PAllowLI && this.vendorLegIntToggleEvent()
    }, o.prototype.setConsentLegIntAndHeaderText = function() {
        k.isV2Template && (m("#ot-sel-blk span:first-child").html(N.PCenterAllowAllConsentText || N.ConsentText), m("#ot-sel-blk span:last-child").html(N.LegitInterestText), m("#onetrust-pc-sdk " + T.P_Cnsnt_Header).html(N.PCenterAllowAllConsentText), D.legIntSettings.PAllowLI && !D.legIntSettings.PShowLegIntBtn && m("#onetrust-pc-sdk .ot-sel-all-hdr .ot-li-hdr").html(N.PCenterLegitInterestText), D.legIntSettings.PAllowLI && !D.legIntSettings.PShowLegIntBtn || Ht(m("#ot-sel-blk span:first-child").el[0], "max-width: 100%;", !0))
    }, o.prototype.hideOrShowVendorList = function(e) {
        0 === e.length ? m("#ot-lst-cnt .ot-acc-cntr").hide() : m("#ot-lst-cnt .ot-acc-cntr").show(), w.showTrackingTech && C.removeTrackingTechAccorions()
    }, o.prototype.updateVendorsDOMToggleStatus = function(e, t) {
        void 0 === t && (t = !1);
        for (var o = m(T.P_Vendor_Container + " " + T.P_Tgl_Cntr).el, n = 0; n < o.length; n++) {
            var r = o[n].querySelector("." + T.P_Ven_Ctgl + " input"),
                i = o[n].querySelector("." + T.P_Ven_Ltgl + " input");
            t ? r && v.setCheckedAttribute("", r, !1) : (r && v.setCheckedAttribute("", r, e), i && v.setCheckedAttribute("", i, e))
        }
        var s = m("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0],
            s = (s && (s.parentElement.classList.remove(this.LINE_THROUGH_CLASS), v.setCheckedAttribute("", s, !!t || e)), m("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0]);
        s && (s.parentElement.classList.remove(this.LINE_THROUGH_CLASS), v.setCheckedAttribute("", s, !t && e)), N.UseGoogleVendors && (t ? this.updateGoogleCheckbox(!1) : this.updateGoogleCheckbox(e)), w.showGeneralVendors && N.GenVenOptOut && this.updateGenVenCheckbox(e)
    }, o.prototype.updateGenVenCheckbox = function(e) {
        for (var t = m(T.P_Gven_List + " .ot-ven-gvctgl input").el, o = 0; o < t.length; o++) v.setCheckedAttribute("", t[o], e);
        var n = m("#onetrust-pc-sdk #ot-selall-gnven-handler").el[0];
        n && (n.parentElement.classList.remove(this.LINE_THROUGH_CLASS), v.setCheckedAttribute("", n, e))
    }, o.prototype.updateGoogleCheckbox = function(e) {
        for (var t = m("#ot-addtl-venlst .ot-tgl-cntr input").el, o = 0; o < t.length; o++) v.setCheckedAttribute("", t[o], e);
        var n = m("#onetrust-pc-sdk #ot-selall-adtlven-handler").el[0];
        n && (n.parentElement.classList.remove(this.LINE_THROUGH_CLASS), v.setCheckedAttribute("", n, e))
    }, o.prototype.updateVendorDisclosure = function(e, t) {
        var r, i, e = m(T.P_Vendor_Container + " #IAB" + e).el[0].parentElement;
        t && t.disclosures && (r = e.querySelector(T.P_Ven_Dets), (e = (i = e.querySelector(T.P_Ven_Disc).cloneNode(!0)).cloneNode(!0)).innerHTML = S.getInnerHtmlContent(this.getHeadingElement(N.PCenterVendorListDisclosure + ": ", "5")), r.insertAdjacentElement("beforeend", e), t.disclosures.forEach(function(e) {
            var t, o = i.cloneNode(!0),
                n = "<p>" + N.PCenterVendorListStorageIdentifier + " </p> <p>" + (e.name || e.identifier) + " </p>";
            e.type && (n += "<p>" + N.PCenterVendorListStorageType + " </p> <p>" + e.type + " </p>"), e.maxAgeSeconds && (t = v.calculateCookieLifespan(e.maxAgeSeconds), n += "<p>" + N.PCenterVendorListLifespan + " </p> <p>" + t + " </p>"), e.domain && (n += "<p>" + N.PCenterVendorListStorageDomain + " </p> <p>" + e.domain + " </p>"), e.purposes && (n += "<p>" + N.PCenterVendorListStoragePurposes + ' </p><div class="disc-pur-cont">', e.purposes.forEach(function(e) {
                e = null == (e = D.iabGroups.purposes[e]) ? void 0 : e.name;
                e && (n += ' <p class="disc-pur">' + e + " </p>")
            }), n += "</div>"), o.innerHTML = S.getInnerHtmlContent(n), r.insertAdjacentElement("beforeend", o)
        }), this.updateDomainsUsageInDisclosures(t, i, r))
    }, o.prototype.getHeadingElement = function(e, t, o) {
        var n;
        return null != (n = k.moduleInitializer) && n.SEOOptimization ? '<p role="heading" aria-level="' + t + '" class="' + o + '">' + e + "</p>" : "<h" + t + ' class="' + o + '">' + e + "</h" + t + ">"
    }, o.prototype.updateDomainsUsageInDisclosures = function(e, n, r) {
        var t;
        e.domains && e.domains.length && ((t = n.cloneNode(!0)).innerHTML = S.getInnerHtmlContent(this.getHeadingElement(N.PCVLSDomainsUsed + ": ", "5")), r.insertAdjacentElement("beforeend", t), e.domains.forEach(function(e) {
            var t, o = n.cloneNode(!0);
            e.domain && (t = "<p>" + N.PCenterVendorListStorageDomain + " </p> <p>" + e.domain + " </p>"), e.use && (t += "<p>" + N.PCVLSUse + " </p> <p>" + e.use + " </p>"), o.innerHTML = S.getInnerHtmlContent(t), r.insertAdjacentElement("beforeend", o)
        }))
    }, o.prototype.addDescriptionElement = function(e, t) {
        var o = document.createElement("p");
        o.innerHTML = S.getInnerHtmlContent(t || ""), e.parentNode.insertBefore(o, e)
    }, o.prototype.setVdrConsentTglOrChbox = function(e, t, o, n, r, i) {
        var s, a, l = w.vendorsSetting[e],
            t = t.cloneNode(!0);
        l.consent && (t.classList.add(T.P_Ven_Ctgl), l = -1 !== S.inArray(e + ":true", w.vendors.selectedVendors), s = t.querySelector("input"), k.isV2Template && (s.classList.add("vendor-checkbox-handler"), a = t.querySelector(this.LABEL_STATUS), N.PCShowConsentLabels ? a.innerHTML = S.getInnerHtmlContent(l ? N.PCActiveText : N.PCInactiveText) : v.removeChild(a)), v.setCheckedAttribute("", s, l), v.setHtmlAttributes(s, {
            id: T.P_Vendor_CheckBx + "-" + i,
            vendorid: e,
            "aria-label": o
        }), t.querySelector("label").setAttribute("for", T.P_Vendor_CheckBx + "-" + i), t.querySelector(T.P_Label_Txt).textContent = o, D.pcName === at ? N.PCTemplateUpgrade ? n.insertAdjacentElement("beforeend", t) : m(n).append(t) : n.insertBefore(t, r))
    }, o.prototype.setVndrLegIntTglTxt = function(e, t) {
        e = e.querySelector(this.LABEL_STATUS);
        N.PCShowConsentLabels ? e.innerHTML = S.getInnerHtmlContent(t ? N.PCActiveText : N.PCInactiveText) : v.removeChild(e)
    }, o.prototype.setVdrLegIntTglOrChbx = function(t, e, o, n, r, i, s) {
        var a, l = w.vendorsSetting[t],
            o = o.cloneNode(!0),
            c = null == (c = w.vendors.list.find(function(e) {
                return e.vendorId === t
            }).legIntPurposes) ? void 0 : c.length;
        l.legInt && !l.specialPurposesOnly && c && (c = -1 !== S.inArray(t + ":true", w.vendors.selectedLegIntVendors), D.legIntSettings.PShowLegIntBtn ? (a = B.generateLegIntButtonElements(c, t, !0, n), e.querySelector(T.P_Acc_Txt).insertAdjacentHTML("beforeend", a), (a = e.querySelector(".ot-remove-objection-handler")) && Ht(a, a.getAttribute("data-style"))) : (a = o.querySelector("input"), k.isV2Template && (a.classList.add("vendor-checkbox-handler"), this.setVndrLegIntTglTxt(o, c)), o.classList.add(T.P_Ven_Ltgl), a.classList.remove("vendor-checkbox-handler"), a.classList.add("vendor-leg-checkbox-handler"), v.setCheckedAttribute("", a, c), v.setHtmlAttributes(a, {
            id: T.P_Vendor_LegCheckBx + "-" + r,
            "leg-vendorid": t,
            "aria-label": n
        }), o.querySelector("label").setAttribute("for", T.P_Vendor_LegCheckBx + "-" + r), o.querySelector(T.P_Label_Txt).textContent = n, e.querySelector("." + T.P_Ven_Ctgl) && (i = e.querySelector("." + T.P_Ven_Ctgl)), D.pcName !== at || s.children.length ? s.insertBefore(o, i) : m(s).append(o), l.consent || D.pcName !== at || o.classList.add(T.P_Ven_Ltgl_Only)))
    }, o.prototype.setVndrSplPurSection = function(e, t) {
        var o = this,
            n = e.querySelector(".spl-purpose"),
            e = e.querySelector(".spl-purpose-grp"),
            r = e.cloneNode(!0);
        e.parentElement.removeChild(e), D.isIab2orv2Template && t.specialPurposes.forEach(function(e) {
            m(r.querySelector(o.CONSENT_CATEGORY)).text(e.purposeName), n.insertAdjacentHTML("afterend", S.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.specialPurposes.length ? n.parentElement.removeChild(n) : m(n.querySelector("p")).text(N.SpecialPurposesText)
    }, o.prototype.setVndrFtSection = function(e, t) {
        var o = this,
            n = e.querySelector(".vendor-feature"),
            e = e.querySelector(".vendor-feature-group"),
            r = e.cloneNode(!0);
        e.parentElement.removeChild(e), m(n.querySelector("p")).text(N.FeaturesText), t.features.forEach(function(e) {
            m(r.querySelector(o.CONSENT_CATEGORY)).text(e.featureName), n.insertAdjacentHTML("afterend", S.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.features.length && n.parentElement.removeChild(n)
    }, o.prototype.setVndrSplFtSection = function(e, t) {
        var o = this,
            n = e.querySelector(".vendor-spl-feature"),
            e = e.querySelector(".vendor-spl-feature-grp"),
            r = e.cloneNode(!0);
        n.parentElement.removeChild(e), D.isIab2orv2Template && t.specialFeatures.forEach(function(e) {
            m(r.querySelector(o.CONSENT_CATEGORY)).text(e.featureName), n.insertAdjacentHTML("afterend", S.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.specialFeatures.length ? n.parentElement.removeChild(n) : m(n.querySelector("p")).text(N.SpecialFeaturesText)
    }, o.prototype.setVndrAccTxt = function(e, t) {
        t = t.querySelector(T.P_Acc_Txt);
        t && v.setHtmlAttributes(t, {
            id: "IAB-ACC-TXT" + e,
            "aria-labelledby": "IAB-ACC-TXT" + e,
            role: "region"
        })
    }, o.prototype.setVndrDisclosure = function(e, t, o) {
        t.deviceStorageDisclosureUrl && (v.setHtmlAttributes(o, {
            "disc-vid": e
        }), w.discVendors[e] = {
            isFetched: !1,
            disclosureUrl: t.deviceStorageDisclosureUrl
        })
    }, o.prototype.setVndrListSelectAllChkBoxs = function() {
        var e = m("#onetrust-pc-sdk " + T.P_Sel_All_Vendor_Consent_Handler).el[0],
            e = (e && e.setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCenterSelectAllVendorsText + " " + N.LegitInterestText), m("#onetrust-pc-sdk " + T.P_Sel_All_Vendor_Leg_Handler).el[0]);
        e && e.setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCIABVendorsText + ", " + N.PCenterSelectAllVendorsText)
    }, o.prototype.setVndrConsentPurposes = function(e, t, o) {
        var n = this,
            r = e.querySelector(".vendor-consent-group"),
            i = e.querySelector(".vendor-option-purpose"),
            s = r.cloneNode(!0),
            a = e.querySelector(".legitimate-interest"),
            l = !1;
        return r.parentElement.removeChild(r), t.consent && (m(i.querySelector("p")).text(N.ConsentPurposesText), o.purposes.forEach(function(e) {
            m(s.querySelector(n.CONSENT_CATEGORY)).text(e.purposeName);
            e = s.querySelector(".consent-status");
            e && s.removeChild(e), a.insertAdjacentHTML("beforebegin", S.getInnerHtmlContent(s.outerHTML)), l = !0
        })), t.consent || i.parentElement.removeChild(i), l
    }, o.prototype.getVndrTglCntr = function(e) {
        return k.isV2Template ? E.chkboxEl.cloneNode(!0) : e.querySelector(".ot-checkbox")
    }, o.prototype.attachVendorsToDOM = function() {
        for (var u, p, C = this, g = w.vendors.list, h = w.vendors.vendorTemplate.cloneNode(!0), y = (w.discVendors = {}, k.isV2Template && (u = h.querySelector(".ot-ven-pur").cloneNode(!0), p = h.querySelector(T.P_Ven_Disc).cloneNode(!0), m(h.querySelector(".ot-ven-dets")).html("")), document.createDocumentFragment()), f = this, e = 0; e < g.length; e++)(e => {
            var t, o, n = h.cloneNode(!0),
                r = g[e].vendorId,
                i = g[e].vendorName,
                s = n.querySelector("." + T.P_Ven_Bx),
                a = w.vendorsSetting[r],
                l = (v.setHtmlAttributes(s, {
                    id: "IAB" + r,
                    name: "IAB" + r,
                    "aria-controls": "IAB-ACC-TXT" + r,
                    "aria-label": i
                }), s.nextElementSibling.setAttribute("for", "IAB" + r), n.querySelector(T.P_Ven_Name).innerText = i, f.updateIABLinksDOM(g[e], n), f.getVndrTglCntr(n)),
                c = n.querySelector(T.P_Tgl_Cntr),
                d = (k.isV2Template || l.parentElement.removeChild(l), n.querySelector(T.P_Arrw_Cntr));
            f.setVdrConsentTglOrChbox(r, l, i, c, d, e), f.setVdrLegIntTglOrChbx(r, n, l, i, e, d, c), k.isV2Template && (c.insertAdjacentElement("beforeend", E.arrowEl.cloneNode(!0)), N.PCAccordionStyle !== ce.Caret) && n.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)), f.setVndrAccTxt(r, n), f.setVndrDisclosure(r, g[e], s), k.isV2Template ? f.populateVendorDetailsHtml(n, u, g[e], p) : (t = n.querySelector(".legitimate-interest"), l = n.querySelector(".legitimate-interest-group"), o = l.cloneNode(!0), p = n.querySelector(T.P_Ven_Disc), i = n.querySelector(T.P_Ven_Dets), d = p.cloneNode(!0), p.parentElement.removeChild(p), f.attachVendorDisclosure(d, g[e]), i.insertAdjacentElement("afterbegin", d), f.setVndrConsentPurposes(n, a, g[e]), c = o.querySelector(".vendor-opt-out-handler"), D.isIab2orv2Template && c.parentElement.removeChild(c), l.parentElement.removeChild(l), a.legInt && (m(t.querySelector("p")).text(N.LegitimateInterestPurposesText), D.legIntSettings.PAllowLI) && D.isIab2orv2Template && g[e].legIntPurposes.forEach(function(e) {
                m(o.querySelector(C.CONSENT_CATEGORY)).text(e.purposeName), t.insertAdjacentHTML("afterend", S.getInnerHtmlContent(o.outerHTML))
            }), a.legInt || t.parentElement.removeChild(t), f.setVndrSplPurSection(n, g[e]), f.setVndrFtSection(n, g[e]), f.setVndrSplFtSection(n, g[e]), (r = s.parentElement.querySelector(".vendor-purposes p")).parentElement.removeChild(r)), y.appendChild(n), f.setVndrListSelectAllChkBoxs()
        })(e);
        document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Container).append(y)
    }, o.prototype.updateIABLinksDOM = function(e, t) {
        var o, n = e.vendorName,
            r = t.querySelector(T.P_Ven_Link),
            t = t.querySelector(T.P_Ven_Leg_Claim),
            i = D.isTcfV2Template ? e.vendorPrivacyUrl : e.policyUrl,
            s = !1;
        N.BannerRequireExternalLinks && (k.fp.CMPIconSprite && N.OTExternalLinkLogo && !N.BannerExternalLinksLogo ? (s = !0, o = h.updateCorrectUrl(N.OTExternalLinkLogo), o = N.BannerExternalLinksLogo ? h.updateCorrectUrl(N.BannerExternalLinksLogo) : o, o = "<svg class='ot-ext-lnk'>\n                        <use href='#" + new URL(o, window.location.origin).pathname.split("/").pop().split(".").shift() + "'></use>\n                        </svg>") : r.classList.add(this.EXT_LINK_CLASS)), v.setHtmlAttributes(r, {
            href: i,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), r.innerHTML = S.getInnerHtmlContent(N.PCenterViewPrivacyPolicyText + "&nbsp;<span class='ot-scrn-rdr'>" + n + " " + N.NewWinTxt + "</span>"), N.BannerRequireExternalLinks && s && (h.hasAdjacentExternalLinkSvg(r) || r.insertAdjacentHTML("afterend", S.getInnerHtmlContent(o))), D.isTcfV2Template && e.legIntClaim && 0 < N.PCIABVendorLegIntClaimText.trim().length ? (v.setHtmlAttributes(t, {
            href: e.legIntClaim,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), t.innerHTML = S.getInnerHtmlContent(N.PCIABVendorLegIntClaimText + "&nbsp;<span class='ot-scrn-rdr'>" + n + " " + N.NewWinTxt + "</span>"), N.BannerRequireExternalLinks && (s ? t.insertAdjacentHTML("afterend", S.getInnerHtmlContent(o)) : t.classList.add(this.EXT_LINK_CLASS))) : t.remove()
    }, o.prototype.populateVendorDetailsHtml = function(e, o, t, n) {
        function r(e, t, o, n, r) {
            if (void 0 === r && (r = !1), t.length) {
                for (var i = u.getHeadingElement(String(N[e]), "5") + "<ul>", s = 0, a = t; s < a.length; s++) {
                    var l, c = a[s],
                        d = o(c);
                    r && null != (l = n) && l[c.purposeId] && (d += " (" + (l = n[c.purposeId].retention) + " " + (1 === l ? N.PCenterVendorListLifespanDay : N.PCenterVendorListLifespanDays) + ")"), i += "<li><p>" + d + "</p></li>"
                }
                p(i += "</ul>")
            }
        }
        var i, u = this,
            s = e.querySelector(".ot-ven-dets"),
            e = w.vendorsSetting[t.vendorId],
            p = function(e) {
                var t = o.cloneNode(!0);
                t.innerHTML = S.getInnerHtmlContent(e), s.insertAdjacentElement("beforeend", t)
            },
            n = n.cloneNode(!0);
        this.attachVendorDisclosure(n, t), s.insertAdjacentElement("beforeend", n), D.isTcfV2Template && null != (n = t.dataDeclaration) && n.length && r("PCVListDataDeclarationText", t.dataDeclaration, function(e) {
            return e.Name
        }), D.isTcfV2Template && null != (null == (n = t.dataRetention) ? void 0 : n.stdRetention) && (i = 1 === (n = t.dataRetention.stdRetention) ? N.PCenterVendorListLifespanDay : N.PCenterVendorListLifespanDays, n = this.getHeadingElement(N.PCVListDataRetentionText, "5") + ("<li><p>" + N.PCVListStdRetentionText) + " (" + n + " " + i + ")</p></li>", p(n)), e.consent && r("ConsentPurposesText", t.purposes, function(e) {
            return e.purposeName
        }, null == (i = t.dataRetention) ? void 0 : i.purposes, !0), e.legInt && null != (n = t.legIntPurposes) && n.length && r("LegitimateInterestPurposesText", t.legIntPurposes, function(e) {
            return e.purposeName
        }), D.isIab2orv2Template && null != (i = t.specialPurposes) && i.length && r("SpecialPurposesText", t.specialPurposes, function(e) {
            return e.purposeName
        }, null == (e = t.dataRetention) ? void 0 : e.specialPurposes, !0), null != (n = t.features) && n.length && r("FeaturesText", t.features, function(e) {
            return e.featureName
        }), D.isIab2orv2Template && null != (i = t.specialFeatures) && i.length && r("SpecialFeaturesText", t.specialFeatures, function(e) {
            return e.featureName
        })
    }, o.prototype.InitializeVendorList = function() {
        var e;
        w.vendors.list = w.iabData ? w.iabData.vendors : null, w.vendors.vendorTemplate = m(T.P_Vendor_Container + " li").el[0].cloneNode(!0), m("#onetrust-pc-sdk " + T.P_Vendor_Container).html(""), k.isV2Template || D.pcName !== at || (e = w.vendors.vendorTemplate.querySelectorAll(T.P_Acc_Header), (e = D.legIntSettings.PAllowLI && D.isIab2orv2Template ? e[0] : e[1]).parentElement.removeChild(e))
    }, o.prototype.cancelVendorFilter = function() {
        for (var e = m("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o = e[t].getAttribute("data-purposeid"),
                o = 0 <= w.filterByIABCategories.indexOf(o);
            v.setCheckedAttribute(null, e[t], o)
        }
    }, o.prototype.attachVendorDisclosure = function(e, t) {
        var o = "";
        t.cookieMaxAge && (o += this.getHeadingElement(N.PCenterVendorListLifespan + " :", "5")), o += "<span> " + t.cookieMaxAge + "</span>", t.usesNonCookieAccess && (o += "<p>" + N.PCenterVendorListNonCookieUsage + "</p>"), e.innerHTML = S.getInnerHtmlContent(o)
    }, o.prototype.updateVendorFilterList = function() {
        for (var e = m("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o, n = e[t].getAttribute("data-purposeid");
            e[t].checked && w.filterByIABCategories.indexOf(n) < 0 ? w.filterByIABCategories.push(n) : !e[t].checked && -1 < w.filterByIABCategories.indexOf(n) && (o = w.filterByIABCategories, w.filterByIABCategories.splice(o.indexOf(n), 1))
        }
        return w.filterByIABCategories
    }, o.prototype.saveVendorStatus = function(e) {
        var t = w.vendors,
            o = w.oneTrustIABConsent,
            e = ((e = void 0 === e ? !1 : e) || (o.purpose = t.selectedPurpose.slice(), o.specialFeatures = t.selectedSpecialFeatures.slice()), o.legimateInterest = t.selectedLegInt.slice(), o.vendors = t.selectedVendors.slice(), o.legIntVendors = t.selectedLegIntVendors.slice(), w.addtlVendors);
        e.vendorConsent = Object.keys(e.vendorSelected)
    }, o.prototype.updateIabVariableReference = function() {
        var e = w.oneTrustIABConsent,
            t = w.vendors,
            o = (t.selectedPurpose = e.purpose.slice(), t.selectedLegInt = e.legimateInterest.slice(), t.selectedVendors = e.vendors.slice(), t.selectedLegIntVendors = e.legIntVendors.slice(), t.selectedSpecialFeatures = e.specialFeatures.slice(), w.addtlVendors);
        o.vendorSelected = {}, o.vendorConsent.forEach(function(e) {
            o.vendorSelected[e] = !0
        })
    }, o.prototype.allowAllhandler = function() {
        js.initializeIABData(!0, !1)
    }, o.prototype.rejectAllHandler = function(e) {
        js.initializeIABData(!1, !0, e = void 0 === e ? !1 : e)
    }, o.prototype.populateAddtlVendors = function(e) {
        var t, o, n = this.getArrowElement(),
            r = this.setupIABAccordion(n),
            i = this.setupGoogleVendorsAccordion(n, r),
            s = this.prepareVendorTemplate();
        for (t in e) e[t] && (o = this.createAdditionalVendorItem(s, t, e[t]), m(i.querySelector("#ot-addtl-venlst")).append(o));
        m(this.LST_CNT_COLUMN_SELECTOR).append(i), m("#onetrust-pc-sdk").on("click", "#ot-pc-lst .ot-acc-cntr > input", function(e) {
            v.setCheckedAttribute(null, e.target, e.target.checked)
        }), this.showConsentHeader()
    }, o.prototype.setupIABAccordion = function(e) {
        var t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"),
            o = t.cloneNode(!0),
            t = (v.removeChild(o.querySelector("#ot-selall-hostcntr")), v.removeChild(t.querySelector("#ot-selall-vencntr")), v.removeChild(t.querySelector("#ot-selall-licntr")), E.accordionEl.cloneNode(!0));
        return t.classList.add("ot-iab-acc"), t.querySelector(C.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", e.cloneNode(!0)), t.querySelector(C.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", S.getInnerHtmlContent(this.getHeadingElement(N.PCIABVendorsText, "4", this.VEN_TITLE_CLASS))), t.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", o), t.querySelector(this.ACC_TXT).insertAdjacentElement("beforeEnd", m("#ot-ven-lst").el[0]), m(this.LST_CNT_COLUMN_SELECTOR).append(t), t.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCIABVendorsText), this.iabAccInit = !0, o
    }, o.prototype.setupGoogleVendorsAccordion = function(e, t) {
        var t = t.cloneNode(!0),
            o = (v.removeChild(t.querySelector("#ot-selall-licntr")), t.querySelector(".ot-chkbox").id = "ot-selall-adtlvencntr", t.querySelector("input").id = "ot-selall-adtlven-handler", t.querySelector("label").setAttribute("for", "ot-selall-adtlven-handler"), E.accordionEl.cloneNode(!0));
        return o.querySelector(C.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", e.cloneNode(!0)), o.querySelector(C.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", S.getInnerHtmlContent(this.getHeadingElement(N.PCGoogleVendorsText, "4", this.VEN_TITLE_CLASS))), o.querySelector(C.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", t), o.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeEnd", S.getInnerHtmlContent("<ul id='ot-addtl-venlst'></ul>")), o.classList.add("ot-adtlv-acc"), o.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCGoogleVendorsText), o.querySelector("#ot-selall-adtlven-handler").setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCGoogleVendorsText + ", " + N.PCenterSelectAllVendorsText), o
    }, o.prototype.prepareVendorTemplate = function() {
        var e = w.vendors.vendorTemplate.cloneNode(!0);
        return e.querySelector("button").classList.remove("ot-ven-box"), e.querySelector("button").classList.add("ot-addtl-venbox"), v.removeChild(e.querySelector(this.ACC_TXT)), e
    }, o.prototype.createAdditionalVendorItem = function(e, t, o) {
        var e = e.cloneNode(!0),
            n = o.name;
        return e.querySelector(T.P_Ven_Name).innerText = n, v.setHtmlAttributes(e.querySelector("button"), {
            id: "Adtl-IAB" + t
        }), this.setupVendorPrivacyLink(e, o.policyUrl, n), this.setupVendorToggle(e, t, n), this.addVendorAccordionArrows(e), this.checkIfLegLinkRemove(e), e
    }, o.prototype.setupVendorPrivacyLink = function(e, t, o) {
        e = e.querySelector(T.P_Ven_Link);
        v.setHtmlAttributes(e, {
            href: t,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), e.innerHTML = S.getInnerHtmlContent(N.PCenterViewPrivacyPolicyText + "&nbsp;<span class='ot-scrn-rdr'>" + o + " " + N.NewWinTxt + "</span>"), N.BannerRequireExternalLinks && this.addExternalLinkIcon(e)
    }, o.prototype.addExternalLinkIcon = function(e) {
        var t;
        k.fp.CMPIconSprite && N.OTExternalLinkLogo && !N.BannerExternalLinksLogo ? h.hasAdjacentExternalLinkSvg(e) || (t = h.updateCorrectUrl(N.OTExternalLinkLogo), t = N.BannerExternalLinksLogo ? h.updateCorrectUrl(N.BannerExternalLinksLogo) : t, t = new URL(t, window.location.origin).pathname.split("/").pop().split(".").shift(), e.insertAdjacentHTML("afterend", S.getInnerHtmlContent("<svg class='ot-ext-lnk'>\n                                    <use href='#" + t + "'></use>\n                                    </svg>"))) : e.classList.add(this.EXT_LINK_CLASS)
    }, o.prototype.setupVendorToggle = function(e, t, o) {
        var n = E.chkboxEl.cloneNode(!0),
            r = (n.classList.remove("ot-ven-ctgl"), n.classList.add("ot-ven-adtlctgl"), Boolean(w.addtlVendors.vendorSelected[t])),
            i = n.querySelector("input"),
            s = (i.classList.add("ot-addtlven-chkbox-handler"), n.querySelector(this.LABEL_STATUS)),
            s = (N.PCShowConsentLabels ? s.innerHTML = S.getInnerHtmlContent(r ? N.PCActiveText : N.PCInactiveText) : v.removeChild(s), v.setCheckedAttribute("", i, r), v.setHtmlAttributes(i, {
                id: "ot-addtlven-chkbox-" + t,
                "addtl-vid": t,
                "aria-label": o
            }), n.querySelector("label").setAttribute("for", "ot-addtlven-chkbox-" + t), n.querySelector(T.P_Label_Txt).textContent = o, e.querySelector(T.P_Tgl_Cntr));
        m(s).append(n)
    }, o.prototype.addVendorAccordionArrows = function(e) {
        e.querySelector(T.P_Tgl_Cntr).insertAdjacentElement("beforeend", E.arrowEl.cloneNode(!0)), N.PCAccordionStyle !== ce.Caret && e.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0))
    }, o.prototype.populateGeneralVendors = function() {
        var e, t, o, n, r, i = this,
            s = N.GeneralVendors,
            a = document.querySelector(".ot-gv-acc"),
            l = Boolean(a);
        s.length ? (this.handleVendorsPresence(a), e = this.getArrowElement(), this.iabAccInit || this.addIabAccordion(), t = this.createSelectAllCheckbox(), o = this.createGeneralVendorsAccordion(e, t), n = this.createVendorTemplate(), l && m("" + T.P_Gven_List).html(""), r = !0, s.forEach(function(e) {
            var t = i.createVendorElement(e, n);
            m(l ? "" + T.P_Gven_List : o.querySelector("" + T.P_Gven_List)).append(t), mo.isGenVenPartOfAlwaysActiveGroup(e.VendorCustomId) || (r = !1)
        }), l || m(this.LST_CNT_COLUMN_SELECTOR).append(o), m("#onetrust-pc-sdk").on("click", "#ot-pc-lst .ot-acc-cntr > input", function(e) {
            return v.setCheckedAttribute(null, e.target, e.target.checked)
        }), this.showConsentHeader(), r && v.setDisabledAttribute("#ot-selall-gnven-handler", null, !0)) : this.handleNoVendors(a)
    }, o.prototype.handleNoVendors = function(e) {
        this.hasGenVendors = !1, e && m(e).hide()
    }, o.prototype.handleVendorsPresence = function(e) {
        this.hasGenVendors = !0, e && m(e).show()
    }, o.prototype.getArrowElement = function() {
        return (N.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0)
    }, o.prototype.createSelectAllCheckbox = function() {
        var e = document.createElement("div"),
            t = (e.setAttribute("class", "ot-sel-all-chkbox"), E.chkboxEl.cloneNode(!0));
        return t.id = "ot-selall-gnvencntr", t.querySelector("input").id = "ot-selall-gnven-handler", t.querySelector("label").setAttribute("for", "ot-selall-gnven-handler"), m(e).append(t), e
    }, o.prototype.createGeneralVendorsAccordion = function(e, t) {
        var o = E.accordionEl.cloneNode(!0),
            n = o.querySelector(C.ACC_HDR_CLASS);
        return n.insertAdjacentElement("beforeend", e.cloneNode(!0)), n.insertAdjacentHTML("beforeend", S.getInnerHtmlContent(this.getHeadingElement(N.PCenterGeneralVendorsText, "4", this.VEN_TITLE_CLASS))), N.GenVenOptOut && n.insertAdjacentElement("beforeend", t), o.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeend", S.getInnerHtmlContent("<ul id='ot-gn-venlst'></ul>")), o.classList.add("ot-gv-acc"), o.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCenterGeneralVendorsText), o
    }, o.prototype.createVendorTemplate = function() {
        var e = w.vendors.vendorTemplate.cloneNode(!0),
            t = e.querySelector("button");
        return t.classList.remove("ot-ven-box"), t.classList.add("ot-gv-venbox"), m(e.querySelector(this.ACC_TXT)).html('<ul class="ot-host-opt"></ul>'), e
    }, o.prototype.createVendorElement = function(e, t) {
        var o, n = this,
            r = this.mapGenVendorToHostFormat(e),
            i = t.cloneNode(!0),
            t = e.VendorCustomId,
            s = e.Name,
            a = (i.querySelector(T.P_Ven_Name).innerText = s, i.querySelector("button")),
            a = (v.setHtmlAttributes(a, {
                id: "Gn-" + t
            }), i.querySelector(T.P_Ven_Link));
        return e.PrivacyPolicyUrl ? (v.setHtmlAttributes(a, {
            href: e.PrivacyPolicyUrl,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), a.innerHTML = S.getInnerHtmlContent(N.PCGVenPolicyTxt + "&nbsp;<span class='ot-scrn-rdr'>" + s + " " + N.NewWinTxt + "</span>"), N.BannerRequireExternalLinks && (k.fp.CMPIconSprite && N.OTExternalLinkLogo && !N.BannerExternalLinksLogo ? (o = h.updateCorrectUrl(N.OTExternalLinkLogo), o = N.BannerExternalLinksLogo ? h.updateCorrectUrl(N.BannerExternalLinksLogo) : o, o = "<svg class='ot-ext-lnk'>\n                                <use href='#" + new URL(o, window.location.origin).pathname.split("/").pop().split(".").shift() + "'></use>\n                                </svg>", h.hasAdjacentExternalLinkSvg(a) || a.insertAdjacentHTML("afterend", S.getInnerHtmlContent(o))) : a.classList.add(this.EXT_LINK_CLASS))) : a.classList.add("ot-hide"), this.addDescriptionElement(a, e.Description), N.GenVenOptOut && this.addConsentToggle(i, e, t, s, r), N.PCAccordionStyle !== ce.Caret && i.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)), e.Cookies.length || m(i).addClass("ot-hide-acc"), e.Cookies.forEach(function(e) {
            e = n.getCookieElement(e, r);
            m(i.querySelector(".ot-host-opt")).append(e)
        }), this.checkIfLegLinkRemove(i), i
    }, o.prototype.addConsentToggle = function(e, t, o, n, r) {
        var i = E.chkboxEl.cloneNode(!0),
            s = (i.classList.remove("ot-ven-ctgl"), i.classList.add("ot-ven-gvctgl"), Boolean(w.genVendorsConsent[o])),
            a = i.querySelector("input"),
            l = (a.classList.add("ot-gnven-chkbox-handler"), i.querySelector(this.LABEL_STATUS)),
            l = (N.PCShowConsentLabels ? l.innerHTML = S.getInnerHtmlContent(s ? N.PCActiveText : N.PCInactiveText) : v.removeChild(l), v.setCheckedAttribute("", a, s), v.setHtmlAttributes(a, {
                id: "ot-gnven-chkbox-" + o,
                "gn-vid": o,
                "aria-label": n
            }), mo.isGenVenPartOfAlwaysActiveGroup(o) && v.setDisabledAttribute(null, a, !0), i.querySelector("label").setAttribute("for", "ot-gnven-chkbox-" + o), i.querySelector(T.P_Label_Txt).textContent = n, e.querySelector(T.P_Tgl_Cntr));
        m(l).append(i), l.insertAdjacentElement("beforeend", E.arrowEl.cloneNode(!0))
    }, o.prototype.addIabAccordion = function() {
        var e = (N.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0),
            t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"),
            o = t.cloneNode(!0),
            t = (v.removeChild(o.querySelector("#ot-selall-hostcntr")), v.removeChild(t.querySelector("#ot-selall-vencntr")), v.removeChild(t.querySelector("#ot-selall-licntr")), E.accordionEl.cloneNode(!0));
        t.classList.add("ot-iab-acc"), t.querySelector(C.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", e.cloneNode(!0)), t.querySelector(C.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", S.getInnerHtmlContent(this.getHeadingElement(N.PCIABVendorsText, "4", this.VEN_TITLE_CLASS))), t.querySelector(C.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", o), t.querySelector(this.ACC_TXT).insertAdjacentElement("beforeEnd", m("#ot-ven-lst").el[0]), m(this.LST_CNT_COLUMN_SELECTOR).append(t), t.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, N.PCIABVendorsText), this.iabAccInit = !0
    }, o.prototype.showConsentHeader = function() {
        var e = D.legIntSettings;
        m("#onetrust-pc-sdk .ot-sel-all-hdr").show(), e.PAllowLI && !e.PShowLegIntBtn || m("#onetrust-pc-sdk .ot-li-hdr").hide()
    }, o.prototype.setBackBtnTxt = function() {
        (k.isV2Template ? (m(T.P_Vendor_List + " .back-btn-handler").attr(this.ARIA_LABEL_ATTRIBUTE, N.PCenterBackText), m(T.P_Vendor_List + " .back-btn-handler title")) : m(T.P_Vendor_List + " .back-btn-handler .pc-back-button-text")).html(N.PCenterBackText)
    }, o.prototype.getCookieElement = function(e, t) {
        var o = w.hosts.hostCookieTemplate.cloneNode(!0),
            n = o.querySelector("dl"),
            r = n.querySelector("div").cloneNode(!0),
            i = (r.classList.remove("cookie-name-container"), n.innerHTML = S.getInnerHtmlContent(""), e.Name),
            s = (N.AddLinksToCookiepedia && t.isFirstParty && (i = h.getCookieLabel(e, N.AddLinksToCookiepedia)), r.cloneNode(!0));
        return s.classList.add(T.P_c_Name), s.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(N.pcCListName), s.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(i), n.appendChild(s), N.pcShowCookieHost && ((s = r.cloneNode(!0)).classList.add(T.P_c_Host), s.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(N.pcCListHost), s.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(e.Host), n.appendChild(s)), N.pcShowCookieDuration && ((s = r.cloneNode(!0)).classList.add(T.P_c_Duration), s.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(N.pcCListDuration), s.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(e.IsSession ? N.LifespanTypeText : h.getDuration(e)), n.appendChild(s)), N.pcShowCookieType && (i = t.Type === he.GenVendor ? !e.isThirdParty : t.isFirstParty, (s = r.cloneNode(!0)).classList.add(T.P_c_Type), s.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(N.pcCListType), s.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(i ? N.firstPartyTxt : N.thirdPartyTxt), n.appendChild(s)), N.pcShowCookieCategory && (i = void 0, i = t.Type === he.GenVendor ? e.category : (t.isFirstParty ? e : t).groupName) && ((s = r.cloneNode(!0)).classList.add(T.P_c_Category), s.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(N.pcCListCategory), s.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(i), n.appendChild(s)), N.pcShowCookieDescription && e.description && ((s = r.cloneNode(!0)).classList.add(T.P_c_Desc), s.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(N.pcCListDescription), s.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(e.description), n.appendChild(s)), o
    }, o.prototype.getNoResultsFound = function(e) {
        e = w.showTrackingTech ? N.PCTechNotFound : e ? N.PCHostNotFound : N.PCVendorNotFound;
        return " " + e + "."
    }, o.prototype.getAdditionalTechnologiesHtml = function(e) {
        var t = document.createDocumentFragment(),
            o = N.AdditionalTechnologiesConfig,
            n = 0 < e.Cookies.length;
        return (n = n && e.Cookies[0].HostId === this.FIRST_PARTY_COOKIES_GROUP_NAME ? 0 < e.Cookies[0].Cookies.length : n) && ((n = C.getMainAccordionContainer(o.PCCookiesLabel, o.PCCookiesLabel, !1)).classList.add(this.TECH_COOKIES_SELECTOR), t.appendChild(n)), 0 < e.LocalStorages.length && ((n = C.getMainAccordionContainer(o.PCLocalStorageLabel, o.PCLocalStorageLabel)).classList.add("tech-local"), C.setSessionLocalStorageTemplate(n, e.LocalStorages, N.AdditionalTechnologiesConfig.PCLocalStorageDurationText), t.appendChild(n)), 0 < e.SessionStorages.length && ((n = C.getMainAccordionContainer(o.PCSessionStorageLabel, o.PCSessionStorageDurationText)).classList.add("tech-session"), C.setSessionLocalStorageTemplate(n, e.SessionStorages, N.AdditionalTechnologiesConfig.PCSessionStorageDurationText), t.appendChild(n)), t
    }, o.prototype.getMainAccordionContainer = function(e, t, o) {
        void 0 === o && (o = !0);
        var n = C.getAccordionStyleElement(),
            r = E.accordionEl.cloneNode(!0);
        return r.classList.add("ot-add-tech"), r.querySelector(C.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", n), r.querySelector(C.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", S.getInnerHtmlContent(this.getHeadingElement(e, "4", this.VEN_TITLE_CLASS))), r.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, t), o && r.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeend", S.getInnerHtmlContent('<ul id="ot-host-lst" style="display: block;"></ul>')), r.cloneNode(!0)
    }, o.prototype.setSessionLocalStorageTemplate = function(e, t, o) {
        var n = w.hosts.hostTemplate.cloneNode(!0),
            r = (v.removeChild(n.querySelector(".ot-a scc-txt")), e.querySelector(this.ACC_TXT + " " + T.P_Host_Cntr));
        r.removeAttribute("style"), r.classList.add("ot-host-opt");
        for (var i = 0, s = t; i < s.length; i++) {
            var a = s[i],
                a = C.getSessionLocalStorageElement(a, o);
            r.append(a)
        }
    }, o.prototype.getSessionLocalStorageElement = function(e, t) {
        var o = w.hosts.hostCookieTemplate.cloneNode(!0),
            n = o.querySelector("dl"),
            r = n.querySelector("div").cloneNode(!0),
            i = (r.classList.remove("cookie-name-container"), n.innerHTML = S.getInnerHtmlContent(""), C.createKeyValueDivEle(r, T.P_c_Name, N.pcCListName, e.Name)),
            i = (n.appendChild(i), C.createKeyValueDivEle(r, T.P_c_Host, N.pcCListHost, e.Host)),
            i = (n.appendChild(i), C.createKeyValueDivEle(r, T.P_c_Duration, N.pcCListDuration, t)),
            t = (n.appendChild(i), C.createKeyValueDivEle(r, T.P_c_Desc, N.pcCListDescription, e.description));
        return n.appendChild(t), o
    }, o.prototype.createKeyValueDivEle = function(e, t, o, n) {
        e = e.cloneNode(!0);
        return e.classList.add(t), e.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = S.getInnerHtmlContent(o), e.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = S.getInnerHtmlContent(n), e
    }, o.prototype.getAdditionalTechnologiesDataFromGroup = function(e) {
        for (var t, o = [], n = {
                SessionStorages: [],
                LocalStorages: [],
                Cookies: []
            }, r = 0, i = C.getGroupsFromFilter(e); r < i.length; r++) {
            var s = i[r],
                a = on.getCookiesForGroup(s),
                o = U(o, null != (t = a.firstPartyCookiesList) ? t : []);
            n.Cookies = U(n.Cookies, a.thirdPartyCookiesList), n.LocalStorages = U(n.LocalStorages, null != (a = null == (t = s.TrackingTech) ? void 0 : t.LocalStorages) ? a : []), n.SessionStorages = U(n.SessionStorages, null != (a = null == (t = s.TrackingTech) ? void 0 : t.SessionStorages) ? a : [])
        }
        return o.length && n.Cookies.unshift({
            HostName: N.PCFirstPartyCookieListText,
            DisplayName: N.PCFirstPartyCookieListText,
            HostId: this.FIRST_PARTY_COOKIES_GROUP_NAME,
            isFirstParty: !0,
            Cookies: o,
            Description: ""
        }), n
    }, o.prototype.getFirstsAndThirdCookisFromGroups = function(e) {
        var t = [],
            o = [];
        return C.getGroupsFromFilter(e).forEach(function(e) {
            e = on.getCookiesForGroup(e);
            t = U(t, e.firstPartyCookiesList), o = U(o, e.thirdPartyCookiesList)
        }), {
            firstPartyCookiesList: t,
            thirdPartyCookiesList: o
        }
    }, o.prototype.getGroupsFromFilter = function(t) {
        var o = [];
        return N.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                (!t || !t.length || -1 !== t.indexOf(e.CustomGroupId)) && o.push(e)
            })
        }), o
    }, o.prototype.getAccordionStyleElement = function() {
        return (N.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0)
    }, o.prototype.getFilteredAdditionaTechtData = function(e, t) {
        var o, n = {
                SessionStorages: [],
                LocalStorages: [],
                Cookies: []
            },
            r = this.getSearchQuery(e),
            e = JSON.parse(JSON.stringify(t));
        return e.Cookies[0].HostId === this.FIRST_PARTY_COOKIES_GROUP_NAME && ((o = e.Cookies.shift()).Cookies = null == (t = o.Cookies) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        })), n.Cookies = null == (t = e.Cookies) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.DisplayName || e.HostName)
        }), o && 0 < o.Cookies.length && n.Cookies.unshift(o), n.LocalStorages = null == (t = e.LocalStorages) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        }), n.SessionStorages = null == (o = e.SessionStorages) ? void 0 : o.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        }), n
    }, o.prototype.checkIfLegLinkRemove = function(e) {
        D.isTcfV2Template && e.querySelector(T.P_Ven_Leg_Claim).remove()
    };
    var C, sn = o;

    function o() {
        this.hasIabVendors = !1, this.hasGoogleVendors = !1, this.hasGenVendors = !1, this.iabAccInit = !1, this._displayNull = "display: '';", this.ARIA_LABEL_ATTRIBUTE = "aria-label", this.TECH_COOKIES_SELECTOR = "tech-cookies", this.FIRST_PARTY_COOKIES_GROUP_NAME = "first-party-cookies-group", this.LABEL_STATUS = ".ot-label-status", this.CONSENT_CATEGORY = ".consent-category", this.ACC_TXT = ".ot-acc-txt", this.NTH_CHILD_ONE_SELECTOR = "dt:nth-child(1)", this.NTH_CHILD_TWO_SELECTOR = "dd:nth-child(2)", this.LINE_THROUGH_CLASS = "line-through", this.ACC_HDR_CLASS = ".ot-acc-hdr", this.VEN_TITLE_CLASS = "ot-vensec-title", this.EXT_LINK_CLASS = "ot-ext-lnk", this.TARGET_BLANK_REL_NOOPENER = "noopener noreferrer", this.LST_CNT_COLUMN_SELECTOR = "#ot-lst-cnt .ot-sdk-column", this.googleSearchSelectors = {
            vendorAccBtn: "#ot-addtl-venlst #Adtl-IAB",
            name: "name",
            accId: ".ot-adtlv-acc",
            selectAllEvntHndlr: "#ot-selall-adtlven-handler",
            venListId: "#ot-addtl-venlst",
            ctgl: ".ot-ven-adtlctgl"
        }, this.genVendorSearchSelectors = {
            vendorAccBtn: "#ot-gn-venlst #Gn-",
            name: "Name",
            accId: ".ot-gv-acc",
            selectAllEvntHndlr: "#ot-selall-gnven-handler",
            venListId: "#ot-gn-venlst",
            ctgl: ".ot-ven-gvctgl"
        }
    }
    var an, ln = "Banner",
        cn = "Preference Center",
        dn = "API",
        un = "Close",
        pn = "Allow All",
        Cn = "Reject All",
        gn = "Confirm",
        hn = "Confirm",
        yn = "Continue without Accepting",
        fn = "OneTrust Cookie Consent",
        Sn = "Banner Auto Close",
        mn = "Banner Close Button",
        vn = "Banner - Continue without Accepting",
        Tn = "Banner - Confirm",
        An = "Preferences Close Button",
        Pn = "Preference Center Opened From Banner",
        kn = "Preference Center Opened From Button",
        In = "Preference Center Opened From Function",
        bn = "Preferences Save Settings",
        Ln = "Vendors List Opened From Function",
        En = "Floating Cookie Settings Open Button",
        On = "Floating Cookie Settings Close Button",
        _n = "Preferences Toggle On",
        Dn = "Preferences Toggle Off",
        Nn = "General Vendor Toggle On",
        wn = "General Vendor Toggle Off",
        Bn = "Host Toggle On",
        Vn = "Host Toggle Off",
        Gn = "Preferences Legitimate Interest Objection",
        xn = "Preferences Legitimate Interest Remove Objection",
        Hn = "IAB Vendor Toggle ON",
        Rn = "IAB Vendor Toggle Off",
        Fn = "IAB Vendor Legitimate Interest Objection",
        Mn = "IAB Vendor Legitimate Interest Remove Objection",
        Un = "Vendor Service Toggle On",
        qn = "Vendor Service Toggle Off",
        jn = (Kn.prototype.init = function() {
            this.insertHtml(), this.insertCss(), this.showNty(), this.initHandler()
        }, Kn.prototype.getContent = function() {
            return F(this, void 0, void 0, function() {
                return M(this, function(e) {
                    return [2, Yt.getSyncNtfyContent().then(function(e) {
                        p.syncNtfyGrp = {
                            name: e.name,
                            html: atob(e.html),
                            css: e.css
                        }
                    })]
                })
            })
        }, Kn.prototype.insertHtml = function() {
            this.removeHtml();

            function e(e) {
                return t.querySelector(e)
            }
            var t = document.createDocumentFragment(),
                o = document.createElement("div"),
                o = (m(o).html(p.syncNtfyGrp.html), o.querySelector(this.El)),
                n = (N.BannerRelativeFontSizesToggle && m(o).addClass("otRelFont"), N.useRTL && m(o).attr("dir", "rtl"), m(t).append(o), N.NtfyConfig),
                n = (this.initHtml("Sync", n.Sync, e, t.querySelector(this.El)), n.ShowCS ? m(e(".ot-pc-handler")).html(n.CSTxt) : (m(o).addClass("ot-hide-csbtn"), e(".ot-sync-btncntr").parentElement.removeChild(e(".ot-sync-btncntr"))), document.createElement("div"));
            m(n).append(t), m("#onetrust-consent-sdk").append(n.firstChild)
        }, Kn.prototype.initHandler = function() {
            m(this.El + " .ot-sync-close-handler").on("click", function() {
                return an.close()
            })
        }, Kn.prototype.showNty = function() {
            var e = m(this.El);
            e.css("bottom: -300px;"), e.animate({
                bottom: "1em;"
            }, 1e3), setTimeout(function() {
                e.css("bottom: 1rem;")
            }, 1e3), e.focus()
        }, Kn.prototype.changeState = function() {
            setTimeout(function() {
                an.refreshState()
            }, 1500)
        }, Kn.prototype.refreshState = function() {
            function e(e) {
                return t.querySelector(e)
            }
            var t = m(this.El).el[0],
                o = (t.classList.add("ot-nty-complete"), t.classList.remove("ot-nty-sync"), N.NtfyConfig);
            this.initHtml("Complete", o.Complete, e, t), o.ShowCS && ("LINK" === o.CSType && m(e(".ot-pc-handler")).addClass("ot-pc-link"), m(".ot-sync-btncntr").show("inline-block"), this.alignContent(), m(window).on("resize", function() {
                return an.resizeEvent
            })), setTimeout(function() {
                an.close()
            }, 1e3 * N.NtfyConfig.NtfyDuration)
        }, Kn.prototype.insertCss = function() {
            var e = document.getElementById("onetrust-style");
            e.innerHTML = S.getInnerHtmlContent(e.innerHTML + p.syncNtfyGrp.css), e.innerHTML = S.getInnerHtmlContent(e.innerHTML + this.addCustomStyles())
        }, Kn.prototype.addCustomStyles = function() {
            var e = N.NtfyConfig,
                t = e.Sync,
                o = e.Complete,
                n = e.CSButton,
                r = e.CSLink;
            return "\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync {\n            background-color: " + t.BgColor + ";\n            border: 1px solid " + t.BdrColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-sync-refresh>g {\n            fill: " + t.IconBgColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync #ot-sync-title {\n            text-align: " + t.TitleAlign + ";\n            color: " + t.TitleColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync .ot-sync-desc  {\n            text-align: " + t.DescAlign + ";\n            color: " + t.DescColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete {\n            background-color: " + o.BgColor + ";\n            border: 1px solid " + o.BdrColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-sync-check>g {\n            fill: " + o.IconBgColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete #ot-sync-title {\n            text-align: " + o.TitleAlign + ";\n            color: " + o.TitleColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete .ot-sync-desc  {\n            text-align: " + o.DescAlign + ";\n            color: " + o.DescColor + ";\n        }\n        " + ("BUTTON" === e.CSType ? "\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-pc-handler {\n            background-color: " + n.BgColor + ";\n            border: 1px solid " + n.BdrColor + ";\n            color: " + n.Color + ";\n            text-align: " + n.Align + ";\n        }" : " #onetrust-consent-sdk #ot-sync-ntfy .ot-pc-handler.ot-pc-link {\n            color: " + r.Color + ";\n            text-align: " + r.Align + ";\n        }") + "\n        "
        }, Kn.prototype.initHtml = function(e, t, o, n) {
            var r = "Complete" === e ? ".ot-sync-refresh" : ".ot-sync-check";
            t.ShowIcon ? (m(o("Sync" === e ? ".ot-sync-refresh" : ".ot-sync-check")).show(), m(o(r)).hide(), m(o(".ot-sync-icon")).show("inline-block"), n.classList.remove("ot-hide-icon")) : (m(o(".ot-sync-icon")).hide(), n.classList.add("ot-hide-icon")), t.Title ? m(o("#ot-sync-title")).html(t.Title) : m(o("#ot-sync-title")).hide(), t.Desc ? m(o(".ot-sync-desc")).html(t.Desc) : m(o(".ot-sync-desc")).hide(), t.ShowClose ? (m(o(".ot-sync-close-handler")).show("inline-block"), m(o(".ot-close-icon")).attr("aria-label", t.CloseAria), n.classList.remove("ot-hide-close")) : (m(o(".ot-sync-close-handler")).hide(), n.classList.add("ot-hide-close"))
        }, Kn.prototype.close = function() {
            this.hideSyncNtfy(), h.resetFocusToBody()
        }, Kn.prototype.hideSyncNtfy = function() {
            N.NtfyConfig.ShowCS && window.removeEventListener("resize", an.resizeEvent), m("#ot-sync-ntfy").fadeOut(400)
        }, Kn.prototype.removeHtml = function() {
            var e = m(this.El).el;
            e && v.removeChild(e)
        }, Kn.prototype.alignContent = function() {
            m(".ot-sync-btncntr").el[0].clientHeight > m(".ot-sync-titlecntr").el[0].clientHeight && (m(".ot-sync-titlecntr").addClass("ot-pos-abs"), m(".ot-sync-btncntr").addClass("ot-pos-rel"))
        }, Kn.prototype.resizeEvent = function() {
            window.innerWidth <= 896 && an.alignContent()
        }, Kn);

    function Kn() {
        this.El = "#ot-sync-ntfy"
    }
    Yn.prototype.toggleVendorConsent = function(e, t) {
        void 0 === t && (t = null), (e = (e = void 0 === e ? [] : e).length ? e : p.oneTrustIABConsent.vendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = m(T.P_Vendor_Container + " ." + T.P_Ven_Ctgl + ' [vendorid="' + t + '"]').el[0];
            t && v.setCheckedAttribute("", t, "true" === e)
        });
        var o, n = m("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0];
        n && (o = v.getActiveIdArray(v.distinctArray(e)), (t = null === t ? o.length === e.length : t) || 0 === o.length ? n.parentElement.classList.remove(Ut.P_Line_Through) : n.parentElement.classList.add(Ut.P_Line_Through), v.setCheckedAttribute("", n, t))
    }, Yn.prototype.toggleVendorLi = function(e, t) {
        void 0 === t && (t = null), (e = (e = void 0 === e ? [] : e).length ? e : p.oneTrustIABConsent.legIntVendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = m(T.P_Vendor_Container + " ." + T.P_Ven_Ltgl + ' [leg-vendorid="' + t + '"]').el[0];
            t && v.setCheckedAttribute("", t, "true" === e)
        });
        var o, n = m("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0];
        n && (o = v.getActiveIdArray(v.distinctArray(e)), (t = null === t ? o.length === e.length : t) || 0 === o.length ? n.parentElement.classList.remove(Ut.P_Line_Through) : n.parentElement.classList.add(Ut.P_Line_Through), v.setCheckedAttribute("", n, t))
    }, Yn.prototype.updateVendorLegBtns = function(e) {
        (e = (e = void 0 === e ? [] : e).length ? e : p.oneTrustIABConsent.legIntVendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = m(T.P_Vendor_Container + ' .ot-leg-btn-container[data-group-id="' + t + '"]').el[0];
            t && y.updateLegIntBtnElement(t, "true" === e)
        })
    };
    var zn, Wn = Yn;

    function Yn() {}

    function Jn() {
        return (!D.isIab2orv2Template && N.PCTemplateUpgrade && N.PCCategoryStyle === ve.Toggle ? E.toggleEl : E.chkboxEl).cloneNode(!0)
    }
    Qn.prototype.setHtmlTemplate = function(e) {
        O.setInternalData(), O.rootHtml = e, O.cloneHtmlElements()
    }, Qn.prototype.getVendorListEle = function(e) {
        var t = document.createDocumentFragment(),
            o = document.createElement("div"),
            n = (o.classList.add("ot-vs-list"), N.VendorServiceConfig.PCVSExpandGroup);
        return e.forEach(function(e, t) {
            e = O.createVendor(e.groupRef, e, n, "ot-vs-lst-id-" + t);
            o.appendChild(e)
        }), t.appendChild(o), t
    }, Qn.prototype.insertVendorServiceHtml = function(e, t) {
        var o;
        O.checkIfIsInvalid(e, t) || (o = document.createDocumentFragment(), O.setVendorContainer(o, e), O.setVendorList(o, e), e.SubGroups && 0 < e.SubGroups.length ? (o.querySelector(this.MAIN_CONT_ELE).classList.add("ot-vnd-subgrp-cnt"), e = t.children[1], D.pcName === at && (e = t.children[2]), t.insertBefore(o, e)) : t.appendChild(o))
    }, Qn.prototype.toggleVendorService = function(e, t, o, n) {
        e = L.getGroupById(e), t = L.getVSById(t);
        n = n || O.getVendorInputElement(t.CustomVendorServiceId), O.setVendorServiceState(n, t, o), o ? O.changeGroupState(e, o, O.isToggle) : O.checkGroupChildrenState(e) || O.changeGroupState(e, !1, O.isToggle)
    }, Qn.prototype.setVendorStateByGroup = function(e, t) {
        e = e.VendorServices;
        if (p.showVendorService && e)
            for (var o = 0, n = e; o < n.length; o++) {
                var r = n[o],
                    i = O.getVendorInputElement(r.CustomVendorServiceId);
                O.setVendorServiceState(i, r, t)
            }
    }, Qn.prototype.resetVendorUIState = function(e) {
        e.forEach(function(e, t) {
            t = O.getVendorInputElement(t);
            O.changeVendorServiceUIState(t, e)
        })
    }, Qn.prototype.setVendorServiceState = function(e, t, o) {
        O.changeVendorServiceState(t, o), O.changeVendorServiceUIState(e, o);
        e = o ? Un : qn;
        uo.triggerGoogleAnalyticsEvent(fn, e, t.ServiceName + ": " + t.CustomVendorServiceId)
    }, Qn.prototype.removeVSUITemplate = function(e) {
        var t = e.querySelector(this.MAIN_CONT_ELE);
        t && e.removeChild(t)
    }, Qn.prototype.consentAll = function(o) {
        p.getVendorsInDomain().forEach(function(e) {
            var t = o;
            o || (t = L.isAlwaysActiveGroup(e.groupRef)), O.toggleVendorService(e.groupRef.CustomGroupId, e.CustomVendorServiceId, t || o)
        })
    }, Qn.prototype.cloneHtmlElements = function() {
        var e, t, o, n, r = O.rootHtml.querySelector(this.MAIN_CONT_ELE);
        r && (e = r.querySelector(".ot-vnd-serv-hdr-cntr"), n = (o = (t = r.querySelector(".ot-vnd-lst-cont")).querySelector(".ot-vnd-item")).querySelector(".ot-vnd-info"), O.vendorLabelContainerClone = e.cloneNode(!0), r.removeChild(e), O.vendorInfoClone = n.cloneNode(!0), o.querySelector(".ot-vnd-info-cntr").removeChild(n), O.vendorItemClone = o.cloneNode(!0), t.removeChild(o), O.vendorListContainerClone = t.cloneNode(!0), r.removeChild(t), O.vendorServMainContainerClone = r.cloneNode(!0), O.rootHtml.removeChild(r))
    }, Qn.prototype.setInternalData = function() {
        O.isToggle = N.PCCategoryStyle === ve.Toggle;
        var e = N.VendorServiceConfig;
        O.stringTranslation = new Map, O.stringTranslation.set("ServiceName", e.PCVSNameText || "ServiceName"), O.stringTranslation.set("ParentCompany", e.PCVSParentCompanyText || "ParentCompany"), O.stringTranslation.set("Address", e.PCVSAddressText || "Address"), O.stringTranslation.set("DefaultCategoryName", e.PCVSDefaultCategoryText || "DefaultCategoryName"), O.stringTranslation.set("Description", e.PCVSDefaultDescriptionText || "Description"), O.stringTranslation.set("DPOEmail", e.PCVSDPOEmailText || "DPOEmail"), O.stringTranslation.set("DPOLink", e.PCVSDPOLinkText || "DPOLink"), O.stringTranslation.set("PrivacyPolicyLink", e.PCVSPrivacyPolicyLinkText || "PrivacyPolicyLink"), O.stringTranslation.set("CookiePolicyLink", e.PCVSCookiePolicyLinkText || "CookiePolicyLink"), O.stringTranslation.set("OptOutLink", e.PCVSOptOutLinkText || "OptOutLink"), O.stringTranslation.set("LegalBasis", e.PCVSLegalBasisText || "LegalBasis")
    }, Qn.prototype.setVendorContainer = function(e, t) {
        var o = O.vendorServMainContainerClone.cloneNode(!0),
            t = (o.setAttribute("data-group-id", t.CustomGroupId), O.vendorLabelContainerClone.cloneNode(!0));
        t.querySelector(".ot-vnd-serv-hdr").innerHTML = S.getInnerHtmlContent(N.VendorServiceConfig.PCVSListTitle), o.appendChild(t), e.appendChild(o)
    }, Qn.prototype.setVendorList = function(e, t) {
        for (var o = 0, n = O.getVSFromGroupAndSubgroups(t), r = n.length, e = e.querySelector(this.MAIN_CONT_ELE), i = O.vendorListContainerClone.cloneNode(), s = N.VendorServiceConfig.PCVSExpandCategory; o < r; o++) {
            var a = O.createVendor(t, n[o], s);
            i.appendChild(a)
        }
        e.appendChild(i)
    }, Qn.prototype.getVSFromGroupAndSubgroups = function(e, t) {
        var o, n = null != (o = e.VendorServices) ? o : [];
        if (t = void 0 === t ? !1 : t)
            for (var r = 0, i = null != (o = e.SubGroups) ? o : []; r < i.length; r++) {
                var s = null != (s = i[r].VendorServices) ? s : [];
                n.push.apply(n, s)
            }
        return n
    }, Qn.prototype.createVendor = function(e, t, o, n) {
        var r = O.vendorItemClone.cloneNode(!0),
            i = (r.setAttribute("data-vnd-id", t.CustomVendorServiceId), N.PCAccordionStyle === ce.NoAccordion ? (r.classList.remove("ot-accordion-layout"), (i = r.querySelector("button")) && r.removeChild(i)) : O.setExpandVendorList(r, o), O.setVendorHeader(e, t, r, n), r.querySelector(".ot-vnd-info-cntr"));
        return O.setVendorInfo(i, t), r
    }, Qn.prototype.setExpandVendorList = function(e, t) {
        e.querySelector("button").setAttribute("aria-expanded", "" + t)
    }, Qn.prototype.setVendorHeader = function(e, t, o, n) {
        var r = N.PCShowAlwaysActiveToggle,
            i = "always active" === L.getGrpStatus(e).toLowerCase(),
            o = o.querySelector(".ot-acc-hdr"),
            s = (i && o.classList.add("ot-always-active-group"), null),
            e = (i && N.PCCategoryStyle === ve.Toggle || (s = O.setHeaderInputStyle(e, t, i, n)), O.setHeaderText(t, o)),
            n = (o.appendChild(e), O.getPositionForElement(N.PCAccordionStyle, O.isToggle)),
            t = n.positionIcon;
        s && o.insertAdjacentElement(n.positionInput, s), i && r && (e = O.getAlwaysActiveElement(), o.insertAdjacentElement("beforeend", e)), N.PCAccordionStyle !== ce.NoAccordion && (n = O.setHeaderAccordionIcon(), o.insertAdjacentElement(t, n))
    }, Qn.prototype.getPositionForElement = function(e, t) {
        var o = "beforeend",
            n = "beforeend";
        return {
            positionIcon: o = t && e === ce.PlusMinus ? "afterbegin" : o,
            positionInput: n = t ? n : "afterbegin"
        }
    }, Qn.prototype.setHeaderAccordionIcon = function() {
        var e = (N.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0);
        return e
    }, Qn.prototype.setHeaderText = function(e, t) {
        var o = t.querySelector(".ot-cat-header"),
            n = o.cloneNode();
        return t.removeChild(o), n.innerText = e.ServiceName, n
    }, Qn.prototype.setHeaderInputStyle = function(e, t, o, n) {
        var r, i, s, a;
        return N.VendorServiceConfig.PCVSOptOut ? (e = L.checkIsActiveByDefault(e), r = !1, r = (i = p.vsConsent).has(t.CustomVendorServiceId) ? i.get(t.CustomVendorServiceId) : e, (i = Jn()).querySelector("input").classList.add("category-switch-handler"), e = i.querySelector("input"), a = t.CustomVendorServiceId, n = null != n ? n : "ot-vendor-id-" + a, s = "ot-vendor-header-id-" + a, m(e).attr("id", n), m(e).attr("name", n), m(e).attr("aria-labelledby", s), m(e).data("ot-vs-id", a), m(e).data("optanongroupid", t.groupRef.CustomGroupId), o && e.setAttribute("aria-disabled", "true"), v.setCheckedAttribute(null, e, r), a = O.isToggle ? n : s, m(i.querySelector("label")).attr("for", a), m(i.querySelector(".ot-label-txt")).html(t.ServiceName), i) : null
    }, Qn.prototype.getAlwaysActiveElement = function() {
        var e = document.createElement("div");
        return e.classList.add("ot-always-active"), e.innerText = N.AlwaysActiveText, e
    }, Qn.prototype.setVendorInfo = function(e, t) {
        var o, n, r, i, s, a, l, c = ["DPOLink", "PrivacyPolicyLink", "CookiePolicyLink", "OptOutLink"];
        for (o in t) O.skipVendorInfoKey(o, t) || (n = t[o], (r = O.vendorInfoClone.cloneNode(!0)).dataset.vndInfoKey = o + "-" + t.CustomVendorServiceId, i = r.querySelector(".ot-vnd-lbl"), s = r.querySelector(".ot-vnd-cnt"), i.innerHTML = S.getInnerHtmlContent(O.getLocalizedString(o)), c.includes(o) ? (s.remove(), a = document.createElement("a"), m(a).attr("href", n), m(a).attr("target", "_blank"), m(a).attr("rel", "noopener"), m(a).attr("aria-label", n + " " + N.NewWinTxt), a.classList.add("ot-vnd-cnt"), a.innerText = n, k.fp.CMPIconSprite && N.BannerRequireExternalLinks ? ((l = document.createElement("div")).appendChild(a), i.insertAdjacentElement("afterend", l)) : i.insertAdjacentElement("afterend", a)) : s.innerHTML = S.getInnerHtmlContent(n), e.appendChild(r))
    }, Qn.prototype.skipVendorInfoKey = function(e, t) {
        return "VendorServiceId" === e || "DefaultCategoryId" === e || "ServiceName" === e || "groupRef" === e || "CustomVendorServiceId" === e || "PurposeId" === e || !t[e]
    }, Qn.prototype.getLocalizedString = function(e) {
        return O.stringTranslation.has(e) ? O.stringTranslation.get(e) : "DEFAULT"
    }, Qn.prototype.checkGroupChildrenState = function(e) {
        for (var t, o = 0, n = null != (t = e.SubGroups) ? t : []; o < n.length; o++) {
            var r = n[o];
            if (O.checkGroupChildrenState(r)) return !0
        }
        for (var i = 0, s = null != (t = e.VendorServices) ? t : []; i < s.length; i++) {
            var a = s[i];
            if (p.vsConsent.get(a.CustomVendorServiceId)) return !0
        }
        return !1
    }, Qn.prototype.changeVendorServiceState = function(e, t) {
        p.vsConsent.set(e.CustomVendorServiceId, t)
    }, Qn.prototype.changeVendorServiceUIState = function(e, t) {
        e && v.setCheckedAttribute(null, e, t)
    }, Qn.prototype.changeGroupState = function(e, t, o) {
        var n = L.getParentByGrp(e);
        y.toggleGrpStatus(e, t), O.updateGroupUIState(e.CustomGroupId, t, o, null !== n), n && (e = O.checkGroupChildrenState(n), O.changeGroupState(n, e, o))
    }, Qn.prototype.updateGroupUIState = function(e, t, o, n) {
        void 0 === n && (n = !1);
        n = document.querySelector((n ? "#ot-sub-group-id-" : "#ot-group-id-") + e);
        n && v.setCheckedAttribute(null, n, t)
    }, Qn.prototype.getVendorInputElement = function(e) {
        return document.getElementById("ot-vendor-id-" + e)
    }, Qn.prototype.checkIfIsInvalid = function(e, t) {
        return !e || !e.VendorServices || !t || e.VendorServices.length <= 0
    };
    var O, Xn = Qn;

    function Qn() {
        this.MAIN_CONT_ELE = ".ot-vnd-serv"
    }

    function Zn(e, t) {
        var o, n, r = "otGenericBackdrop",
            i = "#" + r,
            s = "ot-generic-modal-layer";

        function a(e) {
            e ? (m(i).removeClass("ot-hide"), m(i).el[0].removeAttribute("style")) : (m(i).fadeOut(400), m(i).addClass("ot-hide"))
        }
        return (o = document.createElement("div")).classList.add(s), (n = document.createElement("div")).setAttribute("id", r), n.classList.add("onetrust-pc-dark-filter"), o.appendChild(n), (r = document.createElement("div")).classList.add("ot-general-modal"), r.setAttribute("id", null != e ? e : "genericModal"), o.appendChild(r), n = "#onetrust-consent-sdk .ot-general-modal { background-color: " + N.pcBackgroundColor + ";}", (e = document.getElementById("onetrust-style")).textContent = e.textContent + n, {
            dialogLayerHtml: o,
            modalHtml: r,
            closeModalHandler: function() {
                a(!1);
                var e = t.querySelector("." + s);
                t.removeChild(e)
            },
            openModalHandler: function() {
                a(!0)
            }
        }
    }
    er.getInstance = function() {
        return er.instance = er.instance ? er.instance : new er
    }, er.prototype.getHealthSignatureUIIfNeeded = function(e) {
        if ((void 0 === e && (e = !1), D.requireSignatureEnabled) && (this.healthSignatureGroup = N.Groups.find(function(e) {
                return e.needsHealthSignature
            }), this.healthSignatureGroup))
            if (D.healthSignatureGroup || e)
                if (D.healthSignatureData) this.setSignHealthDataIntoCookieGroup(D.healthSignatureData);
                else {
                    var t = y.isGroupActive(this.healthSignatureGroup),
                        o = "1" === I.readCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION);
                    if (!(e && t && o)) return this.showHealthSignatureModal(function() {}), this.healthSignatureElement
                }
        else(t = y.isGroupActive(this.healthSignatureGroup)) && Nr.setDataSubjectIdV2(D.healthSignatureData), I.writeCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION, t ? "1" : "");
        return null
    }, er.prototype.checkIfHealthSignatureNeeded = function(e) {
        var t, o, n = this;
        return void 0 === e && (e = !1), !D.requireSignatureEnabled || p.bannerCloseSource === ee.RejectAll || p.bannerCloseSource === ee.BannerCloseButton || p.bannerCloseSource === ee.ContinueWithoutAcceptingButton ? Promise.resolve() : (this.healthSignatureGroup = N.Groups.find(function(e) {
            return e.needsHealthSignature
        }), this.healthSignatureGroup ? (e = e || this.getGroupToggleHtmlValue()) ? D.healthSignatureData ? (this.setSignHealthDataIntoCookieGroup(D.healthSignatureData), Promise.resolve()) : (t = y.isGroupActive(this.healthSignatureGroup), o = "1" === I.readCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION), e && t && o ? Promise.resolve() : new Promise(function(e) {
            n.showHealthSignatureModal(e)
        })) : ((t = y.isGroupActive(this.healthSignatureGroup)) && Nr.setDataSubjectIdV2(D.healthSignatureData), I.writeCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION, t ? "1" : ""), Promise.resolve()) : (e = "🛑 INVALID Cookie category: " + N.RequireSignatureCID, Promise.reject(e)))
    }, er.prototype.getHealthSignatureComponent = function(e, t) {
        this.isModal = !1, this.langJson = N, this.parentElement = e, this.healthSignatureGroup = t;
        e = {
            errorMessage: this.langJson.PCRequireSignatureHelpText,
            inputLabelText: this.langJson.PCRequireSignatureFieldLabel
        }, t = '<form class="ot-signature-health-form" id="form">\n        <div class="ot-input-field-cont">\n            <label for="otHealthSignatureData" class="ot-signature-label">' + e.inputLabelText + '</label>\n            <input type="text" id="otHealthSignatureData" name="otHealthSignatureData" required aria-required="true" class="ot-signature-input"\n                aria-label="' + e.inputLabelText + '" autofocus aria-invalid="true" aria-describedby="otHealthSignatureErrorMesg"/>\n            <span id="otHealthSignatureErrorMesg" class="ot-health-signature-error">\n                ' + e.errorMessage + "\n            </span>\n        </div>\n    </form>", e = document.createElement("div");
        e.innerHTML = S.getInnerHtmlContent(t), e.classList.add("ot-signature-health-group"), this.setConsentIdInput(e), this.healthSignatureElement = e, this.parentElement.appendChild(e), this.addEventHandlers()
    }, er.prototype.resetHealthSignatureData = function(e) {
        void 0 === e && (e = !1), D.requireSignatureEnabled && (D.healthSignatureData = "", D.healthSignatureGroup = null, e) && I.writeCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION, "")
    }, er.prototype.setConsentIdInPC = function() {
        this.setConsentIdInput(null)
    }, er.prototype.setConsentIdInput = function(e) {
        var t;
        this.healthSignatureGroup && (I.readCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION) ? (t = (e || document).querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR)) && (e = "", y.isGroupActive(this.healthSignatureGroup) && (e = I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID)), t.value = e) : (t = document.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR)) && (t.value = ""))
    }, er.prototype.showHealthSignatureModal = function(t) {
        var o = this;
        Jo.hideConsentNoticeV2(), this.langJson = N, this.parentElement = document.querySelector(this.PARENT_SELECTOR), this.setMyHealthDataModal(function(e) {
            o.setSignHealthDataIntoCookieGroup(e), t()
        }, function() {
            y.toggleGrpStatus(o.healthSignatureGroup, !1), y.toggleGroupHtmlElement(o.healthSignatureGroup, o.healthSignatureGroup.CustomGroupId, !1), t()
        })
    }, er.prototype.setMyHealthDataModal = function(e, t) {
        this.isModal = !0, this.rejectCallback = t, this.confirmCallback = e, this.configOptions = {
            mainTitle: this.healthSignatureGroup.GroupName,
            description: this.healthSignatureGroup.GroupDescription,
            subtitle: this.langJson.PCRequireSignatureHeaderText,
            ariaLabel: this.langJson.PCRequireSignatureHeaderDesc,
            errorMessage: this.langJson.PCRequireSignatureHelpText,
            subDescription: this.langJson.PCRequireSignatureHeaderDesc,
            inputLabelText: this.langJson.PCRequireSignatureFieldLabel,
            rejectButtonText: this.langJson.PCRequireSignatureRejectBtnText,
            acceptButtonText: this.langJson.PCRequireSignatureConfirmBtnText
        };
        t = document.createDocumentFragment(), e = this.createModal(t);
        this.healthSignatureElement = this.createHealtSignatureForm(e), this.parentElement.appendChild(t), this.setFocusOnInput(), this.addEventHandlers(), this.genericModal.openModalHandler()
    }, er.prototype.setSignHealthDataIntoCookieGroup = function(e) {
        e ? (Nr.setDataSubjectIdV2(e), D.healthSignatureData = e, y.toggleGrpStatus(this.healthSignatureGroup, !0)) : (D.healthSignatureData = "", y.toggleGrpStatus(this.healthSignatureGroup, !1)), I.writeCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION, e ? "1" : "")
    }, er.prototype.createModal = function(e) {
        return this.genericModal = Zn(this.MODAL_ID, this.parentElement), e.appendChild(this.genericModal.dialogLayerHtml), this.genericModal.modalHtml
    }, er.prototype.createHealtSignatureForm = function(e) {
        t = this.configOptions, o = !0 === (null == (o = k.moduleInitializer) ? void 0 : o.SEOOptimization);
        var t, o = '<div\n        class="ot-signature-health"\n        role="dialog"\n        aria-label="' + t.ariaLabel + '"\n        aria-describedby="otSignatureGroupDesc">\n        <section class="ot-signature-cont">\n            ' + (o ? '<p id="otSignatureSubtitle" class="ot-signature-subtitle" role="heading" aria-level="4">' + t.subtitle + "</p>" : '<h4 id="otSignatureSubtitle" class="ot-signature-subtitle">' + t.subtitle + "</h4>") + '\n            <p class="ot-signature-paragraph">' + t.subDescription + '</p>\n        </section>\n        <section class="ot-signature-cont">\n            ' + (o ? '<p id="otSignatureGroupTitle" class="ot-signature-group-title" role="heading" aria-level="5">' + t.mainTitle + "</p>" : '<h5 id="otSignatureGroupTitle" class="ot-signature-group-title">' + t.mainTitle + "</h5>") + '\n            <p id="otSignatureGroupDesc" class="ot-signature-paragraph">' + t.description + '</p>\n        </section>\n        <form class="ot-signature-health-form" id="form">\n            <label for="otHealthSignatureData" class="ot-signature-label">' + t.inputLabelText + '</label>\n            <input type="text" id="otHealthSignatureData" name="otHealthSignatureData" required aria-required="true" class="ot-signature-input"\n                aria-label="' + t.inputLabelText + '" autofocus aria-invalid="true" aria-describedby="otHealthSignatureErrorMesg"/>\n            <span id="otHealthSignatureErrorMesg" class="ot-health-signature-error" aria-live="assertive">\n                ' + t.errorMessage + '\n            </span>\n        </form>\n        <div class="ot-signature-buttons-cont">\n            <button class="ot-signature-button reject">' + t.rejectButtonText + '</button>\n            <button class="ot-signature-button accept">' + t.acceptButtonText + "</button>\n        </div>\n    </div>";
        return e.innerHTML = S.getInnerHtmlContent(o), this.setConsentIdInput(e), this.addStyles(), e.querySelector(".ot-signature-health")
    }, er.prototype.addEventHandlers = function() {
        this.isModal ? (this.parentElement.querySelector(this.REJECT_SELECTOR).addEventListener("click", this.rejectListener.bind(this)), this.parentElement.querySelector(this.CONFIRM_SELECTOR).addEventListener("click", this.confirmListener.bind(this))) : this.parentElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).addEventListener("keyup", this.healthSignatureInputChanged.bind(this))
    }, er.prototype.removeModal = function() {
        this.removeEventHandlers(), this.genericModal.closeModalHandler()
    }, er.prototype.removeEventHandlers = function() {
        this.isModal ? (this.parentElement.querySelector(this.REJECT_SELECTOR).removeEventListener("click", this.rejectListener), this.parentElement.querySelector(this.CONFIRM_SELECTOR).removeEventListener("click", this.confirmListener)) : this.parentElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).removeEventListener("keyup", this.healthSignatureInputChanged)
    }, er.prototype.rejectListener = function() {
        this.removeModal(), this.rejectCallback && this.rejectCallback()
    }, er.prototype.confirmListener = function() {
        var e = this.healthSignatureElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).value;
        e && (this.removeModal(), this.confirmCallback(e))
    }, er.prototype.healthSignatureInputChanged = function(e) {
        D.healthSignatureData = e.target.value
    }, er.prototype.setFocusOnInput = function() {
        this.healthSignatureElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).focus()
    }, er.prototype.addStyles = function() {
        var e = "",
            t = (e = (e = (e += this.setParagraphStyles()) + this.setAcceptButtonsStyles()) + this.setRejectButtonsStyles(), document.getElementById("onetrust-style"));
        t.textContent = t.textContent + e
    }, er.prototype.setRejectButtonsStyles = function() {
        return "#onetrust-consent-sdk .ot-signature-health " + this.REJECT_SELECTOR + " {\n            color: " + N.bannerMPButtonTextColor + ";\n            border-color: " + N.bannerMPButtonTextColor + ";\n            background-color: " + N.bannerMPButtonColor + ";\n        }"
    }, er.prototype.setAcceptButtonsStyles = function() {
        return "#onetrust-consent-sdk .ot-signature-health " + this.CONFIRM_SELECTOR + " {\n            color: " + N.buttonTextColor + ";\n            border-color: " + N.buttonColor + ";\n            background-color: " + N.buttonColor + ";\n        }"
    }, er.prototype.setParagraphStyles = function() {
        return this.HEALTH_SIGNATURE_PARAGRAPH_SELECTOR + " {\n            color: " + N.textColor + ";\n        }"
    }, er.prototype.getGroupToggleHtmlValue = function() {
        var e = this.healthSignatureGroup.CustomGroupId,
            e = document.querySelector("input#ot-group-id-" + e + ", input#ot-bnr-hdr-id-" + e + ", input#ot-bnr-grp-id-" + e);
        return !!e && !0 === e.checked
    };
    var $n = er;

    function er() {
        this.MODAL_ID = "healthSignatureDataModal", this.PARENT_SELECTOR = "#onetrust-consent-sdk", this.REJECT_SELECTOR = ".ot-signature-button.reject", this.CONFIRM_SELECTOR = ".ot-signature-button.accept", this.HEALTH_SIGNATURE_INPUT_SELECTOR = "#otHealthSignatureData", this.HEALTH_SIGNATURE_PARAGRAPH_SELECTOR = "p.ot-signature-paragraph"
    }

    function tr(t, e) {
        var o = [""];
        e && (o.push("domain=" + e + ";"), e.startsWith(".") || o.push("domain=." + e + ";")), o.forEach(function(e) {
            e = t + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;" + (e ? " " + e : "");
            document.cookie = e, document.cookie = e + " SameSite=None; Secure;"
        })
    }

    function or(e, t) {
        var o;
        null != (o = null == (o = k) ? void 0 : o.fp) && o.CmpOptOutCookieDeletion && 0 !== (o = e.filter(function(e) {
            return !t.includes(e)
        })).length && o.forEach(function(e) {
            e = L.getGroupById(e);
            e && e.FirstPartyCookies && e.FirstPartyCookies.filter(function(e) {
                return !e.isThirdParty
            }).forEach(function(e) {
                var t, o, n;
                e.patternKey ? (t = e.patternKey, o = e.Host, n = new RegExp(t), document.cookie.split(";").forEach(function(e) {
                    e = e.split("=")[0].trim();
                    e && n.test(e) && tr(e, o)
                })) : tr(e.Name, e.Host)
            })
        })
    }

    function nr(e) {
        return e ? e.split(",").filter(function(e) {
            return 0 < e.trim().length
        }) : []
    }
    ir.prototype.updateDataSubjectTimestamp = function() {
        var e = B.alertBoxCloseDate(),
            e = e && h.getUTCFormattedDate(e);
        m(".ot-userid-timestamp").html(N.PCenterUserIdTimestampTitleText + ": " + e)
    }, ir.prototype.closeBanner = function(e, t) {
        var o = this;
        void 0 === t && (t = !1), e ? (e = h.shouldShowDoubleOptInSignal(!0), !t && e ? h.createDoubleOptInConfirmDialog(!1, function() {
            o.closeOptanonAlertBox(), o.allowAll(!1)
        }, function() {
            N.OnClickCloseBanner && document.body.addEventListener("click", g.bodyClickEvent), N.ScrollCloseBanner && window.addEventListener("scroll", g.scrollCloseBanner)
        }) : (this.closeOptanonAlertBox(), this.isAutoCloseTrigger = !0, this.allowAll(!1), this.isAutoCloseTrigger = !1)) : (this.checkImplicitConsentWhenBannerIsClosed(!1), this.closeOptanonAlertBox(), this.close(!1))
    }, ir.prototype.allowAll = function(e, t) {
        void 0 === t && (t = !1), k.moduleInitializer.MobileSDK ? window.OneTrust.AllowAll() : this.AllowAllV2(e, t)
    }, ir.prototype.bannerActionsHandler = function(t, n, e) {
        var r = this,
            o = (void 0 === e && (e = !1), nr(window.OptanonActiveGroups)),
            i = (Ao.setLandingPathParam(A.NOT_LANDING_PAGE), w.groupsConsent = [], w.hostsConsent = [], w.genVendorsConsent = {}, {});
        N.Groups.forEach(function(e) {
            if (e.IsAboutGroup) return !1;
            U(e.SubGroups, [e]).forEach(function(e) {
                var o = r.getGroupStatus(t, n, e);
                r.setGroupConsent(o, e), e.Hosts.length && h.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    var t;
                    i[e.HostId] ? Io.updateHostStatus(e, o) : (i[e.HostId] = !0, t = Io.isHostPartOfAlwaysActiveGroup(e.HostId), w.hostsConsent.push(e.HostId + ":" + (t || o ? "1" : "0")))
                }), w.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    mo.updateGenVendorStatus(e, o)
                })
            })
        }), N.IsIabEnabled && (t ? this.iab.allowAllhandler() : this.iab.rejectAllHandler(e)), Ro.removeAddedOTCssStyles(), Jo.hideConsentNoticeV2(), go.writeGrpParam(P.OPTANON_CONSENT), go.writeHstParam(P.OPTANON_CONSENT), w.genVenOptOutEnabled && go.writeGenVenCookieParam(P.OPTANON_CONSENT), w.vsIsActiveAndOptOut && go.writeVSConsentCookieParam(P.OPTANON_CONSENT), on.substitutePlainTextScriptTags(), Zo.updateGtmMacros(), or(o, nr(window.OptanonActiveGroups)), this.executeOptanonWrapper(), this.shouldApplyGpcOverride() && this.resetConsentUI(), this.updateFloatingBtnOptOutNotification(), null != (o = null == (e = k) ? void 0 : e.moduleInitializer) && o.BannerRefreshAfterCallToActionEnabled && this.reloadPage()
    }, ir.prototype.getGroupStatus = function(e, t, o) {
        return e ? !(this.shouldApplyGpcOverride() && o.IsGpcEnabled || this.isAutoCloseTrigger && D.DNTEnabled && o.IsDntEnabled && o.Status.toLowerCase() !== f.ALWAYS_INACTIVE && o.Status.toLowerCase() !== f.ALWAYS_ACTIVE || o.Status.toLowerCase() === f.ALWAYS_INACTIVE) : !!t && L.isAlwaysActiveGroup(o)
    }, ir.prototype.shouldApplyGpcOverride = function() {
        return this.isAutoCloseTrigger && D.gpcEnabled && D.gpcForAGrpEnabled
    }, ir.prototype.setGroupConsent = function(e, t) {
        var o; - 1 < Nt.indexOf(t.Type) && (o = "", o = D.requireSignatureEnabled && t.needsHealthSignature ? D.healthSignatureData ? "1" : "0" : e && t.HasConsentOptOut ? "1" : "0", e = v.findIndex(w.groupsConsent, function(e) {
            return e.split(":")[0] === t.CustomGroupId
        }), o = t.CustomGroupId + ":" + o, -1 < e ? w.groupsConsent[e] = o : w.groupsConsent.push(o))
    }, ir.prototype.applyAlwaysActiveInactiveGroupConsent = function() {
        var r = this,
            i = {};
        N.Groups.forEach(function(n) {
            U(n.SubGroups, [n]).forEach(function(e) {
                var t, o = null == (o = n.Status) ? void 0 : o.toLowerCase();
                o === f.ALWAYS_ACTIVE ? t = !0 : o === f.ALWAYS_INACTIVE && (t = !1), o !== f.ALWAYS_ACTIVE && o !== f.ALWAYS_INACTIVE || (r.setGroupConsent(t, n), e.Hosts.length && h.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    i[e.HostId] ? Io.updateHostStatus(e, t) : (i[e.HostId] = !0, w.hostsConsent.push(e.HostId + ":" + (t ? "1" : "0")))
                }), w.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    mo.updateGenVendorStatus(e, t)
                }))
            })
        })
    }, ir.prototype.nextPageCloseBanner = function() {
        Ao.isLandingPage() || B.isAlertBoxClosedAndValid() || this.closeBanner(N.NextPageAcceptAllCookies, !0)
    }, ir.prototype.rmScrollAndClickBodyEvents = function() {
        N.ScrollCloseBanner && window.removeEventListener("scroll", this.scrollCloseBanner), N.OnClickCloseBanner && document.body.removeEventListener("click", this.bodyClickEvent)
    }, ir.prototype.onClickCloseBanner = function(e) {
        B.isAlertBoxClosedAndValid() || (uo.triggerGoogleAnalyticsEvent(fn, Sn), this.closeBanner(N.OnClickAcceptAllCookies)), g.rmScrollAndClickBodyEvents()
    }, ir.prototype.scrollCloseBanner = function() {
        var e = m(document).height() - m(window).height(),
            e = (0 === e && (e = m(window).height()), 100 * m(window).scrollTop() / e);
        25 < (e = e <= 0 ? 100 * (document.scrollingElement && document.scrollingElement.scrollTop || document.documentElement && document.documentElement.scrollTop || document.body && document.body.scrollTop) / (document.scrollingElement && document.scrollingElement.scrollHeight || document.documentElement && document.documentElement.scrollHeight || document.body && document.body.scrollHeight) : e) && !B.isAlertBoxClosedAndValid() && (!w.isPCVisible || N.NoBanner) ? (uo.triggerGoogleAnalyticsEvent(fn, Sn), g.closeBanner(N.ScrollAcceptAllCookies), g.rmScrollAndClickBodyEvents()) : B.isAlertBoxClosedAndValid() && g.rmScrollAndClickBodyEvents()
    }, ir.prototype.AllowAllV2 = function(e, t) {
        void 0 === t && (t = !1);
        for (var o = this.groupsClass.getAllGroupElements(), n = t ? Ce[4] : Ce[1], r = 0; r < o.length; r++) {
            var i = L.getGroupById(o[r].getAttribute("data-optanongroupid"));
            D.requireSignatureEnabled && i.needsHealthSignature ? this.groupsClass.toggleGrpElements(o[r], i, !!D.healthSignatureData) : (this.groupsClass.toggleGrpElements(o[r], i, !0), this.groupsClass.toogleSubGroupElement(o[r], !0, !1, !0), this.groupsClass.toogleSubGroupElement(o[r], !0, !0, !0))
        }
        w.showVendorService && O.consentAll(!0), this.bannerActionsHandler(!0, !1), h.updateIntTypeFromCookie(), n !== w.consentInteractionType && this.consentTransactions(e, !0, t), N.IsIabEnabled && (this.iab.updateIabVariableReference(), this.iab.updateVendorsDOMToggleStatus(!0), this.updateVendorLegBtns(!0))
    }, ir.prototype.rejectAll = function(e, t) {
        for (var o, n, r = (t = void 0 === t ? !1 : t) ? Ce[5] : Ce[2], i = this.groupsClass.getAllGroupElements(), s = null != (o = null == (o = k) ? void 0 : o.fp) && o.CookieV2RejectAll ? (n = this.initializeObjectToLIRejectAll(t), this.initializeAllowLIRejectAll(t)) : !(n = !0), a = 0; a < i.length; a++) {
            var l = L.getGroupById(i[a].getAttribute("data-optanongroupid"));
            "always active" !== L.getGrpStatus(l).toLowerCase() && (y.toggleGrpElements(i[a], l, !1, s), this.groupsClass.toogleSubGroupElement(i[a], !1, !1, !0), N.IsIabEnabled && (N.IsIabEnabled, !n) || this.groupsClass.toogleSubGroupElement(i[a], !1, !0, !0))
        }
        w.showVendorService && O.consentAll(!1), this.bannerActionsHandler(!1, !0, s), h.updateIntTypeFromCookie(), r !== w.consentInteractionType && this.consentTransactions(e, !1, t), N.IsIabEnabled && (this.iab.updateIabVariableReference(), this.iab.updateVendorsDOMToggleStatus(!1, s), s || this.updateVendorLegBtns(!1))
    }, ir.prototype.initializeObjectToLIRejectAll = function(e) {
        return !e && N.BannerShowRejectAllButton && N.BRejectConsentType === Le.OBJECT_TO_LI || e && N.PCenterShowRejectAllButton && N.BRejectConsentType === Le.OBJECT_TO_LI
    }, ir.prototype.initializeAllowLIRejectAll = function(e) {
        return N.IsIabEnabled && (!e && N.BannerShowRejectAllButton && N.BRejectConsentType === Le.LI_ACTIVE_IF_LEGAL_BASIS || e && N.PCenterShowRejectAllButton && N.BRejectConsentType === Le.LI_ACTIVE_IF_LEGAL_BASIS)
    }, ir.prototype.updateConsentData = function(e) {
        Ao.setLandingPathParam(A.NOT_LANDING_PAGE), N.IsIabEnabled && !e && this.iab.saveVendorStatus(), go.writeGrpParam(P.OPTANON_CONSENT), go.writeHstParam(P.OPTANON_CONSENT), w.showGeneralVendors && N.GenVenOptOut && go.writeGenVenCookieParam(P.OPTANON_CONSENT), w.vsIsActiveAndOptOut && go.writeVSConsentCookieParam(P.OPTANON_CONSENT), on.substitutePlainTextScriptTags(), Zo.updateGtmMacros()
    }, ir.prototype.close = function(e, t) {
        void 0 === t && (t = te.Banner);
        var o, n = nr(window.OptanonActiveGroups);
        Jo.hideConsentNoticeV2(), this.applyAlwaysActiveInactiveGroupConsent(), this.updateConsentData(e), or(n, nr(window.OptanonActiveGroups)), N.IsConsentLoggingEnabled ? (o = t === te.PC ? gn : t === te.Banner ? un : D.apiSource, e = t === te.PC ? cn : t === te.Banner ? ln : dn, w.bannerCloseSource === ee.ContinueWithoutAcceptingButton && (o = yn), w.bannerCloseSource === ee.BannerSaveSettings && (o = hn), n = this.setInteractionType(e, o), Ms.resetForceReceiptCooloff(), Ms.createConsentTxn(!1, n, t === te.PC), t === te.API && (D.apiSource = void 0)) : B.dispatchConsentEvent(), this.executeOptanonWrapper(), this.updateFloatingBtnOptOutNotification(), null == (n = null == (e = k) ? void 0 : e.moduleInitializer) || !n.BannerRefreshAfterCallToActionEnabled || o !== hn && o !== gn || this.reloadPage()
    }, ir.prototype.setInteractionType = function(t, o) {
        try {
            var e = t + " - " + o;
            return e = N.NoBanner && N.ShowPreferenceCenterCloseButton && t === cn && w.bannerCloseSource === ee.BannerCloseButton && t !== dn ? Ce[13] : e
        } catch (e) {
            return t + " - " + o
        }
    }, ir.prototype.reloadPage = function() {
        console.warn("Triggering Page Refresh"), setTimeout(function() {
            location.reload()
        }, 200)
    }, ir.prototype.executeOptanonWrapper = function() {
        try {
            if ("function" == typeof window.OptanonWrapper && "undefined" !== window.OptanonWrapper) {
                window.OptanonWrapper();
                for (var e = 0, t = w.srcExecGrpsTemp; e < t.length; e++) {
                    var o = t[e]; - 1 === w.srcExecGrps.indexOf(o) && w.srcExecGrps.push(o)
                }
                w.srcExecGrpsTemp = [];
                for (var n = 0, r = w.htmlExecGrpsTemp; n < r.length; n++) {
                    o = r[n]; - 1 === w.htmlExecGrps.indexOf(o) && w.htmlExecGrps.push(o)
                }
                w.htmlExecGrpsTemp = []
            }
        } catch (e) {
            console.warn("Error in Optanon wrapper, please review your code. " + e)
        }
    }, ir.prototype.updateVendorLegBtns = function(e) {
        if (D.legIntSettings.PAllowLI && D.legIntSettings.PShowLegIntBtn)
            for (var t = m(T.P_Vendor_Container + " .ot-leg-btn-container").el, o = 0; o < t.length; o++) this.groupsClass.updateLegIntBtnElement(t[o], e)
    }, ir.prototype.updateFloatingBtnOptOutNotification = function() {
        js.csBtnGroup && h.syncOptOutNotification()
    }, ir.prototype.showFltgCkStgButton = function() {
        var e = m("#ot-sdk-btn-floating"),
            e = (e.removeClass("ot-hide"), e.removeClass("ot-pc-open"), N.cookiePersistentLogo.includes("ot_guard_logo.svg") && m(g.fltgFrontBtnSvg).attr(Tt, ""), m(g.fltgBackBtnSvg).attr(Tt, "true"), document.querySelector(g.fltgBtnBackBtn)),
            t = document.querySelector(g.fltgBtnFrontBtn);
        t && (t.setAttribute(Tt, "false"), t.style.display = "block"), e && (e.setAttribute(Tt, "true"), e.style.display = "none")
    }, ir.prototype.consentTransactions = function(e, t, o) {
        void 0 === o && (o = !1), Ms && !e && N.IsConsentLoggingEnabled ? (Ms.resetForceReceiptCooloff(), e = void 0, e = D.apiSource ? dn : o ? cn : ln, Ms.createConsentTxn(!1, e + " - " + (t ? pn : Cn), o), D.apiSource = void 0) : B.dispatchConsentEvent()
    }, ir.prototype.hideVendorsList = function() {
        Jo.checkIfPcSdkContainerExist() || (N.PCTemplateUpgrade ? m("#onetrust-pc-sdk " + T.P_Content).removeClass("ot-hide") : m("#onetrust-pc-sdk .ot-main-content").show(), m("#onetrust-pc-sdk #close-pc-btn-handler.main").show(), m("#onetrust-pc-sdk " + T.P_Vendor_List).addClass("ot-hide"))
    }, ir.prototype.resetConsent = function() {
        var e = this,
            t = this.getInitialConsent();
        w.groupsConsent = JSON.parse(JSON.stringify(t)), w.hostsConsent = JSON.parse(JSON.stringify(w.initialHostConsent)), w.showGeneralVendors && (w.genVendorsConsent = JSON.parse(JSON.stringify(w.initialGenVendorsConsent))), w.vsIsActiveAndOptOut && (w.vsConsent = new Map(w.initialVendorsServiceConsent)), N.IsIabEnabled && (w.oneTrustIABConsent = JSON.parse(JSON.stringify(w.initialOneTrustIABConsent)), w.vendors = JSON.parse(JSON.stringify(w.initialVendors)), w.vendors.vendorTemplate = w.initialVendors.vendorTemplate), N.UseGoogleVendors && (w.addtlVendors = JSON.parse(JSON.stringify(w.initialAddtlVendors)), w.addtlVendorsList = JSON.parse(JSON.stringify(w.initialAddtlVendorsList))), setTimeout(function() {
            e.resetConsentUI()
        }, 400)
    }, ir.prototype.getInitialConsent = function() {
        var e;
        return N.NoBanner && N.ShowPreferenceCenterCloseButton && 0 < D.consentableImpliedConsentGroup.length ? (e = w.initialGroupsConsent.map(function(e) {
            var t = e.split(":")[0];
            return D.consentableImpliedConsentGroup.find(function(e) {
                return e.CustomGroupId === t
            }) ? t + ":1" : e
        }), D.consentableImpliedConsentGroup = [], e) : w.initialGroupsConsent
    }, ir.prototype.setLblTxtForTgl = function(e, t) {
        e = e.querySelector(".ot-label-status");
        N.PCShowConsentLabels && e && (e.innerHTML = S.getInnerHtmlContent(t ? N.PCActiveText : N.PCInactiveText))
    }, ir.prototype.resetConsentUI = function() {
        var p = this;
        y.getAllGroupElements().forEach(function(e) {
            var t = e.getAttribute("data-optanongroupid"),
                t = L.getGroupById(t),
                o = y.isGroupActive(t),
                n = b.GroupTypes;
            if (D.pcName === at && N.PCTemplateUpgrade && (e = document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid"))), p.setLblTxtForTgl(e, o), t.Type === bt || t.Type === n.Stack || 0 < (null == (n = t.SubGroups) ? void 0 : n.length))
                for (var r = e.querySelector('input[class*="category-switch-handler"]'), i = (v.setCheckedAttribute(null, r, o), e.querySelectorAll("li" + T.P_Subgrp_li)), s = 0; s < i.length; s++) {
                    var a = L.getGroupById(i[s].getAttribute("data-optanongroupid")),
                        l = (a.OptanonGroupId, y.isGroupActive(a)),
                        c = i[s].querySelector('input[class*="cookie-subgroup-handler"]'),
                        d = i[s].querySelector(".ot-label-status"),
                        u = e.querySelector(".ot-label-status");
                    N.PCShowConsentLabels && d && (u.innerHTML = S.getInnerHtmlContent(l ? N.PCActiveText : N.PCInactiveText)), v.setCheckedAttribute(null, c, l), g.resetLegIntButton(a, i[s])
                } else {
                    r = e.querySelector('input[class*="category-switch-handler"]');
                    v.setCheckedAttribute(null, r, o), g.resetLegIntButton(t, e)
                }
        }), N.IsIabEnabled && zn.toggleVendorConsent(), this.resetGenVenUI(), this.resetGoogleVenUI(), w.vsIsActiveAndOptOut && O.resetVendorUIState(w.vsConsent)
    }, ir.prototype.resetGenVenUI = function() {
        var e = m("#onetrust-pc-sdk .ot-gnven-chkbox-handler").el;
        if (w.showGeneralVendors && e && e.length) {
            for (var t = 0, o = e; t < o.length; t++) {
                var n = o[t],
                    r = n.getAttribute("gn-vid"),
                    i = Boolean(w.genVendorsConsent[r]);
                v.setCheckedAttribute("", n, i), mo.updateGenVendorStatus(r, i)
            }
            C.genVenSelectAllTglEvent()
        }
    }, ir.prototype.resetGoogleVenUI = function() {
        var e = m("#onetrust-pc-sdk .ot-addtlven-chkbox-handler").el;
        if (N.UseGoogleVendors && e && e.length)
            for (var t = 0, o = e; t < o.length; t++) {
                var n = o[t],
                    r = n.getAttribute("addtl-vid");
                w.addtlVendorsList[r] && (r = Boolean(w.addtlVendors.vendorSelected[r]), v.setCheckedAttribute("", n, r))
            }
    }, ir.prototype.resetLegIntButton = function(e, t) {
        var o;
        D.legIntSettings.PAllowLI && e.Type === b.GroupTypes.Pur && e.HasLegIntOptOut && D.legIntSettings.PShowLegIntBtn && (o = !0, -1 < w.vendors.selectedLegInt.indexOf(e.IabGrpId + ":false") && (o = !1), y.updateLegIntBtnElement(t, o))
    }, ir.prototype.handleTogglesOnSingularConsentUpdate = function(e, t) {
        if (this.closeOptanonAlertBox(), e === yt)
            for (var s = this, o = 0, n = t; o < n.length; o++) {
                var r = n[o];
                ((e, t) => {
                    for (var o = L.getGroupById(e), n = s.groupsClass.getAllGroupElements(), r = 0; r < n.length; r++) {
                        var i = L.getGroupById(n[r].getAttribute("data-optanongroupid"));
                        if (i.OptanonGroupId === o.OptanonGroupId && !i.Parent) {
                            u.toggleV2Category(null, i, t, i.CustomGroupId);
                            break
                        }
                        i = i.SubGroups.find(function(e) {
                            return e.OptanonGroupId === o.OptanonGroupId
                        });
                        i && u.toggleSubCategory(null, i.CustomGroupId, t, i.CustomGroupId)
                    }
                })(c = r.id, d = r.isEnabled)
            } else if (e === mt)
                for (var i = 0, a = t; i < a.length; i++) {
                    var l = a[i],
                        c = l.id,
                        d = l.isEnabled,
                        l = L.getGrpByVendorId(c);
                    l && O.toggleVendorService(l.CustomGroupId, c, d)
                }
        this.close(!1, te.API)
    }, ir.prototype.checkImplicitConsentWhenBannerIsClosed = function(e) {
        var t;
        void 0 === e && (e = !1), B.isAlertBoxClosedAndValid() || !Ao.isLandingPage() && !e || (w.bannerCloseSource === ee.BannerCloseButton && D.resetImpliedConsentableGroups(), t = new Map, D.consentableImpliedConsentGroup.forEach(function(n) {
            var r;
            n.Status === f.INACTIVE_LANDING_PAGE && 0 <= (r = v.findIndex(w.groupsConsent, function(e) {
                return e.split(":")[0] === n.CustomGroupId
            })) && (t.set(n.CustomGroupId, n), U(n.SubGroups, [n]).forEach(function(e) {
                var t = D.gpcEnabled && e.IsGpcEnabled,
                    o = D.DNTEnabled && e.IsDntEnabled;
                w.groupsConsent[r] = n.CustomGroupId + ":1", (t || o) && (w.groupsConsent[r] = n.CustomGroupId + ":0"), !t && !o && e.Hosts.length && h.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    return Io.updateHostStatus(e, !0)
                }), !t && !o && w.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    return mo.updateGenVendorStatus(e, !0)
                })
            }))
        }), this.setImplicitConsentUI(t))
    }, ir.prototype.setImplicitConsentUI = function(e) {
        var o = this;
        e.size <= 0 || e.forEach(function(e, t) {
            t = o.getGroupElement(t);
            t && (o.groupsClass.toggleGrpElements(t, e, !0), o.groupsClass.toogleSubGroupElement(t, !0, !1, !0), o.groupsClass.toogleSubGroupElement(t, !0, !0, !0))
        })
    }, ir.prototype.getGroupElement = function(e) {
        return document.querySelector("div#onetrust-pc-sdk " + T.P_Category_Grp + " " + T.P_Category_Item + '[data-optanongroupid="' + e + '"]:not(.ot-vnd-item)')
    };
    var g, rr = ir;

    function ir() {
        var n = this;
        this.iab = C, this.groupsClass = y, this.isAutoCloseTrigger = !1, this.fltgBackBtnSvg = ".ot-floating-button__back svg", this.fltgFrontBtnSvg = ".ot-floating-button__front svg", this.fltgBtnBackBtn = ".ot-floating-button__back button", this.fltgBtnFrontBtn = ".ot-floating-button__front button", this.closeOptanonAlertBox = function() {
            var e;
            h.hideBanner(), m(document).off("keydown", u.closePCWhenEscPressed), N.NtfyConfig.ShowNtfy && an.hideSyncNtfy(), uo.setAlertBoxClosed(!0), N.PCTemplateUpgrade && N.PCenterUserIdTitleText && N.IsConsentLoggingEnabled && n.updateDataSubjectTimestamp(), B.isAlertBoxClosedAndValid() && (e = m(".onetrust-pc-dark-filter").el[0]) && "none" !== getComputedStyle(e).getPropertyValue("display") && m(".onetrust-pc-dark-filter").fadeOut(400), js.csBtnGroup && n.showFltgCkStgButton()
        }, this.bodyClickEvent = function(e) {
            var t = e.target;
            t.closest("#onetrust-banner-sdk") || t.closest("#onetrust-pc-sdk") || t.closest(".onetrust-pc-dark-filter") || t.closest(".ot-sdk-show-settings") || t.closest(".optanon-show-settings") || t.closest(".optanon-toggle-display") || t.closest(".ot-confirm-dialog-overlay") || g.onClickCloseBanner(e)
        }, this.bannerCloseButtonHandler = function(o) {
            return void 0 === o && (o = !1), F(n, void 0, void 0, function() {
                var t;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (g.checkImplicitConsentWhenBannerIsClosed(o), g.closeOptanonAlertBox(), k.moduleInitializer.MobileSDK) ? (window.OneTrust.Close(), [3, 5]) : [3, 1];
                        case 1:
                            return e.trys.push([1, 3, , 4]), [4, $n.getInstance().checkIfHealthSignatureNeeded()];
                        case 2:
                            return e.sent(), [3, 4];
                        case 3:
                            return t = e.sent(), console.error(t), [3, 4];
                        case 4:
                            t = te.Banner, (w.bannerCloseSource === ee.ConfirmChoiceButton || w.bannerCloseSource === ee.BannerCloseButton && w.pcClosedFromCloseBtn) && (t = te.PC), g.close(o, t), e.label = 5;
                        case 5:
                            return [2, !1]
                    }
                })
            })
        }, this.allowAllEventHandler = function(r) {
            return void 0 === r && (r = !1), F(n, void 0, void 0, function() {
                var o, t, n = this;
                return M(this, function(e) {
                    return m(document).off("keydown", u.shiftBannerFocus), o = r ? "Preferences Allow All" : "Banner Accept Cookies", t = function() {
                        return F(n, void 0, void 0, function() {
                            var t;
                            return M(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        uo.triggerGoogleAnalyticsEvent(fn, o), r && D.requireSignatureEnabled && (Jo.hideConsentNoticeV2(), this.closeOptanonAlertBox()), e.label = 1;
                                    case 1:
                                        return e.trys.push([1, 3, , 4]), [4, $n.getInstance().checkIfHealthSignatureNeeded(!0)];
                                    case 2:
                                        return e.sent(), [3, 4];
                                    case 3:
                                        return t = e.sent(), console.error(t), [3, 4];
                                    case 4:
                                        return this.allowAllEvent(!1, r), this.hideVendorsList(), [2]
                                }
                            })
                        })
                    }, h.shouldShowDoubleOptInSignal(!0) ? h.createDoubleOptInConfirmDialog(r, t) : t(), [2]
                })
            })
        }, this.allowAllEvent = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = !1), n.closeOptanonAlertBox(), g.allowAll(e, t)
        }, this.rejectAllEventHandler = function(e) {
            void 0 === e && (e = !1), m(document).off("keydown", u.shiftBannerFocus), uo.triggerGoogleAnalyticsEvent(fn, e ? "Preferences Reject All" : "Banner Reject All"), $n.getInstance().resetHealthSignatureData(!0), k.moduleInitializer.MobileSDK ? window.OneTrust.RejectAll() : (n.rejectAllEvent(!1, e), n.hideVendorsList())
        }, this.rejectAllEvent = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = !1), n.closeOptanonAlertBox(), !B.isIABCrossConsentEnabled() || D.thirdPartyiFrameLoaded ? n.rejectAll(e, t) : D.thirdPartyiFramePromise.then(function() {
                n.rejectAll(e, t)
            })
        }
    }
    lr.prototype.setFilterList = function(o) {
        var e, n = this,
            r = (m("#onetrust-pc-sdk #ot-filter-list-header").html(N.PCCookieListFiltersText), null == (e = null == (e = null == (e = m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Option)) ? void 0 : e.el) ? void 0 : e[0]) ? void 0 : e.cloneNode(!0));
        m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Options).html(""), (k.isV2Template || N.PCLayout.Popup) && (m(this.CANCEL_FILTER).html(N.PCenterCancelFiltersText || "Cancel"), m(this.CANCEL_FILTER).attr(vt, N.PCenterCancelFilterAriaLabel)), !k.isV2Template && N.PCLayout.Popup || (m("#onetrust-pc-sdk " + T.P_Clr_Fltr_Txt).html(N.PCenterClearFiltersText), m("#onetrust-pc-sdk " + T.P_Clr_Fltr_Txt).attr(vt, N.PCenterClearFiltersAriaLabel), e = h.getVendorPageHeaderText(), m("#filter-btn-handler").el[0].setAttribute("aria-label", N.PCenterFilterText + " " + e)), m("#onetrust-pc-sdk #filter-apply-handler").html(N.PCenterApplyFiltersText), m("#onetrust-pc-sdk #filter-apply-handler").attr(vt, N.PCenterApplyFiltersAriaLabel), o ? D.consentableGrps.forEach(function(e) {
            var t = w.cookieListType === ye.GenVen || w.cookieListType === ye.HostAndGenVen ? e.Hosts.length || e.FirstPartyCookies.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length : e.Hosts.length || e.FirstPartyCookies.length;
            t && n.filterGroupOptionSetter(r, e, o)
        }) : D.iabGrps.forEach(function(e) {
            n.filterGroupOptionSetter(r, e, o)
        }), this.setFilterAriaPositions()
    }, lr.prototype.setFilterListByGroup = function(e, t) {
        var o, n, r = this;
        !e || e.length <= 0 ? m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Options).html("") : (o = null == (n = null == (n = null == (n = m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Option)) ? void 0 : n.el) ? void 0 : n[0]) ? void 0 : n.cloneNode(!0), m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Options).html(""), (k.isV2Template || N.PCLayout.Popup) && (m(this.CANCEL_FILTER).html(N.PCenterCancelFiltersText || "Cancel"), m(this.CANCEL_FILTER).attr(vt, N.PCenterCancelFilterAriaLabel)), !k.isV2Template && N.PCLayout.Popup || (m("#onetrust-pc-sdk " + T.P_Clr_Fltr_Txt).html(N.PCenterClearFiltersText), m("#onetrust-pc-sdk " + T.P_Clr_Fltr_Txt).attr(vt, N.PCenterClearFiltersAriaLabel), n = h.getVendorPageHeaderText(), m("#filter-btn-handler").el[0].setAttribute("aria-label", N.PCenterFilterText + " " + n)), m("#onetrust-pc-sdk #filter-apply-handler").html(N.PCenterApplyFiltersText), e.forEach(function(e) {
            r.filterGroupOptionSetter(o, e, t)
        }), this.setFilterAriaPositions())
    }, lr.prototype.setFilterAriaPositions = function() {
        var e = document.querySelector("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Options),
            e = (e && e.setAttribute("role", "listbox"), document.querySelectorAll("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Option)),
            n = e.length;
        e.forEach(function(t, e) {
            t.setAttribute("role", "option"), t.setAttribute("tabindex", "0"), t.setAttribute("aria-selected", "false"), t.setAttribute("aria-setsize", n.toString()), t.setAttribute("aria-posinset", (e + 1).toString());
            var o = t.querySelector("input");
            o && (o.setAttribute("tabindex", "-1"), t.addEventListener("keydown", function(e) {
                " " !== e.key && "Enter" !== e.key || (e.preventDefault(), o.click(), t.setAttribute("aria-selected", String(o.checked)))
            }), t.addEventListener("click", function() {
                t.setAttribute("aria-selected", String(o.checked))
            }))
        })
    }, lr.prototype.filterGroupOptionSetter = function(e, t, o) {
        var n = t.CustomGroupId,
            r = n + "-filter";
        e && (e = e.cloneNode(!0), m(T.P_Fltr_Modal + " " + T.P_Fltr_Options).append(e), m(e.querySelector("input")).attr("id", r), m(e.querySelector("label")).attr("for", r), (k.isV2Template ? m(e.querySelector(T.P_Label_Txt)) : m(e.querySelector("label span"))).html(t.GroupName), m(e.querySelector("input")).attr(o ? "data-optanongroupid" : "data-purposeid", n))
    };
    var sr, ar = lr;

    function lr() {
        this.bodyScrollProp = "", this.htmlScrollProp = "", this.ONETRUST_PC_SDK = "#onetrust-pc-sdk", this.ONETRUST_PC_DARK_FILTER = ".onetrust-pc-dark-filter", this.CANCEL_FILTER = "#onetrust-pc-sdk #filter-cancel-handler"
    }
    ur.prototype.showParagraph = function(e) {
        var t = R({}, e),
            o = t.listTitle,
            n = t.htmlFragment,
            t = t.paragrphContainerSelector;
        cr.options = e, cr.hideOtherHtmlElements(e), cr.setParagraphTitle(o), cr.addItemListToRootElement(n, t)
    }, ur.prototype.hideParagraphUI = function() {
        var e = R({}, cr.options),
            t = e.showFooter;
        e.showSearchBox || (null != (e = cr.checkboxesContainerEle) && e.classList.remove("ot-hide"), null != (e = cr.searchInputContainerEle) && e.classList.remove("ot-hide"), null != (e = cr.listHotsVendorsContainerEle) && e.classList.remove("ot-hide")), t || (null != (e = cr.footerButtonContainerEle) && e.classList.remove("ot-hide"), u.setCenterLayoutFooterHeight()), cr.rootEle.removeChild(cr.paragraphContainerEle)
    }, ur.prototype.addItemListToRootElement = function(e, t) {
        var o = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_List);
        cr.rootEle = o.querySelector(this.MAIN_CONT_ELE), cr.rootEle.appendChild(e), cr.paragraphContainerEle = cr.rootEle.querySelector(t)
    }, ur.prototype.setParagraphTitle = function(e) {
        document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]').innerHTML = S.getInnerHtmlContent(e)
    }, ur.prototype.hideOtherHtmlElements = function(e) {
        var e = R({}, e),
            t = e.showFooter,
            e = e.showSearchBox,
            o = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_List),
            o = (!e && o && (cr.checkboxesContainerEle = o.querySelector(this.SEL_BLK_ELE), cr.searchInputContainerEle = o.querySelector(this.LST_SUBHDR_ELE), cr.listHotsVendorsContainerEle = o.querySelector(this.SDK_ROW_ELE), null != (e = cr.checkboxesContainerEle) && e.classList.add("ot-hide"), null != (o = cr.searchInputContainerEle) && o.classList.add("ot-hide"), null != (e = cr.listHotsVendorsContainerEle)) && e.classList.add("ot-hide"), document.querySelector("#onetrust-pc-sdk .ot-pc-footer .ot-btn-container"));
        !t && o && (cr.footerButtonContainerEle = o, null != (e = cr.footerButtonContainerEle) && e.classList.add("ot-hide"), u.setCenterLayoutFooterHeight())
    };
    var cr, dr = ur;

    function ur() {
        this.SDK_ROW_ELE = ".ot-sdk-row", this.SEL_BLK_ELE = "#ot-sel-blk", this.MAIN_CONT_ELE = "#ot-lst-cnt", this.LST_SUBHDR_ELE = ".ot-lst-subhdr"
    }
    gr.prototype.showIllustrations = function(e, t) {
        e = pr.insertParagraphContainer(e, t), t = {
            showFooter: !1,
            showSearchBox: !1,
            listTitle: N.PCIllusText,
            htmlFragment: e,
            paragrphContainerSelector: "." + this.PARAGRAPH_CONTAINER_ELE
        };
        cr.showParagraph(t)
    }, gr.prototype.hideUI = function() {
        cr.hideParagraphUI()
    }, gr.prototype.addIllustrationsLink = function(e, t, o, n) {
        void 0 === n && (n = !1);
        var r = t.IabIllustrations && 0 < t.IabIllustrations.length;
        o && r && N.PCGrpDescType === re.UserFriendly && (o = N.PCVendorFullLegalText + "&nbsp;", (r = document.createElement("button")).classList.add("ot-link-btn"), r.classList.add("ot-pgph-link"), r.setAttribute("aria-label", t.GroupName + ", " + N.PCVendorFullLegalText), r.setAttribute("data-parent-id", t.CustomGroupId), n ? (r.classList.add("ot-pgph-link-subgroup"), e.appendChild(r)) : (o = "&nbsp;|&nbsp" + o, e.insertAdjacentElement("afterend", r)), r.innerHTML = S.getInnerHtmlContent(o))
    }, gr.prototype.insertParagraphContainer = function(e, t) {
        var o = document.createDocumentFragment(),
            n = document.createElement("div"),
            e = (n.classList.add(this.PARAGRAPH_CONTAINER_ELE), pr.insertPurposeTitle(e)),
            r = (n.appendChild(e), document.createElement("div"));
        return r.classList.add("ot-paragraph-lst"), t.forEach(function(e, t) {
            e = pr.insertDescriptionElement(e, t);
            r.appendChild(e)
        }), n.appendChild(r), o.appendChild(n), o
    }, gr.prototype.insertPurposeTitle = function(e) {
        null != (o = k.moduleInitializer) && o.SEOOptimization ? ((t = document.createElement("p")).setAttribute("role", "heading"), t.setAttribute("aria-level", "4")) : t = document.createElement("h4"), t.classList.add("ot-pgph-title");
        var t, o = document.createTextNode(e);
        return t.appendChild(o), t
    }, gr.prototype.insertDescriptionElement = function(e, t) {
        var o = document.createElement("p");
        return o.setAttribute("id", "ot-pgph-desc-id-" + t), o.classList.add("ot-pgph-desc"), o.innerText = e, o
    };
    var pr, Cr = gr;

    function gr() {
        this.PARAGRAPH_CONTAINER_ELE = "ot-pgph-contr"
    }
    n.prototype.insertPcHtml = function() {
        _.jsonAddAboutCookies(N);
        var t = document.createDocumentFragment(),
            e = (js.preferenceCenterGroup && (o = document.createElement("div"), m(o).html(js.preferenceCenterGroup.html), o = o.querySelector("#onetrust-pc-sdk"), _.addClassesPerConfig(o), m(t).append(o), _.manageCloseButtons(o, o = function(e) {
                return t.querySelectorAll(e)
            }, n = function(e) {
                return t.querySelector(e)
            }), N.Language && N.Language.Culture && m(n("#onetrust-pc-sdk")).attr("lang", N.Language.Culture), _.addLogos(n, o), m(n(T.P_Title)).html(N.MainText), N.PCCloseButtonType === Ae.Link && N.PCTemplateUpgrade && D.pcName === at && m(n(T.P_Title)).addClass("ot-pc-title-shrink"), N.PCTemplateUpgrade && m(n(Uo + ' > div[role="dialog"]')).css("height: 100%;"), m(n(Uo + ' > div[role="dialog"]')).attr(this._ariaLabel, N.MainText), D.pcName === at && (null != (e = m(n(T.P_Title))) && e.attr("title", N.MainText), m(n(T.P_Privacy_Txt)).html(N.AboutCookiesText), m(n(T.P_Privacy_Hdr)).html(N.AboutCookiesText), null != (e = m(n("#onetrust-pc-sdk " + T.P_Content + " .ot-tab-list"))) && e.attr(this._ariaLabel, N.PCenterCookieCategoriesAriaLabel), _.updateTitleForMobileView(n)), e = '<span class="ot-tcf2-vendor-count ot-text-bold tcf2-vcount">' + D.tcf2ActiveVendors.all.toString() + "</span>", e = h.replaceTextFromString("[VENDOR_NUMBER]", N.MainInfoText, e), m(n(T.P_Policy_Txt)).html(e), _.configureLinkFields(n, o), _.configureSubjectDataFields(n), _.configureButtons(n, o), _.setManagePreferenceText(n), _.initializePreferenceCenterGroups(n, t), _.removeListsWhenAppropriate(n), h.addExternalIconForLinks(o), N.PCTemplateUpgrade) && _.setOptOutSignalNotification(n), document.createElement("iframe")),
            o = (e.setAttribute("class", "ot-text-resize"), e.setAttribute("sandbox", "allow-same-origin"), e.setAttribute("title", "onetrust-text-resize"), Ht(e, "position: absolute; top: -50000px; width: 100em;"), e.setAttribute(this._ariaHidden, "true"), m(t.querySelector("#onetrust-pc-sdk")).append(e), h.replaceHeadings(t), document.getElementById("onetrust-consent-sdk")),
            n = (m(o).append(t), D.ignoreInjectingHtmlCss || m(document.body).append(o), (N.showCookieList || w.showGeneralVendors) && on.InitializeHostList(), T.P_Vendor_List + " " + T.P_Host_Cntr + " li"),
            e = m(n).el[0];
        e && v.removeChild(e)
    }, n.prototype.updateTitleForMobileView = function(e) {
        function t() {
            var e = window.getComputedStyle(o.el).display;
            o.attr(_._ariaHidden, "none" !== e ? "false" : "true"), n.attr(_._ariaHidden, "none" !== e ? "true" : "false")
        }
        var o = m(e(T.P_Title_Mobile)),
            n = m(e(T.P_Title));
        o.html(N.MainText), setTimeout(t), m(window).on("resize", t)
    }, n.prototype.addClassesPerConfig = function(e) {
        /Chrome|Safari/i.test(navigator.userAgent) && /Google Inc|Apple Computer/i.test(navigator.vendor) || m(e).addClass("ot-sdk-not-webkit"), N.useRTL && m(e).attr("dir", "rtl"), D.legIntSettings.PAllowLI && D.isIab2orv2Template && (m(e).addClass("ot-leg-opt-out"), D.legIntSettings.PShowLegIntBtn) && m(e).addClass("ot-leg-btn"), N.BannerRelativeFontSizesToggle && m(e).addClass("otRelFont"), N.PCShowConsentLabels && m(e).addClass("ot-tgl-with-label"), (N.UseGoogleVendors || w.showGeneralVendors) && m(e).addClass("ot-addtl-vendors"), "right" === N.PreferenceCenterPosition && m(e).addClass(N.useRTL ? "right-rtl" : "right")
    }, n.prototype.manageCloseButtons = function(e, t, o) {
        var n = m(t(T.P_Close_Btn)).el;
        if (N.ShowPreferenceCenterCloseButton) {
            N.CloseText || (N.CloseText = "Close Preference Center");
            for (var r = 0, i = n; r < i.length; r++) {
                var s = i[r];
                N.PCCloseButtonType === Ae.Link && N.PCTemplateUpgrade ? (m(s).html(N.PCContinueText), m(e).addClass("ot-close-btn-link"), m(s).el.removeAttribute(this._ariaLabel)) : (m(s).el.setAttribute(this._ariaLabel, N.CloseText), h.setCloseIcon(o("#onetrust-pc-sdk .ot-close-icon")))
            }
        } else
            for (var a = 0; a < n.length; a++) m(n[a].parentElement).el.removeChild(n[a])
    }, n.prototype.addLogos = function(e, t) {
        var o, n, r, i = e(T.P_Logo);
        i && N.optanonLogo && (o = h.updateCorrectUrl(N.optanonLogo), h.checkMobileOfflineRequest(h.getBannerVersionUrl()) && (o = v.getRelativeURL(o, !0, !0)), r = new URL(o, window.location.origin).pathname, k.fp.CMPIconSprite && (r.includes("/logos/static/") || r.includes("src/assets/images/") && new URL(o, window.location.origin).host.includes("localhost")) ? (r = r.split("/").pop().split(".").shift(), (n = document.createElementNS("http://www.w3.org/2000/svg", "svg")).innerHTML = "<use></use>", n.querySelector("use").setAttribute("href", "#" + r), N.PCLogoAria && m(i).attr(this._ariaLabel, N.PCLogoAria), i.setAttribute("role", "img"), i.append(n)) : ((r = document.createElement("img")).setAttribute("alt", N.PCLogoAria), r.setAttribute("src", o), i.append(r))), D.isShopify ? h.removeFooterLogo(e(".ot-pc-footer-logo")) : h.insertFooterLogo(t(".ot-pc-footer-logo a"))
    }, n.prototype.configureLinkFields = function(e, t) {
        var o;
        N.AboutText && m(e(T.P_Policy_Txt)).html(m(e(T.P_Policy_Txt)).html() + '\n            <br/><a href="' + N.AboutLink + '" class="privacy-notice-link" rel="noopener noreferrer" target="_blank"\n                    aria-label="' + N.PCCookiePolicyLinkScreenReader + '">' + N.AboutText + "</a>"), N.PCenterImprintLinkText && (N.AboutText || e(T.P_Policy_Txt).insertAdjacentHTML("beforeend", S.getInnerHtmlContent("<br/>")), (o = document.createElement("a")).classList.add("ot-link-btn", "ot-imprint-handler"), o.textContent = N.PCenterImprintLinkText, o.setAttribute(this._ariaLabel, N.PCenterImprintLinkScreenReader), o.setAttribute("href", N.PCenterImprintLinkUrl), o.setAttribute("rel", "noopener noreferrer"), o.setAttribute("target", "_blank"), e(T.P_Policy_Txt).appendChild(o)), N.PCenterVendorListLinkText && (o = !N.IsIabEnabled && w.showGeneralVendors ? "ot-gv-list-handler" : "onetrust-vendors-list-handler", e(T.P_Policy_Txt).insertAdjacentHTML("beforeend", S.getInnerHtmlContent('<button class="ot-link-btn ' + o + '" aria-label="' + N.PCenterVendorListLinkAriaLabel + '">\n                    ' + N.PCenterVendorListLinkText + "\n                    </button>")))
    }, n.prototype.configureSubjectDataFields = function(e) {
        var t;
        N.PCTemplateUpgrade && N.PCenterUserIdTitleText && N.IsConsentLoggingEnabled && (t = I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID), e(T.P_Policy_Txt).insertAdjacentHTML("beforeend", S.getInnerHtmlContent('<div class="ot-userid-title"><strong>' + N.PCenterUserIdTitleText + ": </strong> " + t + "</div>")), N.PCenterUserIdDescriptionText && e(T.P_Policy_Txt).insertAdjacentHTML("beforeend", S.getInnerHtmlContent('<div class="ot-userid-desc"><em>' + N.PCenterUserIdDescriptionText + "</em></div>")), N.PCenterUserIdTimestampTitleText) && (t = (t = I.getCookie(P.ALERT_BOX_CLOSED)) && h.getUTCFormattedDate(t) || N.PCenterUserIdNotYetConsentedText, e(T.P_Policy_Txt).insertAdjacentHTML("beforeend", S.getInnerHtmlContent('<div class="ot-userid-timestamp"><strong>' + N.PCenterUserIdTimestampTitleText + ": </strong> " + t + "</div>")))
    }, n.prototype.setManagePreferenceText = function(e) {
        var e = e(T.P_Manage_Cookies_Txt),
            t = m(e);
        e && (t.html(N.ManagePreferenceText), N.ManagePreferenceText || v.removeChild(t.el))
    }, n.prototype.configureButtons = function(e, t) {
        this.setButtonsOrder(e), N.ConfirmText.trim() ? m(e(zo)).html(N.ConfirmText) : e(zo).parentElement.removeChild(e(zo));
        for (var o = t(".save-preference-btn-handler"), n = 0; n < o.length; n++) m(o[n]).html(N.AllowAllText);
        var r = t(".ot-pc-refuse-all-handler");
        if (N.PCenterShowRejectAllButton && N.PCenterRejectAllButtonText.trim())
            for (n = 0; n < r.length; n++) m(r[n]).html(N.PCenterRejectAllButtonText);
        else v.removeChild(r);
        this.checkIfStackButtons(e)
    }, n.prototype.setButtonsOrder = function(e) {
        if (N.PCTemplateUpgrade && k.fp.WebButtonCustomisations && this.checkButtonsOrderValidation(e)) {
            var t = new Map,
                o = new Map,
                n = e(".ot-pc-refuse-all-handler[ot-button-order]"),
                r = e(zo + "[ot-button-order]"),
                i = e(".save-preference-btn-handler[ot-button-order]"),
                s = (this.setButtonOrderConfig(r, t, o, _e.ACCEPT_ALL), this.setButtonOrderConfig(n, t, o, _e.REJECT_ALL), this.setButtonOrderConfig(i, t, o, _e.SAVE_PREFERENCE), e("#onetrust-pc-sdk .ot-pc-footer .ot-btn-container"));
            if (s) {
                s.classList.add("ot-button-order-container");
                for (var a = 0, l = Object.entries(N.PcBO); a < l.length; a++) {
                    var c = l[a],
                        d = c[0],
                        c = c[1],
                        u = t.get(Number(d)),
                        c = o.get(c);
                    u && c && (u.replaceWith(c), c.classList.add("ot-button-order-" + d), "0" !== d || D.pcName !== nt && D.pcName !== it || s.insertBefore(c, s.firstChild))
                }
                D.pcName === at && (r = s.querySelectorAll('[class*="ot-button-order-"]'), s.innerHTML = "", null != (n = r)) && n.forEach(function(e) {
                    return s.appendChild(e)
                })
            }
        }
    }, n.prototype.checkIfStackButtons = function(e) {
        var t = this.butttonsTextAreLarge();
        N.PCTemplateUpgrade && k.fp.WebButtonCustomisations && (D.pcName === nt || D.pcName === at) && t && (t = e(".ot-btn-container.ot-button-order-container")) && (t.classList.add("ot-stack-buttons"), null != (e = t = e(".ot-pc-footer")) && e.style.setProperty("height", "100%"), null != (e = t) && e.style.setProperty("display", "flex"), null != (e = t)) && e.style.setProperty("flex-direction", "column")
    }, n.prototype.butttonsTextAreLarge = function() {
        var e;
        return 20 < (null == (e = N.ConfirmText) ? void 0 : e.length) || 20 < (null == (e = N.AllowAllText) ? void 0 : e.length) || 20 < (null == (e = N.PCenterRejectAllButtonText) ? void 0 : e.length)
    }, n.prototype.checkButtonsOrderValidation = function(e) {
        var t = e(".ot-pc-refuse-all-handler"),
            o = e(zo);
        return !(e(".save-preference-btn-handler") && !this.checkIfConfigurationIsValid(_e.SAVE_PREFERENCE) || o && !this.checkIfConfigurationIsValid(_e.ACCEPT_ALL) || t && !this.checkIfConfigurationIsValid(_e.REJECT_ALL))
    }, n.prototype.checkIfConfigurationIsValid = function(e) {
        var t, o = !1;
        for (t in N.PcBO) {
            var n = Number(t);
            if (N.PcBO[n] === e) {
                o = !0;
                break
            }
        }
        return o
    }, n.prototype.setButtonOrderConfig = function(e, t, o, n) {
        var r;
        e && (r = Number(e.getAttribute("ot-button-order")), e.removeAttribute("ot-button-order"), t.set(r, e), o.set(n, e.cloneNode(!0)))
    }, n.prototype.removeListsWhenAppropriate = function(e) {
        var t;
        N.IsIabEnabled || (t = e(T.P_Vendor_Container)) && t.parentElement.removeChild(t), N.showCookieList || w.showGeneralVendors || (t = e(T.P_Host_Cntr)) && t.parentElement.removeChild(t)
    }, n.prototype.setParentGroupName = function(e, t, o, n) {
        var r = e.querySelector('.category-header,.ot-cat-header,.category-menu-switch-handler>h3,.category-menu-switch-handler>p[aria-level="3"],.category-menu-switch-handler>span[id^="ot-header-id"],.category-menu-switch-handler>span[id="ot-pvcy-txt"],.category-menu-switch-handler>span[id="privacy-text"]');
        m(r).html(t), m(r).attr("id", o), D.pcName === at && (e.querySelector(T.P_Category_Header).innerHTML = S.getInnerHtmlContent(t), e.querySelector("" + T.P_Desc_Container).setAttribute("id", n), e.querySelector(".category-menu-switch-handler").setAttribute("aria-controls", n))
    }, n.prototype.setLegIntButton = function(e, t, o, n) {
        void 0 === o && (o = !1);
        var r = !0,
            r = (-1 < w.vendors.selectedLegInt.indexOf(t.IabGrpId + ":false") && (r = !1), B.generateLegIntButtonElements(r, t.OptanonGroupId, !1, t.GroupName)),
            t = (o ? n.insertAdjacentHTML("afterend", r) : e.insertAdjacentHTML("beforeend", r), e.querySelector(".ot-remove-objection-handler"));
        t && Ht(t, t.getAttribute("data-style"))
    }, n.prototype.setParentGroupDescription = function(e, t, o, n, r) {
        var i = y.safeFormattedGroupDescription(t),
            s = e.querySelector("p:not(.ot-always-active)"),
            a = e.querySelector(T.P_Acc_Grp_Desc),
            s = s || a;
        return -1 < Vt.indexOf(t.Type) && o.PCGrpDescType === re.Legal ? i = t.DescriptionLegal : s.classList.add("ot-category-desc"), D.legIntSettings.PAllowLI && !D.legIntSettings.PShowLegIntBtn && (t.SubGroups.some(function(e) {
            return e.HasLegIntOptOut
        }) || t.HasLegIntOptOut ? s.parentElement.classList.add("ot-leg-border-color") : v.removeChild(e.querySelector(T.P_Li_Hdr))), D.pcName !== at && s.setAttribute("id", n), m(s).html(i), t.Type === b.GroupTypes.Stack && v.removeChild(s), s
    }, n.prototype.cloneOtHtmlEls = function(e) {
        var t = /otPcPanel|otPcCenter/;
        E.toggleEl = m(e(".ot-tgl")).el.cloneNode(!0), E.arrowEl = m(e('#onetrust-pc-sdk [role="dialog"] > ' + T.P_Arrw_Cntr)).el.cloneNode(!0), E.subGrpEl = m(e(T.P_Sub_Grp_Cntr)).el.cloneNode(!0), E.vListEl = m(e(T.P_Ven_Lst_Cntr)).el.cloneNode(!0), E.cListEl = m(e(T.P_Host_Lst_cntr)).el.cloneNode(!0), E.chkboxEl = m(e(T.P_CBx_Cntr)).el.cloneNode(!0), E.accordionEl = m(e(".ot-acc-cntr")).el.cloneNode(!0), t.test(D.pcName) && (E.plusMinusEl = m(e(".ot-plus-minus")).el.cloneNode(!0)), v.removeChild(e(".ot-tgl")), v.removeChild(e('#onetrust-pc-sdk [role="dialog"] > ' + T.P_Arrw_Cntr)), v.removeChild(e(T.P_Sub_Grp_Cntr)), v.removeChild(e(T.P_Ven_Lst_Cntr)), v.removeChild(e(T.P_Host_Lst_cntr)), v.removeChild(e(T.P_CBx_Cntr)), v.removeChild(e(".ot-acc-cntr")), t.test(D.pcName) && v.removeChild(e(".ot-plus-minus"))
    }, n.prototype.insertSelectAllEls = function(e) {
        var e = e(T.P_Select_Cntr + " .ot-sel-all-chkbox"),
            t = w.showVendorService ? Jn() : E.chkboxEl.cloneNode(!0),
            t = (t.id = T.P_Sel_All_Host_El, t.querySelector("input").id = "select-all-hosts-groups-handler", t.querySelector("label").setAttribute("for", "select-all-hosts-groups-handler"), m(e).append(t), w.showVendorService ? Jn() : E.chkboxEl.cloneNode(!0)),
            t = (t.id = T.P_Sel_All_Vendor_Consent_El, t.querySelector("input").id = "select-all-vendor-groups-handler", t.querySelector("label").setAttribute("for", "select-all-vendor-groups-handler"), m(e).append(t), w.showVendorService ? Jn() : E.chkboxEl.cloneNode(!0));
        t.id = T.P_Sel_All_Vendor_Leg_El, t.querySelector("input").id = "select-all-vendor-leg-handler", t.querySelector("label").setAttribute("for", "select-all-vendor-leg-handler"), m(e).append(t)
    }, n.prototype.initializePreferenceCenterGroups = function(e, t) {
        var o, n = D.pcName,
            r = (k.isV2Template && (_.cloneOtHtmlEls(e), (r = E.chkboxEl.cloneNode(!0)).querySelector("input").classList.add("category-filter-handler"), m(e(T.P_Fltr_Modal + " " + T.P_Fltr_Option)).append(r), _.insertSelectAllEls(e)), m(e("#onetrust-pc-sdk " + T.P_Category_Grp))),
            i = (n === nt || n === it || n === rt ? N.PCenterEnableAccordion ? v.removeChild(r.el.querySelector(T.P_Category_Item + ":not(.ot-accordion-layout)")) : v.removeChild(r.el.querySelector(T.P_Category_Item + ".ot-accordion-layout")) : n === at && (N.PCenterEnableAccordion = !1), e("#onetrust-pc-sdk " + T.P_Category_Item)),
            s = k.isV2Template ? E.subGrpEl.cloneNode(!0) : m(e(T.P_Sub_Grp_Cntr)),
            a = k.isV2Template ? null : m(e(T.P_Acc_Container + " " + T.P_Sub_Grp_Cntr));
        N.PCTemplateUpgrade && /otPcTab/.test(n) && (o = e(".ot-abt-tab").cloneNode(!0), v.removeChild(e(".ot-abt-tab"))), r.el.removeChild(i), _.setVendorListClass(e, i), _.setPCHeader(e, i), _.createHtmlForEachGroup({
            fm: e,
            fragment: t,
            categoryGroupTemplate: i,
            cookiePreferencesContainer: r,
            popupSubGrpContainer: a,
            subGrpContainer: s
        }), _.setPcTabLayout(e, t, o)
    }, n.prototype.getActiveVendorCount = function(e) {
        var t = parseInt(e.IabGrpId),
            o = 0;
        return e.Type === b.GroupTypes.Pur ? o = D.tcf2ActiveVendors.pur.get(t) : e.Type === b.GroupTypes.Ft ? o = D.tcf2ActiveVendors.ft.get(t) : e.Type === b.GroupTypes.Spl_Pur ? o = D.tcf2ActiveVendors.spl_pur.get(t) : e.Type === b.GroupTypes.Spl_Ft && (o = D.tcf2ActiveVendors.spl_ft.get(t)), o || 0
    }, n.prototype.getActiveVendorCountForStack = function(e) {
        return D.tcf2ActiveVendors.stack.get(e) || 0
    }, n.prototype.getVendorCountEl = function(e, t) {
        var o = "[VENDOR_NUMBER]",
            n = "";
        switch (t) {
            case Ot:
                n = N.PCVendorsCountFeatureText;
                break;
            case _t:
                n = N.PCVendorsCountSpcFeatureText;
                break;
            case Et:
                n = N.PCVendorsCountSpcPurposeText;
                break;
            default:
                n = N.PCVendorsCountText
        }
        return n && -1 < n.indexOf(o) ? '<span class="ot-pur-vdr-count"> ' + n.replace(o, e.toString()) + " </span>" : ""
    }, n.prototype.createHtmlForEachGroup = function(e) {
        var t = e.fm,
            o = e.fragment,
            n = e.categoryGroupTemplate,
            r = e.cookiePreferencesContainer,
            i = e.popupSubGrpContainer,
            s = e.subGrpContainer,
            e = N.Groups.filter(function(e) {
                return e.Order
            });
        N.PCTemplateUpgrade && (w.showVendorService ? O.setHtmlTemplate(t('#onetrust-pc-sdk div[role="dialog"]')) : O.removeVSUITemplate(t('#onetrust-pc-sdk div[role="dialog"]')));
        for (var a = 0, l = e; a < l.length; a++) {
            var c = l[a],
                d = c.GroupName,
                u = c.CustomGroupId,
                d = _.appendVendorCountElement(c, d),
                p = n.cloneNode(!0),
                p = m(p).el,
                C = "ot-group-id-" + u,
                g = "ot-header-id-" + u,
                h = "ot-desc-id-" + u,
                y = "",
                u = (c.Status === f.ALWAYS_ACTIVE && (y = " ot-status-id-" + u), p.setAttribute("data-optanongroupid", u), p.querySelector("input,button")),
                u = (u && (c.Type !== b.GroupTypes.Stack && u.setAttribute("aria-controls", h), u.setAttribute("aria-labelledby", g + y)), _.setParentGroupName(p, d, g, h), _.setPopupData(c, p), _.setParentGroupDescription(p, c, N, h, C)),
                y = (k.isV2Template ? _.setToggle(p, u, c, C, g) : _.setToggleProps(p, u, c, C, g), this.addCategoryGroupsToParent(t, r, p), _.setSubGroupData(c, p, i, s), N.PCGrpDescLinkPosition === ie.Top),
                d = (c.Type === b.GroupTypes.Stack && y && (u = p.querySelector(T.P_Sub_Grp_Cntr)), y ? u : null);
            _.setVendorListBtn(p, t, o, c, d, N), _.setHostListBtn(p, t, o, c), _.setVendorServiceData(c, p), _.appendHealthSignatureFormToGroup(c, p), w.dataGroupState.push(c)
        }
    }, n.prototype.addCategoryGroupsToParent = function(e, t, o) {
        var n = 0 === t.el.children.length,
            e = !!e("#onetrust-pc-sdk " + T.P_Category_Grp).querySelector(T.P_Category_Item),
            r = (r = t.el.querySelectorAll(T.P_Category_Item + ":not(.ot-vnd-item)"))[r.length - 1];
        n ? t.append(o) : (n = t.el.querySelector(T.P_Li_Hdr) || t.el.querySelector("h3") || t.el.querySelector('p[aria-level="3"]') || t.el.querySelector('span[id^="ot-header-id"]'), !e && n ? S.insertAfter(o, n) : r ? S.insertAfter(o, r) : t.el.insertBefore(o, t.el.firstChild))
    }, n.prototype.appendHealthSignatureFormToGroup = function(e, t) {
        var o;
        D.requireSignatureEnabled && e.needsHealthSignature && (o = T.P_Acc_Container, N.PCLayout.Tab && (o = "#ot-desc-id-" + e.CustomGroupId), t = t.querySelector(o), $n.getInstance().getHealthSignatureComponent(t, e))
    }, n.prototype.appendVendorCountElement = function(e, t) {
        var o, n, r = -1 < e.SubGroups.findIndex(function(e) {
            return e.IsIabPurpose
        });
        return D.isTcfV2Template && (e.IsIabPurpose || r) && (n = void 0, n = e.Type !== b.GroupTypes.Stack && e.Type !== b.GroupTypes.Bundle && e.Type !== b.GroupTypes.Cookie ? this.getActiveVendorCount(e) : (o = "", o = !e.IsIabPurpose && r ? e.CustomGroupId : e.IabGrpId, this.getActiveVendorCountForStack(o)), t += this.getVendorCountEl(n, e.Type)), t
    }, n.prototype.setPopupData = function(e, t) {
        D.pcName === st && (e.ShowVendorList && D.isIab2orv2Template ? (v.removeChild(t.querySelector("p:not(.ot-always-active)")), v.removeChild(t.querySelector(T.P_Acc_Txt + ":not(" + T.P_Acc_Container + ")")), e.SubGroups.length || k.isV2Template || v.removeChild(t.querySelector(T.P_Sub_Grp_Cntr))) : v.removeChild(t.querySelector(T.P_Acc_Container)))
    }, n.prototype.setVendorServiceData = function(e, t) {
        var o, n = D.pcName;
        w.showVendorService && N.VendorServiceConfig.PCVSCategoryView && (o = T.P_Acc_Txt, n === at && (o = T.P_Desc_Container), n = t.querySelector(o), N.PCAccordionStyle === ce.NoAccordion && (n = t), O.insertVendorServiceHtml(e, n))
    }, n.prototype.jsonAddAboutCookies = function(e) {
        var t = {};
        return t.GroupName = e.AboutCookiesText, t.GroupDescription = e.MainInfoText, t.ShowInPopup = !0, t.Order = 0, t.IsAboutGroup = !0, t
    }, n.prototype.setVendorListBtn = function(e, t, o, n, r, i) {
        var s, a, l = D.pcName;
        n.ShowVendorList ? (s = a = void 0, k.isV2Template ? a = (s = E.vListEl.cloneNode(!0)).querySelector(".category-vendors-list-handler") : s = (a = e.querySelector(".category-vendors-list-handler")).parentElement, a.setAttribute("dir", "ltr"), a.innerHTML = S.getInnerHtmlContent(i.VendorListText), a.setAttribute(this._ariaLabel, N.PCOpensVendorDetailsAlert), a.setAttribute("data-parent-id", n.CustomGroupId), _.setIABLegalLink(a, n, i), k.isV2Template && (a = e, l === at ? a = e.querySelector("" + T.P_Desc_Container) : i.PCenterEnableAccordion && (a = e.querySelector(T.P_Acc_Txt)), a.insertAdjacentElement("beforeend", s)), r && r.insertAdjacentElement("beforebegin", s)) : k.isV2Template || (l !== it && l !== nt || i.PCenterEnableAccordion ? (l === st || l === it || l === nt && i.PCenterEnableAccordion) && (n = t("#vendor-list-container"), a = e.querySelector(T.P_Acc_Txt), n && o.querySelector("" + T.P_Content).removeChild(n), k.isV2Template || m(a).el.removeChild(a.querySelector(T.P_Ven_Lst_Cntr))) : v.removeChild(e.querySelector(T.P_Ven_Lst_Cntr)), l !== at && l !== rt) || (r = e.querySelector(T.P_Ven_Lst_Cntr)) && r.parentElement.removeChild(r)
    }, n.prototype.setIABLegalLink = function(e, t, o) {
        D.isTcfV2Template ? pr.addIllustrationsLink(e, t, t.ShowVendorList) : o.PCGrpDescType === re.UserFriendly && (t = N.BannerRequireExternalLinks && !(k.fp.CMPIconSprite && N.OTExternalLinkLogo && !N.BannerExternalLinksLogo), e.insertAdjacentHTML("afterend", S.getInnerHtmlContent("<a href='" + N.IabLegalTextUrl + "?lang=" + w.consentLanguage + '\'\n                        rel="noopener noreferrer" ' + (t ? 'class="ot-ext-lnk"' : "") + " target='_blank'>&nbsp;|&nbsp;" + o.PCVendorFullLegalText + '&nbsp;<span class="ot-scrn-rdr">\n                        ' + N.NewWinTxt + "</span></a>")))
    }, n.prototype.setHostListBtn = function(e, t, o, n) {
        var r, i = D.pcName,
            s = !1,
            a = (N.showCookieList && (s = -1 < v.findIndex(U(n.SubGroups, [n]), function(e) {
                return -1 === Dt.indexOf(e.Type) && e.FirstPartyCookies.length
            })), w.showGeneralVendors && n.GeneralVendorsIds && n.GeneralVendorsIds.length);
        !w.showVendorService && (N.showCookieList || w.showGeneralVendors) && (n.ShowHostList || s || a) ? (s = void 0, k.isV2Template ? (s = (a = E.cListEl.cloneNode(!0)).querySelector(".category-host-list-handler"), r = e, i === at ? r = e.querySelector("" + T.P_Desc_Container) : N.PCenterEnableAccordion && (r = e.querySelector(T.P_Acc_Txt)), r.insertAdjacentElement("beforeend", a)) : s = e.querySelector(".category-host-list-handler"), _.setcListHandler(s, n)) : _.setHostListVendorList(t, o, e)
    }, n.prototype.setcListHandler = function(e, t) {
        var o, n;
        e && (o = (n = _.setcListHeaderTitleAndScreenReader())[0], n = n[1], e.setAttribute("dir", "ltr"), e.innerHTML = S.getInnerHtmlContent(o), e.setAttribute(this._ariaLabel, t.GroupName + " - " + n), e.setAttribute("data-parent-id", t.CustomGroupId))
    }, n.prototype.setcListHeaderTitleAndScreenReader = function() {
        var e, t = w.showTrackingTech ? (e = N.AdditionalTechnologiesConfig.PCTechDetailsText, N.AdditionalTechnologiesConfig.PCTechDetailsAriaLabel) : w.showGeneralVendors ? (e = N.GroupGenVenListLabel, N.PCenterVendorListScreenReader) : (e = N.ThirdPartyCookieListText, N.PCOpensCookiesDetailsAlert);
        return [e, t]
    }, n.prototype.setHostListVendorList = function(e, t, o) {
        var n;
        D.pcName === st ? (e = e("#vendor-list-container"), n = o.querySelector(T.P_Acc_Txt), e && t.querySelector("" + T.P_Content).removeChild(e), n.querySelector(T.P_Host_Lst_cntr) && m(n).el.removeChild(n.querySelector(T.P_Host_Lst_cntr))) : (t = o.querySelector(T.P_Host_Lst_cntr)) && t.parentElement.removeChild(t)
    }, n.prototype.setSubGroupData = function(e, t, o, n) {
        var r;
        0 < e.SubGroups.length && e.ShowSubgroup && (r = D.pcName === st && e.ShowVendorList && D.isIab2orv2Template && !N.PCTemplateUpgrade, _.setSubGrps(e, r ? o : n, t, N))
    }, n.prototype.setSubGrps = function(t, o, n, r) {
        var e;
        D.pcName === st && t.ShowVendorList && D.isIab2orv2Template && !N.PCTemplateUpgrade && (e = n.querySelector(T.P_Sub_Grp_Cntr)).parentElement.removeChild(e), t.SubGroups.forEach(function(e) {
            _.setSubGroups({
                group: t,
                subgroup: e,
                grpEl: n,
                subGrpEl: o,
                json: r
            })
        })
    }, n.prototype.setSubGroups = function(e) {
        var t, o = e.group,
            n = e.subgroup,
            r = e.grpEl,
            i = e.subGrpEl,
            e = e.json,
            s = D.pcName,
            a = _.getRemoveConsentToggle(n),
            i = (k.isV2Template ? i : i.el).cloneNode(!0),
            l = i.querySelector(T.P_Subgp_ul),
            c = i.querySelector(T.P_Subgrp_li).cloneNode(!0),
            d = n.CustomGroupId,
            u = "ot-sub-group-id-" + d,
            p = L.getGrpStatus(n).toLowerCase(),
            C = c.querySelector('.cookie-subgroup>h4, .cookie-subgroup>h5,\n            .cookie-subgroup>h6, .ot-subgrp>h4,\n            .ot-subgrp>h5, .ot-subgrp>h6, .cookie-subgroup>p[aria-level="4"], .cookie-subgroup>p[aria-level="5"],\n            .cookie-subgroup>p[aria-level="6"], .ot-subgrp>p[aria-level="4"],\n            .ot-subgrp>p[aria-level="5"], .ot-subgrp>p[aria-level="6"]'),
            g = c.querySelector(T.P_Tgl_Cntr),
            d = (c.setAttribute("data-optanongroupid", d), k.isV2Template ? ((t = _.getInputEle()).querySelector("input").setAttribute("data-optanongroupid", d), t.querySelector("input").classList.add("cookie-subgroup-handler"), t = t.cloneNode(!0), g.insertAdjacentElement("beforeend", t)) : (t = c.querySelector(".ot-toggle")).querySelector("input").setAttribute("data-optanongroupid", d), m(i.querySelector(T.P_Subgp_ul)).html(""), _.addSubgroupName(n, C), _.setDataIfVendorServiceEnabled(C, c, t), t.querySelector("input").setAttribute("id", u), t.querySelector("input").setAttribute(this._ariaLabel, n.GroupName), t.querySelector("label").setAttribute("for", u), _.setSubGroupDescription({
                json: e,
                group: o,
                subgroup: n,
                subGroupClone: c
            }), D.isTcfV2Template && pr.addIllustrationsLink(c, n, o.ShowVendorList, !0), U(wt, Nt));
        o.ShowSubgroupToggle && -1 < d.indexOf(n.Type) ? _.setSubGroupToggle({
            id: u,
            subGroupClone: c,
            group: o,
            subgroup: n,
            toggleGroup: g
        }) : p === f.ALWAYS_ACTIVE && (o.ShowSubgroupToggle || -1 === Bt.indexOf(n.Type)) || (a = !0), _.setSubGroupsProperties({
            removeConsentToggle: a,
            subGroupToggle: t,
            subGroupClone: c,
            status: p,
            subgroup: n,
            grpEl: r,
            pcName: s,
            json: e,
            subGrpElClone: i,
            ulParentContainerEle: l
        })
    }, n.prototype.getRemoveConsentToggle = function(e) {
        var t = !1;
        return t = D.isIab2orv2Template && e.Type === b.GroupTypes.Pur && !e.HasConsentOptOut ? !0 : t
    }, n.prototype.addSubgroupName = function(e, t) {
        var o, n = e.GroupName;
        D.isTcfV2Template && e.IsIabPurpose && (o = this.getActiveVendorCount(e), n += this.getVendorCountEl(o, e.Type)), m(t).html(n)
    }, n.prototype.setDataIfVendorServiceEnabled = function(e, t, o) {
        var n;
        w.showVendorService && ((n = document.createElement("div")).classList.add("ot-acc-hdr"), e.classList.add("ot-cat-header"), n.appendChild(e), e = "afterbegin", N.PCCategoryStyle === ve.Toggle && (e = "beforeend"), n.insertAdjacentElement(e, o), t.removeChild(t.querySelector(T.P_Subgrp_Tgl_Cntr)), t.insertAdjacentElement("afterbegin", n))
    }, n.prototype.setSubGroupDescription = function(e) {
        var t, o = e.json,
            n = e.group,
            r = e.subgroup,
            e = e.subGroupClone,
            i = D.pcName,
            s = o.PCGrpDescType === re.Legal,
            i = i === st && n.ShowVendorList && D.isIab2orv2Template,
            a = m(e.querySelector(T.P_Subgrp_Desc));
        i ? (t = r.DescriptionLegal && s ? r.DescriptionLegal : r.GroupDescription, a.html(t)) : (t = y.safeFormattedGroupDescription(r), i = !1, -1 < Vt.indexOf(r.Type) && s && (i = !0, t = r.DescriptionLegal), o.PCenterEnableAccordion && i || (a = m(e.querySelector("p"))), n.ShowSubGroupDescription ? a.html(t) : a.html(""))
    }, n.prototype.setSubGroupToggle = function(e) {
        var t = e.id,
            o = e.subGroupClone,
            n = e.group,
            r = e.subgroup,
            e = e.toggleGroup,
            i = y.isGroupActive(r),
            n = (_.setSubGroupActive({
                group: n,
                subgroup: r,
                subGroupClone: o
            }, i), e.querySelector(".ot-label-status"));
        N.PCShowConsentLabels ? n.innerHTML = S.getInnerHtmlContent(i ? N.PCActiveText : N.PCInactiveText) : v.removeChild(n), D.legIntSettings.PAllowLI && r.Type === b.GroupTypes.Pur && r.HasLegIntOptOut && (D.legIntSettings.PShowLegIntBtn ? _.setLegIntButton(o, r) : (i = e.cloneNode(!0), e.insertAdjacentElement("afterend", i), n = i.querySelector(".ot-label-status"), (o = i.querySelector("input")).setAttribute("id", t + "-leg-out"), i.querySelector("label").setAttribute("for", t + "-leg-out"), r.IsLegIntToggle = !0, e = y.isGroupActive(r), N.PCShowConsentLabels ? n.innerHTML = S.getInnerHtmlContent(e ? N.PCActiveText : N.PCInactiveText) : v.removeChild(n), v.setCheckedAttribute(null, o, e), r.IsLegIntToggle = !1))
    }, n.prototype.setSubGroupActive = function(e, t) {
        var o;
        t && (t = e.group, o = e.subgroup, e = e.subGroupClone, t = L.getGrpStatus(t).toLowerCase(), e.querySelector("input").setAttribute("checked", ""), t === f.ALWAYS_ACTIVE) && -1 === Vt.indexOf(o.Type) && e.querySelector("input").setAttribute("aria-disabled", "true")
    }, n.prototype.setSubGroupsProperties = function(e) {
        var t = e.removeConsentToggle,
            o = e.subGroupToggle,
            n = e.subGroupClone,
            r = e.status,
            i = e.subgroup,
            s = e.grpEl,
            a = e.pcName,
            l = e.json,
            c = e.subGrpElClone,
            e = e.ulParentContainerEle;
        t && (o.classList.add("ot-hide-tgl"), o.querySelector("input").setAttribute(this._ariaHidden, "true")), r !== f.ALWAYS_ACTIVE && r !== f.ALWAYS_INACTIVE || t || (o && o.parentElement.removeChild(o), (t = n.querySelector(T.P_Tgl_Cntr)) && t.classList.add("ot-always-active-subgroup"), _.setAlwaysActive(n, !0, r === f.ALWAYS_INACTIVE)), "COOKIE" === i.Type && -1 !== i.Parent.indexOf("STACK") && Ht(c, "display: none;"), m(e).append(n), k.isV2Template ? (o = s, "otPcTab" === a ? o = s.querySelector("" + T.P_Desc_Container) : l.PCenterEnableAccordion && (o = s.querySelector(T.P_Acc_Txt)), o.insertAdjacentElement("beforeend", c)) : (t = s.querySelector(T.P_Category_Item + " " + T.P_Ven_Lst_Cntr)) && t.insertAdjacentElement("beforebegin", c), w.showVendorService && N.VendorServiceConfig.PCVSCategoryView && O.insertVendorServiceHtml(i, e)
    }, n.prototype.getInputEleForCategory = function(e) {
        return w.showVendorService && N.PCCategoryStyle === ve.Checkbox && e.classList.add("ot-checkbox-consent"), _.getInputEle()
    }, n.prototype.getInputEle = function() {
        return !D.isIab2orv2Template && N.PCTemplateUpgrade ? Jn() : E.toggleEl.cloneNode(!0)
    }, n.prototype.setToggle = function(e, t, o, n, r) {
        var i = _.getInputEleForCategory(e),
            s = (i.querySelector("input").classList.add("category-switch-handler"), i.querySelector("input")),
            a = e.querySelector(T.P_Category_Header),
            l = y.isGroupActive(o),
            c = [f.ALWAYS_ACTIVE, f.ALWAYS_INACTIVE].includes(L.getGrpStatus(o).toLowerCase()),
            d = o.OptanonGroupId.toString(),
            u = b.GroupTypes,
            p = !0;
        !D.isIab2orv2Template || o.Type !== u.Pur && o.Type !== u.Stack || o.HasConsentOptOut || (p = !1), m(i.querySelector("label")).attr("for", n), m(i.querySelector(".ot-label-txt")).html(o.GroupName);
        D.legIntSettings.PAllowLI && o.Type === u.Pur && o.HasLegIntOptOut && (D.legIntSettings.PShowLegIntBtn ? _.setLegIntButton(e, o, !0, t) : (u = i.cloneNode(!0), o.IsLegIntToggle = !0, t = y.isGroupActive(o), C = u.querySelector(".ot-label-status"), N.PCShowConsentLabels ? C.innerHTML = S.getInnerHtmlContent(t ? N.PCActiveText : N.PCInactiveText) : v.removeChild(C), o.IsLegIntToggle = !1, y.setInputID(u.querySelector("input"), n + "-leg-out", d, t, r), m(u.querySelector("label")).attr("for", n + "-leg-out"), a.insertAdjacentElement("afterend", u)));
        var C = i.querySelector(".ot-label-status"),
            d = (N.PCShowConsentLabels ? C.innerHTML = S.getInnerHtmlContent(l ? N.PCActiveText : N.PCInactiveText) : v.removeChild(C), N.PCCategoryStyle === ve.Toggle);
        this.hideToggleContainer(c, p, d, i), p && this.setAlwaysActiveOrToggleInput(o, e, i, s, n, r), _.setNoAccordionHeader(e, c)
    }, n.prototype.setNoAccordionHeader = function(e, t) {
        var o, n, r, i;
        !D.isIab2orv2Template && N.PCTemplateUpgrade && (o = N.PCCategoryStyle === ve.Checkbox, N.PCAccordionStyle === ce.NoAccordion) && o && ((o = document.createElement("div")).classList.add("ot-acc-hdr"), n = e.querySelector(".ot-chkbox"), r = e.querySelector(".ot-always-active"), i = e.querySelector(T.P_Category_Header), n && o.appendChild(n), o.appendChild(i), t && o.appendChild(r), e.insertBefore(o, e.firstChild))
    }, n.prototype.hideToggleContainer = function(e, t, o, n) {
        !e && t || !o || (n.classList.add("ot-hide-tgl"), n.querySelector("input").setAttribute(this._ariaHidden, "true"))
    }, n.prototype.setAlwaysActiveOrToggleInput = function(e, t, o, n, r, i) {
        var s = "always active" === (null == (s = L.getGrpStatus(e)) ? void 0 : s.trim().toLowerCase()),
            a = "always inactive" === (null == (a = L.getGrpStatus(e)) ? void 0 : a.trim().toLowerCase()),
            l = N.PCCategoryStyle === ve.Toggle,
            c = e.OptanonGroupId.toString(),
            e = y.isGroupActive(e),
            d = t.querySelector(T.P_Category_Header);
        !D.isIab2orv2Template && N.PCTemplateUpgrade ? ((s || a) && N.PCShowAlwaysActiveToggle && (_.setAlwaysActive(t, !1, a), o.querySelector("input").setAttribute("aria-disabled", "true")), s && l || _.insertAccordionInputHeader(d, o), y.setInputID(n, r, c, e, i), _.insertAccordionPointer(t, d)) : (_.insertAccordionPointer(t, d), s || a ? N.PCShowAlwaysActiveToggle && _.setAlwaysActive(t, !1, a) : (_.insertAccordionInputHeader(d, o), y.setInputID(n, r, c, e, i)))
    }, n.prototype.setOptOutSignalVisibility = function(e, t) {
        var o = D.gpcEnabled && D.gpcForAGrpEnabled,
            n = y.isAnyGPCGroupOptedOut();
        N.PCShowOptOutSignal && (o && n || D.previewMode) ? (e.classList.remove("ot-hide"), h.applyOptOutSignalA11y(!0, t)) : (e.classList.add("ot-hide"), h.removeOptOutSignalA11y(!0, t))
    }, n.prototype.setOptOutSignalNotification = function(e) {
        var t = h.createOptOutSignalElement(e, !0);
        _.setOptOutSignalVisibility(t, e)
    }, n.prototype.insertAccordionInputHeader = function(e, t) {
        var o = _.getPositionForInputEle();
        e.insertAdjacentElement(o, t)
    }, n.prototype.getPositionForInputEle = function() {
        var e = "beforebegin";
        return e = !D.isIab2orv2Template && N.PCTemplateUpgrade && N.PCCategoryStyle !== ve.Toggle ? e : "afterend"
    }, n.prototype.insertAccordionPointer = function(e, t) {
        var o, n;
        e.classList.add("ot-vs-config"), N.PCenterEnableAccordion && (!D.isIab2orv2Template && N.PCTemplateUpgrade ? (e = e.querySelector(T.P_Acc_Header), o = n = void 0, n = (N.PCAccordionStyle === ce.Caret ? (o = "beforeend", E.arrowEl) : (o = N.PCCategoryStyle === ve.Checkbox ? "beforeend" : "afterbegin", E.plusMinusEl)).cloneNode(!0), e.insertAdjacentElement(o, n)) : N.PCAccordionStyle === ce.Caret ? t.insertAdjacentElement("afterend", E.arrowEl.cloneNode(!0)) : t.insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)))
    }, n.prototype.setToggleProps = function(e, t, o, n, r) {
        var i = e.querySelectorAll("input:not(.cookie-subgroup-handler)"),
            s = e.querySelectorAll("label"),
            a = y.isGroupActive(o),
            l = o.CustomGroupId,
            c = e.querySelector(".label-text");
        c && m(c).html(o.GroupName);
        for (var d, u, p, C, g = 0; g < i.length; g++) s[g] && m(s[g]).attr("for", n), 2 <= i.length && 0 === g ? m(i[g]).attr("id", n + "-toggle") : (d = this.canShowConsentToggle(o), this.canShowLegIntToggle(o) && (D.legIntSettings.PShowLegIntBtn ? _.setLegIntButton(e, o, !0, t) : (C = (u = e.querySelector(T.P_Tgl_Cntr + ":not(" + T.P_Subgrp_Tgl_Cntr + ")") || e.querySelector(".ot-toggle")).cloneNode(!0), u.insertAdjacentElement("afterend", C), u = C.querySelector("input"), o.IsLegIntToggle = !0, p = y.isGroupActive(o), o.IsLegIntToggle = !1, y.setInputID(u, n + "-leg-out", l, p, r), m(C.querySelector("label")).attr("for", n + "-leg-out"), v.removeChild(C.querySelector(T.P_Arrw_Cntr)))), u = L.getGrpStatus(o).toLowerCase() === f.ALWAYS_ACTIVE, p = L.getGrpStatus(o).toLowerCase() === f.ALWAYS_INACTIVE, !u && d || (C = i[g].closest(".ot-toggle")) && (C.classList.add("ot-hide-tgl"), C.querySelector("input").setAttribute(this._ariaHidden, !0)), d && (u && _.setAlwaysActive(e, !1, p), y.setInputID(i[g], n, l, a, r)))
    }, n.prototype.canShowConsentToggle = function(e) {
        var t = !0,
            o = b.GroupTypes;
        return t = !D.isIab2orv2Template || e.Type !== o.Pur && e.Type !== o.Stack || e.HasConsentOptOut ? t : !1
    }, n.prototype.canShowLegIntToggle = function(e) {
        var t = b.GroupTypes;
        return D.legIntSettings.PAllowLI && e.Type === t.Pur && e.HasLegIntOptOut
    }, n.prototype.setAlwaysActive = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = !1);
        var n, r = D.pcName;
        r === st || r === at || t ? (r = e.querySelector(T.P_Tgl_Cntr)) && r.insertAdjacentElement("afterbegin", m("<div class='ot-always-active'>" + (o ? N.AlwaysInactiveText : N.AlwaysActiveText) + "</div>", "ce").el) : (r = "ot-status-id-" + (r = null == (n = r = (t = e.querySelector(T.P_Category_Header)).id) ? void 0 : n.split("-")[3]), !k.isV2Template && N.PCenterEnableAccordion && (r = "ot-status-id-" + (r = null == (n = r = (t = e.querySelector(T.P_Arrw_Cntr)).id) ? void 0 : n.split("-")[3])), m(t).el.insertAdjacentElement("afterend", m('<div id="' + r + "\" class='ot-always-active'>" + (o ? N.AlwaysInactiveText : N.AlwaysActiveText) + "</div>", "ce").el)), N.PCenterEnableAccordion ? (n = e.querySelector(T.P_Acc_Header)) && n.classList.add("ot-always-active-group") : ((t = e.querySelector("" + T.P_Desc_Container)) && t.classList.add("ot-always-active-group"), e.classList.add("ot-always-active-group"))
    }, n.prototype.setPcTabLayout = function(e, t, o) {
        var n, r = e(".ot-tab-desc");
        "otPcTab" === D.pcName && (o && e("#onetrust-pc-sdk " + T.P_Category_Grp).insertAdjacentElement("afterbegin", o), r && 640 < window.innerWidth && m(r).append(t.querySelectorAll("#onetrust-pc-sdk " + T.P_Desc_Container)), N.IsIabEnabled ? (n = e(T.P_Desc_Container + " .category-vendors-list-handler")) && (n.setAttribute("dir", "ltr"), n.innerHTML = S.getInnerHtmlContent(N.VendorListText)) : (n = e(T.P_Desc_Container + " .category-vendors-list-handler")) && n.parentElement.removeChild(n))
    }, n.prototype.setVendorListClass = function(e, t) {
        k.isV2Template ? N.PCAccordionStyle === ce.Caret && (m(e("#onetrust-pc-sdk " + T.P_Vendor_List)).addClass("ot-enbl-chr"), N.PCenterEnableAccordion) && m(e("#onetrust-pc-sdk " + T.P_Content)).addClass("ot-enbl-chr") : m(t.querySelector(T.P_Sub_Grp_Cntr)).remove()
    }, n.prototype.setPCHeader = function(e, t) {
        var o = D.pcName,
            n = e(T.P_Li_Hdr) || t.querySelector(T.P_Li_Hdr);
        D.legIntSettings.PAllowLI && D.grpContainLegalOptOut && D.isIab2orv2Template && !D.legIntSettings.PShowLegIntBtn ? (n.querySelector("span:first-child").innerText = N.ConsentText, n.querySelector("span:last-child").innerText = N.LegitInterestText, k.isV2Template && (n.querySelector("span:first-child").innerText = N.PCenterConsentText, n.querySelector("span:last-child").innerText = N.PCenterLegIntColumnHeader), N.PCenterEnableAccordion && n ? n.classList.add("ot-leg-border-color") : "otPcList" === o && t.insertAdjacentElement("afterbegin", n)) : (v.removeChild(e("#onetrust-pc-sdk " + T.P_Li_Hdr)), v.removeChild(t.querySelector(T.P_Li_Hdr)))
    };
    var _, hr = n;

    function n() {
        this._ariaHidden = "aria-hidden", this._ariaLabel = "aria-label"
    }
    Sr.prototype.showBanner = function() {
        var e = D.bannerName,
            t = m(this.El);
        p.skipAddingHTML && "none" === getComputedStyle(t.el[0]).getPropertyValue("display") && e !== Qe && e !== Xe && e !== et ? t.css("display: block;") : N.BAnimation === Te.SlideIn ? this.slideInAnimation(t, e) : N.BAnimation === Te.FadeIn && t.addClass("ot-fade-in")
    }, Sr.prototype.insertAlertHtml = function() {
        N.IsGPPEnabled && Hs.setCmpDisplayStatus("visible");

        function e(e) {
            return t.querySelector(e)
        }
        var t = document.createDocumentFragment(),
            o = document.createElement("div"),
            o = (m(o).html(js.bannerGroup.html), o.querySelector("#onetrust-banner-sdk"));
        this.setAriaModalForBanner(o), k.fp.CookieV2SSR ? (m(t).append(o), this.setBannerLinkAttributes(e), this._rejectBtn = e(jo), this._acceptBtn = e(qo)) : this.insertHtmlForNonSSRFlow(o, t, e, function(e) {
            return t.querySelectorAll(e)
        }), this.ssrAndNonSSRCommonHtml(t)
    }, Sr.prototype.insertHtmlForNonSSRFlow = function(e, t, o, n) {
        var r, i, s = D.bannerName;
        js.bannerGroup && (N.BannerRelativeFontSizesToggle && m(e).addClass("otRelFont"), (N.BInitialFocus || N.BInitialFocusLinkAndButton) && e.setAttribute("tabindex", "0"), N.useRTL && m(e).attr("dir", "rtl"), D.isIab2orv2Template && N.BannerDPDDescription.length && m(e).addClass("ot-iab-2"), (r = N.BannerPosition) && ("bottom-left" === r ? m(e).addClass("ot-bottom-left") : "bottom-right" === r ? m(e).addClass("ot-bottom-right") : m(e).addClass(r)), m(t).append(e), this.setBannerData(o), r = this.setIAB2HtmlData(o), this.setAcceptAndRejectBtnHtml(o), this.setButtonsOrder(o), t = this.htmlForBannerButtons(e, o, n), n = N.showBannerCloseButton, i = N.BCloseButtonType === Ae.Link, this.setWidthForFlatBanner(o, r, t), n && s === Ze && D.isIab2orv2Template && !i && ((t = o(".banner-close-btn-container")).parentElement.removeChild(t), m(e).el.insertAdjacentElement("beforeEnd", t), m(o("#onetrust-banner-sdk .ot-sdk-container")).addClass("ot-top-cntr")), this.setBannerOptions(o, r), this.setBannerLogo(e, o))
    }, Sr.prototype.setBannerOptions = function(e, t) {
        var o = this,
            n = D.bannerName,
            r = this.isCmpEnabled(),
            i = [{
                type: "purpose",
                titleKey: "BannerPurposeTitle",
                descriptionKey: "BannerPurposeDescription",
                identifier: "purpose-option"
            }, {
                type: "feature",
                titleKey: "BannerFeatureTitle",
                descriptionKey: "BannerFeatureDescription",
                identifier: "feature-option"
            }, {
                type: "information",
                titleKey: "BannerInformationTitle",
                descriptionKey: "BannerInformationDescription",
                identifier: "information-option"
            }],
            s = m(e(this._bannerOptionsSelector)).el;
        r ? (n === $e ? this.setFloatingRoundedIconBannerCmpOptions(e, i) : (this.setCmpBannerOptions(e, i), n === tt && t.el.insertAdjacentElement("beforeend", s)), m(window).on("resize", function() {
            window.innerWidth <= 896 && o.setBannerOptionContent()
        })) : (D.bannerName === Ze && (s = m(e(".banner-options-card")).el), v.removeChild(s))
    }, Sr.prototype.setWidthForFlatBanner = function(e, t, o) {
        var n = D.bannerName,
            r = N.showBannerCloseButton,
            i = this.hasNoActionButtons();
        n === Xe && (D.isIab2orv2Template && (t.removeClass("ot-sdk-eight"), this.setOrderForAcceptAndCookieSettings(e, o)), r && !i && D.isIab2orv2Template ? t.addClass("ot-sdk-nine") : r && i ? t.addClass("ot-sdk-eleven") : !r && i ? t.addClass("ot-sdk-twelve") : r || i || !D.isIab2orv2Template || (t.addClass("ot-sdk-ten"), m(e(this._btnGrpParentSelector)).addClass("ot-sdk-two"), m(e(this._btnGrpParentSelector)).removeClass("ot-sdk-three")))
    }, Sr.prototype.setOrderForAcceptAndCookieSettings = function(e, t) {
        N.PCTemplateUpgrade && k.fp.WebButtonCustomisations || (N.showBannerAcceptButton && t.insertAdjacentElement("afterbegin", this._acceptBtn), N.showBannerCookieSettings && t.insertAdjacentElement("beforeend", e(Ko)))
    }, Sr.prototype.hasNoActionButtons = function() {
        var e = !N.showBannerAcceptButton && !N.showBannerCookieSettings && !N.BannerShowRejectAllButton;
        return D.bannerName === tt ? e && !N.BShowSaveBtn : e
    }, Sr.prototype.htmlForBannerButtons = function(e, t, o) {
        var n = D.bannerName,
            r = (this.hasNoActionButtons() && t(this._btnGrpParentSelector).parentElement.removeChild(t(this._btnGrpParentSelector)), N.showBannerCloseButton),
            i = m(o(".banner-close-button")).el,
            s = t("#onetrust-button-group"),
            a = N.BCloseButtonType === Ae.Link;
        if (r)
            for (l = 0; l < i.length; l++) a ? (m(i[l]).html(N.BContinueText), m(e).addClass("ot-close-btn-link"), m(i[l]).addClass("ot-close-link"), m(i[l]).removeClass("onetrust-close-btn-ui"), m(i[l]).removeClass("ot-close-icon"), n !== Ze && n !== $e || (s.insertAdjacentElement("afterbegin", t(".onetrust-close-btn-handler").parentElement), m(i[l]).attr("tabindex", "1"))) : (h.setCloseIcon(t("#onetrust-banner-sdk .ot-close-icon")), m(i[l]).el.setAttribute(vt, N.BannerCloseButtonText || "Close Cookie Banner"));
        else {
            for (var l = 0; l < i.length; l++) m(i[l].parentElement).el.removeChild(i[l]);
            n !== Xe && n !== $e || v.removeChild(t("#onetrust-close-btn-container-mobile"))
        }
        return s
    }, Sr.prototype.setButtonsOrder = function(e) {
        if (this.checkButtonOrderPreconditions()) {
            var t = e("#onetrust-button-group");
            if (t) {
                t.classList.add("ot-button-order-container");
                var o, n, r = new Map;
                if (N.showBannerAcceptButton && (o = e(qo)) && (o.classList.add("ot-button-order-" + N.BannerBO.ACCEPT_ALL), r.set(N.BannerBO.ACCEPT_ALL, o)), N.BannerShowRejectAllButton && (o = e(jo)) && (o.classList.add("ot-button-order-" + N.BannerBO.REJECT_ALL), r.set(N.BannerBO.REJECT_ALL, o)), N.BShowSaveBtn && (o = e(".ot-bnr-save-handler")) && (n = void 0 !== N.BannerBO.SAVE_PREFERENCE && 0 <= N.BannerBO.SAVE_PREFERENCE ? N.BannerBO.SAVE_PREFERENCE : N.BannerBO.COOKIE_SETTINGS, o.classList.add("ot-button-order-" + n), r.set(n, o)), N.showBannerCookieSettings && this.addCookieSettingsButtonsOrder(e, r), !(r.size <= 0)) {
                    t.innerHTML = "";
                    for (var i = Array.from(r.keys()).sort(function(e, t) {
                            return e - t
                        }), s = 0; s < i.length; s++) {
                        var a = r.get(i[s]);
                        a && t.appendChild(a)
                    }
                }
            }
        }
    }, Sr.prototype.checkButtonOrderPreconditions = function() {
        return !(!N.PCTemplateUpgrade || !k.fp.WebButtonCustomisations || (this._isValidButtonOrderConfig = this.checkButtonsOrderValidation(), !this._isValidButtonOrderConfig))
    }, Sr.prototype.checkButtonsOrderValidation = function() {
        var e;
        return !(N.BShowSaveBtn && void 0 === N.BannerBO.SAVE_PREFERENCE && void 0 === N.BannerBO.COOKIE_SETTINGS || N.showBannerAcceptButton && void 0 === N.BannerBO.ACCEPT_ALL || N.BannerShowRejectAllButton && void 0 === N.BannerBO.REJECT_ALL || (e = this.isFourButtonsConfigured(), N.showBannerCookieSettings && void 0 === N.BannerBO.COOKIE_SETTINGS && !e))
    }, Sr.prototype.addCookieSettingsButtonsOrder = function(e, t) {
        var e = e(Ko),
            o = D.bannerName === tt,
            n = this.isFourButtonsConfigured(),
            r = o && n ? Number.MAX_VALUE : N.BannerBO.COOKIE_SETTINGS;
        e && (o && n || e.classList.add("ot-button-order-" + r), t.set(r, e))
    }, Sr.prototype.isFourButtonsConfigured = function() {
        return N.BannerShowRejectAllButton && N.showBannerAcceptButton && N.showBannerCookieSettings && N.BShowSaveBtn
    }, Sr.prototype.setAcceptAndRejectBtnHtml = function(e) {
        var t = D.bannerName,
            e = (N.showBannerAcceptButton ? (this._acceptBtn = e(qo), m(this._acceptBtn).html(N.AlertAllowCookiesText), t !== et || N.showBannerCookieSettings || N.BannerShowRejectAllButton || m(this._acceptBtn.parentElement).addClass("accept-btn-only")) : v.removeChild(e(qo)), N.BannerShowRejectAllButton && N.BannerRejectAllButtonText.trim() ? (this._rejectBtn = e(jo), m(this._rejectBtn).html(N.BannerRejectAllButtonText), e(this._btnGrpParentSelector).classList.add("has-reject-all-button")) : (v.removeChild(e(jo)), v.removeChild(e("#onetrust-reject-btn-container"))), m(e(Ko)));
        N.showBannerCookieSettings ? (e.html(N.AlertMoreInfoText), e.attr("aria-label", N.AlertMoreInfoTextDialog), N.BannerSettingsButtonDisplayLink && e.addClass("cookie-setting-link"), t !== et || N.showBannerAcceptButton || e.addClass("cookie-settings-btn-only")) : v.removeChild(e.el)
    }, Sr.prototype.setIAB2HtmlData = function(e) {
        var t = D.bannerName,
            o = (D.isIab2orv2Template && N.BannerDPDDescription.length && t !== tt ? (m(e(".ot-dpd-container .ot-dpd-title")).html(N.BannerDPDTitle), m(e(".ot-dpd-container .ot-dpd-desc")).html(N.BannerDPDDescription.join(",&nbsp;"))) : v.removeChild(e(".ot-dpd-container")), m(e(this._otGrpContainerSelector))),
            t = (D.isIab2orv2Template && N.BannerAdditionalDescription.trim() && this.setAdditionalDesc(e), D.isIab2orv2Template && N.BannerDPDDescription.length ? t !== tt ? m(e(".ot-dpd-container .ot-dpd-desc")) : o : m(e(yr.POLICY_TEXT_SELECTOR)));
        return N.IsIabEnabled && N.BannerIABPartnersLink && t.append('<a href="#" class="ot-link-btn onetrust-vendors-list-handler">\n        ' + N.BannerIABPartnersLink + "\n        </a>"), o
    }, Sr.prototype.setBannerData = function(e) {
        var t;
        N.BannerTitle ? (m(e("#onetrust-policy-title")).html(N.BannerTitle), m(e('[role="dialog"]')).attr(vt, N.BannerTitle)) : (v.removeChild(e("#onetrust-policy-title")), m(e("#onetrust-banner-sdk")).addClass("ot-wo-title"), m(e('[role="dialog"]')).attr(vt, N.AriaPrivacy)), !N.IsIabEnabled && p.showGeneralVendors && N.BannerNonIABVendorListText && ((t = document.createElement("div")).setAttribute("id", "ot-gv-link-ctnr"), m(t).html('<a href="#" class="ot-link-btn ot-gv-list-handler">' + N.BannerNonIABVendorListText + "</a>"), m(e("#onetrust-policy")).el.appendChild(t)), m(e(yr.POLICY_TEXT_SELECTOR)).html(N.AlertNoticeText), this.setBannerLinkAttributes(e)
    }, Sr.prototype.setBannerLinkAttributes = function(e) {
        var t, o;
        m(e(this.cookiePolicyLinkSelector)).length && (t = m(e(yr.POLICY_TEXT_SELECTOR + " .ot-cookie-policy-link")), e = m(e(yr.POLICY_TEXT_SELECTOR + " .ot-imprint-link")), o = "noopener noreferrer", N.BShowPolicyLink && t && (t.attr(vt, N.BCookiePolicyLinkScreenReader), t.attr("rel", o), t.attr("target", "_blank")), N.BShowImprintLink) && e && (e.attr(vt, N.BImprintLinkScreenReader), e.attr("rel", o), e.attr("target", "_blank"))
    }, Sr.prototype.isCmpEnabled = function() {
        return N.BannerPurposeTitle || N.BannerPurposeDescription || N.BannerFeatureTitle || N.BannerFeatureDescription || N.BannerInformationTitle || N.BannerInformationDescription
    }, Sr.prototype.ssrAndNonSSRCommonHtml = function(t) {
        function e(e) {
            return t.querySelector(e)
        }

        function o(e) {
            return t.querySelectorAll(e)
        }
        var n, r, i, s = this,
            a = this.isCmpEnabled(),
            l = (this.setOptOutSignalNotification(e), "[VENDOR_NUMBER]"),
            c = e(yr.POLICY_TEXT_SELECTOR),
            d = m(c).html(),
            l = (D.isIab2orv2Template && -1 < d.indexOf(l) && (n = '<span class="ot-tcf2-vendor-count ot-text-bold">' + D.tcf2ActiveVendors.all.toString() + "</span>", r = ".ot-cookie-policy-link, .ot-imprint-link", i = [], c && c.querySelectorAll(r).forEach(function(e) {
                i.push(e.innerHTML)
            }), d = h.replaceTextFromString(l, d, n), m(c).html(d), c) && i.length && c.querySelectorAll(r).forEach(function(e, t) {
                t < i.length && (e.innerHTML = i[t])
            }), D.bannerName === tt && k.moduleInitializer.IsSuppressPC && (p.dataGroupState = N.Groups.filter(function(e) {
                return e.Order
            })), h.addExternalIconForLinks(o), D.bannerName === tt && (this._fourBtns = this.isFourButtonsConfigured(), this._saveBtn = e(".ot-bnr-save-handler"), this._settingsBtn = e(Ko), this._btnsCntr = e(".banner-actions-container"), N.BShowSaveBtn ? m(this._saveBtn).html(N.BSaveBtnTxt) : (v.removeChild(this._saveBtn), this._saveBtn = null), h.insertFooterLogo(o(".ot-bnr-footer-logo a")), this._descriptCntr = e(".ot-cat-lst"), this.setBannerBtn(), window.addEventListener("resize", function() {
                s.setBannerBtn()
            }), this._fourBtns && m(e("#onetrust-banner-sdk")).addClass("has-reject-all-button"), this.insertGrps(e)), h.replaceHeadings(t), document.createElement("div"));
        m(l).append(t), D.ignoreInjectingHtmlCss || (m("#onetrust-consent-sdk").append(l.firstChild), a && this.setBannerOptionContent()), this.setBnrBtnGrpAlignment()
    }, Sr.prototype.setAriaModalForBanner = function(e) {
        N.ForceConsent && e.querySelector('[role="dialog"]').setAttribute("aria-modal", "true")
    }, Sr.prototype.setBnrBtnGrpAlignment = function() {
        var e = m(this._otGrpContainerSelector).el,
            t = m(this._btnGrpParentSelector).el,
            e = ((e.length && e[0].clientHeight) < (t.length && t[0].clientHeight) ? m("#onetrust-banner-sdk").removeClass("vertical-align-content") : m("#onetrust-banner-sdk").addClass("vertical-align-content"), document.querySelector("#onetrust-button-group-parent button:first-of-type")),
            t = document.querySelector("#onetrust-button-group-parent button:last-of-type");
        t && e && 1 < Math.abs(t.offsetTop - e.offsetTop) && m("#onetrust-banner-sdk").addClass("ot-buttons-fw")
    }, Sr.prototype.slideInAnimation = function(e, t) {
        t === Xe ? "bottom" === N.BannerPosition ? (e.css("bottom: -99px;"), e.animate({
            bottom: "0px"
        }, 1e3), p.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("bottom: 0px;"), p.bnrAnimationInProg = !1
        }, 1e3)) : (e.css("top: -99px; bottom: auto;"), D.pagePushedDown && !Ro.checkIsBrowserIE11OrBelow() ? Ro.BannerPushDownHandler() : (e.animate({
            top: "0"
        }, 1e3), p.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("top: 0px; bottom: auto;"), p.bnrAnimationInProg = !1
        }, 1e3))) : t !== Qe && t !== et || (e.css("bottom: -300px;"), e.animate({
            bottom: "1em"
        }, 2e3), p.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("bottom: 1rem;"), p.bnrAnimationInProg = !1
        }, 2e3))
    }, Sr.prototype.setBannerBtn = function() {
        var e;
        N.PCTemplateUpgrade && k.fp.WebButtonCustomisations && this._isValidButtonOrderConfig && D.bannerName === tt ? window.innerWidth <= 600 && this._fourBtns ? (e = document.querySelector("#onetrust-button-group"), v.insertElement(e, this._settingsBtn, "beforeend")) : this._fourBtns && this._descriptCntr.insertAdjacentElement("beforeend", this._settingsBtn) : window.innerWidth <= 600 ? (v.insertElement(this._btnsCntr, this._settingsBtn, "afterbegin"), v.insertElement(this._btnsCntr, this._saveBtn, "afterbegin"), v.insertElement(this._btnsCntr, this._acceptBtn, "afterbegin"), v.insertElement(this._btnsCntr, this._rejectBtn, "afterbegin")) : this._fourBtns ? (this._descriptCntr.insertAdjacentElement("beforeend", this._settingsBtn), this._acceptBtn.insertAdjacentElement("beforebegin", this._rejectBtn), this._btnsCntr.insertAdjacentElement("beforebegin", this._saveBtn)) : (v.insertElement(this._btnsCntr, this._settingsBtn, "beforebegin"), v.insertElement(this._btnsCntr, this._saveBtn, this._settingsBtn ? "afterbegin" : "beforebegin"), v.insertElement(this._btnsCntr, this._rejectBtn, "beforeend"), v.insertElement(this._btnsCntr, this._acceptBtn, "beforeend"))
    }, Sr.prototype.setCmpBannerOptions = function(n, e) {
        var r = m(n("#banner-options .banner-option")).el.cloneNode(!0),
            i = (m(n(this._bannerOptionsSelector)).html(""), 1);
        e.forEach(function(e) {
            var t = r.cloneNode(!0),
                o = N[e.titleKey],
                e = N[e.descriptionKey];
            (o || e) && (t.querySelector(".banner-option-header :first-child").innerHTML = S.getInnerHtmlContent(o), o = t.querySelector(".banner-option-details"), e ? (o.setAttribute("id", "option-details-" + i++), o.innerHTML = S.getInnerHtmlContent(e)) : o.parentElement.removeChild(o), m(n("#banner-options")).el.appendChild(t))
        })
    }, Sr.prototype.setFloatingRoundedIconBannerCmpOptions = function(n, e) {
        var r = this,
            i = m(n("#banner-options button")).el.cloneNode(!0),
            s = m(n(".banner-option-details")).el.cloneNode(!0);
        m(n(this._bannerOptionsSelector)).html(""), e.forEach(function(e) {
            var t = i.cloneNode(!0),
                o = N[e.titleKey];
            (o || N[e.descriptionKey]) && (t.setAttribute("id", e.identifier), t.querySelector(".banner-option-header :first-child").innerHTML = S.getInnerHtmlContent(o), m(n(r._bannerOptionsSelector)).el.appendChild(t))
        }), e.forEach(function(e) {
            var t, o = N[e.descriptionKey];
            o && ((t = s.cloneNode(!0)).innerHTML = S.getInnerHtmlContent(o), t.classList.add(e.identifier), m(n(r._bannerOptionsSelector)).el.appendChild(t))
        })
    }, Sr.prototype.setBannerOptionContent = function() {
        var t = this;
        D.bannerName !== Xe && D.bannerName !== $e || setTimeout(function() {
            var e;
            (window.innerWidth < 769 ? (e = m(t._bannerOptionsSelector).el[0], m(t._otGrpContainerSelector)) : (e = m(t._bannerOptionsSelector).el[0], D.bannerName === $e ? m(".banner-content") : m("#onetrust-banner-sdk .ot-sdk-container"))).el[0].appendChild(e)
        })
    }, Sr.prototype.setAdditionalDesc = function(e) {
        var t = N.BannerAdditionalDescPlacement,
            o = document.createElement("span"),
            n = (o.classList.add("ot-b-addl-desc"), m(o).html(N.BannerAdditionalDescription), e(yr.POLICY_TEXT_SELECTOR));
        t === le.AfterTitle ? n.insertAdjacentElement("beforeBegin", o) : t === le.AfterDescription ? n.insertAdjacentElement("afterEnd", o) : t === le.AfterDPD && (n = e(".ot-dpd-container .ot-dpd-desc"), (n = N.ChoicesBanner ? e(this._otGrpContainerSelector) : n).insertAdjacentElement("beforeEnd", o))
    }, Sr.prototype.insertGrps = function(e) {
        var d = e(".ot-cat-item").cloneNode(!0),
            u = (v.removeChild(e(".ot-cat-item")), N.BCategoryStyle === ve.Checkbox ? v.removeChild(d.querySelector(".ot-tgl")) : (v.removeChild(d.querySelector(".ot-chkbox")), m(d).addClass("ot-cat-bdr")), e(".ot-cat-lst ul"));
        N.Groups.forEach(function(e) {
            var t = d.cloneNode(!0),
                o = t.querySelector(".ot-tgl,.ot-chkbox"),
                n = e.GroupName,
                r = e.CustomGroupId,
                i = "ot-bnr-grp-id-" + r,
                s = "ot-bnr-hdr-id-" + r,
                a = -1 !== Bt.indexOf(e.Type),
                l = L.getGrpStatus(e).toLowerCase() === f.ALWAYS_ACTIVE || a,
                c = L.getGrpStatus(e).toLowerCase() === f.ALWAYS_INACTIVE || a,
                a = y.isGroupActive(e) || a,
                e = (m(o.querySelector("label")).attr("for", i), m(o.querySelector(".ot-label-txt")).html(e.GroupName), o.querySelector("input")),
                l = ((l || c) && (N.BCategoryStyle === ve.Toggle ? (v.removeChild(o), t.insertAdjacentElement("beforeend", m("<div class='ot-always-active'>" + (c ? N.AlwaysInactiveText : N.AlwaysActiveText) + "</div>", "ce").el)) : e.setAttribute("aria-disabled", "true")), e.classList.add("category-switch-handler"), y.setInputID(e, i, r, a, s), t.querySelector('h4, p[aria-level="4"]'));
            m(l).html(n), m(l).attr("id", s), m(u).append(t)
        })
    }, Sr.prototype.setBannerLogo = function(e, t) {
        var o, n;
        k.fp.CookieV2BannerLogo && N.BnrLogo && (o = t(Mo), n = "afterend", D.bannerName === $e && (o = t("#onetrust-cookie-btn"), n = "beforeend"), t = h.updateCorrectUrl(N.BnrLogo), m(e).addClass("ot-bnr-w-logo"), m(o).el.innerHTML = S.getInnerHtmlContent(""), o.insertAdjacentHTML(n, S.getInnerHtmlContent("<img class='ot-bnr-logo' src='" + t + "'\n            title='" + N.BnrLogoAria + "'\n            alt='" + N.BnrLogoAria + "'/>")))
    }, Sr.prototype.setOptOutSignalNotification = function(e) {
        var t = D.gpcEnabled && D.gpcForAGrpEnabled;
        N.BShowOptOutSignal && (t || D.previewMode) && (h.createOptOutSignalElement(e, !1), h.applyOptOutSignalA11y(!1, e))
    };
    var yr, fr = Sr;

    function Sr() {
        this.POLICY_TEXT_SELECTOR = "#onetrust-policy-text", this.El = "#onetrust-banner-sdk", this._saveBtn = null, this._settingsBtn = null, this._acceptBtn = null, this._rejectBtn = null, this._descriptCntr = null, this._btnsCntr = null, this._fourBtns = !1, this._isValidButtonOrderConfig = !0, this._bannerOptionsSelector = "#banner-options", this._btnGrpParentSelector = "#onetrust-button-group-parent", this._otGrpContainerSelector = "#onetrust-group-container", this.cookiePolicyLinkSelector = "#onetrust-policy-text a"
    }
    Tr.prototype.setHeaderConfig = function() {
        mr.setHeader(), mr.setSearchInput(), mr.setHeaderUIConsent();
        var e = mr.getGroupsForFilter();
        sr.setFilterListByGroup(e, !1)
    }, Tr.prototype.filterVendorByString = function(e) {
        mr.searchQuery = e, mr.filterVendorByGroupOrQuery()
    }, Tr.prototype.filterVendorByGroup = function(e) {
        mr.filterGroups = e, mr.filterVendorByGroupOrQuery()
    }, Tr.prototype.showVSList = function() {
        mr.removeListeners(), mr.showEmptyResults(!1, ""), mr.clearUIElementsInMain(), mr.addVSList(p.getVendorsInDomain())
    }, Tr.prototype.showEmptyResults = function(e, t) {
        e ? this.setNoResultsContent(t) : (m("#onetrust-pc-sdk " + T.P_Vendor_Content).removeClass("no-results"), (e = m("#onetrust-pc-sdk #no-results")).length && e.remove())
    }, Tr.prototype.setNoResultsContent = function(e) {
        var t, o, n, r, i = m("#onetrust-pc-sdk #no-results").el[0];
        if (!i) return t = document.createElement("div"), o = document.createElement("p"), n = document.createTextNode(" " + N.PCVendorNotFound + "."), r = document.createElement("span"), t.id = "no-results", t.setAttribute("aria-live", "assertive"), t.setAttribute("aria-atomic", "true"), r.id = "user-text", r.innerText = e, o.appendChild(r), o.appendChild(n), t.appendChild(o), m("#onetrust-pc-sdk " + T.P_Vendor_Content).addClass("no-results"), m("#vendor-search-handler").el[0].setAttribute("aria-describedby", t.id), m("#onetrust-pc-sdk " + T.P_Vendor_Content).append(t);
        i.querySelector("span").innerText = e
    }, Tr.prototype.getGroupsFilter = function() {
        for (var e = [], t = 0, o = m("#onetrust-pc-sdk .category-filter-handler").el; t < o.length; t++) {
            var n = o[t],
                r = n.getAttribute("data-purposeid");
            n.checked && e.push(r)
        }
        return e
    }, Tr.prototype.cancelFilter = function() {
        for (var e = 0, t = m("#onetrust-pc-sdk .category-filter-handler").el; e < t.length; e++) {
            var o = t[e],
                n = o.getAttribute("data-optanongroupid"),
                n = 0 <= p.filterByCategories.indexOf(n);
            v.setCheckedAttribute(null, o, n)
        }
        var r = mr.getGroupsFilter();
        mr.filterVendorByGroup(r)
    }, Tr.prototype.clearFilter = function() {
        mr.searchQuery = "", mr.filterGroups = []
    }, Tr.prototype.toggleVendors = function(r) {
        p.getVendorsInDomain().forEach(function(e, t) {
            var o, n;
            L.isAlwaysActiveGroup(e.groupRef) || (o = document.getElementById("ot-vendor-id-" + t), n = document.getElementById("ot-vs-lst-id-" + t), O.toggleVendorService(e.groupRef.CustomGroupId, t, r, o), O.toggleVendorService(e.groupRef.CustomGroupId, t, r, n))
        })
    }, Tr.prototype.hideVendorList = function() {
        mr.removeListeners(), mr.clearUIElementsInMain()
    }, Tr.prototype.addListeners = function() {
        m("#onetrust-pc-sdk " + T.P_Vendor_Content + " .ot-vs-list .category-switch-handler").on("click", mr.toggleVendorHandler), m("#onetrust-pc-sdk").on("click", ".ot-vs-list", u.onCategoryItemToggle.bind(this))
    }, Tr.prototype.removeListeners = function() {
        var e;
        document.querySelectorAll("#onetrust-pc-sdk .ot-vs-list .category-switch-handler").forEach(function(e) {
            return e.removeEventListener("click", u.toggleGroupORVendorHandler)
        }), null != (e = document.querySelector("#onetrust-pc-sdk .ot-vs-list")) && e.removeEventListener("click", u.onCategoryItemToggle)
    }, Tr.prototype.toggleVendorHandler = function(e) {
        u.toggleVendorFromListHandler(e), mr.checkAllowAllCheckedValue()
    }, Tr.prototype.filterVendorByGroupOrQuery = function() {
        var o = new Map;
        p.getVendorsInDomain().forEach(function(e, t) {
            mr.checkVendorConditions(e) && o.set(t, e)
        }), mr.showEmptyResults(o.size <= 0, mr.searchQuery), mr.removeListeners(), mr.clearUIElementsInMain(), mr.addVSList(o)
    }, Tr.prototype.checkVendorConditions = function(e) {
        return !("" !== mr.searchQuery && e.ServiceName.toLowerCase().indexOf(mr.searchQuery.toLowerCase()) < 0 || 0 < mr.filterGroups.length && mr.filterGroups.indexOf(e.groupRef.CustomGroupId) < 0)
    }, Tr.prototype.addVSList = function(e) {
        var t = m("#onetrust-pc-sdk " + T.P_Vendor_Content + " .ot-sdk-column"),
            o = O.getVendorListEle(e);
        t.append(o);
        h.addExternalIconForLinks(function(e) {
            return o.querySelectorAll(e)
        }), mr.addListeners()
    }, Tr.prototype.getGroupsForFilter = function() {
        var t = new Map;
        return p.getVendorsInDomain().forEach(function(e) {
            t.has(e.groupRef.CustomGroupId) || t.set(e.groupRef.CustomGroupId, e.groupRef)
        }), Array.from(t.values())
    }, Tr.prototype.clearUIElementsInMain = function() {
        m("#onetrust-pc-sdk " + T.P_Vendor_Content + " ul" + T.P_Host_Cntr).html(""), m("#onetrust-pc-sdk " + T.P_Vendor_Content + " ul" + T.P_Host_Cntr).hide(), m("#onetrust-pc-sdk " + T.P_Vendor_Content + " ul" + T.P_Vendor_Container).html(""), m("#onetrust-pc-sdk " + T.P_Vendor_Content + " ul" + T.P_Vendor_Container).hide();
        var e = m("#onetrust-pc-sdk " + T.P_Vendor_Content + " .ot-vs-list");
        e && e.length && e.remove()
    }, Tr.prototype.setHeader = function() {
        var e = N.VendorServiceConfig.PCVSListTitle,
            t = document.querySelector("#onetrust-pc-sdk " + T.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]');
        t && (t.innerText = e)
    }, Tr.prototype.setSearchInput = function() {
        var e = N.PCenterCookieListSearch,
            t = N.PCenterCookieSearchAriaLabel,
            o = m("#onetrust-pc-sdk " + T.P_Vendor_Search_Input);
        o.el[0].placeholder = e, o.attr("aria-label", t)
    }, Tr.prototype.setHeaderUIConsent = function() {
        var e, t, o;
        m("#onetrust-pc-sdk " + T.P_Select_Cntr).addClass("ot-vnd-list-cnt"), m("#onetrust-pc-sdk " + T.P_Select_Cntr + " .ot-sel-all").addClass("ot-vs-selc-all"), N.PCCategoryStyle === ve.Toggle && (m("#onetrust-pc-sdk " + T.P_Select_Cntr + " .ot-sel-all").addClass("ot-toggle-conf"), N.PCAccordionStyle === ce.Caret) && m("#onetrust-pc-sdk " + T.P_Select_Cntr + " .ot-sel-all").addClass("ot-caret-conf"), m("#onetrust-pc-sdk " + T.P_Leg_Select_All).hide(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Host_El).hide(), m("#onetrust-pc-sdk " + T.P_Host_Cntr).hide(), m(T.P_Vendor_List + " #select-all-text-container").hide(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).hide(), m("#onetrust-pc-sdk " + T.P_Vendor_Container).show(), m("#onetrust-pc-sdk " + T.P_Select_Cntr).show(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Consent_El).show("inline-block"), m("#onetrust-pc-sdk " + T.P_Vendor_List).removeClass(T.P_Host_UI), m("#onetrust-pc-sdk " + T.P_Vendor_Content).removeClass(T.P_Host_Cnt), document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox .sel-all-hdr") || (e = void 0, null != (t = k.moduleInitializer) && t.SEOOptimization ? ((e = document.createElement("p")).setAttribute("role", "heading"), e.setAttribute("aria-level", "4")) : e = document.createElement("h4"), e.className = "sel-all-hdr", e.textContent = (null == (t = N.VendorServiceConfig) ? void 0 : t.PCVSAllowAllText) || "PCVSAllowAllText", t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"), o = N.PCCategoryStyle === ve.Checkbox ? "beforeend" : "afterbegin", t.insertAdjacentElement(o, e)), mr.checkAllowAllCheckedValue()
    }, Tr.prototype.checkAllowAllCheckedValue = function() {
        var t = !0,
            e = (p.vsConsent.forEach(function(e) {
                e || (t = !1)
            }), document.getElementById("#select-all-vendor-groups-handler"));
        v.setCheckedAttribute(null, e, t)
    };
    var mr, vr = Tr;

    function Tr() {
        this.searchQuery = "", this.filterGroups = []
    }
    r.prototype.initCookieSettingHandlers = function() {
        m(document).on("click", ".optanon-show-settings, .optanon-toggle-display, .ot-sdk-show-settings, .ot-pc-handler", this.cookiesSettingsBoundListener)
    }, r.prototype.initFlgtCkStgBtnEventHandlers = function() {
        m(".ot-floating-button__open").on("click", function(e) {
            setTimeout(function() {
                u.floatingCookieSettingOpenBtnClicked(e)
            }, 0)
        }), m(".ot-floating-button__close").on("click", function(e) {
            setTimeout(function() {
                u.floatingCookieSettingCloseBtnClicked(e)
            }, 0)
        })
    }, r.prototype.floatingCookieSettingOpenBtnClicked = function(e) {
        m(u.fltgBtnSltr).addClass("ot-pc-open"), N.cookiePersistentLogo.includes("ot_guard_logo.svg") && m(u.fltgBtnFSltr).attr(Tt, "true"), m(u.fltgBtnBSltr).attr(Tt, ""), m(u.fltgBtnFrontBtn).el[0].setAttribute(Tt, !0), m(u.fltgBtnFrontBtn).el[0].style.display = "none", m(u.fltgBtnBackBtn).el[0].setAttribute(vt, N.AriaClosePreferences), m(u.fltgBtnBackBtn).el[0].setAttribute(Tt, !1), m(u.fltgBtnBackBtn).el[0].style.display = "block", uo.triggerGoogleAnalyticsEvent(fn, En), u.showCookieSettingsHandler(e)
    }, r.prototype.floatingCookieSettingCloseBtnClicked = function(e) {
        m(u.fltgBtnFrontBtn).el[0].setAttribute(vt, h.getFloatingBtnAriaLabel()), m(u.fltgBtnFrontBtn).el[0].setAttribute(Tt, !1), m(u.fltgBtnFrontBtn).el[0].style.display = "block", m(u.fltgBtnBackBtn).el[0].setAttribute(Tt, !0), m(u.fltgBtnBackBtn).el[0].style.display = "none", e && (uo.triggerGoogleAnalyticsEvent(fn, On), u.hideCookieSettingsHandler(e))
    }, r.prototype.initialiseLegIntBtnHandlers = function() {
        m(document).on("click", ".ot-obj-leg-btn-handler", u.onLegIntButtonClick), m(document).on("click", ".ot-remove-objection-handler", u.onLegIntButtonClick)
    }, r.prototype.initialiseAddtlVenHandler = function() {
        m("#onetrust-pc-sdk #ot-addtl-venlst").on("click", u.selectVendorsGroupHandler), m("#onetrust-pc-sdk #ot-selall-adtlven-handler").on("click", u.selAllAdtlVenHandler)
    }, r.prototype.initializeGenVenHandlers = function() {
        m("#onetrust-pc-sdk #ot-gn-venlst .ot-gnven-chkbox-handler").on("click", u.genVendorToggled), m("#onetrust-pc-sdk #ot-gn-venlst .ot-gv-venbox").on("click", u.genVendorDetails), m("#onetrust-pc-sdk #ot-selall-gnven-handler").on("click", u.selectAllGenVenHandler)
    }, r.prototype.initialiseConsentNoticeHandlers = function() {
        var e = this;
        D.pcName === at && u.categoryMenuSwitchHandler(), m("#onetrust-pc-sdk .onetrust-close-btn-handler").on("click", function(e) {
            setTimeout(function() {
                u.bannerCloseButtonHandler(e)
            }, 0)
        }), m("#onetrust-pc-sdk #accept-recommended-btn-handler").on("click", function() {
            setTimeout(function() {
                g.allowAllEventHandler(!0)
            }, 0)
        }), m("#onetrust-pc-sdk .ot-pc-refuse-all-handler").on("click", function() {
            setTimeout(function() {
                g.rejectAllEventHandler(!0)
            }, 0)
        }), m("#onetrust-pc-sdk #close-pc-btn-handler").on("click", function(e) {
            setTimeout(function() {
                w.pcClosedFromCloseBtn = !0, w.bannerCloseSource = ee.BannerCloseButton, u.hideCookieSettingsHandler(e)
            }, 0)
        }), m(document).on("keydown", u.closePCWhenEscPressed), m("#onetrust-pc-sdk #vendor-close-pc-btn-handler").on("click", u.hideCookieSettingsHandler), m("#onetrust-pc-sdk .category-switch-handler").on("click", u.toggleGroupORVendorHandler), m("#onetrust-pc-sdk .cookie-subgroup-handler").on("click", u.toggleSubCategory), m("#onetrust-pc-sdk .category-menu-switch-handler").on("keydown", function(e) {
            D.pcName !== at || e.keyCode !== ae.UpArrow && e.keyCode !== ae.DownArrow || (e.preventDefault(), N.PCTemplateUpgrade ? u.changeSelectedTabV2(e) : u.changeSelectedTab(e))
        }), m("" + u.PC_SELECTOR).on("click", T.P_Category_Item + " > input:first-child," + T.P_Category_Item + " > button:first-child", u.onCategoryItemToggle.bind(this)), (N.showCookieList || w.showGeneralVendors) && (m("#onetrust-pc-sdk .category-host-list-handler").on("click", function(e) {
            setTimeout(function() {
                w.showGeneralVendors && N.showCookieList ? w.cookieListType = ye.HostAndGenVen : w.showGeneralVendors ? w.cookieListType = ye.GenVen : w.cookieListType = ye.Host, u.pcLinkSource = e.target, u.loadCookieList(e.target)
            }, 0)
        }), h.isOptOutEnabled() ? (m("#onetrust-pc-sdk #select-all-hosts-groups-handler").on("click", u.selectAllHostsGroupsHandler), m("#onetrust-pc-sdk " + T.P_Host_Cntr).on("click", u.selectHostsGroupHandler)) : m("#onetrust-pc-sdk " + T.P_Host_Cntr).on("click", u.toggleAccordionStatus)), u.addListenerWhenIabEnabled(), u.addEventListenerWhenIsHostOrVendorsAreEnabled(), u.adddListenerWhenNoBanner(), m("#onetrust-pc-sdk .ot-gv-list-handler").on("click", function(t) {
            return F(e, void 0, void 0, function() {
                return M(this, function(e) {
                    return w.cookieListType = ye.GenVen, u.loadCookieList(t.target), [2]
                })
            })
        }), u.addListenerWhenVendorServices(), u.addEventListnerForVendorsList()
    }, r.prototype.addEventListenerWhenIsHostOrVendorsAreEnabled = function() {
        (N.IsIabEnabled || N.showCookieList || w.showGeneralVendors || w.showVendorService) && (m(document).on("click", ".back-btn-handler", u.backBtnHandler), u.addListenerSearchKeyEvent(), m(this.FILTER_BTN_SELECTOR).on("click", u.toggleVendorFiltersHandler), u.setFilterButtonExpanded(!1), m("#onetrust-pc-sdk #filter-apply-handler").on("click", function() {
            setTimeout(function() {
                u.applyFilterHandler()
            }, 0)
        }), m("#onetrust-pc-sdk " + T.P_Fltr_Modal).on("click", u.tglFltrOptionHandler), !k.isV2Template && D.pcName !== st || m("#onetrust-pc-sdk #filter-cancel-handler").on("click", u.cancelFilterHandler), !k.isV2Template && D.pcName === st || m("#onetrust-pc-sdk #clear-filters-handler").on("click", u.clearFiltersHandler), k.isV2Template ? m("#onetrust-pc-sdk #filter-cancel-handler").on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || e.shiftKey || (e.preventDefault(), m("#onetrust-pc-sdk #clear-filters-handler").el[0].focus())
        }) : m("#onetrust-pc-sdk #filter-apply-handler").on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || e.shiftKey || (e.preventDefault(), (e = m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Option).el[0]) && e.focus())
        }), m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Options).on("keydown", function(e) {
            var t = m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Option).el[0];
            9 !== e.keyCode && "tab" !== e.code || !e.shiftKey || e.target !== t || (e.preventDefault(), m("#onetrust-pc-sdk #filter-apply-handler").el[0].focus())
        }))
    }, r.prototype.addListenerSearchKeyEvent = function() {
        m(u.VENDOR_SEARCH_SELECTOR).on("keyup", function(e) {
            e = e.target.value.trim();
            u.currentSearchInput !== e && (w.showVendorService ? mr.filterVendorByString(e) : u.isCookieList ? (C.searchHostList(e), w.showTrackingTech && u.addEventAdditionalTechnologies()) : (C.loadVendorList(e, []), N.UseGoogleVendors && C.searchVendors(C.googleSearchSelectors, w.addtlVendorsList, me.GoogleVendor, e), w.showGeneralVendors && N.GeneralVendors.length && C.searchVendors(C.genVendorSearchSelectors, N.GeneralVendors, me.GeneralVendor, e)), C.playSearchStatus(u.isCookieList), u.currentSearchInput = e)
        })
    }, r.prototype.addListenerWhenIabEnabled = function() {
        N.IsIabEnabled && (m("#onetrust-pc-sdk .category-vendors-list-handler").on("click", function(e) {
            setTimeout(function() {
                u.pcLinkSource = e.target, u.showVendorsList(e.target)
            }, 0)
        }), m("#onetrust-pc-sdk .ot-pgph-link").on("click", function(e) {
            u.pcLinkSource = e.target, u.showIllustrations(e.target)
        }), m("#onetrust-pc-sdk " + T.P_Vendor_Container).on("click", u.selectVendorsGroupHandler), N.UseGoogleVendors || u.bindSelAllHandlers(), u.initialiseLegIntBtnHandlers())
    }, r.prototype.adddListenerWhenNoBanner = function() {
        N.NoBanner && (N.OnClickCloseBanner && document.body.addEventListener("click", g.bodyClickEvent), N.ScrollCloseBanner) && window.addEventListener("scroll", g.scrollCloseBanner)
    }, r.prototype.addListenerWhenVendorServices = function() {
        w.showVendorService && (u.bindSelAllHandlers(), m("#onetrust-pc-sdk .onetrust-vendors-list-handler").on("click", function() {
            setTimeout(function() {
                u.showVendorsList(null, !0)
            }, 0)
        }))
    }, r.prototype.bindSelAllHandlers = function() {
        m("#onetrust-pc-sdk #select-all-vendor-leg-handler").on("click", u.selectAllVendorsLegIntHandler), m("#onetrust-pc-sdk #select-all-vendor-groups-handler").on("click", u.SelectAllVendorConsentHandler)
    }, r.prototype.hideCookieSettingsHandler = function(e) {
        void 0 === e && (e = window.event), $n.getInstance().resetHealthSignatureData(), uo.triggerGoogleAnalyticsEvent(fn, An), Ro.removeAddedOTCssStyles(Ho.PC), w.pcLayer === se.IabIllustrations && pr.hideUI(), null != (t = null == (t = window.OneTrust_ConfirmDialog) ? void 0 : t.getInstance()) && t.close(), m(document).off("keydown", u.closePCWhenEscPressed), u.getResizeElement().removeEventListener("resize", u.setCenterLayoutFooterHeight), window.removeEventListener("resize", u.setCenterLayoutFooterHeight), !k.isV2Template && D.pcName !== st || u.closeFilter(!1), D.pcName === rt && m("#onetrust-pc-sdk " + T.P_Content).removeClass("ot-hide"), g.hideVendorsList(), js.csBtnGroup && (m(u.fltgBtnSltr).removeClass("ot-pc-open"), u.floatingCookieSettingCloseBtnClicked(null));
        var t = w.pcClosedFromCloseBtn;
        return Jo.hideConsentNoticeV2(), w.pcClosedFromCloseBtn = t, u.confirmPC(e), g.resetConsent(), js.csBtnGroup && h.syncOptOutNotification(), !1
    }, r.prototype.selectAllHostsGroupsHandler = function(e) {
        var t = e.target;
        if ("function" == typeof t.getAttribute && "true" === t.getAttribute(this.AriaDisabled)) e.preventDefault(), e.stopPropagation(), t.checked = !1;
        else {
            var o = !!t.checked,
                e = m("#onetrust-pc-sdk #" + T.P_Sel_All_Host_El).el[0],
                t = e.classList.contains("line-through"),
                n = m("#onetrust-pc-sdk .host-checkbox-handler").el;
            v.setCheckedAttribute("#select-all-hosts-groups-handler", null, o), v.setAriaCheckedAttribute("#select-all-hosts-groups-handler", null, o.toString());
            for (var r = 0; r < n.length; r++) n[r].getAttribute("disabled") || v.setCheckedAttribute(null, n[r], o);
            w.optanonHostList.forEach(function(e) {
                Io.updateHostStatus(e, o)
            }), n.forEach(function(e) {
                mo.updateGenVendorStatus(e.getAttribute("hostId"), o)
            }), t && e.classList.remove("line-through")
        }
    }, r.prototype.selectHostsGroupHandler = function(e) {
        u.toggleAccordionStatus(e);
        var t = e.target.getAttribute("hostId"),
            o = e.target.getAttribute("ckType"),
            n = e.target.checked;
        null !== t && (o === he.GenVendor ? (o = N.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        }).Name, uo.triggerGoogleAnalyticsEvent(fn, n ? Nn : wn, o + ": VEN_" + t), mo.updateGenVendorStatus(t, n)) : (o = v.findIndex(w.optanonHostList, function(e) {
            return e.HostId === t
        }), o = w.optanonHostList[o], u.toggleHostStatus(o, n)), v.setCheckedAttribute(null, e.target, n))
    }, r.prototype.onCategoryItemToggle = function(e) {
        e.stopPropagation();
        var t = e.target;
        "BUTTON" !== t.tagName && "INPUT" !== t.tagName || (D.pcName === rt && this.setPcListContainerHeight(), u.toggleAccordionStatus(e))
    }, r.prototype.setFilterButtonExpanded = function(e) {
        var t;
        try {
            var o = null == (t = m(this.FILTER_BTN_SELECTOR).el) ? void 0 : t[0];
            o && o.setAttribute(this.ARIA_EXPANDED, e ? "true" : "false")
        } catch (e) {
            console.info(e)
        }
    }, r.prototype.focusFilterButton = function() {
        m(this.FILTER_BTN_SELECTOR).focus()
    }, r.prototype.toggleHostStatus = function(e, t) {
        uo.triggerGoogleAnalyticsEvent(fn, t ? Bn : Vn, e.HostName + ": H_" + e.HostId), Io.updateHostStatus(e, t)
    }, r.prototype.toggleBannerOptions = function(e) {
        var t = this;
        m(".banner-option-input").each(function(e) {
            m(e).el.setAttribute(t.ARIA_EXPANDED, "false")
        }), u.toggleAccordionStatus(e)
    }, r.prototype.bannerCloseButtonHandler = function(n) {
        var r;
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                return m(document).off("keydown", u.shiftBannerFocus), -1 < (t = (null == (r = null == (r = n) ? void 0 : r.target) ? void 0 : r.className) || "").indexOf("save-preference-btn-handler") ? (w.bannerCloseSource = ee.ConfirmChoiceButton, uo.triggerGoogleAnalyticsEvent(fn, bn)) : -1 < t.indexOf("banner-close-button") ? (w.bannerCloseSource = ee.BannerCloseButton, o = mn, -1 < t.indexOf("ot-close-link") && (o = vn, w.bannerCloseSource = ee.ContinueWithoutAcceptingButton), uo.triggerGoogleAnalyticsEvent(fn, o)) : -1 < t.indexOf("ot-bnr-save-handler") && (w.bannerCloseSource = ee.BannerSaveSettings, uo.triggerGoogleAnalyticsEvent(fn, Tn)), Ro.removeAddedOTCssStyles(), g.hideVendorsList(), [2, g.bannerCloseButtonHandler()]
            })
        })
    }, r.prototype.onLegIntButtonClick = function(e) {
        var t, o, n, r;
        e && (n = "true" === (e = e.currentTarget).parentElement.getAttribute("is-vendor"), t = e.parentElement.getAttribute("data-group-id"), r = "", o = !e.classList.contains("ot-leg-int-enabled"), n ? u.onVendorToggle(t, de.LI) : (r = (n = L.getGroupById(t)).GroupName, n.Parent ? u.updateSubGroupToggles(n, o, !0) : u.updateGroupToggles(n, o, !0)), y.updateLegIntBtnElement(e.parentElement, o, r))
    }, r.prototype.updateGroupToggles = function(t, o, e) {
        Io.toggleGroupHosts(t, o), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(t, o), t.IsLegIntToggle = e, u.toggleGroupStatus(t, o), t.SubGroups && t.SubGroups.length && (D.bannerName === tt && k.moduleInitializer.IsSuppressPC && t.SubGroups.length ? t.SubGroups.forEach(function(e) {
            e.IsLegIntToggle = t.IsLegIntToggle, y.toggleGrpStatus(e, o), e.IsLegIntToggle = !1, Io.toggleGroupHosts(e, o), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(e, o), O.setVendorStateByGroup(e, o)
        }) : y.toogleAllSubGrpElements(t, o), t.SubGroups.forEach(function(e) {
            return O.setVendorStateByGroup(e, o)
        })), O.setVendorStateByGroup(t, o), k.fp.WebButtonCustomisations || this.allowAllVisible(y.setAllowAllButton()), t.IsLegIntToggle = !1
    }, r.prototype.toggleGroupStatus = function(e, t) {
        var o;
        D.requireSignatureEnabled && e.needsHealthSignature ? (o = !1, t ? (D.healthSignatureData && (o = !0), D.healthSignatureGroup = e) : D.healthSignatureGroup = null, y.toggleGrpStatus(e, o)) : y.toggleGrpStatus(e, t)
    }, r.prototype.updateSubGroupToggles = function(e, t, o) {
        Io.toggleGroupHosts(e, t), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(e, t);
        var n = L.getGroupById(e.Parent),
            o = (e.IsLegIntToggle = o, n.IsLegIntToggle = e.IsLegIntToggle, y.isGroupActive(n));
        t ? (y.toggleGrpStatus(e, !0), y.isAllSubgroupsEnabled(n) && !o && (y.toggleGrpStatus(n, !0), Io.toggleGroupHosts(n, t), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(n, t), y.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), !0))) : (y.toggleGrpStatus(e, !1), y.isAllSubgroupsDisabled(n) && o ? (y.toggleGrpStatus(n, !1), Io.toggleGroupHosts(n, t), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(n, t), y.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), t)) : (y.toggleGrpStatus(n, !1), Io.toggleGroupHosts(n, !1), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(n, t), y.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), !1))), this.allowAllVisible(y.setAllowAllButton()), e.IsLegIntToggle = !1, n.IsLegIntToggle = e.IsLegIntToggle
    }, r.prototype.hideCategoryContainer = function(e) {
        this.isCookieList = e = void 0 === e ? !1 : e, u.addHideClassContainer(), w.showVendorService ? mr.setHeaderConfig() : (e ? u.setCookieListTemplate() : u.setVendorListTemplate(), sr.setFilterList(e))
    }, r.prototype.setCookieListTemplate = function() {
        var e = k.isV2Template;
        m(T.P_Vendor_List + " #select-all-text-container").show(this.inlineBlockDisplay), m("#onetrust-pc-sdk " + T.P_Host_Cntr).show(), h.isOptOutEnabled() ? m("#onetrust-pc-sdk #" + T.P_Sel_All_Host_El).show(this.inlineBlockDisplay) : m("#onetrust-pc-sdk #" + T.P_Sel_All_Host_El).hide(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).hide(), m("#onetrust-pc-sdk " + T.P_Leg_Header).hide(), e || m("#onetrust-pc-sdk " + T.P_Leg_Select_All).hide(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Consent_El).hide(), m("#onetrust-pc-sdk  " + T.P_Vendor_Container).hide(), (N.UseGoogleVendors || w.showGeneralVendors) && m("#onetrust-pc-sdk .ot-acc-cntr").hide(), m("#onetrust-pc-sdk " + T.P_Vendor_List).addClass(T.P_Host_UI), m("#onetrust-pc-sdk " + T.P_Vendor_Content).addClass(T.P_Host_Cnt)
    }, r.prototype.setVendorListTemplate = function() {
        m("#onetrust-pc-sdk " + T.P_Vendor_Container).show(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Consent_El).show(this.inlineBlockDisplay), N.UseGoogleVendors && m("#onetrust-pc-sdk .ot-acc-cntr").show(), D.legIntSettings.PAllowLI && D.isIab2orv2Template ? (m("#onetrust-pc-sdk " + T.P_Select_Cntr).show(k.isV2Template ? void 0 : this.inlineBlockDisplay), m("#onetrust-pc-sdk " + T.P_Leg_Select_All).show(this.inlineBlockDisplay), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).show(this.inlineBlockDisplay), m(T.P_Vendor_List + " #select-all-text-container").show(this.inlineBlockDisplay), D.legIntSettings.PShowLegIntBtn ? (m("#onetrust-pc-sdk " + T.P_Leg_Header).hide(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).hide()) : m("#onetrust-pc-sdk " + T.P_Leg_Header).show()) : (m("#onetrust-pc-sdk " + T.P_Select_Cntr).show(), m(T.P_Vendor_List + " #select-all-text-container").show(this.inlineBlockDisplay), m("#onetrust-pc-sdk " + T.P_Leg_Select_All).show(this.inlineBlockDisplay), m("#onetrust-pc-sdk " + T.P_Leg_Header).hide(), m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).hide()), m("#onetrust-pc-sdk #" + T.P_Sel_All_Host_El).hide(), m("#onetrust-pc-sdk " + T.P_Host_Cntr).hide(), m("#onetrust-pc-sdk " + T.P_Vendor_List).removeClass(T.P_Host_UI), m("#onetrust-pc-sdk " + T.P_Vendor_Content).removeClass(T.P_Host_Cnt)
    }, r.prototype.showAllVendors = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, u.fetchAndSetupPC()];
                    case 1:
                        return e.sent(), u.showVendorsList(null, !0), w.isPCVisible ? [3, 3] : [4, u.showCookieSettingsHandler(t)];
                    case 2:
                        e.sent(), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, r.prototype.fetchAndSetupPC = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return k.moduleInitializer.IsSuppressPC && 0 === m("" + u.PC_SELECTOR).length ? [4, Yt.getPcContent()] : [3, 2];
                    case 1:
                        t = e.sent(), js.preferenceCenterGroup = {
                            name: t.name,
                            html: atob(t.html),
                            css: t.css
                        }, k.isV2Template = N.PCTemplateUpgrade && /otPcPanel|otPcCenter|otPcTab/.test(t.name), (t = document.getElementById("onetrust-style")).innerHTML = S.getInnerHtmlContent(t.innerHTML + js.preferenceCenterGroup.css), t.innerHTML = S.getInnerHtmlContent(t.innerHTML + No.addCustomPreferenceCenterCSS()), _.insertPcHtml(), u.initialiseConsentNoticeHandlers(), N.IsIabEnabled && C.InitializeVendorList(), e.label = 2;
                    case 2:
                        return 0 !== m("" + u.PC_SELECTOR).length && N.PCTemplateUpgrade && ((t = document.querySelector("#onetrust-pc-sdk .ot-optout-signal")).querySelector("span").innerText = h.getOptOutSignalText(!0), _.setOptOutSignalVisibility(t)), [2]
                }
            })
        })
    }, r.prototype.setVendorContent = function() {
        m("" + u.FILTER_COUNT_SELECTOR).text(w.filterByIABCategories.length.toString()), C.loadVendorList("", w.filterByIABCategories), N.UseGoogleVendors && (w.vendorDomInit ? C.resetAddtlVendors() : (C.initGoogleVendors(), m("" + u.PC_SELECTOR).on("click", ".ot-acc-cntr > button", u.toggleAccordionStatus.bind(this)))), w.vendorDomInit || (w.vendorDomInit = !0, u.initialiseLegIntBtnHandlers(), N.UseGoogleVendors && (u.initialiseAddtlVenHandler(), u.bindSelAllHandlers())), w.showGeneralVendors && !w.genVendorDomInit && (w.genVendorDomInit = !0, C.initGenVendors(), u.initializeGenVenHandlers(), N.UseGoogleVendors || (u.bindSelAllHandlers(), m("" + u.PC_SELECTOR).on("click", ".ot-acc-cntr > button", u.toggleAccordionStatus.bind(this))))
    }, r.prototype.addEventAdditionalTechnologies = function() {
        var e = document.querySelectorAll("#onetrust-pc-sdk .ot-acc-cntr.ot-add-tech > button");
        0 < e.length && (m(e).off("click", u.toggleAccordionStatus), m(e).on("click", u.toggleAccordionStatus))
    }, r.prototype.showVendorsList = function(e, t) {
        return void 0 === t && (t = !1), w.cookieListType = null, u.hideCategoryContainer(!1), Ro.addOTCssPropertiesToBody(Ho.PC, {}), w.showVendorService ? mr.showVSList() : (t || (t = e.getAttribute("data-parent-id")) && (t = L.getGroupById(t)) && (t = U(t.SubGroups, [t]).reduce(function(e, t) {
            return -1 < Dt.indexOf(t.Type) && e.push(t.CustomGroupId), e
        }, []), w.filterByIABCategories = U(w.filterByIABCategories, t)), u.setVendorContent(), on.updateFilterSelection(!1)), w.pcLayer = se.VendorList, e && Vo.setPCFocus(Vo.getPCElements()), this.setSearchInputFocus(), !1
    }, r.prototype.showIllustrations = function(e) {
        e = e.getAttribute("data-parent-id"), e = L.getGroupById(e);
        w.cookieListType = null, w.pcLayer = se.IabIllustrations, u.addHideClassContainer(), pr.showIllustrations(e.GroupName, e.IabIllustrations), Vo.setPCFocus(Vo.getPCElements())
    }, r.prototype.addHideClassContainer = function() {
        var e = D.pcName;
        N.PCTemplateUpgrade ? m("#onetrust-pc-sdk " + T.P_Content).addClass("ot-hide") : m("#onetrust-pc-sdk .ot-main-content").hide(), m("#onetrust-pc-sdk " + T.P_Vendor_List).removeClass("ot-hide"), e !== st && e !== rt && m("#onetrust-pc-sdk #close-pc-btn-handler.main").hide(), e === rt && Ht(m("" + u.PC_SELECTOR).el[0], 'height: "";', !0)
    }, r.prototype.loadCookieList = function(e) {
        w.filterByCategories = [], u.hideCategoryContainer(!0);
        var t, e = e && e.getAttribute("data-parent-id");
        return e && (t = L.getGroupById(e), w.filterByCategories.push(e), t.SubGroups.length) && t.SubGroups.forEach(function(e) {
            -1 === Dt.indexOf(e.Type) && (e = e.CustomGroupId, w.filterByCategories.indexOf(e) < 0) && w.filterByCategories.push(e)
        }), C.loadHostList("", w.filterByCategories), w.showTrackingTech && u.addEventAdditionalTechnologies(), m("" + u.FILTER_COUNT_SELECTOR).text(w.filterByCategories.length.toString()), on.updateFilterSelection(!0), w.pcLayer = se.CookieList, Vo.setPCFocus(Vo.getPCElements()), this.setSearchInputFocus(), !1
    }, r.prototype.selectAllVendorsLegIntHandler = function(e) {
        var t = m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Leg_El).el[0],
            o = t.classList.contains("line-through"),
            n = m(T.P_Vendor_Container + ' li:not([style="display: none;"]) .vendor-leg-checkbox-handler').el,
            r = e.target.checked,
            i = {};
        w.vendors.selectedLegIntVendors.map(function(e, t) {
            i[e.split(":")[0]] = t
        });
        for (var s = 0; s < n.length; s++) {
            v.setCheckedAttribute(null, n[s], r), N.PCShowConsentLabels && (n[s].parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(r ? N.PCActiveText : N.PCInactiveText));
            var a = n[s].getAttribute("leg-vendorid"),
                l = i[a];
            void 0 === l && (l = a), w.vendors.selectedLegIntVendors[l] = a + ":" + r
        }
        o && t.classList.remove("line-through"), v.setCheckedAttribute(null, e.target, r), v.setAriaCheckedAttribute(null, e.target, r)
    }, r.prototype.selAllAdtlVenHandler = function(e) {
        if ("true" === e.target.getAttribute(this.AriaDisabled)) e.preventDefault(), e.stopPropagation();
        else {
            for (var t = m("#onetrust-pc-sdk #ot-selall-adtlvencntr").el[0], o = t.classList.contains("line-through"), n = m("#onetrust-pc-sdk .ot-addtlven-chkbox-handler").el, r = e.target.checked, i = 0; i < n.length; i++) v.setCheckedAttribute(null, n[i], r), N.PCShowConsentLabels && (n[i].parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(r ? N.PCActiveText : N.PCInactiveText));
            r ? N.UseGoogleVendors && Object.keys(w.addtlVendorsList).forEach(function(e) {
                w.addtlVendors.vendorSelected[e] = !0
            }) : w.addtlVendors.vendorSelected = {}, o && t.classList.remove("line-through")
        }
    }, r.prototype.selectAllGenVenHandler = function(e) {
        var t;
        "true" === e.target.getAttribute(this.AriaDisabled) ? (e.preventDefault(), e.stopPropagation()) : (t = e.target.checked, u.selectAllHandler({
            selAllEl: "#onetrust-pc-sdk #ot-selall-gnvencntr",
            vendorBoxes: "#onetrust-pc-sdk .ot-gnven-chkbox-handler"
        }, "genven", t), v.setCheckedAttribute(null, e.target, t), v.setAriaCheckedAttribute(null, e.target, t))
    }, r.prototype.selectAllHandler = function(e, t, o) {
        for (var n = m(e.selAllEl).el[0], r = n.classList.contains("line-through"), i = m(e.vendorBoxes).el, s = 0; s < i.length; s++) "genven" === t && !o && w.alwaysActiveGenVendors.includes(i[s].getAttribute("gn-vid")) ? (v.setDisabledAttribute(null, i[s], !0), v.setCheckedAttribute(null, i[s], !0)) : v.setCheckedAttribute(null, i[s], o), N.PCShowConsentLabels && (i[s].parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(o ? N.PCActiveText : N.PCInactiveText));
        o ? "googleven" === t && N.UseGoogleVendors ? Object.keys(w.addtlVendorsList).forEach(function(e) {
            w.addtlVendors.vendorSelected[e] = !0
        }) : "genven" === t && w.showGeneralVendors && N.GeneralVendors.forEach(function(e) {
            w.genVendorsConsent[e.VendorCustomId] = !0
        }) : "googleven" === t ? w.addtlVendors.vendorSelected = {} : (w.genVendorsConsent = {}, w.alwaysActiveGenVendors.forEach(function(e) {
            w.genVendorsConsent[e] = !0
        })), r && n.classList.remove("line-through")
    }, r.prototype.SelectAllVendorConsentHandler = function(e) {
        var t = e.target.checked;
        if (w.showVendorService) mr.toggleVendors(t);
        else {
            var o = m("#onetrust-pc-sdk #" + T.P_Sel_All_Vendor_Consent_El).el[0],
                n = o.classList.contains("line-through"),
                r = m(T.P_Vendor_Container + ' li:not([style="display: none;"]) .vendor-checkbox-handler').el,
                i = {};
            w.vendors.selectedVendors.map(function(e, t) {
                i[e.split(":")[0]] = t
            });
            for (var s = 0; s < r.length; s++) {
                v.setCheckedAttribute(null, r[s], t), N.PCShowConsentLabels && (r[s].parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(t ? N.PCActiveText : N.PCInactiveText));
                var a = r[s].getAttribute("vendorid"),
                    l = i[a];
                void 0 === l && (l = a), w.vendors.selectedVendors[l] = a + ":" + t
            }
            n && o.classList.remove("line-through")
        }
        v.setCheckedAttribute(null, e.target, t), v.setAriaCheckedAttribute(null, e.target, t)
    }, r.prototype.onVendorToggle = function(o, e) {
        var t = w.vendors,
            n = w.addtlVendors,
            r = e === de.LI ? t.selectedLegIntVendors : e === de.AddtlConsent ? [] : t.selectedVendors,
            i = !1,
            s = Number(o);
        r.some(function(e, t) {
            e = e.split(":");
            if (e[0] === o) return s = t, i = "true" === e[1], !0
        }), e === de.LI ? (uo.triggerGoogleAnalyticsEvent(fn, i ? Fn : Mn, t.list.find(function(e) {
            return e.vendorId === o
        }).vendorName + ": " + b.IdPatterns.Pur + o), t.selectedLegIntVendors[s] = o + ":" + !i, D.legIntSettings.PShowLegIntBtn || C.vendorLegIntToggleEvent()) : e === de.AddtlConsent ? (n.vendorSelected[o] ? delete n.vendorSelected[o] : n.vendorSelected[o] = !0, C.venAdtlSelAllTglEvent()) : (uo.triggerGoogleAnalyticsEvent(fn, i ? Rn : Hn, t.list.find(function(e) {
            return e.vendorId === o
        }).vendorName + ": " + b.IdPatterns.Pur + o), t.selectedVendors[s] = o + ":" + !i, C.vendorsListEvent())
    }, r.prototype.onVendorDisclosure = function(r) {
        var i;
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = w.discVendors)[r].isFetched ? [3, 4] : (t[r].isFetched = !0, o = t[r].disclosureUrl, n = void 0, null != (i = k.moduleInitializer) && i.DisclosureCDNUrl ? (o = k.moduleInitializer.DisclosureCDNUrl + "/" + r + ".json", [4, Yt.getStorageDisclosure(o)]) : [3, 2]);
                    case 1:
                        if (n = e.sent()) return [2, C.updateVendorDisclosure(r, n)];
                        o = t[r].disclosureUrl, e.label = 2;
                    case 2:
                        return [4, Yt.getStorageDisclosure(o)];
                    case 3:
                        return n = e.sent(), [2, C.updateVendorDisclosure(r, n)];
                    case 4:
                        return [2]
                }
            })
        })
    }, r.prototype.tglFltrOptionHandler = function(e) {
        e && e.target.classList.contains("category-filter-handler") && v.setCheckedAttribute(null, e.target, e.target.checked)
    }, r.prototype.selectVendorsGroupHandler = function(e) {
        u.toggleAccordionStatus(e);
        var t = e.target.getAttribute("leg-vendorid"),
            o = e.target.getAttribute("vendorid"),
            n = e.target.getAttribute("addtl-vid"),
            r = e.target.getAttribute("disc-vid");
        t ? u.onVendorToggle(t, de.LI) : o ? u.onVendorToggle(o, de.Consent) : n && u.onVendorToggle(n, de.AddtlConsent), r && u.onVendorDisclosure(r), (t || o || n) && (v.setCheckedAttribute(null, e.target, e.target.checked), N.PCShowConsentLabels) && (e.target.parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(e.target.checked ? N.PCActiveText : N.PCInactiveText))
    }, r.prototype.toggleVendorFiltersHandler = function() {
        var e, t = !1,
            o = m("#onetrust-pc-sdk " + T.P_Fltr_Modal).el[0];
        switch (D.pcName) {
            case it:
            case nt:
            case rt:
            case at:
                (t = "block" === o.style.display) ? (u.closeFilter(), u.setFilterButtonExpanded(!1)) : (e = m("#onetrust-pc-sdk " + T.P_Triangle).el[0], m(e).attr("style", "display: block;"), m(o).attr("style", "display: block;"), e = Array.prototype.slice.call(o.querySelectorAll("[href], input, button")), Vo.setPCFocus(e), u.setFilterButtonExpanded(!0));
                break;
            case st:
                896 < window.innerWidth || 896 < window.screen.height ? Ht(o, "width: 400px;", !0) : Ht(o, "height: 100%; width: 100%;"), o.querySelector(".ot-checkbox input").focus();
                break;
            default:
                return
        }
        k.isV2Template && !t && (m("#onetrust-pc-sdk").addClass("ot-shw-fltr"), m("#onetrust-pc-sdk .ot-fltr-scrlcnt").el[0].scrollTop = 0)
    }, r.prototype.clearFiltersHandler = function() {
        u.setAriaLabelforButtonInFilter(N.PCenterFilterClearedAria);
        for (var e = m("#onetrust-pc-sdk " + T.P_Fltr_Modal + " input").el, t = 0; t < e.length; t++) v.setCheckedAttribute(null, e[t], !1);
        u.syncFilterAriaSelected(), u.isCookieList ? w.filterByCategories = [] : w.filterByIABCategories = []
    }, r.prototype.cancelFilterHandler = function() {
        w.showVendorService ? mr.cancelFilter() : u.isCookieList ? on.cancelHostFilter() : C.cancelVendorFilter(), u.syncFilterAriaSelected(), u.closeFilter(), u.focusFilterButton()
    }, r.prototype.syncFilterAriaSelected = function() {
        document.querySelectorAll("#onetrust-pc-sdk " + T.P_Fltr_Modal + " " + T.P_Fltr_Option).forEach(function(e) {
            var t = e.querySelector("input");
            t && e.setAttribute(u.AriaSelected, String(t.checked))
        })
    }, r.prototype.applyFilterHandler = function() {
        var e;
        u.setAriaLabelforButtonInFilter(N.PCenterFilterAppliedAria), w.showVendorService ? (e = mr.getGroupsFilter(), mr.filterVendorByGroup(e)) : u.isCookieList ? (e = on.updateHostFilterList(), C.loadHostList("", e), w.showTrackingTech && u.addEventAdditionalTechnologies()) : (e = C.updateVendorFilterList(), C.loadVendorList("", e)), m("" + u.FILTER_COUNT_SELECTOR).text(String(e.length)), u.closeFilter(), u.focusFilterButton(), C.playSearchStatus(u.isCookieList)
    }, r.prototype.setAriaLabelforButtonInFilter = function(e) {
        var t = w.isPCVisible ? document.querySelector("#onetrust-pc-sdk span[aria-live]") : document.querySelector("#onetrust-banner-sdk span[aria-live]");
        if (!t) {
            (t = document.createElement("span")).classList.add("ot-scrn-rdr"), t.setAttribute("aria-atomic", "true");
            var o = void 0;
            if (w.isPCVisible ? o = document.getElementById(u.pcSDKSelector) : document.getElementById(u.bannerSelector) && (o = document.getElementById(u.bannerSelector)), !o) return;
            o.appendChild(t)
        }
        t.setAttribute("aria-atomic", "true"), t.setAttribute("aria-relevant", "additions"), t.setAttribute("aria-live", "assertive"), t.setAttribute(vt, e), u.timeCallback && clearTimeout(u.timeCallback), u.timeCallback = setTimeout(function() {
            u.timeCallback = null, t.setAttribute(vt, "")
        }, 900)
    }, r.prototype.setPcListContainerHeight = function() {
        m("#onetrust-pc-sdk " + T.P_Content).el[0].classList.contains("ot-hide") ? Ht(m("" + u.PC_SELECTOR).el[0], 'height: "";', !0) : setTimeout(function() {
            var e = window.innerHeight;
            768 <= window.innerWidth && 600 <= window.innerHeight && (e = .8 * window.innerHeight), !m("#onetrust-pc-sdk " + T.P_Content).el[0].scrollHeight || m("#onetrust-pc-sdk " + T.P_Content).el[0].scrollHeight >= e ? Ht(m("" + u.PC_SELECTOR).el[0], "height: " + e + "px;", !0) : Ht(m("" + u.PC_SELECTOR).el[0], "height: auto;", !0)
        })
    }, r.prototype.changeSelectedTab = function(e) {
        var t, o = m("#onetrust-pc-sdk .category-menu-switch-handler"),
            n = 0,
            r = m(o.el[0]);
        o.each(function(e, t) {
            m(e).el.classList.contains(T.P_Active_Menu) && (n = t, m(e).el.classList.remove(T.P_Active_Menu), r = m(e))
        }), e.keyCode === ae.DownArrow ? t = n + 1 >= o.el.length ? m(o.el[0]) : m(o.el[n + 1]) : e.keyCode === ae.UpArrow && (t = m(n - 1 < 0 ? o.el[o.el.length - 1] : o.el[n - 1])), this.tabMenuToggle(t, r)
    }, r.prototype.changeSelectedTabV2 = function(e) {
        var t, o = e.target.parentElement,
            e = (e.keyCode === ae.DownArrow ? t = o.nextElementSibling || o.parentElement.firstChild : e.keyCode === ae.UpArrow && (t = o.previousElementSibling || o.parentElement.lastChild), t.querySelector(".category-menu-switch-handler"));
        e.focus(), this.groupTabClick(e)
    }, r.prototype.categoryMenuSwitchHandler = function() {
        for (var o = this, e = m("#onetrust-pc-sdk .category-menu-switch-handler").el, n = this, t = 0; t < e.length; t++)(t => {
            e[t].addEventListener("click", n.groupTabClick), e[t].addEventListener("keydown", function(e) {
                if (1 <= t && e.shiftKey && 9 === e.keyCode && !N.ShowPreferenceCenterCloseButton && N.PCLayout.Tab && (e.preventDefault(), Vo.lastItem.focus()), 32 === e.keyCode || "space" === e.code) return o.groupTabClick(e.currentTarget), e.preventDefault(), !1
            })
        })(t)
    }, r.prototype.groupTabClick = function(e) {
        var t = m("#onetrust-pc-sdk " + T.P_Grp_Container).el[0],
            o = t.querySelector("." + T.P_Active_Menu),
            e = e.currentTarget || e,
            n = e.getAttribute("aria-controls");
        o.setAttribute("tabindex", -1), o.setAttribute(u.AriaSelected, !1), o.classList.remove(T.P_Active_Menu), t.querySelector(T.P_Desc_Container + ":not(.ot-hide)").classList.add("ot-hide"), t.querySelector("#" + n).classList.remove("ot-hide"), e.setAttribute("tabindex", 0), e.setAttribute(u.AriaSelected, !0), e.classList.add(T.P_Active_Menu)
    }, r.prototype.tabMenuToggle = function(e, t) {
        e.el.setAttribute("tabindex", 0), e.el.setAttribute(u.AriaSelected, !0), t.el.setAttribute("tabindex", -1), t.el.setAttribute(u.AriaSelected, !1), e.focus(), t.el.parentElement.parentElement.querySelector("" + T.P_Desc_Container).classList.add("ot-hide"), e.el.parentElement.parentElement.querySelector("" + T.P_Desc_Container).classList.remove("ot-hide"), e.el.classList.add(T.P_Active_Menu)
    }, r.prototype.closeFilter = function(e) {
        var t, o;
        void 0 === e && (e = !0), Jo.checkIfPcSdkContainerExist() || (t = m("#onetrust-pc-sdk " + T.P_Fltr_Modal).el[0], o = m("#onetrust-pc-sdk " + T.P_Triangle).el[0], D.pcName === st ? 896 < window.innerWidth || 896 < window.screen.height ? Ht(t, "width: 0;", !0) : Ht(t, "height: 0;") : Ht(t, "display: none;"), o && m(o).attr("style", "display: none;"), k.isV2Template && m("#onetrust-pc-sdk").removeClass("ot-shw-fltr"), e && Vo.setFirstAndLast(Vo.getPCElements()))
    }, r.prototype.setBackButtonFocus = function() {
        m("#onetrust-pc-sdk .back-btn-handler").el[0].focus()
    }, r.prototype.setSearchInputFocus = function() {
        m(u.VENDOR_SEARCH_SELECTOR).el[0].focus()
    }, r.prototype.setCenterLayoutFooterHeight = function() {
        var e = u.pc;
        if (D.pcName === at && e) {
            var t = e.querySelectorAll("" + T.P_Desc_Container),
                o = e.querySelectorAll("li .category-menu-switch-handler");
            if (!e.querySelector(".category-menu-switch-handler + " + T.P_Desc_Container) && window.innerWidth <= 640)
                for (var n = 0; n < t.length; n++) o[n].insertAdjacentElement("afterend", t[n]);
            else e.querySelector(".category-menu-switch-handler + " + T.P_Desc_Container) && 640 < window.innerWidth && m(e.querySelector(".ot-tab-desc")).append(t)
        }
        u.pcCenterAndTabCheckButtonsOrderSizes(), u.setPanelLayoutButtonsSize(), u.setMainContentHeight()
    }, r.prototype.pcCenterAndTabCheckButtonsOrderSizes = function() {
        var e, t, o, n, r;
        N.PCTemplateUpgrade && k.fp.WebButtonCustomisations && (D.pcName === nt || D.pcName === at) && (window.innerWidth <= 500 || 20 < (null == (e = N.ConfirmText) ? void 0 : e.length) || 20 < (null == (e = N.AllowAllText) ? void 0 : e.length) || 20 < (null == (e = N.PCenterRejectAllButtonText) ? void 0 : e.length) ? u.stackButtons() : (e = document.querySelector(u.PC_SELECTOR), t = document.querySelector(u.PC_FOOTER), o = document.querySelector(u.otPcContainerSelector), n = document.querySelector("#ot-pc-lst"), null != (r = t) && r.style.setProperty("height", "auto"), r = dt, null != (e = null == (e = e) ? void 0 : e.classList) && e.contains("ot-ftr-stacked") && (r = ct), null != (e = t) && e.style.setProperty(Ct, r + "px"), null != (t = o) && t.style.setProperty(Ct, r + "px"), null != (e = n) && e.style.setProperty(Ct, r + "px")))
    }, r.prototype.setPanelLayoutButtonsSize = function() {
        var e, t, o, n, r;
        N.PCTemplateUpgrade && k.fp.WebButtonCustomisations && D.pcName === it && (o = document.querySelector(".ot-btn-container.ot-button-order-container")) && (t = (null == (t = o.children) ? void 0 : t.length) * ct / 3, t = Math.max(ut, Math.min(ct, t)), o.classList.contains("ot-hide") && (t = Math.min(pt, t)), o = document.querySelector(".ot-pc-footer"), n = document.querySelector("#ot-pc-lst"), r = document.querySelector(u.otPcContainerSelector), null != (e = o) && e.style.setProperty("height", "100%"), null != (e = o) && e.style.setProperty("display", "flex"), null != (e = o) && e.style.setProperty("flex-direction", "column"), null != (e = o) && e.style.setProperty(Ct, t + "px"), null != (o = r) && o.style.setProperty(Ct, t + "px"), null != (e = n)) && e.style.setProperty(Ct, t + "px")
    }, r.prototype.stackButtons = function() {
        var e, t = document.querySelector(u.PC_FOOTER),
            o = document.querySelector(u.otPcContainerSelector),
            n = document.querySelector("#ot-pc-lst"),
            r = document.querySelector(".ot-btn-container.ot-button-order-container");
        r && (e = (null == (e = r) ? void 0 : e.children.length) * ct / 3, e = Math.max(ut, Math.min(ct, e)), r.classList.contains("ot-hide") && (e = Math.min(pt, e)), null != (r = t) && r.style.setProperty("height", "100%"), null != (r = t) && r.style.setProperty(Ct, e + "px"), null != (t = o) && t.style.setProperty(Ct, e + "px"), null != (r = n)) && r.style.setProperty(Ct, e + "px")
    }, r.prototype.setMainContentHeight = function() {
        var e, t = this.pc,
            o = t.querySelector(u.PC_FOOTER),
            n = t.querySelector(".ot-pc-header"),
            r = N.PCLayout,
            i = (u.toggleFtrStackedClass(t), N.PCTemplateUpgrade || r.Center || (e = t.clientHeight - o.clientHeight - n.clientHeight - 3, N.PCTemplateUpgrade && !r.Tab && N.PCenterVendorListDescText && (e = e - ((i = m("#vdr-lst-dsc").el).length && i[0].clientHeight) - 10), Ht(t.querySelector("" + T.P_Vendor_List), "height: " + e + "px;", !0)), t.querySelector("" + T.P_Content));
        N.PCTemplateUpgrade && r.Center ? (e = 600 < window.innerWidth && 475 < window.innerHeight, !this.pcBodyHeight && e && (this.pcBodyHeight = i.scrollHeight), e ? (i = this.pcBodyHeight + o.clientHeight + n.clientHeight + 20) > .8 * window.innerHeight || 0 === this.pcBodyHeight ? Ht(t, "height: " + .8 * window.innerHeight + "px;", !0) : Ht(t, "height: " + i + "px;", !0) : Ht(t, "height: 95%;", !0)) : this.setPCContentAndListHeight(t, r)
    }, r.prototype.toggleFtrStackedClass = function(e) {
        var t = e.querySelectorAll(".ot-pc-footer button"),
            t = Array.from(t).filter(function(e) {
                return "none" !== getComputedStyle(e).display
            }),
            o = t[t.length - 1];
        e.classList.remove("ot-ftr-stacked"), t[0] && o && o.offsetTop > t[0].offsetTop + 1 && e.classList.add("ot-ftr-stacked")
    }, r.prototype.setPCContentAndListHeight = function(e, t) {
        var o = e.querySelector(u.PC_FOOTER),
            n = e.querySelector(".ot-pc-header"),
            r = e.querySelector("#ot-pc-lst");
        Ht(e.querySelector("" + T.P_Content), "height: " + (e.clientHeight - o.clientHeight - n.clientHeight - 3) + "px;", !0), t.Tab && Ht(r, "height: " + (e.clientHeight - o.clientHeight - n.clientHeight - 3) + "px;", !0)
    }, r.prototype.allowAllVisible = function(e) {
        e !== this.allowVisible && N.PCLayout.Tab && N.PCTemplateUpgrade && (this.pc && this.setMainContentHeight(), this.allowVisible = e)
    }, r.prototype.restorePc = function() {
        w.pcLayer === se.CookieList ? (u.hideCategoryContainer(!0), C.loadHostList("", w.filterByCategories), w.showTrackingTech && u.addEventAdditionalTechnologies(), m("" + u.FILTER_COUNT_SELECTOR).text(w.filterByCategories.length.toString())) : w.pcLayer === se.VendorList && (u.hideCategoryContainer(!1), u.setVendorContent()), w.isPCVisible = !1, u.toggleInfoDisplay(), w.pcLayer !== se.VendorList && w.pcLayer !== se.CookieList || (on.updateFilterSelection(w.pcLayer === se.CookieList), u.setBackButtonFocus(), Vo.setPCFocus(Vo.getPCElements()))
    }, r.prototype.toggleInfoDisplay = function() {
        var n;
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return !w.isPCVisible && h.isBannerVisible() && (w.wasBannerVisible = !0), js.csBtnGroup && (m(u.fltgBtnSltr).addClass("ot-pc-open"), u.otGuardLogoPromise.then(function() {
                            N.cookiePersistentLogo.includes("ot_guard_logo.svg") && m(u.fltgBtnFSltr).attr(Tt, "true")
                        }), m(u.fltgBtnBSltr).attr(Tt, ""), m(u.fltgBtnBackBtn).el[0].style.display = "block"), [4, u.fetchAndSetupPC()];
                    case 1:
                        return e.sent(), D.pcName === rt && this.setPcListContainerHeight(), void 0 !== w.pcLayer && w.pcLayer !== se.Banner || (w.pcLayer = se.PrefCenterHome), t = m("" + u.PC_SELECTOR).el[0], m(".onetrust-pc-dark-filter").el[0].removeAttribute("style"), t.removeAttribute("style"), w.isPCVisible || (Jo.showConsentNotice(), w.isPCVisible = !0, o = document.querySelector(u.otPcContainerSelector), null != (n = o) && n.setAttribute("tabindex", "-1"), N.PCTemplateUpgrade && (this.pc = t, o = t.querySelector("#accept-recommended-btn-handler"), this.allowVisible = o && 0 < o.clientHeight, this.setCenterLayoutFooterHeight(), u.getResizeElement().addEventListener("resize", u.setCenterLayoutFooterHeight), window.addEventListener("resize", u.setCenterLayoutFooterHeight)), m(document).on("keydown", u.closePCWhenEscPressed)), window.dispatchEvent(new CustomEvent("OneTrustPCLoaded", {
                            OneTrustPCLoaded: "yes"
                        })), u.captureInitialConsent(), D.requireSignatureEnabled && $n.getInstance().setConsentIdInPC(), [2]
                }
            })
        })
    }, r.prototype.close = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return N.BCloseButtonType === Ae.Link ? w.bannerCloseSource = ee.ContinueWithoutAcceptingButton : w.bannerCloseSource = ee.BannerCloseButton, [4, g.bannerCloseButtonHandler(t)];
                    case 1:
                        return e.sent(), Ro.removeAddedOTCssStyles(), u.getResizeElement().removeEventListener("resize", u.setCenterLayoutFooterHeight), window.removeEventListener("resize", u.setCenterLayoutFooterHeight), [2]
                }
            })
        })
    }, r.prototype.closePreferenceCenter = function(e) {
        e && e.preventDefault(), window.location.href = "https://otsdk//consentChanged"
    }, r.prototype.initializeAlartHtmlAndHandler = function() {
        w.skipAddingHTML = 0 < m("#onetrust-banner-sdk").length, w.skipAddingHTML || yr.insertAlertHtml(), this.initialiseAlertHandlers(), Vo.setBannerFocus()
    }, r.prototype.initialiseAlertHandlers = function() {
        var e = this,
            t = (yr.showBanner(), !N.ShowAlertNotice || B.isAlertBoxClosedAndValid() || N.NoBanner || w.hideBanner),
            o = h.isCookiePolicyPage(N.MainInfoText),
            t = (t && o ? m(".onetrust-pc-dark-filter").addClass("ot-hide") : N.ForceConsent && !h.isCookiePolicyPage(N.AlertNoticeText) && m(".onetrust-pc-dark-filter").removeClass("ot-hide").css("z-index:2147483645;"), N.OnClickCloseBanner && document.body.addEventListener("click", g.bodyClickEvent), N.ScrollCloseBanner && (window.addEventListener("scroll", g.scrollCloseBanner), m(document).on("click", ".onetrust-close-btn-handler", g.rmScrollAndClickBodyEvents), m(document).on("click", "#onetrust-accept-btn-handler", g.rmScrollAndClickBodyEvents), m(document).on("click", "#accept-recommended-btn-handler", g.rmScrollAndClickBodyEvents)), this.addEventListnerForVendorsList(), N.FloatingRoundedIcon && m("#onetrust-banner-sdk #onetrust-cookie-btn").on("click", function(e) {
                w.pcSource = e.currentTarget, u.showCookieSettingsHandler(e)
            }), m("#onetrust-banner-sdk .onetrust-close-btn-handler").on("click", function(e) {
                setTimeout(function() {
                    $n.getInstance().resetHealthSignatureData(), u.bannerCloseButtonHandler(e)
                }, 0)
            }), m("#onetrust-banner-sdk .ot-bnr-save-handler").on("click", u.bannerCloseButtonHandler), m("#onetrust-banner-sdk #onetrust-pc-btn-handler").on("click", function(e) {
                setTimeout(function() {
                    u.showCookieSettingsHandler(e)
                }, 0)
            }), m("#onetrust-banner-sdk #onetrust-accept-btn-handler").on("click", function() {
                setTimeout(function() {
                    g.allowAllEventHandler(!1)
                }, 0)
            }), m("#onetrust-banner-sdk #onetrust-reject-all-handler").on("click", function() {
                setTimeout(function() {
                    g.rejectAllEventHandler(!1)
                }, 0)
            }), m("#onetrust-banner-sdk .banner-option-input").on("click", D.bannerName === $e ? u.toggleBannerOptions : u.toggleAccordionStatus), m("#onetrust-banner-sdk .ot-gv-list-handler").on("click", function(t) {
                return F(e, void 0, void 0, function() {
                    return M(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return w.cookieListType = ye.GenVen, [4, u.fetchAndSetupPC()];
                            case 1:
                                return e.sent(), u.loadCookieList(t.target), u.showCookieSettingsHandler(t), [2]
                        }
                    })
                })
            }), m("#onetrust-banner-sdk .category-switch-handler").on("click", u.toggleBannerCategory), document.getElementById("onetrust-banner-sdk"));
        N.ForceConsent && t && "none" !== window.getComputedStyle(t).display && m(document).on("keydown", u.shiftBannerFocus), m("#onetrust-banner-sdk").on("keydown", function(e) {
            32 !== e.keyCode && "Space" !== e.code && 13 !== e.keyCode && "Enter" !== e.code || h.findUserType(e)
        })
    }, r.prototype.addEventListnerForVendorsList = function() {
        (N.IsIabEnabled || N.UseGoogleVendors || w.showGeneralVendors) && !w.showVendorService && (document.removeEventListener("click", this.vendorsListDelegatedHandler), document.addEventListener("click", this.vendorsListDelegatedHandler))
    }, r.prototype.getResizeElement = function() {
        var e = document.querySelector("#onetrust-pc-sdk .ot-text-resize");
        return e ? e.contentWindow || e : document
    }, r.prototype.insertCookieSettingText = function(e) {
        void 0 === e && (e = !1);
        for (var t = N.CookieSettingButtonText, o = m(".ot-sdk-show-settings").el, n = m(".optanon-toggle-display").el, r = 0; r < o.length; r++) m(o[r]).text(t), m(n[r]).text(t);
        e ? (null != (e = document.querySelector(".ot-sdk-show-settings")) && e.addEventListener("click", this.cookiesSettingsBoundListener), null != (e = document.querySelector(".optanon-toggle-display")) && e.addEventListener("click", this.cookiesSettingsBoundListener)) : u.initCookieSettingHandlers()
    }, r.prototype.genVendorToggled = function(e) {
        var t, o;
        "true" === e.target.getAttribute(this.AriaDisabled) ? (e.preventDefault(), e.stopPropagation()) : (t = e.target.getAttribute("gn-vid"), mo.updateGenVendorStatus(t, e.target.checked), o = N.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        }).Name, uo.triggerGoogleAnalyticsEvent(fn, e.target.checked ? Nn : wn, o + ": VEN_" + t), C.genVenSelectAllTglEvent())
    }, r.prototype.genVendorDetails = function(e) {
        u.toggleAccordionStatus(e)
    }, r.prototype.confirmPC = function(n) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = B.isAlertBoxClosedAndValid(), N.NoBanner && N.ShowPreferenceCenterCloseButton && !t) ? (w.pcClosedFromCloseBtn || (w.bannerCloseSource = ee.ConfirmChoiceButton), [4, g.bannerCloseButtonHandler()]) : [3, 2];
                    case 1:
                        e.sent(), e.label = 2;
                    case 2:
                        return o = h.isBannerVisible(), !k.moduleInitializer.MobileSDK || !t && o || u.closePreferenceCenter(n), [2]
                }
            })
        })
    }, r.prototype.captureInitialConsent = function() {
        w.initialGroupsConsent = JSON.parse(JSON.stringify(w.groupsConsent)), w.initialHostConsent = JSON.parse(JSON.stringify(w.hostsConsent)), w.showGeneralVendors && (w.initialGenVendorsConsent = JSON.parse(JSON.stringify(w.genVendorsConsent))), N.IsIabEnabled && (w.initialOneTrustIABConsent = JSON.parse(JSON.stringify(w.oneTrustIABConsent)), w.initialVendors = JSON.parse(JSON.stringify(w.vendors)), w.initialVendors.vendorTemplate = w.vendors.vendorTemplate), N.UseGoogleVendors && (w.initialAddtlVendorsList = JSON.parse(JSON.stringify(w.addtlVendorsList)), w.initialAddtlVendors = JSON.parse(JSON.stringify(w.addtlVendors))), w.vsIsActiveAndOptOut && (w.initialVendorsServiceConsent = new Map(w.vsConsent))
    }, r.prototype.getShowCookieSettingClassName = function(e) {
        if (!e || !e.target) return "";
        var e = e.target,
            t = e.className;
        if ("BUTTON" !== e.tagName) {
            e = e.closest("button");
            if (!e) return "";
            t = e.className
        }
        return "string" != typeof t ? "" : t
    };
    var u, Ar = r;

    function r() {
        var r = this;
        this.allowVisible = !1, this.fltgBtnBackBtn = ".ot-floating-button__back button", this.fltgBtnBSltr = ".ot-floating-button__back svg", this.FILTER_BTN_SELECTOR = "#onetrust-pc-sdk #filter-btn-handler", this.ARIA_EXPANDED = "aria-expanded", this.fltgBtnFrontBtn = ".ot-floating-button__front button", this.fltgBtnFSltr = ".ot-floating-button__front svg", this.fltgBtnSltr = "#ot-sdk-btn-floating", this.PC_SELECTOR = "#onetrust-pc-sdk", this.FILTER_COUNT_SELECTOR = "#onetrust-pc-sdk #filter-count", this.VENDOR_SEARCH_SELECTOR = "#onetrust-pc-sdk #vendor-search-handler", this.PC_FOOTER = ".ot-pc-footer", this.isCookieList = !1, this.pc = null, this.currentSearchInput = "", this.pcLinkSource = null, this.pcSDKSelector = "onetrust-pc-sdk", this.bannerSelector = "onetrust-banner-sdk", this.otPcContainerSelector = "#ot-pc-content", this.AriaDisabled = "aria-disabled", this.AriaSelected = "aria-selected", this.inlineBlockDisplay = "inline-block", this.otGuardLogoResolve = null, this.otGuardLogoPromise = new Promise(function(e) {
            r.otGuardLogoResolve = e
        }), this.closePCWhenEscPressed = function(e) {
            var t, o = document.getElementById(u.pcSDKSelector);
            o && (t = "none" !== window.getComputedStyle(o).display, 27 === e.keyCode && o && t && ("block" === (o = m("#onetrust-pc-sdk " + T.P_Fltr_Modal).el[0]).style.display || "0px" < o.style.width ? (u.closeFilter(), u.focusFilterButton()) : N.NoBanner && !N.ShowPreferenceCenterCloseButton || u.hideCookieSettingsHandler(), u.confirmPC()), t && 32 === e.keyCode || "Space" === e.code || 13 === e.keyCode || "Enter" === e.code) && h.findUserType(e)
        }, this.showCookieSettingsHandler = function(n) {
            return F(r, void 0, void 0, function() {
                var t, o;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (t = document.getElementById(u.pcSDKSelector), t && "none" !== window.getComputedStyle(t).getPropertyValue("display")) ? [2] : (m(document).on("keydown", u.closePCWhenEscPressed), n && n.stopPropagation(), n && n.target && (t = this.getShowCookieSettingClassName(n), o = "onetrust-pc-btn-handler" === n.target.id, t = t.includes("ot-sdk-show-settings"), (o || t) && (t = o ? Pn : kn, uo.triggerGoogleAnalyticsEvent(fn, t)), o = n.target, w.pcSource = o.closest(".ot-sdk-show-settings, .optanon-show-settings, .optanon-toggle-display, .ot-pc-handler, #onetrust-pc-btn-handler") || n.target), [4, u.toggleInfoDisplay()]);
                        case 1:
                            return e.sent(), [2, !1]
                    }
                })
            })
        }, this.cookiesSettingsBoundListener = this.showCookieSettingsHandler.bind(this), this.backBtnHandler = function() {
            return w.pcLayer === se.IabIllustrations ? pr.hideUI() : (w.showVendorService && mr.hideVendorList(), w.showTrackingTech && (u.currentSearchInput = "")), g.hideVendorsList(), D.pcName === rt && (m("#onetrust-pc-sdk " + T.P_Content).removeClass("ot-hide"), m("" + u.PC_SELECTOR).el[0].removeAttribute("style"), r.setPcListContainerHeight()), m("" + u.FILTER_COUNT_SELECTOR).text("0"), m(u.VENDOR_SEARCH_SELECTOR).length && (m(u.VENDOR_SEARCH_SELECTOR).el[0].value = ""), w.currentGlobalFilteredList = [], w.filterByCategories = [], w.filterByIABCategories = [], w.vendors.searchParam = "", u.closeFilter(), w.pcLayer = se.PrefCenterHome, r.pcLinkSource ? (r.pcLinkSource.focus(), r.pcLinkSource = null) : Vo.setPCFocus(Vo.getPCElements()), !1
        }, this.toggleAccordionStatus = function(e) {
            var e = e.target,
                t = (null == (t = e) ? void 0 : t.closest("[aria-expanded]")) || e;
            t && null !== t.getAttribute(r.ARIA_EXPANDED) && (e = "true" === t.getAttribute(r.ARIA_EXPANDED) ? "false" : "true", t.setAttribute(r.ARIA_EXPANDED, e))
        }, this.bannerCloseBoundListener = this.bannerCloseButtonHandler.bind(this), this.toggleGroupORVendorHandler = function(e) {
            var t = e.currentTarget;
            "true" === t.getAttribute(this.AriaDisabled) ? (e.preventDefault(), e.stopPropagation()) : t.dataset.otVsId ? u.toggleVendorServiceHandler.bind(this)(e) : t.dataset.optanongroupid && u.toggleV2Category.bind(this)()
        }, this.toggleVendorFromListHandler = function(e) {
            var t, o, n = e.currentTarget;
            "true" === n.getAttribute(this.AriaDisabled) ? (e.preventDefault(), e.stopPropagation()) : (e = n.checked, t = n.dataset.otVsId, n = n.dataset.optanongroupid, o = document.getElementById("ot-vendor-id-" + t), O.toggleVendorService(n, t, e, o))
        }, this.toggleVendorServiceHandler = function(e) {
            var t, o, n = e.currentTarget;
            "true" === n.getAttribute(r.AriaDisabled) ? (e.preventDefault(), e.stopPropagation()) : (e = n.checked, t = n.dataset.otVsId, o = n.dataset.optanongroupid, O.toggleVendorService(o, t, e, n), o = L.getVSById(t), u.setAriaLabelforButtonInFilter(o.ServiceName))
        }, this.toggleV2Category = function(e, t, o, n) {
            t || (r = this.getAttribute("data-optanongroupid"), i = "function" == typeof this.getAttribute, a = v.findIndex(w.dataGroupState, function(e) {
                return i && e.CustomGroupId === r
            }), t = w.dataGroupState[a]), void 0 === o && (o = m(this).is(":checked")), N.ChoicesBanner && v.setCheckedAttribute("#ot-bnr-grp-id-" + t.CustomGroupId, null, o), n ? document.querySelector("#ot-group-id-" + n) && (v.setCheckedAttribute("#ot-group-id-" + n, null, o), s = document.querySelector("#ot-group-id-" + n)) : (v.setCheckedAttribute(null, s = this, o), s.parentElement.querySelector(".ot-switch-nob")), N.PCShowConsentLabels && (s.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(o ? N.PCActiveText : N.PCInactiveText));
            var r, i, s, a = this instanceof HTMLElement && -1 !== this.getAttribute("id").indexOf("-leg-out");
            u.setAriaLabelforButtonInFilter(t.GroupName), u.updateGroupToggles(t, o, a)
        }, this.toggleBannerCategory = function(e) {
            var t, o = this;
            "true" === o.getAttribute(this.AriaDisabled) ? (e.preventDefault(), e.stopPropagation()) : (e = v.findIndex(w.dataGroupState, function(e) {
                return "function" == typeof o.getAttribute && e.CustomGroupId === o.getAttribute("data-optanongroupid")
            }), e = w.dataGroupState[e], t = m(o).is(":checked"), u.toggleV2Category(null, e, t, e.CustomGroupId))
        }, this.shiftBannerFocus = function(e) {
            var t = document.getElementById(u.pcSDKSelector),
                o = !1;
            t && (o = "none" !== window.getComputedStyle(t).display), "Tab" !== e.code || o || Vo.handleBannerFocus(e, e.shiftKey), "Escape" !== e.code || o || setTimeout(function() {
                $n.getInstance().resetHealthSignatureData(), u.bannerCloseButtonHandler(e)
            }, 0)
        }, this.toggleSubCategory = function(e, t, o, n) {
            t = t || this.getAttribute("data-optanongroupid");
            var r, t = L.getGroupById(t),
                n = (void 0 === o && (o = m(this).is(":checked")), n ? (v.setCheckedAttribute("#ot-sub-group-id-" + n, null, o), r = document.querySelector("#ot-sub-group-id-" + n)) : v.setCheckedAttribute(null, r = this, o), L.getParentGroup(t.Parent).ShowSubgroup),
                n = (N.PCShowConsentLabels && n && (r.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(o ? N.PCActiveText : N.PCInactiveText)), this instanceof HTMLElement && -1 !== this.getAttribute("id").indexOf("-leg-out"));
            u.setAriaLabelforButtonInFilter(t.GroupName), u.updateSubGroupToggles(t, o, n), O.setVendorStateByGroup(t, o)
        }, this.vendorsListDelegatedHandler = function(e) {
            var t;
            (null == (t = e.target) ? void 0 : t.closest(".onetrust-vendors-list-handler")) && !w.showVendorService && setTimeout(function() {
                u.showAllVendors(e)
            }, 0)
        }
    }
    Ir.prototype.insertCookiePolicyHtml = function() {
        if (m(this.ONETRUST_COOKIE_POLICY).length) {
            var e, t, o, n = document.createDocumentFragment(),
                r = (js.cookieListGroup && (t = N.CookiesV2NewCookiePolicy ? ".ot-sdk-cookie-policy" : "#ot-sdk-cookie-policy-v2", o = document.createElement("div"), m(o).html(js.cookieListGroup.html), o.removeChild(o.querySelector(t)), e = o.querySelector(".ot-sdk-cookie-policy"), N.useRTL) && m(e).attr("dir", "rtl"), e.querySelector("#cookie-policy-title").innerHTML = S.getInnerHtmlContent(N.CookieListTitle || ""), e.querySelector("#cookie-policy-description").innerHTML = S.getInnerHtmlContent(N.CookieListDescription || ""), e.querySelector("section")),
                i = e.querySelector("section tbody tr"),
                s = null,
                a = null;
            N.CookiesV2NewCookiePolicy || (s = e.querySelector("section.subgroup"), a = e.querySelector("section.subgroup tbody tr"), m(e).el.removeChild(e.querySelector("section.subgroup"))), m(e).el.removeChild(e.querySelector("section")), !m(this.COOKIE_POLICY_SELECTOR).length && m(this.OPTANON_POLICY_SELECTOR).length ? m(this.OPTANON_POLICY_SELECTOR).append('<div id="ot-sdk-cookie-policy"></div>') : (m(this.COOKIE_POLICY_SELECTOR).html(""), m(this.OPTANON_POLICY_SELECTOR).html(""));
            for (var l = 0, c = N.Groups; l < c.length; l++) {
                var d = c[l],
                    u = {
                        json: N,
                        group: d,
                        sectionTemplate: r,
                        tableRowTemplate: i,
                        cookieList: e,
                        fragment: n
                    };
                if (N.CookiesV2NewCookiePolicy) this.insertGroupHTMLV2(u);
                else if (this.insertGroupHTML(u), d.ShowSubgroup)
                    for (var p = 0, C = d.SubGroups; p < C.length; p++) {
                        var g = C[p],
                            g = {
                                json: N,
                                group: g,
                                sectionTemplate: s,
                                tableRowTemplate: a,
                                cookieList: e,
                                fragment: n
                            };
                        this.insertGroupHTML(g)
                    }
            }
        }
    }, Ir.prototype.insertGroupHTMLV2 = function(e) {
        function t(e) {
            return c.querySelector(e)
        }
        var o, n = this,
            r = e.json,
            i = e.group,
            s = e.sectionTemplate,
            a = e.tableRowTemplate,
            l = e.cookieList,
            e = e.fragment,
            c = s.cloneNode(!0),
            s = i.SubGroups,
            d = (m(t("tbody")).html(""), i.Hosts.slice()),
            u = i.FirstPartyCookies.slice(),
            p = d.length || u.length ? i.GroupName : "",
            s = (i.ShowSubgroup && s.length ? (o = c.querySelector("section.ot-sdk-subgroup ul li"), s.forEach(function(e) {
                var t = o.cloneNode(!0);
                d = d.concat(e.Hosts), u = u.concat(e.FirstPartyCookies), (e.Hosts.length || e.FirstPartyCookies.length) && (p += "," + e.GroupName), m(t.querySelector(".ot-sdk-cookie-policy-group")).html(e.GroupName), m(t.querySelector(".ot-sdk-cookie-policy-group-desc")).html(n.groupsClass.safeFormattedGroupDescription(e)), m(o.parentElement).append(t)
            }), c.querySelector("section.ot-sdk-subgroup ul").removeChild(o)) : c.removeChild(c.querySelector("section.ot-sdk-subgroup")), N.TTLGroupByTech && (this.setCookieListHeaderOrder(c), this.setCookieListBodyOrder(a)), r.IsLifespanEnabled ? m(t("th.ot-life-span")).el.innerHTML = S.getInnerHtmlContent(r.LifespanText) : m(t("thead tr")).el.removeChild(m(t("th.ot-life-span")).el), m(t("th.ot-cookies")).el.innerHTML = S.getInnerHtmlContent(r.CookiesText), m(t("th.ot-host")).el.innerHTML = S.getInnerHtmlContent(r.CategoriesText), m(t("th.ot-cookies-type")).el.innerHTML = S.getInnerHtmlContent(r.CookiesUsedText), m(t("th.ot-host-description")).el.innerHTML = S.getInnerHtmlContent(r.CookiesDescText), this.transformFirstPartyCookies(u, d, i)),
            C = !1;
        (C = N.TTLGroupByTech ? N.TTLShowTechDesc : s.some(function(e) {
            return e.Description
        })) || m(t("thead tr")).el.removeChild(m(t("th.ot-host-description")).el), m(t(".ot-sdk-cookie-policy-group")).html(i.GroupName), m(t(".ot-sdk-cookie-policy-group-desc")).html(this.groupsClass.safeFormattedGroupDescription(i)), N.TTLGroupByTech ? this.insertCookieLineByLine({
            json: r,
            hosts: s,
            tableRowTemplate: a,
            showHostDescription: C,
            st: t
        }) : this.insertHostHtmlV2({
            json: r,
            hosts: s,
            tableRowTemplate: a,
            showHostDescription: C,
            st: t
        }), 0 === s.length ? c.removeChild(c.querySelector("table")) : m(t("caption")).el.innerHTML = S.getInnerHtmlContent(p), m(l).append(c), m(e).append(l), m(this.COOKIE_POLICY_SELECTOR).append(e)
    }, Ir.prototype.insertHostHtmlV2 = function(e) {
        for (var l, c = e.json, d = e.tableRowTemplate, u = e.showHostDescription, p = e.st, C = this, t = 0, o = e.hosts; t < o.length; t++)(e => {
            for (var t = d.cloneNode(!0), o = function(e) {
                    return t.querySelector(e)
                }, n = (C.clearCookieRowElement(o), []), r = [], i = 0, s = e.Cookies; i < s.length; i++) {
                var a = s[i],
                    a = ((l = a).IsSession ? n.push(c.LifespanTypeText) : n.push(h.getDuration(l)), l.Name);
                e.Type && (a = '\n                    <a href="https://cookiepedia.co.uk/cookies/' + l.Name + '"\n                        rel="noopener noreferrer" target="_blank" aria-label="' + l.Name + " " + N.NewWinTxt + '">\n                        ' + l.Name + "\n                    </a>"), r.push(a)
            }
            C.setDataLabelAttribute(o, c), C.createCookieRowHtmlElement({
                host: e,
                subGroupCookie: l,
                trt: o,
                json: c,
                lifespanText: n.join(", "),
                hostType: r.join(", ")
            }), C.removeLifeSpanOrHostDescription(c, u, t, o), m(p("tbody")).append(t)
        })(o[t])
    }, Ir.prototype.insertGroupHTML = function(e) {
        function t(e) {
            return l.querySelector(e)
        }
        var o, n = e.json,
            r = e.group,
            i = e.sectionTemplate,
            s = e.tableRowTemplate,
            a = e.cookieList,
            e = e.fragment,
            l = i.cloneNode(!0),
            i = (m(t("caption")).el.innerHTML = S.getInnerHtmlContent(r.GroupName), m(t("tbody")).html(""), m(t("thead tr")), n.IsLifespanEnabled ? m(t("th.life-span")).el.innerHTML = S.getInnerHtmlContent(n.LifespanText) : m(t("thead tr")).el.removeChild(m(t("th.life-span")).el), m(t("th.cookies")).el.innerHTML = S.getInnerHtmlContent(n.CookiesText), m(t("th.host")).el.innerHTML = S.getInnerHtmlContent(n.CategoriesText), !1);
        if (r.Hosts.some(function(e) {
                return e.description
            }) ? i = !0 : m(t("thead tr")).el.removeChild(m(t("th.host-description")).el), m(t(".ot-sdk-cookie-policy-group")).html(r.GroupName), m(t(".ot-sdk-cookie-policy-group-desc")).html(this.groupsClass.safeFormattedGroupDescription(r)), 0 < r.FirstPartyCookies.length) {
            m(t(".cookies-used-header")).html(n.CookiesUsedText), m(t(".cookies-list")).html("");
            for (var c = 0; c < r.FirstPartyCookies.length; c++) o = r.FirstPartyCookies[c], m(t(".cookies-list")).append("<li> " + h.getCookieLabel(o, n.AddLinksToCookiepedia) + " <li>")
        } else l.removeChild(t(".cookies-used-header")), l.removeChild(t(".cookies-list"));
        this.insertHostHtmlV1({
            json: n,
            hosts: r.Hosts,
            tableRowTemplate: s,
            showHostDescription: i,
            st: t
        }), m(a).append(l), m(e).append(a), m(this.COOKIE_POLICY_SELECTOR).append(e)
    }, Ir.prototype.insertHostHtmlV1 = function(e) {
        for (var l = e.json, t = e.hosts, c = e.tableRowTemplate, d = e.showHostDescription, u = e.st, o = 0, n = t; o < n.length; o++)(e => {
            for (var t = c.cloneNode(!0), o = function(e) {
                    return t.querySelector(e)
                }, n = (m(o(".cookies-td ul")).html(""), m(o(".life-span-td ul")).html(""), m(o(".host-td")).html(""), m(o(".host-description-td")).html('<span class="ot-mobile-border"></span><p>' + e.Description + "</p> "), 0), r = 0, i = e.Cookies; r < i.length; r++) {
                var s = i[r],
                    a = "",
                    a = s.IsSession ? l.LifespanTypeText : 0 === s.Length ? "<1 " + l.LifespanDurationText || l.PCenterVendorListLifespanDays : s.Length + " " + l.LifespanDurationText || l.PCenterVendorListLifespanDays,
                    a = l.IsLifespanEnabled ? "&nbsp;(" + a + ")" : "";
                m(o(".cookies-td ul")).append("<li> " + s.Name + " " + a + " </li>"), l.IsLifespanEnabled && (a = s.Length ? s.Length + " days" : "N/A", m(o(".life-span-td ul")).append("<li>" + a + "</li>")), 0 === n && (m(o(".host-td")).append('<span class="ot-mobile-border"></span>'), m(o(".host-td")).append('<a href="https://cookiepedia.co.uk/host/' + s.Host + '" rel="noopener noreferrer" target="_blank"\n                        aria-label="' + (e.DisplayName || e.HostName) + " " + N.NewWinTxt + '">' + (e.DisplayName || e.HostName) + "</a>")), n++
            }
            d || t.removeChild(o("td.host-description-td")), m(u("tbody")).append(t)
        })(n[o]);
        0 === t.length && m(u("table")).el.removeChild(m(u("thead")).el)
    }, Ir.prototype.transformFirstPartyCookies = function(e, t, o) {
        var n = this,
            r = t.slice(),
            t = (e.forEach(function(e) {
                n.populateHostGroup(e, r, N.firstPartyTxt)
            }), o.GeneralVendorsIds),
            e = (this.populateGenVendor(t, o, r), o.SubGroups || []);
        return e.length && e.forEach(function(e) {
            var t = e.GeneralVendorsIds;
            n.populateGenVendor(t, e, r)
        }), r
    }, Ir.prototype.populateGenVendor = function(e, o, n) {
        var r = this;
        e.length && e.forEach(function(t) {
            var e = N.GeneralVendors.find(function(e) {
                return e.VendorCustomId === t
            });
            e.Cookies.length && e.Cookies.forEach(function(e) {
                var t;
                e.category === o.GroupName && (t = e.isThirdParty ? "" : N.firstPartyTxt, r.populateHostGroup(e, n, t))
            })
        })
    }, Ir.prototype.populateHostGroup = function(t, e, o) {
        e.some(function(e) {
            if (e.HostName === t.Host && e.Type === o) return e.Cookies.push(t), !0
        }) || e.unshift({
            HostName: t.Host,
            DisplayName: t.Host,
            HostId: "",
            Description: "",
            Type: o,
            Cookies: [t]
        })
    }, Ir.prototype.insertCookieLineByLine = function(e) {
        for (var t = e.json, o = e.tableRowTemplate, n = e.showHostDescription, r = e.st, i = 0, s = e.hosts; i < s.length; i++)
            for (var a = s[i], l = 0, c = a.Cookies; l < c.length; l++) {
                var d = c[l],
                    u = d.IsSession ? t.LifespanTypeText : h.getDuration(d),
                    p = d.Name,
                    C = (a.Type && (p = '<a href="https://cookiepedia.co.uk/cookies/' + p + '"\n                        rel="noopener noreferrer" target="_blank" aria-label="' + p + " " + N.NewWinTxt + '">' + p + "\n                    </a>"), o.cloneNode(!0)),
                    g = this.queryToHtmlElement(C);
                this.clearCookieRowElement(g), this.createCookieRowHtmlElement({
                    host: a,
                    subGroupCookie: d,
                    trt: g,
                    json: t,
                    lifespanText: u,
                    hostType: p
                }), this.removeLifeSpanOrHostDescription(t, n, C, g), m(r("tbody")).append(C)
            }
    }, Ir.prototype.removeLifeSpanOrHostDescription = function(e, t, o, n) {
        e.IsLifespanEnabled || o.removeChild(n("td.ot-life-span-td")), t || o.removeChild(n("td.ot-host-description-td"))
    }, Ir.prototype.createCookieRowHtmlElement = function(e) {
        var t = e.host,
            o = e.subGroupCookie,
            n = e.trt,
            r = e.lifespanText,
            i = e.hostType,
            s = ".ot-host-td",
            e = (this.setDataLabelAttribute(n, e.json), m(n(".ot-host-description-td")).html('<span class="ot-mobile-border"></span><p>' + o.description + "</p> "), m(n(s)).append('<span class="ot-mobile-border"></span>'), t.DisplayName || t.HostName);
        m(n(s)).append(t.Type ? e : '<a href="https://cookiepedia.co.uk/host/' + o.Host + '" rel="noopener noreferrer" target="_blank"\n                        aria-label="' + e + " " + N.NewWinTxt + '">\n                        ' + e + "\n                        </a>"), n(".ot-cookies-td .ot-cookies-td-content").insertAdjacentHTML("beforeend", S.getInnerHtmlContent(i)), m(n(".ot-life-span-td .ot-life-span-td-content")).html(r), m(n(".ot-cookies-type .ot-cookies-type-td-content")).html(t.Type ? N.firstPartyTxt : N.thirdPartyTxt)
    }, Ir.prototype.setDataLabelAttribute = function(e, t) {
        var o = "data-label";
        e(".ot-host-td").setAttribute(o, t.CategoriesText), e(".ot-cookies-td").setAttribute(o, t.CookiesText), e(".ot-cookies-type").setAttribute(o, t.CookiesUsedText), e(".ot-life-span-td").setAttribute(o, t.LifespanText), e(".ot-host-description-td").setAttribute(o, t.CookiesDescText)
    }, Ir.prototype.clearCookieRowElement = function(e) {
        m(e(".ot-cookies-td span")).text(""), m(e(".ot-life-span-td span")).text(""), m(e(".ot-cookies-type span")).text(""), m(e(".ot-cookies-td .ot-cookies-td-content")).html(""), m(e(".ot-host-td")).html("")
    }, Ir.prototype.setCookieListHeaderOrder = function(e) {
        var e = e.querySelector("section table thead tr"),
            t = e.querySelector("th.ot-host"),
            o = e.querySelector("th.ot-cookies"),
            n = e.querySelector("th.ot-life-span"),
            r = e.querySelector("th.ot-cookies-type"),
            i = e.querySelector("th.ot-host-description");
        e.innerHTML = S.getInnerHtmlContent(""), e.appendChild(o.cloneNode(!0)), e.appendChild(t.cloneNode(!0)), e.appendChild(n.cloneNode(!0)), e.appendChild(r.cloneNode(!0)), e.appendChild(i.cloneNode(!0))
    }, Ir.prototype.setCookieListBodyOrder = function(e) {
        var t = e.querySelector("td.ot-host-td"),
            o = e.querySelector("td.ot-cookies-td"),
            n = e.querySelector("td.ot-life-span-td"),
            r = e.querySelector("td.ot-cookies-type"),
            i = e.querySelector("td.ot-host-description-td");
        e.innerHTML = S.getInnerHtmlContent(""), e.appendChild(o.cloneNode(!0)), e.appendChild(t.cloneNode(!0)), e.appendChild(n.cloneNode(!0)), e.appendChild(r.cloneNode(!0)), e.appendChild(i.cloneNode(!0))
    }, Ir.prototype.queryToHtmlElement = function(t) {
        return function(e) {
            return t.querySelector(e)
        }
    };
    var Pr, kr = Ir;

    function Ir() {
        this.groupsClass = y, this.COOKIE_POLICY_SELECTOR = "#ot-sdk-cookie-policy", this.OPTANON_POLICY_SELECTOR = "#optanon-cookie-policy", this.ONETRUST_COOKIE_POLICY = "#ot-sdk-cookie-policy, #optanon-cookie-policy"
    }
    Er.prototype.initBanner = function() {
        this.canImpliedConsentLandingPage(), k.moduleInitializer.CookieSPAEnabled ? m(window).on("otloadbanner", this.windowLoadBanner.bind(this)) : m(window).one("otloadbanner", this.windowLoadBanner.bind(this))
    }, Er.prototype.insertCSBtnHtmlAndCss = function(e) {
        var t = document.getElementById("onetrust-style"),
            t = (t.innerHTML = S.getInnerHtmlContent(t.innerHTML + js.csBtnGroup.css), document.createElement("div")),
            t = (m(t).html(js.csBtnGroup.html), t.querySelector("#ot-sdk-btn-floating"));
        e && t && m(t).removeClass("ot-hide"), m("#onetrust-consent-sdk").append(t), N.cookiePersistentLogo && (N.cookiePersistentLogo.includes("ot_guard_logo.svg") ? this.applyPersistentSvgOnDOM() : (m(".ot-floating-button__front, .ot-floating-button__back").addClass("custom-persistent-icon"), e = h.updateCorrectUrl(N.cookiePersistentLogo), t = new URL(e, window.location.origin).pathname, k.fp.CMPIconSprite && (t.includes("/logos/static/") || t.includes("src/assets/images/") && new URL(e, window.location.origin).host.includes("localhost")) && (e = "<svg>\n                    <use href='#" + t.split("/").pop().split(".").shift() + "'></use>\n                    </svg>", m(".ot-floating-button__front > button").html(e), m(".ot-floating-button__front svg").attr("class", "ot-source-sprite"))))
    }, Er.prototype.applyPersistentSvgOnDOM = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return k.fp.CMPIconSprite ? (t = "<svg>\n            <use href='#ot_guard_logo'></use>\n            </svg>", [3, 3]) : [3, 1];
                    case 1:
                        return [4, Yt.getPersistentCookieSvg()];
                    case 2:
                        t = e.sent(), e.label = 3;
                    case 3:
                        return m(this.FLOATING_COOKIE_FRONT_BTN).html(t), u.otGuardLogoResolve(!0), [2]
                }
            })
        })
    }, Er.prototype.canImpliedConsentLandingPage = function() {
        this.isImpliedConsent() && !Ao.isLandingPage() && "true" === I.readCookieParam(P.OPTANON_CONSENT, A.AWAITING_RE_CONSENT) && this.checkForRefreshCloseImplied()
    }, Er.prototype.isImpliedConsent = function() {
        return N.ConsentModel && "implied consent" === N.ConsentModel.Name.toLowerCase() || 0 < D.consentableImpliedConsentGroup.length
    }, Er.prototype.checkForRefreshCloseImplied = function() {
        g.bannerCloseButtonHandler(!0)
    }, Er.prototype.hideCustomHtml = function() {
        var e = document.getElementById("onetrust-banner-sdk");
        e && Ht(e, "display: none;")
    }, Er.prototype.shouldShowBanner = function(e) {
        return N.ShowAlertNotice && !e && !N.NoBanner && !w.hideBanner
    }, Er.prototype.shouldShowPc = function(e) {
        return N.ShowAlertNotice && !e && N.NoBanner
    }, Er.prototype.windowLoadBanner = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (this.core.substitutePlainTextScriptTags(), t = k.moduleInitializer, m("#onetrust-consent-sdk").length ? o = document.getElementById("onetrust-consent-sdk") : (o = document.createElement("div"), m(o).attr("id", "onetrust-consent-sdk"), m(o).attr("data-nosnippet", "true"), m(document.body).append(o)), k.fp.CMPIconSprite) ? (r = N.OTSpriteLogo, (n = k.moduleInitializer.ScriptType) !== je.LOCAL && n !== je.LOCAL_TEST || (r = h.updateCorrectUrl(N.OTSpriteLogo)), [4, Yt.getSpriteSvg(r)]) : [3, 2];
                    case 1:
                        n = e.sent(), r = document.createElement("div"), m(r).attr("id", "onetrust-sprite-svg"), m(r).html(n), m(o).append(r), e.label = 2;
                    case 2:
                        return (m(".onetrust-pc-dark-filter").length || (i = document.createElement("div"), m(i).attr("class", "onetrust-pc-dark-filter"), m(i).attr("class", "ot-hide"), m(i).attr("class", "ot-fade-in"), o.firstChild ? o.insertBefore(i, o.firstChild) : m(o).append(i)), N.IsIabEnabled && this.iab.updateIabVariableReference(), i = B.isAlertBoxClosedAndValid(), s = this.shouldShowBanner(i), a = this.shouldShowPc(i), w.ntfyRequired ? (this.hideCustomHtml(), an.init(), an.changeState()) : (s ? u.initializeAlartHtmlAndHandler() : (N.IsGPPEnabled && Hs.setCmpDisplayStatus("disabled"), this.hideCustomHtml()), u.addEventListnerForVendorsList()), t.IsSuppressPC || (_.insertPcHtml(), u.initialiseConsentNoticeHandlers(), N.IsIabEnabled && this.iab.InitializeVendorList()), this.prepopulateCookieOrVendorPageTitle(), this.initializeHbbTvScript(), this.insertCSBtn(!s), a) ? [4, u.toggleInfoDisplay()] : [3, 4];
                    case 3:
                        e.sent(), e.label = 4;
                    case 4:
                        return u.insertCookieSettingText(), this.initializeFloatingButtonOnBannerLoad(a), br.insertTrackigTechOrCookiePolicy(), g.executeOptanonWrapper(), this.initializeCookieParamsOnBannerLoad(s), [2]
                }
            })
        })
    }, Er.prototype.prepopulateCookieOrVendorPageTitle = function() {
        k.isV2Template && (N.GeneralVendorsEnabled ? this.iab.setListSearchValues(Ee.vendors) : this.iab.setListSearchValues(Ee.cookies))
    }, Er.prototype.initializeFloatingButtonOnBannerLoad = function(e) {
        var t = m(this.FLOATING_COOKIE_BTN),
            o = m(this.FLOATING_COOKIE_FRONT_BTN),
            n = m(this.FLOATING_COOKIE_BACK_BTN);
        t.length && (t.attr("data-title", N.CookieSettingButtonText), o.el[0].setAttribute(vt, h.getFloatingBtnAriaLabel()), n.el[0].setAttribute(vt, N.AriaClosePreferences), e ? (o.el[0].setAttribute(Tt, !0), o.el[0].style.display = "none") : (n.el[0].setAttribute(Tt, !0), n.el[0].style.display = "none"), h.shouldShowOptOutNotification()) && h.initOptOutSignalNotification()
    }, Er.prototype.initializeCookieParamsOnBannerLoad = function(e) {
        I.readCookieParam(P.OPTANON_CONSENT, Zt) || go.writeGrpParam(P.OPTANON_CONSENT), I.readCookieParam(P.OPTANON_CONSENT, $t) || go.writeHstParam(P.OPTANON_CONSENT), w.showGeneralVendors && !I.readCookieParam(P.OPTANON_CONSENT, eo) && go.writeGenVenCookieParam(P.OPTANON_CONSENT), w.vsIsActiveAndOptOut && !I.readCookieParam(P.OPTANON_CONSENT, to) && go.writeVSConsentCookieParam(P.OPTANON_CONSENT), e && Vo.setBannerFocus()
    }, Er.prototype.initializeHbbTvScript = function() {
        var e;
        k.moduleInitializer.RemoteActionsEnabled && ((e = document.getElementById("hbbtv")) && e.remove(), (e = document.createElement("script")).id = "hbbtv", e.src = w.storageBaseURL + "/scripttemplates/" + k.moduleInitializer.Version + "/hbbtv.js", e.type = "text/javascript", m(document.body).append(e))
    }, Er.prototype.insertCSBtn = function(e) {
        js.csBtnGroup && (this.insertCSBtnHtmlAndCss(e), u.initFlgtCkStgBtnEventHandlers())
    }, Er.prototype.insertTrackingTechnologies = function() {
        var e, t;
        m("#ot-sdk-cookie-policy, #optanon-cookie-policy").length && (window.OnetrustCookiePolicy && window.OnetrustCookiePolicy.InsertCookiePolicyHtml ? window.OnetrustCookiePolicy.InsertCookiePolicyHtml(h, N, m) : ((t = document.createElement("script")).id = "cookie-policy-script", t.onload = function() {
            return window.OnetrustCookiePolicy.InsertCookiePolicyHtml(h, N, m)
        }, t.type = "text/javascript", t.src = w.storageBaseURL + "/scripttemplates/" + k.moduleInitializer.Version + "/trackingTechnologies.js", null != (e = D.sriHash) && e["trackingTechnologies.js"] && (t.integrity = D.sriHash["trackingTechnologies.js"]), document.head.appendChild(t)))
    }, Er.prototype.insertTrackigTechOrCookiePolicy = function() {
        k.fp.CookieV2TrackingTechnologies ? br.insertTrackingTechnologies() : Pr.insertCookiePolicyHtml()
    };
    var br, Lr = Er;

    function Er() {
        this.iab = C, this.core = on, this.FLOATING_COOKIE_BTN = "#ot-sdk-btn-floating", this.FLOATING_COOKIE_FRONT_BTN = "#ot-sdk-btn-floating .ot-floating-button__front .ot-floating-button__open", this.FLOATING_COOKIE_BACK_BTN = "#ot-sdk-btn-floating .ot-floating-button__back .ot-floating-button__close"
    }
    Dr.prototype.initialiseLandingPath = function() {
        var e = B.needReconsent();
        Ao.isLandingPage() ? Ao.setLandingPathParam(location.href) : e && !B.awaitingReconsent() ? (Ao.setLandingPathParam(location.href), I.writeCookieParam(P.OPTANON_CONSENT, A.AWAITING_RE_CONSENT, !0)) : (e || I.writeCookieParam(P.OPTANON_CONSENT, A.AWAITING_RE_CONSENT, !1), Ao.setLandingPathParam(A.NOT_LANDING_PAGE), !D.isSoftOptInMode || k.moduleInitializer.MobileSDK || B.isAlertBoxClosedAndValid() || uo.setAlertBoxClosed(!0), N.NextPageCloseBanner && N.ShowAlertNotice && g.nextPageCloseBanner())
    };
    var Or, _r = Dr;

    function Dr() {}
    Br.prototype.IsAlertBoxClosedAndValid = function() {
        return B.isAlertBoxClosedAndValid()
    }, Br.prototype.LoadBanner = function() {
        uo.loadBanner()
    }, Br.prototype.Init = function(e) {
        void 0 === e && (e = !1), xe.insertViewPortTag(), js.ensureHtmlGroupDataInitialised(), Or.initialiseLandingPath(), Zo.updateGtmMacros(!1), e || No.initialiseCssReferences()
    }, Br.prototype.FetchAndDownloadPC = function() {
        u.fetchAndSetupPC()
    }, Br.prototype.ToggleInfoDisplay = function() {
        uo.triggerGoogleAnalyticsEvent(fn, In), u.toggleInfoDisplay()
    }, Br.prototype.Close = function(e) {
        u.close(e)
    }, Br.prototype.AllowAll = function(e) {
        D.apiSource = oe.AcceptAll, h.shouldShowDoubleOptInSignal(!0) ? h.createDoubleOptInConfirmDialog(w.isPCVisible, function() {
            g.allowAllEvent(e)
        }) : g.allowAllEvent(e)
    }, Br.prototype.RejectAll = function(e) {
        D.apiSource = oe.RejectAll, g.rejectAllEvent(e)
    }, Br.prototype.sendReceipt = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, A.INTERACTION_TYPE);
        Ms.createConsentTxn(!1, e, !1, !0, !0)
    }, Br.prototype.setDataSubjectIdV2 = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = ""), (e || t) && (e && e.trim() && (e = e.replace(/ /g, ""), I.writeCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID, e, !0)), null != (e = o) && e.trim() && I.writeCookieParam(P.OPTANON_CONSENT, A.IDENTIFIER_TYPE, o.trim()), w.dsParams.isAnonymous = t, w.dsParams.forceUserConsentAttributes = !0, I.writeCookieParam(P.OPTANON_CONSENT, A.IS_ANONYMOUS_CONSENT, t ? "1" : "0"))
    }, Br.prototype.getDataSubjectId = function() {
        return I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID, !0)
    }, Br.prototype.getDSDefaultIdentifier = function() {
        var e;
        return null == (e = N.ConsentIntegration) ? void 0 : e.DefaultIdentifier
    }, Br.prototype.synchroniseCookieWithPayload = function(n) {
        var e = I.readCookieParam(P.OPTANON_CONSENT, "groups"),
            e = v.strToArr(e),
            r = [];
        e.forEach(function(e) {
            var e = e.split(":"),
                t = L.getGroupById(e[0]),
                o = v.findIndex(n, function(e) {
                    return e.Id === t.PurposeId
                }),
                o = n[o];
            o ? o.TransactionType === Re ? (r.push(e[0] + ":1"), t.Parent ? u.toggleSubCategory(null, t.CustomGroupId, !0, t.CustomGroupId) : u.toggleV2Category(null, t, !0, t.CustomGroupId)) : (r.push(e[0] + ":0"), t.Parent ? u.toggleSubCategory(null, t.CustomGroupId, !1, t.CustomGroupId) : u.toggleV2Category(null, t, !1, t.CustomGroupId)) : r.push(e[0] + ":" + e[1])
        }), go.writeGrpParam(P.OPTANON_CONSENT, r)
    }, Br.prototype.getGeolocationData = function() {
        return w.userLocation
    }, Br.prototype.TriggerGoogleAnalyticsEvent = function(e, t, o, n) {
        uo.triggerGoogleAnalyticsEvent(e, t, o, n)
    }, Br.prototype.ReconsentGroups = function() {
        var n = !1,
            e = I.readCookieParam(P.OPTANON_CONSENT, "groups"),
            r = v.strToArr(e),
            i = v.strToArr(e.replace(/:0|:1/g, "")),
            s = !1,
            t = I.readCookieParam(P.OPTANON_CONSENT, "hosts"),
            a = v.strToArr(t),
            l = v.strToArr(t.replace(/:0|:1/g, "")),
            c = ["inactive", "inactive landingpage", "do not track"];
        e && (N.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                var t = e.CustomGroupId,
                    o = v.indexOf(i, t); - 1 !== o && (e = L.getGrpStatus(e).toLowerCase(), -1 < c.indexOf(e)) && (n = !0, r[o] = t + ("inactive landingpage" === e ? ":1" : ":0"))
            })
        }), n) && go.writeGrpParam(P.OPTANON_CONSENT, r), t && (N.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(n) {
                n.Hosts.forEach(function(e) {
                    var t, o = v.indexOf(l, e.HostId); - 1 !== o && (t = L.getGrpStatus(n).toLowerCase(), -1 < c.indexOf(t)) && (s = !0, a[o] = e.HostId + ("inactive landingpage" === t ? ":1" : ":0"))
                })
            })
        }), s) && go.writeHstParam(P.OPTANON_CONSENT, a)
    }, Br.prototype.SetAlertBoxClosed = function(e) {
        uo.setAlertBoxClosed(e)
    }, Br.prototype.GetDomainData = function() {
        return D.pubDomainData
    }, Br.prototype.setGeoLocation = function(e, t) {
        w.userLocation = {
            country: e,
            state: t = void 0 === t ? "" : t,
            stateName: ""
        }
    }, Br.prototype.changeLang = function(t) {
        var o;
        t !== w.lang && (o = k.moduleInitializer, Yt.getLangJson(t).then(function(e) {
            e ? (D.init(e), js.fetchAssets(t).then(function() {
                var e = document.getElementById("onetrust-style"),
                    e = (e && (e.textContent = ""), No.initialiseCssReferences(), o.IsSuppressPC && !w.isPCVisible || (v.removeChild(m("#onetrust-pc-sdk").el), w.vendorDomInit = !1, w.genVendorDomInit = !1, _.insertPcHtml(), u.initialiseConsentNoticeHandlers(), N.IsIabEnabled && (B.assignIABDataWithGlobalVendorList(w.gvlObj), C.InitializeVendorList()), w.isPCVisible && u.restorePc()), !0);
                v.removeChild(m("#onetrust-banner-sdk").el), B.isAlertBoxClosedAndValid() || o.IsSuppressBanner && (o.IsSuppressBanner, w.skipAddingHTML) || N.NoBanner || !N.ShowAlertNotice || (u.initializeAlartHtmlAndHandler(), Vo.setBannerFocus(), e = !1), Nr.initCookiePolicyAndSettings(), v.removeChild(m("#ot-sdk-btn-floating").el), br.insertCSBtn(e), Nr.processedHtml = null, Nr.updateTCStringOnLangChange(t)
            })) : console.error("Language:" + t + " doesn't exist for the geo rule")
        }))
    }, Br.prototype.updateTCStringOnLangChange = function(e) {
        D.isIab2orv2Template && (w.consentLanguage = e, w.tcModel.consentLanguage = w.consentLanguage, w.tcModel.useNonStandardTexts = N.UseNonStandardStacks, B.isAlertBoxClosedAndValid() || h.updateTCString())
    }, Br.prototype.initCookiePolicyAndSettings = function(e) {
        var t;
        (e = void 0 === e ? !1 : e) && (null != (t = document.querySelector(".ot-sdk-show-settings")) && t.removeEventListener("click", u.cookiesSettingsBoundListener), null != (t = document.querySelector(".optanon-toggle-display"))) && t.removeEventListener("click", u.cookiesSettingsBoundListener), k.fp.CookieV2TrackingTechnologies ? br.insertTrackingTechnologies() : Pr.insertCookiePolicyHtml(), u.insertCookieSettingText(e)
    }, Br.prototype.showVendorsList = function() {
        w.pcLayer !== se.VendorList && (u.showAllVendors(), uo.triggerGoogleAnalyticsEvent(fn, Ln))
    }, Br.prototype.getTestLogData = function() {
        var e = N.Groups,
            t = D.pubDomainData,
            o = k.moduleInitializer.Version,
            o = (console.info("%cWelcome to OneTrust Log", "padding: 8px; background-color: #43c233; color: white; font-style: italic; border: 1px solid black; font-size: 1.5em;"), console.info("Script is for: %c" + (t.Domain || N.optanonCookieDomain), "padding: 4px 6px; font-style: italic; border: 2px solid #43c233; font-size: 12px;"), console.info("Script Version Published: " + o), console.info("The consent model is: " + t.ConsentModel.Name), null !== B.alertBoxCloseDate()),
            n = (console.info("Consent has " + (o ? "" : "not ") + "been given " + (o ? "👍" : "🛑")), Zo.checkAndWarnGCMConfig(), []),
            r = (e.forEach(function(e) {
                var t = "",
                    t = e.Status && "always active" === e.Status.toLowerCase() ? "Always Active" : y.isGroupActive(e) ? "Active" : "Inactive";
                n.push({
                    CustomGroupId: e.CustomGroupId,
                    GroupName: e.GroupName,
                    Status: t
                })
            }), console.groupCollapsed("Current Category Status"), console.table(n), console.groupEnd(), []),
            o = (t.GeneralVendors.forEach(function(e) {
                r.push({
                    CustomGroupId: e.VendorCustomId,
                    Name: e.Name,
                    Status: Nr.isCategoryActive(e.VendorCustomId) ? "active" : "inactive"
                })
            }), console.groupCollapsed("General Vendor Ids"), console.table(r), console.groupEnd(), D.getRegionRule()),
            t = w.userLocation,
            i = k.moduleInitializer.GeoRuleGroupName,
            t = (D.conditionalLogicEnabled ? console.groupCollapsed("Geolocation, Template & Condition") : console.groupCollapsed("Geolocation and Template"), w.userLocation.country && console.info("The Geolocation is " + t.country.toUpperCase()), console.info("The Geolocation rule is " + o.Name), console.info("The GeolocationRuleGroup is " + i), D.canUseConditionalLogic && console.info("The Condition name is " + D.Condition.Name), console.info("The TemplateName is " + D.getTemplateName()), console.groupEnd(), e.filter(function(e) {
                return y.isGroupActive(e) && "COOKIE" === e.Type
            }));
        console.groupCollapsed("The cookies expected to be active if blocking has been implemented are"), t.forEach(function(e) {
            console.groupCollapsed(e.GroupName);
            e = Nr.getAllFormatCookiesForAGroup(e);
            console.table(e, ["Name", "Host", "description"]), console.groupEnd()
        }), console.groupEnd()
    }, Br.prototype.isCategoryActive = function(e) {
        return -1 !== window.OptanonActiveGroups.indexOf("," + e + ",")
    }, Br.prototype.getAllFormatCookiesForAGroup = function(e) {
        var t = [];
        return e.FirstPartyCookies.forEach(function(e) {
            return t.push({
                Name: e.Name,
                Host: e.Host,
                Description: e.description
            })
        }), (null == (e = e.Hosts) ? void 0 : e.reduce(function(e, t) {
            return e.concat(JSON.parse(JSON.stringify(t.Cookies)))
        }, [])).forEach(function(e) {
            return t.push({
                Name: e.Name,
                Host: e.Host,
                Description: e.description
            })
        }), t
    }, Br.prototype.updateSingularConsent = function(l, c) {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, u.fetchAndSetupPC()];
                    case 1:
                        for (e.sent(), D.apiSource = oe.UpdateConsent, t = c.split(","), o = [], n = 0, r = t; n < r.length; n++) s = r[n], s = s.split(":"), i = s[0], s = s[1], a = Boolean(Number(s)), l === yt ? "always active" === L.getGrpStatus(L.getGroupById(i)) || (Nr.updateConsentArray(w.groupsConsent, i, s), o.push({
                            id: i,
                            isEnabled: a
                        })) : l === ft ? Nr.updateConsentArray(w.hostsConsent, i, s) : l === St ? w.genVendorsConsent[i] = a : l === mt && o.push({
                            id: i,
                            isEnabled: a
                        });
                        return g.handleTogglesOnSingularConsentUpdate(l, o), [2]
                }
            })
        })
    }, Br.prototype.vendorServiceEnabled = function() {
        return w.showVendorService
    }, Br.prototype.updateGCM = function(e) {
        e || console.error("No callback passed to the UpdateGCM"), D.gcmUpdateCallback = e
    }, Br.prototype.updateConsentArray = function(e, t, o) {
        var n = e.findIndex(function(e) {
            return e === t + ":0" || e === t + ":1"
        }); - 1 < n ? e[n] = t + ":" + o : e.push(t + ":" + o)
    };
    var Nr, wr = Br;

    function Br() {
        this.processedHtml = "", this.useGeoLocationService = !0, this.IsAlertBoxClosed = this.IsAlertBoxClosedAndValid, this.InitializeBanner = function() {
            return br.initBanner()
        }, this.getHTML = function() {
            return document.getElementById("onetrust-banner-sdk") || (_.insertPcHtml(), yr.insertAlertHtml()), Nr.processedHtml || (Nr.processedHtml = document.querySelector("#onetrust-consent-sdk").outerHTML), Nr.processedHtml
        }, this.getCSS = function() {
            return No.processedCSS
        }, this.setConsentProfile = function(e) {
            var t, o;
            e.customPayload && null != (t = o = e.customPayload) && t.Interaction && I.writeCookieParam(P.OPTANON_CONSENT, A.INTERACTION_COUNT, o.Interaction), Nr.setDataSubjectIdV2(e.identifier, e.isAnonymous, e.identifierType), Nr.synchroniseCookieWithPayload(e.purposes), g.executeOptanonWrapper()
        }, this.InsertScript = function(e, t, o, n, r, i) {
            var s, a = null != n && void 0 !== n,
                l = a && void 0 !== n.ignoreGroupCheck && !0 === n.ignoreGroupCheck;
            if (y.canInsertForGroup(r, l) && !v.contains(w.srcExecGrps, r)) {
                w.srcExecGrpsTemp.push(r), a && void 0 !== n.deleteSelectorContent && !0 === n.deleteSelectorContent && v.empty(t);
                var c = document.createElement("script");
                switch (null != o && void 0 !== o && (s = !1, c.onload = c.onreadystatechange = function() {
                    s || this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || (s = !0, o())
                }), c.type = "text/javascript", c.src = e, i && (c.async = i), t) {
                    case "head":
                        document.getElementsByTagName("head")[0].appendChild(c);
                        break;
                    case "body":
                        document.getElementsByTagName("body")[0].appendChild(c);
                        break;
                    default:
                        var d = document.getElementById(t);
                        d && (d.appendChild(c), a) && void 0 !== n.makeSelectorVisible && !0 === n.makeSelectorVisible && v.show(t)
                }
                if (a && void 0 !== n.makeElementsVisible)
                    for (var u = 0, p = n.makeElementsVisible; u < p.length; u++) {
                        var C = p[u];
                        v.show(C)
                    }
                if (a && void 0 !== n.deleteElements)
                    for (var g = 0, h = n.deleteElements; g < h.length; g++) {
                        C = h[g];
                        v.remove(C)
                    }
            }
        }, this.InsertHtml = function(e, t, o, n, r) {
            var i = null != n && void 0 !== n,
                s = i && void 0 !== n.ignoreGroupCheck && !0 === n.ignoreGroupCheck;
            if (y.canInsertForGroup(r, s) && !v.contains(w.htmlExecGrps, r)) {
                if (w.htmlExecGrpsTemp.push(r), i && void 0 !== n.deleteSelectorContent && !0 === n.deleteSelectorContent && v.empty(t), v.appendTo(t, e), i && void 0 !== n.makeSelectorVisible && !0 === n.makeSelectorVisible && v.show(t), i && void 0 !== n.makeElementsVisible)
                    for (var a = 0, l = n.makeElementsVisible; a < l.length; a++) {
                        var c = l[a];
                        v.show(c)
                    }
                if (i && void 0 !== n.deleteElements)
                    for (var d = 0, u = n.deleteElements; d < u.length; d++) {
                        c = u[d];
                        v.remove(c)
                    }
                null != o && void 0 !== o && o()
            }
        }, this.BlockGoogleAnalytics = function(e, t) {
            window["ga-disable-" + e] = !y.canInsertForGroup(t)
        }
    }

    function Vr() {}
    Vr.prototype.getFieldsValues = function(e, t, o, n, r) {
        void 0 === r && (r = !1);
        e = this.getSectionFieldsMapping(e), t = this.getSectionFieldsMapping(t, !0), o = this.getDynamicFields(o, n), n = this.getMSPASectionFieldValue(), r = r ? this.getGpcSectionFieldValue() : {};
        return N.IsMSPAEnabled && N.MSPAOptionMode === Ne.MspaServiceProviderMode && k.fp.CookieIABGPPV2 ? this.serviceProviderMode(e, t, o, n, r) : R(R(R(R(R({}, e), t), o), n), r)
    }, Vr.prototype.serviceProviderMode = function(e, t, o, n, r) {
        e = this.getNotApplicableValue(e), t = this.getNotApplicableValue(t), o = this.getNotApplicableValue(o);
        return R(R(R(R(R({}, e), t), o), n), r)
    }, Vr.prototype.getNotApplicableValue = function(e) {
        var o = {};
        return Object.entries(e).forEach(function(e) {
            var t = e[0],
                e = e[1];
            Array.isArray(e) ? o[t] = e.map(function(e) {
                return 0
            }) : o[t] = 0
        }), o
    }, Vr.prototype.getGpcSectionFieldValue = function() {
        var e = {};
        return e[we.GpcSegmentType] = 1, e[we.Gpc] = D.gpcEnabled, e
    }, Vr.prototype.getMSPASectionFieldValue = function() {
        var e = {};
        return N.IsMSPAEnabled ? (e.MspaCoveredTransaction = 1, N.MSPAOptionMode === Ne.MspaServiceProviderMode ? (e.MspaServiceProviderMode = 1, e.MspaOptOutOptionMode = 2) : N.MSPAOptionMode === Ne.MspaOptOutOptionMode ? (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 1) : (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 2)) : (e.MspaCoveredTransaction = 2, e.MspaServiceProviderMode = 0, e.MspaOptOutOptionMode = 0), e
    }, Vr.prototype.getDynamicArrayFieldsValue = function(e, t) {
        for (var o = {}, n = [], r = this.getSectionFieldsMapping(t), i = 1; i <= Object.keys(r).length; i++) n.push(r[e + i]);
        return o[e] = n, o
    }, Vr.prototype.getDynamicFields = function(e, t) {
        var o, n = {};
        return N.IsGPPKnownChildApplicable && e && (o = this.getDynamicArrayFieldsValue(Be.KnownChildSensitiveDataConsents, e), n = R(R({}, n), o)), N.IsGPPDataProcessingApplicable && t && (o = this.getDynamicArrayFieldsValue(Be.SensitiveDataProcessing, t), n = R(R({}, n), o)), n
    }, Vr.prototype.getSectionFieldsMapping = function(e, o) {
        var n = this,
            r = (void 0 === o && (o = !1), {});
        return k.fp, Object.entries(e).forEach(function(e) {
            var t = e[0],
                e = n.evaluateValueOperators(e[1]);
            r[t] = n.calculateFieldValue(e, o)
        }), r
    }, Vr.prototype.evaluateValueOperators = function(e) {
        var t, o, n = "",
            r = [];
        return e && (t = e.split(" && "), o = e.split(" || "), r = (1 < t.length ? (n = "&&", t) : 1 < o.length ? (n = "||", o) : (n = "", [e])).map(function(e) {
            return N.GPPPurposes[e] || ""
        })), {
            values: r,
            operator: n
        }
    }, Vr.prototype.calculateFieldValue = function(e, t) {
        var o;
        if (e.values.length) switch (e.operator) {
            case "&&":
                o = this.calculateAndFieldValue(e.values, t);
                break;
            case "||":
                o = this.calculateOrFieldValue(e.values, t);
                break;
            default:
                o = this.calculateSingleFieldValue(e.values[0], t)
        } else o = 0;
        return o
    }, Vr.prototype.calculateOrFieldValue = function(e, t) {
        var o = this;
        return this.isNotApplicable(e) ? 0 : (e = e.filter(function(e) {
            return "" !== e.trim()
        }).some(function(e) {
            return o.fieldValueCondition(e, t)
        }), this.calculateFieldValueFromBit(e, t))
    }, Vr.prototype.calculateAndFieldValue = function(e, t) {
        var o = this;
        return this.isNotApplicable(e) ? 0 : (e = e.every(function(e) {
            return o.fieldValueCondition(e, t)
        }), this.calculateFieldValueFromBit(e, t))
    }, Vr.prototype.calculateSingleFieldValue = function(e, t) {
        return e && this.isValidGroup(e) ? (e = this.fieldValueCondition(e, t), this.calculateFieldValueFromBit(e, t)) : 0
    }, Vr.prototype.isValidGroup = function(e) {
        e = e ? L.getGroupById(e) : null;
        return !!e && D.isValidConsentNoticeGroup(e, N.IsIabEnabled)
    }, Vr.prototype.calculateFieldValueFromBit = function(e, t) {
        t = t ? e ? 1 : 0 : e ? 2 : 1;
        return t
    }, Vr.prototype.isNotApplicable = function(e) {
        var t = this;
        return !e.some(function(e) {
            return Boolean(e) && t.isValidGroup(e)
        })
    }, Vr.prototype.fieldValueCondition = function(e, t) {
        return t ? Boolean(e) : Nr.isCategoryActive(e)
    }, x(Mr, Gr = V = Vr), Mr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(bo, Lo, Eo, Oo, !0)
    };
    var Gr, xr, Hr, Rr, Fr = Mr;

    function Mr() {
        return null !== Gr && Gr.apply(this, arguments) || this
    }(l = xr = xr || {}).SaleOptOut = "SaleOptOutCID", l.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (l = Hr = Hr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = Rr = Rr || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(Kr, Ur = V), Kr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(xr, Hr, null, Rr, !1)
    };
    var Ur, qr, jr = Kr;

    function Kr() {
        return null !== Ur && Ur.apply(this, arguments) || this
    }(l = qr = qr || {}).Version = "version", l.CmpId = "cmpId", l.CmpVersion = "cmpVersion", l.ConsentScreen = "consentScreen", l.ConsentLanguage = "consentLanguage", l.VendorListVersion = "vendorListVersion", l.PolicyVersion = "policyVersion", l.IsServiceSpecific = "isServiceSpecific", l.UseNonStandardStacks = "useNonStandardTexts", l.PurposeOneTreatment = "purposeOneTreatment", l.PublisherCountryCode = "publisherCountryCode", l.NumCustomPurposes = "numCustomPurposes", l.VendorsAllowedSegmentType = "VendorsAllowedSegmentType", l.VendorsDisclosedSegmentType = "VendorsDisclosedSegmentType", l.PublisherPurposesSegmentType = "PublisherPurposesSegmentType", Qr.prototype.getSectionFieldsValues = function() {
        for (var e = {}, t = 0, o = Object.keys(qr); t < o.length; t++) {
            var n = o[t],
                r = qr[n];
            p.tcModel && p.tcModel[r] && (e[n] = p.tcModel[r])
        }
        e.ConsentLanguage = null == (i = e.ConsentLanguage) ? void 0 : i.toString().toUpperCase();
        var i = this.setPurposesData();
        return R(R({}, e), i)
    }, Qr.prototype.setPurposesData = function() {
        var o, e = {},
            t = p.oneTrustIABConsent,
            n = this.getConsentValuesFromPurpose(t.purpose),
            n = (e.PurposeConsents = n, e.PublisherConsents = n, D.legIntSettings.PAllowLI ? this.getConsentValuesFromPurpose(t.legimateInterest) : []);
        return e.PurposeLegitimateInterests = n, e.PublisherLegitimateInterests = n, e.VendorConsents = this.syncVendorConsent(p.tcModel.vendorConsents), D.legIntSettings.PAllowLI && !n.length && (t.legIntVendors = []), e.VendorLegitimateInterests = this.getConsentValuesFromPurpose(v.distinctArray(t.legIntVendors), !0, !0), e.SpecialFeatureOptins = this.getConsentValuesFromPurpose(t.specialFeatures), null != (t = null == (n = p.tcModel) ? void 0 : n.vendorsDisclosed) && t.size && (o = [], p.tcModel.vendorsDisclosed.forEach(function(e, t) {
            e && o.push(t)
        }), o.length) && (e.VendorsDisclosedSegmentType = 1, e.VendorsDisclosed = o), e
    }, Qr.prototype.syncVendorConsent = function(e) {
        var e = e.clone(),
            o = [];
        return e.forEach(function(e, t) {
            p.vendorsSetting[t] && p.vendorsSetting[t].consent || !e || o.push(t)
        }), e.unset(o), Array.from(e.values())
    }, Qr.prototype.getConsentValuesFromPurpose = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = !1), e = e.map(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1];
            return {
                id: Number(t),
                val: e
            }
        }).sort(function(e, t) {
            return e.id - t.id
        }).map(function(e) {
            return e.id + ":" + e.val
        }), o && (e = e.filter(function(e) {
            return "true" === e.split(":")[1]
        }));
        var n = t ? 0 : 1;
        return t ? e.map(function(e) {
            return parseInt(e.split(":")[n])
        }) : e.map(function(e) {
            return "true" === e.split(":")[n]
        })
    };
    var zr, Wr, Yr, Jr, Xr = Qr;

    function Qr() {}(l = zr = zr || {}).SaleOptOut = "SaleOptOutCID", l.SharingOptOut = "SharingOptOutCID", l.PersonalDataConsents = "PersonalDataCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (l = Wr = Wr || {}).SharingNotice = "SharingOptOutCID", l.SaleOptOutNotice = "SaleOptOutCID", l.SharingOptOutNotice = "SharingOptOutCID", l.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID || ConsumerHealthCID || CrimeVictimCID || NationalOriginCID || TransgenderCID", l.SensitiveDataLimitUseNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID || ConsumerHealthCID || CrimeVictimCID || NationalOriginCID || TransgenderCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = Yr = Yr || {}).KnownChildSensitiveDataConsents1 = "PDCAboveAgeCID", l.KnownChildSensitiveDataConsents2 = "PDCBelowAgeCID", l.KnownChildSensitiveDataConsents3 = "KnownChildProcessAge16To17CID", (l = Jr = Jr || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", l.SensitiveDataProcessing9 = "SensitivePICID", l.SensitiveDataProcessing10 = "SensitiveSICID", l.SensitiveDataProcessing11 = "UnionMembershipCID", l.SensitiveDataProcessing12 = "CommunicationCID", l.SensitiveDataProcessing13 = "ConsumerHealthCID", l.SensitiveDataProcessing14 = "CrimeVictimCID", l.SensitiveDataProcessing15 = "NationalOriginCID", l.SensitiveDataProcessing16 = "TransgenderCID", x(ni, Zr = V), ni.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(zr, Wr, Yr, Jr, !0)
    };
    var Zr, $r, ei, ti, oi = ni;

    function ni() {
        return null !== Zr && Zr.apply(this, arguments) || this
    }(l = $r = $r || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", l.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (l = ei = ei || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = ti = ti || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", x(di, ri = V), di.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues($r, ei, null, ti, !0)
    };
    var ri, ii, si, ai, li, ci = di;

    function di() {
        return null !== ri && ri.apply(this, arguments) || this
    }(l = ii = ii || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (l = si = si || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = ai = ai || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", l.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", l.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (l = li = li || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(fi, ui = V), fi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ii, si, ai, li, !0)
    };
    var ui, pi, Ci, gi, hi, yi = fi;

    function fi() {
        return null !== ui && ui.apply(this, arguments) || this
    }(l = pi = pi || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", l.AdditionalDataProcessingConsent = "PersonalDataCID", (l = Ci = Ci || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = gi = gi || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", l.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", l.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (l = hi = hi || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(Pi, Si = V), Pi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(pi, Ci, gi, hi, !0)
    };
    var Si, mi, vi, Ti, Ai = Pi;

    function Pi() {
        return null !== Si && Si.apply(this, arguments) || this
    }(l = mi = mi || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", l.AdditionalDataProcessingConsent = "PersonalDataCID", l.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (l = vi = vi || {}).ProcessingNotice = "PersonalDataCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = Ti = Ti || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(_i, ki = V), _i.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(mi, vi, null, Ti, !0)
    };
    var ki, Ii, bi, Li, Ei, Oi = _i;

    function _i() {
        return null !== ki && ki.apply(this, arguments) || this
    }(l = Ii = Ii || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (i = bi = bi || {}).ProcessingNotice = l.AdditionalDataProcessingConsent = "PersonalDataCID", i.SaleOptOutNotice = "SaleOptOutCID", i.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = Li = Li || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessBelowAge13CID", l.KnownChildSensitiveDataConsents2 = "KnownChildProcessBetweenAge13To16CID", l.KnownChildSensitiveDataConsents3 = "KnownChildProcessBetweenAge16To18CID", (i = Ei = Ei || {}).SensitiveDataProcessing1 = "RaceCID", i.SensitiveDataProcessing2 = "ReligionCID", i.SensitiveDataProcessing3 = "HealthCID", i.SensitiveDataProcessing4 = "SexualOrientationCID", i.SensitiveDataProcessing5 = "ImmigrationCID", i.SensitiveDataProcessing6 = "GeneticCID", i.SensitiveDataProcessing7 = "BiometricCID", i.SensitiveDataProcessing8 = "GeolocationCID", x(xi, Di = V), xi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ii, bi, Li, Ei, !1)
    };
    var Di, Ni, wi, Bi, Vi, Gi = xi;

    function xi() {
        return null !== Di && Di.apply(this, arguments) || this
    }(l = Ni = Ni || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (i = wi = wi || {}).ProcessingNotice = l.AdditionalDataProcessingConsent = "PersonalDataCID", i.SaleOptOutNotice = "SaleOptOutCID", i.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = Bi = Bi || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", l.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", l.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", l.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To18CID", l.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To18CID", (i = Vi = Vi || {}).SensitiveDataProcessing1 = "RaceCID", i.SensitiveDataProcessing2 = "ReligionCID", i.SensitiveDataProcessing3 = "HealthCID", i.SensitiveDataProcessing4 = "SexualOrientationCID", i.SensitiveDataProcessing5 = "ImmigrationCID", i.SensitiveDataProcessing6 = "GeneticCID", i.SensitiveDataProcessing7 = "BiometricCID", i.SensitiveDataProcessing8 = "GeolocationCID", i.SensitiveDataProcessing9 = "TransgenderCID", x(qi, Hi = V), qi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ni, wi, Bi, Vi, !0)
    };
    var Hi, Ri, Fi, Mi, Ui = qi;

    function qi() {
        return null !== Hi && Hi.apply(this, arguments) || this
    }(l = Ri = Ri || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", l.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (i = Fi = Fi || {}).ProcessingNotice = "AdditionalDataCID", i.SaleOptOutNotice = "SaleOptOutCID", i.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", i.SensitiveDataOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID", (l = Mi = Mi || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(Ji, ji = V), Ji.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ri, Fi, null, Mi, !0)
    };
    var ji, Ki, zi, Wi, Yi = Ji;

    function Ji() {
        return null !== ji && ji.apply(this, arguments) || this
    }(i = Ki = Ki || {}).SaleOptOut = "SaleOptOutCID", i.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", i.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (l = zi = zi || {}).ProcessingNotice = i.AdditionalDataProcessingConsent = "PersonalDataCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (i = Wi = Wi || {}).SensitiveDataProcessing1 = "RaceCID", i.SensitiveDataProcessing2 = "ReligionCID", i.SensitiveDataProcessing3 = "HealthCID", i.SensitiveDataProcessing4 = "SexualOrientationCID", i.SensitiveDataProcessing5 = "ImmigrationCID", i.SensitiveDataProcessing6 = "GeneticCID", i.SensitiveDataProcessing7 = "BiometricCID", i.SensitiveDataProcessing8 = "GeolocationCID", x(ts, Xi = V), ts.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ki, zi, null, Wi, !0)
    };
    var Xi, Qi, Zi, $i, es = ts;

    function ts() {
        return null !== Xi && Xi.apply(this, arguments) || this
    }(l = Qi = Qi || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", l.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (i = Zi = Zi || {}).ProcessingNotice = l.AdditionalDataProcessingConsent = "PersonalDataCID", i.SaleOptOutNotice = "SaleOptOutCID", i.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (l = $i = $i || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(ls, os = V), ls.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Qi, Zi, null, $i, !0)
    };
    var os, ns, rs, is, ss, as = ls;

    function ls() {
        return null !== os && os.apply(this, arguments) || this
    }(i = ns = ns || {}).SaleOptOut = "SaleOptOutCID", i.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (l = rs = rs || {}).ProcessingNotice = i.AdditionalDataProcessingConsent = "PersonalDataCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (i = is = is || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", i.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", i.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", i.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To17CID", i.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To17CID", (l = ss = ss || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", l.SensitiveDataProcessing9 = "TransgenderCID", l.SensitiveDataProcessing10 = "SensitiveSICID", x(hs, cs = V), hs.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ns, rs, is, ss, !0)
    };
    var cs, ds, us, ps, Cs, gs = hs;

    function hs() {
        return null !== cs && cs.apply(this, arguments) || this
    }(i = ds = ds || {}).SaleOptOut = "SaleOptOutCID", i.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (l = us = us || {}).ProcessingNotice = i.AdditionalDataProcessingConsent = "PersonalDataCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (i = ps = ps || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", i.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", i.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (l = Cs = Cs || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "ImmigrationCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(Ts, ys = V), Ts.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ds, us, ps, Cs, !0)
    };
    var ys, fs, Ss, ms, vs = Ts;

    function Ts() {
        return null !== ys && ys.apply(this, arguments) || this
    }(i = fs = fs || {}).SaleOptOut = "SaleOptOutCID", i.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", i.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (l = Ss = Ss || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (i = ms = ms || {}).SensitiveDataProcessing1 = "RaceCID", i.SensitiveDataProcessing2 = "ReligionCID", i.SensitiveDataProcessing3 = "SexualOrientationCID", i.SensitiveDataProcessing4 = "ImmigrationCID", i.SensitiveDataProcessing5 = "HealthCID", i.SensitiveDataProcessing6 = "GeneticCID", i.SensitiveDataProcessing7 = "BiometricCID", i.SensitiveDataProcessing8 = "GeolocationCID", x(Ls, As = V), Ls.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(fs, Ss, null, ms, !1)
    };
    var As, Ps, ks, Is, bs = Ls;

    function Ls() {
        return null !== As && As.apply(this, arguments) || this
    }(l = Ps = Ps || {}).SaleOptOut = "SaleOptOutCID", l.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", l.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (i = ks = ks || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", i.SaleOptOutNotice = "SaleOptOutCID", i.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", i.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || SexualOrientationCID || ImmigrationCID || HealthCID || GeneticCID || BiometricCID || GeolocationCID", (l = Is = Is || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "SexualOrientationCID", l.SensitiveDataProcessing4 = "ImmigrationCID", l.SensitiveDataProcessing5 = "HealthCID", l.SensitiveDataProcessing6 = "GeneticCID", l.SensitiveDataProcessing7 = "BiometricCID", l.SensitiveDataProcessing8 = "GeolocationCID", x(_s, Es = V), _s.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ps, ks, null, Is, !1)
    };
    var Es, Os = _s;

    function _s() {
        return null !== Es && Es.apply(this, arguments) || this
    }(i = Ds = Ds || {}).SaleOptOut = "SaleOptOutCID", i.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (l = Ns = Ns || {}).ProcessingNotice = i.AdditionalDataProcessingConsent = "PersonalDataCID", l.SaleOptOutNotice = "SaleOptOutCID", l.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (i = ws = ws || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", i.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", i.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (l = Bs = Bs || {}).SensitiveDataProcessing1 = "RaceCID", l.SensitiveDataProcessing2 = "ReligionCID", l.SensitiveDataProcessing3 = "HealthCID", l.SensitiveDataProcessing4 = "SexualOrientationCID", l.SensitiveDataProcessing5 = "TransgenderCID", l.SensitiveDataProcessing6 = "ImmigrationCID", l.SensitiveDataProcessing7 = "NationalOriginCID", l.SensitiveDataProcessing8 = "CrimeVictimCID", l.SensitiveDataProcessing9 = "GeneticCID", l.SensitiveDataProcessing10 = "BiometricCID", l.SensitiveDataProcessing11 = "GeolocationCID", x(xs, Vs = V), xs.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ds, Ns, ws, Bs, !0)
    };
    var Ds, Ns, ws, Bs, Vs, Gs = xs;

    function xs() {
        return null !== Vs && Vs.apply(this, arguments) || this
    }
    Fs.prototype.initGppConsent = function() {
        this.initTemplateAndSectionInstance(), this.cmpApi.setApplicableSections(this.getApplicableSections(this.gppTemplateApplied));
        var o, n, e = this.readGppCookies(),
            t = this.getCurrentSectionName(this.gppTemplateApplied),
            r = !1;
        this.gppSectionId = this.getCurrentSectionId(this.gppTemplateApplied), e && (ta.needReconsent() ? this.deleteAllGppCookies() : (this.cmpApi.setGppString(e), r = !0)), this.cmpApi.setSupportedAPIs((o = [], n = {}, Object.keys(Ge).forEach(function(e) {
            var t = {},
                e = (t[e] = Ge[e], Object.assign(t, n));
            n = e
        }), Object.keys(Ve).map(function(e) {
            return {
                name: e,
                value: Ve[e]
            }
        }).forEach(function(e) {
            e = n[e.name] + ":" + e.value;
            o.push(e)
        }), o.filter(function(e, t) {
            return o.indexOf(e) === t
        }))), this.cmpApi.setCmpStatus(null == (e = this.gppSDKRef) ? void 0 : e.cmpStatus.LOADED), (t && !this.cmpApi.hasSection(t) || D.gpcBrowserValueChanged || p.grpsSynced && 0 < p.grpsSynced.length) && this.setOrUpdateGppSectionString(t, r), window.OneTrust.OnConsentChanged(this.updateGppConsentString), this.cmpApi.setSignalStatus(null == (e = this.gppSDKRef) ? void 0 : e.signalStatus.READY)
    }, Fs.prototype.initTemplateAndSectionInstance = function() {
        var e = k.fp;
        e && e.CookieIABGPPV2 ? this.gppTemplateApplied = this.getTemplateTypeByLocation() : this.gppTemplateApplied = this.getGppTemplateApplied(), this.gppSection = this.getSectionInstance(this.gppTemplateApplied)
    }, Fs.prototype.setCmpDisplayStatus = function(e) {
        var t;
        "visible" === e ? this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.VISIBLE) : "hidden" === e ? this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.HIDDEN) : "disabled" === e && this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.DISABLED)
    }, Fs.prototype.setGppCookies = function(e, t) {
        t ? this.updateGppCookies(e) : (t = this.getCookiesChunk(e), e = Object.keys(t).length, this.writeGppCookies(e, t))
    }, Fs.prototype.readGppCookies = function() {
        var e = Number(I.readCookieParam(P.OPTANON_CONSENT, De.ChunkCountParam) || 0);
        if (e <= 1) return 0 === e ? "" : I.getCookie(P.GPP_CONSENT);
        for (var t = "", o = 1; o <= e; o++) var n = I.getCookie("" + De.Name + o),
            t = t.concat(n);
        return t
    }, Fs.prototype.deleteGppCookies = function(e, t) {
        if (0 < e && (1 === e && (I.setCookie("" + De.Name, "", 0, !0), e++), e <= t))
            for (var o = e; o <= t; o++) I.setCookie("" + De.Name + o, "", 0, !0)
    }, Fs.prototype.getSectionInstance = function(e) {
        var t;
        switch (e) {
            case Oe.CPRA:
            case Oe.CCPA:
                t = new Fr;
                break;
            case Oe.CDPA:
                t = new jr;
                break;
            case Oe.USNATIONAL:
                t = new oi;
                break;
            case Oe.COLORADO:
                t = new ci;
                break;
            case Oe.OREGON:
                t = new Gs;
                break;
            case Oe.FLORIDA:
                t = new Gi;
                break;
            case Oe.CONNECTICUT:
                t = new yi
        }
        return t = ["MONTANA", "TEXAS", "DELAWARE", "NEBRASKA", "IOWA", "TENNESSEE", "NEWJERSEY", "NEWHAMPSHIRE", "UCPA", "VIRGINIA", "IAB2V2"].includes(e) ? this.getSectionInstanceByTempType(e) : t
    }, Fs.prototype.getSectionInstanceByTempType = function(e) {
        var t;
        switch (e) {
            case Oe.MONTANA:
                t = new Ai;
                break;
            case Oe.TEXAS:
                t = new Oi;
                break;
            case Oe.DELAWARE:
                t = new Ui;
                break;
            case Oe.IOWA:
                t = new Yi;
                break;
            case Oe.NEBRASKA:
                t = new es;
                break;
            case Oe.TENNESSEE:
                t = new as;
                break;
            case Oe.NEWJERSEY:
                t = new gs;
                break;
            case Oe.NEWHAMPSHIRE:
                t = new vs;
                break;
            case Oe.UCPA:
                t = new Os;
                break;
            case Oe.VIRGINIA:
                t = new bs;
                break;
            case Oe.IAB2V2:
                t = new Xr
        }
        return t
    }, Fs.prototype.getTemplateTypeByLocation = function() {
        var e;
        return D.getRegionRuleType() === Oe.IAB2V2 ? Oe.IAB2V2 : !N.UseGPPUSNational && "us" === (e = Nr.getGeolocationData()).country.toLocaleLowerCase() && He[e.state.toLocaleLowerCase()] || Oe.USNATIONAL
    }, Fs.prototype.hasGPPSection = function() {
        return !!this.gppSection
    }, Fs.prototype.getGppTemplateApplied = function() {
        return N.UseGPPUSNational ? Oe.USNATIONAL : D.getRegionRuleType()
    }, Fs.prototype.initGppSDK = function() {
        var e, t = Number.parseInt((null == (t = k.moduleInitializer.GppData) ? void 0 : t.cmpId) || "28");
        return null == (e = this.gppSDKRef) ? void 0 : e.gppCmpApi(t, 1.1)
    }, Fs.prototype.setOrUpdateGppSectionString = function(o, e) {
        var n = this,
            t = this.gppSection.getSectionFieldsValues();
        Object.entries(t).forEach(function(e) {
            var t = e[0];
            n.cmpApi.setFieldValue(o, t, e[1])
        }), this.cmpApi.fireSectionChange(o), this.setGppCookies(this.cmpApi.getGppString(), e)
    }, Fs.prototype.getCurrentSectionName = function(t) {
        var e, o = "",
            n = Object.entries(Ve).find(function(e) {
                return e[0] === t
            });
        return o = null != (e = n) && e.length && 1 < n.length ? n[1] : o
    }, Fs.prototype.getCurrentSectionId = function(t) {
        var e, o = 0,
            n = Object.entries(Ge).find(function(e) {
                return e[0] === t
            });
        return o = null != (e = n) && e.length && 1 < n.length ? n[1] : o
    }, Fs.prototype.updateGppCookies = function(e) {
        var e = this.getCookiesChunk(e),
            t = Object.keys(e).length,
            o = Number(I.readCookieParam(P.OPTANON_CONSENT, De.ChunkCountParam) || 0);
        this.writeGppCookies(t, e), t < o && this.deleteGppCookies(t + 1, o)
    }, Fs.prototype.deleteAllGppCookies = function() {
        var e = Number(I.readCookieParam(P.OPTANON_CONSENT, De.ChunkCountParam) || 0);
        this.deleteGppCookies(1, e)
    }, Fs.prototype.getCookiesChunk = function(e) {
        for (var t = {}, o = !1, n = e, r = 1; n.length;) {
            var i, s = void 0;
            n.length > De.ChunkSize ? s = De.ChunkSize : (s = n.length, o = 1 === r), o ? (t[De.Name] = n, n = "") : (i = n.slice(0, s), n = n.slice(s, n.length), t["" + De.Name + r] = i), r++
        }
        return t
    }, Fs.prototype.writeGppCookies = function(e, t) {
        I.writeCookieParam(P.OPTANON_CONSENT, De.ChunkCountParam, e), I.writeCookieParam(P.OPTANON_CONSENT, De.gppSid, this.gppSectionId);
        for (var o = 0, n = Object.entries(t); o < n.length; o++) {
            var r = n[o],
                i = r[0];
            I.setCookie(i, r[1], N.ReconsentFrequencyDays)
        }
    }, Fs.prototype.getSupportedAPIs = function() {
        return Object.values(Ve).filter(function(e, t, o) {
            return o.indexOf(e) === t
        })
    }, Fs.prototype.getApplicableSections = function(e) {
        return [this.getCurrentSectionId(e)]
    };
    var Hs, Rs = Fs;

    function Fs() {
        var e, t = this;
        this.gppSDKRef = null == (e = window.otIabModule) ? void 0 : e.gppSdkRef, this.cmpApi = this.initGppSDK(), this.updateGppConsentString = function() {
            t.cmpApi.getCmpDisplayStatus() === (null == (e = t.gppSDKRef) ? void 0 : e.displayStatus.VISIBLE) && t.cmpApi.setCmpDisplayStatus(null == (e = t.gppSDKRef) ? void 0 : e.displayStatus.HIDDEN);
            var e = t.getCurrentSectionName(t.gppTemplateApplied);
            t.setOrUpdateGppSectionString(e, !0)
        }
    }
    qs.prototype.isAuthUsr = function(e) {
        var t = I.readCookieParam(P.OPTANON_CONSENT, A.IS_ANONYMOUS_CONSENT);
        w.consentPreferences || "1" !== t ? I.writeCookieParam(P.OPTANON_CONSENT, "iType", "") : I.writeCookieParam(P.OPTANON_CONSENT, "iType", "" + Ce[e])
    }, qs.prototype.isBannerClosedByIconOrLink = function() {
        var e = w.bannerCloseSource;
        return e === ee.BannerCloseButton || e === ee.ContinueWithoutAcceptingButton
    }, qs.prototype.addCrossDeviceAttributes = function(e) {
        w.isV2Stub && (e.syncGroup = w.syncGrpId, N.UseGoogleVendors) && (e.gacString = I.getCookie(P.ADDITIONAL_CONSENT_STRING))
    }, qs.prototype.addAdvAnalyticsAttributes = function(e, t) {
        var o, n = L.getGroupById(N.AdvancedAnalyticsCategory);
        n && this.canSendAdvancedAnalytics(e.purposes, n) && (o = window.navigator.userAgent, e.dsDataElements = {
            InteractionType: t,
            Country: w && w.userLocation && /^[a-zA-Z]{2}$/.test(w.userLocation.country) ? w.userLocation.country.toUpperCase() : "",
            UserAgent: o,
            ConsentModel: N.ConsentModel.Name
        }, e.source = {
            purposeIds: [n.PurposeId],
            content: window.location.href,
            type: "WEB"
        }, this.addGeolocationAttributes(e, n))
    }, qs.prototype.addGeolocationAttributes = function(e, t) {
        var o = w.userLocation;
        o && (e.geolocation = {
            country: o.country.toUpperCase(),
            state: o.state,
            stateName: o.stateName || "",
            purposeIds: t ? [t.PurposeId] : []
        })
    }, qs.prototype.shouldCreateForceReceipt = function() {
        var e, t = I.readCookieParam(P.OPTANON_CONSENT, A.FORCE_CONSENT_COOLOFF);
        return !(t && 2 === (t = t.split("_")).length && (e = parseInt(t[0], 10), t = 1e3 * parseInt(t[1], 10), !isNaN(e)) && !isNaN(t)) || (e = 1 === e ? 1 : 2 === e ? 2 : 7, Date.now() >= t + 864e5 * e)
    }, qs.prototype.recordForceReceiptSent = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, A.FORCE_CONSENT_COOLOFF),
            t = 1,
            e = (e && 2 === (e = e.split("_")).length && (e = parseInt(e[0], 10), isNaN(e) || (t = Math.min(e + 1, 3))), Math.floor(Date.now() / 1e3));
        I.writeCookieParam(P.OPTANON_CONSENT, A.FORCE_CONSENT_COOLOFF, t + "_" + e)
    }, qs.prototype.resetForceReceiptCooloff = function() {
        I.writeCookieParam(P.OPTANON_CONSENT, A.FORCE_CONSENT_COOLOFF, "")
    }, qs.prototype.canSendConsentReceipt = function(e, t, o) {
        return h.updateIntTypeFromCookie(), !(!e && D.apiSource !== oe.UpdateConsent && w.consentInteractionType === t && !o && !(w.consentInteractionType === t && this.isConsentReceiptCoolingPeriodOver() || w.makeInitialTxnCall))
    }, qs.prototype.isConsentReceiptCoolingPeriodOver = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, A.LAST_CONSENT_RECEIPT, !0) || void 0,
            t = Date.now();
        return !e || t - e >= this.MIN_INTERVAL_BETWEEN_CALLS || (this.MIN_INTERVAL_BETWEEN_CALLS, !1)
    }, qs.prototype.addGppStringAttribute = function(e) {
        N.IsGPPEnabled && Hs.hasGPPSection() && Hs.updateGppConsentString();
        var t = I.getCookie(P.GPP_CONSENT);
        t && (e.gppString = t)
    }, qs.prototype.addConsentStringToPayload = function(e) {
        var t = I.getMergedCookieByName(P.EU_PUB_CONSENT),
            o = D.getRegionRuleType();
        (D.isIab2orv2Template || "IABC" === o) && t ? e.consentString = {
            type: "IABC" === o ? "tcfcanada" : "IAB2" !== o && "IAB2V2" !== o ? "" : "tcfeu",
            content: t
        } : N.IsGPPEnabled && e.hasOwnProperty("gppString") && e.gppString && (e.consentString = {
            type: "gpp",
            content: e.gppString
        }, delete e.gppString)
    }, qs.prototype.createConsentTxn = function(e, t, o, n, r, i) {
        void 0 === t && (t = ""), void 0 === o && (o = !1), void 0 === i && (i = "");
        var s = this.ensureConsentId(e, n = void 0 === n ? !0 : n, r = void 0 === r ? !1 : r),
            a = N.ConsentIntegration,
            l = this.getConsentURL(s.isAnonymous),
            c = this.canCreateConsentReceiptTxn(s, e);
        if (w.isV2Stub && t && this.isAuthUsr(t), c) {
            c = k.moduleInitializer, s = (Ms.noOptOutToogle = c.TenantFeatures.CookieV2NoOptOut, Ms.isCloseByIconOrLink = this.isBannerClosedByIconOrLink(), {
                requestInformation: a.RequestInformation,
                identifier: s.id,
                identifierType: s.identifierType,
                customPayload: {
                    Interaction: s.count,
                    AddDefaultInteraction: s.addDfltInt
                },
                isAnonymous: s.isAnonymous,
                test: c.ScriptType === je.TEST || c.ScriptType === je.LOCAL_TEST,
                purposes: this.getConsetPurposes(e, i, t),
                dsDataElements: {}
            });
            if (this.handleReceiptsWhenSendReceiptIsEnabled(s, r, t), this.addCrossDeviceAttributes(s), this.addAdvAnalyticsAttributes(s, t), this.addGppStringAttribute(s), this.addConsentStringToPayload(s), !c.MobileSDK && n && s.purposes.length) {
                i = JSON.stringify(s), c = this.getAuthToken();
                if (this.sendBeaconSupported(e, c)) {
                    n = navigator.sendBeacon(l, i);
                    try {
                        n && I.writeCookieParam(P.OPTANON_CONSENT, A.LAST_CONSENT_RECEIPT, Date.now())
                    } catch (e) {
                        console.info("[ConsentReceipt] sendBeacon logging error", e)
                    }
                    B.dispatchConsentEvent()
                } else this.canSendConsentReceipt(o, t, r) && S.ajax({
                    url: l,
                    type: "post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(s),
                    sync: e,
                    success: function() {
                        B.dispatchConsentEvent();
                        try {
                            I.writeCookieParam(P.OPTANON_CONSENT, A.LAST_CONSENT_RECEIPT, Date.now()), w.makeInitialTxnCall = !1
                        } catch (e) {
                            console.info("[ConsentReceipt] signature/timestamp logging error", e)
                        }
                    },
                    error: function() {
                        B.dispatchConsentEvent()
                    },
                    token: c
                })
            }
            D.pubDomainData.ConsentIntegrationData = {
                consentApi: a.ConsentApi,
                consentPayload: s
            }
        }
        w.consentInteractionType = t, this.storeInteractionType(t)
    }, qs.prototype.canCreateConsentReceiptTxn = function(e, t) {
        var o = N.ConsentIntegration,
            n = this.getConsentURL(e.isAnonymous),
            r = window.navigator.userAgent,
            r = /OneTrust/.test(r),
            i = w.isBotHeader && w.isBotHeaderDomain && e.isAnonymous;
        return n && o.RequestInformation && e.id && !r && !i && !this.blockDefaultReceiptCall(t)
    }, qs.prototype.getConsentURL = function(e) {
        var t = N.ConsentIntegration,
            o = t.ConsentApi,
            n = k.moduleInitializer.TenantFeatures;
        return n && n.CookieV2NewConsentReceiptAPI && (e && t.AnonymousConsentApi ? o = t.AnonymousConsentApi : w.isV2Stub && t.CROConsentApi && (o = t.CROConsentApi)), o
    }, qs.prototype.blockDefaultReceiptCall = function(e) {
        return !!e && !!k.fp.CMPNotGiven && !N.CanGenerateNotGivenReceipts
    }, qs.prototype.ensureConsentId = function(e, t, o) {
        void 0 === o && (o = !1);
        var n, r = !1,
            i = this.getIdenTypeAndIsAnonAttr(),
            s = i.isAnonymous,
            i = i.identifierType,
            e = e || !t || o ? 0 : (r = !0, 1),
            a = I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID, !0),
            t = (a ? (n = parseInt(I.readCookieParam(P.OPTANON_CONSENT, A.INTERACTION_COUNT), 10), isNaN(n) || (t && !o && ++n, e = n, r = !1)) : (a = v.generateUUID(), I.writeCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID, a)), I.writeCookieParam(P.OPTANON_CONSENT, A.INTERACTION_COUNT, e), I.writeCookieParam(P.OPTANON_CONSENT, A.IS_ANONYMOUS_CONSENT, s ? "1" : "0"), !!w.dsParams.token);
        return I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_HAD_TOKEN, t ? "1" : "0"), {
            id: a,
            count: e,
            addDfltInt: r,
            identifierType: i,
            isAnonymous: s
        }
    }, qs.prototype.getIdenTypeAndIsAnonAttr = function() {
        var e = !0,
            t = I.readCookieParam(P.OPTANON_CONSENT, A.IDENTIFIER_TYPE, !1),
            o = t,
            n = (!1 !== (null == (n = N.ConsentIntegration) ? void 0 : n.IdentifiedReceiptsAllowed) && w.isV2Stub || (e = !0, o = null == (n = N.ConsentIntegration) ? void 0 : n.DefaultAnonymousIdentifier), (w.isV2Stub || null != (n = N.ConsentIntegration) && n.IdentifiedReceiptsAllowed && !w.isV2Stub) && (e = (n = this.setAnonymityBasedOnKnownUserOrNot(e, o)).isAnonymous, o = n.idTypeUpdated), w.dsParams);
        return n.forceUserConsentAttributes && (n && n.hasOwnProperty("isAnonymous") && (e = n.isAnonymous), t) && !1 !== (null == (n = N.ConsentIntegration) ? void 0 : n.IdentifiedReceiptsAllowed) && (o = t), {
            isAnonymous: e,
            identifierType: o
        }
    }, qs.prototype.setAnonymityBasedOnKnownUserOrNot = function(e, t) {
        var o, n = "",
            n = null != (o = w.dsParams) && o.id ? (e = !1, null != (o = t) && o.trim().length ? t : null == (o = N.ConsentIntegration) ? void 0 : o.DefaultIdentifier) : (e = !0, null == (t = N.ConsentIntegration) ? void 0 : t.DefaultAnonymousIdentifier);
        return {
            isAnonymous: e,
            idTypeUpdated: n
        }
    }, qs.prototype.storeInteractionType = function(e) {
        if (null != e) {
            var t;
            if ("number" == typeof e) isNaN(e) || (t = e);
            else if ("string" == typeof e) {
                e = e.trim();
                if (!e) return;
                var o = Number(e);
                isNaN(o) ? "number" == typeof(e = Ce[e]) && (t = e) : t = o
            }
            e = Object.values(Ce).filter(function(e) {
                return "number" == typeof e
            });
            void 0 !== t && e.includes(t) && I.writeCookieParam(P.OPTANON_CONSENT, A.INTERACTION_TYPE, t)
        }
    }, qs.prototype.getAuthToken = function() {
        var e = null;
        return e = N.ConsentIntegration.EnableJWTAuthForKnownUsers && w.dsParams.id && w.dsParams.token ? w.dsParams.token : e
    }, qs.prototype.sendBeaconSupported = function(e, t) {
        return e && navigator.sendBeacon && !t
    }, qs.prototype.handleReceiptsWhenSendReceiptIsEnabled = function(e, t, o) {
        !w.isV2Stub && t && ((t = I.getCookie(P.ALERT_BOX_CLOSED)) && (e.interactionDate = t), o && (e.InteractionType = o), e.enableDataElementDateValidation = !0)
    }, qs.prototype.getGrpDetails = function(e, o) {
        var n = [];
        return e.forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = "true" === e[1] ? "1" : "0",
                t = Ms.getOptanonIdForIabGroup(t, o);
            n.push(t + ":" + e)
        }), n
    }, qs.prototype.getOptanonIdForIabGroup = function(e, t) {
        var o;
        return t === ne.Purpose ? o = b.IdPatterns.Pur + e : t === ne.SpecialFeature && (o = b.IdPatterns.Spl_Ft + e), o
    }, qs.prototype.getConsetPurposes = function(n, r, i) {
        var s = this,
            a = [],
            e = [],
            t = w.oneTrustIABConsent,
            o = t && t.purpose ? this.getGrpDetails(t.purpose, ne.Purpose) : [],
            l = t && t.specialFeatures ? this.getGrpDetails(t.specialFeatures, ne.SpecialFeature) : [],
            e = U(t.specialPurposes, t.features);
        return U(w.groupsConsent, o, l).forEach(function(e) {
            var t, e = e.split(":"),
                o = L.getGroupById(e[0]);
            o && o.PurposeId && (e = s.getTransactionType(o, e, n), t = s.processGroupConsentPurpose(o, e, a, r, i), s.setVSConsentByGroup(o, e, t).forEach(function(e) {
                return a.push(e)
            }))
        }), e.forEach(function(e) {
            e.purposeId && a.push({
                Id: e.purposeId,
                TransactionType: Me
            })
        }), "GPC" !== r && "DNT" !== r || (a = a.filter(function(e) {
            return e.PurposeNote
        })), w.bannerCloseSource = ee.Unknown, a
    }, qs.prototype.setVSConsentByGroup = function(e, o, n) {
        var r = [];
        return w.showVendorService && e.VendorServices && e.VendorServices.forEach(function(e) {
            var t;
            t = o.useOwn ? w.vsConsent.get(e.CustomVendorServiceId) ? Re : Fe : o.txnType, r.push("GPC" === n ? {
                Id: e.PurposeId,
                TransactionType: t,
                PurposeNote: {
                    noteId: N.ConsentIntegration.GPCReasonID,
                    noteType: "UNSUBSCRIBE_REASON",
                    noteText: N.GPCOptOutNoteText
                }
            } : "DNT" === n ? {
                Id: e.PurposeId,
                TransactionType: t,
                PurposeNote: {
                    noteId: N.ConsentIntegration.DNTReasonID,
                    noteType: "UNSUBSCRIBE_REASON",
                    noteText: N.DNTOptOutNoteText
                }
            } : {
                Id: e.PurposeId,
                TransactionType: t
            })
        }), r
    }, qs.prototype.getTransactionType = function(e, t, o) {
        var n = {
            txnType: Me,
            useOwn: !1
        };
        return e.Status === f.ALWAYS_ACTIVE ? n.txnType = Me : e.Status.toLowerCase() === f.ALWAYS_INACTIVE || e.Status === f.INACTIVE && Ms.isCloseByIconOrLink || o ? n.txnType = Ue : e.Status === f.ACTIVE && Ms.isCloseByIconOrLink ? n.txnType = Ms.noOptOutToogle ? qe : Re : (n.useOwn = !0, n.txnType = this.getTxnType(t[1])), n
    }, qs.prototype.getTxnType = function(e) {
        return "0" === e ? Fe : Re
    }, qs.prototype.isPurposeConsentedTo = function(e, t) {
        var o = [Re, Me];
        return e.some(function(e) {
            return e.Id === t.PurposeId && (-1 !== o.indexOf(e.TransactionType) || L.checkIfGroupHasConsent(t))
        })
    }, qs.prototype.processGroupConsentPurpose = function(e, t, o, n, r) {
        return (!n && "GPC value changed" === r || "GPC" === n) && e.isDeniedByGPC ? (o.push({
            Id: e.PurposeId,
            TransactionType: t.txnType,
            PurposeNote: {
                noteId: N.ConsentIntegration.GPCReasonID,
                noteType: "UNSUBSCRIBE_REASON",
                noteText: N.GPCOptOutNoteText
            }
        }), "GPC") : "DNT" === n && e.isDeniedByDNT ? (o.push({
            Id: e.PurposeId,
            TransactionType: t.txnType,
            PurposeNote: {
                noteId: N.ConsentIntegration.DNTReasonID,
                noteType: "UNSUBSCRIBE_REASON",
                noteText: N.DNTOptOutNoteText
            }
        }), "DNT") : (o.push({
            Id: e.PurposeId,
            TransactionType: t.txnType
        }), "none")
    }, qs.prototype.canSendAdvancedAnalytics = function(t, e) {
        var o = this;
        return "BRANCH" === e.Type || e.Type === b.GroupTypes.Stack ? e.SubGroups.length && e.SubGroups.every(function(e) {
            return o.isPurposeConsentedTo(t, e)
        }) : this.isPurposeConsentedTo(t, e)
    };
    var Ms, Us = qs;

    function qs() {
        this.MIN_INTERVAL_BETWEEN_CALLS = 6048e5
    }
    var js, Ks = function() {
            this.assets = function() {
                return {
                    name: "otCookiePolicy",
                    html: '<div class="ot-sdk-cookie-policy ot-sdk-container">\n    <h3 id="cookie-policy-title">Cookie Tracking Table</h3>\n    <div id="cookie-policy-description"></div>\n    <section>\n        <h4 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h4>\n        <p class="ot-sdk-cookie-policy-group-desc">group description</p>\n        <h5 class="cookies-used-header">Cookies Used</h5>\n        <ul class="cookies-list">\n            <li>Cookie 1</li>\n        </ul>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="table-header host">Host</th>\n                    <th scope="col" class="table-header host-description">Host Description</th>\n                    <th scope="col" class="table-header cookies">Cookies</th>\n                    <th scope="col" class="table-header life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="host-description-td" data-label="Host Description"><span\n                            class="ot-mobile-border"></span>These\n                        cookies are used to make sure\n                        visitor page requests are routed to the same server in all browsing sessions.</td>\n                    <td class="cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>ARRAffinity</li>\n                        </ul>\n                    </td>\n                    <td class="life-span-td" data-label="Life Span"><span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>100 days</li>\n                        </ul>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n    <section class="subgroup">\n        <h5 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h5>\n        <p class="ot-sdk-cookie-policy-group-desc">description</p>\n        <h6 class="cookies-used-header">Cookies Used</h6>\n        <ul class="cookies-list">\n            <li>Cookie 1</li>\n        </ul>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="table-header host">Host</th>\n                    <th scope="col" class="table-header host-description">Host Description</th>\n                    <th scope="col" class="table-header cookies">Cookies</th>\n                    <th scope="col" class="table-header life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="host-description-td" data-label="Host Description">\n                        <span class="ot-mobile-border"></span>\n                        cookies are used to make sureng sessions.\n                    </td>\n                    <td class="cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>ARRAffinity</li>\n                        </ul>\n                    </td>\n                    <td class="life-span-td" data-label="Life Span"><span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>100 days</li>\n                        </ul>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n</div>\n\x3c!-- New Cookies policy Link--\x3e\n<div id="ot-sdk-cookie-policy-v2" class="ot-sdk-cookie-policy ot-sdk-container">\n    <h3 id="cookie-policy-title" class="ot-sdk-cookie-policy-title">Cookie Tracking Table</h3>\n    <div id="cookie-policy-description"></div>\n    <section>\n        <h4 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h4>\n        <p class="ot-sdk-cookie-policy-group-desc">group description</p>\n        <section class="ot-sdk-subgroup">\n            <ul>\n                <li>\n                    <h5 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h5>\n                    <p class="ot-sdk-cookie-policy-group-desc">description</p>\n                </li>\n            </ul>\n        </section>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="ot-table-header ot-host">Host</th>\n                    <th scope="col" class="ot-table-header ot-host-description">Host Description</th>\n                    <th scope="col" class="ot-table-header ot-cookies">Cookies</th>\n                    <th scope="col" class="ot-table-header ot-cookies-type">Type</th>\n                    <th scope="col" class="ot-table-header ot-life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="ot-host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="ot-host-description-td" data-label="Host Description">\n                        <span class="ot-mobile-border"></span>\n                        cookies are used to make sureng sessions.\n                    </td>\n                    <td class="ot-cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-cookies-td-content">ARRAffinity</span>\n                    </td>\n                    <td class="ot-cookies-type" data-label="Type">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-cookies-type-td-content">1st Party</span>\n                    </td>\n                    <td class="ot-life-span-td" data-label="Life Span">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-life-span-td-content">100 days</span>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n</div>',
                    css: ".ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-right:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:left}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;left:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-left:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;left:6px;width:40%;padding-right:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;left:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-right:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;left:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}",
                    cssRTL: ".ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-right:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-right:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-left:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-left:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:right}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;right:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-right:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;right:6px;width:40%;padding-left:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;right:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-left:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;right:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-left:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}"
                }
            }
        },
        zs = "opt-out",
        Ws = (Ys.prototype.initializeFeaturesAndSpecialPurposes = function() {
            var t = this;
            w.oneTrustIABConsent.features = [], w.oneTrustIABConsent.specialPurposes = [], N.Groups.forEach(function(e) {
                t.checkAndPopulateFeatAndSplPur(e)
            })
        }, Ys.prototype.checkAndPopulateFeatAndSplPur = function(e) {
            var t, o = this,
                n = b.GroupTypes;
            e.Type !== n.Ft && e.Type !== n.Spl_Pur || ((t = {}).groupId = e.OptanonGroupId, t.purposeId = e.PurposeId, t.value = !0, (e.Type === n.Ft ? w.oneTrustIABConsent.features : w.oneTrustIABConsent.specialPurposes).push(t)), e.SubGroups && e.SubGroups.forEach(function(e) {
                o.checkAndPopulateFeatAndSplPur(e)
            })
        }, Ys.prototype.initGrpsAndHosts = function() {
            this.initializeGroupData(D.consentableGrps), B.isAlertBoxClosedAndValid() || D.initConsentableImpliedConsentGroup(D.consentableGrps), N.showCookieList && h.isOptOutEnabled() ? this.initializeHostData(D.consentableGrps) : (w.hostsConsent = [], go.writeHstParam(P.OPTANON_CONSENT))
        }, Ys.prototype.ensureHtmlGroupDataInitialised = function() {
            var e, t, o, n;
            this.initGrpsAndHosts(), w.showGeneralVendors && (mo.populateGenVendorLists(), mo.initGenVendorConsent()), N.IsIabEnabled && (this.initializeIABData(), this.initializeFeaturesAndSpecialPurposes()), w.vsIsActiveAndOptOut && this.initializeVendorsService(), B.setOrUpdate3rdPartyIABConsentFlag(), B.setGeolocationInCookies(), N.IsConsentLoggingEnabled && (e = window.OneTrust.dataSubjectParams || {}, t = I.readCookieParam(P.OPTANON_CONSENT, "iType"), o = "", n = !1, w.isV2Stub && e.id && e.token && (t ? (n = !0, o = Ce[t]) : D.forceCreateTrxLocalConsentIsGreater && Ms.shouldCreateForceReceipt() && (n = !0, Ms.recordForceReceiptSent()), w.makeInitialTxnCall = !0), Ms.createConsentTxn(!1, o, !1, n))
        }, Ys.prototype.initializeVendorsService = function() {
            var o = B.isAlertBoxClosedAndValid(),
                e = I.readCookieParam(P.OPTANON_CONSENT, to),
                n = v.strToMap(e);
            w.getVendorsInDomain().forEach(function(e, t) {
                n.has(t) || (e = !o && L.checkIsActiveByDefault(e.groupRef), n.set(t, e))
            }), w.vsConsent = n
        }, Ys.prototype.initializeGroupData = function(e) {
            var t;
            I.readCookieParam(P.OPTANON_CONSENT, Zt) ? (Io.synchroniseCookieGroupData(e), t = I.readCookieParam(P.OPTANON_CONSENT, Zt), w.groupsConsent = v.strToArr(t), w.gpcConsentTxn && (N.IsConsentLoggingEnabled && Ms.createConsentTxn(!1, "GPC value changed", !1, !0), w.gpcConsentTxn = !1, uo.setAlertBoxClosed(!0)), w.dntConsentTxn && (N.IsConsentLoggingEnabled && Ms.createConsentTxn(!1, "DNT value changed", !1, !0, !1, "DNT"), w.dntConsentTxn = !1)) : (w.groupsConsent = [], e.forEach(function(e) {
                var t = L.checkIsActiveByDefault(e) && e.HasConsentOptOut;
                e.Status === f.INACTIVE_LANDING_PAGE && !B.isAlertBoxClosedAndValid() && Ao.isLandingPage() && (t = !1), w.groupsConsent.push(e.CustomGroupId + ":" + (t ? "1" : "0")), D.gpcEnabled && e.IsGpcEnabled && e.Status === f.INACTIVE && (e.isDeniedByGPC = !0), D.DNTEnabled && e.IsDntEnabled && e.Status === f.ACTIVE && (e.isDeniedByDNT = !0)
            }), N.IsConsentLoggingEnabled && window.addEventListener("beforeunload", this.consentDefaulCall)), N.IsConsentLoggingEnabled && D.makeGPCOrDNTConsentCall && !B.isAlertBoxClosedAndValid() && (D.makeGPCOrDNTConsentCall = !1, D.gpcEnabled && e.some(function(e) {
                return !0 === e.isDeniedByGPC
            }) ? Ms.createConsentTxn(!1, "GPC value changed", !1, !0, !1, "GPC") : D.DNTEnabled && e.some(function(e) {
                return !0 === e.isDeniedByDNT
            }) && Ms.createConsentTxn(!1, "DNT value changed", !1, !0, !1, "DNT"))
        }, Ys.prototype.initializeHostData = function(e) {
            var t, r;
            I.readCookieParam(P.OPTANON_CONSENT, "hosts") ? (Io.synchroniseCookieHostData(), t = I.readCookieParam(P.OPTANON_CONSENT, "hosts"), w.hostsConsent = v.strToArr(t), e.forEach(function(e) {
                L.isAlwaysActiveGroup(e) && e.Hosts.length && e.Hosts.forEach(function(e) {
                    w.oneTrustAlwaysActiveHosts.push(e.HostId)
                })
            })) : (w.hostsConsent = [], r = {}, e.forEach(function(e) {
                var o = L.isAlwaysActiveGroup(e),
                    n = w.syncRequired ? Io.groupHasConsent(e) : L.checkIsActiveByDefault(e);
                e.Hosts.length && e.Hosts.forEach(function(e) {
                    var t;
                    r[e.HostId] ? Io.updateHostStatus(e, n) : (r[e.HostId] = !0, o && w.oneTrustAlwaysActiveHosts.push(e.HostId), t = Io.isHostPartOfAlwaysActiveGroup(e.HostId), w.hostsConsent.push(e.HostId + (t || n ? ":1" : ":0")))
                })
            }))
        }, Ys.prototype.consentDefaulCall = function() {
            var e = parseInt(I.readCookieParam(P.OPTANON_CONSENT, A.INTERACTION_COUNT), 10);
            !isNaN(e) && 0 !== e || (uo.triggerGoogleAnalyticsEvent(fn, "Click", "No interaction"), N.IsConsentLoggingEnabled && Ms.createConsentTxn(!0), window.removeEventListener("beforeunload", js.consentDefaulCall))
        }, Ys.prototype.fetchAssets = function(s) {
            return void 0 === s && (s = null), F(this, void 0, void 0, function() {
                var t, o, n, r, i;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return t = k.moduleInitializer, i = B.isAlertBoxClosedAndValid(), o = !!s, i = js.isFetchBanner(t.IsSuppressBanner, i), n = js.cookieSettingBtnPresent(), n = D.isIab2orv2Template ? N.PCShowPersistentCookiesHoverButton && (!N.PCenterDynamicRenderingEnable || (N.PCenterDynamicRenderingEnable, !n)) : N.PCShowPersistentCookiesHoverButton, r = "true" === w.urlParams.get(lt), w.hideBanner = r, [4, Promise.all([!i || N.NoBanner || r ? Promise.resolve(null) : Yt.getBannerContent(o, s), !t.IsSuppressPC || w.isPCVisible ? Yt.getPcContent() : Promise.resolve(null), n ? Yt.getCSBtnContent() : Promise.resolve(null), Yt.getCommonStyles()])];
                        case 1:
                            return i = e.sent(), r = i[0], o = i[1], t = i[2], n = i[3], js.fetchContent(r, o, t, n), js.setCookieListGroupData(), [2]
                    }
                })
            })
        }, Ys.prototype.fetchContent = function(e, t, o, n) {
            var r;
            e && (r = e.html, k.fp.CookieV2SSR || (r = atob(e.html)), this.bannerGroup = {
                name: e.name,
                html: r,
                css: e.css
            }), t && (this.preferenceCenterGroup = {
                name: t.name,
                html: atob(t.html),
                css: t.css
            }, k.isV2Template = N.PCTemplateUpgrade && /otPcPanel|otPcCenter|otPcTab/.test(t.name)), o && (this.csBtnGroup = {
                name: "CookieSettingsButton",
                html: atob(o.html),
                css: o.css
            }), n && (this.commonStyles = n)
        }, Ys.prototype.cookieSettingBtnPresent = function() {
            return m("#ot-sdk-btn").length || m(".ot-sdk-show-settings").length || m(".optanon-show-settings").length
        }, Ys.prototype.isFetchBanner = function(e, t) {
            return !e || N.ShowAlertNotice && !t && e && !m("#onetrust-banner-sdk").length
        }, Ys.prototype.setCookieListGroupData = function() {
            var e;
            k.fp.CookieV2TrackingTechnologies || (e = (new Ks).assets(), js.cookieListGroup = {
                name: e.name,
                html: e.html,
                css: N.useRTL ? e.cssRTL : e.css
            })
        }, Ys.prototype.initializeIabPurposeConsentOnReload = function() {
            var t = this;
            D.consentableIabGrps.forEach(function(e) {
                t.setIABConsent(e, !1), e.IsLegIntToggle = !0, t.setIABConsent(e, !1)
            })
        }, Ys.prototype.initializeIABData = function(o, n, r) {
            var i = this,
                e = (void 0 === o && (o = !1), void 0 === n && (n = !1), void 0 === r && (r = !1), w.oneTrustIABConsent),
                t = (e.purpose = [], e.vendors = [], e.legIntVendors = [], e.specialFeatures = [], e.legimateInterest = [], w.addtlVendors),
                s = N.VendorConsentModel === zs;
            t.vendorConsent = [], !e.IABCookieValue || o || n || B.reconsentRequired() ? (D.consentableIabGrps.forEach(function(e) {
                var t;
                n && !r ? i.setIABConsent(e, L.isAlwaysActiveGroup(e)) : r ? e.HasConsentOptOut && i.setIABConsent(e, !1) : (t = o && e.HasConsentOptOut, i.setIABConsent(e, t), e.Type === b.GroupTypes.Pur && (e.IsLegIntToggle = !0, i.setIABConsent(e, e.HasLegIntOptOut)))
            }), N.IsIabEnabled && r && (w.oneTrustIABConsent.legimateInterest = w.vendors.selectedLegInt.slice()), t = o || !n && s, r && this.iab.saveVendorStatus(r), B.setIABVendor(t, r, n), !B.reconsentRequired() || o || n || B.resetTCModel()) : (this.initializeIabPurposeConsentOnReload(), ao.populateGoogleConsent(), ao.populateVendorAndPurposeFromCookieData())
        }, Ys.prototype.canSoftOptInInsertForGroup = function(e) {
            var e = L.getGroupById(e);
            if (e) return e = e && !e.Parent ? e : L.getParentGroup(e.Parent), "inactive landingpage" !== L.getGrpStatus(e).toLowerCase() || !Ao.isLandingPage()
        }, Ys.prototype.setIABConsent = function(e, t) {
            e.Type === b.GroupTypes.Spl_Ft ? this.setIabSpeciFeatureConsent(e, t) : e.IsLegIntToggle ? (this.setIabLegIntConsent(e, t), e.IsLegIntToggle = !1) : this.setIabPurposeConsent(e, t)
        }, Ys.prototype.setIabPurposeConsent = function(o, n) {
            var r = !1;
            w.oneTrustIABConsent.purpose = w.oneTrustIABConsent.purpose.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || w.oneTrustIABConsent.purpose.push(o.IabGrpId + ":" + n)
        }, Ys.prototype.setIabLegIntConsent = function(o, n) {
            var r = !1;
            w.oneTrustIABConsent.legimateInterest = w.oneTrustIABConsent.legimateInterest.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || w.oneTrustIABConsent.legimateInterest.push(o.IabGrpId + ":" + n)
        }, Ys.prototype.setIabSpeciFeatureConsent = function(o, n) {
            var r = !1;
            w.oneTrustIABConsent.specialFeatures = w.oneTrustIABConsent.specialFeatures.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || w.oneTrustIABConsent.specialFeatures.push(o.IabGrpId + ":" + n)
        }, Ys);

    function Ys() {
        this.iab = C
    }
    Xs.prototype.getAllGroupElements = function() {
        return document.querySelectorAll("div#onetrust-pc-sdk " + T.P_Category_Grp + " " + T.P_Category_Item + ":not(.ot-vnd-item)")
    }, Xs.prototype.toggleGrpElements = function(e, t, o, n) {
        void 0 === n && (n = !1);
        for (var r = (e = D.pcName === at && N.PCTemplateUpgrade ? document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid")) : e).querySelectorAll('input[class*="category-switch-handler"]'), i = 0; i < r.length; i++) {
            var s = r[i].getAttribute("id").includes("leg-out");
            n && s || (v.setCheckedAttribute(null, r[i], o), r[i] && N.PCShowConsentLabels && (r[i].parentElement.parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(o ? N.PCActiveText : N.PCInactiveText)))
        }
        D.legIntSettings.PAllowLI && D.legIntSettings.PShowLegIntBtn && t.Type === b.GroupTypes.Pur && t.HasLegIntOptOut && !n && y.updateLegIntBtnElement(e.querySelector(".ot-leg-btn-container"), o)
    }, Xs.prototype.toogleAllSubGrpElements = function(e, t) {
        var o;
        e.ShowSubgroup ? (o = e.CustomGroupId, o = this.getGroupElementByOptanonGroupId(o.toString()), y.toogleSubGroupElement(o, t, e.IsLegIntToggle)) : this.updateHiddenSubGroupData(e, t)
    }, Xs.prototype.isSubGrpLegIntEnabled = function(e, t) {
        return D.legIntSettings.PAllowLI && D.legIntSettings.PShowLegIntBtn && e.Type === b.GroupTypes.Pur && e.HasLegIntOptOut && t.ShowSubgroupToggle
    }, Xs.prototype.toogleSubGroupElement = function(e, t, o, n) {
        void 0 === o && (o = !1), void 0 === n && (n = !1);
        for (var r = (e = D.pcName === at && N.PCTemplateUpgrade ? document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid")) : e).querySelectorAll("li" + T.P_Subgrp_li), i = 0; i < r.length; i++) {
            var s = L.getGroupById(r[i].getAttribute("data-optanongroupid")),
                a = s.OptanonGroupId,
                l = L.getParentGroup(s.Parent),
                l = (this.isSubGrpLegIntEnabled(s, l) && o && y.updateLegIntBtnElement(r[i], t), o ? "[id='ot-sub-group-id-" + a + "-leg-out']" : "[id='ot-sub-group-id-" + a + "']"),
                a = r[i].querySelector('input[class*="cookie-subgroup-handler"]' + l);
            v.setCheckedAttribute(null, a, t), a && N.PCShowConsentLabels && (a.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(t ? N.PCActiveText : N.PCInactiveText)), n || (s.IsLegIntToggle = o, y.toggleGrpStatus(s, t), s.IsLegIntToggle = !1, Io.toggleGroupHosts(s, t), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(s, t))
        }
    }, Xs.prototype.toggleGrpStatus = function(e, t) {
        var o = e.IsLegIntToggle && e.Type === b.GroupTypes.Pur ? t ? xn : Gn : t ? _n : Dn;
        uo.triggerGoogleAnalyticsEvent(fn, o, e.GroupName + ": " + e.OptanonGroupId), t ? this.updateEnabledGroupData(e) : this.updateDisabledGroupData(e)
    }, Xs.prototype.setInputID = function(e, t, o, n, r) {
        m(e).attr("id", t), m(e).attr("name", t), m(e).data("optanonGroupId", o), v.setCheckedAttribute(null, e, n), m(e).attr("aria-labelledby", r)
    }, Xs.prototype.updateEnabledGroupData = function(e) {
        var t, o; - 1 < wt.indexOf(e.Type) ? this.updateIabGroupData(e, !0) : (t = y.getGroupVariable(), -1 !== (o = v.indexOf(t, e.CustomGroupId + ":0")) && (t[o] = e.CustomGroupId + ":1"))
    }, Xs.prototype.updateDisabledGroupData = function(e) {
        var t, o; - 1 < wt.indexOf(e.Type) ? this.updateIabGroupData(e, !1) : e.Status !== f.ALWAYS_ACTIVE && (t = y.getGroupVariable(), -1 !== (o = v.indexOf(t, e.CustomGroupId + ":1")) && (t[o] = e.CustomGroupId + ":0"), this.isImplicitConsentDefaultStatus(e)) && D.removeGroupFromImpliedConsentableGroup(e)
    }, Xs.prototype.updateIabGroupData = function(e, t) {
        var o;
        e.Type === b.GroupTypes.Spl_Ft ? this.updateIabSpecialFeatureData(e.IabGrpId, t) : (o = e.IsLegIntToggle ? w.vendors.selectedLegInt : w.vendors.selectedPurpose, this.updateIabPurposeData(e.IabGrpId, t, o))
    }, Xs.prototype.isAllSubgroupsDisabled = function(e) {
        return !e.SubGroups.some(function(e) {
            return y.isGroupActive(e)
        })
    }, Xs.prototype.isAllSubgroupsEnabled = function(e) {
        return !e.SubGroups.some(function(e) {
            return y.IsGroupInActive(e)
        })
    }, Xs.prototype.toggleGroupHtmlElement = function(e, t, o) {
        D.legIntSettings.PAllowLI && D.legIntSettings.PShowLegIntBtn && e.Type === b.GroupTypes.Pur && e.HasLegIntOptOut && (e = document.querySelector("[data-el-id=" + t + "]")) && this.updateLegIntBtnElement(e, o);
        e = m("#ot-group-id-" + t).el[0];
        v.setCheckedAttribute(null, e, o), e && N.PCShowConsentLabels && (e.parentElement.querySelector(".ot-label-status").innerHTML = S.getInnerHtmlContent(o ? N.PCActiveText : N.PCInactiveText))
    }, Xs.prototype.updateLegIntBtnElement = function(e, t, o) {
        void 0 === o && (o = "");
        var n = D.legIntSettings,
            r = e.querySelector(".ot-obj-leg-btn-handler"),
            e = e.querySelector(".ot-remove-objection-handler");
        t ? (r.classList.add("ot-inactive-leg-btn"), r.classList.add("ot-leg-int-enabled"), r.classList.remove("ot-active-leg-btn"), r.focus()) : (r.classList.add("ot-active-leg-btn"), r.classList.remove("ot-inactive-leg-btn"), r.classList.remove("ot-leg-int-enabled")), r.querySelector("span").innerText = t ? n.PObjectLegIntText : n.PObjectionAppliedText, o && r.setAttribute("aria-label", o + ", " + (t ? n.PObjectLegIntText : n.PObjectionAppliedText)), Ht(e, "display: " + (t ? "none" : "inline-block") + ";", !0)
    }, Xs.prototype.isGroupActive = function(e) {
        e = -1 < wt.indexOf(e.Type) ? -1 !== this.isIabPurposeActive(e) : -1 !== S.inArray(e.CustomGroupId + ":1", y.getGroupVariable()) || this.isGroupEnabledForImplicitConsent(e);
        return e
    }, Xs.prototype.isGroupEnabledForImplicitConsent = function(e) {
        return this.isImplicitConsentDefaultStatus(e) && D.isGroupExistInImpliedConsentableGroup(e)
    }, Xs.prototype.isImplicitConsentDefaultStatus = function(e) {
        return e.Status === f.INACTIVE_LANDING_PAGE && !ta.isAlertBoxClosedAndValid() && Ao.isLandingPage()
    }, Xs.prototype.safeFormattedGroupDescription = function(e) {
        return e && e.GroupDescription ? e.GroupDescription.replace(/\r\n/g, "<br>") : ""
    }, Xs.prototype.canInsertForGroup = function(e, t) {
        void 0 === t && (t = !1);
        var o = null != e && void 0 !== e,
            n = I.readCookieParam(P.OPTANON_CONSENT, "groups"),
            r = w.groupsConsent.join(","),
            i = I.readCookieParam(P.OPTANON_CONSENT, "hosts"),
            s = w.hostsConsent.join(",");
        if (t) return !0;
        n === r && i === s || js.ensureHtmlGroupDataInitialised();
        var a = [];
        if (w.showGeneralVendors)
            for (var l = 0, c = Object.entries(w.genVendorsConsent); l < c.length; l++) {
                var d = c[l],
                    u = d[0];
                a.push(u + ":" + (d[1] ? "1" : "0"))
            }
        w.showVendorService && w.vsConsent.forEach(function(e, t) {
            a.push(t + ":" + (e ? "1" : "0"))
        });
        t = w.groupsConsent.concat(w.hostsConsent).concat(a), n = v.contains(t, e + ":1"), r = this.doesHostExist(e), i = this.doesGroupExist(e), s = !1, w.showGeneralVendors ? s = this.doesGenVendorExist(e) : w.showVendorService && (s = this.doesVendorServiceExist(e)), t = !(!r && !s) || n && js.canSoftOptInInsertForGroup(e);
        return !(!o || !(n && t || !i && !r && !s))
    }, Xs.prototype.setAllowAllButton = function() {
        var t = 0,
            e = N.Groups.some(function(e) {
                if (-1 === Bt.indexOf(e.Type)) return y.IsGroupInActive(e) && t++, e.SubGroups.some(function(e) {
                    return y.IsGroupInActive(e)
                }) && t++, 1 <= t
            }),
            o = Qt.getAllowAllButton();
        return e ? o.show("inline-block") : o.hide(), Vo.lastItem && Vo.setLastItem(), e
    }, Xs.prototype.isAnyGPCGroupOptedOut = function() {
        for (var e = !1, t = 0, o = N.Groups.filter(function(e) {
                return e.IsGpcEnabled
            }); t < o.length; t++) {
            var n = o[t];
            if (!0 === y.IsGroupInActive(n)) {
                e = !0;
                break
            }
        }
        return e
    }, Xs.prototype.getGroupVariable = function() {
        return w.groupsConsent
    }, Xs.prototype.IsGroupInActive = function(e) {
        e = -1 < wt.indexOf(e.Type) ? -1 === this.isIabPurposeActive(e) : !(-1 < Bt.indexOf(e.Type)) && -1 === S.inArray(e.CustomGroupId + ":1", y.getGroupVariable());
        return e
    }, Xs.prototype.updateIabPurposeData = function(t, e, o) {
        var n = v.findIndex(o, function(e) {
            return e.split(":")[0] === t
        });
        o[-1 === n ? Number(t) : n] = t + ":" + e
    }, Xs.prototype.updateIabSpecialFeatureData = function(t, e) {
        var o = -1 === (o = v.findIndex(w.vendors.selectedSpecialFeatures, function(e) {
            return e.split(":")[0] === t
        })) ? Number(t) : o;
        w.vendors.selectedSpecialFeatures[o] = t + ":" + e
    }, Xs.prototype.getGroupElementByOptanonGroupId = function(e) {
        return document.querySelector("#onetrust-pc-sdk " + T.P_Category_Grp + " " + T.P_Category_Item + '[data-optanongroupid=\n            "' + e + '"]')
    }, Xs.prototype.updateHiddenSubGroupData = function(e, t) {
        e.SubGroups.forEach(function(e) {
            y.toggleGrpStatus(e, t), Io.toggleGroupHosts(e, t), w.genVenOptOutEnabled && Io.toggleGroupGenVendors(e, t)
        })
    }, Xs.prototype.isIabPurposeActive = function(e) {
        var t = e.Type === b.GroupTypes.Spl_Ft ? w.vendors.selectedSpecialFeatures : e.IsLegIntToggle ? w.vendors.selectedLegInt : w.vendors.selectedPurpose;
        return S.inArray(e.IabGrpId + ":true", t)
    }, Xs.prototype.doesGroupExist = function(e) {
        return !!L.getGroupById(e)
    }, Xs.prototype.doesHostExist = function(e) {
        var t = w.hostsConsent;
        return -1 !== t.indexOf(e + ":0") || -1 !== t.indexOf(e + ":1")
    }, Xs.prototype.doesGenVendorExist = function(t) {
        return !!N.GeneralVendors && !!N.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        })
    }, Xs.prototype.doesVendorServiceExist = function(e) {
        return w.getVendorsInDomain().has(e)
    };
    var y, Js = Xs;

    function Xs() {}
    s.prototype.addLogoUrls = function() {
        h.checkMobileOfflineRequest(h.getBannerVersionUrl()) || (D.mobileOnlineURL.push(h.updateCorrectUrl(N.optanonLogo)), D.mobileOnlineURL.push(h.updateCorrectUrl(N.oneTrustFtrLogo)))
    }, s.prototype.getCookieLabel = function(e, t, o) {
        var n;
        return void 0 === o && (o = !0), e ? (n = e.Name, t ? '\n                <a  class="cookie-label"\n                    href="' + (o ? "https://cookiepedia.co.uk/cookies/" : "https://cookiepedia.co.uk/host/") + e.Name + '"\n                    rel="noopener noreferrer"\n                    target="_blank"\n                >\n                    ' + e.Name + '&nbsp;<span class="ot-scrn-rdr">' + N.NewWinTxt + "</span>\n                </a>\n            " : n) : ""
    }, s.prototype.getBannerSDKAssestsUrl = function() {
        return this.getBannerVersionUrl() + "/assets"
    }, s.prototype.getBannerVersionUrl = function() {
        var e = D.bannerScriptElement.getAttribute("src");
        return "" + (-1 !== e.indexOf("/consent/") ? e.split("consent/")[0] + "scripttemplates/" : e.split("otSDKStub")[0]) + k.moduleInitializer.Version
    }, s.prototype.checkMobileOfflineRequest = function(e) {
        return k.moduleInitializer.MobileSDK && new RegExp("^file://", "i").test(e)
    }, s.prototype.updateCorrectIABUrl = function(e) {
        var t, o = k.moduleInitializer.ScriptType;
        return o !== je.LOCAL && o !== je.LOCAL_TEST || (o = v.getURL(e), (t = (t = D.bannerScriptElement) && t.getAttribute("src") ? v.getURL(t.getAttribute("src")) : null) && o && t.hostname !== o.hostname && (e = (e = (t = "" + D.bannerDataParentURL) + o.pathname.split("/").pop().replace(/(^\/?)/, "/")).replace(o.hostname, t.hostname))), e
    }, s.prototype.updateCorrectUrl = function(e, t) {
        if ((void 0 === t && (t = !1), D.previewMode) && new RegExp("^data:image/").test(e)) return e;
        var o = v.getURL(e),
            n = D.bannerScriptElement,
            n = n && n.getAttribute("src") ? v.getURL(n.getAttribute("src")) : null;
        if (n && o && n.hostname !== o.hostname) {
            var r = k.moduleInitializer.ScriptType;
            if (r === je.LOCAL || r === je.LOCAL_TEST) {
                if (t) return e;
                n = D.bannerDataParentURL + "/" + D.getRegionRule().Id, D.canUseConditionalLogic && (n += "/" + D.Condition.Id), e = n + (null == (r = null == (r = e) ? void 0 : r.replace(null == (t = k.moduleInitializer) ? void 0 : t.CDNLocation, "")) ? void 0 : r.replace(/(^\/?)/, "/"))
            } else e = null == (t = e) ? void 0 : t.replace(o.hostname, n.hostname)
        }
        return e
    }, s.prototype.isBundleOrStackActive = function(n, r) {
        void 0 === r && (r = null);
        for (var i = w.oneTrustIABConsent, s = !0, a = (r = r || w.groupsConsent, 0);
            (() => {
                var e, t, o = n.SubGroups[a];
                o && o.Status !== f.ALWAYS_ACTIVE && (o.Type === Lt ? (-1 < (t = v.findIndex(r, function(e) {
                    return e.split(":")[0] === o.CustomGroupId
                })) && "0" === r[t].split(":")[1] || !r.length) && (s = !1) : (e = o.Type === b.GroupTypes.Spl_Ft ? i.specialFeatures : i.purpose, (-1 < (t = v.findIndex(e, function(e) {
                    return e.split(":")[0] === o.IabGrpId
                })) && "false" === e[t].split(":")[1] || !e.length) && (s = !1))), a++
            })(), s && a < n.SubGroups.length;);
        return s
    }, s.prototype.otFetchOfflineFile = function(n) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return n = n.replace(".json", ".js"), t = n.split("/"), t = t[t.length - 1], o = t.split(".js")[0], [4, new Promise(function(e) {
                            function t() {
                                e(window[o])
                            }
                            h.jsonp(n, t, t)
                        })];
                    case 1:
                        return [2, e.sent()]
                }
            })
        })
    }, s.prototype.jsonp = function(e, t, o, n) {
        void 0 === n && (n = ""), h.checkMobileOfflineRequest(e) || D.mobileOnlineURL.push(e);
        var r = document.createElement("script"),
            i = document.getElementsByTagName("head")[0];

        function s() {
            t()
        }
        r.onreadystatechange = function() {
            "loaded" !== this.readyState && "complete" !== this.readyState || s()
        }, r.id = n, r.onload = s, r.onerror = function() {
            o()
        }, r.type = "text/javascript", k.moduleInitializer.CookieV2CSPEnabled && w.nonce && r.setAttribute("nonce", w.nonce), D.sriHash && (e.includes("otTCF") && null != (n = D.sriHash) && n["otTCF.js"] && (r.integrity = D.sriHash["otTCF.js"]), e.includes("otGPP") && null != (n = D.sriHash) && n["otGPP.js"] && (r.integrity = D.sriHash["otGPP.js"]), e.includes("otConfirmDialog")) && null != (n = D.sriHash) && n["otConfirmDialog.js"] && (r.integrity = D.sriHash["otConfirmDialog.js"]), r.async = !0, r.src = S.getScriptUrl(e), w.crossOrigin && r.setAttribute("crossorigin", w.crossOrigin), i.appendChild(r)
    }, s.prototype.isCookiePolicyPage = function(e) {
        for (var t = !1, o = v.removeURLPrefixes(window.location.href), n = m("<div></div>", "ce").el, r = (m(n).html(e), n.querySelectorAll("a")), i = 0; i < r.length; i++)
            if (v.removeURLPrefixes(r[i].href) === o) {
                t = !0;
                break
            }
        return t
    }, s.prototype.isBannerVisible = function() {
        var e = !1,
            t = document.getElementById(this.BannerSdkId);
        return e = t ? t.getAttribute("style") ? -1 === t.getAttribute("style").replace(/\s/g, "").indexOf("display:none") : "none" !== window.getComputedStyle(t).display : e
    }, s.prototype.hideBanner = function() {
        var e, t = this;
        w.bnrAnimationInProg ? setTimeout(function() {
            return t.hideBanner()
        }, 100) : (m("#" + this.BannerSdkId).fadeOut(400), null != (e = null == (e = window.OneTrust_ConfirmDialog) ? void 0 : e.getInstance()) && e.close())
    }, s.prototype.resetFocusToBody = function() {
        document.activeElement && document.activeElement.blur()
    }, s.prototype.getDuration = function(e) {
        var t, o = e.Length,
            e = e.DurationType;
        return o && 0 !== parseInt(o) ? (o = parseInt(o), e ? (t = 1 < (o = this.round_to_precision(o / e, .5)) ? gt[e] + "s" : gt[e], N.LifespanDurationText && 1 === e && (t = "LifespanDurationText"), o + " " + N[t]) : this.getDurationText(o)) : N.LfSpanSecs
    }, s.prototype.isDateCurrent = function(e) {
        var e = e.split("/"),
            t = parseInt(e[1]),
            o = parseInt(e[0]),
            e = parseInt(e[2]),
            n = new Date,
            r = n.getDate(),
            i = n.getFullYear(),
            n = n.getMonth() + 1;
        return i < e || e === i && n < o || e === i && o === n && r <= t
    }, s.prototype.insertFooterLogo = function(e) {
        var t = m(e).el;
        if (t.length && N.oneTrustFtrLogo) {
            var o = h.updateCorrectUrl(N.oneTrustFtrLogo);
            h.checkMobileOfflineRequest(h.getBannerVersionUrl()) && (o = v.getRelativeURL(o, !0, !0));
            for (var n = 0; n < t.length; n++) {
                var r, i, s = "Powered by OneTrust " + N.NewWinTxt,
                    a = (m(t[n]).attr("href", N.pCFooterLogoUrl), m(t[n]).attr("aria-label", s), t[n].querySelector("img"));
                k.fp.CMPIconSprite ? (t[n].removeChild(a), r = "#" + new URL(o, window.location.origin).pathname.split("/").pop().split(".").shift(), (i = document.createElementNS("http://www.w3.org/2000/svg", "svg")).classList.add("ot-footer-svg-logo"), i.innerHTML = "<use></use>", i.setAttribute("title", s), i.querySelector("use").setAttribute("href", r), t[n].appendChild(i)) : (a.setAttribute("src", o), a.setAttribute("title", s))
            }
        }
    }, s.prototype.removeFooterLogo = function(e) {
        e && v.removeChild(e)
    }, s.prototype.getUTCFormattedDate = function(e) {
        e = new Date(e);
        return e.getUTCFullYear() + "-" + (e.getUTCMonth() + 1).toString().padStart(2, "0") + "-" + e.getUTCDate().toString().toString().padStart(2, "0") + " " + e.getUTCHours() + ":" + e.getUTCMinutes().toString().toString().padStart(2, "0") + ":" + e.getUTCSeconds().toString().toString().padStart(2, "0")
    }, s.prototype.getDurationText = function(e) {
        return 365 <= e ? (e = this.round_to_precision(e /= 365, .5)) + " " + (1 < e ? N.LfSpnYrs : N.LfSpnYr) : N.LifespanDurationText ? e + " " + N.LifespanDurationText : e + " " + (1 < e ? N.PCenterVendorListLifespanDays : N.PCenterVendorListLifespanDay)
    }, s.prototype.round_to_precision = function(e, t) {
        e = +e + (void 0 === t ? .5 : t / 2);
        return e - e % (void 0 === t ? 1 : +t)
    }, s.prototype.isOptOutEnabled = function() {
        return N.PCTemplateUpgrade ? w.genVenOptOutEnabled : N.allowHostOptOut
    }, s.prototype.findUserType = function(e) {
        w.isKeyboardUser = !(!e || 0 !== e.detail)
    }, s.prototype.getCSSPropsFromString = function(e) {
        var t, o;
        return e ? (t = e.length, o = {}, (e = e.endsWith(";") ? e.substring(0, t - 1) : e).trim().split(";").forEach(function(e) {
            e = e.trim().toString().split(":"), e = JSON.parse('{ "' + e[0].trim() + '" : "' + e[1].trim() + '" }');
            o = Object.assign(o, e)
        }), o) : {}
    }, s.prototype.setCloseIcon = function(e) {
        var t, o, n = h.updateCorrectUrl(N.OTCloseBtnLogo),
            r = m(e);
        r.length && (t = e.querySelector("svg"), k.fp.CMPIconSprite && n && !t ? (t = new URL(n, window.location.origin).pathname.split("/").pop().split(".").shift(), (o = document.createElementNS("http://www.w3.org/2000/svg", "svg")).classList.add("ot-svg-icon"), o.innerHTML = "<use></use>", o.querySelector("use").setAttribute("href", "#" + t), e.appendChild(o)) : Ht(r.el, 'background-image: url("' + n + '")', !0))
    }, s.prototype.createOptOutSignalElement = function(e, t) {
        var o = e(t ? "#ot-pc-content" : "#onetrust-policy"),
            n = document.createElement("div"),
            r = (n.classList.add("ot-optout-signal"), document.createElement("div")),
            i = (r.classList.add("ot-optout-icon"), r.setAttribute("aria-hidden", "true"), document.createElement("span"));
        return i.setAttribute("id", t ? "ot-pc-gpc-txt" : "ot-bnr-gpc-txt"), i.innerText = this.getOptOutSignalText(t), n.append(r), n.append(i), null != (t = o) && t.prepend(n), this.applyGuardLogo(e), n
    }, s.prototype.getOptOutSignalContext = function(e, t) {
        function o(e) {
            return t ? t(e) : document.querySelector(e)
        }
        var n = e ? "ot-pc-gpc-txt" : "ot-bnr-gpc-txt",
            e = o("#" + (e ? this.PcSdkId : this.BannerSdkId));
        return {
            gpcTextId: n,
            find: o,
            sdkContainer: e,
            dialog: null == (n = e) ? void 0 : n.querySelector('[role="dialog"]')
        }
    }, s.prototype.applyOptOutSignalA11y = function(e, t) {
        var t = this.getOptOutSignalContext(e, t),
            o = t.gpcTextId,
            n = t.find,
            r = t.sdkContainer,
            t = t.dialog,
            i = n("#" + o);
        t && i && (e ? this.applyPcDialogLabel(t, i) : this.applyBannerDialogLabel(t, o, n)), r && i && this.addDescribedBy(r, o)
    }, s.prototype.removeOptOutSignalA11y = function(e, t) {
        var t = this.getOptOutSignalContext(e, t),
            o = t.gpcTextId,
            n = t.sdkContainer,
            t = t.dialog;
        t && (e ? this.restorePcDialogLabel(t) : t.hasAttribute(Pt) && t.removeAttribute(Pt)), n && this.removeDescribedBy(n, o)
    }, s.prototype.applyPcDialogLabel = function(e, t) {
        var t = t.textContent || "",
            o = e.getAttribute(vt) || "";
        t && !e.hasAttribute(this.OrigLabelAttr) && (e.setAttribute(this.OrigLabelAttr, o), e.setAttribute(vt, t + ". " + o))
    }, s.prototype.applyBannerDialogLabel = function(e, t, o) {
        var n = "onetrust-policy-title",
            t = [t];
        o("#" + n) && t.push(n), e.setAttribute(Pt, t.join(" "))
    }, s.prototype.restorePcDialogLabel = function(e) {
        var t = e.getAttribute(this.OrigLabelAttr);
        null !== t && (e.setAttribute(vt, t), e.removeAttribute(this.OrigLabelAttr))
    }, s.prototype.addDescribedBy = function(e, t) {
        var o = e.getAttribute(At) || "";
        o.includes(t) || e.setAttribute(At, o ? o + " " + t : t)
    }, s.prototype.removeDescribedBy = function(e, t) {
        var o = (e.getAttribute(At) || "").split(" ").filter(function(e) {
            return e !== t
        }).join(" ");
        o ? e.setAttribute(At, o) : e.removeAttribute(At)
    }, s.prototype.getOptOutSignalText = function(e) {
        return e ? N.PCOptOutSignalText : N.BOptOutSignalText
    }, s.prototype.getFloatingBtnAriaLabel = function(e) {
        var t = N.CookieSettingButtonText;
        return (void 0 !== e ? e : this.shouldShowOptOutNotification()) && N.PCOptOutSignalText ? t + ", " + N.PCOptOutSignalText : t
    }, s.prototype.initOptOutSignalNotification = function() {
        var e, t = this,
            o = document.querySelector(this.FltgBtnSelector);
        o && (o.querySelector(this.OptOutNtfySelector) || this.createOptOutNtfyElement(o), this.cachedFltgBtn = o, this.cachedNtfy = o.querySelector(this.OptOutNtfySelector), o.classList.add(this.HasOptOutNtfyClass), (e = o.querySelector(this.FltgFrontBtnSelector)) && e.setAttribute(vt, this.getFloatingBtnAriaLabel()), this.optOutNtfyInitialized || (o.addEventListener("mouseenter", e = function() {
            !o.classList.contains("ot-pc-open") && t.shouldShowOptOutNotification() && t.showOptOutNotification()
        }), o.addEventListener("focusin", e), o.addEventListener("keydown", function(e) {
            "Escape" === e.key && t.hideOptOutNotification()
        }), this.optOutNtfyInitialized = !0))
    }, s.prototype.createOptOutNtfyElement = function(e) {
        var t = document.createElement("div"),
            o = (t.className = "ot-optout-ntfy ot-hide", document.createElement("span")),
            o = (o.className = "ot-optout-ntfy-icon", o.setAttribute(Tt, "true"), t.appendChild(o), document.createElement("span"));
        o.className = "ot-optout-ntfy-txt", o.textContent = N.PCOptOutSignalText, t.appendChild(o), e.appendChild(t)
    }, s.prototype.syncOptOutNotification = function() {
        var e = this.shouldShowOptOutNotification(),
            t = this.cachedFltgBtn || document.querySelector(this.FltgBtnSelector);
        t && (t = t.querySelector(this.FltgFrontBtnSelector)) && t.setAttribute(vt, this.getFloatingBtnAriaLabel(e)), e ? (this.initOptOutSignalNotification(), this.showOptOutNotification()) : this.hideOptOutNotification()
    }, s.prototype.showOptOutNotification = function() {
        var e, t = this,
            o = this.cachedNtfy || document.querySelector(this.OptOutNtfySelector);
        o && ((e = this.cachedFltgBtn || document.querySelector(this.FltgBtnSelector)) && e.classList.add(this.NtfyActiveClass), o.classList.remove("ot-hide"), requestAnimationFrame(function() {
            o.classList.add(t.OptOutNtfyShowClass)
        }), this.optOutNtfyTimer && clearTimeout(this.optOutNtfyTimer), this.optOutNtfyTimer = setTimeout(function() {
            t.hideOptOutNotification()
        }, 5e3))
    }, s.prototype.hideOptOutNotification = function() {
        var e, t = this,
            o = this.cachedNtfy || document.querySelector(this.OptOutNtfySelector);
        o && ((e = this.cachedFltgBtn || document.querySelector(this.FltgBtnSelector)) && e.classList.remove(this.NtfyActiveClass), o.classList.remove(this.OptOutNtfyShowClass), setTimeout(function() {
            o.classList.contains(t.OptOutNtfyShowClass) || o.classList.add("ot-hide")
        }, 300), this.optOutNtfyTimer) && (clearTimeout(this.optOutNtfyTimer), this.optOutNtfyTimer = null)
    }, s.prototype.shouldShowOptOutNotification = function() {
        var e, t;
        return !!(N.PCShowPersistentCookiesHoverButton && N.PCShowOptOutSignal && (e = D.gpcEnabled && D.gpcForAGrpEnabled, t = !!N.Groups && y.isAnyGPCGroupOptedOut(), e && t || D.previewMode))
    }, s.prototype.shouldShowDoubleOptInSignal = function(o) {
        var e, t, n, r, i;
        return void 0 === o && (o = !1), !(!N.PCShowDoubleOptInSignal || (t = !!(e = w.isPCVisible ? document.getElementById(this.PcSdkId) : document.getElementById(this.BannerSdkId)) && "none" !== window.getComputedStyle(e).display, !e) || !t) && (e = I.readCookieParam(P.OPTANON_CONSENT, Zt), t = v.strToArr(e), n = h.getGroupConsentMap(t), r = h.getGroupConsentMap(w.groupsConsent), i = null !== B.alertBoxCloseDate(), null == (e = N.Groups) ? void 0 : e.some(function(e) {
            var t = D.gpcEnabled && e.IsGpcEnabled;
            if (i || t) {
                t = e.CustomGroupId;
                if ("0" === n[t] && ("1" === r[t] || o)) return !0
            }
            return !1
        }))
    }, s.prototype.getGroupConsentMap = function(e) {
        return null == (e = e) ? void 0 : e.reduce(function(e, t) {
            t = t.split(":");
            return e[t[0]] = t[1], e
        }, {})
    }, s.prototype.createDoubleOptInConfirmDialog = function(e, t, o) {
        var n = null == (n = window.OneTrust_ConfirmDialog) ? void 0 : n.getInstance();
        n && (n.create({
            text: N.PCDoubleOptInSignalText,
            description: N.PCDoubleOptInSignalDescription,
            cancelText: N.PCDoubleOptInSignalCancelText,
            confirmText: N.PCDoubleOptInSignalConfirmText,
            onConfirm: t,
            onCancel: o
        }).open(e ? "#" + this.PcSdkId : "#" + this.BannerSdkId), h.setCloseIcon(document.querySelector(".ot-confirm-dialog .ot-close-icon")))
    }, s.prototype.applyGuardLogo = function(i) {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return k.fp.CMPIconSprite ? (n = "<svg aria-hidden=\"true\">\n            <use href='#ot_opt_out_signal'></use>\n            </svg>", m(i(".ot-optout-icon")).html(n), m(i(".ot-optout-icon svg")).attr("class", "ot-source-sprite"), [3, 3]) : [3, 1];
                    case 1:
                        return (t = N.cookiePersistentLogo).includes("ot_guard_logo.svg") || (o = N.OTCloseBtnLogo, r = o.indexOf("static/"), t = o.replace(o.slice(r + 7), "ot_guard_logo.svg")), (o = k.moduleInitializer.ScriptType) !== je.LOCAL && o !== je.LOCAL_TEST || (t = h.updateCorrectUrl(t)), [4, Yt.getPersistentCookieSvg(t)];
                    case 2:
                        n = e.sent(), r = (r = n) && n.replace(/<svg([\s\S]*?)>/i, '<svg$1 aria-hidden="true">'), m(".ot-optout-icon").html(r), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, s.prototype.updateTCString = function() {
        var e = B.iabStringSDK().tcString().encode(w.tcModel);
        w.cmpApi.update(e, !1)
    }, s.prototype.replaceTextFromString = function(e, t, o) {
        return t.split(e).join(o)
    }, s.prototype.getStubQueryParam = function(e) {
        var t = D.stubUrl || window.otStubData && window.otStubData.stubUrl;
        return !t || (t = t.split("?")).length < 2 ? null : new URLSearchParams(t[1]).get(e)
    }, s.prototype.updateIntTypeFromCookie = function() {
        var e;
        w.consentInteractionType || (e = I.readCookieParam(P.OPTANON_CONSENT, "intType")) && (w.consentInteractionType = Ce[e])
    }, s.prototype.getStubAttr = function(e) {
        var t = D.bannerScriptElement,
            t = t && t.getAttribute(e);
        return t || h.getStubQueryParam(e)
    }, s.prototype.getVendorPageHeaderText = function() {
        var e = document.querySelector("#" + this.PcSdkId + " " + T.P_Vendor_Title + ", #" + this.PcSdkId + ' #ot-lst-title p[aria-level="3"]');
        return e instanceof HTMLElement ? e.innerText : ""
    }, s.prototype.replaceHeadings = function(e) {
        var t;
        if (null != (t = k.moduleInitializer) && t.SEOOptimization)
            for (var o = 1; o <= 6; o++)(n => {
                e.querySelectorAll("h" + n).forEach(function(e) {
                    var t, o;
                    e.closest('[role="tab"]') ? ((t = document.createElement("span")).innerHTML = e.innerHTML, e.className && (t.className = e.className), e.id && (t.id = e.id), null != (o = e.parentNode) && o.replaceChild(t, e)) : ((o = document.createElement("p")).setAttribute("role", "heading"), o.setAttribute("aria-level", n.toString()), o.innerHTML = e.innerHTML, e.className && (o.className = e.className), e.id && (o.id = e.id), e.title && (o.title = e.title), null != (t = e.parentNode) && t.replaceChild(o, e))
                })
            })(o)
    }, s.prototype.hasAdjacentExternalLinkSvg = function(e) {
        e = e.nextElementSibling;
        return !(!e || "SVG" !== e.tagName.toUpperCase() || !e.classList.contains("ot-ext-lnk"))
    }, s.prototype.addExternalIconForLinks = function(e) {
        var o, n = this;
        N.BannerRequireExternalLinks && (o = k.fp.CMPIconSprite && N.OTExternalLinkLogo && !N.BannerExternalLinksLogo, e('a[target="_blank"]').forEach(function(e) {
            var t = e.parentElement;
            t && "DIV" === t.tagName && (t.classList.contains("ot-pc-footer-logo") || t.classList.contains("ot-bnr-footer-logo")) || (o ? n.hasAdjacentExternalLinkSvg(e) || (t = h.updateCorrectUrl(N.OTExternalLinkLogo), t = N.BannerExternalLinksLogo ? h.updateCorrectUrl(N.BannerExternalLinksLogo) : t, t = new URL(t, window.location.origin).pathname.split("/").pop().split(".").shift(), e.insertAdjacentHTML("afterend", S.getInnerHtmlContent("<svg class='ot-ext-lnk'>\n                                <use href='#" + t + "'></use>\n                                </svg>"))) : e.classList.add("ot-ext-lnk"))
        }))
    };
    var h, i = s;

    function s() {
        this.OptOutNtfySelector = ".ot-optout-ntfy", this.OptOutNtfyShowClass = "ot-ntfy-show", this.HasOptOutNtfyClass = "ot-has-optout-ntfy", this.NtfyActiveClass = "ot-ntfy-active", this.FltgBtnSelector = "#ot-sdk-btn-floating", this.FltgFrontBtnSelector = ".ot-floating-button__open", this.optOutNtfyTimer = null, this.optOutNtfyInitialized = !1, this.cachedFltgBtn = null, this.cachedNtfy = null, this.OrigLabelAttr = "data-ot-orig-label", this.BannerSdkId = "onetrust-banner-sdk", this.PcSdkId = "onetrust-pc-sdk"
    }
    Qs.prototype.getPurposeOneGrpId = function() {
        return b.IdPatterns.Pur + "1"
    }, Qs.prototype.setRegionRule = function(e) {
        this.rule = e
    }, Qs.prototype.getRegionRule = function() {
        return this.rule
    }, Qs.prototype.getRegionRuleType = function() {
        return this.multiVariantTestingEnabled && this.selectedVariant ? this.selectedVariant.TemplateType : this.conditionalLogicEnabled && !this.allConditionsFailed ? this.Condition.TemplateType : this.rule.Type
    }, Qs.prototype.getTemplateName = function() {
        return this.multiVariantTestingEnabled && this.selectedVariant ? this.selectedVariant.Name : (this.canUseConditionalLogic ? this.Condition : this.rule).TemplateName
    }, Qs.prototype.isGroupExistInImpliedConsentableGroup = function(t) {
        return D.consentableImpliedConsentGroup.some(function(e) {
            return e.CustomGroupId === t.CustomGroupId
        })
    }, Qs.prototype.removeGroupFromImpliedConsentableGroup = function(t) {
        this.consentableImpliedConsentGroup = this.consentableImpliedConsentGroup.filter(function(e) {
            return e.CustomGroupId !== t.CustomGroupId
        })
    }, Qs.prototype.initConsentableImpliedConsentGroup = function(e) {
        var t = this;
        e.forEach(function(e) {
            e.Status === f.INACTIVE_LANDING_PAGE && t.consentableImpliedConsentGroup.push(e)
        })
    }, Qs.prototype.resetImpliedConsentableGroups = function() {
        this.consentableImpliedConsentGroup = this.consentableGrps.filter(function(e) {
            return e.Status === f.INACTIVE_LANDING_PAGE
        })
    }, Qs.prototype.canUseGoogleVendors = function(e) {
        return !!e && (this.conditionalLogicEnabled && !this.allConditionsFailed ? this.Condition : this.rule).UseGoogleVendors
    }, Qs.prototype.initVariables = function() {
        this.consentableGrps = [], this.consentableImpliedConsentGroup = [], this.consentableIabGrps = [], this.iabGrps = [], this.iabGrpIdMap = {}, this.domainGrps = {}, this.iabGroups = {
            purposes: {},
            legIntPurposes: {},
            specialPurposes: {},
            features: {},
            specialFeatures: {}
        }
    }, Qs.prototype.init = function(e) {
        this.getGPCSignal(), this.initVariables();
        var t = e.DomainData;
        this.setPublicDomainData(JSON.parse(JSON.stringify(t))), this.domainDataMapper(t), this.commonDataMapper(e.CommonData), N.NtfyConfig = e.NtfyConfig || {}, this.setBannerName(), this.setPcName(), this.populateGPCSignal(), this.populateGPCBrowserSignal(), this.populateDNTSignal(), N.GoogleConsent.GCEnable && this.initGCM()
    }, Qs.prototype.getGPCSignal = function() {
        navigator.globalPrivacyControl ? this.gpcEnabled = !0 : this.gpcEnabled = !1
    }, Qs.prototype.isValidConsentNoticeGroup = function(e, t) {
        var o, n, r, i, s, a;
        return !!e.ShowInPopup && (o = this.isGroupHasCookies(e), s = i = r = n = !1, null != (a = e) && a.Parent || (e.SubGroups.length && (n = e.SubGroups.some(function(e) {
            return e.GroupName && e.ShowInPopup && e.FirstPartyCookies.length
        }), r = e.SubGroups.some(function(e) {
            return e.GroupName && e.ShowInPopup && (e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length)
        }), i = e.SubGroups.some(function(e) {
            return e.GroupName && e.AlwaysShowCategory
        }), !t || e.FirstPartyCookies.length && e.Hosts.length || (s = !e.SubGroups.some(function(e) {
            return -1 === Dt.indexOf(e.Type)
        }))), a = e.SubGroups.some(function(e) {
            return -1 < Dt.indexOf(e.Type)
        }), (-1 < Dt.indexOf(e.Type) || a) && (e.ShowVendorList = !0), (e.Hosts.length || r || n) && (e.ShowHostList = !0)), this.isValidGroup(o, e, n, r, s, i))
    }, Qs.prototype.isValidGroup = function(e, t, o, n, r, i) {
        var s = p.showVendorService && t.VendorServices && t.VendorServices.length;
        return !!t.AlwaysShowCategory || e || -1 < Dt.indexOf(t.Type) || o || n || i || r || s
    }, Qs.prototype.isGroupHasCookies = function(e) {
        return e.FirstPartyCookies.length || e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length || e.VendorServices && e.VendorServices.length
    }, Qs.prototype.extractGroupIdForIabGroup = function(e) {
        return -1 < e.indexOf(b.IdPatterns.Spl_Pur) ? e = e.replace(b.IdPatterns.Spl_Pur, "") : -1 < e.indexOf(b.IdPatterns.Pur) ? e = e.replace(b.IdPatterns.Pur, "") : -1 < e.indexOf(b.IdPatterns.Ft) ? e = e.replace(b.IdPatterns.Ft, "") : -1 < e.indexOf(b.IdPatterns.Spl_Ft) && (e = e.replace(b.IdPatterns.Spl_Ft, "")), e
    }, Qs.prototype.isIabGrpAndNonConsentable = function(e) {
        var t = b.GroupTypes;
        return !this.isIab2orv2Template && -1 < Dt.indexOf(e.Type) || this.isIab2orv2Template && (e.Type === t.Pur || e.Type === t.Stack) && !e.HasConsentOptOut && !e.HasLegIntOptOut || e.Type === t.Spl_Ft && !e.HasConsentOptOut
    }, Qs.prototype.setTcfPurposeParentMapForGrp = function(e) {
        var t = b.GroupTypes;
        if (this.isTcfV2Template && e.Parent) switch (e.Type) {
            case t.Pur:
                this.tcfParentMap.pur.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Spl_Pur:
                this.tcfParentMap.spl_pur.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Ft:
                this.tcfParentMap.ft.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Spl_Ft:
                this.tcfParentMap.spl_ft.set(parseInt(e.IabGrpId), e.Parent)
        }
    }, Qs.prototype.populateGroups = function(e, r) {
        var i = this,
            s = {},
            a = [],
            l = b.GroupTypes,
            t = (e.forEach(function(e) {
                var t = e.CustomGroupId;
                if (i.setHealthSignatureDataIntoGroup(r, e), void 0 !== e.HasConsentOptOut && e.IsIabPurpose || (e.HasConsentOptOut = !0), !i.isIabGrpAndNonConsentable(e)) {
                    if (t !== D.getPurposeOneGrpId() || e.ShowInPopup || (i.purposeOneTreatment = !0), i.grpContainLegalOptOut = e.HasLegIntOptOut || i.grpContainLegalOptOut, e.SubGroups = [], e.Parent ? a.push(e) : s[t] = e, i.isIab2orv2Template && -1 < Dt.indexOf(e.Type)) {
                        var o = i.extractGroupIdForIabGroup(t),
                            n = (i.iabGrpIdMap[t] = o, e.IabGrpId = o, {
                                description: e.GroupDescription,
                                descriptionLegal: e.DescriptionLegal,
                                id: Number(o),
                                name: e.GroupName
                            });
                        switch (e.Type) {
                            case l.Pur:
                                i.iabGroups.purposes[o] = n;
                                break;
                            case l.Spl_Pur:
                                i.iabGroups.specialPurposes[o] = n;
                                break;
                            case l.Ft:
                                i.iabGroups.features[o] = n;
                                break;
                            case l.Spl_Ft:
                                i.iabGroups.specialFeatures[o] = n
                        }
                    }
                    i.setTcfPurposeParentMapForGrp(e)
                }
            }), a.forEach(function(e) {
                s[e.Parent] && e.ShowInPopup && (e.AlwaysShowCategory || e.FirstPartyCookies.length || e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length || -1 < Dt.indexOf(e.Type)) && s[e.Parent].SubGroups.push(e)
            }), []);
        return Object.keys(s).forEach(function(e) {
            i.isValidConsentNoticeGroup(s[e], r.IsIabEnabled) && (s[e].SubGroups.sort(function(e, t) {
                return e.Order - t.Order
            }), t.push(s[e]))
        }), this.initGrpVar(t), t.sort(function(e, t) {
            return e.Order - t.Order
        })
    }, Qs.prototype.setHealthSignatureDataIntoGroup = function(e, t) {
        this.requireSignatureEnabled && e.RequireSignatureCID === t.CustomGroupId && (t.needsHealthSignature = !0, "1" === I.readCookieParam(P.OPTANON_CONSENT, A.HEALTH_SIGNATURE_AUTHORIZATION)) && (t.healthSignatureId = I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID))
    }, Qs.prototype.isGrpConsentable = function(e) {
        var t = b.GroupTypes;
        return e.Type === t.Cookie || e.Type === t.Pur || e.Type === t.Spl_Ft
    }, Qs.prototype.initGrpVar = function(e) {
        var o = this,
            n = !0,
            r = !0;
        e.forEach(function(e) {
            U([e], e.SubGroups).forEach(function(e) {
                o.isGrpConsentable(e) && (o.domainGrps[e.PurposeId.toLowerCase()] = e.CustomGroupId), -1 < Nt.indexOf(e.Type) && o.consentableGrps.push(e), -1 < wt.indexOf(e.Type) && o.consentableIabGrps.push(e), -1 === Nt.indexOf(e.Type) && o.iabGrps.push(e), o.applyGpcStatusOverride(e);
                var t = o.applyDNTStatusOverride(e);
                t !== f.ACTIVE && t !== f.INACTIVE_LANDING_PAGE && t !== f.DNT || (n = !1), t !== f.INACTIVE_LANDING_PAGE && t !== f.ALWAYS_ACTIVE && (r = !1), o.gpcForAGrpEnabled || (o.gpcForAGrpEnabled = e.IsGpcEnabled), o.dntForAGrpEnabled || (o.dntForAGrpEnabled = e.IsDntEnabled)
            })
        }), this.isOptInMode = n, this.isSoftOptInMode = r
    }, Qs.prototype.applyGpcStatusOverride = function(e) {
        var t;
        this.gpcEnabled && e.IsGpcEnabled && (null == (t = null == (t = e.Status) ? void 0 : t.toLowerCase()) ? void 0 : t.trim()) !== f.ALWAYS_INACTIVE.toLowerCase() && (e.Status = f.INACTIVE)
    }, Qs.prototype.applyDNTStatusOverride = function(e) {
        var t = this.DNTEnabled && e.IsDntEnabled && (null == (t = null == (t = e.Status) ? void 0 : t.toLowerCase()) ? void 0 : t.trim()) !== f.ALWAYS_INACTIVE.toLowerCase() ? f.DNT : e.Status.toLowerCase();
        return t.trim()
    }, Qs.prototype.domainDataMapper = function(e) {
        this.requireSignatureEnabled = (null == (t = k.fp) ? void 0 : t.CookieV2SubmitPurpose) && e.IsRequireSignatureEnabled && e.PCTemplateUpgrade;
        var t = {
            AriaClosePreferences: e.AriaClosePreferences,
            AriaOpenPreferences: e.AriaOpenPreferences,
            AriaPrivacy: e.AriaPrivacy,
            CenterRounded: e.CenterRounded,
            Flat: e.Flat,
            FloatingFlat: e.FloatingFlat,
            FloatingRounded: e.FloatingRounded,
            FloatingRoundedCorner: e.FloatingRoundedCorner,
            FloatingRoundedIcon: e.FloatingRoundedIcon,
            VendorLevelOptOut: e.IsIabEnabled,
            AboutCookiesText: e.AboutCookiesText,
            AboutLink: e.AboutLink,
            AboutText: e.AboutText,
            ActiveText: e.ActiveText,
            AddLinksToCookiepedia: e.AddLinksToCookiepedia,
            AlertAllowCookiesText: e.AlertAllowCookiesText,
            AlertCloseText: e.AlertCloseText,
            AlertLayout: e.AlertLayout,
            AlertMoreInfoText: e.AlertMoreInfoText,
            AlertMoreInfoTextDialog: e.AlertMoreInfoTextDialog,
            AlertNoticeText: e.AlertNoticeText,
            AllowAllText: e.PreferenceCenterConfirmText,
            AlwaysActiveText: e.AlwaysActiveText,
            AlwaysInactiveText: e.AlwaysInactiveText,
            BannerAdditionalDescPlacement: e.BannerAdditionalDescPlacement,
            BannerAdditionalDescription: e.BannerAdditionalDescription,
            BannerCloseButtonText: e.BannerCloseButtonText,
            BannerFeatureDescription: e.BannerFeatureDescription,
            BannerFeatureTitle: e.BannerFeatureTitle,
            BannerIABPartnersLink: e.BannerIABPartnersLink,
            BannerInformationDescription: e.BannerInformationDescription,
            BannerInformationTitle: e.BannerInformationTitle,
            BannerNonIABVendorListText: e.BannerNonIABVendorListText,
            BannerPosition: e.BannerPosition,
            BannerPurposeDescription: e.BannerPurposeDescription,
            BannerPurposeTitle: e.BannerPurposeTitle,
            BannerRejectAllButtonText: e.BannerRejectAllButtonText,
            BannerRelativeFontSizesToggle: e.BannerRelativeFontSizesToggle,
            BannerSettingsButtonDisplayLink: e.BannerSettingsButtonDisplayLink,
            BannerShowRejectAllButton: e.BannerShowRejectAllButton,
            BShowOptOutSignal: e.BShowOptOutSignal,
            BOptOutSignalText: e.BOptOutSignalText,
            BRegionAriaLabel: e.BRegionAriaLabel,
            BannerTitle: e.BannerTitle,
            BCloseButtonType: e.BCloseButtonType,
            BContinueText: e.BContinueText,
            BCookiePolicyLinkScreenReader: e.BCookiePolicyLinkScreenReader,
            BnrLogoAria: e.BnrLogoAria,
            BImprintLinkScreenReader: e.BImprintLinkScreenReader,
            BInitialFocus: e.BInitialFocus,
            BInitialFocusLinkAndButton: e.BInitialFocusLinkAndButton,
            BRejectConsentType: e.BRejectConsentType,
            BSaveBtnTxt: e.BSaveBtnText,
            BShowImprintLink: e.BShowImprintLink,
            BShowPolicyLink: e.BShowPolicyLink,
            BShowSaveBtn: e.BShowSaveBtn,
            cctId: e.cctId,
            CanGenerateNotGivenReceipts: e.CanGenerateNotGivenReceipts,
            ChoicesBanner: e.ChoicesBanner,
            CloseShouldAcceptAllCookies: e.CloseShouldAcceptAllCookies,
            CloseText: e.CloseText,
            ConfirmText: e.ConfirmText,
            ConsentModel: {
                Name: e.ConsentModel
            },
            CookieListDescription: e.CookieListDescription,
            CookieListTitle: e.CookieListTitle,
            CookieSettingButtonText: e.CookieSettingButtonText,
            CookiesUsedText: e.CookiesUsedText,
            CustomJs: e.CustomJs,
            firstPartyTxt: e.CookieFirstPartyText,
            FooterDescriptionText: e.FooterDescriptionText,
            ForceConsent: e.ForceConsent,
            GeneralVendors: e.GeneralVendors,
            GeneralVendorsEnabled: e.PCenterUseGeneralVendorsToggle,
            GenVenOptOut: e.PCenterAllowVendorOptout,
            GlobalRestrictionEnabled: e.GlobalRestrictionEnabled,
            GlobalRestrictions: e.GlobalRestrictions,
            GoogleConsent: {
                GCAdStorage: e.GCAdStorage,
                GCAnalyticsStorage: e.GCAnalyticsStorage,
                GCEnable: e.GCEnable,
                GCFunctionalityStorage: e.GCFunctionalityStorage,
                GCPersonalizationStorage: e.GCPersonalizationStorage,
                GCRedactEnable: e.GCRedactEnable,
                GCSecurityStorage: e.GCSecurityStorage,
                GCWaitTime: e.GCWaitTime,
                GCAdUserData: e.GCAdUserData,
                GCAdPersonalization: e.GCAdPersonalization
            },
            MCMData: e.MCMData,
            ACMData: e.ACMData,
            GroupGenVenListLabel: e.PCenterGeneralVendorThirdPartyCookiesText,
            Groups: this.populateGroups(e.Groups, e),
            HideToolbarCookieList: e.HideToolbarCookieList,
            IabType: e.IabType,
            InactiveText: e.InactiveText,
            IsConsentLoggingEnabled: e.IsConsentLoggingEnabled,
            IsIabEnabled: e.IsIabEnabled,
            IsIabThirdPartyCookieEnabled: e.IsIabThirdPartyCookieEnabled,
            IsLifespanEnabled: e.IsLifespanEnabled,
            Language: e.Language,
            LastReconsentDate: e.LastReconsentDate,
            LfSpanSecs: e.PCLifeSpanSecs,
            LfSpnWk: e.PCLifeSpanWk,
            LfSpnWks: e.PCLifeSpanWks,
            LfSpnYr: e.PCLifeSpanYr,
            LfSpnYrs: e.PCLifeSpanYrs,
            LifespanDurationText: e.LifespanDurationText,
            MainInfoText: e.MainInfoText,
            MainText: e.MainText,
            ManagePreferenceText: e.PreferenceCenterManagePreferencesText,
            NewVendorsInactiveEnabled: e.NewVendorsInactiveEnabled,
            NewWinTxt: e.PreferenceCenterMoreInfoScreenReader,
            NextPageAcceptAllCookies: e.NextPageAcceptAllCookies,
            NextPageCloseBanner: e.NextPageCloseBanner,
            NoBanner: e.NoBanner,
            OnClickAcceptAllCookies: e.OnClickAcceptAllCookies,
            OnClickCloseBanner: e.OnClickCloseBanner,
            OverriddenVendors: null != (t = e.OverriddenVendors) ? t : {},
            OverridenGoogleVendors: null != (t = e.OverridenGoogleVendors) ? t : {},
            Publisher: e.publisher,
            PublisherCC: e.PublisherCC,
            ReconsentFrequencyDays: e.ReconsentFrequencyDays,
            ScrollAcceptAllCookies: e.ScrollAcceptAllCookies,
            ScrollCloseBanner: e.ScrollCloseBanner,
            ShowAlertNotice: e.ShowAlertNotice,
            showBannerCloseButton: e.showBannerCloseButton,
            ShowPreferenceCenterCloseButton: e.ShowPreferenceCenterCloseButton,
            ThirdPartyCookieListText: e.ThirdPartyCookieListText,
            thirdPartyTxt: e.CookieThirdPartyText,
            UseGoogleVendors: this.canUseGoogleVendors(e.PCTemplateUpgrade),
            VendorConsentModel: e.VendorConsentModel,
            VendorListText: e.VendorListText,
            Vendors: e.Vendors,
            PCCategoryStyle: e.PCCategoryStyle || ve.Checkbox,
            PCShowAlwaysActiveToggle: e.PCShowAlwaysActiveToggle,
            PCenterImprintLinkScreenReader: e.PCenterImprintLinkScreenReader,
            PCenterImprintLinkText: e.PCenterImprintLinkText,
            PCenterImprintLinkUrl: e.PCenterImprintLinkUrl,
            PCShowOptOutSignal: e.PCShowOptOutSignal,
            PCShowDoubleOptInSignal: e.PCShowDoubleOptInSignal,
            PCDoubleOptInSignalText: e.PCDoubleOptInSignalText,
            PCDoubleOptInSignalDescription: e.PCDoubleOptInSignalDescription,
            PCDoubleOptInSignalConfirmText: e.PCDoubleOptInSignalConfirmText,
            PCDoubleOptInSignalCancelText: e.PCDoubleOptInSignalCancelText,
            PCOptOutSignalText: e.PCOptOutSignalText,
            PCRegionAriaLabel: e.PCRegionAriaLabel,
            PCHostNotFound: e.PCHostNotFound,
            PCVendorNotFound: e.PCVendorNotFound,
            PCTechNotFound: e.PCTechNotFound,
            UseNonStandardStacks: e.UseNonStandardStacks,
            RequireSignatureCID: e.RequireSignatureCID,
            IsRequireSignatureEnabled: e.IsRequireSignatureEnabled,
            PCRequireSignatureHelpText: e.PCRequireSignatureHelpText,
            PCRequireSignatureFieldLabel: e.PCRequireSignatureFieldLabel,
            PCRequireSignatureHeaderText: e.PCRequireSignatureHeaderText,
            PCRequireSignatureHeaderDesc: e.PCRequireSignatureHeaderDesc,
            PCRequireSignatureRejectBtnText: e.PCRequireSignatureRejectBtnText,
            PCRequireSignatureConfirmBtnText: e.PCRequireSignatureConfirmBtnText,
            PCCookieListFiltersText: e.PCCookieListFiltersText,
            GPCOptOutNoteText: e.GPCOptOutNoteText,
            DNTOptOutNoteText: e.DNTOptOutNoteText
        };
        this.setButtonsOrder(t, e), this.setPCDomainData(t, e), this.setAdditionalTechnologies(t, e), this.setVendorServiceConfigData(t, e), this.setDomainCommonDataDefaults(t, e), this.setDomainPCDataDefaults(t, e), this.setGppData(t, e), e.PCTemplateUpgrade && (e.Center || e.Panel) && (t.PCAccordionStyle = e.PCAccordionStyle), t.PCenterEnableAccordion = e.PCAccordionStyle !== ce.NoAccordion, this.legIntSettings = e.LegIntSettings || {}, void 0 === this.legIntSettings.PAllowLI && (this.legIntSettings.PAllowLI = !0), k.moduleInitializer.MobileSDK || (this.pagePushedDown = e.BannerPushesDownPage), N = R(R({}, N), t)
    }, Qs.prototype.setButtonsOrder = function(e, t) {
        k.fp.WebButtonCustomisations && (e.PcBO = {
            0: t.PCBPOFirstPosition,
            1: t.PCBPOSecondPosition,
            2: t.PCBPOThirdPosition
        }, e.BannerBO = ((e = {})[t.BannerBPOFirstPosition] = 0, e[t.BannerBPOSecondPosition] = 1, e[t.BannerBPOThirdPosition] = 2, e[t.BannerBPOFourthPosition] = 3, e))
    }, Qs.prototype.setGppData = function(e, t) {
        e.GPPPurposes = R({}, t.GPPPurposes), e.IsGPPDataProcessingApplicable = t.IsGPPDataProcessingApplicable, e.IsGPPEnabled = t.IsGPPEnabled, e.IsGPPKnownChildApplicable = t.IsGPPKnownChildApplicable, e.IsMSPAEnabled = t.IsMSPAEnabled, e.MSPAOptionMode = t.MSPAOptionMode, e.UseGPPUSNational = t.UseGPPUSNational
    }, Qs.prototype.setPCDomainData = function(e, t) {
        e.PCAccordionStyle = ce.Caret, e.PCActiveText = t.PCActiveText, e.PCCloseButtonType = t.PCCloseButtonType, e.PCContinueText = t.PCContinueText, e.PCCookiePolicyLinkScreenReader = t.PCCookiePolicyLinkScreenReader, e.PCCookiePolicyText = t.PCCookiePolicyText, e.PCenterAllowAllConsentText = t.PCenterAllowAllConsentText, e.PCenterApplyFiltersText = t.PCenterApplyFiltersText, e.PCenterApplyFiltersAriaLabel = t.PCenterApplyFiltersAriaLabel, e.AmazonConsentSrcUrl = t.AmazonConsentSrcUrl, e.PCenterToggleActiveColor = t.PCenterToggleActiveColor, e.PCenterToggleInActiveColor = t.PCenterToggleInActiveColor, e.PCenterBackText = t.PCenterBackText, e.PCenterCancelFiltersText = t.PCenterCancelFiltersText, e.PCenterCancelFilterAriaLabel = t.PCenterCancelFilterAriaLabel, e.PCenterClearFiltersAriaLabel = t.PCenterClearFiltersAriaLabel, e.PCenterClearFiltersText = t.PCenterClearFiltersText, e.PCenterCookiesListText = t.PCenterCookiesListText, e.PCenterEnableAccordion = t.PCenterEnableAccordion, e.PCenterFilterText = t.PCenterFilterText, e.PCenterGeneralVendorsText = t.PCenterGeneralVendorsText, e.PCenterRejectAllButtonText = t.PCenterRejectAllButtonText, e.PCenterSelectAllVendorsText = t.PCenterSelectAllVendorsText, e.PCenterShowRejectAllButton = t.PCenterShowRejectAllButton, e.PCenterUserIdDescriptionText = t.PCenterUserIdDescriptionText, e.PCenterUserIdNotYetConsentedText = t.PCenterUserIdNotYetConsentedText, e.PCenterUserIdTimestampTitleText = t.PCenterUserIdTimestampTitleText, e.PCenterUserIdTitleText = t.PCenterUserIdTitleText, e.PCenterVendorListDescText = t.PCenterVendorListDescText, e.PCenterVendorListDisclosure = t.PCenterVendorListDisclosure, e.PCenterVendorListLifespan = t.PCenterVendorListLifespan, e.PCenterVendorListLifespanDay = t.PCenterVendorListLifespanDay, e.PCenterVendorListLifespanDays = t.PCenterVendorListLifespanDays, e.PCenterVendorListLifespanMonth = t.PCenterVendorListLifespanMonth, e.PCenterVendorListLifespanMonths = t.PCenterVendorListLifespanMonths, e.PCenterVendorListNonCookieUsage = t.PCenterVendorListNonCookieUsage, e.PCenterVendorListStorageDomain = t.PCenterVendorListStorageDomain, e.PCVLSDomainsUsed = t.PCVLSDomainsUsed, e.PCVLSUse = t.PCVLSUse, e.PCenterVendorListStorageIdentifier = t.PCenterVendorListStorageIdentifier, e.PCenterVendorListStoragePurposes = t.PCenterVendorListStoragePurposes, e.PCenterVendorListStorageType = t.PCenterVendorListStorageType, e.PCenterVendorsListText = t.PCenterVendorsListText, e.PCenterViewPrivacyPolicyText = t.PCenterViewPrivacyPolicyText, e.PCGoogleVendorsText = t.PCGoogleVendorsText, e.PCGrpDescLinkPosition = t.PCGrpDescLinkPosition, e.PCGrpDescType = t.PCGrpDescType, e.PCGVenPolicyTxt = t.PCGeneralVendorsPolicyText, e.PCIABVendorsText = t.PCIABVendorsText, e.PCIABVendorLegIntClaimText = t.PCIABVendorLegIntClaimText, e.PCVListDataDeclarationText = t.PCVListDataDeclarationText, e.PCVListDataRetentionText = t.PCVListDataRetentionText, e.PCVListStdRetentionText = t.PCVListStdRetentionText, e.IABDataCategories = t.IABDataCategories, e.PCInactiveText = t.PCInactiveText, e.PCIllusText = t.PCIllusText, e.PCLogoAria = t.PCLogoScreenReader, e.PCOpensCookiesDetailsAlert = t.PCOpensCookiesDetailsAlert, e.PCenterVendorListScreenReader = t.PCenterVendorListScreenReader, e.PCOpensVendorDetailsAlert = t.PCOpensVendorDetailsAlert, e.PCenterDynamicRenderingEnable = t.PCenterDynamicRenderingEnable, e.PCTemplateUpgrade = t.PCTemplateUpgrade, e.PCVendorFullLegalText = t.PCVendorFullLegalText, e.PCViewCookiesText = t.PCViewCookiesText, e.PCLayout = {
            Center: t.Center,
            List: t.List,
            Panel: t.Panel,
            Popup: t.Popup,
            Tab: t.Tab
        }, e.PCenterVendorListLinkText = t.PCenterVendorListLinkText, e.PCenterVendorListLinkAriaLabel = t.PCenterVendorListLinkAriaLabel, e.PreferenceCenterPosition = t.PreferenceCenterPosition, e.PCVendorsCountText = t.PCVendorsCountText, e.PCVendorsCountFeatureText = t.PCVendorsCountFeatureText, e.PCVendorsCountSpcFeatureText = t.PCVendorsCountSpcFeatureText, e.PCVendorsCountSpcPurposeText = t.PCVendorsCountSpcPurposeText
    }, Qs.prototype.setVendorServiceConfigData = function(e, t) {
        e.VendorServiceConfig = {
            PCVSOptOut: t.PCVSOptOut,
            PCVSEnable: t.PCVSEnable,
            PCVSExpandCategory: t.PCVSExpandCategory,
            PCVSExpandGroup: t.PCVSExpandGroup,
            PCVSCategoryView: t.PCVSCategoryView,
            PCVSNameText: t.PCVSNameText,
            PCVSAllowAllText: t.PCVSAllowAllText,
            PCVSListTitle: t.PCVSListTitle,
            PCVSParentCompanyText: t.PCVSParentCompanyText,
            PCVSAddressText: t.PCVSAddressText,
            PCVSDefaultCategoryText: t.PCVSDefaultCategoryText,
            PCVSDefaultDescriptionText: t.PCVSDefaultDescriptionText,
            PCVSDPOEmailText: t.PCVSDPOEmailText,
            PCVSDPOLinkText: t.PCVSDPOLinkText,
            PCVSPrivacyPolicyLinkText: t.PCVSPrivacyPolicyLinkText,
            PCVSCookiePolicyLinkText: t.PCVSCookiePolicyLinkText,
            PCVSOptOutLinkText: t.PCVSOptOutLinkText,
            PCVSLegalBasisText: t.PCVSLegalBasisText
        }
    }, Qs.prototype.setAdditionalTechnologies = function(e, t) {
        e.AdditionalTechnologiesConfig = {
            PCShowTrackingTech: t.PCShowTrackingTech,
            PCCookiesLabel: t.PCCookiesLabel,
            PCTechDetailsText: t.PCTechDetailsText,
            PCTrackingTechTitle: t.PCTrackingTechTitle,
            PCLocalStorageLabel: t.PCLocalStorageLabel,
            PCSessionStorageLabel: t.PCSessionStorageLabel,
            PCTechDetailsAriaLabel: t.PCTechDetailsAriaLabel,
            PCLocalStorageDurationText: t.PCLocalStorageDurationText,
            PCSessionStorageDurationText: t.PCSessionStorageDurationText
        }
    }, Qs.prototype.setDomainCommonDataDefaults = function(e, t) {
        e.AdvancedAnalyticsCategory = t.AdvancedAnalyticsCategory || "", e.BannerDPDDescription = t.BannerDPDDescription || [], e.BannerDPDDescriptionFormat = t.BannerDPDDescriptionFormat || "", e.BannerDPDTitle = t.BannerDPDTitle || "", e.CategoriesText = t.CategoriesText || "Categories", e.CookiesText = t.CookiesText || "Cookies", e.CookiesDescText = t.CookiesDescText || "Description", e.LifespanText = t.LifespanText || "Lifespan", e.LifespanTypeText = t.LifespanTypeText || "Session", e.PCenterConsentText = t.PCenterConsentText || "Consent"
    }, Qs.prototype.setDomainPCDataDefaults = function(e, t) {
        e.PCenterCookieListFilterAria = t.PCenterCookieListFilterAria || "Filter", e.PCenterCookieListSearch = t.PCenterCookieListSearch || "Search", e.PCenterCookieSearchAriaLabel = t.PCenterCookieSearchAriaLabel || "Cookie list search", e.PCenterCookieCategoriesAriaLabel = t.PCenterCookieCategoriesAriaLabel || "Cookie Categories", e.PCenterFilterAppliedAria = t.PCenterFilterAppliedAria || "Applied", e.PCenterFilterClearedAria = t.PCenterFilterClearedAria || "Filters Cleared", e.PCenterLegIntColumnHeader = t.PCenterLegIntColumnHeader || "Legitimate Interest", e.PCenterLegitInterestText = t.PCenterLegitInterestText || "Legitimate Interest", e.PCenterVendorListFilterAria = t.PCenterVendorListFilterAria || "Filter", e.PCenterVendorListSearch = t.PCenterVendorListSearch || "Search", e.PCenterVendorSearchAriaLabel = t.PCenterVendorSearchAriaLabel || "Vendor list search", e.PCFirstPartyCookieListText = t.PCFirstPartyCookieListText || "First Party Cookies", e.PCShowConsentLabels = !!t.PCTemplateUpgrade && t.PCShowConsentLabels, e.PCShowPersistentCookiesHoverButton = t.PCShowPersistentCookiesHoverButton || !1
    }, Qs.prototype.commonDataMapper = function(e) {
        var t = {
            iabThirdPartyConsentUrl: e.IabThirdPartyCookieUrl,
            optanonHideAcceptButton: e.OptanonHideAcceptButton,
            optanonHideCookieSettingButton: e.OptanonHideCookieSettingButton,
            optanonStyle: e.OptanonStyle,
            optanonStaticContentLocation: e.OptanonStaticContentLocation,
            bannerCustomCSS: e.BannerCustomCSS.replace(/\\n/g, ""),
            pcCustomCSS: e.PCCustomCSS.replace(/\\n/g, ""),
            textColor: e.TextColor,
            buttonColor: e.ButtonColor,
            buttonTextColor: e.ButtonTextColor,
            bannerMPButtonColor: e.BannerMPButtonColor,
            bannerMPButtonTextColor: e.BannerMPButtonTextColor,
            backgroundColor: e.BackgroundColor,
            bannerAccordionBackgroundColor: e.BannerAccordionBackgroundColor,
            BContinueColor: e.BContinueColor,
            PCContinueColor: e.PCContinueColor,
            pcTextColor: e.PcTextColor,
            pcButtonColor: e.PcButtonColor,
            pcButtonTextColor: e.PcButtonTextColor,
            pcAccordionBackgroundColor: e.PcAccordionBackgroundColor,
            pcLinksTextColor: e.PcLinksTextColor,
            bannerLinksTextColor: e.BannerLinksTextColor,
            pcEnableToggles: e.PcEnableToggles,
            pcBackgroundColor: e.PcBackgroundColor,
            pcMenuColor: e.PcMenuColor,
            pcMenuHighLightColor: e.PcMenuHighLightColor,
            legacyBannerLayout: e.LegacyBannerLayout,
            optanonLogo: e.OptanonLogo,
            oneTrustFtrLogo: e.OneTrustFooterLogo,
            optanonCookieDomain: e.OptanonCookieDomain,
            cookiePersistentLogo: e.CookiePersistentLogo,
            optanonGroupIdPerformanceCookies: e.OptanonGroupIdPerformanceCookies,
            optanonGroupIdFunctionalityCookies: e.OptanonGroupIdFunctionalityCookies,
            optanonGroupIdTargetingCookies: e.OptanonGroupIdTargetingCookies,
            optanonGroupIdSocialCookies: e.OptanonGroupIdSocialCookies,
            optanonShowSubGroupCookies: e.ShowSubGroupCookies,
            useRTL: e.UseRTL,
            showBannerCookieSettings: e.ShowBannerCookieSettings,
            showBannerAcceptButton: e.ShowBannerAcceptButton,
            showCookieList: e.ShowCookieList,
            allowHostOptOut: e.AllowHostOptOut,
            CookiesV2NewCookiePolicy: e.CookiesV2NewCookiePolicy,
            cookieListTitleColor: e.CookieListTitleColor,
            cookieListGroupNameColor: e.CookieListGroupNameColor,
            cookieListTableHeaderColor: e.CookieListTableHeaderColor,
            CookieListTableHeaderBackgroundColor: e.CookieListTableHeaderBackgroundColor,
            cookieListPrimaryColor: e.CookieListPrimaryColor,
            cookieListCustomCss: e.CookieListCustomCss,
            pcShowCookieHost: e.PCShowCookieHost,
            pcShowCookieDuration: e.PCShowCookieDuration,
            pcShowCookieType: e.PCShowCookieType,
            pcShowCookieCategory: e.PCShowCookieCategory,
            pcShowCookieDescription: e.PCShowCookieDescription,
            ConsentIntegration: e.ConsentIntegration,
            ConsentPurposesText: e.BConsentPurposesText || "Consent Purposes",
            FeaturesText: e.BFeaturesText || "Features",
            LegitimateInterestPurposesText: e.BLegitimateInterestPurposesText || "Legitimate Interest Purposes",
            ConsentText: e.BConsentText || "Consent",
            LegitInterestText: e.BLegitInterestText || "Legit. Interest",
            pcDialogClose: e.PCDialogClose || "dialog closed",
            pCFooterLogoUrl: e.PCFooterLogoUrl,
            SpecialFeaturesText: e.BSpecialFeaturesText || "Special Features",
            SpecialPurposesText: e.BSpecialPurposesText || "Special Purposes",
            pcCListName: e.PCCListName || "Name",
            pcCListHost: e.PCCListHost || "Host",
            pcCListDuration: e.PCCListDuration || "Duration",
            pcCListType: e.PCCListType || "Type",
            pcCListCategory: e.PCCListCategory || "Category",
            pcCListDescription: e.PCCListDescription || "Description",
            IabLegalTextUrl: e.IabLegalTextUrl,
            pcLegIntButtonColor: e.PcLegIntButtonColor,
            pcLegIntButtonTextColor: e.PcLegIntButtonTextColor,
            PCenterExpandToViewText: e.PCenterExpandToViewText,
            BCategoryContainerColor: e.BCategoryContainerColor,
            BCategoryStyleColor: e.BCategoryStyleColor,
            BLineBreakColor: e.BLineBreakColor,
            BSaveBtnColor: e.BSaveBtnColor,
            BCategoryStyle: e.BCategoryStyle,
            BAnimation: e.BAnimation,
            BFocusBorderColor: e.BFocusBorderColor,
            PCFocusBorderColor: e.PCFocusBorderColor,
            BnrLogo: e.BnrLogo,
            OTCloseBtnLogo: e.OTCloseBtnLogo,
            OTSpriteLogo: e.OTSpriteLogo,
            OTExternalLinkLogo: e.OTExternalLinkLogo,
            BannerExternalLinksLogo: this.customExternalLinkLogo(e),
            BannerRequireExternalLinks: e.BannerRequireExternalLinks,
            BannerRequireExternalLinksCustomLogo: e.BannerRequireExternalLinksCustomLogo
        };
        this.cookieListMapper(t, e), N = R(R({}, N), t), this.pubDomainData.CookiesV2NewCookiePolicy = e.CookiesV2NewCookiePolicy
    }, Qs.prototype.customExternalLinkLogo = function(e) {
        return e.BannerRequireExternalLinksCustomLogo ? e.BannerExternalLinksLogo : ""
    }, Qs.prototype.cookieListMapper = function(e, t) {
        e.TTLGroupByTech = t.TTLGroupByTech, e.TTLShowTechDesc = t.TTLShowTechDesc
    }, Qs.prototype.setPublicDomainData = function(n) {
        this.pubDomainData = {
            AboutCookiesText: n.AboutCookiesText,
            AboutLink: n.AboutLink,
            AboutText: n.AboutText,
            ActiveText: n.ActiveText,
            AddLinksToCookiepedia: n.AddLinksToCookiepedia,
            AlertAllowCookiesText: n.AlertAllowCookiesText,
            AlertCloseText: n.AlertCloseText,
            AlertLayout: n.AlertLayout,
            AlertMoreInfoText: n.AlertMoreInfoText,
            AlertMoreInfoTextDialog: n.AlertMoreInfoAriaLabel,
            AlertNoticeText: n.AlertNoticeText,
            AllowAllText: n.PreferenceCenterConfirmText,
            AlwaysActiveText: n.AlwaysActiveText,
            AlwaysInactiveText: n.AlwaysInactiveText,
            BAnimation: n.BAnimation,
            BannerCloseButtonText: n.BannerCloseButtonText,
            BannerDPDDescription: n.BannerDPDDescription || [],
            BannerDPDDescriptionFormat: n.BannerDPDDescriptionFormat || "",
            BannerDPDTitle: n.BannerDPDTitle || "",
            BannerFeatureDescription: n.BannerFeatureDescription,
            BannerFeatureTitle: n.BannerFeatureTitle,
            BannerIABPartnersLink: n.BannerIABPartnersLink,
            BannerInformationDescription: n.BannerInformationDescription,
            BannerInformationTitle: n.BannerInformationTitle,
            BannerPosition: n.BannerPosition,
            BannerPurposeDescription: n.BannerPurposeDescription,
            BannerPurposeTitle: n.BannerPurposeTitle,
            BannerRejectAllButtonText: n.BannerRejectAllButtonText,
            BannerRelativeFontSizesToggle: n.BannerRelativeFontSizesToggle,
            BannerSettingsButtonDisplayLink: n.BannerSettingsButtonDisplayLink,
            BannerShowRejectAllButton: n.BannerShowRejectAllButton,
            BannerTitle: n.BannerTitle,
            BCategoryContainerColor: n.BCategoryContainerColor,
            BCategoryStyle: n.BCategoryStyle,
            BCategoryStyleColor: n.BCategoryStyleColor,
            BCloseButtonType: n.BCloseButtonType,
            BContinueText: n.BContinueText,
            BInitialFocus: n.BInitialFocus,
            BInitialFocusLinkAndButton: n.BInitialFocusLinkAndButton,
            BLineBreakColor: n.BLineBreakColor,
            BRejectConsentType: n.BRejectConsentType,
            BSaveBtnColor: n.BSaveBtnColor,
            BSaveBtnTxt: n.BSaveBtnText,
            BShowSaveBtn: n.BShowSaveBtn,
            CategoriesText: n.CategoriesText,
            cctId: n.cctId,
            ChoicesBanner: n.ChoicesBanner,
            CloseShouldAcceptAllCookies: n.CloseShouldAcceptAllCookies,
            CloseText: n.CloseText,
            ConfirmText: n.ConfirmText,
            ConsentIntegrationData: null,
            ConsentModel: {
                Name: n.ConsentModel
            },
            CookieListDescription: n.CookieListDescription,
            CookieListTitle: n.CookieListTitle,
            CookieSettingButtonText: n.CookieSettingButtonText,
            CookiesText: n.CookiesText,
            CookiesDescText: n.CookiesDescText,
            CookiesUsedText: n.CookiesUsedText,
            CustomJs: n.CustomJs,
            Domain: k.moduleInitializer.Domain,
            FooterDescriptionText: n.FooterDescriptionText,
            ForceConsent: n.ForceConsent,
            GeneralVendors: n.GeneralVendors,
            GoogleConsent: {
                GCAdStorage: n.GCAdStorage,
                GCAnalyticsStorage: n.GCAnalyticsStorage,
                GCEnable: n.GCEnable,
                GCFunctionalityStorage: n.GCFunctionalityStorage,
                GCPersonalizationStorage: n.GCPersonalizationStorage,
                GCRedactEnable: n.GCRedactEnable,
                GCSecurityStorage: n.GCSecurityStorage,
                GCWaitTime: n.GCWaitTime,
                GCAdUserData: n.GCAdUserData,
                GCAdPersonalization: n.GCAdPersonalization
            },
            MCMData: n.MCMData,
            ACMData: n.ACMData,
            Groups: null,
            HideToolbarCookieList: n.HideToolbarCookieList,
            IabType: n.IabType,
            InactiveText: n.InactiveText,
            IsBannerLoaded: !1,
            IsConsentLoggingEnabled: n.IsConsentLoggingEnabled,
            IsIABEnabled: n.IsIabEnabled,
            IsIabThirdPartyCookieEnabled: n.IsIabThirdPartyCookieEnabled,
            IsLifespanEnabled: n.IsLifespanEnabled,
            Language: n.Language,
            LastReconsentDate: n.LastReconsentDate,
            LifespanDurationText: n.LifespanDurationText,
            LifespanText: n.LifespanText,
            LifespanTypeText: n.LifespanTypeText,
            MainInfoText: n.MainInfoText,
            MainText: n.MainText,
            ManagePreferenceText: n.PreferenceCenterManagePreferencesText,
            NextPageAcceptAllCookies: n.NextPageAcceptAllCookies,
            NextPageCloseBanner: n.NextPageCloseBanner,
            NoBanner: n.NoBanner,
            OnClickAcceptAllCookies: n.OnClickAcceptAllCookies,
            OnClickCloseBanner: n.OnClickCloseBanner,
            OverridenGoogleVendors: n.OverridenGoogleVendors,
            PCAccordionStyle: ce.Caret,
            PCCloseButtonType: n.PCCloseButtonType,
            PCContinueText: n.PCContinueText,
            PCenterAllowAllConsentText: n.PCenterAllowAllConsentText,
            PCenterApplyFiltersText: n.PCenterApplyFiltersText,
            PCenterBackText: n.PCenterBackText,
            PCenterCancelFiltersText: n.PCenterCancelFiltersText,
            PCenterClearFiltersText: n.PCenterClearFiltersText,
            PCenterCookieSearchAriaLabel: n.PCenterCookieSearchAriaLabel || "Cookie list search",
            PCenterCookieCategoriesAriaLabel: n.PCenterCookieCategoriesAriaLabel || "Cookie Categories",
            PCenterCookiesListText: n.PCenterCookiesListText,
            PCenterEnableAccordion: n.PCenterEnableAccordion,
            PCenterExpandToViewText: n.PCenterExpandToViewText,
            PCenterFilterAppliedAria: n.PCenterFilterAppliedAria || "Applied",
            PCenterFilterClearedAria: n.PCenterFilterClearedAria || "Filters Cleared",
            PCenterFilterText: n.PCenterFilterText,
            PCenterRejectAllButtonText: n.PCenterRejectAllButtonText,
            PCenterSelectAllVendorsText: n.PCenterSelectAllVendorsText,
            PCenterShowRejectAllButton: n.PCenterShowRejectAllButton,
            PCenterUserIdDescriptionText: n.PCenterUserIdDescriptionText,
            PCenterUserIdNotYetConsentedText: n.PCenterUserIdNotYetConsentedText,
            PCenterUserIdTimestampTitleText: n.PCenterUserIdTimestampTitleText,
            PCenterUserIdTitleText: n.PCenterUserIdTitleText,
            PCenterVendorListDescText: n.PCenterVendorListDescText,
            PCenterVendorSearchAriaLabel: n.PCenterVendorSearchAriaLabel || "Vendor list search",
            PCenterVendorsListText: n.PCenterVendorsListText,
            PCenterViewPrivacyPolicyText: n.PCenterViewPrivacyPolicyText,
            PCFirstPartyCookieListText: n.PCFirstPartyCookieListText,
            PCGoogleVendorsText: n.PCGoogleVendorsText,
            PCGrpDescLinkPosition: n.PCGrpDescLinkPosition,
            PCGrpDescType: n.PCGrpDescType,
            PCIABVendorsText: n.PCIABVendorsText,
            PCIABVendorLegIntClaimText: n.PCIABVendorLegIntClaimText,
            PCVListDataDeclarationText: n.PCVListDataDeclarationText,
            PCVListDataRetentionText: n.PCVListDataRetentionText,
            PCVListStdRetentionText: n.PCVListStdRetentionText,
            IABDataCategories: n.IABDataCategories,
            PCLogoAria: n.PCLogoScreenReader,
            PCOpensCookiesDetailsAlert: n.PCOpensCookiesDetailsAlert,
            PCenterVendorListScreenReader: n.PCenterVendorListScreenReader,
            PCOpensVendorDetailsAlert: n.PCOpensVendorDetailsAlert,
            PCShowPersistentCookiesHoverButton: n.PCShowPersistentCookiesHoverButton,
            PCenterDynamicRenderingEnable: n.PCenterDynamicRenderingEnable,
            PCTemplateUpgrade: n.PCTemplateUpgrade,
            PCVendorFullLegalText: n.PCVendorFullLegalText,
            PCViewCookiesText: n.PCViewCookiesText,
            PCLayout: {
                Center: n.Center,
                List: n.List,
                Panel: n.Panel,
                Popup: n.Popup,
                Tab: n.Tab
            },
            PCenterVendorListLinkText: n.PCenterVendorListLinkText,
            PCenterVendorListLinkAriaLabel: n.PCenterVendorListLinkAriaLabel,
            PCenterImprintLinkScreenReader: n.PCenterImprintLinkScreenReader,
            PCenterImprintLinkText: n.PCenterImprintLinkText,
            PCenterImprintLinkUrl: n.PCenterImprintLinkUrl,
            PreferenceCenterPosition: n.PreferenceCenterPosition,
            ScrollAcceptAllCookies: n.ScrollAcceptAllCookies,
            ScrollCloseBanner: n.ScrollCloseBanner,
            ShowAlertNotice: n.ShowAlertNotice,
            showBannerCloseButton: n.showBannerCloseButton,
            ShowPreferenceCenterCloseButton: n.ShowPreferenceCenterCloseButton,
            ThirdPartyCookieListText: n.ThirdPartyCookieListText,
            UseGoogleVendors: this.canUseGoogleVendors(n.PCTemplateUpgrade),
            VendorConsentModel: n.VendorConsentModel,
            VendorLevelOptOut: n.IsIabEnabled,
            VendorListText: n.VendorListText,
            CookiesV2NewCookiePolicy: !1
        }, n.PCTemplateUpgrade && (n.Center || n.Panel) && n.PCAccordionStyle !== ce.NoAccordion && (this.pubDomainData.PCAccordionStyle = n.PCAccordionStyle), this.pubDomainData.PCenterEnableAccordion = n.PCAccordionStyle !== ce.NoAccordion;
        var r = [];
        n.Groups.forEach(function(e) {
            var t, o;
            !n.IsIabEnabled && e.IsIabPurpose || (e.Cookies = JSON.parse(JSON.stringify(e.FirstPartyCookies)), o = null == (o = e.Hosts) ? void 0 : o.reduce(function(e, t) {
                return e.concat(JSON.parse(JSON.stringify(t.Cookies)))
            }, []), (t = e.Cookies).push.apply(t, o), r.push(e))
        }), this.pubDomainData.Groups = r
    }, Qs.prototype.setBannerScriptElement = function(e) {
        this.bannerScriptElement = e, this.setDomainElementAttributes()
    }, Qs.prototype.setGCMcallback = function() {
        window.otEventListeners && window.otEventListeners.length && window.otEventListeners.forEach(function(e) {
            e && "consent.changed" === e.event && (D.gcmUpdateCallback = e.listener)
        })
    }, Qs.prototype.setDomainElementAttributes = function() {
        var e;
        this.bannerScriptElement && ((e = "true" === h.getStubAttr(Ke) || k.moduleInitializer.LanguageDetectionEnabled && k.moduleInitializer.LanguageDetectionByHtml) && this.setUseDocumentLanguage(e), this.bannerScriptElement.hasAttribute("data-ignore-ga") && (this.ignoreGoogleAnlyticsCall = "true" === this.bannerScriptElement.getAttribute("data-ignore-ga")), this.bannerScriptElement.hasAttribute("data-ignore-html")) && (this.ignoreInjectingHtmlCss = "true" === this.bannerScriptElement.getAttribute("data-ignore-html"))
    }, Qs.prototype.setUseDocumentLanguage = function(e) {
        this.useDocumentLanguage = e
    }, Qs.prototype.setPcName = function() {
        var e = N.PCLayout;
        e.Center ? this.pcName = nt : e.Panel ? this.pcName = it : e.Popup ? this.pcName = st : e.List ? this.pcName = rt : e.Tab && (this.pcName = at)
    }, Qs.prototype.setBannerName = function() {
        N.Flat ? this.bannerName = Xe : N.FloatingRoundedCorner ? this.bannerName = Qe : N.FloatingFlat ? this.bannerName = Ze : N.FloatingRounded ? this.bannerName = et : N.FloatingRoundedIcon ? this.bannerName = $e : N.CenterRounded ? this.bannerName = Je : N.ChoicesBanner ? this.bannerName = tt : N.NoBanner && (this.bannerName = ot)
    }, Qs.prototype.populateGPCSignal = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, A.GPC_ENABLED),
            t = this.gpcForAGrpEnabled && this.gpcEnabled ? "1" : "0";
        this.gpcValueChanged = e ? e != t : this.gpcForAGrpEnabled, I.writeCookieParam(P.OPTANON_CONSENT, A.GPC_ENABLED, t)
    }, Qs.prototype.populateDNTSignal = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, A.DNT_ENABLED),
            t = this.dntForAGrpEnabled && this.DNTEnabled ? "1" : "0";
        this.dntValueChanged = e ? e != t : this.dntForAGrpEnabled, I.writeCookieParam(P.OPTANON_CONSENT, A.DNT_ENABLED, t)
    }, Qs.prototype.populateGPCBrowserSignal = function() {
        var e = I.readCookieParam(P.OPTANON_CONSENT, A.GPC_Browser_Flag),
            t = this.gpcEnabled ? "1" : "0";
        this.gpcBrowserValueChanged = e !== t, I.writeCookieParam(P.OPTANON_CONSENT, A.GPC_Browser_Flag, t)
    }, Qs.prototype.initGCM = function() {
        var o = [],
            e = (Object.keys(this.rule.States).forEach(function(t) {
                D.rule.States[t].forEach(function(e) {
                    o.push((t + "-" + e).toUpperCase())
                })
            }), D.rule.Countries.map(function(e) {
                return e.toUpperCase()
            }));
        D.gcmCountries = e.concat(o)
    }, Qs.prototype.getRegionDetailsOnRuleSet = function(e, t) {
        var o, n;
        t && 1 < t.length && (o = ["co", "va", "ut"], 1 <= (n = t.filter(function(e) {
            return !o.includes(e)
        })).length) && n.length < t.length && (e.KnownChildSensitiveDataConsents = 2)
    };
    var l = Qs;

    function Qs() {
        var t = this;
        this.DNTEnabled = "yes" === navigator.doNotTrack || "1" === navigator.doNotTrack, this.gpcEnabled = !1, this.gpcForAGrpEnabled = !1, this.dntForAGrpEnabled = !1, this.dntValueChanged = !1, this.pagePushedDown = !1, this.iabGroups = {
            purposes: {},
            legIntPurposes: {},
            specialPurposes: {},
            features: {},
            specialFeatures: {}
        }, this.iabType = null, this.grpContainLegalOptOut = !1, this.purposeOneTreatment = !1, this.ignoreInjectingHtmlCss = !1, this.ignoreGoogleAnlyticsCall = !1, this.mobileOnlineURL = [], this.iabGrpIdMap = {}, this.iabGrps = [], this.consentableGrps = [], this.consentableImpliedConsentGroup = [], this.consentableIabGrps = [], this.domainGrps = {}, this.thirdPartyiFrameLoaded = !1, this.thirdPartyiFrameResolve = null, this.thirdPartyiFramePromise = new Promise(function(e) {
            t.thirdPartyiFrameResolve = e
        }), this.isOptInMode = !1, this.isSoftOptInMode = !1, this.gpcValueChanged = !1, this.gpcBrowserValueChanged = !1, this.conditionalLogicEnabled = !1, this.allConditionsFailed = !1, this.canUseConditionalLogic = !1, this.gtmUpdatedinStub = !1, this.gcmDevIdSet = !1, this.makeGPCOrDNTConsentCall = !0, this.tcf2ActiveVendors = {
            all: 0,
            pur: new Map,
            ft: new Map,
            spl_pur: new Map,
            spl_ft: new Map,
            stack: new Map
        }, this.tcfParentMap = {
            pur: new Map,
            ft: new Map,
            spl_pur: new Map,
            spl_ft: new Map
        }
    }
    var D, N = {};

    function Zs() {
        this.otSDKVersion = "202604.2.0", this.isAMP = !1, this.ampData = {}, this.otCookieData = window.OneTrust && window.OneTrust.otCookieData || [], this.syncRequired = !1, this.isIabSynced = !1, this.isGacSynced = !1, this.grpsSynced = [], this.syncedValidGrp = !1, this.groupsConsent = [], this.initialGroupsConsent = [], this.hostsConsent = [], this.initialHostConsent = [], this.genVendorsConsent = {}, this.vsConsent = new Map, this.initialGenVendorsConsent = {}, this.vendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.initialVendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.oneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.initialOneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.addtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.initialAddtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.addtlConsentVersion = "2~", this.deletedGoogleVendors = {}, this.initialAddtlVendorsList = {}, this.isAddtlConsent = !1, this.currentGlobalFilteredList = [], this.filterByIABCategories = [], this.filterByCategories = [], this.hosts = {
            hostTemplate: null,
            hostCookieTemplate: null
        }, this.generalVendors = {
            gvTemplate: null,
            gvCookieTemplate: null
        }, this.oneTrustAlwaysActiveHosts = [], this.alwaysActiveGenVendors = [], this.softOptInGenVendors = [], this.optInGenVendors = [], this.optanonHostList = [], this.srcExecGrps = [], this.htmlExecGrps = [], this.srcExecGrpsTemp = [], this.htmlExecGrpsTemp = [], this.isPCVisible = !1, this.wasBannerVisible = !1, this.pcClosedFromCloseBtn = !1, this.dataGroupState = [], this.makeInitialTxnCall = !1, this.userLocation = {
            country: "",
            state: "",
            stateName: ""
        }, this.vendorsSetting = {}, this.dsParams = {}, this.isV2Stub = !1, this.fireOnetrustGrp = !1, this.showVendorService = !1, this.showGeneralVendors = !1, this.genVenOptOutEnabled = !1, this.gpcConsentTxn = !1, this.dntConsentTxn = !1, this.vsIsActiveAndOptOut = !1, this.bAsset = {}, this.pcAsset = {}, this.csBtnAsset = {}, this.cStyles = {}, this.vendorDomInit = !1, this.genVendorDomInit = !1, this.syncNtfyContent = {}, this.ntfyRequired = !1, this.skipAddingHTML = !1, this.bnrAnimationInProg = !1, this.isPreview = !1, this.geoFromUrl = "", this.hideBanner = !1, this.setAttributePolyfillIsActive = !1, this.storageBaseURL = "", this.isKeyboardUser = !1, this.isBotHeader = !1, this.isBotHeaderDomain = !1, this.customerStyles = new Map, this.showTrackingTech = !1, this.currentTrackingTech = {}
    }
    Zs.prototype.getVendorsInDomain = function() {
        var e, t;
        return w._vendorsInDomain || (e = new Map, t = null != (t = N.Groups) ? t : [], w.setVendorServicesMap(t, e), w._vendorsInDomain = e), w._vendorsInDomain
    }, Zs.prototype.setVendorServicesMap = function(e, t) {
        for (var o, n = 0, r = e; n < r.length; n++) {
            var i = r[n];
            i.SubGroups && 0 < i.SubGroups.length && w.setVendorServicesMap(i.SubGroups, t);
            for (var s = 0, a = null != (o = i.VendorServices) ? o : []; s < a.length; s++) {
                var l = a[s],
                    c = Object.assign({}, i);
                delete c.VendorServices, l.groupRef = c, t.set(l.CustomVendorServiceId, l)
            }
        }
    }, Zs.prototype.clearVendorsInDomain = function() {
        w._vendorsInDomain = null
    }, Zs.prototype.checkVendorConsent = function(e) {
        return w.vendorsSetting[e] && w.vendorsSetting[e].consent
    };
    var w = new Zs,
        p = w;

    function c() {
        this.IABTCF_DEFAULT_LANGUAGE = "EN", this.IABTCF_DEFAULT_SERBIAN = "SR-CYRL", this.IABTCF_DEFAULT_PORTUGUESE = "PT-PT", this.IABTCF_SUPPORTED_LANGUAGES = new Set(["AR", "BG", "BS", "CA", "CS", "CY", "DA", "DE", "EL", "EN", "ES", "ET", "EU", "FI", "FR", "GL", "HE", "HR", "HU", "HI", "ID", "IT", "JA", "KA", "KO", "LT", "LV", "MK", "MS", "MT", "NL", "NO", "PL", "PT-BR", "PT-PT", "RO", "RU", "SK", "SL", "SQ", "SR-LATN", "SR-CYRL", "SV", "SW", "TH", "TL", "TR", "UK", "VI", "ZH", "ZH-HANT"])
    }
    c.prototype.initializeBannerVariables = function(e) {
        var t = e.DomainData;
        D.iabType = t.IabType, T = t.PCTemplateUpgrade ? Ut : qt, b = "IAB2" === D.iabType ? jt : Kt, D.init(e), w.showGeneralVendors = N.GeneralVendorsEnabled && N.PCTemplateUpgrade, w.showVendorService = k.fp.CookieV2VendorServiceScript && N.VendorServiceConfig.PCVSEnable && !D.isIab2orv2Template && N.PCTemplateUpgrade, w.vsIsActiveAndOptOut = w.showVendorService && N.VendorServiceConfig.PCVSOptOut, w.showTrackingTech = k.fp.CookieV2TrackingTechPrefCenter && N.AdditionalTechnologiesConfig.PCShowTrackingTech, w.genVenOptOutEnabled = w.showGeneralVendors && N.GenVenOptOut, h.addLogoUrls(), this.ensureAmazonConsent(t), this.setGeolocationInCookies(), this.setOrUpdate3rdPartyIABConsentFlag()
    }, c.prototype.ensureAmazonConsent = function(e) {
        var t, o, n, r, i;
        try {
            window && "function" == typeof window.amznConsent || null != (t = N) && t.ACMData && N.ACMData.Enabled && (o = e.AmazonConsentSrcUrl) && !document.querySelector('script[src="' + o + '"]') && ((n = document.createElement("script")).src = o, n.async = !0, n.type = "text/javascript", (r = window.otStubData || {}).nonce && n.setAttribute("nonce", r.nonce), (i = r.crossOrigin || w.crossOrigin) && n.setAttribute("crossorigin", i), document.head.appendChild(n))
        } catch (e) {
            try {
                console.info("OT - Failed to ensure Amazon Consent script", e)
            } catch (e) {}
        }
    }, c.prototype.initializeVendorInOverriddenVendors = function(e, t) {
        N.OverriddenVendors[e] = {
            disabledCP: [],
            disabledLIP: [],
            active: t,
            legInt: !1,
            consent: !1
        }
    }, c.prototype.applyGlobalRestrictionsonNewVendor = function(e, t, o, n) {
        var r = N.GlobalRestrictions,
            i = N.OverriddenVendors;
        switch (N.Publisher.restrictions[o] || (N.Publisher.restrictions[o] = {}), i[t] || this.initializeVendorInOverriddenVendors(t, !0), i[t].disabledCP || (i[t].disabledCP = []), i[t].disabledLIP || (i[t].disabledLIP = []), r[o]) {
            case pe.Disabled:
                (n ? i[t].disabledCP : i[t].disabledLIP).push(o), N.Publisher.restrictions[o][t] = pe.Disabled;
                break;
            case pe.Consent:
                n ? (i[t].consent = !0, N.Publisher.restrictions[o][t] = pe.Consent) : (i[t].disabledLIP.push(o), this.checkFlexiblePurpose(e, t, o, !1));
                break;
            case pe.LegInt:
                n ? (i[t].disabledCP.push(o), this.checkFlexiblePurpose(e, t, o, !0)) : (i[t].legInt = !0, N.Publisher.restrictions[o][t] = pe.LegInt);
                break;
            case void 0:
                n ? i[t].consent = !0 : i[t].legInt = !0
        }
    }, c.prototype.checkFlexiblePurpose = function(e, t, o, n) {
        e.flexiblePurposes.includes(o) ? (n ? N.OverriddenVendors[t].legInt = !0 : N.OverriddenVendors[t].consent = !0, N.Publisher.restrictions[o][t] = n ? pe.LegInt : pe.Consent) : N.Publisher.restrictions[o][t] = pe.Disabled
    }, c.prototype.getActivePurposesForVendor = function(e, t) {
        var o = N.OverriddenVendors[t] && N.OverriddenVendors[t].disabledCP,
            n = N.OverriddenVendors[t] && N.OverriddenVendors[t].disabledLIP,
            o = o ? this.removeElementsFromArray(e.purposes, N.OverriddenVendors[t].disabledCP) || [] : e.purposes || [],
            n = n ? this.removeElementsFromArray(e.legIntPurposes, N.OverriddenVendors[t].disabledLIP) || [] : e.legIntPurposes || [],
            t = U(o, n, e.flexiblePurposes || []);
        return new Set(t)
    }, c.prototype.canInferGCMSettingsFromTCString = function() {
        return D.isTcfV2Template && N.GoogleConsent.GCEnable
    }, c.prototype.shouldOverrideTCData = function() {
        var e = this.canInferGCMSettingsFromTCString();
        return N.UseGoogleVendors || e
    }, c.prototype.setActiveVendorCount = function(o, e) {
        var n, r, i, s = this,
            a = [];
        "IAB2V2" === D.getRegionRuleType() && (n = new Set, r = D.tcf2ActiveVendors, (i = this.getActivePurposesForVendor(o, e)).forEach(function(e) {
            var t = r.pur.get(e) || 0;
            r.pur.set(e, t + 1), D.tcfParentMap.pur.get(e) && n.add(D.tcfParentMap.pur.get(e))
        }), o.specialPurposes && o.specialPurposes.forEach(function(e) {
            var t = r.spl_pur.get(e) || 0;
            r.spl_pur.set(e, t + 1), D.tcfParentMap.spl_pur.get(e) && (n.add(D.tcfParentMap.spl_pur.get(e)), t = D.tcfParentMap.spl_pur.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), o.features && o.features.forEach(function(e) {
            var t = r.ft.get(e) || 0;
            r.ft.set(e, t + 1), D.tcfParentMap.ft.get(e) && (n.add(D.tcfParentMap.ft.get(e)), t = D.tcfParentMap.ft.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), o.specialFeatures && o.specialFeatures.forEach(function(e) {
            var t = r.spl_ft.get(e) || 0;
            r.spl_ft.set(e, t + 1), D.tcfParentMap.spl_ft.get(e) && (n.add(D.tcfParentMap.spl_ft.get(e)), t = D.tcfParentMap.spl_ft.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), n.forEach(function(e) {
            var t = r.stack.get(e) || 0;
            r.stack.set(e, t + 1)
        }))
    }, c.prototype.updateParentCountByType = function(e, t, o, n, r) {
        var i, s, a, l;
        e && !n.includes(e) && (i = !1, a = e.split("_"), s = ["IAB2V2", "IFE2V2", "ISP2V2", "ISF2V2"].includes(a[0]), 1 < a.length) && s && (s = this.readProp(Gt, a[0]), a = parseInt(a[1]), l = void 0, (s === Gt.IAB2V2 && !r.has(a) || s !== Gt.IAB2V2 && (l = o[this.readProp(xt, s)]) && !l.includes(a)) && (i = !0), s) && i && ((r = t[s].get(a)) ? t[s].set(a, r + 1) : (t[s].set(a, 1), n.push(e)))
    }, c.prototype.readProp = function(e, t) {
        var o, n = "";
        for (o in e)
            if (t === o) {
                n = e[o];
                break
            }
        return n
    }, c.prototype.isVendorInvalid = function(e, t) {
        var o = !1,
            n = !e.purposes.length && !e.flexiblePurposes.length,
            r = (N.OverriddenVendors[t] && !N.OverriddenVendors[t].consent && (n = !0), !0);
        return D.legIntSettings.PAllowLI && e.legIntPurposes.length && (!N.OverriddenVendors[t] || N.OverriddenVendors[t].legInt) && (r = !1), o = !n || !r || e.specialPurposes.length || e.features.length || e.specialFeatures.length ? o : !0
    }, c.prototype.removeInActiveVendorsForTcf = function(r) {
        var i = this,
            s = w.iabData.vendorListVersion,
            e = N.Publisher,
            a = N.GlobalRestrictionEnabled;
        0 !== Object.keys(e).length && e && Object.keys(e.restrictions).length, Object.keys(r.vendors).forEach(function(t) {
            var o = r.vendors[t],
                e = !1,
                n = i.getVendorGVLVersion(o),
                n = (s < n && (N.NewVendorsInactiveEnabled ? (i.initializeVendorInOverriddenVendors(t, !1), e = !0) : a && (o.purposes.forEach(function(e) {
                    i.applyGlobalRestrictionsonNewVendor(o, t, e, !0)
                }), o.legIntPurposes.forEach(function(e) {
                    i.applyGlobalRestrictionsonNewVendor(o, t, e, !1)
                }))), N.OverriddenVendors[t] && !N.OverriddenVendors[t].active && (e = !0), -1 < N.Vendors.indexOf(Number(t)) && (e = !0), i.isVendorInvalid(o, t));
            (e = e || n) && delete r.vendors[t], e || i.setActiveVendorCount(o, t)
        })
    }, c.prototype.getVendorGVLVersion = function(e) {
        return D.isTcfV2Template ? e.iab2V2GVLVersion : e.iab2GVLVersion
    }, c.prototype.removeElementsFromArray = function(e, t) {
        return e.filter(function(e) {
            return !t.includes(e)
        })
    }, c.prototype.setPublisherRestrictions = function() {
        var i, t, s, a, e = N.Publisher;
        e && e.restrictions && (i = this.iabStringSDK(), t = e.restrictions, s = w.iabData, a = w.oneTrustIABConsent.vendorList.vendors, Object.keys(t).forEach(function(o) {
            var n, r = t[o],
                e = D.iabGroups.purposes[o];
            e && (n = {
                description: e.description,
                purposeId: e.id,
                purposeName: e.name
            }), Object.keys(r).forEach(function(e) {
                var t;
                w.vendorsSetting[e] && (t = w.vendorsSetting[e].arrIndex, 1 === r[e] && -1 === a[e].purposes.indexOf(Number(o)) ? s.vendors[t].purposes.push(n) : 2 === r[e] && -1 === a[e].legIntPurposes.indexOf(Number(o)) && s.vendors[t].legIntPurposes.push(n), t = i.purposeRestriction(Number(o), r[e]), w.tcModel.publisherRestrictions.add(Number(e), t))
            })
        }))
    }, c.prototype.populateVendorListTCF = function() {
        var p;
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a, l, c, d, u;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = this.iabStringSDK(), o = w.iabData, n = h.updateCorrectIABUrl(o.globalVendorListUrl), r = !this.isIABCrossConsentEnabled(), s = this.getConsentLanguage(), h.checkMobileOfflineRequest(h.getBannerVersionUrl())) ? [3, 1] : (D.mobileOnlineURL.push(n), i = t.gvl(s, n, w.gvlObj), [3, 3]);
                    case 1:
                        return l = (a = t).gvl, c = [s, null], [4, h.otFetchOfflineFile(v.getRelativeURL(n, !0))];
                    case 2:
                        i = l.apply(a, c.concat([e.sent()])), e.label = 3;
                    case 3:
                        return this.removeInActiveVendorsForTcf(i), D.tcf2ActiveVendors.all = Object.keys(i.vendors).length, w.oneTrustIABConsent.vendorList = i, this.assignIABDataWithGlobalVendorList(i), d = w, [4, t.tcModel(i)];
                    case 4:
                        d.tcModel = e.sent(), r && this.setPublisherRestrictions(), w.tcModel.cmpId = parseInt(o.cmpId), D.isTcfV2Template && (w.tcModel.useNonStandardTexts = N.UseNonStandardStacks), w.tcModel.cmpVersion = parseInt(o.cmpVersion), 0 < (u = Object.keys(i.vendors).map(Number)).length && null != (p = null == (p = w.tcModel) ? void 0 : p.vendorsDisclosed) && p.set(u);
                        try {
                            w.tcModel.consentLanguage = w.consentLanguage
                        } catch (e) {
                            w.tcModel.consentLanguage = "EN"
                        }
                        return w.tcModel.consentScreen = parseInt(o.consentScreen), w.tcModel.isServiceSpecific = r, w.tcModel.purposeOneTreatment = D.purposeOneTreatment, N.PublisherCC ? w.tcModel.publisherCountryCode = N.PublisherCC : w.userLocation.country && (w.tcModel.publisherCountryCode = w.userLocation.country), w.cmpApi = t.cmpApi(w.tcModel.cmpId, w.tcModel.cmpVersion, r, this.shouldOverrideTCData() ? {
                            getTCData: this.overrideTCData,
                            getInAppTCData: this.overrideTCData
                        } : void 0), null !== this.alertBoxCloseDate() && !this.needReconsent() || this.resetTCModel(), [2]
                }
            })
        })
    }, c.prototype.resetTCModel = function() {
        var e, t, o = this.iabStringSDK(),
            n = w.tcModel.clone();
        n.unsetAll(), D.legIntSettings.PAllowLI && (e = D.consentableIabGrps.filter(function(e) {
            return e.HasLegIntOptOut && e.Type === b.GroupTypes.Pur
        }).map(function(e) {
            return parseInt(D.iabGrpIdMap[e.CustomGroupId])
        }), t = Object.keys(w.vendorsSetting).filter(function(e) {
            return w.vendorsSetting[e].legInt
        }).map(function(e) {
            return parseInt(e)
        }), n.purposeLegitimateInterests.set(e), n.vendorLegitimateInterests.set(t), n.isServiceSpecific) && n.publisherLegitimateInterests.set(e);
        try {
            var r, i = w.oneTrustIABConsent && w.oneTrustIABConsent.vendorList,
                s = i && i.vendors;
            s && n && n.vendorsDisclosed && "function" == typeof n.vendorsDisclosed.set && (r = Object.keys(s).map(Number)).length && n.vendorsDisclosed.set(r)
        } catch (e) {
            console.info(e)
        }
        w.cmpApi.update(o.tcString().encode(n), !0)
    }, c.prototype.overrideTCData = function(e, t, o) {
        var n, r, i = B.canInferGCMSettingsFromTCString();
        t && t.tcString && (N.UseGoogleVendors && (n = (w.addtlVendors.vendorConsent || []).map(function(e) {
            return parseInt(e, 10)
        }), r = Object.keys(w.addtlVendorsList || {}).map(function(e) {
            return parseInt(e, 10)
        }).filter(function(e) {
            return !n.includes(e)
        }), t.addtlConsent = ro(n, r)), i) && (t.enableAdvertiserConsentMode = !0), "function" == typeof e ? e(t, o) : console.error("__tcfapi received invalid parameters.")
    }, c.prototype.setIabData = function() {
        w.iabData = D.isTcfV2Template ? k.moduleInitializer.Iab2V2Data : k.moduleInitializer.IabV2Data, w.iabData.consentLanguage = w.consentLanguage
    }, c.prototype.assignIABDataWithGlobalVendorList = function(o) {
        var r = this,
            i = N.OverriddenVendors,
            s = (w.iabData.vendorListVersion = o.vendorListVersion, w.iabData.vendors = [], N.IABDataCategories);
        Object.keys(o.vendors).forEach(function(n) {
            w.vendorsSetting[n] = {
                consent: !0,
                legInt: !0,
                arrIndex: 0,
                specialPurposesOnly: !1
            };
            var e = {},
                t = o.vendors[n];
            e.vendorId = n, e.vendorName = t.name, e.policyUrl = t.policyUrl, r.setIAB2VendorData(t, e), e.cookieMaxAge = t.cookieMaxAgeSeconds ? v.calculateCookieLifespan(t.cookieMaxAgeSeconds) : null, e.usesNonCookieAccess = t.usesNonCookieAccess, e.deviceStorageDisclosureUrl = t.deviceStorageDisclosureUrl || null, D.legIntSettings.PAllowLI && !r.shouldHaveVendorLIUnset(i, t, n) || (w.vendorsSetting[n].legInt = !1), D.legIntSettings.PAllowLI && r.vendorHasNoLIAndPurConsent(i, t, n) && t.specialPurposes.length && (w.vendorsSetting[n].specialPurposesOnly = !0, w.anyVendorHasOnlySplPur = !0), r.canShowConsentToggle(i, t, n), e.features = t.features.reduce(function(e, t) {
                t = D.iabGroups.features[t];
                return t && e.push({
                    description: t.description,
                    featureId: t.id,
                    featureName: t.name
                }), e
            }, []), e.specialFeatures = o.vendors[n].specialFeatures.reduce(function(e, t) {
                t = D.iabGroups.specialFeatures[t];
                return t && e.push({
                    description: t.description,
                    featureId: t.id,
                    featureName: t.name
                }), e
            }, []), r.mapDataDeclarationForVendor(o.vendors[n], e, s), r.mapDataRetentionForVendor(o.vendors[n], e), e.purposes = o.vendors[n].purposes.reduce(function(e, t) {
                var o = D.iabGroups.purposes[t];
                return !o || i[n] && i[n].disabledCP && -1 !== i[n].disabledCP.indexOf(t) || e.push({
                    description: o.description,
                    purposeId: o.id,
                    purposeName: o.name
                }), e
            }, []), e.legIntPurposes = o.vendors[n].legIntPurposes.reduce(function(e, t) {
                var o = D.iabGroups.purposes[t];
                return !o || i[n] && i[n].disabledLIP && -1 !== i[n].disabledLIP.indexOf(t) || e.push({
                    description: o.description,
                    purposeId: o.id,
                    purposeName: o.name
                }), e
            }, []), e.specialPurposes = t.specialPurposes.reduce(function(e, t) {
                t = D.iabGroups.specialPurposes[t];
                return t && e.push({
                    description: t.description,
                    purposeId: t.id,
                    purposeName: t.name
                }), e
            }, []), w.iabData.vendors.push(e), w.vendorsSetting[n].arrIndex = w.iabData.vendors.length - 1
        })
    }, c.prototype.canShowConsentToggle = function(e, t, o) {
        var n = !!D.legIntSettings.PAllowLI && t.flexiblePurposes.every(function(e) {
                return t.legIntPurposes.includes(e)
            }),
            r = !!D.legIntSettings.PAllowLI && (e[o] ? !e[o].consent : n);
        (!e[o] || e[o].consent) && (e[o] || t.purposes.length || t.flexiblePurposes.length && (t.flexiblePurposes.length, !n)) && (t.purposes.length || t.flexiblePurposes.length && (t.flexiblePurposes.length, !r)) || (w.vendorsSetting[o].consent = !1)
    }, c.prototype.vendorHasNoLIAndPurConsent = function(e, t, o) {
        return e[o] && !e[o].legInt && !e[o].consent || !e[o] && !t.legIntPurposes.length && !t.purposes.length
    }, c.prototype.shouldHaveVendorLIUnset = function(e, t, o) {
        var n = !1,
            r = !1,
            i = t.specialPurposes.length;
        return (e[o] && !e[o].legInt || !e[o] && !t.legIntPurposes.length) && (n = !0), (e[o] && !e[o].consent || !e[o] && !t.purposes.length) && (r = !0), !(!n || r === Boolean(i) && (r || i))
    }, c.prototype.mapDataDeclarationForVendor = function(e, t, n) {
        var o;
        D.isTcfV2Template && null != (o = e.dataDeclaration) && o.length && (t.dataDeclaration = e.dataDeclaration.reduce(function(e, t) {
            var o = n.find(function(e) {
                return e.Id === t
            });
            return o && e.push({
                Description: o.Description,
                Id: o.Id,
                Name: o.Name
            }), e
        }, []))
    }, c.prototype.mapDataRetentionForVendor = function(o, n) {
        var e;
        n.dataRetention = {}, D.isTcfV2Template && o.dataRetention && (null !== (null == (e = o.dataRetention) ? void 0 : e.stdRetention) && void 0 !== (null == (e = o.dataRetention) ? void 0 : e.stdRetention) && (n.dataRetention = {
            stdRetention: o.dataRetention.stdRetention
        }), Object.keys(null == (e = o.dataRetention) ? void 0 : e.purposes).length && (n.dataRetention.purposes = JSON.parse(JSON.stringify(o.dataRetention.purposes)), Object.keys(o.dataRetention.purposes).forEach(function(e) {
            var t = D.iabGroups.purposes[e];
            t && (n.dataRetention.purposes[e] = {
                name: t.name,
                id: t.id,
                retention: o.dataRetention.purposes[e]
            })
        })), Object.keys(null == (e = o.dataRetention) ? void 0 : e.specialPurposes).length) && (n.dataRetention.specialPurposes = JSON.parse(JSON.stringify(o.dataRetention.specialPurposes)), Object.keys(o.dataRetention.specialPurposes).forEach(function(e) {
            var t = D.iabGroups.specialPurposes[e];
            t && (n.dataRetention.specialPurposes[e] = {
                name: t.name,
                id: t.id,
                retention: o.dataRetention.specialPurposes[e]
            })
        }))
    }, c.prototype.setIAB2VendorData = function(e, t) {
        var o, n, r;
        D.isTcfV2Template && (n = w.lang, r = (r = e.urls.find(function(e) {
            return e.langId === n
        })) || e.urls[0], t.vendorPrivacyUrl = (null == (o = r) ? void 0 : o.privacy) || "", t.legIntClaim = (null == (o = r) ? void 0 : o.legIntClaim) || "", null != (r = e.dataDeclaration) && r.length && (t.dataDeclaration = e.dataDeclaration), e.DataRetention) && (t.DataRetention = e.DataRetention)
    }, c.prototype.populateIABCookies = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!this.isIABCrossConsentEnabled()) return [3, 5];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, this.setIAB3rdPartyCookie(P.EU_CONSENT, "", 0, !0)];
                    case 2:
                        return e.sent(), [3, 4];
                    case 3:
                        return e.sent(), this.setIABCookieData(), this.updateCrossConsentCookie(!1), [3, 4];
                    case 4:
                        return [3, 6];
                    case 5:
                        B.needReconsent() || this.setIABCookieData(), e.label = 6;
                    case 6:
                        return [2]
                }
            })
        })
    }, c.prototype.setIAB3rdPartyCookie = function(e, t, o, n) {
        var r = N.iabThirdPartyConsentUrl;
        try {
            if (r && document.body) return this.updateThirdPartyConsent(r, e, t, o, n);
            throw new ReferenceError
        } catch (e) {
            throw e
        }
    }, c.prototype.setIABCookieData = function() {
        w.oneTrustIABConsent.IABCookieValue = I.getMergedCookieByName(P.EU_PUB_CONSENT)
    }, c.prototype.updateThirdPartyConsent = function(n, r, i, s, a) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                return t = window.location.protocol + "//" + n + "/?name=" + r + "&value=" + i + "&expire=" + s + "&isFirstRequest=" + a, document.getElementById("onetrustIabCookie") ? (document.getElementById("onetrustIabCookie").contentWindow.location.replace(t), [2]) : (Ht(o = document.createElement("iframe"), "display: none;", !0), o.id = "onetrustIabCookie", o.setAttribute("title", "OneTrust IAB Cookie"), o.src = t, document.body.appendChild(o), [2, new Promise(function(e) {
                    o.onload = function() {
                        D.thirdPartyiFrameResolve(), D.thirdPartyiFrameLoaded = !0, e()
                    }, o.onerror = function() {
                        throw D.thirdPartyiFrameResolve(), D.thirdPartyiFrameLoaded = !0, e(), new URIError
                    }
                })])
            })
        })
    }, c.prototype.setIABVendor = function(n, r, i) {
        var t, s = this;
        void 0 === n && (n = !0), void 0 === r && (r = !1), void 0 === i && (i = !1), w.iabData.vendors.forEach(function(e) {
            var t, o, e = e.vendorId;
            D.legIntSettings.PAllowLI ? (o = void 0, r ? o = n : (t = w.vendorsSetting[e], i && t.legInt && !t.specialPurposesOnly ? s.updateVendorPurposeOrLI(!0, e, !1) : (o = !!w.vendorsSetting[e].consent && n, s.updateVendorPurposeOrLI(!0, e, w.vendorsSetting[e].legInt))), s.updateVendorPurposeOrLI(!1, e, o)) : (w.oneTrustIABConsent.legIntVendors = [], s.updateVendorPurposeOrLI(!1, e, n))
        }), N.UseGoogleVendors && (t = w.addtlVendors, Object.keys(w.addtlVendorsList).forEach(function(e) {
            n ? (t.vendorSelected["" + e.toString()] = !0, t.vendorConsent.push("" + e.toString())) : r && (t.vendorSelected["" + e.toString()] = !1, e = t.vendorConsent.indexOf("" + e.toString()), t.vendorConsent.splice(e, 1))
        }))
    }, c.prototype.updateVendorPurposeOrLI = function(e, t, o) {
        void 0 === o && (o = !1), (e = void 0 === e ? !1 : e) ? -1 < (e = w.oneTrustIABConsent.legIntVendors.findIndex(function(e) {
            return e.includes(t.toString() + ":true") || e.includes(t.toString() + ":false")
        })) ? w.oneTrustIABConsent.legIntVendors[e] = t.toString() + ":" + o : w.oneTrustIABConsent.legIntVendors.push(t.toString() + ":" + o) : -1 < (e = w.oneTrustIABConsent.vendors.findIndex(function(e) {
            return e.includes(t.toString() + ":true") || e.includes(t.toString() + ":false")
        })) ? w.oneTrustIABConsent.vendors[e] = t.toString() + ":" + o : w.oneTrustIABConsent.vendors.push(t.toString() + ":" + o)
    }, c.prototype.setOrUpdate3rdPartyIABConsentFlag = function() {
        var e = this.getIABCrossConsentflagData();
        N.IsIabEnabled ? e && !this.needReconsent() || this.updateCrossConsentCookie(N.IsIabThirdPartyCookieEnabled) : e && !this.reconsentRequired() && "true" !== e || this.updateCrossConsentCookie(!1)
    }, c.prototype.isIABCrossConsentEnabled = function() {
        return "true" === this.getIABCrossConsentflagData()
    }, c.prototype.getIABCrossConsentflagData = function() {
        return I.readCookieParam(P.OPTANON_CONSENT, A.IS_IAB_GLOBAL)
    }, c.prototype.setGeolocationInCookies = function() {
        var e, t = I.readCookieParam(P.OPTANON_CONSENT, A.GEO_LOCATION);
        w.userLocation && !t && this.isAlertBoxClosedAndValid() ? (e = w.userLocation.country + ";" + w.userLocation.state, this.setUpdateGeolocationCookiesData(e)) : this.reconsentRequired() && t && this.setUpdateGeolocationCookiesData("")
    }, c.prototype.iabStringSDK = function() {
        var e = k.moduleInitializer.otIABModuleData;
        if (N.IsIabEnabled && e) return {
            gvl: e.tcfSdkRef.gvl,
            tcModel: e.tcfSdkRef.tcModel,
            tcString: e.tcfSdkRef.tcString,
            cmpApi: e.tcfSdkRef.cmpApi,
            purposeRestriction: e.tcfSdkRef.purposeRestriction
        }
    }, c.prototype.setUpdateGeolocationCookiesData = function(e) {
        I.writeCookieParam(P.OPTANON_CONSENT, A.GEO_LOCATION, e)
    }, c.prototype.calculateDaysFromDateToToday = function(e) {
        var e = new Date(e),
            t = new Date,
            t = (e.setUTCHours(0, 0, 0, 0), t.setUTCHours(0, 0, 0, 0), Math.abs(t.getTime() - e.getTime()));
        return Math.ceil(t / 864e5)
    }, c.prototype.reconsentRequired = function() {
        return (k.moduleInitializer.MobileSDK || this.awaitingReconsent()) && this.needReconsent()
    }, c.prototype.awaitingReconsent = function() {
        return "true" === I.readCookieParam(P.OPTANON_CONSENT, A.AWAITING_RE_CONSENT)
    }, c.prototype.needReconsent = function() {
        var e = this.alertBoxCloseDate(),
            t = N.LastReconsentDate;
        return !!(e && t && new Date(t) > new Date(e)) || (w.isAMP && e ? this.calculateDaysFromDateToToday(e) >= N.ReconsentFrequencyDays : void 0)
    }, c.prototype.updateCrossConsentCookie = function(e) {
        I.writeCookieParam(P.OPTANON_CONSENT, A.IS_IAB_GLOBAL, e)
    }, c.prototype.alertBoxCloseDate = function() {
        return I.getCookie(P.ALERT_BOX_CLOSED)
    }, c.prototype.isAlertBoxClosedAndValid = function() {
        return null !== this.alertBoxCloseDate() && !this.reconsentRequired()
    }, c.prototype.generateLegIntButtonElements = function(e, t, o, n) {
        return S.getInnerHtmlContent('<div class="ot-leg-btn-container" data-group-id="' + t + '" data-el-id="' + t + '-leg-out" is-vendor="' + (o = void 0 === o ? !1 : o) + '">\n                    <button class="ot-obj-leg-btn-handler ' + (e ? "ot-leg-int-enabled ot-inactive-leg-btn" : "ot-active-leg-btn") + '" aria-label="' + (n = void 0 === n ? "" : n) + ", " + (e ? D.legIntSettings.PObjectLegIntText : D.legIntSettings.PObjectionAppliedText) + '">\n                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512">\n                            <path fill="' + N.pcButtonTextColor + '" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"/>\n                        </svg>\n                        <span>' + (e ? D.legIntSettings.PObjectLegIntText : D.legIntSettings.PObjectionAppliedText) + '\n                        </span>\n                    </button>\n                    <button\n                        class="ot-remove-objection-handler"\n                            data-style="color:' + N.pcButtonColor + "; " + (e ? "display:none;" : "") + '"\n                            aria-label="' + n + ", " + D.legIntSettings.PRemoveObjectionText + '"\n                    >\n                        ' + D.legIntSettings.PRemoveObjectionText + "\n                    </button>\n                </div>")
    }, c.prototype.syncAlertBoxCookie = function(e) {
        var t = N.ReconsentFrequencyDays;
        I.setCookie(P.ALERT_BOX_CLOSED, e = e || "", t, !1, new Date(e))
    }, c.prototype.syncCookieExpiry = function() {
        if (w.syncRequired) {
            var e = N.ReconsentFrequencyDays,
                t = I.getCookie(P.ALERT_BOX_CLOSED),
                o = I.getCookie(P.OPTANON_CONSENT),
                o = (I.setCookie(P.OPTANON_CONSENT, o, e, !1, new Date(t)), B.needReconsent() && I.removeAlertBox(), I.getMergedCookieByName(P.EU_PUB_CONSENT));
            if (o)
                if (B.isIABCrossConsentEnabled()) I.removeIab2();
                else
                    for (var n = I.getCookiesChunk(o, P.EU_PUB_CONSENT), r = 0, i = Object.keys(n); r < i.length; r++) {
                        var s = i[r];
                        I.setCookie(s, n[s], e, !1, new Date(t))
                    }
            o = I.getCookie(P.ADDITIONAL_CONSENT_STRING);
            o && I.setCookie(P.ADDITIONAL_CONSENT_STRING, o, e, !1, new Date(t))
        }
    }, c.prototype.syncOtPreviewCookie = function() {
        var e = I.getCookie(P.OT_PREVIEW);
        e && I.setCookie(P.OT_PREVIEW, e, 1, !1)
    }, c.prototype.dispatchConsentEvent = function() {
        window.dispatchEvent(new CustomEvent("OTConsentApplied", {
            OTConsentApplied: "yes"
        }))
    }, c.prototype.getConsentLanguage = function() {
        var e;
        return w.lang ? (e = w.lang.toUpperCase(), this.IABTCF_SUPPORTED_LANGUAGES.has(e) || (e = e.substr(0, 2), this.IABTCF_SUPPORTED_LANGUAGES.has(e)) ? e : "PT" === e ? this.IABTCF_DEFAULT_PORTUGUESE : "SR" === e ? this.IABTCF_DEFAULT_SERBIAN : this.IABTCF_DEFAULT_LANGUAGE) : this.IABTCF_DEFAULT_LANGUAGE
    };
    var $s, ea, d, B = new c,
        ta = B,
        oa = (x(na, $s = wr), na.prototype.Close = function(e) {
            g.closeBanner(!1), window.location.href = "https://otsdk//consentChanged"
        }, na.prototype.RejectAll = function(e) {
            g.rejectAllEvent(), window.location.href = "https://otsdk//consentChanged"
        }, na.prototype.AllowAll = function(e) {
            g.AllowAllV2(e), window.location.href = "https://otsdk//consentChanged"
        }, na.prototype.ToggleInfoDisplay = function() {
            u.toggleInfoDisplay()
        }, na);

    function na() {
        var e = null !== $s && $s.apply(this, arguments) || this;
        return e.mobileOnlineURL = D.mobileOnlineURL, e
    }(V = d = d || {})[V.Number = 0] = "Number", V[V.String = 1] = "String", V[V.Boolean = 2] = "Boolean", V[V.Null = 3] = "Null", V[V.Undefined = 4] = "Undefined", V[V.Identifier = 5] = "Identifier", V[V.Dot = 6] = "Dot", V[V.LeftParen = 7] = "LeftParen", V[V.RightParen = 8] = "RightParen", V[V.LeftBracket = 9] = "LeftBracket", V[V.RightBracket = 10] = "RightBracket", V[V.Comma = 11] = "Comma", V[V.Operator = 12] = "Operator", V[V.UnaryOperator = 13] = "UnaryOperator", V[V.Regex = 14] = "Regex", V[V.EOF = 15] = "EOF";
    var ra = "=!<>&|+-",
        ia = ["===", "!==", "==", "!=", ">=", "<=", ">", "<", "&&", "||", "+", "-"],
        sa = {
            true: !0,
            false: !1,
            null: null,
            undefined: void 0
        };

    function aa(e) {
        return "0" <= e && e <= "9"
    }

    function la(e) {
        return "a" <= e && e <= "z" || "A" <= e && e <= "Z" || "_" === e || "$" === e
    }

    function ca(e) {
        for (var t, o = ""; e.pos < e.input.length && (la(t = e.input[e.pos]) || aa(t));) o += e.input[e.pos], e.pos++;
        return "typeof" === o ? {
            type: d.UnaryOperator,
            value: "typeof"
        } : "return" === o ? null : o in sa ? {
            type: d.Boolean,
            value: o
        } : {
            type: d.Identifier,
            value: o
        }
    }
    var da = {
        ".": d.Dot,
        "(": d.LeftParen,
        ")": d.RightParen,
        "[": d.LeftBracket,
        "]": d.RightBracket,
        ",": d.Comma
    };

    function ua(e, t) {
        return "/" === e && (0 === (e = t).length || (e = e[e.length - 1]).type !== d.Identifier && e.type !== d.Number && e.type !== d.String && e.type !== d.RightParen && e.type !== d.RightBracket)
    }

    function pa(e, t, o) {
        return aa(e) || "-" === e && t.pos + 1 < t.input.length && aa(t.input[t.pos + 1]) && (e => 0 === e.length || (e = e[e.length - 1]).type === d.Operator || e.type === d.UnaryOperator || e.type === d.LeftParen || e.type === d.LeftBracket || e.type === d.Comma)(o)
    }

    function Ca(e, t) {
        var o, n, r = e.input[e.pos];
        if ("/" === (o = e.input)[n = e.pos] && "/" === o[n + 1])
            for (var i = e; i.pos < i.input.length && "\n" !== i.input[i.pos];) i.pos++;
        else if (ua(r, t)) t.push((e => {
            e.pos++;
            for (var t = "", o = !1; e.pos < e.input.length && (o || "/" !== e.input[e.pos]);) o = !o && "\\" === e.input[e.pos], t += e.input[e.pos], e.pos++;
            e.pos++;
            for (var n = ""; e.pos < e.input.length && /[gimsuy]/.test(e.input[e.pos]);) n += e.input[e.pos], e.pos++;
            return {
                type: d.Regex,
                value: t + "/" + n
            }
        })(e));
        else if (pa(r, e, t)) t.push(((e, t) => {
            var o = "";
            for (t && (o = "-", e.pos++); e.pos < e.input.length && (aa(e.input[e.pos]) || "." === e.input[e.pos]);) o += e.input[e.pos], e.pos++;
            return {
                type: d.Number,
                value: o
            }
        })(e, "-" === r));
        else if ("'" === (o = r) || '"' === o) t.push((e => {
            for (var t, o = e.input[e.pos], n = (e.pos++, ""); e.pos < e.input.length && e.input[e.pos] !== o;) "\\" === e.input[e.pos] && e.pos + 1 < e.input.length ? (e.pos++, n += "n" === (t = e.input[e.pos]) ? "\n" : "t" === t ? "\t" : "r" === t ? "\r" : t) : n += e.input[e.pos], e.pos++;
            return e.pos++, {
                type: d.String,
                value: n
            }
        })(e));
        else if (la(r))(n = ca(e)) && t.push(n);
        else if (-1 !== ra.indexOf(r)) t.push((e => {
            for (var t = ""; e.pos < e.input.length && -1 !== ra.indexOf(e.input[e.pos]);) t += e.input[e.pos], e.pos++;
            if ("!" === t || "!!" === t) return {
                type: d.UnaryOperator,
                value: t
            };
            if ("=>" === t) return {
                type: d.Operator,
                value: "=>"
            };
            if (-1 !== ia.indexOf(t)) return {
                type: d.Operator,
                value: t
            };
            throw new Error("Unknown operator: " + t)
        })(e));
        else {
            if (!(r in da)) throw new Error("Unexpected character: " + r + " at position " + e.pos);
            t.push({
                type: da[r],
                value: r
            }), e.pos++
        }
    }
    ha.prototype.peek = function() {
        return this.tokens[this.pos]
    }, ha.prototype.advance = function() {
        var e = this.tokens[this.pos];
        return this.pos++, e
    }, ha.prototype.expect = function(e, t) {
        var o = this.advance();
        if (o.type !== e || void 0 !== t && o.value !== t) throw new Error("Expected " + d[e] + (t ? ' "' + t + '"' : "") + " but got " + d[o.type] + ' "' + o.value + '"');
        return o
    }, ha.prototype.parse = function() {
        return this.parseExpression()
    }, ha.prototype.parseExpression = function() {
        return this.parseOr()
    }, ha.prototype.parseOr = function() {
        for (var e = this.parseAnd(); this.peek().type === d.Operator && "||" === this.peek().value;) {
            this.advance();
            e = {
                kind: "Binary",
                operator: "||",
                left: e,
                right: this.parseAnd()
            }
        }
        return e
    }, ha.prototype.parseAnd = function() {
        for (var e = this.parseEquality(); this.peek().type === d.Operator && "&&" === this.peek().value;) {
            this.advance();
            e = {
                kind: "Binary",
                operator: "&&",
                left: e,
                right: this.parseEquality()
            }
        }
        return e
    }, ha.prototype.parseEquality = function() {
        for (var e = this.parseComparison(); this.peek().type === d.Operator && ("===" === this.peek().value || "!==" === this.peek().value || "==" === this.peek().value || "!=" === this.peek().value);) e = {
            kind: "Binary",
            operator: this.advance().value,
            left: e,
            right: this.parseComparison()
        };
        return e
    }, ha.prototype.parseComparison = function() {
        for (var e = this.parseAdditive(); this.peek().type === d.Operator && (">" === this.peek().value || "<" === this.peek().value || ">=" === this.peek().value || "<=" === this.peek().value);) e = {
            kind: "Binary",
            operator: this.advance().value,
            left: e,
            right: this.parseAdditive()
        };
        return e
    }, ha.prototype.parseAdditive = function() {
        for (var e = this.parseUnary(); this.peek().type === d.Operator && ("+" === this.peek().value || "-" === this.peek().value);) e = {
            kind: "Binary",
            operator: this.advance().value,
            left: e,
            right: this.parseUnary()
        };
        return e
    }, ha.prototype.parseUnary = function() {
        return this.peek().type === d.UnaryOperator ? {
            kind: "Unary",
            operator: this.advance().value,
            operand: this.parseUnary()
        } : this.parseCallMember()
    }, ha.prototype.parseCallMember = function() {
        for (var e = this.parsePrimary();;)
            if (this.peek().type === d.Dot) {
                this.advance();
                e = {
                    kind: "Member",
                    object: e,
                    property: {
                        kind: "Literal",
                        value: this.expect(d.Identifier).value
                    },
                    computed: !1
                }
            } else if (this.peek().type === d.LeftBracket) {
            this.advance();
            var t = this.parseExpression();
            this.expect(d.RightBracket), e = {
                kind: "Member",
                object: e,
                property: t,
                computed: !0
            }
        } else {
            if (this.peek().type !== d.LeftParen) break;
            this.advance();
            for (var o = []; this.peek().type !== d.RightParen;) o.push(this.parseExpression()), this.peek().type === d.Comma && this.advance();
            this.expect(d.RightParen), e = {
                kind: "Call",
                callee: e,
                args: o
            }
        }
        return e
    }, ha.prototype.parsePrimary = function() {
        var e, t = this.peek();
        if (t.type === d.Number) return this.advance(), {
            kind: "Literal",
            value: parseFloat(t.value)
        };
        if (t.type === d.String) return this.advance(), {
            kind: "Literal",
            value: t.value
        };
        if (t.type === d.Boolean) return this.advance(), {
            kind: "Literal",
            value: sa[t.value]
        };
        if (t.type === d.Regex) return this.advance(), e = t.value.lastIndexOf("/"), {
            kind: "Regex",
            pattern: t.value.substring(0, e),
            flags: t.value.substring(e + 1)
        };
        if (t.type === d.Identifier) return this.advance(), {
            kind: "Identifier",
            name: t.value
        };
        if (t.type === d.LeftParen) return this.parseParenOrArrow();
        if (t.type === d.LeftBracket) return this.parseArray();
        throw new Error("Unexpected token: " + d[t.type] + ' "' + t.value + '"')
    }, ha.prototype.parseParenOrArrow = function() {
        var e = this.pos;
        if (this.isArrowFunction()) return this.pos = e, this.parseArrowFunction();
        this.pos = e, this.advance();
        e = this.parseExpression();
        return this.expect(d.RightParen), e
    }, ha.prototype.isArrowFunction = function() {
        this.advance();
        for (var e = 1; this.pos < this.tokens.length && 0 < e;) this.peek().type === d.LeftParen && e++, this.peek().type === d.RightParen && e--, 0 < e && this.advance();
        return this.peek().type === d.RightParen && (this.advance(), this.peek().type === d.Operator) && "=>" === this.peek().value
    }, ha.prototype.parseArrowFunction = function() {
        this.advance();
        for (var e = []; this.peek().type !== d.RightParen;) {
            var t = this.expect(d.Identifier);
            e.push(t.value), this.peek().type === d.Comma && this.advance()
        }
        return this.expect(d.RightParen), this.expect(d.Operator, "=>"), {
            kind: "ArrowFunction",
            params: e,
            body: this.parseExpression()
        }
    }, ha.prototype.parseArray = function() {
        this.advance();
        for (var e = []; this.peek().type !== d.RightBracket;) e.push(this.parseExpression()), this.peek().type === d.Comma && this.advance();
        return this.expect(d.RightBracket), {
            kind: "Array",
            elements: e
        }
    };
    var ga = ha;

    function ha(e) {
        this.tokens = e, this.pos = 0
    }
    var ya = ["window", "document", "navigator", "location", "screen", "localStorage", "sessionStorage", "Math", "Date", "JSON", "TRUE"],
        fa = ["includes", "indexOf", "startsWith", "endsWith", "test", "find", "some", "every", "filter", "map", "querySelector", "querySelectorAll", "getElementById", "getElementsByClassName", "getElementsByTagName", "toString", "toLowerCase", "toUpperCase", "trim", "charAt", "substring", "substr", "slice", "split", "match", "search", "replace", "concat", "getVar", "getItem", "getAttribute", "hasAttribute", "parse", "stringify", "now", "floor", "ceil", "round", "random", "abs", "max", "min", "keys"];

    function Sa(e, t) {
        switch (e.kind) {
            case "Literal":
                return e.value;
            case "Regex":
                return new RegExp(e.pattern, e.flags);
            case "Identifier":
                var o = e.name,
                    n = t;
                return o in n ? n[o] : "TRUE" === o || (-1 !== ya.indexOf(o) || void 0 !== window[o] ? window[o] : void 0);
            case "Array":
                return e.elements.map(function(e) {
                    return Sa(e, t)
                });
            case "Unary":
                var r = e,
                    n = t,
                    i = Sa(r.operand, n);
                switch (r.operator) {
                    case "!":
                        return !i;
                    case "!!":
                        return !!i;
                    case "typeof":
                        return typeof i;
                    case "-":
                        return -i;
                    default:
                        throw new Error("Unknown unary operator: " + r.operator)
                }
                return;
            case "Binary":
                var s = e,
                    o = t;
                if ("&&" === s.operator) return Sa(s.left, o) && Sa(s.right, o);
                if ("||" === s.operator) return Sa(s.left, o) || Sa(s.right, o);
                var a = Sa(s.left, o),
                    l = Sa(s.right, o);
                switch (s.operator) {
                    case "===":
                        return a === l;
                    case "!==":
                        return a !== l;
                    case "==":
                        return a == l;
                    case "!=":
                        return a != l;
                    case ">":
                        return l < a;
                    case "<":
                        return a < l;
                    case ">=":
                        return l <= a;
                    case "<=":
                        return a <= l;
                    case "+":
                        return a + l;
                    case "-":
                        return a - l;
                    default:
                        throw new Error("Unknown binary operator: " + s.operator)
                }
                return;
            case "Member":
                var c = e,
                    d = t,
                    u = Sa(c.object, d);
                return null != u ? c.computed ? (d = Sa(c.property, d), u[d]) : (d = c.property.value, u[d]) : void 0;
            case "Call":
                var c = e,
                    p = t,
                    u = void 0;
                if ("Member" === c.callee.kind) {
                    if (null == (u = Sa(c.callee.object, p))) throw new Error("Cannot call method on null/undefined");
                    var C = c.callee,
                        g = void 0;
                    if (!(e => -1 !== fa.indexOf(e))(g = C.computed ? Sa(C.property, p) : C.property.value)) throw new Error("Method not allowed: " + g);
                    C = u[g]
                } else {
                    if ("Identifier" === c.callee.kind && !(c.callee.name in p)) throw new Error("Standalone function call not allowed: " + c.callee.name);
                    C = Sa(c.callee, p)
                }
                if ("function" != typeof C) throw new Error("Not a function");
                return g = c.args.map(function(e) {
                    return Sa(e, p)
                }), C.apply(u, g);
            case "ArrowFunction":
                return h = e, y = t,
                    function() {
                        var e, t = {};
                        for (e in y) y.hasOwnProperty(e) && (t[e] = y[e]);
                        for (var o = 0; o < h.params.length; o++) t[h.params[o]] = arguments[o];
                        return Sa(h.body, t)
                    };
            default:
                throw new Error("Unknown node kind: " + e.kind)
        }
        var h, y
    }

    function ma(e) {
        var t;
        if (e) return "true" === (t = (e = (e => {
            var t = e.trim();
            for (0 === t.indexOf("return ") && (t = t.substring(7)); 0 < t.length && ";" === t[t.length - 1];) t = t.substring(0, t.length - 1).trim();
            return 0 === t.indexOf("else if") ? t = t.substring(7).trim() : 0 === t.indexOf("else") && (t = t.substring(4).trim()), t
        })(e)).toLowerCase()) || "false" !== t && (t = (e => {
            for (var t, o = [], n = {
                    input: e,
                    pos: 0
                }; n.pos < e.length;) " " === (t = e[n.pos]) || "\t" === t || "\n" === t || "\r" === t ? n.pos++ : Ca(n, o);
            return o.push({
                type: d.EOF,
                value: ""
            }), o
        })(e), Sa(new ga(t).parse(), {}))
    }
    Aa.prototype.syncConsentProfile = function(t, e, o) {
        void 0 === o && (o = !1), t ? w.dsParams.id = t.trim() : t = w.dsParams.id, o && (w.dsParams.isAnonymous = o), e = e || w.dsParams.token, t && e && Yt.getConsentProfile(t, e).then(function(e) {
            e = Array.isArray(e) ? e[0] : null;
            va.consentProfileCallback(e, t)
        })
    }, Aa.prototype.checkCarryOverAnonConsentForIAB = function() {
        if (null == (o = D.consentableIabGrps) || !o.length) return {
            iabSyncRequired: !1,
            latestConsentDate: new Date(0)
        };
        if (!D.checkLocalConsentForIabPurposes) return {
            iabSyncRequired: !1,
            latestConsentDate: new Date(0)
        };
        var e, t, o = !1,
            n = w.consentPreferences,
            r = n && 0 < n.purposes.length;
        if (D.carryOverAnonymousConsent ? (e = (t = this.checkLatestConsentDate(D.serverLatestDateForCookies)).consentedDate, t = t.isLocalConsentLatest) : (t = !1, i = this.getLastesConsentDateFromIabConsent(), D.serverLatestDateForCookies > (e = i) && (e = D.serverLatestDateForCookies)), this.checkIfServerConsent(r, t)) {
            I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_CONSENT, ""), I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_HAD_TOKEN, "");
            var o = !0,
                i = "",
                s = (Array.isArray(n.consentStrings) && n.consentStrings.length && (i = (null == (s = n.consentStrings.find(function(e) {
                    return "tcfeu" === e.type
                })) ? void 0 : s.content) || ""), n.gacString || "");
            if (i) {
                w.isIabSynced = !0, w.syncRequired = !0;
                for (var a = I.getCookiesChunk(i, P.EU_PUB_CONSENT), l = 0, c = Object.keys(a); l < c.length; l++) {
                    var d = c[l];
                    I.setCookie(d, a[d], N.ReconsentFrequencyDays, !1, new Date(e))
                }
            }
            s && (w.isGacSynced = !0, w.syncRequired = !0, I.setCookie(P.ADDITIONAL_CONSENT_STRING, s, N.ReconsentFrequencyDays, !1, new Date(e)))
        }
        return this.forceConsentReceipt(r, t, [], !0), {
            iabSyncRequired: o,
            latestConsentDate: e
        }
    }, Aa.prototype.syncPreferences = function(e, t) {
        void 0 === t && (t = !1);
        var o, n = I.getCookie(P.ALERT_BOX_CLOSED),
            r = n,
            i = !1,
            s = !0,
            a = !1,
            l = !1,
            c = !1,
            d = v.strToArr(I.readCookieParam(P.OPTANON_CONSENT, "groups")),
            u = [];
        if (e && null != (o = e.purposes) && o.length) {
            this.checkIfConsentIsGiven(e);
            for (var p = void 0, C = 0, g = e.purposes; C < g.length; C++) {
                var h, y = g[C],
                    f = this.syncGroupWithPreferences(y, d, r, a, t),
                    i = i || f.syncRequired,
                    a = a || f.syncOnlyDate,
                    c = c || f.gpcOverrideApplied,
                    l = l || f.isLocalConsentLatest;
                f.isLocalConsentLatest && (h = (y = D.domainGrps[y.id]) ? L.getGroupById(y) : null) && "COOKIE" === h.Type && u.push(y), (!p || new Date(f.latestConsentDate) > new Date(p)) && (p = f.latestConsentDate)
            }
            n = p
        } else s = !1, N.Groups.forEach(function(e) {
            e.CustomGroupId && "COOKIE" === e.Type && u.push(e.CustomGroupId)
        });
        return this.forceConsentReceipt(s, l, u), {
            alertBoxCookieVal: n,
            groupsConsent: d,
            profileFound: s,
            syncRequired: i,
            syncOnlyDate: a = a && !i,
            gpcOverrideApplied: c
        }
    }, Aa.prototype.checkIfConsentIsGiven = function(e) {
        for (var t = 0, o = e.purposes; t < o.length; t++) {
            var n = o[t],
                r = D.domainGrps[n.id];
            r && this.isCookieGroup(r) && (D.consentGiven = D.consentGiven || n.status !== H[H.NO_CONSENT] && n.status !== H[H.ALWAYS_ACTIVE])
        }
    }, Aa.prototype.syncGroupWithPreferences = function(e, t, o, n, r) {
        var i = D.domainGrps[e.id],
            n = {
                syncRequired: !1,
                syncOnlyDate: n,
                latestConsentDate: o,
                isLocalConsentLatest: !1,
                gpcOverrideApplied: !1
            };
        if (!i || !this.isCookieGroup(i)) return n;
        this.markGroupAsSyncedIfValid(i);
        var o = new Date(e.lastInteractionDate) > new Date(o),
            s = (n.isLocalConsentLatest = !o, L.getGroupById(i));
        return this.shouldSyncGroup(o, s) ? e.status === H[H.NO_CONSENT] ? (this.removeGroupFromConsent(i, t), n) : this.syncGroupConsent(e, i, s, t, r, n) : n
    }, Aa.prototype.markGroupAsSyncedIfValid = function(e) {
        -1 < w.grpsSynced.indexOf(e) && (w.syncedValidGrp = !0)
    }, Aa.prototype.shouldSyncGroup = function(e, t) {
        var o = D.carryOverAnonymousConsent,
            t = D.gpcEnabled && t && t.IsGpcEnabled;
        return !o && D.consentGiven || o && e || t
    }, Aa.prototype.removeGroupFromConsent = function(t, e) {
        var o = e.findIndex(function(e) {
            return e.split(":")[0] === t
        }); - 1 < o && (e.splice(o, 1), w.grpsSynced.push(t))
    }, Aa.prototype.syncGroupConsent = function(e, t, o, n, r, i) {
        var s = this.getConsentValue(e.status),
            o = (D.gpcEnabled && o && o.IsGpcEnabled && "1" === s && (s = "0", o.isDeniedByGPC = !0, i.gpcOverrideApplied = !0), i.syncOnlyDate = !0, i.latestConsentDate = e.lastInteractionDate, !i.gpcOverrideApplied && r);
        return i.syncRequired = this.updateCookieCatConsent(o, t, s, n), i
    }, Aa.prototype.updateCookieCatConsent = function(e, t, o, n) {
        var r = !1;
        if (!e) {
            for (var i = t + ":" + o, s = -1, a = 0; a < n.length; a++) {
                var l = n[a].split(":");
                if (l[0] === t) {
                    l[1] !== o && (n[a] = i, r = !0), s = a;
                    break
                }
            } - 1 === s && (n.push(i), r = !0)
        }
        return r
    }, Aa.prototype.getConsentValue = function(e) {
        var t = null;
        switch (e) {
            case H[H.ACTIVE]:
            case H[H.ALWAYS_ACTIVE]:
                t = ge.Active;
                break;
            case H[H.EXPIRED]:
            case H[H.OPT_OUT]:
            case H[H.PENDING]:
            case H[H.WITHDRAWN]:
                t = ge.InActive
        }
        return t
    }, Aa.prototype.isCookieGroup = function(e) {
        return !/IABV2|ISPV2|IFEV2|ISFV2|IAB2V2|IFE2V2|ISP2V2|ISF2V2/.test(e)
    }, Aa.prototype.hideBannerAndPc = function() {
        var e = h.isBannerVisible();
        e && h.hideBanner(), (e || w.isPCVisible) && (Ro.removeAddedOTCssStyles(), Jo.hideConsentNoticeV2())
    }, Aa.prototype.setOptanonConsentCookie = function(e, t) {
        var o;
        (e.syncRequired || e.gpcOverrideApplied) && (I.writeCookieParam(P.OPTANON_CONSENT, "groups", e.groupsConsent.toString()), o = I.getCookie(P.OPTANON_CONSENT), I.setCookie(P.OPTANON_CONSENT, o, t, !1, new Date(e.alertBoxCookieVal)), I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_CONSENT, ""), I.writeCookieParam(P.OPTANON_CONSENT, A.IS_ANONYMOUS_CONSENT, "0"), I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_HAD_TOKEN, ""))
    }, Aa.prototype.setIabCookie = function(e, t, o, n) {
        var e = this.checkLatestConsentDate(new Date(e)),
            r = e.isLocalConsentLatest,
            i = e.consentedDate,
            e = "",
            n = (n && Array.isArray(n.consentStrings) && n.consentStrings.length && (e = (null == (s = n.consentStrings.find(function(e) {
                return "tcfeu" === e.type
            })) ? void 0 : s.content) || ""), (null == (s = n) ? void 0 : s.gacString) || ""),
            s = e || n;
        if (this.checkIfServerConsent(!!s, r)) {
            if (t.syncRequired = !0, t.profileFound = !0, t.alertBoxCookieVal = i.toISOString(), e)
                for (var a = I.getCookiesChunk(e, P.EU_PUB_CONSENT), l = 0, c = Object.keys(a); l < c.length; l++) {
                    var d = c[l];
                    I.setCookie(d, a[d], o, !1, new Date(i))
                }
            n && I.setCookie(P.ADDITIONAL_CONSENT_STRING, n, o, !1, new Date(i))
        } else s || (t.profileFound = !1);
        this.forceConsentReceipt(t.profileFound, r)
    }, Aa.prototype.setAddtlVendorsCookie = function(e, t) {
        N.UseGoogleVendors && !I.getCookie(P.ADDITIONAL_CONSENT_STRING) && I.setCookie(P.ADDITIONAL_CONSENT_STRING, w.addtlConsentVersion, t, !1, new Date(e.alertBoxCookieVal))
    }, Aa.prototype.updateGrpsDom = function(s) {
        for (var e = 0, t = y.getAllGroupElements(); e < t.length; e++)(e => {
            var t, o = e.getAttribute("data-optanongroupid"),
                n = L.getGroupById(o),
                r = !0,
                i = v.findIndex(w.groupsConsent, function(e) {
                    return e.split(":")[0] === o
                });
            (-1 < i && w.groupsConsent[i].split(":")[1] === ge.InActive || N.IsIabEnabled && s && "COOKIE" !== n.Type && -1 < (t = s.purposes.findIndex(function(e) {
                return e.id === n.PurposeId.toLowerCase()
            })) && -1 === ["ACTIVE", "ALWAYS_ACTIVE"].findIndex(function(e) {
                return e === s.purposes[t].status
            })) && (r = !1), y.toggleGrpElements(e, n, r), y.toogleSubGroupElement(e, r, !1, !0), y.toogleSubGroupElement(e, r, !0, !0)
        })(t[e])
    }, Aa.prototype.updateVendorsDom = function() {
        N.IsIabEnabled && (C.updateIabVariableReference(), zn.toggleVendorConsent(), D.legIntSettings.PAllowLI) && (D.legIntSettings.PShowLegIntBtn ? zn.updateVendorLegBtns() : zn.toggleVendorLi())
    }, Aa.prototype.consentProfileCallback = function(r, i) {
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this.checkIfKnownUsersAreLogged(r, i) ? [2] : (t = this.syncPreferences(r), w.consentPreferences = r, n = N.ReconsentFrequencyDays, o = ta.isIABCrossConsentEnabled(), this.updateConsentCookies(t, n, o, r), Nr.setDataSubjectIdV2(i), (t.syncRequired || t.gpcOverrideApplied) && t.profileFound ? [4, this.performFullConsentSync(t, n, o, r)] : [3, 2]);
                    case 1:
                        return e.sent(), [3, 3];
                    case 2:
                        t.alertBoxCookieVal && (n = D.forceCreateTrxLocalConsentIsGreater && Ms.shouldCreateForceReceipt(), t.profileFound && !n || (n && Ms.recordForceReceiptSent(), this.createTrans(n))), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, Aa.prototype.updateConsentCookies = function(e, t, o, n) {
        this.setOptanonConsentCookie(e, t), N.IsIabEnabled && !o && this.setIabCookie(e.alertBoxCookieVal, e, t, n), e.syncOnlyDate && (ta.syncAlertBoxCookie(e.alertBoxCookieVal), ta.syncCookieExpiry())
    }, Aa.prototype.performFullConsentSync = function(t, o, n, r) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this.markUserAsKnown(t), this.setAddtlVendorsCookie(t, o), this.hideBannerAndPc(), g.closeOptanonAlertBox(), js.initGrpsAndHosts(), [4, this.showSyncNotificationIfNeeded(n)];
                    case 1:
                        return e.sent(), this.updateIabIfEnabled(), this.refreshUiAndTriggerEvents(r), this.createGpcTransactionIfNeeded(t), [2]
                }
            })
        })
    }, Aa.prototype.markUserAsKnown = function(e) {
        I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_CONSENT, ""), I.writeCookieParam(P.OPTANON_CONSENT, A.IS_ANONYMOUS_CONSENT, "0"), I.writeCookieParam(P.OPTANON_CONSENT, A.PREV_USER_HAD_TOKEN, ""), w.syncRequired = e.syncRequired || e.gpcOverrideApplied, ta.syncAlertBoxCookie(e.alertBoxCookieVal)
    }, Aa.prototype.showSyncNotificationIfNeeded = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return !t && N.NtfyConfig.ShowNtfy && ta.isAlertBoxClosedAndValid() ? [4, an.getContent()] : [3, 2];
                    case 1:
                        e.sent(), an.init(), an.changeState(), e.label = 2;
                    case 2:
                        return [2]
                }
            })
        })
    }, Aa.prototype.updateIabIfEnabled = function() {
        N.IsIabEnabled && (ta.setIABCookieData(), js.initializeIabPurposeConsentOnReload(), ao.populateVendorAndPurposeFromCookieData())
    }, Aa.prototype.refreshUiAndTriggerEvents = function(e) {
        this.updateGrpsDom(e), this.updateVendorsDom(), Ao.setLandingPathParam(A.NOT_LANDING_PAGE), on.substitutePlainTextScriptTags(), Zo.updateGtmMacros(!0), g.executeOptanonWrapper()
    }, Aa.prototype.createGpcTransactionIfNeeded = function(e) {
        e.gpcOverrideApplied && N.IsConsentLoggingEnabled && Ms.createConsentTxn(!1, "GPC value changed", !1, !0, !0, "GPC")
    }, Aa.prototype.shouldCreateAnonymousTransaction = function(e) {
        return (!e.profileFound || D.forceCreateTrxLocalConsentIsGreater) && !!e.alertBoxCookieVal
    }, Aa.prototype.checkIfKnownUsersAreLogged = function(e, t) {
        var o = I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID),
            n = I.readCookieParam(P.OPTANON_CONSENT, A.PREV_USER_CONSENT),
            r = I.readCookieParam(P.OPTANON_CONSENT, A.PREV_USER_HAD_TOKEN),
            e = 0 < (null == (e = null == (e = e) ? void 0 : e.purposes) ? void 0 : e.length);
        return o !== t && !n && "1" === r && (I.removeAllCookies(), !e) && (!N.ShowAlertNotice || N.NoBanner || w.hideBanner || u.initializeAlartHtmlAndHandler(), Nr.setDataSubjectIdV2(t), !0)
    }, Aa.prototype.createTrans = function(e) {
        var t = I.readCookieParam(P.OPTANON_CONSENT, "iType");
        Ms.createConsentTxn(!1, Ce[t], !1, !0, e)
    }, Aa.prototype.checkLatestConsentDate = function(e) {
        var t = I.getCookie(P.ALERT_BOX_CLOSED),
            t = t ? new Date(t) : new Date(0),
            o = this.getLastesConsentDateFromIabConsent();
        return t < o ? {
            isLocalConsentLatest: !1,
            consentedDate: o < e ? e : o
        } : t < e ? {
            isLocalConsentLatest: !1,
            consentedDate: e
        } : {
            isLocalConsentLatest: !0,
            consentedDate: t
        }
    }, Aa.prototype.getLastesConsentDateFromIabConsent = function() {
        var e = w.consentPreferences;
        if (!e) return new Date(0);
        for (var t = D.consentableIabGrps.reduce(function(e, t) {
                return e[t.PurposeId] = t, e
            }, {}), o = null, n = 0, r = e.purposes; n < r.length; n++) {
            var i = r[n];
            t[i.id.toUpperCase()] && (i = new Date(i.lastInteractionDate), !o || o < i) && (o = i)
        }
        return o
    }, Aa.prototype.checkIfServerConsent = function(e, t) {
        var o = D.carryOverAnonymousConsent;
        return !!(!o && e || o && e && !t)
    }, Aa.prototype.forceConsentReceipt = function(e, t, o, n) {
        var r, i;
        void 0 === o && (o = []), (n = void 0 !== n && n) || this.hasAnyGroupWithFirstPartyCookies(o) ? (n = D.carryOverAnonymousConsent, o = !(!(o = I.readCookieParam(P.OPTANON_CONSENT, A.PREV_USER_CONSENT)) || "" === o || "0" === o), r = I.readCookieParam(P.OPTANON_CONSENT, A.PREV_USER_HAD_TOKEN), i = I.readCookieParam(P.OPTANON_CONSENT, A.IS_ANONYMOUS_CONSENT), D.forceCreateTrxLocalConsentIsGreater = D.forceCreateTrxLocalConsentIsGreater || (o || "0" === i && "0" === r) && (!e || n && t)) : D.forceCreateTrxLocalConsentIsGreater = !1
    }, Aa.prototype.hasAnyGroupWithFirstPartyCookies = function(e) {
        return 0 !== (e = void 0 === e ? [] : e).length && e.map(function(e) {
            return L.getGroupById(e)
        }).filter(Boolean).some(function(e) {
            return !!(e.FirstPartyCookies && 0 < e.FirstPartyCookies.length) || !!(e.SubGroups && 0 < e.SubGroups.length) && e.SubGroups.some(function(e) {
                return e.FirstPartyCookies && 0 < e.FirstPartyCookies.length
            })
        })
    };
    var va, Ta = Aa;

    function Aa() {}
    ka.prototype.removeCookies = function() {
        I.removePreview(), I.removeOptanon(), I.removeAlertBox(), I.removeIab2(), I.removeAddtlStr(), I.removeVariant(), p.isPreview && Pa.setPreviewCookie(), p.urlParams.get("otreset") && p.urlParams.set("otreset", "false");
        var e = window.location.pathname + "?" + p.urlParams.toString() + window.location.hash;
        Pa.replaceHistory(e)
    }, ka.prototype.setPreviewCookie = function() {
        var e = new Date,
            t = (e.setTime(e.getTime() + 864e5), p.geoFromUrl ? "&geo=" + p.geoFromUrl : ""),
            e = "expiry=" + e.toISOString() + t;
        I.setCookie(P.OT_PREVIEW, e, 1, !1)
    }, ka.prototype.bindStopPreviewEvent = function() {
        (window.attachEvent || window.addEventListener)("message", function(e) {
            return Pa.onMessage(e)
        })
    }, ka.prototype.replaceHistory = function(e) {
        history.pushState({}, "", e), location.reload()
    }, ka.prototype.onMessage = function(e) {
        "string" == typeof e.data && e.data === Pa.CLEAR_COOKIES && (Pa.removeCookies(), e.source) && e.source.postMessage && e.source.postMessage(Pa.CLEARED_COOKIES, e.origin)
    };
    var Pa, V = ka;

    function ka() {
        this.CLEAR_COOKIES = "CLEAR_OT_COOKIES", this.CLEARED_COOKIES = "CLEARED_OT_COOKIES"
    }
    Ea.prototype.isSelfHostedMode = function() {
        var e;
        return (null == (e = null == (e = k) ? void 0 : e.moduleInitializer) ? void 0 : e.ScriptType) === je.LOCAL
    }, Ea.prototype.getSessionEndpoint = function() {
        var e;
        return (null == (e = null == (e = k) ? void 0 : e.moduleInitializer) ? void 0 : e.SessionTrackingUrl) || ""
    }, Ea.prototype.getDomainId = function() {
        var e;
        return (null == (e = w) ? void 0 : e.dataDomainId) || ""
    }, Ea.prototype.hasValidSessionCookie = function() {
        var e = this.getDomainId();
        if (e)
            for (var t = 0, o = document.cookie.split(";"); t < o.length; t++) {
                var n = o[t].trim().split("=");
                if (n[0] === P.SESSION_TRACKING && n[1] === e) return !0
            }
        return !1
    }, Ea.prototype.setSessionCookie = function() {
        var e, t = this.getDomainId();
        t && ((e = new Date).setTime(e.getTime() + 864e5), e = "expires=" + e.toUTCString(), document.cookie = P.SESSION_TRACKING + "=" + t + "; " + e + "; path=/; SameSite=Lax")
    }, Ea.prototype.callSessionEndpoint = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!(o = this.getDomainId())) return console.warn("[OT Session Tracking] Domain ID not available"), [2, !1];
                        if (!(t = this.getSessionEndpoint())) return console.warn("[OT Session Tracking] Session endpoint URL not configured"), [2, !1];
                        o = {
                            domainId: o
                        }, e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, fetch(t, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(o),
                            credentials: "omit"
                        })];
                    case 2:
                        return (n = e.sent()).ok ? [2, !0] : (console.warn("[OT Session Tracking] Session endpoint returned status: " + n.status), [2, !1]);
                    case 3:
                        return n = e.sent(), console.warn("[OT Session Tracking] Failed to call session endpoint:", n), [2, !1];
                    case 4:
                        return [2]
                }
            })
        })
    }, Ea.prototype.trackSession = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this.isSelfHostedMode() ? !this.getSessionEndpoint() || this.hasValidSessionCookie() ? [2] : [4, this.callSessionEndpoint()] : [2];
                    case 1:
                        return e.sent() && this.setSessionCookie(), [2]
                }
            })
        })
    };
    var Ia, ba, La = Ea;

    function Ea() {}
    xe.initPolyfill(), I = new e, h = new i, D = new l, zt = new t, Pa = new V, (e = window.otStubData) && (k.moduleInitializer = e.domainData, k.fp = k.moduleInitializer.TenantFeatures, w.isAMP = e.isAmp, w.dataDomainId = e.domainId, w.isPreview = e.isPreview, w.urlParams = e.urlParams, w.isV2Stub = e.isV2Stub || !1, D.gtmUpdatedinStub = e.gtmUpdated, e.isReset ? Pa.removeCookies() : e.isPreview && Pa.setPreviewCookie(), e.isV2Stub && (D.landingPath = e.landingPathValue), D.setBannerScriptElement(e.stubElement), D.setRegionRule(e.regionRule), k.fp.CookieV2TargetedTemplates && (D.conditionalLogicEnabled = !(null == (ba = D.getRegionRule().Conditions) || !ba.length), D.conditionalLogicEnabled) && ((() => {
            for (var e = D.getRegionRule(), t = 0; t < e.Conditions.length; t++) try {
                if ((e => {
                        if (e) return ma(window.atob(e))
                    })(e.Conditions[t].Expression)) return D.Condition = e.Conditions[t]
            } catch (e) {
                console.warn(e);
                continue
            }
            D.allConditionsFailed = !0
        })(), D.canUseConditionalLogic = !D.allConditionsFailed), w.userLocation = e.userLocation, w.crossOrigin = e.crossOrigin, D.bannerDataParentURL = e.bannerBaseDataURL, D.mobileOnlineURL = U(D.mobileOnlineURL, e.mobileOnlineURL), ba = D.getRegionRule(), D.multiVariantTestingEnabled = k.moduleInitializer.MultiVariantTestingEnabled && 0 < ba.Variants.length && h.isDateCurrent(ba.TestEndTime), D.otDataLayer = e.otDataLayer, w.grpsSynced = e.grpsSynced || [], w.isIabSynced = e.isIabSynced, w.isGacSynced = e.isGacSynced, w.syncRequired = e.isIabSynced || e.isGacSynced || e.grpsSynced && 0 < e.grpsSynced.length, w.consentPreferences = e.preferences, w.syncGrpId = e.syncGrpId, w.consentApi = e.consentApi, w.tenantId = e.tenantId, w.geoFromUrl = e.geoFromUrl, w.nonce = e.nonce, w.setAttributePolyfillIsActive = e.setAttributePolyfillIsActive, w.storageBaseURL = e.storageBaseURL, w.identifierType = e.identifierType, w.isBotHeaderDomain = !!e.isBotHeaderDomain, D.previewMode = e.previewMode, D.prevUserWasAnon = e.prevUserWasAnon, D.userHasProfile = e.userHasProfile, D.consentGiven = e.consentGiven, D.serverLatestDateForCookies = e.serverLatestDateForCookies, D.carryOverAnonymousConsent = e.domainData.AuthenticatedConsent, D.checkLocalConsentForIabPurposes = e.checkLocalConsentForIabPurposes, D.forceCreateTrxLocalConsentIsGreater = e.forceCreateTrxLocalConsentIsGreater, D.stubUrl = e.stubUrl, D.sriHash = e.sriHash, D.isShopify = e.isShopify, D.createLoggedoutTrans = e.createLoggedoutTrans, zt.populateLangSwitcherPlhdr(), window.otStubData = {
            userLocation: w.userLocation
        }, window.OneTrustStub = null),
        function() {
            F(this, void 0, void 0, function() {
                var i, s, a, l;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (L = new fo, y = new Js, Qt = new oo, C = new sn, on = new nn, g = new rr, u = new Ar, _ = new hr, yr = new fr, br = new Lr, k.fp.CookieV2TrackingTechnologies || (Pr = new kr), No = new wo, mo = new vo, js = new Ws, Zo = new $o, Or = new _r, uo = new po, E = new tn, va = new Ta, zn = new Wn, Yt = new Jt, Vo = new Go, Jo = new Xo, O = new Xn, cr = new dr, pr = new Cr, mr = new vr, Ia = new La, k.moduleInitializer.MobileSDK ? ea = new oa : Nr = new wr, ao = new lo, n = I.getCookie(P.ALERT_BOX_CLOSED), r = I.getCookie(P.OPTANON_CONSENT), n && !r && I.removeAlertBox(), D.setGCMcallback(), l = D.getRegionRule(), l = (D.canUseConditionalLogic ? D.Condition : l).UseGoogleVendors, D.isIab2orv2Template = "IAB2" === D.getRegionRuleType() || "IAB2V2" === D.getRegionRuleType(), D.isTcfV2Template = "IAB2V2" === D.getRegionRuleType(), D.isIab2orv2Template) ? [4, Promise.all([Yt.getLangJson(), Yt.fetchGvlObj(), l ? Yt.fetchGoogleVendors() : Promise.resolve(null), Yt.loadCMP()])] : [3, 2];
                        case 1:
                            return l = e.sent(), i = l[0], s = l[1], a = l[2], w.gvlObj = s, w.addtlVendorsList = a ? a.vendors : null, [3, 4];
                        case 2:
                            return [4, Yt.getLangJson()];
                        case 3:
                            i = e.sent(), e.label = 4;
                        case 4:
                            return i.DomainData.IsGPPEnabled ? [4, Yt.loadGPP()] : [3, 6];
                        case 5:
                            e.sent(), Hs = new Rs, e.label = 6;
                        case 6:
                            return i.DomainData.PCShowDoubleOptInSignal ? [4, Yt.loadConfirmDialog()] : [3, 8];
                        case 7:
                            e.sent(), window.OneTrust_ConfirmDialog && window.OneTrust_ConfirmDialog.initConfirmDialog(), e.label = 8;
                        case 8:
                            var t, o;
                            return function(v) {
                                var T;
                                F(this, void 0, void 0, function() {
                                    var m;
                                    return M(this, function(e) {
                                        switch (e.label) {
                                            case 0:
                                                window.OneTrust = window.Optanon = Object.assign({}, window.OneTrust, (e => {
                                                    var t, o = k.moduleInitializer.MobileSDK,
                                                        n = {
                                                            AllowAll: (t = o ? ea : Nr).AllowAll,
                                                            BlockGoogleAnalytics: t.BlockGoogleAnalytics,
                                                            Close: t.Close,
                                                            getCSS: t.getCSS,
                                                            GetDomainData: t.GetDomainData,
                                                            getGeolocationData: t.getGeolocationData,
                                                            getHTML: t.getHTML,
                                                            Init: t.Init,
                                                            InitializeBanner: t.InitializeBanner,
                                                            initializeCookiePolicyHtml: t.initCookiePolicyAndSettings,
                                                            InsertHtml: t.InsertHtml,
                                                            InsertScript: t.InsertScript,
                                                            IsAlertBoxClosed: t.IsAlertBoxClosed,
                                                            IsAlertBoxClosedAndValid: t.IsAlertBoxClosedAndValid,
                                                            LoadBanner: t.LoadBanner,
                                                            OnConsentChanged: uo.OnConsentChanged,
                                                            ReconsentGroups: t.ReconsentGroups,
                                                            RejectAll: t.RejectAll,
                                                            SetAlertBoxClosed: t.SetAlertBoxClosed,
                                                            setGeoLocation: t.setGeoLocation,
                                                            ToggleInfoDisplay: t.ToggleInfoDisplay,
                                                            TriggerGoogleAnalyticsEvent: t.TriggerGoogleAnalyticsEvent,
                                                            useGeoLocationService: t.useGeoLocationService,
                                                            FetchAndDownloadPC: t.FetchAndDownloadPC,
                                                            changeLanguage: t.changeLang,
                                                            testLog: t.getTestLogData,
                                                            UpdateConsent: t.updateSingularConsent,
                                                            IsVendorServiceEnabled: t.vendorServiceEnabled,
                                                            UpdateGCM: t.updateGCM
                                                        };
                                                    return e.IsConsentLoggingEnabled && (n.getDataSubjectId = t.getDataSubjectId, n.setConsentProfile = t.setConsentProfile, n.setDataSubjectId = t.setDataSubjectIdV2, n.getDSDefaultIdentifier = t.getDSDefaultIdentifier, w.isV2Stub ? n.syncConsentProfile = va.syncConsentProfile : n.SendReceipt = t.sendReceipt), o && (n.mobileOnlineURL = t.mobileOnlineURL, n.otCookieData = w.otCookieData), e.IsIabEnabled && (n.updateConsentFromCookies = uo.updateConsentFromCookie, n.getPingRequest = ao.getPingRequestForTcf, n.getVendorConsentsRequestV2 = ao.getVendorConsentsRequestV2, n.showVendorsList = t.showVendorsList), n
                                                })(v.DomainData)), B.initializeBannerVariables(v), go = new ho, Io = new _o, Ms = new Us, Ro = new Wo, Ao = new Po, sr = new ar, an = new jn;
                                                var t = window.OTExternalConsent;
                                                if (t && t.consentedDate && (t.groups || t.dsId || t.tcString || t.addtlString)) {
                                                    console.info("Consent is being passed to SDK through OTExternalConsent and is accepted.", t);
                                                    var o = [],
                                                        n = t.groups.split(",");
                                                    if (n.forEach(function(e) {
                                                            e = e.split(":");
                                                            o.push({
                                                                lastInteractionDate: t.consentedDate,
                                                                status: "1" === e[1] ? H[H.ACTIVE] : H[H.OPT_OUT],
                                                                id: e[0]
                                                            }), w.grpsSynced.push(e[0])
                                                        }), w.consentPreferences = {
                                                            purposes: [],
                                                            gacString: "",
                                                            consentStrings: []
                                                        }, w.syncRequired = !0, go.updateGroupsInCookie(P.OPTANON_CONSENT, n), I.setCookie(P.ALERT_BOX_CLOSED, t.consentedDate, 365), t.dsId && !I.readCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID, !0) && I.writeCookieParam(P.OPTANON_CONSENT, A.CONSENT_ID, t.dsId), t.tcString) {
                                                        w.isIabSynced = !0;
                                                        for (var r = I.getCookiesChunk(t.tcString, P.EU_PUB_CONSENT), i = 0, s = Object.keys(r); i < s.length; i++) {
                                                            var a = s[i];
                                                            I.setCookie(a, r[a], 365)
                                                        }
                                                    }
                                                    t.addtlString && (w.isGacSynced = !0, I.setCookie(P.ADDITIONAL_CONSENT_STRING, "" + t.addtlString, 365))
                                                }
                                                w.isPreview && (B.syncOtPreviewCookie(), Pa.bindStopPreviewEvent()), w.isV2Stub && (n = va.syncPreferences(w.consentPreferences, !0), c = va.checkCarryOverAnonConsentForIAB(), d = c.iabSyncRequired, c = c.latestConsentDate, d && (n.alertBoxCookieVal = c.toISOString()), n.syncRequired = n.syncRequired || d, (w.syncRequired || n.syncRequired) && B.syncAlertBoxCookie(n.alertBoxCookieVal), n.gpcOverrideApplied) && n.profileFound && (w.syncRequired = !0, I.writeCookieParam(P.OPTANON_CONSENT, "groups", n.groupsConsent.toString()), B.syncAlertBoxCookie(n.alertBoxCookieVal), js.initGrpsAndHosts(), Zo.updateGtmMacros(!0), N.IsConsentLoggingEnabled) && Ms.createConsentTxn(!1, "GPC value changed", !1, !0, !0, "GPC"), B.syncCookieExpiry();
                                                var l, c = v,
                                                    d = window.OneTrust.dataSubjectParams || {},
                                                    d = ((w.dsParams = d).id && (l = d.identifierType || (null == (l = c.CommonData.ConsentIntegration) ? void 0 : l.DefaultIdentifier), Nr.setDataSubjectIdV2(d.id, d.isAnonymous, l)), null == (l = d.identifierType) ? void 0 : l.trim());
                                                return w.isV2Stub && (l = void 0, f = null == (f = w.identifierType) ? void 0 : f.trim(), l = f || d || (null == (f = c.CommonData.ConsentIntegration) ? void 0 : f.DefaultIdentifier), I.writeCookieParam(P.OPTANON_CONSENT, A.IDENTIFIER_TYPE, l)), D.multiVariantTestingEnabled && D.selectedVariant && I.setCookie(P.SELECTED_VARIANT, D.selectedVariant.Id, N.ReconsentFrequencyDays), w.isV2Stub && null != (T = D.landingPath) && T.length && N.NextPageCloseBanner && Ao.setLandingPathParam(D.landingPath), [4, ao.initializeIABModule()];
                                            case 1:
                                                return e.sent(), [4, function() {
                                                    var o;
                                                    return F(this, void 0, void 0, function() {
                                                        var t;
                                                        return M(this, function(e) {
                                                            switch (e.label) {
                                                                case 0:
                                                                    return null == (o = N) || !o.ACMData || !N.ACMData.Enabled || null != (o = w.userLocation) && o.country ? [3, 2] : [4, Yt.getGeolocation(k.moduleInitializer)];
                                                                case 1:
                                                                    t = e.sent(), w.userLocation = {
                                                                        country: t.country,
                                                                        state: t.state,
                                                                        stateName: t.stateName
                                                                    }, e.label = 2;
                                                                case 2:
                                                                    return [2]
                                                            }
                                                        })
                                                    })
                                                }()];
                                            case 2:
                                                return e.sent(), window.OneTrust.Init(!0), v.DomainData.IsGPPEnabled && Hs.initGppConsent(), [4, js.fetchAssets()];
                                            case 3:
                                                e.sent(), br.initBanner(), uo.assetResolve(!0), No.initialiseCssReferences(), m = B.isIABCrossConsentEnabled();
                                                var u, p, C, g, h, y, f = v;
                                                if (w.isV2Stub && D.createLoggedoutTrans) try {
                                                    N.ConsentIntegration || (N.ConsentIntegration = (null == (p = null == (u = f) ? void 0 : u.CommonData) ? void 0 : p.ConsentIntegration) || (null == (C = f) ? void 0 : C.ConsentIntegration) || {});
                                                    var S = N.ConsentIntegration;
                                                    Boolean((null == (g = S) ? void 0 : g.ConsentApi) || (null == (h = S) ? void 0 : h.AnonymousConsentApi) || (null == (y = S) ? void 0 : y.CROConsentApi)) && Ms && Ms.createConsentTxn(!1, Ce[12], !1, !0, !0)
                                                } catch (e) {
                                                    console.info("Error creating anonymous receipt on logout", e)
                                                } finally {
                                                    D.createLoggedoutTrans = !1
                                                }
                                                return (w.syncedValidGrp || w.isIabSynced || w.isGacSynced) && !m && N.NtfyConfig.ShowNtfy && B.isAlertBoxClosedAndValid() ? (w.ntfyRequired = !0, [4, an.getContent()]) : [3, 5];
                                            case 4:
                                                e.sent(), e.label = 5;
                                            case 5:
                                                return m || window.OneTrust.LoadBanner(), [2]
                                        }
                                        var d, c
                                    })
                                })
                            }(i), k.moduleInitializer.WebFormIntegrationEnabled && k.moduleInitializer.WebFormSrcUrl && (n = window.otStubData, r = document.createElement("script"), t = k.moduleInitializer.WebFormSrcUrl, r.type = "text/javascript", r.src = t, o = k.moduleInitializer.TenantGuid, k.moduleInitializer.ScriptType === je.TEST && (o += "-test"), r.setAttribute("dataId", o), r.setAttribute("worker", k.moduleInitializer.WebFormWorkerUrl), n.charset && r.setAttribute("charset", n.charset), n.crossOrigin && r.setAttribute("crossorigin", n.crossOrigin), document.querySelector('script[src="' + t + '"]') || document.getElementsByTagName("head")[0].appendChild(r)), Ia.trackSession(), [2]
                    }
                    var n, r
                })
            })
        }()
})();