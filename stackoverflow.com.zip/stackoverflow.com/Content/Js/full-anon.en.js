(() => {
    var __webpack_modules__ = {
            84155: function(e, t, n) {
                var i;
                ! function(t) {
                    "use strict";

                    function s() {}
                    var a = s.prototype,
                        o = [],
                        r = !!o.indexOf;

                    function c(e, t) {
                        if (r) return t.indexOf(e);
                        for (var n = t.length; n--;)
                            if (t[n] === e) return n;
                        return -1
                    }
                    a.getListeners = function(e) {
                        var t = this._events || (this._events = {});
                        return t[e] || (t[e] = [])
                    }, a.addListener = function(e, t) {
                        var n = this.getListeners(e);
                        return -1 === c(t, n) && n.push(t), this
                    }, a.removeListener = function(e, t) {
                        var n = this.getListeners(e),
                            i = c(t, n);
                        return -1 !== i && (n.splice(i, 1), 0 === n.length && (this._events[e] = null)), this
                    }, a.addListeners = function(e, t) {
                        return this.manipulateListeners(!1, e, t)
                    }, a.removeListeners = function(e, t) {
                        return this.manipulateListeners(!0, e, t)
                    }, a.manipulateListeners = function(e, t, n) {
                        var i, s, a = e ? this.removeListener : this.addListener,
                            o = e ? this.removeListeners : this.addListeners;
                        if ("object" == typeof t)
                            for (i in t) t.hasOwnProperty(i) && (s = t[i]) && ("function" == typeof s ? a.call(this, i, s) : o.call(this, i, s));
                        else
                            for (i = n.length; i--;) a.call(this, t, n[i]);
                        return this
                    }, a.removeEvent = function(e) {
                        return e ? this._events[e] = null : this._events = null, this
                    }, a.emitEvent = function(e, t) {
                        for (var n = this.getListeners(e), i = n.length; i--;) !0 === n[i].apply(null, t || o) && this.removeListener(e, n[i]);
                        return this
                    }, void 0 === (i = function() {
                        return s
                    }.call(t, n, t, e)) || (e.exports = i)
                }("undefined" != typeof window ? window : this || {})
            },
            76517: (e, t, n) => {
                "use strict";
                n.d(t, {
                    O: () => i
                });
                const i = {
                    LEFT_MOUSE: 1,
                    MIDDLE_MOUSE: 2,
                    BACKSPACE: 8,
                    TAB: 9,
                    ENTER: 13,
                    ESC: 27,
                    SPACE: 32,
                    PAGEUP: 33,
                    PAGEDOWN: 34,
                    END: 35,
                    HOME: 36,
                    LEFT: 37,
                    UP: 38,
                    RIGHT: 39,
                    DOWN: 40,
                    DEL: 46,
                    0: 48,
                    1: 49,
                    2: 50,
                    3: 51,
                    4: 52,
                    5: 53,
                    6: 54,
                    7: 55,
                    8: 56,
                    9: 57,
                    A: 65,
                    B: 66,
                    C: 67,
                    D: 68,
                    E: 69,
                    F: 70,
                    G: 71,
                    H: 72,
                    I: 73,
                    J: 74,
                    K: 75,
                    L: 76,
                    M: 77,
                    N: 78,
                    O: 79,
                    P: 80,
                    Q: 81,
                    R: 82,
                    S: 83,
                    T: 84,
                    U: 85,
                    V: 86,
                    W: 87,
                    X: 88,
                    Y: 89,
                    Z: 90,
                    F4: 115,
                    COMMA: 188
                }
            },
            70957: (e, t, n) => {
                var i = {
                    "./00_InlineAuth.js": 51062,
                    "./01_Vote.js": 61762,
                    "./02_SignupModal.js": 67708
                };

                function s(e) {
                    var t = a(e);
                    return n(t)
                }

                function a(e) {
                    if (!n.o(i, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return i[e]
                }
                s.keys = function() {
                    return Object.keys(i)
                }, s.resolve = a, e.exports = s, s.id = 70957
            },
            33817: (e, t, n) => {
                "use strict";
                n.d(t, {
                    track: () => i
                });
                n(89621);

                function i(...e) {
                    return StackExchange.gps.track(...e)
                }
            },
            96771: (e, t, n) => {
                var i = {
                    "./se-char-counter.js": 26634,
                    "./se-draggable.js": 91204,
                    "./se-post-editor-text-input.js": 47298,
                    "./se-share-sheet.js": 57144
                };

                function s(e) {
                    var t = a(e);
                    return n(t)
                }

                function a(e) {
                    if (!n.o(i, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return i[e]
                }
                s.keys = function() {
                    return Object.keys(i)
                }, s.resolve = a, e.exports = s, s.id = 96771
            },
            26169: (e, t, n) => {
                var i = {
                    "./00_Header.js": 18370,
                    "./02_TopBar.js": 20420,
                    "./03_Notify.js": 53185,
                    "./04_MoveScroller.js": 4224,
                    "./05_StyleCode.js": 32276,
                    "./07_TagMenu.js": 78165,
                    "./08_UserMenu.js": 26047,
                    "./09_ChatAd.js": 66473,
                    "./10_TagSanitizer.js": 33959,
                    "./11_Question.js": 72745,
                    "./12_Comments.js": 51e3,
                    "./14_TagRenderer.js": 2509,
                    "./18_jQueryCaretPlugin.js": 42304,
                    "./19_NoCaptcha.js": 66590,
                    "./20_Analytics.js": 89621,
                    "./21_OpenID.js": 18821,
                    "./22_UniversalAuth.js": 64956,
                    "./33_AnonFkeyCookie.js": 29304,
                    "./34_jqueryUiLoader.js": 72573,
                    "./36_FlashMessage.js": 19425,
                    "./37_PrepareEditor.js": 84935,
                    "./39_Auth.js": 97477,
                    "./41_Checklist.js": 85736,
                    "./44_StacksValidation.js": 84901,
                    "./45_HomepageWizardModal.js": 61560
                };

                function s(e) {
                    var t = a(e);
                    return n(t)
                }

                function a(e) {
                    if (!n.o(i, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return i[e]
                }
                s.keys = function() {
                    return Object.keys(i)
                }, s.resolve = a, e.exports = s, s.id = 26169
            },
            24934: (e, t, n) => {
                "use strict";
                n.d(t, {
                    nT: () => i
                });
                StackExchange.debug;

                function i(e, t, n) {
                    e.each((function() {
                        Stacks.setTooltipText(this, t, n)
                    }))
                }
            },
            98535: (e, t, n) => {
                var i = {
                    "./chess.mod": [29761, 9761],
                    "./mathHideUserRep.mod": [40636, 636],
                    "./poker.mod": [75045, 5045]
                };

                function s(e) {
                    if (!n.o(i, e)) return Promise.resolve().then((() => {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        s = t[0];
                    return n.e(t[1]).then((() => n(s)))
                }
                s.keys = () => Object.keys(i), s.id = 98535, e.exports = s
            },
            30530: (e, t, n) => {
                "use strict";
                n.r(t), n.d(t, {
                    Svg: () => i
                }), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                class i {
                    static getSvg(e) {
                        const t = $(e),
                            n = () => t;
                        return n.With = function(e) {
                            return t.clone().addClass(e)
                        }, n.WithAttr = function(e) {
                            const n = t.clone();
                            return n.attr(e), n
                        }, n
                    }
                }
                i.AchievementsSm = i.getSvg(n(39984)), i.Alert = i.getSvg(n(55698)), i.AlertCircle = i.getSvg(n(46522)), i.AlertSm = i.getSvg(n(23314)), i.Checkmark = i.getSvg(n(81979)), i.Clear = i.getSvg(n(99071)), i.ClearSm = i.getSvg(n(49399)), i.DevTo = i.getSvg(n(70854)), i.Facebook = i.getSvg(n(57948)), i.HelpSm = i.getSvg(n(86957)), i.Link = i.getSvg(n(60424)), i.People = i.getSvg(n(33529)), i.ShareSm = i.getSvg(n(82421)), i.TrendingDown = i.getSvg(n(29107)), i.TrendingNone = i.getSvg(n(86045)), i.TrendingUp = i.getSvg(n(30604)), i.Twitter = i.getSvg(n(24381)), i.UndoSm = i.getSvg(n(12034)), i.IndustrySm = i.getSvg(n(65306))
            },
            3421: (e, t, n) => {
                var i = n(30530),
                    s = n(34160),
                    a = i.Svg;
                void 0 === s.Svg && (s.Svg = a), e.exports = i
            },
            34160: (e, t, n) => {
                "use strict";
                e.exports = function() {
                    if ("object" == typeof globalThis) return globalThis;
                    var e;
                    try {
                        e = this || new Function("return this")()
                    } catch (e) {
                        if ("object" == typeof window) return window;
                        if ("object" == typeof self) return self;
                        if (void 0 !== n.g) return n.g
                    }
                    return e
                }()
            },
            51062: (e, t, n) => {
                "use strict";
                var i = n(76517);
                var s, a = n(1977);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.InlineAuth = (s = {
                    using_universal_ui: !1,
                    getSsrc: function(e) {
                        var t = $('#login-form input[name="ssrc"]'),
                            n = void 0;
                        return t && 1 === t.length && (n = t.val()), n || (n = e), n
                    },
                    init: function() {
                        var e = [],
                            t = [],
                            n = [],
                            o = [],
                            r = [],
                            c = null,
                            l = null,
                            u = null,
                            d = null;
                        this.setOAuthInfo("", "");
                        var h = function(e, t, n) {
                            return StackExchange.helpers.showMessage(e, t, n)
                        };
                        $("#openid-buttons").on("click", ".js-major-provider", (function(e) {
                            var t = $(this).data("provider");
                            t && (StackExchange.using("gps", (function() {
                                StackExchange.gps.track("signup.start", {
                                    openid_provider: t,
                                    location: s.getSsrc("signup_inline"),
                                    tid: StackExchange.options.user.tid
                                }, !0)
                            })), StackExchange.settings.signup.enableSignupProductEvents && (0, a.H)("signup.start", {
                                source: window.location.href,
                                openIdProvider: t,
                                location: s.getSsrc("signup_inline"),
                                trackingId: StackExchange.options.user.tid
                            }), StackExchange.settings.auth.oauthInPopup && function(e, t, n, i, s) {
                                const a = n.top.outerHeight / 2 + n.top.screenY - s / 2,
                                    o = n.top.outerWidth / 2 + n.top.screenX - i / 2;
                                n.open(e, t, `toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=${i}, height=${s}, top=${a}, left=${o}`)
                            }("", "oauth-frame", window, 500, 550), s.signin($(this), e, !0))
                        }));
                        var _ = $("#se-login-fields");
                        $(_).on("keyup", "input[name=inline-password],input[name=inline-display-name],input[name=inline-email]", (function(e) {
                            var t = $(e.target);
                            if (!t.data("entered")) {
                                var n = "signup." + t.attr("name").replace("display-", "") + ".entered";
                                t.data("entered", !0), StackExchange.using("gps", (function() {
                                    StackExchange.gps.track(n, {}, !0)
                                }))
                            }
                        })), $("#se-login-fields").on("click", "input[name=submit-button]", (function() {
                            StackExchange.using("gps", (function() {
                                StackExchange.gps.track("signup.se.click", {}, !0)
                            }))
                        })), $(".js-terms").on("click", "a[name=privacy],a[name=tos]", (function(e) {
                            var t = "signup." + $(e.target).attr("name") + ".click";
                            StackExchange.using("gps", (function() {
                                StackExchange.gps.track(t, {}, !0)
                            }))
                        }));
                        var p = null,
                            f = null,
                            g = $("input.js-inline-signup");
                        $('input.js-inline-signup, input[name="password2"]').on("keyup focus paste", (function() {
                            if (0 === g.val().length) {
                                var e = __tr(["$pStart$Password must contain at least eight characters, including:$pEnd$ $listStart$ $itemStart$ letters $itemEnd$ $itemStart$ numbers $itemEnd$ $listEnd$"], {
                                    pStart: "<p>",
                                    pEnd: "</p>",
                                    listStart: "<ul>",
                                    listEnd: "</ul>",
                                    itemStart: "<li>",
                                    itemEnd: "</li>"
                                }, "en", []);
                                T(t, {
                                    id: "pw-requirements",
                                    index: -1,
                                    attachTo: g,
                                    message: e
                                })
                            } else C(t, "pw-requirements"), O(!0);
                            for (var n = null, i = 0; i < t.length; i++)
                                if (n) {
                                    var s = n.index;
                                    t[i].index < s && (n = t[i])
                                } else n = t[i];
                            n ? p && f == n.attachTo ? p.find(".message-text").html(n.message) : (p && (p.remove(), f = null), f = n.attachTo, p = h(f, n.message, {
                                position: y(f),
                                css: {
                                    width: "250px;",
                                    color: "#fff"
                                },
                                cssClass: "_black",
                                closeOthers: !1,
                                dismissable: !1,
                                type: "info"
                            }), n.popup && n.popup.fadeOutAndRemove()) : p && (p.remove(), p = null, f = null)
                        })), $('input[name="submit-button"]').on("click", (function() {
                            p && (p.remove(), p = null, f = null)
                        }));
                        var m = $('<div class="caps-lock-warning"></div>').text(__tr(["Caps lock is on"], undefined, "en", [])),
                            v = $("input.js-inline-signup"),
                            w = !1;
                        v.on("keypress", (function(e) {
                            var t = String.fromCharCode(e.which);
                            if (/[a-z]/i.test(t)) {
                                var n = t == t.toUpperCase();
                                w = n && !e.shiftKey
                            }
                            var i = !1 === document.msCapsLockWarningOff;
                            w && !i ? v.after(m) : m.remove()
                        })), v.on("blur", (function() {
                            m.remove()
                        }));
                        var b = !1;
                        $("#login-form input").on("blur", (function(e) {
                            "" == $(e.target).val() || b || (StackExchange.gps.track("signup.start", {
                                openid_provider: "Stack Exchange",
                                location: s.getSsrc("signup_inline"),
                                tid: StackExchange.options.user.tid
                            }, !0), StackExchange.settings.signup.enableSignupProductEvents && (0, a.H)("signup.start", {
                                source: window.location.href,
                                openIdProvider: "Stack Exchange",
                                location: s.getSsrc("signup_inline"),
                                trackingId: StackExchange.options.user.tid
                            }), b = !0)
                        })), $("#login-form input[type='text'], #login-form input[type='password'], #login-form input[type='email']").on("keypress", (function(e) {
                            if (e.which === i.O.ENTER) return $("#submit-button").is(":hidden") ? $("#login-form").trigger("submit") : $("#login-form input[name='submit-button']").trigger("click"), e.preventDefault(), !1
                        }));
                        var k = function(e, t) {
                                if (e.length > 0) {
                                    if (null != t) {
                                        for (var n = !0, i = 0; i < e.length; i++)
                                            if (e[i].message == t.message) {
                                                n = !1;
                                                break
                                            }
                                        e[0].changed = n
                                    }
                                    return e[0]
                                }
                                return null != t && t.popup && t.popup.fadeOutAndRemove(), null
                            },
                            y = function(e) {
                                return {
                                    my: e.data("error-my") || "left top",
                                    at: e.data("error-at") || "right center"
                                }
                            },
                            x = function(e) {
                                null != e && (e.popup || (e.popup = h(e.attachTo, e.message, {
                                    position: y(e.attachTo),
                                    css: {
                                        width: "120px;",
                                        color: "#fff"
                                    },
                                    closeOthers: !1,
                                    dismissable: !1
                                })), e.changed && (r.push(e.popup), e.popup = h(e.attachTo, e.message, {
                                    position: y(e.attachTo),
                                    css: {
                                        width: "120px;",
                                        color: "#fff"
                                    },
                                    closeOthers: !1,
                                    dismissable: !1
                                })))
                            },
                            S = function() {
                                for (var e = 0; e < r.length; e++) r[e] && r[e].fadeOutAndRemove();
                                r = []
                            },
                            E = function() {
                                x(c), x(l), x(d), x(u), setTimeout(S, 200)
                            },
                            C = function(e, t) {
                                for (var n = "all" === t, i = 0; i < e.length && (e[i].id != t && !n || (e[i].popup && r.push(e[i].popup), e.splice(i, 1), n)); i++);
                            };
                        this.removeAllErrors = function() {
                            C(e, "all"), C(t, "all"), C(n, "all"), C(o, "all"), StackExchange.helpers.removeMessages()
                        };
                        var T = StackExchange.Auth.addOrUpdateError,
                            O = function(e) {
                                var n = $("input[name = 'inline-password']");
                                0 !== $password.length && 0 !== $password.val().trim().length || e ? C(t, "pw-empty") : T(t, {
                                    id: "pw-empty",
                                    index: 0,
                                    attachTo: n,
                                    message: __tr(["Password cannot be empty."], undefined, "en", [])
                                }), StackExchange.Auth.passwordStrengthValidation(n, t, C)
                            },
                            j = function() {
                                var i;
                                return O(),
                                    function() {
                                        var e = $("input[name='inline-email']").val() ? .trim().toUpperCase(),
                                            t = $("input[name='inline-display-name']"),
                                            i = t.val() ? .trim().toUpperCase();
                                        e && e === i ? T(n, {
                                            id: "nm",
                                            index: 0,
                                            attachTo: t,
                                            message: __tr(["Name and email address must be different. If you don't want to enter a name, just leave it blank."], undefined, "en", []),
                                            faileType: "name_email_same"
                                        }) : C(n, "nm")
                                    }(), $("#no-captcha-here iframe").length > 0 && (grecaptcha.getResponse().length > 0 ? C(o, "cp") : T(o, {
                                        id: "cp",
                                        index: 0,
                                        attachTo: $("#no-captcha-here"),
                                        message: __tr(["CAPTCHA response required."], undefined, "en", [])
                                    })), 0 === (i = $("input[name='inline-email']")).length || 0 === i.val().trim().length ? T(e, {
                                        id: "em-empty",
                                        index: 0,
                                        attachTo: i,
                                        message: __tr(["Email cannot be empty."], undefined, "en", [])
                                    }) : C(e, "em-empty"), c = k(e, c), l = k(t, l), u = k(n, u), d = k(o, d), null == c && null == l && null == u && null == d
                            },
                            A = !0;
                        $("#login-form input[name='submit-button']").on("click", (function(t) {
                            var n = {
                                isSignup: !0
                            };
                            $("#login-form input").each((function(e, t) {
                                var i = $(t).attr("name");
                                i && (i = i.replace(/(\W|_)/gi, ""), n[i] = $(t).val())
                            })), $.ajax({
                                url: "/users/login-or-signup/validation/track",
                                data: n,
                                type: "POST",
                                complete: function() {
                                    var t = j();
                                    A && ($("#login-form input").on("blur", (function() {
                                        j();
                                        var t = $("#login-form input[name='inline-email']"),
                                            n = t.val() ? .trim();
                                        C(e, "em-ajax"), $.ajax({
                                            type: "POST",
                                            url: "/users/signup/email/validate",
                                            data: {
                                                email: n,
                                                fkey: StackExchange.options.user.fkey
                                            },
                                            success: function(n) {
                                                n.IsValid ? c = null : (T(e, {
                                                    id: "em-ajax",
                                                    index: 1,
                                                    attachTo: t,
                                                    message: n.ErrorMessage
                                                }), c = k(e, c))
                                            },
                                            complete: function() {
                                                E()
                                            }
                                        })
                                    })), A = !1), t ? $("#login-form").trigger("submit") : E()
                                }
                            })
                        }))
                    },
                    removeAllErrors: function() {},
                    signin: function(e, t, n) {
                        var i, o, r = e.data ? (o = {
                            name: (i = e).data("provider")
                        }, i.data("oauthserver") && (o.oauth_server = i.data("oauthserver")), i.data("oauthversion") && (o.oauth_version = i.attr("data-oauthversion")), o) : e;
                        r && (function(e, t) {
                            var n = "signup_inline";
                            t || (StackExchange.using("gps", (function() {
                                StackExchange.gps.track("signup.start", {
                                    openid_provider: e,
                                    location: s.getSsrc(n),
                                    tid: StackExchange.options.user.tid
                                }, !0)
                            })), StackExchange.settings.signup.enableSignupProductEvents && (0, a.H)("signup.start", {
                                source: window.location.href,
                                openIdProvider: e,
                                location: s.getSsrc(n),
                                trackingId: StackExchange.options.user.tid
                            })), e && (StackExchange.using("gps", (function() {
                                StackExchange.gps.track("signup.openid.click", {
                                    openid_provider: e,
                                    location: n
                                }, !0)
                            })), StackExchange.using("gps", (function() {
                                StackExchange.gps.track("openid.click", {
                                    openid_provider: e,
                                    location: n
                                }, !0)
                            })))
                        }(r.name.replace(/_/g, " "), n), "2.0" === r.oauth_version && this.setOAuthInfo(r.oauth_version, r.oauth_server), $("#login-form").trigger("submit"))
                    },
                    setOAuthInfo: function(e, t) {
                        $("#oauth_version").val(e), $("#oauth_server").val(t)
                    }
                }, {
                    init: function() {
                        s.init()
                    }
                })
            },
            61762: (e, t, n) => {
                "use strict";
                n.r(t);
                var i = n(76517);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, Stacks.addController("reactions", {
                    tryToggle: function(e) {
                        "keypress" !== e.type || e.keyCode !== i.O.SPACE && e.keyCode !== i.O.ENTER ? "click" === e.type && (e.currentTarget.blur(), e.preventDefault(), this.toggle(e)) : (e.preventDefault(), this.toggle(e))
                    },
                    toggle: function(e) {
                        var t = $(e.currentTarget),
                            n = t.closest(".js-voting-container"),
                            i = (n.data("post-id"), t.closest(".answer").length);
                        n.is(":working") || (n.working(!0), StackExchange.helpers.removeMessages(), StackExchange.using("gps", (function() {
                            StackExchange.gps.track("react_popup.show", {
                                type: i ? 2 : 1
                            })
                        })), dispatchEvent(new CustomEvent("signupModalShow", {
                            detail: {
                                location: "reactdialog"
                            }
                        })))
                    }
                })
            },
            67708: (e, t, n) => {
                "use strict";
                n.r(t);
                var i = n(20428),
                    s = n.n(i);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function() {
                        function e(e) {
                            return dispatchEvent(new CustomEvent("signupModalShow", {
                                detail: {
                                    location: e
                                }
                            })), !0
                        }
                        s()(".js-signup-button").on("click", (function(t) {
                            e("head") && t.preventDefault()
                        })), s()(".js-home-link").on("click", (function(t) {
                            e("homepage_wizard") && t.preventDefault()
                        })), s()(document).on("click", ".js-embedded-tag-preferences.not-logged-in button", (function() {
                            const e = s()(this),
                                t = e.data("action"),
                                n = e.parent().data("tag-name");
                            let i = null;
                            i = function(e) {
                                    const t = e.closest(".tag-popup").parent().siblings(".post-tag").data("gps-track");
                                    if (!t) return;
                                    const n = StackExchange.gps.parseTrackData(t);
                                    return !n.length || n[0].length < 2 ? void 0 : n[0][1]
                                }(e), !i && e.closest(".tagged-questions-page").length && (i = {
                                    page: 5,
                                    location_on_page: 6,
                                    position_in_list: 1,
                                    total_number_in_list: 1
                                }), StackExchange.gps.track("tagprefs.click", {
                                    action: t,
                                    tagName: n,
                                    isAnon: !0,
                                    ...i
                                }),
                                function(e, t) {
                                    dispatchEvent(new CustomEvent("signupModalShow", {
                                        detail: {
                                            location: "tag_watch_ignore",
                                            tagNames: e,
                                            tagAction: t
                                        }
                                    }))
                                }(n, t)
                        }))
                    }()
            },
            18370: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.anonymous = {}
            },
            20420: (e, t, n) => {
                "use strict";
                var i = n(76517);
                const s = "inquestion",
                    a = `${s}:this`,
                    o = /\/questions\/(\d+)/i;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, window.klass = function(e) {
                    var t = (e = e || this).klass,
                        n = /.*/,
                        i = "prototype";

                    function s(e) {
                        return c.call(a(e) ? e : function() {}, e, 1)
                    }

                    function a(e) {
                        return "function" == typeof e
                    }

                    function o(e, t, n) {
                        return function() {
                            var s = this.supr;
                            this.supr = n[i][e];
                            var a = {}.fabricatedUndefined;
                            try {
                                a = t.apply(this, arguments)
                            } finally {
                                this.supr = s
                            }
                            return a
                        }
                    }

                    function r(e, t, s) {
                        for (var r in t) t.hasOwnProperty(r) && (e[r] = a(t[r]) && a(s[i][r]) && n.test(t[r]) ? o(r, t[r], s) : t[r])
                    }

                    function c(e, t) {
                        function n() {}
                        n[i] = this[i];
                        var s = this,
                            o = new n,
                            l = a(e),
                            u = l ? e : this,
                            d = l ? {} : e;

                        function h() {
                            this.initialize ? this.initialize.apply(this, arguments) : (t || l && s.apply(this, arguments), u.apply(this, arguments))
                        }
                        return h.methods = function(e) {
                            return r(o, e, s), h[i] = o, this
                        }, h.methods.call(h, d).prototype.constructor = h, h.extend = c, h[i].implement = h.statics = function(e, t) {
                            var n;
                            return r(this, e = "string" == typeof e ? ((n = {})[e] = t, n) : e, s), this
                        }, h
                    }
                    return s.noConflict = function() {
                        return e.klass = t, this
                    }, s
                }(window);
                StackExchange.topbar = function() {
                    var e, t = {},
                        n = 0;

                    function r() {
                        if (!e) {
                            e = document.createElement("style");
                            var t = (n = document.querySelector("script[nonce]")) && (n.nonce || n.getAttribute("nonce"));
                            t && e.setAttribute("nonce", t), document.head.appendChild(e)
                        }
                        var n;
                        return e
                    }

                    function c(e, i) {
                        e.data("topbar-dynamic-style-class") || (e.data("topbar-dynamic-style-class", "topbar-dynamic-style-" + ++n), e.addClass(e.data("topbar-dynamic-style-class")));
                        var s, a = e.data("topbar-dynamic-style-class"),
                            o = {
                                maxWidth: "max-width",
                                minHeight: "min-height"
                            },
                            c = [];
                        for (var l in i) Object.prototype.hasOwnProperty.call(i, l) && c.push((o[l] || l) + ":" + (("number" == typeof(s = i[l]) ? s + "px" : s) + ";"));
                        t[a] = "." + a + "{" + c.join("") + "}", r().textContent = Object.keys(t).map((function(e) {
                            return t[e]
                        })).join("\n")
                    }
                    var l = klass({
                            name: "",
                            url: "",
                            cssClass: "",
                            button: null,
                            $dialog: null,
                            $loadingPlaceholder: null,
                            $preloadedDialog: null,
                            $parent: null,
                            alignment: null,
                            hasRead: !1
                        }).methods({
                            isLoading: function() {
                                return null != this.$loadingPlaceholder
                            },
                            isLoaded: function() {
                                return null != this.$dialog
                            },
                            isVisible: function() {
                                var e = this.$dialog || this.$loadingPlaceholder;
                                return null != e && e.is(":visible")
                            },
                            toggle: function(e, t) {
                                if ("boolean" != typeof e) throw new Error("showOrHide is a required parameter");
                                if (!e) {
                                    if (this.isLoading()) return void this.showOrHide(!1);
                                    if (!this.isLoaded()) return
                                }
                                if (this.isLoaded() || this.isLoading() ? (this.showOrHide(e), e || t || !this.hasRead || this.markAsRead()) : this.$preloadedDialog ? this.loadChildContent() : this.loadDialog(), e) {
                                    for (var n = 0; n < L.length; n++) this.button != L[n] && L[n].toggle(!1, t);
                                    $(".js-top-search-popover").removeClass("is-visible")
                                }
                            },
                            showOrHide: function(e) {
                                var t = this.$dialog || this.$loadingPlaceholder || $(),
                                    n = this.button.$button;
                                if (e) {
                                    var i = n.closest("li");
                                    this.$parent || i.length > 0 && (this.$parent = $("<li />").insertAfter(i)), this.$parent ? this.$parent.append(t) : t.insertAfter(this.button.$button), this._bound_pdub || (this._bound_pdub = this.positionDialogUnderButton.bind(this)), this.positionDialogUnderButton(), StackExchange.responsive && StackExchange.responsive.addBreakpointListener(this._bound_pdub)
                                } else StackExchange.responsive && this._bound_pdub && StackExchange.responsive.removeBreakpointListener(this._bound_pdub);
                                t.toggleClass("d-none dno", !e), e && this.isLoaded() && (this.hasRead = !0)
                            },
                            loadChildContent: function() {
                                var e = this.$preloadedDialog.find(".child-content");
                                if (this.$dialog = this.$preloadedDialog, this.showOrHide(!0), this.url) {
                                    $("<div>", {
                                        class: "child-content-loading"
                                    }).addSpinner().appendTo(e);
                                    var t = this;
                                    this.fetchUrl().done((function(n) {
                                        e.html(n), t.afterLoad()
                                    }))
                                }
                            },
                            loadDialog: function() {
                                if (!this.isLoading()) {
                                    this.$loadingPlaceholder = this.getLoadingPlaceholder(), this.showOrHide(!0);
                                    var e = this;
                                    this.fetchUrl().done((function(t) {
                                        e.$dialog = $(t), e.afterLoad();
                                        var n = e.$loadingPlaceholder.is(":visible");
                                        e.showOrHide(n)
                                    })).always((function() {
                                        e.$loadingPlaceholder.remove(), e.$loadingPlaceholder = null
                                    }))
                                }
                            },
                            afterLoad: function() {
                                this.$dialog.find(".js-close-button").on("click", (function() {
                                    StackExchange.topbar.hideAll()
                                })), StackExchange.gps.bindTrackClicks(this.$dialog)
                            },
                            getLoadingPlaceholder: function() {
                                var e = $("<div/>").append(StackExchange.helpers.getSpinnerImg()).html(),
                                    t = this.cssClass + (StackExchange.options.user.isAnonymousNetworkWide ? " anon" : "");
                                return $(['<div class="topbar-dialog ', t, ' dno">', '<div class="header">', e, "</div>", '<div class="modal-content"/>', "</div>"].join(""))
                            },
                            positionDialogUnderButton: function() {
                                for (var e = this.alignment || "right", t = this.button.$button.outerHeight(), n = (this.$dialog || this.$loadingPlaceholder).parent(); n.not("body").length && "static" === n.css("position");) n = n.parent();
                                n = n.length ? n : $("body");
                                var i, s = this.button.$button.offset().left - n.offset().left;
                                "right" === e && (s = n.outerWidth() - s - this.button.$button.outerWidth(), i = n.offset().left + n.outerWidth() - s);
                                var a = {
                                    top: t
                                };
                                StackExchange.responsive && "sm" === StackExchange.responsive.currentRange() || (a[e] = s, i && (a.maxWidth = i)), c(this.$dialog || this.$loadingPlaceholder, a)
                            },
                            fetchUrl: function() {
                                return A("fetching " + this.url), $.ajax({
                                    type: "GET",
                                    url: this.url,
                                    dataType: "html",
                                    error: function() {
                                        StackExchange.helpers.showToast(__tr(["Something went wrong. Please try again."], undefined, "en", []), {
                                            type: "danger"
                                        })
                                    }
                                })
                            },
                            markAsRead: function() {
                                this.button.markAsRead(), this.isLoaded() && this.$dialog.find(".unread-item").removeClass("unread-item")
                            },
                            handleRealtimeMessage: function(e) {
                                this.clearLoadedDialog()
                            },
                            clearLoadedDialog: function() {
                                this.isLoaded() && (this.$dialog.remove(), this.$dialog = null, this.hasRead = !1)
                            },
                            hasFocus: function() {
                                return this.contains(document.activeElement)
                            },
                            contains: function(e) {
                                var t = this.$dialog || this.$loadingPlaceholder;
                                return t && t.length && e && $.contains(t.get(0), e)
                            }
                        }),
                        u = klass({
                            name: "",
                            selector: "",
                            dialog: null,
                            $button: null,
                            onClass: "",
                            unreadCountPrefix: "",
                            queuedUnreadCount: 0,
                            showsOnMouseOver: !1,
                            pendingUnread: {}
                        }).methods({
                            initialize: function() {
                                this.dialog.name = name, this.dialog.button = this, I.push(this.dialog);
                                var e = this;
                                this.$button = $(this.selector), this.$button.on("click", (function() {
                                    return e.toggle(), !1
                                })), this.showsOnMouseOver && this.$button.on("mouseover", (function(t) {
                                    e.showOnMouseOver()
                                })), this.onClass = "is-selected" + (this.onClass ? " " : "") + this.onClass
                            },
                            toggle: function(e, t) {
                                e = "boolean" == typeof e ? e : !this.$button.hasClass(this.onClass), this.$button.toggleClass(this.onClass, e), this.$button.attr("aria-expanded", e), this.dialog.toggle(e, t), !e && this.dialog.hasFocus() && this.$button.trigger("focus")
                            },
                            showOnMouseOver: function() {
                                for (var e = !1, t = 0; t < L.length; t++) {
                                    var n = L[t];
                                    if (n != this && n.showsOnMouseOver && n.isOn()) {
                                        e = !0;
                                        break
                                    }
                                }
                                e && this.toggle(!0, !0)
                            },
                            isOn: function() {
                                return this.$button.hasClass(this.onClass)
                            },
                            markAsRead: function() {
                                this.setUnread($.extend({
                                    count: 0,
                                    litUp: !1
                                }, this.pendingUnread))
                            },
                            setUnread: function(e) {
                                this.isOn() ? $.extend(this.pendingUnread, e) : (this.pendingUnread = {}, this.applyUnreadCount(e.count, e.litUp), (e.count > 0 || e.litUp) && this.dialog.clearLoadedDialog())
                            },
                            applyUnreadCount: function(e, t) {
                                var n = this.$button,
                                    i = n.find(".unread-count, .js-unread-count"),
                                    s = n.data("unread-class");
                                void 0 !== t && s && n.toggleClass(s, t).data("lit-up", t), void 0 !== e && (n.data("unread-count", e), e > 0 ? i.text(this.unreadCountPrefix + e).removeClass("d-none") : i.text(0).addClass("d-none"));
                                var a = this.getButtonLabelAndTitle(n.data("unread-count") || 0, !!n.data("lit-up"));
                                a && (n.attr("aria-label", a.label), n.attr("title", a.title))
                            },
                            handleRealtimeMessage: function(e) {},
                            getButtonLabelAndTitle: function(e, t) {
                                return null
                            }
                        }),
                        d = l.extend({
                            url: "/topbar/site-switcher/site-list",
                            cssClass: "siteSwitcher-dialog",
                            $searchItems: null,
                            $pinnedSiteSearchItems: null,
                            isPreloaded: !0,
                            $preloadedDialog: $(".siteSwitcher-dialog")
                        }).methods({
                            afterLoad: function() {
                                this.$dialog.find(".js-site-filter-txt").typeWatch({
                                    highlight: !1,
                                    wait: 250,
                                    captureLength: -1,
                                    callback: this.filterSites.bind(this)
                                }), this.$searchItems = this.$dialog.find(".js-other-sites li").clone().map((function() {
                                    return {
                                        title: $(".site-icon", this).attr("title").toLowerCase(),
                                        description: $(".site-desc", this).text().toLowerCase(),
                                        hostname: $("a", this).first().attr("href"),
                                        li: this
                                    }
                                }));
                                var e = this.$dialog;
                                this.$dialog.find(".js-site-filter-txt").on("focus", (function() {
                                    var t = e.offset().top + e.height(),
                                        n = e.find(".other-sites li:nth-child(2)"),
                                        i = n.offset().top + n.height();
                                    i > t && e.animate({
                                        scrollTop: e.scrollTop() + i - t
                                    }, 750)
                                })), StackExchange.options.user.isAnonymous && !StackExchange.options.user.isAnonymousOnThisSite || !$(".pinned-site-editor-container").length || ($(".js-found-sites").addClass("d-none"), this.$dialog.find("#js-site-search-txt").typeWatch({
                                    highlight: !1,
                                    wait: 100,
                                    captureLength: -1,
                                    callback: this.findSitesToPin.bind(this)
                                }), this.$dialog.find("#edit-pinned-sites").on("click", this.editPinnedSites.bind(this)), this.$dialog.find("#cancel-pinned-sites").on("click", {
                                    forceListRefresh: $("#save-pinned-sites-btn").is(":enabled")
                                }, this.cancelSiteListEdits), this.$dialog.find("#pin-site-btn").on("click", this.pinSite.bind(this)), this.$dialog.on("click", ".js-remove-pinned-site-link", (function() {
                                    return $(this).parent().remove(), $("#save-pinned-sites-btn").enable(), $(".js-reset-pinned-sites").removeClass("d-none"), !1
                                })), this.$dialog.find("#save-pinned-sites-btn").on("click", this.savePinnedSites.bind(this)), this.$dialog.find(".js-reset-pinned-sites").on("click", this.resetPinnedSites.bind(this))), this.supr()
                            },
                            showOrHide: function(e) {
                                this.supr(e)
                            },
                            pinSite: function() {
                                $("#pin-site-btn").disable();
                                var e = $("#js-site-search-txt").val(),
                                    t = $.grep(this.$pinnedSiteSearchItems, (function(t, n) {
                                        return t.sitename === e
                                    }));
                                if (t.length) {
                                    var n = t[0];
                                    if ($(".pinned-site-link").map((function(e, t) {
                                            return $(t).data("id")
                                        })).toArray().indexOf(n.siteid) > -1) $("#pin-site-btn").enable();
                                    else {
                                        var i = this;
                                        $.ajax({
                                            type: "GET",
                                            url: "/topbar/site-switcher/pin-site",
                                            data: {
                                                siteId: n.siteid
                                            },
                                            dataType: "html"
                                        }).done((function(e) {
                                            var t = $(e).addClass("d-none");
                                            $(".pinned-site-list").append(t), t.removeClass("d-none"), $("#js-site-search-txt").val(""), $("#save-pinned-sites-btn").enable(), i.toggleSiteListResetLink(!0)
                                        })).fail((function() {
                                            $("#pin-site-btn").parent().showErrorMessage(__tr(["Something bad happened; please try again"], undefined, "en", [])), $("#pin-site-btn").enable()
                                        }))
                                    }
                                } else $("#pin-site-btn").enable()
                            },
                            savePinnedSites: function() {
                                var e = $(".pinned-site-list li .pinned-site-link").map((function(e, t) {
                                        return $(t).data("id")
                                    })).toArray(),
                                    t = !$(".js-reset-pinned-sites").is(":visible") || !e.length;
                                this.toggleSiteListResetLink(!t);
                                var n = $(".js-reset-pinned-sites").siblings("input[name=fkey]").val();
                                return $.ajax({
                                    type: "POST",
                                    url: "/topbar/site-switcher/save-pinned-sites",
                                    data: {
                                        siteIds: t ? [] : e,
                                        fkey: n || StackExchange.options.user.fkey
                                    },
                                    dataType: "html",
                                    traditional: !0
                                }).done(function(e) {
                                    $(".my-sites").html(e), this.cancelSiteListEdits(!1), $(".pinned-site-list").data("custom-list", !t), StackExchange.using("gps", (function() {
                                        StackExchange.gps.track("site_switcher.edit", {})
                                    }))
                                }.bind(this)).fail((function() {
                                    $("#save-pinned-sites-btn").parent().showErrorMessage(__tr(["Something bad happened; please try again"], undefined, "en", []))
                                })), !1
                            },
                            resetPinnedSites: function() {
                                var e = this;
                                return $.ajax({
                                    type: "GET",
                                    url: "/topbar/site-switcher/default-active-sites",
                                    dataType: "html"
                                }).done((function(t) {
                                    $(".pinned-site-list").html(t), $("#save-pinned-sites-btn").enable(), e.toggleSiteListResetLink(!1)
                                })).error((function() {
                                    $(".js-reset-pinned-sites").parent().showErrorMessage(__tr(["Something bad happened; please try again"], undefined, "en", []))
                                })), !1
                            },
                            doSearch: function(e, t, n) {
                                var i;
                                t = t.toLowerCase();
                                var s = [];
                                return $.each(e, (function(e, n) {
                                    var i = {
                                            index: e,
                                            li: n.li,
                                            item: n
                                        },
                                        a = n.title.indexOf(t);
                                    n.title == t ? i.priority = 1 : 0 == a ? i.priority = 2 : a > -1 ? i.priority = 3 : n.description.indexOf(t) > -1 ? i.priority = 4 : n.hostname.indexOf(t) > -1 && (i.priority = 5), i.priority && s.push(i)
                                })), i = s.sort((function(e, t) {
                                    return e.priority - t.priority || e.index - t.index
                                })), n && StackExchange.using("gps", (function() {
                                    StackExchange.gps.track("sitesearch.submit", {
                                        term: t,
                                        numresults: s.length
                                    }, !1)
                                })), i
                            },
                            _findSitesToPin: function(e) {
                                var t = $(".js-found-sites"),
                                    n = this.$pinnedSiteSearchItems;
                                if (t.empty(), "" === e) return t.addClass("d-none"), void $("#pin-site-btn").disable();
                                if ((n = this.doSearch(n, e, !1)).length) {
                                    t.removeClass("d-none"), $("#pin-site-btn").enable();
                                    var i = $(".pinned-site-link").map((function(e, t) {
                                        return $(t).data("id")
                                    })).toArray();
                                    $.each(n, (function(e, n) {
                                        var s = $('<li class="pinned-site-candidate">' + n.item.sitename + "</li>");
                                        i.indexOf(n.item.siteid) > -1 ? s.addClass("already-pinned-site") : s.on("click", (function() {
                                            var e = $(this).text();
                                            return $("#js-site-search-txt").val(e), $(".js-found-sites").addClass("d-none"), !1
                                        })), s.appendTo(t)
                                    }))
                                }
                            },
                            findSitesToPin: function(e) {
                                if (this.$pinnedSiteSearchItems) this._findSitesToPin(e);
                                else {
                                    var t = this;
                                    $.ajax({
                                        type: "GET",
                                        url: "/topbar/site-switcher/all-pinnable-sites",
                                        dataType: "json"
                                    }).done((function(n) {
                                        t.$pinnedSiteSearchItems = n, t._findSitesToPin(e)
                                    }))
                                }
                            },
                            filterSites: function(e) {
                                var t = $(".js-other-sites"),
                                    n = this.$searchItems;
                                t.empty(), "" != e && (n = this.doSearch(n, e, !0)), t.append(n.map((function(e) {
                                    return this && this.li || e.li
                                })))
                            },
                            editPinnedSites: function() {
                                $(".siteSwitcher-dialog .header").not("#your-communities-header").addClass("o20"), $(".siteSwitcher-dialog .modal-content").not("#your-communities-section").addClass("o20"), $(".my-sites").addClass("d-none"), $(".pinned-site-editor-container").removeClass("d-none"), $("#edit-pinned-sites").addClass("d-none"), $("#cancel-pinned-sites").removeClass("d-none");
                                var e = $(".pinned-site-list");
                                if ("" === e.html().trim()) {
                                    var t = $("<div/>").append(StackExchange.helpers.getSpinnerImg()).html();
                                    e.append('<li class="ta-center">' + t + "</li>"), $.ajax({
                                        type: "GET",
                                        url: "/topbar/site-switcher/current-pinned-sites",
                                        dataType: "html"
                                    }).done((function(t) {
                                        e.html(t)
                                    })).fail((function() {
                                        e.showErrorMessage(__tr(["Something bad happened; please try again"], undefined, "en", []))
                                    })).always((function() {
                                        e.find(".ajax-loader").remove()
                                    }))
                                }
                                this.toggleSiteListResetLink("true" === e.data("custom-list").toString().toLowerCase());
                                var n = $(".sortable"),
                                    i = this;
                                return n.data("isSortable") || StackExchange.loadJqueryUi().done((function() {
                                    n.sortable({
                                        axis: "y",
                                        update: function() {
                                            $("#save-pinned-sites-btn").enable(), i.toggleSiteListResetLink(!0)
                                        }
                                    }).disableSelection().data("isSortable", !0)
                                })), !1
                            },
                            toggleSiteListResetLink: function(e) {
                                $(".js-reset-pinned-sites").toggleClass("d-none", !e)
                            },
                            cancelSiteListEdits: function(e) {
                                return $(".header").not("#your-communities-header").removeClass("o20"), $(".modal-content").not("#your-communities-section").removeClass("o20"), $(".my-sites").removeClass("d-none"), $("#edit-pinned-sites").removeClass("d-none"), $(".pinned-site-editor-container").addClass("d-none"), $("#cancel-pinned-sites").addClass("d-none"), $("#save-pinned-sites-btn").disable(), e && ($(".pinned-site-list").empty(), $(".js-found-sites").addClass("d-none"), $("#js-site-search-txt").val(""), $("#pin-site-btn").disable()), !1
                            }
                        }),
                        h = u.extend({
                            name: "SiteSwitcher",
                            selector: ".js-site-switcher-button",
                            dialog: new d,
                            showsOnMouseOver: !1,
                            onClass: "icon-site-switcher-on"
                        }),
                        _ = l.extend({
                            cssClass: "feature-notice-dialog",
                            alignment: "left"
                        }).methods({
                            loadDialog: function() {
                                this.$dialog = $(".js-feature-notice-dialog");
                                var e = this.button,
                                    t = e.$button;
                                this.$dialog.find(".js-close-button").on("click", (function() {
                                    return e.mark(4), t.addClass("d-none"), e.toggle(!1), !1
                                })), this.$dialog.find(".js-cta-button").on("click", (function() {
                                    return e.didClickCTA = !0, e.mark(2), !0
                                })), this.showOrHide(!0)
                            }
                        });

                    function p(e, t) {
                        var n = e.data("cookie");
                        if (n) {
                            var i = t($.cookie(n));
                            i && $.cookie(n, i, {
                                expires: new Date(e.data("expire-date")),
                                path: "/"
                            })
                        }
                    }
                    var f = u.extend({
                            name: "FeatureNotice",
                            selector: ".-feature-notice",
                            dialog: new _
                        }).methods({
                            initialize: function() {
                                u.prototype.initialize.apply(this, arguments);
                                var e = this.$button;
                                p(e, (function(e) {
                                    return e ? "!" == e.substring(0, 1) ? "!" + (1 + parseInt(e.substring(1))) : null : "!1"
                                })), e.data("autopopup") && this.toggle(!0, !1, !0)
                            },
                            mark: function(e) {
                                p(this.$button, (function(t) {
                                    if (t) {
                                        var n = t.split(";");
                                        if (2 == n.length && !isNaN(n[0]) && !isNaN(n[1])) return (n[0] | e) + ";" + n[1]
                                    }
                                    return e + ";" + Date.now()
                                }))
                            },
                            markAsRead: function() {
                                this.didClickCTA && u.prototype.markAsRead.apply(this, arguments)
                            },
                            toggle: function(e, t, n) {
                                e = "boolean" == typeof e ? e : !this.$button.hasClass(this.onClass), n = !!n, u.prototype.toggle.apply(this, arguments);
                                var i = this.$button;
                                this.dialog.$dialog;
                                e && (this.mark(1), n || this.mark(8), i.hasClass("js-sample") && StackExchange.using("gps", (function() {
                                    StackExchange.gps.track("new_feature.show", {
                                        campaign: i.data("campaign"),
                                        location: i.data("location"),
                                        auto_popup: n
                                    })
                                })))
                            }
                        }),
                        g = l.extend({
                            url: "/topbar/inbox",
                            cssClass: "inbox-dialog",
                            viewUnreadOnly: !1,
                            ignoreRealtimeMessageDuringUserOperation: !1
                        }).methods({
                            afterLoad: function() {
                                this.supr(), this.hookupMarkAllAsRead(this), this.hookupSwitchBetweenAllAndOnlyRead(this), this.hookupMarkAsReadOnClick(this), this.hookupReadUnreadToggles(this), this.hookupRefreshButton(this), this.enableOrDisableMarkAllAsRead(this)
                            },
                            getStrippedFkey: function() {
                                var e = StackExchange.options.user.fkey,
                                    t = e.lastIndexOf("/");
                                return t >= 0 && (e = e.substr(t + 1)), e
                            },
                            hookupRefreshButton: function(e) {
                                const t = e,
                                    n = e.$dialog.find(".js-refresh-inbox");
                                n.on("click", (function() {
                                    let e = $(".inbox-top-bar-readonly");
                                    e.prepend(StackExchange.helpers.getSpinnerImg().addClass("ta-center")), n.addClass("d-none"), $.ajax({
                                        type: "GET",
                                        url: "/topbar/notifications"
                                    }).done((function(e) {
                                        $(".js-inbox-notifications").html(e), t.hookupMarkAsReadOnClick(t), t.hookupReadUnreadToggles(t), t.enableOrDisableMarkAllAsRead(t)
                                    })).fail((function() {
                                        n.removeClass("d-none"), StackExchange.helpers.showToast(__tr(["An error occurred while reloading notifications. Please try again."], undefined, "en", []), {
                                            type: "danger"
                                        })
                                    })).always((function() {
                                        e.find(".ajax-loader").remove()
                                    }))
                                }))
                            },
                            hookupSwitchBetweenAllAndOnlyRead: function(e) {
                                const t = e,
                                    n = e.$dialog;
                                n.find(".js-view-unread-only").on("click", (function() {
                                    n.find(".inbox-item").not(".unread-item").not(".js-see-all-inbox-items").addClass("d-none"), n.find(".js-inbox-header-unread").removeClass("d-none"), n.find(".js-inbox-header-all").addClass("d-none"), n.find(".js-checkmark-all").addClass("v-hidden"), n.find(".js-checkmark-unread").removeClass("v-hidden"), t.viewUnreadOnly = !0, Stacks.hidePopover($(".js-open-context-menu")[0])
                                })), n.find(".js-view-read-and-unread").on("click", (function() {
                                    n.find(".inbox-item").not(".unread-item").not(".js-see-all-inbox-items").removeClass("d-none"), n.find(".js-inbox-header-unread").addClass("d-none"), n.find(".js-inbox-header-all").removeClass("d-none"), n.find(".js-checkmark-all").removeClass("v-hidden"), n.find(".js-checkmark-unread").addClass("v-hidden"), t.viewUnreadOnly = !1, Stacks.hidePopover($(".js-open-context-menu")[0])
                                }))
                            },
                            hookupMarkAsReadOnClick: function(e) {
                                const t = e,
                                    n = e.$dialog;
                                n.find(".js-readable-inbox-item").on("mousedown", (function(e) {
                                    if (e.which != i.O.LEFT_MOUSE && e.which != i.O.MIDDLE_MOUSE) return;
                                    const n = $(e.currentTarget);
                                    n.hasClass("unread-item") && t.clickSendMarkAsReadBeacon(n, t, 3)
                                })), n.find(".js-readable-inbox-item").on("keyup", (function(e) {
                                    if (e.which != i.O.ENTER) return;
                                    const n = $(e.currentTarget);
                                    n.hasClass("unread-item") && t.clickSendMarkAsReadBeacon(n, t, 3)
                                }))
                            },
                            hookupReadUnreadToggles: function(e) {
                                const t = e,
                                    n = e.$dialog;
                                n.find(".js-toggle-read").on("mousedown", (function(e) {
                                    if (e.which == i.O.LEFT_MOUSE) {
                                        const e = $(this).closest(".js-readable-inbox-item");
                                        t.clickMarkAsRead(e, t, 2)
                                    }
                                    e.stopImmediatePropagation()
                                })), n.find(".js-toggle-unread").on("mousedown", (function(e) {
                                    if (e.which == i.O.LEFT_MOUSE) {
                                        const e = $(this).closest(".js-readable-inbox-item");
                                        t.clickMarkAsUnread(e, t)
                                    }
                                    e.stopImmediatePropagation()
                                })), n.find(".js-toggle-read").on("keyup", (function(e) {
                                    if (e.which == i.O.ENTER) {
                                        const e = $(this).closest(".js-readable-inbox-item");
                                        t.clickMarkAsRead(e, t, 2)
                                    }
                                    e.stopImmediatePropagation()
                                })), n.find(".js-toggle-unread").on("keyup", (function(e) {
                                    if (e.which == i.O.ENTER) {
                                        const e = $(this).closest(".js-readable-inbox-item");
                                        t.clickMarkAsUnread(e, t)
                                    }
                                    e.stopImmediatePropagation()
                                }))
                            },
                            hookupMarkAllAsRead: function(e) {
                                const t = e,
                                    n = e.$dialog;
                                n.find(".js-mark-all-as-read").on("click", (function() {
                                    t.ignoreRealtimeMessageDuringUserOperation = !0, $.ajax({
                                        type: "POST",
                                        url: "/topbar/mark-all-as-read",
                                        data: {
                                            fkey: t.getStrippedFkey()
                                        },
                                        dataType: "json"
                                    }).done((function(i) {
                                        e.button.setUnread({
                                            count: i.UnreadMessagesCount
                                        }), e.isLoaded() && t.markMessageAsRead(n.find(".unread-item")), t.enableOrDisableMarkAllAsRead(t)
                                    })).fail((function() {
                                        StackExchange.helpers.showToast(__tr(["An error occurred while updating notification status. Please try again."], undefined, "en", []), {
                                            type: "danger"
                                        })
                                    })).always((function() {
                                        t.ignoreRealtimeMessageDuringUserOperation = !1
                                    })), Stacks.hidePopover($(".js-open-context-menu")[0])
                                }))
                            },
                            enableOrDisableMarkAllAsRead: function(e) {
                                const t = e.$dialog.find(".js-mark-all-as-read");
                                var n = e.button.$button.find(".js-unread-count").text();
                                t.prop("disabled", 0 == n)
                            },
                            markAsRead: function() {
                                this.button.markAsRead()
                            },
                            markMessageAsUnread: function(e) {
                                e.addClass("unread-item").removeClass("read-item"), e.find(".js-toggle-read").removeClass("d-none"), e.find(".js-toggle-unread").addClass("d-none")
                            },
                            markMessageAsRead: function(e) {
                                e.addClass("read-item").removeClass("unread-item"), e.find(".js-toggle-unread").removeClass("d-none"), e.find(".js-toggle-read").addClass("d-none")
                            },
                            clickSendMarkAsReadBeacon: function(e, t, n) {
                                t.ignoreRealtimeMessageDuringUserOperation = !0;
                                const i = new FormData;
                                i.append("fkey", t.getStrippedFkey()), i.append("inboxId", e.attr("id")), i.append("relatedPostId", e.attr("relatedPostId")), i.append("source", n), navigator.sendBeacon("/topbar/mark-inbox-as-read", i), t.ignoreRealtimeMessageDuringUserOperation = !1
                            },
                            clickMarkAsRead: function(e, t, n) {
                                t.ignoreRealtimeMessageDuringUserOperation = !0;
                                const i = new FormData;
                                i.append("fkey", t.getStrippedFkey()), i.append("inboxId", e.attr("id")), i.append("relatedPostId", e.attr("relatedPostId")), i.append("source", n), fetch("/topbar/mark-inbox-as-read", {
                                    method: "POST",
                                    body: i
                                }).then((e => {
                                    if (!e.ok) throw e;
                                    return e.json()
                                })).then((n => {
                                    t.button.setUnread({
                                        count: n.UnreadMessagesCount
                                    }), t.markMessageAsRead(e), t.viewUnreadOnly && e.addClass("d-none"), t.enableOrDisableMarkAllAsRead(t)
                                })).catch((e => {
                                    0 != e.status && StackExchange.helpers.showToast(__tr(["An error occurred while updating the status of the notification. Please try again."], undefined, "en", []), {
                                        type: "danger"
                                    })
                                })).finally((() => {
                                    t.ignoreRealtimeMessageDuringUserOperation = !1
                                }))
                            },
                            clickMarkAsUnread: function(e, t) {
                                t.ignoreRealtimeMessageDuringUserOperation = !0, $.ajax({
                                    type: "POST",
                                    url: "/topbar/mark-inbox-as-unread",
                                    data: {
                                        inboxId: e.attr("id"),
                                        relatedPostId: e.attr("relatedPostId"),
                                        fkey: t.getStrippedFkey()
                                    },
                                    dataType: "json"
                                }).done((function(n) {
                                    t.button.setUnread({
                                        count: n.UnreadMessagesCount
                                    }), t.markMessageAsUnread(e), t.enableOrDisableMarkAllAsRead(t)
                                })).fail((function() {
                                    StackExchange.helpers.showToast(__tr(["An error occurred while updating the status of the notification. Please try again."], undefined, "en", []), {
                                        type: "danger"
                                    })
                                })).always((function() {
                                    t.ignoreRealtimeMessageDuringUserOperation = !1
                                }))
                            }
                        }),
                        m = u.extend({
                            name: "Inbox",
                            selector: ".js-inbox-button",
                            dialog: new g,
                            showsOnMouseOver: !1
                        }).methods({
                            handleRealtimeMessage: function(e) {
                                if (this.setUnread({
                                        count: e.UnreadInboxCount
                                    }), !this.dialog.ignoreRealtimeMessageDuringUserOperation) {
                                    let t = $(".js-refresh-inbox");
                                    t.html(__tr(["Refresh ($count$)", "Refresh ($count$)"], {
                                        count: e.UnreadInboxCount
                                    }, "en", ["count"])), t.removeClass("d-none")
                                }
                            },
                            getButtonLabelAndTitle: function(e) {
                                var t, n;
                                return e > 0 ? (t = __tr(["Inbox ($__count$ unread message)", "Inbox ($__count$ unread messages)"], {
                                    __count: e
                                }, "en", ["__count"]), n = __tr(["You have unread inbox messages"], undefined, "en", [])) : (t = __tr(["Inbox"], undefined, "en", []), n = __tr(["Recent inbox messages"], undefined, "en", [])), {
                                    label: t,
                                    title: n
                                }
                            },
                            markAsRead: function() {},
                            setUnread: function(e) {
                                this.pendingUnread = {}, this.applyUnreadCount(e.count, e.litUp)
                            }
                        }),
                        v = l.extend({
                            url: (StackExchange.options.site.routePrefix || "") + "/topbar/achievements",
                            cssClass: "achievements-dialog"
                        }).methods({
                            afterLoad: function() {
                                this.alignRep(), this.bindDateGroupToggles(), this.displayUtcTime(), this.bindGpsTracker(), this.supr()
                            },
                            alignRep: function() {
                                var e = this.$dialog.find(".js-items .js-faux-column"),
                                    t = 0;
                                e.filter(".js-rep-change").each((function() {
                                    var e = $(this).text().trim().length;
                                    e > t && (t = e)
                                })), t > 0 && e.width(6 * (t + 1))
                            },
                            bindDateGroupToggles: function() {
                                this.$dialog.find(".js-date-group-toggle").on("click", (function() {
                                    var e = $(this),
                                        t = e.closest(".js-date-group"),
                                        n = t.find(".js-items"),
                                        i = t.find(".rep-site-container");
                                    e.find(".date-group-toggle").toggleClass("toggle-hidden"), n.add(i).fadeToggle("fast")
                                })), this.$dialog.find(".rep-site-container").on("click", (function(e) {
                                    e.stopImmediatePropagation()
                                }))
                            },
                            displayUtcTime: function() {
                                var e = this.$dialog,
                                    t = function() {
                                        var t = new Date;
                                        t.setTime(t.getTime() + 1e3 * StackExchange.options.serverTimeOffsetSec);
                                        var n = t.getUTCHours(),
                                            i = t.getUTCMinutes();
                                        n < 10 && (n = "0" + n), i < 10 && (i = "0" + i), e.find(".js-utc-time").text(n + ":" + i)
                                    };
                                t(), setInterval(t, 6e4)
                            },
                            bindGpsTracker: function() {
                                var e = $("#js-gps-container.js-empty-achiev");
                                e.find("a:first").addClass("js-gps-track").data("gps-track", "achievements_popup.click({ item_type:6 })"), e.find("a:last").addClass("js-gps-track").data("gps-track", "achievements_popup.click({ item_type:7 })"), StackExchange.gps.bindTrackClicks(e)
                            }
                        }),
                        w = u.extend({
                            name: "Achievements",
                            selector: ".js-achievements-button",
                            dialog: new v,
                            unreadCountPrefix: "+",
                            showsOnMouseOver: !1
                        }).methods({
                            handleRealtimeMessage: function(e) {
                                var t = {
                                    count: e.UnreadRepCount
                                };
                                void 0 !== e.UnreadNonRepCount && (t.litUp = e.UnreadNonRepCount > 0), this.setUnread(t)
                            },
                            getButtonLabelAndTitle: function(e, t) {
                                var n, i;
                                return e > 0 ? (n = __tr(["Achievements ($__count$ new reputation)", "Achievements ($__count$ new reputation)"], {
                                    __count: e
                                }, "en", ["__count"]), i = __tr(["You have new reputation changes"], undefined, "en", [])) : t ? (n = __tr(["Achievements (unread)"], undefined, "en", []), i = __tr(["You have new achievements"], undefined, "en", [])) : (n = __tr(["Achievements"], undefined, "en", []), i = __tr(["Recent achievements: reputation, badges, and privileges earned"], undefined, "en", [])), {
                                    label: n,
                                    title: i
                                }
                            }
                        }),
                        b = l.extend({
                            cssClass: "help-dialog"
                        }).methods({
                            loadDialog: function() {
                                this.$dialog = $(".js-help-dialog"), this.showOrHide(!0)
                            }
                        }),
                        k = u.extend({
                            name: "Help",
                            selector: ".js-help-button",
                            dialog: new b
                        }),
                        y = l.extend({
                            cssClass: "network-logo-dialog",
                            alignment: "left"
                        }).methods({
                            loadDialog: function() {
                                this.$dialog = $(".js-network-logo-dialog"), this.showOrHide(!0);
                                var e = this.button;
                                this.$dialog.find(".js-close-button").on("click", (function() {
                                    return e.toggle(!1), !1
                                }))
                            }
                        }),
                        x = u.extend({
                            name: "NetworkLogo",
                            selector: ".js-network-logo",
                            dialog: new y
                        }),
                        S = l.extend({
                            url: "/topbar/review",
                            cssClass: "review-dialog"
                        }),
                        E = u.extend({
                            name: "Review",
                            selector: ".js-review-button",
                            dialog: new S
                        }),
                        C = l.extend({
                            url: "/topbar/mod-inbox",
                            cssClass: "modInbox-dialog"
                        }).methods({}),
                        T = u.extend({
                            name: "ModInbox",
                            selector: ".js-mod-inbox-button",
                            dialog: new C
                        }),
                        O = l.extend({
                            cssClass: "js-leftnav-dialog",
                            alignment: "left"
                        }).methods({
                            loadDialog: function() {
                                this.$dialog = $(".js-leftnav-dialog"), this.showOrHide(!0);
                                var e = this;
                                StackExchange.responsive && StackExchange.responsive.addBreakpointListener((function(t, n) {
                                    $("html").hasClass("html__unpinned-leftnav") || "sm" === n && e.button.toggle(!1)
                                }))
                            }
                        }),
                        j = u.extend({
                            name: "LeftNav",
                            selector: ".js-left-sidebar-toggle",
                            dialog: new O
                        });

                    function A(e) {
                        StackExchange.options.enableLogging && console.log("topbar: " + e)
                    }

                    function R() {
                        for (var e = 0; e < L.length; e++) L[e].toggle(!1)
                    }

                    function P(e, t) {
                        var n = this;
                        this.settings = $.extend({}, {
                            enableHints: !0,
                            enablePrizm: !0,
                            isTopbarAware: !0,
                            onChoice: null,
                            searchUrl: "/search/ac?q=",
                            transformResultsHtml: null
                        }, t), this.resultsCache = {}, this.searchHintsLoaded = !1, this.refreshResultsOnNextShow = !1, e.on("s-popover:show", (function() {
                            n.refreshResultsOnNextShow && (n.suggest.call(n), n.refreshResultsOnNextShow = !1)
                        }));
                        var i = $("#" + e.attr("aria-controls")),
                            s = i.find(".js-ac-results");
                        if (this.$searchPopover = i, this.$searchBox = e, this.$resultsDiv = s, this.$screenReaderInfo = i.find(".js-screen-reader-info"), this.$loadingIndicator = i.find(".js-spinner"), this.$searchHintsContainer = i.find(".js-search-hints"), this.settings.enableHints ? e.on("s-popover:show", this.fetchSearchHints.bind(this)) : this.searchHintsLoaded = !0, e.hasClass("js-search-autocomplete")) {
                            var a = StackExchange.helpers.DelayedReaction(this.suggest.bind(this), 500, {
                                    sliding: !0
                                }),
                                o = /Trident/.test(navigator.userAgent) ? "textinput" : "input";
                            e.on(o, this.onInput.bind(this)), e.on(o, a.trigger), e.on("keydown", this.searchBoxOnKeyDown.bind(this)), i.on("keydown", this.searchPopoverOnKeyDown.bind(this)), s.on("click", ".js-ac-result", this.choose.bind(this)), this.settings.isTopbarAware && $(".js-top-bar").on("focusin", this.hideWhenFocusLost.bind(this))
                        }
                    }

                    function N() {
                        var e = $(".js-search-field");
                        $(".js-search-channel-selector").on("change", (function() {
                                var e = $(this).find("option:selected");
                                if (e && 1 === e.length) {
                                    var t = e.data("url");
                                    t && $("#search").attr("action", t);
                                    var n = e.data("search-on");
                                    n && $(".js-search-on").val(n)
                                }
                            })).trigger("change"), StackExchange.settings.search.enableNewQuickSearch || new P(e),
                            function(e, t = document.location) {
                                var n;
                                null === (n = null == e ? void 0 : e.form) || void 0 === n || n.addEventListener("submit", (() => {
                                    if (e.value.includes(a)) {
                                        let n = (t.pathname.match(o) || [])[1];
                                        n && (e.value = e.value.replace(a, `${s}:${n}`))
                                    }
                                }))
                            }(e[0])
                    }

                    function M() {
                        var e = $(".js-searchbar"),
                            t = $(".js-searchbar-trigger"),
                            n = $(".js-search-field");
                        t.on("click", (function(i) {
                            var s;
                            i.preventDefault(), t.toggleClass("is-selected", s), e.toggleClass("s-topbar--searchbar__open", s), StackExchange.helpers.DelayedReaction((function() {
                                n.trigger("focus")
                            }), 0).trigger()
                        }))
                    }

                    function D() {
                        $.cookie("notice-apa", "1", {
                            path: "/",
                            expires: 180
                        });
                        var e = $(".s-topbar--searchbar--input-group.js-search-pulsing"),
                            t = e.find("input"),
                            n = $(".js-text-pulsing");
                        $.post("/ai-search-alpha-launch-items/dismiss", {
                            fkey: StackExchange.options.user.fkey,
                            itemToDismiss: "PulsingAnimation"
                        }), e.removeClass("js-search-pulsing"), t.removeClass("js-input-border-pulsing"), n.removeClass("js-text-pulsing")
                    }
                    P.prototype = {
                        query: function() {
                            return this.$searchBox.val().trim()
                        },
                        hasQuery: function() {
                            return !!this.query()
                        },
                        fetchSearchHints: function() {
                            var e = this;
                            if (!this.searchHintsLoaded) {
                                var t = new URLSearchParams(window.location.search).get("searchOn"),
                                    n = {};
                                t && (n.searchOn = t), $.ajax({
                                    type: "GET",
                                    url: "/search/hints",
                                    data: n
                                }).done((function(t) {
                                    e.$searchHintsContainer.empty(), e.$searchHintsContainer.append(t), e.searchHintsLoaded = !0
                                })).fail((function(e, t, n) {
                                    StackExchange.debug.log("Autocomplete Error: " + n.toString())
                                }))
                            }
                        },
                        hasResults: function() {
                            return this.$resultsDiv[0].childElementCount > 0
                        },
                        hideResults: function() {
                            this.showResults("")
                        },
                        hidePopover: function() {
                            this.$searchPopover.removeClass("is-visible")
                        },
                        hideWhenFocusLost: function(e) {
                            $(e.target).is(this.$searchBox) || 0 !== $(e.target).parents(".js-top-search-popover").length || this.hidePopover()
                        },
                        onInput: function() {
                            var e = this.hasQuery();
                            this.toggleSpinner(e), e || this.settings.enableHints || this.hidePopover()
                        },
                        showResults: function(e) {
                            var t = 0 === e.trim().length;
                            this.$searchHintsContainer.find(".js-search-hints-text").toggleClass("d-none", !t), this.toggleSpinner(!1);
                            var n = (this.settings.transformResultsHtml || function(e) {
                                return $(e)
                            })(e);
                            this.$resultsDiv.empty().append(n).toggleClass("d-none", t);
                            var i = this.$resultsDiv.find(".js-ac-result").length;
                            this.$screenReaderInfo.text(0 === i ? "No results" : __tr(["$__results$ result found", "$__results$ results found"], {
                                __results: i
                            }, "en", ["__results"]))
                        },
                        toggleSpinner: function(e) {
                            this.$loadingIndicator.toggleClass("d-none", !e)
                        },
                        suggest: function() {
                            var e = this,
                                t = e.query();
                            if (e.hasQuery()) {
                                var n = e.resultsCache[t];
                                if (void 0 !== n) e.showResults(n);
                                else {
                                    var i = new URL(this.settings.searchUrl + encodeURIComponent(t), location.href);
                                    $.get(i.href).done((function(n) {
                                        e.resultsCache[t] = n, e.showResults(n)
                                    })).fail((function(t, n, i) {
                                        StackExchange.debug.log("Autocomplete Error: " + i.toString()), e.toggleSpinner(!1)
                                    }))
                                }
                            } else e.hideResults()
                        },
                        selected: function(e) {
                            if (0 === arguments.length) return this.$resultsDiv.find(".js-ac-result:focus");
                            if (e) {
                                if (!(e = $(e)).hasClass("js-ac-result")) return;
                                e.siblings().trigger("blur"), e.trigger("focus")
                            } else this.$resultsDiv.children().trigger("blur")
                        },
                        selectNext: function() {
                            if (this.hasResults()) {
                                var e = this.selected(),
                                    t = e.next(".js-ac-result");
                                0 !== e.length ? t.length > 0 && (this.selected(t), t[0].scrollIntoView({
                                    behavior: "smooth",
                                    block: "nearest"
                                })) : this.$resultsDiv.children(".js-ac-result").first().trigger("focus")
                            }
                        },
                        selectPrev: function() {
                            if (this.hasResults()) {
                                var e = this.selected().prev(".js-ac-result");
                                e.length > 0 ? (this.selected(e), e[0].scrollIntoView({
                                    behavior: "smooth",
                                    block: "nearest"
                                })) : this.$searchBox.trigger("focus")
                            }
                        },
                        searchBoxOnKeyDown: function(e) {
                            switch (e.key) {
                                case "ArrowDown":
                                    this.hasResults() && this.selectNext(), e.preventDefault();
                                    break;
                                case "Escape":
                                    this.hidePopover()
                            }
                        },
                        searchPopoverOnKeyDown: function(e) {
                            switch (e.key) {
                                case "ArrowDown":
                                    this.hasResults() && this.selectNext(), e.preventDefault();
                                    break;
                                case "ArrowUp":
                                    this.hasResults() && this.selectPrev(), e.preventDefault();
                                    break;
                                case "Escape":
                                    this.hidePopover(), this.$searchBox.trigger("focus")
                            }
                        },
                        choose: function(e) {
                            var t = $(e.target).closest(".js-ac-result"),
                                n = this.$resultsDiv.find(".js-ac-result").index(t);
                            if (t.find(".js-ac-enter-hint").addClass("d-none"), this.settings.enablePrizm && StackExchange.using("gps", (function() {
                                    StackExchange.gps.track("sitesearch.autocomplete.click", {
                                        completion_index: n
                                    })
                                })), this.settings.onChoice) return e.preventDefault(), this.settings.onChoice(t), !1
                        }
                    };
                    var L = [],
                        I = [];
                    return {
                        init: function(e) {
                            e = e || {}, window.devicePixelRatio >= 1.5 && $(".js-avatar-me").attr("src", (function(e, t) {
                                return t.replace("?s=24", "?s=48")
                            })), L.push(new h), L.push(new x), $(".js-left-sidebar-toggle").length && L.push(new j), StackExchange.settings.userMessaging && StackExchange.settings.userMessaging.showNewFeatureNotice && L.push(new f), L.push(new m), L.push(new w), L.push(new k), L.push(new E), StackExchange.options.user.isModerator && L.push(new T), $(document).on("click", (function(e) {
                                (function(e) {
                                    for (var t = 0; t < L.length; t++) {
                                        var n = L[t];
                                        if ((n.$button || $()).get(0) === e) return !0;
                                        if (n.dialog && n.dialog.contains(e)) return !0
                                    }
                                    return !1
                                })(e.target) || R()
                            }));
                            var t, n, i, s = document.body.style;
                            if ("justifyContent" in s || "WebkitJustifyContent" in s || $(".js-top-bar *:visible").addClass("topbar-flexbox-fallback").not(".-logo, .-logo *, svg, .-badges *").addClass("topbar-flexbox-fallback-width"), N(), M(), function() {
                                    var e = !1,
                                        t = (navigator.userAgent || "").match(/\bEdge\/(\d+)/);
                                    if (t && parseInt(t[1], 10) < 17 && (e = !0), e || !window.CSS || !CSS.supports || !CSS.supports("(position: sticky) or (position: -webkit-sticky)")) {
                                        var n = $(".js-sticky-leftnav");
                                        if (n.length) {
                                            e && n.addClass("left-sidebar__fake-sticky");
                                            var i = $(".js-pinned-left-sidebar"),
                                                s = parseInt(i.css("padding-top"), 10),
                                                a = $(window);
                                            a.on("scroll", o), StackExchange.responsive.addBreakpointListener(o), o()
                                        }
                                    }

                                    function o() {
                                        if (i.is(":visible")) {
                                            var e = i.offset().top - a.scrollTop() + StackExchange.scrollPadding.getPaddingTop(),
                                                t = Math.max(StackExchange.scrollPadding.getPaddingTopMinimal(), e) + s,
                                                o = n.height(),
                                                r = t + o - e - i.height();
                                            t -= Math.max(0, r), c(n, {
                                                top: t
                                            }), c(i, {
                                                minHeight: o + s
                                            })
                                        }
                                    }
                                }(), t = $("#js-gdpr-consent-banner"), (n = t.find(".js-notice-close")).on("click", (function() {
                                    n.prop("disabled", !0), $.ajax({
                                        method: "POST",
                                        url: "/accounts/accept-gdpr-consent-banner",
                                        data: {
                                            fkey: StackExchange.options.user.fkey
                                        },
                                        dataType: "json",
                                        success: function(e) {
                                            e && t.remove()
                                        },
                                        complete: function() {
                                            n.prop("disabled", !1)
                                        }
                                    })
                                })), $(".s-topbar--searchbar--input-group.js-search-pulsing input").length > 0 && (i = $(".s-topbar--searchbar--input-group.js-search-pulsing input"), $("<style type='text/css' />").text(".js-alpha-search-label { color: hsl(210, 8%, 75%); }.js-search-pulsing { border-radius: 8px; border: 2px solid transparent; -webkit-animation: pulse 5s infinite; animation: pulse 5s infinite; outline: 0 }@-webkit-keyframes pulse { from { border-color: transparent; } 50% { border-color: hsl(206, 93%, 83.5%); } to { border-color: transparent }}@keyframes pulse { from { border-color: transparent; } 50% { border-color: hsl(206, 93%, 83.5%); } to { border-color: transparent }}.js-input-border-pulsing { animation: blink 5s infinite; outline: 0; -webkit-animation: blink 5s infinite; outline: 0 }@-webkit-keyframes blink { from { border-color: hsl(210, 8%, 75%); } 50% { border-color: hsl(206, 93%, 83.5%); } to { border-color: hsl(210, 8%, 75%); }}@keyframes blink { from { border-color: hsl(210, 8%, 75%); } 50% { border-color: hsl(206, 93%, 83.5%); } to { border-color: hsl(210, 8%, 75%); }}.js-text-pulsing { color: hsl(210, 8%, 75%); animation: color-change 5s infinite; -webkit-animation: color-change 5s infinite; }@-webkit-keyframes color-change { from { color: hsl(210, 8%, 75%); } 50% { color: hsl(210, 77%, 36%); } to { color: hsl(210, 8%, 75%); }}@keyframes color-change { from { color: hsl(210, 8%, 75%); } 50% { color: hsl(210, 77%, 36%); } to { color: hsl(210, 8%, 75%); }}").appendTo("head"), i.on("focus", (function() {
                                    D()
                                })), setTimeout((function() {
                                    D()
                                }), 12e4)), $("#js-ai-search-alpha-popover").length > 0 && initAISearchAlphaPopover(), $("a.js-join-this-community").on("click", (function() {
                                    $(this).addClass("pe-none o50")
                                })), $("#popover-review-queue").length) {
                                var a = $(".js-review-button");
                                a.on("s-popover:hide", (function(e) {
                                    var t = e.originalEvent.detail.dispatcher;
                                    t && 0 === $(t).closest(".js-top-bar").length && e.preventDefault()
                                })), a.attr({
                                    "data-controller": "s-popover",
                                    "aria-controls": "popover-review-queue"
                                }), StackExchange.helpers.toggleStacksPopover(a, !0), $(".js-review-queue-popover-learn-more, .js-review-queue-popover-close-button, .js-review-button").on("click", (function() {
                                    StackExchange.helpers.toggleStacksPopover(a, !1), StackExchange.helpers.toggleUserFlags(StackOverflow.Models.UserFlags.ShowReviewQueueNotice | StackOverflow.Models.UserFlags.ReviewQueueNoticeIsForCampaign, !1), StackExchange.helpers.toggleAccountPreferenceFlags(StackOverflow.Models.AccountPreferenceFlags.DismissReviewQueueNoticeCampaign, !0)
                                }))
                            }
                        },
                        hideAll: R,
                        handleRealtimeMessage: function(e) {
                            var t;
                            if (e && (t = JSON.parse(e)))
                                for (var n in A("realtime message - " + e), t)
                                    for (var i = 0; i < L.length; i++)
                                        if (n == L[i].name) {
                                            L[i].handleRealtimeMessage(t[n]);
                                            break
                                        }
                        },
                        toggleUnpinnedLeftNav: function(e) {
                            var t, n, i = $("html").hasClass("html__unpinned-leftnav");
                            arguments.length || (e = !i), i !== !!e && (e ? ($("html").addClass("html__unpinned-leftnav"), t = "sm md lg", n = "") : ($("html").removeClass("html__unpinned-leftnav"), t = "sm", n = "md lg"), $(".js-pinned-left-sidebar").attr("data-is-here-when", n), $(".js-unpinned-left-sidebar").attr("data-is-here-when", t), StackExchange.responsive.forceCheck())
                        },
                        SearchAutoComplete: P
                    }
                }()
            },
            53185: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.notify = function() {
                    var e = 0;

                    function t(e, t, n) {
                        var i = t * parseInt($("body").css("margin-top").match(/\d+/)) / e;
                        n ? $("body:not(.no-message-slide), body:not(.no-message-slide) .js-top-bar").animate({
                            marginTop: i + "px"
                        }, "fast", "linear") : $("body:not(.no-message-slide), body:not(.no-message-slide) .js-top-bar").css("marginTop", i + "px")
                    }
                    var n = function(n, i) {
                            var s = $("#notify-" + n + (i ? "-" + i : ""));
                            s.length && (n >= 0 && $.post("/messages/mark-as-read", {
                                messagetypeid: n,
                                id: i || null
                            }), function(e, t) {
                                var n = $("#dismissed-messages");
                                n.val(n.val() + "~" + e + (t ? " " + t : "") + "~")
                            }(n, i), e--, s.fadeOut("fast", (function() {
                                t(e + 1, e, !0), s.remove(), 0 === $("#notify-container div").length && $("#notify-container").hide()
                            })))
                        },
                        i = function(t) {
                            if (e++, function(e, t) {
                                    var n = $("#dismissed-messages").val();
                                    return !!n && new RegExp("~" + e + (t ? " " + t : "") + "~").test(n)
                                }(t.messageTypeId, t.id)) return !1;
                            var i = "";
                            t.messageTypeId && (i = ' id="notify-' + t.messageTypeId + (t.id ? "-" + t.id : "") + '"');
                            var s = "<div" + i + ' style="display:none"><span class="notify-close">' + $("<a>&times;</a>").attr("title", __tr(["dismiss this notification"], undefined, "en", [])).outerHTML() + '</span><span class="notify-text">' + t.text + "</span>";
                            if (t.showProfile) {
                                var a = encodeURIComponent("/users/" + t.userId + "?tab=badges&sort=recent");
                                s += " " + __tr(["See your <a href=\"$url$\">profile</a>."], {
                                    url: "/messages/mark-as-read?messagetypeid=" + t.messageTypeId + "&returnurl=" + a
                                }, "en", [])
                            }
                            s += "</div>";
                            var o = $(s);
                            return t.cssClass && o.addClass(t.cssClass), o.find(".notify-close").on("click", (function() {
                                t.close && t.close(), n(t.messageTypeId, t.id)
                            })), $("#notify-container").append(o), $("#notify-container").show(), !0
                        },
                        s = function() {
                            $("#notify-container div").fadeIn("slow")
                        };
                    return {
                        showMessages: function(n) {
                            for (var a = 0, o = e, r = n.length, c = 0; c < r && c < n.length; c++) i(n[c]) && a++;
                            t(o, a, !1), s()
                        },
                        show: function(e, t, n) {
                            $("body:not(.no-message-slide), body:not(.no-message-slide) .js-top-bar").animate({
                                marginTop: "2.5em"
                            }, "fast", "linear"), i({
                                text: e,
                                messageTypeId: t,
                                cssClass: n
                            }), s()
                        },
                        close: n,
                        getMessageText: function(e) {
                            return $("#notify-" + e + " .notify-text").text()
                        }
                    }
                }()
            },
            4224: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, window.moveScroller = function() {
                    var e = $("#scroller").width(),
                        t = function() {
                            var t = "lg" === StackExchange.responsive.currentRange(),
                                n = $(window).scrollTop(),
                                i = $("#scroller-anchor").offset().top,
                                s = $("#scroller"),
                                a = StackExchange.scrollPadding.getPaddingTop() + "px";
                            t && n > i ? s.height() > $(window).height() ? s.css({
                                position: "fixed",
                                top: "",
                                bottom: "0",
                                width: e,
                                "z-index": 3
                            }) : s.css({
                                position: "fixed",
                                top: a,
                                bottom: "",
                                width: e,
                                "z-index": 3
                            }) : s.css({
                                position: "relative",
                                top: "",
                                bottom: "",
                                width: ""
                            })
                        };
                    StackExchange.responsive.addBreakpointListener((function() {
                        var n = $("#scroller"),
                            i = n[0].style.width,
                            s = n[0].style.position;
                        n.css({
                            position: "relative",
                            width: ""
                        }), e = n.width(), n.css({
                            position: s,
                            width: i
                        }), t()
                    })), $(window).on("scroll", t).on("resize", t), t()
                }
            },
            32276: () => {
                function e(e) {
                    if (e.currentTarget.classList.contains("spoiler") && !e.target.classList.contains("is-visible")) return e.preventDefault(), e.currentTarget.classList.add("is-visible"), !1
                }
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, window.styleCode = function() {
                    function e() {
                        if ("undefined" == typeof jtab) {
                            var e = !1;
                            $(".js-post-body pre code, .js-wmd-preview pre code, .js-md-preview pre code, .js-style-code pre code").parent().each((function() {
                                var t = "s-code-block",
                                    n = "prettyprint-override";
                                if ($(this).hasClass(n) && ($(this).removeClass(n).addClass(t), e = !0), !$(this).hasClass(t)) {
                                    var i = $("#js-codeblock-lang").text() || null;
                                    i && ($(this).addClass(i).addClass(t), e = !0)
                                }
                            })), e && StackExchange.using("highlightjs", (function() {
                                $("pre.s-code-block code:not(.hljs)").each((function() {
                                    0 == $(this).parents(".js-editor").length && StackExchange.highlightjs.instance.highlightElement(this)
                                }))
                            }))
                        } else jtab.renderimplicit()
                    }
                    return function() {
                        "undefined" != typeof MathJax && (MathJax.Hub ? MathJax.Hub.Queue(["Typeset", MathJax.Hub]) : MathJax.typeset()), StackExchange.ifUsing("snippets", (function() {
                            StackExchange.snippets.redraw && StackExchange.snippets.redraw()
                        })), e(), styleCode.initializeSpoilers()
                    }
                }(), styleCode.initializeSpoilers = function() {
                    $("body").off("click.spoilers", ".spoiler").off("keyup.spoilers", ".spoiler").on("click.spoilers", ".spoiler", (function(t) {
                        e(t)
                    })).on("keyup.spoilers", ".spoiler", (function(t) {
                        13 !== t.which && 32 !== t.which || e(t)
                    })).on("click.spoilers", ".spoiler a", (function(e) {
                        e.stopPropagation()
                    })).on("keyup.spoilers", ".spoiler a", (function(e) {
                        13 !== e.which && 32 !== e.which || e.stopPropagation()
                    })), $(".spoiler:not([data-spoiler])").attr("data-spoiler", __tr(["Reveal spoiler"], undefined, "en", [])), $(".spoiler").attr("tabindex", "0"), $(".spoiler").attr("aria-label", __tr(["Reveal spoiler"], undefined, "en", []))
                }, styleCode.updateSpoilersOnPreviewRefresh = function() {
                    StackExchange.MarkdownEditor && StackExchange.MarkdownEditor.creationCallbacks.add((function(e) {
                        e.hooks.chain("onPreviewRefresh", (function() {
                            styleCode.initializeSpoilers()
                        }))
                    }))
                }, styleCode.updateLangdivDelayed = StackExchange.helpers.DelayedReaction((function(e) {
                    var t = $("#js-codeblock-lang");
                    t.length && $.get("/api/tags/langdiv", {
                        tags: e.join(" ")
                    }).done((function(e) {
                        e ? t.replaceWith(e) : t.empty(), StackExchange.MarkdownEditor.refreshAllPreviews(), styleCode()
                    }))
                }), 1500, {
                    sliding: !0
                })
            },
            78165: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.tagmenu = function() {
                    var e, t = !1,
                        n = {},
                        i = 0;

                    function s() {
                        if (!e) {
                            e = document.createElement("style");
                            var t = (n = document.querySelector("script[nonce]")) && (n.nonce || n.getAttribute("nonce"));
                            t && e.setAttribute("nonce", t), document.head.appendChild(e)
                        }
                        var n;
                        return e
                    }
                    return {
                        init: function() {
                            if (!t) {
                                t = !0;
                                var e, n = {
                                    selector: ".s-tag.post-tag:not(.user-tag,.no-tag-menu,.invalid-tag,.job-link), .js-hoverable-post-tag",
                                    className: "tag-popup",
                                    getUrl: (e = "/popup", function(t) {
                                        let n = function(e) {
                                                const t = $(e);
                                                if (t.closest(".mixed-site-content, .js-post-body, .js-tag-preferences-container").length) return null;
                                                const n = t.attr("href");
                                                let i = t.data("tag-menu-tagname");
                                                i && (i = i.toString());
                                                if (!(i || n && "/" === n.charAt(0))) return null;
                                                const s = i || t.text();
                                                if (s.indexOf("*") > -1) return null;
                                                return t.attr("title", ""), "/tags/" + encodeURIComponent(s)
                                            }(t),
                                            i = function(e) {
                                                const t = $(e),
                                                    n = t.data("tag-menu-origin");
                                                return n ? "?origin=" + encodeURIComponent(n) : ""
                                            }(t);
                                        return null !== n ? n + e + i : n
                                    }),
                                    showing: a,
                                    shown: o,
                                    fade: !0,
                                    unclipped: !0,
                                    renderInline: !0
                                };
                                StackExchange.helpers.MagicPopup(n)
                            }
                        }
                    };

                    function a(e, t) {
                        var a = $(e),
                            o = $(window),
                            r = t.find(".js-source-arrow"),
                            c = $(".left-sidebar:visible, #chrome-sidebar-root:visible"),
                            l = a.offset(),
                            u = a.outerHeight(),
                            d = a.outerWidth(),
                            h = t.outerWidth(),
                            _ = t.outerHeight(),
                            p = t.parent().offsetParent(),
                            f = p.offset() || {
                                top: 0,
                                left: 0
                            },
                            g = l.top - f.top,
                            m = l.left - f.left + d / 2,
                            v = g + u,
                            w = o.scrollTop(),
                            b = w + o.height() - StackExchange.scrollPadding.getPaddingTop(),
                            k = {
                                left: m - h / 2
                            };
                        l.top + u + _ > b && l.top - (_ + 8) > w ? (k.bottom = p.outerHeight(!0) - g - u / 2, r.addClass("-bottom")) : (k.top = v, r.addClass("-top"));
                        var y = c.length > 0 ? c.offset().left + c.outerWidth() : 0,
                            x = o.width();
                        return k.left + f.left + h > x && (k.left -= k.left + f.left + h - x), k.left + f.left < y && (k.left = y - f.left),
                            function(e, t) {
                                e.data("tag-menu-dynamic-style-class") || (e.data("tag-menu-dynamic-style-class", "tag-menu-dynamic-style-" + ++i), e.addClass(e.data("tag-menu-dynamic-style-class")));
                                var a, o = e.data("tag-menu-dynamic-style-class"),
                                    r = {
                                        marginLeft: "margin-left"
                                    },
                                    c = [],
                                    l = Object.assign({}, e.data("tag-menu-dynamic-styles") || {}, t);
                                for (var u in e.data("tag-menu-dynamic-styles", l), l) Object.prototype.hasOwnProperty.call(l, u) && c.push((r[u] || u) + ":" + ("number" == typeof(a = l[u]) ? a + "px" : a) + ";");
                                n[o] = "." + o + "{" + c.join("") + "}", s().textContent = Object.keys(n).map((function(e) {
                                    return n[e]
                                })).join("\n")
                            }(r, {
                                marginLeft: m - (k.left + h / 2)
                            }), k
                    }

                    function o(e) {
                        var t = $(e).data("gps-track");
                        if (t) {
                            var n = StackExchange.gps.parseTrackData(t);
                            !n.length || n[0].length < 2 || StackExchange.gps.track("tag_popover.show", n[0][1])
                        }
                    }
                }()
            },
            26047: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.usermenu = function() {
                    var e, t, n, i;
                    return {
                        init: function() {
                            e || (e = !0, StackExchange.helpers.MagicPopup({
                                selector: ".user-hover .user-gravatar48, .user-hover .user-gravatar32, .js-user-hover-target",
                                predicate: function(e) {
                                    return !$(e).closest(".mixed-site-content").length
                                },
                                getUrl: function(e) {
                                    var t, n = $(e);
                                    if (n.is(".js-user-hover-target")) t = parseInt(n.data("userId"), 10);
                                    else {
                                        var s = n.closest(".user-hover").find(".user-details a").attr("href"),
                                            a = new RegExp("/users/([^/]+).*$").exec(s);
                                        if (!a) return null;
                                        t = parseInt(a[1])
                                    }
                                    i = !StackExchange.options.user.isAnonymous && t === StackExchange.options.user.userId;
                                    return "/users/user-info/" + t
                                },
                                cache: !0,
                                id: "user-menu",
                                showing: s,
                                removed: a,
                                renderInline: !0
                            }))
                        }
                    };

                    function s(e, s) {
                        let a = $(e),
                            o = a.find("img:last"),
                            r = a.position(),
                            c = o.offset(),
                            l = o.height(),
                            u = o.width(),
                            d = Math.max(u, l),
                            h = 64 * l / d,
                            _ = 64 * u / d,
                            p = s.find("img:first").css({
                                width: _,
                                height: h
                            }),
                            f = s.find(".anonymous-gravatar"),
                            g = p.offset() ? ? f.offset(),
                            m = p.position() ? ? f.position();
                        p.css("visibility", "hidden"), p.attr("aria-hidden", "true");
                        let v = 0;
                        if (p.length) {
                            t = o.clone().css({
                                position: "absolute",
                                zIndex: 1003,
                                left: m.left,
                                top: m.top,
                                width: u,
                                height: l
                            }).appendTo(s.offsetParent());
                            let e = function() {
                                p[0].complete ? (p.css("visibility", "visible"), t ? .fadeOutAndRemove()) : setTimeout(e, 100)
                            };
                            v = Math.max(0, c.left - g.left + s.outerWidth() - $(window).width() + 8), t.animate({
                                width: _,
                                height: h,
                                top: m.top,
                                left: m.left
                            }, 200, e)
                        }
                        n = !0;
                        let w = s.find(".um-header-info a:not(.um-user-link), .um-about-me a, .um-links a").length > 0;
                        return StackExchange.gps.track("user_popup.show", {
                            is_own: i,
                            has_links: w
                        }), setTimeout((function() {
                            n && StackExchange.gps.track("user_popup.read", {
                                is_own: i,
                                has_links: w
                            })
                        }), 2e3), s.on("click", ".um-gravatar a, a.um-user-link", (function() {
                            StackExchange.gps.track("user_popup.click", {
                                clicked_link: 0,
                                is_own: i
                            })
                        })), s.on("click", ".um-header-info a:not(.um-user-link)", (function() {
                            StackExchange.gps.track("user_popup.click", {
                                clicked_link: 1,
                                is_own: i
                            })
                        })), s.on("click", ".um-about-me a", (function() {
                            StackExchange.gps.track("user_popup.click", {
                                clicked_link: 2,
                                is_own: i
                            })
                        })), s.on("click", ".um-links a", (function() {
                            StackExchange.gps.track("user_popup.click", {
                                clicked_link: 3,
                                is_own: i
                            })
                        })), {
                            top: r.top,
                            left: r.left - v,
                            additional: t
                        }
                    }

                    function a(e, i) {
                        t ? .remove(), n = !1
                    }
                }()
            },
            66473: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.chatAd = function() {
                    var e, t, n = 180,
                        i = 480,
                        s = [__tr(["Jan"], undefined, "en", []), __tr(["Feb"], undefined, "en", []), __tr(["Mar"], undefined, "en", []), __tr(["Apr"], undefined, "en", []), __tr(["May"], undefined, "en", []), __tr(["Jun"], undefined, "en", []), __tr(["Jul"], undefined, "en", []), __tr(["Aug"], undefined, "en", []), __tr(["Sep"], undefined, "en", []), __tr(["Oct"], undefined, "en", []), __tr(["Nov"], undefined, "en", []), __tr(["Dec"], undefined, "en", [])];

                    function a(e) {
                        return e < 10 ? "0" + e : e
                    }

                    function o(e) {
                        var t = Math.floor((new Date).getTime() / 1e3) - e,
                            n = t % 60,
                            i = Math.floor(t / 60),
                            o = Math.floor(t / 3600);
                        if (t < 1) return __tr(["just now"], undefined, "en", []);
                        if (t < 60) return __tr(["$seconds$ sec ago", "$seconds$ secs ago"], {
                            seconds: n
                        }, "en", ["seconds"]);
                        if (t < 3600) return __tr(["$minutes$ min ago", "$minutes$ mins ago"], {
                            minutes: i
                        }, "en", ["minutes"]);
                        if (t < 86400) return __tr(["$hours$ hour ago", "$hours$ hours ago"], {
                            hours: o
                        }, "en", ["hours"]);
                        var r = Math.floor(t / 86400);
                        if (1 == r) return __tr(["yesterday"], undefined, "en", []);
                        if (r <= 2) return __tr(["$__count$ day ago", "$__count$ days ago"], {
                            __count: r
                        }, "en", ["__count"]);
                        var c = new Date(1e3 * e);
                        return __tr(["$month$ $date$ at $hours$:$minutes$"], {
                            month: s[c.getMonth()],
                            date: c.getDate(),
                            hours: c.getHours(),
                            minutes: a(c.getMinutes())
                        }, "en", [])
                    }

                    function r() {
                        t && $.get(t, null, h)
                    }

                    function c(e) {
                        if ("!" === e.charAt(0)) {
                            var t = e.substr(1);
                            if (/^https?:\/\/i\.sstatic\.net\//.test(t)) t += (/\?/.test(t) ? "&" : "?") + "g&s=32";
                            return t
                        }
                        return "https://www.gravatar.com/avatar/" + e + "?s=23&d=identicon&r=PG"
                    }

                    function l(t) {
                        for (var n = $('<div class="d-flex gs4 ai-center fw-wrap" />'), i = 0; i < t.length && i < 7; i++) {
                            var s = t[i],
                                a = s.name;
                            s.lastPost && (a += ": " + o(s.lastPost));
                            var r = $('<img class="bar-sm">').attr({
                                    title: a,
                                    src: c(s.emailhash),
                                    width: 23,
                                    height: 23
                                }),
                                l = $('<a class="flex--item">').attr("href", e + "/users/" + s.id).append(r);
                            n.append(l)
                        }
                        return n
                    }

                    function u(t) {
                        var n = t.user,
                            i = t.userid;
                        return i ? $("<a>").attr("href", e + "/users/" + i).text(n) : $("<span>").text(n)
                    }

                    function d() {
                        t && (n <= i && window.setTimeout(r, 1e3 * n), n += 30)
                    }

                    function h(t, n, i) {
                        var s = $(".js-chat-ad-rooms");
                        if (t.error) d();
                        else {
                            s.empty();
                            for (var r, c, h, _ = t.rooms, p = 0; p < _.length && p < 2; p++) {
                                var f = _[p],
                                    g = e + "/rooms/" + f.id,
                                    m = (f.messages || []).length > 0 ? f.messages[0] : null,
                                    v = $('<div class="d-flex fd-column gs2" />');
                                $('<a class="flex--item" />').attr("href", g).text(f.name).appendTo(v), m && $('<div class="flex--item fs-fine fc-black-350 mb4" />').attr("title", (c = f.lastPost, h = void 0, h = new Date, h.setTime(1e3 * c), [h.getUTCFullYear(), "-", a(h.getUTCMonth() + 1), "-", a(h.getUTCDate()), " ", a(h.getUTCHours()), ":", a(h.getUTCMinutes()), ":", a(h.getUTCSeconds()), "Z"].join(""))).html(o(f.lastPost) + " - ").append(u(m)).appendTo(v), f.singleImage ? v.append((r = f.id, $('<div class="flex--item"><img src="' + e + "/rooms/users/" + r + '.jpeg" /></div>'))) : v.append(l(f.users)), s.append($('<div class="s-sidebarwidget--item" />').append(v))
                            }
                            s.toggleClass("d-none", 0 === _.length);
                            var w = $(".js-chat-ad-link");
                            t.activeUsers > 1 ? w.text(__tr(["$num$ person chatting", "$num$ people chatting"], {
                                num: t.activeUsers
                            }, "en", ["num"])) : w.text(__tr(["Visit chat"], undefined, "en", [])), w.attr("title", __tr(["$users$ user active in $rooms$ room the last 60 minutes", "$users$ user active in $rooms$ rooms the last 60 minutes", "$users$ users active in $rooms$ room the last 60 minutes", "$users$ users active in $rooms$ rooms the last 60 minutes"], {
                                users: t.activeUsers,
                                rooms: t.activeRooms
                            }, "en", ["users", "rooms"])), d()
                        }
                    }
                    return {
                        init: function(n) {
                            if (/^\/questions\/\d+/i.test(window.location.pathname) && (i = 0), e = n.chatUrl, t = n.reloadUrl, n.tagBased) {
                                var s = function() {
                                    var e = $(".question .post-taglist .post-tag");
                                    return e.length ? e.map((function(e, t) {
                                        return $(t).text()
                                    })).get().join(" ") : null
                                }();
                                if (!s) return;
                                t && (t += (/\?/.test(t) ? "&" : "?") + "tags=" + encodeURIComponent(s))
                            }
                            null === n.preloadedData ? r() : h(n.preloadedData, null, null)
                        }
                    }
                }()
            },
            33959: () => {
                var e, t;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, $.extend(StackExchange.helpers, (e = {
                    àåáâäãåąɐᵄᶛ: "a",
                    æǣǽᴂᵆ: "ae",
                    çćčĉ: "c",
                    đƍðÐ: "d",
                    èéêëęǝᴈᵌ: "e",
                    ⅎ: "f",
                    ğĝᵷ: "g",
                    ĥɥʮᶣ: "h",
                    ìíîïıᴉᵎ: "i",
                    ĵ: "j",
                    ʞ: "k",
                    ł: "l",
                    ɯɰᵚᶭᴟ: "m",
                    ñń: "n",
                    òóôõöøő: "o",
                    œɶᴔ: "oe",
                    řɹɺɻʴʵ: "r",
                    śşšŝ: "s",
                    ß: "ss",
                    ʇ: "t",
                    Þ: "th",
                    ùúûüŭů: "u",
                    ʌᶺ: "v",
                    ʍ: "w",
                    ýŸÿʎ: "y",
                    żźž: "z"
                }, t = "\\u0030-\\u0039\\u0041-\\u005a\\u005f\\u0061-\\u007a\\u00aa\\u00b5\\u00ba\\u00c0-\\u00d6\\u00d8-\\u00f6\\u00f8-\\u02c1\\u02c6-\\u02d1\\u02e0-\\u02e4\\u02ec\\u02ee\\u0370-\\u0374\\u0376-\\u0377\\u037a-\\u037d\\u0386\\u0388-\\u038a\\u038c\\u038e-\\u03a1\\u03a3-\\u03f5\\u03f7-\\u0481\\u048a-\\u0523\\u0531-\\u0556\\u0559\\u0561-\\u0587\\u05d0-\\u05ea\\u05f0-\\u05f2\\u0621-\\u064a\\u0660-\\u0669\\u066e-\\u066f\\u0671-\\u06d3\\u06d5\\u06e5-\\u06e6\\u06ee-\\u06fc\\u06ff\\u0710\\u0712-\\u072f\\u074d-\\u07a5\\u07b1\\u07c0-\\u07ea\\u07f4-\\u07f5\\u07fa\\u0904-\\u0939\\u093d\\u0950\\u0958-\\u0961\\u0966-\\u096f\\u0971-\\u0972\\u097b-\\u097f\\u0985-\\u098c\\u098f-\\u0990\\u0993-\\u09a8\\u09aa-\\u09b0\\u09b2\\u09b6-\\u09b9\\u09bd\\u09ce\\u09dc-\\u09dd\\u09df-\\u09e1\\u09e6-\\u09f1\\u0a05-\\u0a0a\\u0a0f-\\u0a10\\u0a13-\\u0a28\\u0a2a-\\u0a30\\u0a32-\\u0a33\\u0a35-\\u0a36\\u0a38-\\u0a39\\u0a59-\\u0a5c\\u0a5e\\u0a66-\\u0a6f\\u0a72-\\u0a74\\u0a85-\\u0a8d\\u0a8f-\\u0a91\\u0a93-\\u0aa8\\u0aaa-\\u0ab0\\u0ab2-\\u0ab3\\u0ab5-\\u0ab9\\u0abd\\u0ad0\\u0ae0-\\u0ae1\\u0ae6-\\u0aef\\u0b05-\\u0b0c\\u0b0f-\\u0b10\\u0b13-\\u0b28\\u0b2a-\\u0b30\\u0b32-\\u0b33\\u0b35-\\u0b39\\u0b3d\\u0b5c-\\u0b5d\\u0b5f-\\u0b61\\u0b66-\\u0b6f\\u0b71\\u0b83\\u0b85-\\u0b8a\\u0b8e-\\u0b90\\u0b92-\\u0b95\\u0b99-\\u0b9a\\u0b9c\\u0b9e-\\u0b9f\\u0ba3-\\u0ba4\\u0ba8-\\u0baa\\u0bae-\\u0bb9\\u0bd0\\u0be6-\\u0bef\\u0c05-\\u0c0c\\u0c0e-\\u0c10\\u0c12-\\u0c28\\u0c2a-\\u0c33\\u0c35-\\u0c39\\u0c3d\\u0c58-\\u0c59\\u0c60-\\u0c61\\u0c66-\\u0c6f\\u0c85-\\u0c8c\\u0c8e-\\u0c90\\u0c92-\\u0ca8\\u0caa-\\u0cb3\\u0cb5-\\u0cb9\\u0cbd\\u0cde\\u0ce0-\\u0ce1\\u0ce6-\\u0cef\\u0d05-\\u0d0c\\u0d0e-\\u0d10\\u0d12-\\u0d28\\u0d2a-\\u0d39\\u0d3d\\u0d60-\\u0d61\\u0d66-\\u0d6f\\u0d7a-\\u0d7f\\u0d85-\\u0d96\\u0d9a-\\u0db1\\u0db3-\\u0dbb\\u0dbd\\u0dc0-\\u0dc6\\u0e01-\\u0e30\\u0e32-\\u0e33\\u0e40-\\u0e46\\u0e50-\\u0e59\\u0e81-\\u0e82\\u0e84\\u0e87-\\u0e88\\u0e8a\\u0e8d\\u0e94-\\u0e97\\u0e99-\\u0e9f\\u0ea1-\\u0ea3\\u0ea5\\u0ea7\\u0eaa-\\u0eab\\u0ead-\\u0eb0\\u0eb2-\\u0eb3\\u0ebd\\u0ec0-\\u0ec4\\u0ec6\\u0ed0-\\u0ed9\\u0edc-\\u0edd\\u0f00\\u0f20-\\u0f29\\u0f40-\\u0f47\\u0f49-\\u0f6c\\u0f88-\\u0f8b\\u1000-\\u102a\\u103f-\\u1049\\u1050-\\u1055\\u105a-\\u105d\\u1061\\u1065-\\u1066\\u106e-\\u1070\\u1075-\\u1081\\u108e\\u1090-\\u1099\\u10a0-\\u10c5\\u10d0-\\u10fa\\u10fc\\u1100-\\u1159\\u115f-\\u11a2\\u11a8-\\u11f9\\u1200-\\u1248\\u124a-\\u124d\\u1250-\\u1256\\u1258\\u125a-\\u125d\\u1260-\\u1288\\u128a-\\u128d\\u1290-\\u12b0\\u12b2-\\u12b5\\u12b8-\\u12be\\u12c0\\u12c2-\\u12c5\\u12c8-\\u12d6\\u12d8-\\u1310\\u1312-\\u1315\\u1318-\\u135a\\u1380-\\u138f\\u13a0-\\u13f4\\u1401-\\u166c\\u166f-\\u1676\\u1681-\\u169a\\u16a0-\\u16ea\\u1700-\\u170c\\u170e-\\u1711\\u1720-\\u1731\\u1740-\\u1751\\u1760-\\u176c\\u176e-\\u1770\\u1780-\\u17b3\\u17d7\\u17dc\\u17e0-\\u17e9\\u1810-\\u1819\\u1820-\\u1877\\u1880-\\u18a8\\u18aa\\u1900-\\u191c\\u1946-\\u196d\\u1970-\\u1974\\u1980-\\u19a9\\u19c1-\\u19c7\\u19d0-\\u19d9\\u1a00-\\u1a16\\u1b05-\\u1b33\\u1b45-\\u1b4b\\u1b50-\\u1b59\\u1b83-\\u1ba0\\u1bae-\\u1bb9\\u1c00-\\u1c23\\u1c40-\\u1c49\\u1c4d-\\u1c7d\\u1d00-\\u1dbf\\u1e00-\\u1f15\\u1f18-\\u1f1d\\u1f20-\\u1f45\\u1f48-\\u1f4d\\u1f50-\\u1f57\\u1f59\\u1f5b\\u1f5d\\u1f5f-\\u1f7d\\u1f80-\\u1fb4\\u1fb6-\\u1fbc\\u1fbe\\u1fc2-\\u1fc4\\u1fc6-\\u1fcc\\u1fd0-\\u1fd3\\u1fd6-\\u1fdb\\u1fe0-\\u1fec\\u1ff2-\\u1ff4\\u1ff6-\\u1ffc\\u203f-\\u2040\\u2054\\u2071\\u207f\\u2090-\\u2094\\u2102\\u2107\\u210a-\\u2113\\u2115\\u2119-\\u211d\\u2124\\u2126\\u2128\\u212a-\\u212d\\u212f-\\u2139\\u213c-\\u213f\\u2145-\\u2149\\u214e\\u2183-\\u2184\\u2c00-\\u2c2e\\u2c30-\\u2c5e\\u2c60-\\u2c6f\\u2c71-\\u2c7d\\u2c80-\\u2ce4\\u2d00-\\u2d25\\u2d30-\\u2d65\\u2d6f\\u2d80-\\u2d96\\u2da0-\\u2da6\\u2da8-\\u2dae\\u2db0-\\u2db6\\u2db8-\\u2dbe\\u2dc0-\\u2dc6\\u2dc8-\\u2dce\\u2dd0-\\u2dd6\\u2dd8-\\u2dde\\u2e2f\\u3005-\\u3006\\u3031-\\u3035\\u303b-\\u303c\\u3041-\\u3096\\u309d-\\u309f\\u30a1-\\u30fa\\u30fc-\\u30ff\\u3105-\\u312d\\u3131-\\u318e\\u31a0-\\u31b7\\u31f0-\\u31ff\\u3400-\\u4db5\\u4e00-\\u9fc3\\ua000-\\ua48c\\ua500-\\ua60c\\ua610-\\ua62b\\ua640-\\ua65f\\ua662-\\ua66e\\ua67f-\\ua697\\ua717-\\ua71f\\ua722-\\ua788\\ua78b-\\ua78c\\ua7fb-\\ua801\\ua803-\\ua805\\ua807-\\ua80a\\ua80c-\\ua822\\ua840-\\ua873\\ua882-\\ua8b3\\ua8d0-\\ua8d9\\ua900-\\ua925\\ua930-\\ua946\\uaa00-\\uaa28\\uaa40-\\uaa42\\uaa44-\\uaa4b\\uaa50-\\uaa59\\uac00-\\ud7a3\\uf900-\\ufa2d\\ufa30-\\ufa6a\\ufa70-\\ufad9\\ufb00-\\ufb06\\ufb13-\\ufb17\\ufb1d\\ufb1f-\\ufb28\\ufb2a-\\ufb36\\ufb38-\\ufb3c\\ufb3e\\ufb40-\\ufb41\\ufb43-\\ufb44\\ufb46-\\ufbb1\\ufbd3-\\ufd3d\\ufd50-\\ufd8f\\ufd92-\\ufdc7\\ufdf0-\\ufdfb\\ufe33-\\ufe34\\ufe4d-\\ufe4f\\ufe70-\\ufe74\\ufe76-\\ufefc\\uff10-\\uff19\\uff21-\\uff3a\\uff3f\\uff41-\\uff5a\\uff66-\\uffbe\\uffc2-\\uffc7\\uffca-\\uffcf\\uffd2-\\uffd7\\uffda-\\uffdc", {
                    noDiacritics: function(t) {
                        for (var n in e) e.hasOwnProperty(n) && (t = t.replace(new RegExp("[" + n + "]", "g"), e[n]));
                        return t
                    },
                    tagSeparator: function(e) {
                        if (e = e ? .trim() ? ? "", /^\|.*\|$/.test(e)) return "|";
                        var n = StackExchange.settings.tags.allowNonAsciiTags ? t : "";
                        return !/\s/.test(e) && RegExp("[A-Za-z" + n + "0-9#\\-.*]\\+[A-za-z" + n + "0-9#\\-.]").test(e) ? "+" : /[\s|,;]+/
                    },
                    sanitizeAndSplitTags: function(e, n, i, s) {
                        for (var a = (e ? .trim() ? ? "").split(StackExchange.helpers.tagSeparator(e)), o = [], r = 0; r < a.length; r++) {
                            var c = a[r];
                            s || (c = c.toLowerCase()), StackExchange.settings.tags.allowNonAsciiTags || (c = StackExchange.helpers.noDiacritics(c)), c = c.replace(/_/g, "-");
                            var l = (s ? "[^A-Za-z0-9.#+" : "[^a-z0-9.#+") + (n ? "*" : "") + (StackExchange.settings.tags.allowNonAsciiTags ? t : "") + "-]";
                            c = (c = (c = c.replace(new RegExp(l, "g"), "")).replace(/^[#+-]+/, "")).replace(/[.-]+$/, "");
                            var u = -1 !== ["or", "and", "not"].indexOf(c),
                                d = -1 !== o.indexOf(c);
                            c.length > 0 && (!u && !d || i) && o.push(c)
                        }
                        return o
                    }
                }))
            },
            72745: (e, t, n) => {
                "use strict";
                n.r(t);
                var i = n(41928),
                    s = n(77339),
                    a = (n(76517), n(35148)),
                    o = n(73739);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.question = function() {
                    function e() {
                        $(".js-answer-help").removeClass("d-none").attr("aria-hidden", "false")
                    }

                    function t(e) {
                        e.preventDefault(), $(".js-answer-help").addClass("d-none").attr("aria-hidden", "true")
                    }

                    function n() {
                        $("#qualityBanWarningShown").val("true"), $(".js-answer-ban").removeClass("d-none").attr("aria-hidden", "false")
                    }

                    function r(e) {
                        e.preventDefault(), $(".js-answer-ban").addClass("d-none").attr("aria-hidden", "true")
                    }
                    var c;

                    function l(e) {
                        return $(".question[data-questionid=" + e + "], .answer[data-answerid=" + e + "]")
                    }
                    var u = function(e) {
                            e.addClass("highlighted-post")
                        },
                        d = function() {
                            var e = "click.shareLinks";
                            $(document).off(e).on(e, ".bottom-share-links a", (function(e) {
                                var t = $(this).attr("href"),
                                    n = null;
                                t && t.length && (t.indexOf("%3fsgp%3d") >= 0 ? n = 1 : t.indexOf("%3fsfb%3d") >= 0 ? n = 2 : t.indexOf("%3fstw%3d") >= 0 ? n = 3 : t.indexOf("%3fsem%3d") >= 0 && (n = 4)), n && StackExchange.gps.track("share.click", {
                                    location: 3,
                                    service: n
                                }, !0)
                            }));
                            var t = $(".js-bottom-notice");
                            t && t.length && t.data("loc") && t.off(e).on(e, "a", (function() {
                                var e = 0,
                                    n = t.data("loc"),
                                    i = $(this).attr("href");
                                $(this).hasClass("post-tag") ? e = 1 : /\/ask$/.test(i) ? e = 2 : /\/tags$/.test(i) ? e = 4 : /\/unanswered$/.test(i) ? e = 5 : (/\/questions$/.test(i) || /\/questions[?\/]/.test(i)) && (e = 3), StackExchange.gps.track("next_action.click", {
                                    type: e,
                                    location: n
                                }, !0)
                            }))
                        },
                        h = function() {
                            var e = window.location.hash.replace("#", "").toLowerCase();
                            if (e) {
                                var t = e.split("_"),
                                    n = t[0],
                                    i = t[1],
                                    s = !0;
                                switch (n) {
                                    case "answer":
                                        StackExchange.using("editor", (function() {
                                            var e = $("#wmd-input");
                                            e.is(":visible") ? e.trigger("focus") : window.setTimeout((function() {
                                                $(".js-add-another-answer").trigger("click")
                                            }), 10)
                                        })), window.addEventListener("stacks-editor:created", (e => {
                                            e.detail.editor.focus(), e.detail.editor.dom.scrollIntoView()
                                        }), {
                                            once: !0
                                        });
                                        break;
                                    case "addcomment":
                                        i && $("#comments-link-" + i).find(".js-add-link").trigger("click");
                                        break;
                                    case "notify":
                                        $(".js-inline-mentions-edit-link").trigger("click");
                                        break;
                                    case "edittags":
                                        $("#edit-tags").trigger("click");
                                        break;
                                    default:
                                        s = !1
                                }
                                s && window.history.replaceState(null, null, window.location.href.split("#")[0])
                            }
                        };

                    function _() {
                        var e = function(e, n) {
                                e.attr("aria-pressed", n ? "true" : "false").each((function() {
                                    var e = $(this).data("selected-classes");
                                    e && $(this).toggleClass(e, n)
                                }));
                                var i = t(e) ? e.data("remove-endorsement-title") : e.data("add-endorsement-title");
                                e.each((function() {
                                    Stacks.setTooltipHtml($(this)[0], i, {
                                        placement: "right"
                                    })
                                }))
                            },
                            t = function(e) {
                                return "true" === e.attr("aria-pressed")
                            },
                            n = function(t) {
                                var n = $(".js-endorse-link");
                                e(n, !1), $(".js-endorsements").empty();
                                for (var i = 0; i < t.ExplicitEndorsements.length; i++) {
                                    var s = t.ExplicitEndorsements[i],
                                        a = s.PostId,
                                        o = s.HasEndorsements,
                                        r = $(s.EndorsementContent);
                                    if (a && r) {
                                        var c = $("#answer-" + a).find(".js-endorsements");
                                        if (c.length > 0) c.replaceWith(r);
                                        else $("#answer-" + a).find(".answercell").prepend(r);
                                        var l = r.parents(".answer").find(".js-endorse-link");
                                        e(l, o)
                                    }
                                }
                            },
                            i = $(".js-endorse-link"),
                            s = i.data("single-community-slug");
                        s ? i.on("click", (function() {
                            var e = $(this);
                            if (!e.is(":working")) {
                                e.working(!0);
                                var i = t(e),
                                    a = e.data("action-edit-endorsement-url");
                                $.ajax({
                                    type: "POST",
                                    url: a,
                                    content: "application/json; charset=utf-8",
                                    dataType: "json",
                                    data: {
                                        fkey: StackExchange.options.user.fkey,
                                        EndorseActions: [{
                                            perform: i ? "Remove" : "Add",
                                            slug: s
                                        }]
                                    }
                                }).done((function(e, t, i) {
                                    e.Success ? n(e) : StackExchange.helpers.showToast(e.Message.message, {
                                        type: "danger"
                                    })
                                })).fail((function() {
                                    StackExchange.helpers.showToast(__tr(["Error updating recommendation"], undefined, "en", []), {
                                        type: "danger"
                                    })
                                })).always((function(t, n, i) {
                                    e.working(!1).trigger("update")
                                }))
                            }
                        })) : i.on("click", (function(e) {
                            var t = $(this);
                            if (!t.is(":working")) {
                                t.working(!0);
                                var i = t.data("action-endorse-modal-url");
                                return StackExchange.helpers.loadModal(i).done((function() {
                                    const e = $(".js-stacks-managed-popup");
                                    var i = $(".js-change-recommendation"),
                                        s = $("input.js-community-selection"),
                                        a = $(".js-submit-recommendation");

                                    function o() {
                                        for (var e = 0; e < s.length; e++) {
                                            var t = $(s[e]);
                                            if (!!t.data("original-state") != !!t.is(":checked")) return !0
                                        }
                                        return !1
                                    }
                                    s.on("change", (function() {
                                        a.prop("disabled", !o())
                                    })), i.on("submit", (function a(r, c) {
                                        if (r.preventDefault(), o()) {
                                            var l = [];
                                            if (c && c.length > 0) l = c;
                                            else
                                                for (var u = 0; u < s.length; u++) {
                                                    var d = $(s[u]),
                                                        h = !!d.data("original-state"),
                                                        _ = !!d.is(":checked");
                                                    h !== _ && l.push({
                                                        slug: d.data("slug"),
                                                        perform: _ ? "add" : "remove"
                                                    })
                                                }
                                            var p = i.prop("action");
                                            $.post(p, {
                                                fkey: StackExchange.options.user.fkey,
                                                endorseActions: l
                                            }).done((function(t, i, s) {
                                                if (t.Success) {
                                                    n(t);
                                                    for (var o = 0; o < l.length; o++) {
                                                        var c = "add" === l[o].perform;
                                                        l[o].perform = c ? "remove" : "add"
                                                    }
                                                    StackExchange.helpers.showToast(t.Message.message, {
                                                        type: "success",
                                                        actions: [{
                                                            labelContents: "Undo",
                                                            click: function() {
                                                                a(r, l)
                                                            }
                                                        }]
                                                    }), e.remove()
                                                } else StackExchange.helpers.showToast(t.Message.message, {
                                                    type: "danger"
                                                })
                                            })).fail((function() {
                                                StackExchange.helpers.showToast("Error updating recommendations", {
                                                    type: "danger"
                                                })
                                            })).always((function(e, n, i) {
                                                t.working(!1).trigger("update")
                                            }))
                                        } else StackExchange.helpers.showToast(__tr(["No changes to save"], {
                                            transient: !0
                                        }, "en", []))
                                    })), s.trigger("change"), t.working(!1).trigger("update")
                                })).always((function() {
                                    t.working(!1).trigger("update")
                                })), t.working(!1).trigger("update"), e.preventDefault(), !1
                            }
                        })), $(".js-endorse-link").each((function() {
                            var n = $(this);
                            e(n, t(n))
                        }))
                    }

                    function p(e) {
                        let t = window.location.href;
                        $.ajax({
                            type: "POST",
                            url: t,
                            data: {
                                fkey: StackExchange.options.user.fkey,
                                sortOrderPreference: e
                            }
                        })
                    }

                    function f(e) {
                        const t = new URL(window.location.href);
                        if (t) {
                            t.searchParams.set("answertab", e), t.searchParams.delete("page"), t.searchParams.delete("tab");
                            const n = t.toString().replace(/#.*$/, "");
                            window.location.href = n + "#tab-top"
                        }
                        p(e)
                    }

                    function g(e) {
                        e && ($.cookie("notice-tsl", "1", {
                            path: "/",
                            expires: 30
                        }), StackExchange.options.user.isAnonymous || $.post("/trending-launch-popover/dismiss", {
                            fkey: StackExchange.options.user.fkey
                        }))
                    }
                    return {
                        initTitleSearch: function(e, t, n) {
                            var i, s = document.title,
                                a = n.searchRouteOverride || "/search/titles",
                                o = n.onResults || function() {},
                                r = 0;
                            e.attr("autocomplete", "off");
                            var c = function(c) {
                                    var l = e.val();
                                    if (!("" == l || l == i && !0 !== c || StackExchange.settings.site.newTitleSearchBoxEnabled && $(".title-float-selected:visible").length > 0)) {
                                        for (var u = l.split(" "), d = 0, h = 0; h < u.length; h++) u[h].trim().length > 0 && d++;
                                        var _ = (new Date).getTime();
                                        !0 !== c && (d < 3 || (_ - r) / 1e3 < 5) && !e.hasClass("edit-field-overlayed") || (r = _, i = l, n.siteName && (document.title = l ? l + " - " + n.siteName : s), $(".js-similar-questions-loader").length ? (t.empty(), StackExchange.helpers.addStacksSpinner(t, "lg", "fc-orange-400 ml16 mt12")) : (t.empty(), StackExchange.helpers.addSpinner(t)), $.ajax({
                                            url: a,
                                            dataType: "json",
                                            data: {
                                                title: l
                                            },
                                            success: function(e) {
                                                e && e.content ? (t.html(e.content), setTimeout((function() {
                                                    o(t.find(".answer-link a").attr("target", "_blank"))
                                                }), 1), $(".js-link").attr("target", "_blank"), $(".js-verify-not-duplicate").removeClass("d-none"), $(".js-next-title").prop("disabled", !0), $(".js-similar-questions-outer-div").length && ($(".js-similar-questions-outer-div").removeClass("d-none"), $(".js-question-summary-scroll").one("scroll", (function() {
                                                    StackExchange.using("gps", (function() {
                                                        StackExchange.gps.track("similarquestions.title_scroll")
                                                    }))
                                                })))) : ($(".js-similar-questions-outer-div").toggleClass("d-none", !0), o(null))
                                            },
                                            complete: function(e) {
                                                e.responseJSON.content.length > 0 && StackExchange.helpers.removeSpinner(t), $(".js-next-title").prop("disabled", !1)
                                            }
                                        }))
                                    }
                                },
                                l = !1;
                            return t.mouseenter((function() {
                                    l = !0
                                })).mouseleave((function() {
                                    l = !1
                                })), e.on("keyup", c).on("blur", (function() {
                                    var e = function() {
                                        r = 0, c()
                                    };
                                    l ? t.one("mouseleave", e) : e()
                                })), e.val() && c(),
                                function(e) {
                                    r = 0, c(e)
                                }
                        },
                        getQuestionId: function(e) {
                            var t = (e ? e.closest(".question") : $(".question")).data("questionid");
                            if (!t) throw new Error("getQuestionId could not find an id");
                            return t
                        },
                        initShareLinks: d,
                        canViewVoteCounts: function() {
                            return c
                        },
                        scrollToPost: function(e) {
                            var t = l(e);
                            if (0 === t.length) return !1;
                            var n = t.hasClass("question") ? "#question" : "#" + e;
                            return location.hash !== n ? location.hash = n : t.scrollIntoView(), u(t), !0
                        },
                        scrollToComment: function(e, t) {
                            if (0 === l(t).length) return !1;
                            var n = "#comment" + e + "_" + t;
                            return location.hash !== n ? location.hash = n : StackExchange.comments.highlight(e, t), !0
                        },
                        instrumentVotingForVotePromptExperiment: function() {
                            $(".js-voting-container").each((function(e, t) {
                                var n = $(t),
                                    i = +n.data("post-id"),
                                    s = n.find(".js-vote-up-btn"),
                                    a = n.find(".js-vote-down-btn");
                                s.attr("data-gps-track", "post.prompted_vote({post_id:" + i + ", vote_type: 2})").addClass("js-gps-track"), a.attr("data-gps-track", "post.prompted_vote({post_id:" + i + ", vote_type: 3})").addClass("js-gps-track"), StackExchange.using("gps", (function() {
                                    StackExchange.gps.bindTrackClicks(n)
                                }))
                            }))
                        },
                        init: function(m) {
                            var v, w;
                            StackExchange.settings.questions.enableSavesFeature && (0, s.P)(), c = m.canViewVoteCounts, StackExchange.question.fullInit ? StackExchange.question.fullInit(m) : (StackExchange.question.bindAnonymousVoteDisclaimers(), StackExchange.OutdatedAnswers.initAnon(!0)), StackExchange.comments.init({
                                    autoShowCommentHelp: m.autoShowCommentHelp,
                                    commentHighlightFocus: m.commentHighlightFocus
                                }), d(), m.showAnswerBanWarning && $("#wmd-input").one("focus", n), $(".js-answer-ban-close-btn").on("click", r), m.showAnswerHelp && !m.showAnswerBanWarning && $("#wmd-input").one("focus", e), $(".js-answer-help-close-btn").on("click", t), m.focusPostEditor && ($("#wmd-input").trigger("focus"), $("#post-form")[0].scrollIntoView(!0)), _(), m.showCitation && $(document).on("click", ".js-post-menu .js-cite-link", (function(e) {
                                    e.preventDefault(), (0, i.X)($(this))
                                })), StackExchange.helpers.bindOnHashChange_HighlightDestination((function(e, t) {
                                    StackExchange.comments.highlight(e, t)
                                }), (function(e) {
                                    var t = l(e);
                                    u(t)
                                })),
                                function() {
                                    try {
                                        localStorage.removeItem("nextPrevTrackState"), localStorage.removeItem("nextPrevTrackState2"), localStorage.removeItem("nextPrevState")
                                    } catch (e) {}
                                }(), $(document).on({
                                    mouseenter: function() {
                                        var e = $(this),
                                            t = e.find(".js-new-contributor-label"),
                                            n = e.find(".js-new-contributor-popover");
                                        w && this === v ? w.cancel() : (n.addClass("is-visible").css({
                                            top: e.height() + 4,
                                            left: t.position().left + t.width() / 2 - e.width() / 2,
                                            width: e.width()
                                        }), v = this, w = StackExchange.helpers.DelayedReaction((function() {
                                            n.removeClass("is-visible"), w = null
                                        }), 100))
                                    },
                                    mouseleave: function() {
                                        w && w.trigger()
                                    }
                                }, ".js-new-contributor-indicator"), $(".downvoted-answer").on("click", (function(e) {
                                    $(e.target).parents(".downvoted-answer").find(".s-prose, .comment-body, .post-signature, .vote > *").toggleClass("o100")
                                })), $(document).on("click", ".js-sort-preference-change", (function() {
                                    p($(this).attr("data-value"))
                                })), $(document).on("change", "#answer-sort-dropdown-select-menu", (function(e) {
                                    f(e.target.value)
                                })), (m.showTrendingSortLaunchPopover || m.showTrendingSortPostLaunchPopover) && ($(".js-try-trending-sort").on("click", (function() {
                                    g(m.showTrendingSortLaunchPopover), f("trending")
                                })), $(".js-launch-popover-toggle").on("s-popover:shown", (function() {
                                    $.post("/trending-launch-popover/track", {
                                        fkey: StackExchange.options.user.fkey,
                                        type: m.showTrendingSortLaunchPopover ? "First30Days" : "After30Days"
                                    })
                                })), $(".js-launch-popover-toggle").on("s-popover:hidden", (function() {
                                    g(m.showTrendingSortLaunchPopover)
                                }))), $(".wmd-input").on("focus", (function() {
                                    ! function() {
                                        let e = $(".js-ai-policy-notice");
                                        0 !== e.length && e.toggleClass("d-none", !1).attr("aria-hidden", "false"), $(".js-dismiss-ai-banner").on("click", (function(t) {
                                            t.preventDefault(), (0, a.f)(o.nh.DismissAIPolicyBanner, !0), e.remove()
                                        }))
                                    }()
                                })), window.setTimeout(h, 0)
                        }
                    }
                }(), StackExchange.question.bindAnonymousVoteDisclaimers = function() {
                    function e(e) {
                        var t = $(this),
                            n = t.closest(".js-voting-container"),
                            i = t.hasClass("js-vote-up-btn"),
                            s = t.hasClass("js-vote-down-btn"),
                            a = t.hasClass("js-bookmark-btn"),
                            o = t.hasClass("js-follow-post"),
                            r = t.closest(".answer").length;
                        r && $(".question").data("questionid");
                        if (e.preventDefault(), i || s || o) {
                            if (StackExchange.options.inReadOnly) return void n.showErrorMessage(__tr(["Voting isn't available in read-only mode."], undefined, "en", []), {
                                transient: !0
                            });
                            var c = n.data("post-id");
                            if (o) {
                                var l = t.closest(".question").length > 0;
                                r = !l, c = parseInt(l ? t.closest(".question").data("questionid") : t.closest(".answer").data("answerid"))
                            }
                            var u = o ? 21 : i ? 2 : 3;
                            let e = "";
                            2 === u && (e = t.siblings("#voteUpHash").val()), 3 === u && (e = t.siblings("#voteDownHash").val()), 21 === u && (e = t.siblings("#voteFollowHash").val()), (i || s) && $.ajax({
                                type: "POST",
                                url: "/posts/record-anon-vote-attempt",
                                data: {
                                    fkey: StackExchange.options.user.fkey,
                                    postId: c,
                                    voteTypeId: u
                                },
                                dataType: "json"
                            }), dispatchEvent(new CustomEvent("signupModalShow", {
                                detail: {
                                    vote: u,
                                    voteHash: e,
                                    location: "votedialog"
                                }
                            }))
                        } else if (a) {
                            if (StackExchange.options.inReadOnly) return void n.showErrorMessage(__tr(["Bookmarking is disabled while the site is in read-only mode."], undefined, "en", []), {
                                transient: !0
                            });
                            var d = __tr(["Please $startAnchor$log in or register$endAnchor$ to bookmark this question."], {
                                startAnchor: '<a href="/users/login?ssrc=bookmark_question&returnurl=' + escape(document.location) + '">',
                                endAnchor: "</a>"
                            }, "en", []);
                            StackExchange.using("gps", (function() {
                                StackExchange.gps.track("favorite_popup.show", {})
                            })), StackExchange.helpers.showMessage(t, d, {
                                type: "info",
                                position: {
                                    my: "left top",
                                    at: "right center"
                                },
                                css: {
                                    "margin-left": "-10px"
                                }
                            })
                        }
                    }
                    $(".js-vote-down-btn, .js-vote-up-btn, .js-bookmark-btn:not(.disabled), .js-follow-post:not(.disabled)").each((function() {
                        var t = $(this);
                        t.data("bound-anonymous") || (t.data("bound-anonymous", !0), t.on("click", e))
                    })), StackExchange.question.bindFetchAcceptedAnswerDates()
                }, StackExchange.question.bindFetchAcceptedAnswerDates = function() {
                    $(".js-accepted-answer-indicator").on("mouseenter mouseleave focus", (function() {
                        var e = $(this);
                        if (!e.is(":working")) {
                            e.working(!0);
                            var t = e.closest(".answer").data("answerid");
                            if (t) {
                                var n = "/posts/" + t + "/accepted-answer-date";
                                $.get(n, (function(t) {
                                    e.setTooltipHtml(t)
                                }))
                            } else e.removeAttr("title data-controller")
                        }
                    }))
                }, StackExchange.question.addAnswerIvcObservers = function() {
                    var e = new Set,
                        t = (new Set, new IntersectionObserver((function(t, n) {
                            t.forEach((function(t) {
                                if (t.isIntersecting) {
                                    var i = t.target.closest(".js-answer"),
                                        s = i.dataset.answerid;
                                    e.has(s) || (e.add(s), o = "intersection", r = (a = i).querySelector(".js-post-body").getBoundingClientRect(), c = {
                                        v: "1",
                                        contentHeight: r.height.toFixed(1),
                                        contentY: (r.y + window.scrollY).toFixed(1),
                                        scrollY: window.scrollY.toFixed(1),
                                        pageHeight: document.body.scrollHeight.toFixed(1),
                                        viewportHeight: window.innerHeight.toFixed(1),
                                        viewportWidth: window.innerWidth.toFixed(1),
                                        trigger: o
                                    }, l = a.dataset.ivc + "&" + new URLSearchParams(c).toString(), $.get(l), n.unobserve(t.target))
                                }
                                var a, o, r, c, l
                            }))
                        })));
                    document.querySelectorAll(".js-answer .js-vote-count").forEach((function(e) {
                        t.observe(e)
                    }))
                }
            },
            51e3: (e, t, n) => {
                "use strict";
                n.r(t);
                var i = n(36666);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.comments = StackExchange.comments || i.Ay
            },
            2509: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, window.initTagRenderer = function(e, t, n) {
                    window.tagRenderer || (n = n || {
                        tags: [],
                        id: ""
                    }, window.tagRendererRaw = function(i, s, a, o) {
                        s = s || "", a = a || "a";
                        var r = "",
                            c = o ? "s-tag" : "s-tag post-tag",
                            l = StackExchange.helpers.encodeHexHtmlEntities(i);
                        s || (e && $.inArray(l, e) > -1 ? r = o ? "s-tag__required" : "s-tag__required required-tag" : t && $.inArray(l, t) > -1 && (r = o ? "s-tag__moderator" : "s-tag__moderator moderator-tag"));
                        var u = $("<" + a + ">").addClass(c).addClass(r).addClass($.inArray(i, n.tags) > -1 ? "site" + n.id + " themed channel" + n.id + "-tag" : "").text(i);
                        return "a" === a.toLowerCase() && u.attr({
                            rel: "tag",
                            href: s + "/questions/tagged/" + encodeURIComponent(i),
                            title: __tr(["show questions tagged '$tag$'"], {
                                tag: i
                            }, "en", [])
                        }), u.outerHTML()
                    }, window.tagRenderer = function(e, t, n, i) {
                        return $(tagRendererRaw(e, t, n, i))
                    }, window.tagRenderer.requiredTags = e, window.tagRenderer.moderatorOnlyTags = t, window.tagRenderer.channelOptions = n, window.tagRenderer.markDivergedTag = e => {
                        n.tags.includes(e) || n.tags.push(e)
                    })
                }
            },
            42304: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e, t, n, i) {
                        var s = !("selectionStart" in e("<input type='text' />")[0]);
                        e.fn.caret = function(e, a) {
                            var o, r, c = this[0];
                            if ("object" == typeof e && "number" == typeof e.start && "number" == typeof e.end) o = e.start, r = e.end;
                            else if ("number" == typeof e && "number" == typeof a) o = e, r = a;
                            else if ("string" == typeof e)(o = c.value.indexOf(e)) > -1 ? r = o + e[t] : o = null;
                            else if ("[object RegExp]" === Object.prototype.toString.call(e)) {
                                var l = e.exec(c.value);
                                null != l && (r = (o = l.index) + l[0][t])
                            }
                            if (void 0 !== o) {
                                if (s) {
                                    var u = this[0].createTextRange();
                                    u.collapse(!0), u.moveStart("character", o), u.moveEnd("character", r - o), u.select()
                                } else this[0].selectionStart = o, this[0].selectionEnd = r;
                                return this[0].focus(), this
                            }
                            if (s) {
                                var d = document.selection;
                                if ("textarea" != this[0].tagName.toLowerCase()) {
                                    var h = this.val();
                                    (f = d[n]()[i]()).moveEnd("character", h[t]);
                                    var _ = "" == f.text ? h[t] : h.lastIndexOf(f.text);
                                    (f = d[n]()[i]()).moveStart("character", -h[t]);
                                    var p = f.text[t]
                                } else {
                                    var f, g = (f = d[n]())[i]();
                                    g.moveToElementText(this[0]), g.setEndPoint("EndToEnd", f);
                                    p = (_ = g.text[t] - f.text[t]) + f.text[t]
                                }
                            } else _ = c.selectionStart, p = c.selectionEnd;
                            var m = c.value.substring(_, p);
                            return {
                                start: _,
                                end: p,
                                text: m,
                                replace: function(e) {
                                    return c.value.substring(0, _) + e + c.value.substring(p, c.value[t])
                                }
                            }
                        }
                    }(jQuery, "length", "createRange", "duplicate")
            },
            66590: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.nocaptcha = {
                    init: function(e, t) {
                        var n = ['<div class="popup captcha-popup lightbox-panel" style="display: block; text-align: left;">', '<div class="popup-close">', $("<a>", {
                            title: __tr(["close this popup (or hit Esc)"], undefined, "en", []),
                            text: "×"
                        }).prop("outerHTML"), "</div>", e, "</div>"].join("");
                        $("body").loadPopup({
                            target: $("body"),
                            html: n,
                            lightbox: !0,
                            loaded: function(e) {
                                ! function(e, t) {
                                    var n = e.find("form").first();
                                    StackExchange.helpers.enableSubmitButton(n), n.on("submit", (function() {
                                        return StackExchange.helpers.disableSubmitButton(n), n.find('input[type="submit"]').addSpinnerAfter(), $.ajax({
                                            url: "/nocaptcha",
                                            type: "POST",
                                            dataType: "json",
                                            data: n.serialize(),
                                            success: function(i) {
                                                i.captchaError ? (StackExchange.helpers.removeSpinner(), StackExchange.helpers.enableSubmitButton(n), n.find(".form-error").html(i.captchaError), Recaptcha.reload()) : (e.find(".popup-close a").trigger("click"), t(i))
                                            },
                                            error: function() {
                                                StackExchange.helpers.removeSpinner(), StackExchange.helpers.enableSubmitButton(n), StackExchange.helpers.showErrorMessage(n, __tr(["An error occurred submitting the CAPTCHA"], undefined, "en", []))
                                            }
                                        }), !1
                                    }))
                                }(e, t)
                            }
                        })
                    }
                }
            },
            89621: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.gps = function() {
                    if (StackExchange.gps && StackExchange.gps.inited) return StackExchange.gps;
                    var e = {};

                    function t() {
                        return StackExchange && StackExchange.options && StackExchange.options.site && StackExchange.options.site.routePrefix && StackExchange.options.site.routePrefix.length ? StackExchange.options.site.routePrefix : ""
                    }

                    function n(e, t, n, i) {
                        $(e).find(t).each((function() {
                            var e = $(this).find(n);
                            e.each((function(t) {
                                var n;
                                $(this).addClass("js-gps-track").data("gps-track", "question_tags.click({ " + (n = {
                                    tagName: $(this).text(),
                                    position_in_list: t + 1,
                                    total_number_in_list: e.length,
                                    ...i
                                }, (Object.entries(n).map((([e, t]) => `${e}:${t}`)).join(", ") ? ? "") + " })"))
                            }))
                        }))
                    }

                    function i(e) {
                        u("bindTrackClicks bound {0} elements in {1}", $(e || document).find(".js-gps-track").off("click.gps").one("click.gps", (function() {
                            var e = $(this).data("gps-track") ? .trim();
                            if (e)
                                for (var t = s(e), n = 0; n < t.length; n++) {
                                    var i = t[n];
                                    StackExchange.gps.track(i[0], i[1], !0)
                                }
                        })).length, e || "document")
                    }

                    function s(e) {
                        for (var t = [], n = e.match(/([a-z._-]+)(\([^)]+\))?/gi), i = 0; i < n.length; i++) {
                            var s = n[i];
                            if (s.indexOf("{") < 0) t.push([s, {}]);
                            else {
                                for (var a = s.match(/([a-z._-]+)\s*\(\s*\{([^}]+)\}\s*\)/i) || [], o = a[1], r = (a[2].trim() || "").match(/[^,]+/gi) || [], c = {}, l = 0; l < r.length; l++) {
                                    var u = r[l],
                                        d = u.indexOf(":"),
                                        h = u.substr(0, d).trim(),
                                        _ = p(u.substr(d + 1).trim());
                                    c[h] = _
                                }
                                t.push([o, c])
                            }
                        }
                        return t;

                        function p(e) {
                            if ("true" === e) return !0;
                            if ("false" === e) return !1;
                            if ("'" === e[0] || '"' === e[0]) return e.substring(1, e.length - 1);
                            var t = parseFloat(e);
                            return isNaN(t) ? e : t
                        }
                    }

                    function a(n) {
                        var i = function() {
                            var e = r(),
                                t = localStorage[e];
                            return t ? JSON.parse(t) : []
                        }();
                        if (i.length > 0) {
                            for (var s = (new Date).getTime(), a = [], o = 0; o < i.length && a.length < 20; o++) {
                                var c = i[o],
                                    d = s - c.now;
                                d < 0 || d > 36e5 ? l(c) : a.push(c)
                            }
                            a.length > 0 ? function(n, i) {
                                Array.isArray(n) || (n = [n]);
                                for (var s = 0; s < n.length; s++) {
                                    var a = JSON.stringify(n[s]);
                                    e[a] && (n.splice(s, 1), s--)
                                }
                                for (s = 0; s < n.length; s++) {
                                    a = JSON.stringify(n[s]);
                                    e[a] = !0
                                }
                                var o = JSON.stringify(n);
                                if (navigator && navigator.sendBeacon) try {
                                    u("sending (beacon): " + o);
                                    var r = t() + "/gps/event";
                                    if (navigator && navigator.sendBeacon(r, o)) {
                                        for (s = 0; s < n.length; s++) {
                                            l(n[s]);
                                            a = JSON.stringify(n[s]);
                                            delete e[a]
                                        }
                                        return void(i && i())
                                    }
                                } catch (e) {
                                    u(e)
                                }
                                u("sending (AJAX): " + o), $.ajax({
                                    type: "POST",
                                    url: "/gps/event",
                                    data: {
                                        data: o
                                    },
                                    success: function(e, t, i) {
                                        for (var s = 0; s < n.length; s++) l(n[s])
                                    },
                                    complete: function() {
                                        for (var t = 0; t < n.length; t++) {
                                            var s = JSON.stringify(n[t]);
                                            delete e[s]
                                        }
                                        i && i()
                                    }
                                })
                            }(a, n) : n && n()
                        }
                    }

                    function o(e, t, n, i) {
                        c({
                            evt: e,
                            properties: t || {},
                            now: (new Date).getTime()
                        }), navigator && navigator.sendBeacon && (n = !1), n ? (i && i(), window.setTimeout(a, 1e4)) : a(i)
                    }

                    function r() {
                        return "gps-pending" + t()
                    }

                    function c(e) {
                        var t;
                        (t = e) && StackExchange.options && StackExchange.options.user && (t.properties && !t.properties.user_type && (t.properties.user_type = StackExchange.options.user.user_type), !t.ab && StackExchange.options.user.ab && (t.ab = StackExchange.options.user.ab));
                        var n, i = r(),
                            s = localStorage[i];
                        if (s) {
                            var a = JSON.parse(s);
                            a.push(e), n = JSON.stringify(a)
                        } else n = JSON.stringify([e]);
                        u("addToPending " + JSON.stringify(e)), localStorage[i] = n
                    }

                    function l(e) {
                        var t = r(),
                            n = localStorage[t];
                        if (n) {
                            for (var i = JSON.parse(n), s = JSON.stringify(e), a = -1, o = 0; o < i.length; o++) {
                                if (s == JSON.stringify(i[o])) {
                                    a = o;
                                    break
                                }
                            } - 1 != a && (i.splice(a, 1), 0 != i.length ? localStorage[t] = JSON.stringify(i) : localStorage.removeItem(t))
                        }
                    }

                    function u(e) {
                        if ((StackExchange.options && StackExchange.options.enableLogging || $.cookie("devlog")) && "string" == typeof e) {
                            if (arguments.length > 1) {
                                var t = Array.prototype.slice.call(arguments, 1);
                                e = String.prototype.formatUnicorn.apply(e, t)
                            }
                            console.log("gps: " + e)
                        }
                    }
                    return {
                        inited: !1,
                        init: function(e) {
                            return !!StackExchange.gps.inited || (StackExchange.gps.inited = !0, e && function() {
                                try {
                                    if (!window.localStorage) return !1;
                                    if (window.localStorage["gps-probe"] = "1", "1" != window.localStorage["gps-probe"]) return !1;
                                    window.localStorage.removeItem("gps-probe")
                                } catch (e) {
                                    return !1
                                }
                                return !0
                            }() ? (StackExchange.gps.sendPending = a, StackExchange.gps.track = o, StackExchange._gps_track && ($.each(StackExchange._gps_track, (function(e, t) {
                                c(t)
                            })), delete StackExchange._gps_track), a(), t = ".js-gps-related-tags .post-tag", s = "related_tags.click", r = ", item_type:1", $(".tagged-questions-page, .questions-page, .tags-page").find(t).each((function(e) {
                                $(this).addClass("js-gps-track").data("gps-track", s + "({ position:" + (e + 1) + r + " })")
                            })), n(".home-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 1,
                                location_on_page: 1
                            }), n(".home-page", "#recent-tags-list", ".post-tag", {
                                page: 1,
                                location_on_page: 2
                            }), n(".home-page", "#watched-tags-list", ".s-tag", {
                                page: 1,
                                location_on_page: 9
                            }), n(".questions-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 2,
                                location_on_page: 1
                            }), n(".questions-page", ".js-gps-related-tags", ".post-tag", {
                                page: 2,
                                location_on_page: 2
                            }), n(".question-page", ".post-taglist .js-post-tag-list-wrapper", ".post-tag", {
                                page: 3,
                                location_on_page: 3
                            }), n(".question-page", ".js-bottom-notice .js-post-tag-list-wrapper", ".post-tag", {
                                page: 3,
                                location_on_page: 4
                            }), n(".tags-page", "#tags_list", ".post-tag", {
                                page: 4,
                                location_on_page: 5
                            }), n(".tagged-questions-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 5,
                                location_on_page: 1
                            }), n(".tagged-questions-page", ".js-gps-related-tags", ".post-tag", {
                                page: 5,
                                location_on_page: 2
                            }), n(".tagged-questions-page", ".js-watched-tag-list", ".post-tag", {
                                page: 5,
                                location_on_page: 7
                            }), n(".tagged-questions-page", ".js-ignored-tag-list", ".post-tag", {
                                page: 5,
                                location_on_page: 8
                            }), i(), !0) : (StackExchange.gps.track = function(e, t, n, i) {
                                i && i()
                            }, delete StackExchange._gps_track, !1));
                            var t, s, r
                        },
                        bindTrackClicks: i,
                        track: StackExchange.gps.track,
                        sendPending: StackExchange.gps.sendPending,
                        trackOutboundClicks: function(e, t) {
                            $(e).on("click", t + " a[href]:not(.question-hyperlink, .answer-hyperlink)", (function() {
                                var e = $(this).attr("href");
                                StackExchange.helpers.isInNetwork(e) || ("undefined" == typeof ga ? u("outbound link clicked " + e) : ga("send", "event", "outbound", "click", e, {
                                    useBeacon: !0
                                }))
                            }))
                        },
                        parseTrackData: s
                    }
                }()
            },
            18821: (e, t, n) => {
                "use strict";
                n.r(t);
                var i = n(1977);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.openid = function() {
                    function e(e, t) {
                        return e ? (t && $(e).data("ssrc", t), $(e).data("ssrc")) : "unknown"
                    }

                    function t(t, n) {
                        var s = e(n);
                        t && (StackExchange.gps.track("openid.click", {
                            openid_provider: t,
                            location: s
                        }, !0), StackExchange.gps.track("signup.openid.click", {
                            openid_provider: t,
                            location: s
                        }, !0)), StackExchange.gps.track("signup.start", {
                            openid_provider: t,
                            location: s,
                            tid: StackExchange.options.user.tid
                        }, !0), StackExchange.settings.signup.enableSignupProductEvents && (0, i.H)("signup.start", {
                            source: window.location.href,
                            openIdProvider: t,
                            location: s,
                            trackingId: StackExchange.options.user.tid
                        })
                    }

                    function n(e) {
                        return function() {
                            StackExchange.using("editor", (function() {
                                StackExchange.cardiologist.ensureDraftSaved(e)
                            }))
                        }
                    }
                    return {
                        initPostLogin: function(i, s, a) {
                            var o = decodeURIComponent(s),
                                r = "unknown";
                            a && a.length ? r = a : (0 === o.indexOf("/questions/") && (r = "question_page"), "/questions/ask" === o && (r = "question_ask"));
                            var c = $(i);
                            e(c, r), c.removeClass("dno"), c.find(".google-login").on("click", (function() {
                                t("Google", c),
                                    function(t) {
                                        t.find(".ssrc").val(e(t)), t.find(".use-google").val("true"), t.find(".use-facebook").val(""), t.find(".use-github").val(""), t.find(".js-submit-openid").trigger("click")
                                    }(c)
                            })), c.find(".facebook-login").on("click", (function() {
                                t("Facebook", c),
                                    function(t) {
                                        t.find(".ssrc").val(e(t)), t.find(".use-facebook").val("true"), t.find(".use-google").val(""), t.find(".use-github").val(""), t.find(".js-submit-openid").trigger("click")
                                    }(c)
                            })), c.find(".github-login").on("click", (function() {
                                t("GitHub", c),
                                    function(t) {
                                        t.find(".ssrc").val(e(t)), t.find(".use-google").val(""), t.find(".use-facebook").val(""), t.find(".use-github").val("true"), t.find(".js-submit-openid").trigger("click")
                                    }(c)
                            })), c.find(".stackexchange-login").on("click", n((function() {
                                t("Stack Exchange", c), StackExchange.navPrevention.stop(), window.location = "/users/signup?ssrc=" + encodeURIComponent(r) + "&returnUrl=" + encodeURIComponent(o)
                            }))), c.find(".js-submit-openid").on("click", (function() {
                                ! function(t, i) {
                                    var s = t.find(".use-facebook").val(),
                                        a = t.find(".use-google").val(),
                                        o = t.find(".use-github").val();
                                    n((function() {
                                        var n = (!!StackExchange.options.site.isChildMeta ? StackExchange.options.site.parentUrl : "") + "/users/signup?returnurl=" + encodeURIComponent(i),
                                            r = $('<form method="post" action="' + n + '"></form>'),
                                            c = $('<input type="hidden" name="oauth_version" />'),
                                            l = $('<input type="hidden" name="oauth_server" />');
                                        r.append(c), r.append(l), c.val("2.0"), s ? l.val("https://www.facebook.com/v2.0/dialog/oauth") : a ? l.val("https://accounts.google.com/o/oauth2/auth") : o && l.val("https://github.com/login/oauth/authorize"), r.append("<input type='hidden' name='fkey' value='" + StackExchange.options.user.fkey + "' />"), $('<input type="hidden" name="ssrc" />').val(e(t)).appendTo(r), StackExchange.navPrevention.stop(), r.hide().appendTo("body").trigger("submit")
                                    }))()
                                }(c, o)
                            }))
                        }
                    }
                }()
            },
            64956: () => {
                var e, t, n;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, window.UniversalAuth = (e = 1, t = 1e4, n = !1, {
                    redirectOnCompletion: function(e, i) {
                        if (n) window.location.replace(e);
                        else {
                            var s, a = 0;
                            s = setInterval((function() {
                                if (n) return window.location.replace(e), void clearInterval(s);
                                var o = a < t,
                                    r = a < 5e4,
                                    c = (a += 200) >= 5e4;
                                o && a >= t && i && i(), r && c && clearInterval(s)
                            }), 200)
                        }
                    },
                    performAuth: function() {
                        UniversalAuth.enabled() && ($.cookie("clear-ic") && $((function() {
                            $.cookie("clear-ic", null, {
                                path: "/"
                            })
                        })), null !== $.cookie("uauth") && ($.post("/users/login/universal/request", (function(t, i, s) {
                            var a = [];
                            0 == t.length && (n = !0), $.each(t, (function(t, i) {
                                var s = "//" + i.Host + "/users/login/universal.gif?authToken=" + encodeURIComponent(i.Token) + "&nonce=" + encodeURIComponent(i.Nonce);
                                $((function() {
                                    var t = $("<img/>").attr({
                                        style: "display:none",
                                        src: s,
                                        crossOrigin: "use-credentials"
                                    });
                                    a.push(t), t.one("load", (function() {
                                        var i = t[0].width,
                                            s = t[0].height;
                                        if (2 === i && 2 === s && e > 0 && (e--, !$.cookie("uauth"))) {
                                            var o = new Date,
                                                r = new Date(o.getTime() + 3e5);
                                            $.cookie("uauth", "true", {
                                                path: "/",
                                                domain: document.domain,
                                                expires: r
                                            }), a = null, setTimeout((function() {
                                                UniversalAuth.performAuth()
                                            }), 10)
                                        }! function() {
                                            if (null === $.cookie("uauth") && a) {
                                                for (var e = 0; e < a.length; e++)
                                                    if (!a[e][0].complete) return;
                                                n = !0
                                            }
                                        }()
                                    })), $("#footer").append(t)
                                }))
                            }))
                        }), "json"), $.cookie("uauth", null, {
                            path: "/",
                            domain: document.domain
                        })))
                    },
                    enabled: function() {
                        return !0
                    }
                })
            },
            29304: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.ready((function() {
                    if (StackExchange.options.user.isAnonymous) {
                        var e = /\bfkey=/i;
                        $(document).on("ajaxSend", (function(n, i, s) {
                            "post" === s.type.toLowerCase() && (e.test(s.url) || e.test(s.data)) && t()
                        })), $(document).on("submit", "form", (function(e) {
                            var n = $(this);
                            "post" === (n.attr("method") || "").toLowerCase() && n.find("input[name='fkey']").length && t()
                        }))
                    }

                    function t() {
                        try {
                            $.cookie("fkey", StackExchange.options.user.fkey, {
                                path: "/",
                                expires: 1 / 144
                            })
                        } catch (e) {}
                    }
                }))
            },
            72573: (module, exports, __webpack_require__) => {
                var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.loadJqueryUi = function() {
                    var cssLink = StackExchange.settings.paths.jQueryUICSSPath,
                        jsLink = StackExchange.settings.paths.jQueryUIJSPath;
                    if ($.ui) return $.Deferred().resolve();
                    $("<link>").attr({
                        href: cssLink,
                        rel: "stylesheet",
                        type: "text/css",
                        media: "all"
                    }).appendTo("head");
                    var result = $.Deferred(),
                        locale = StackExchange.options.locale,
                        datepickerLanguageGetter, datepickerLanguageScript;
                    return $.ajaxSetup({
                        cache: !0
                    }), "en" !== locale && (datepickerLanguageGetter = $.ajax({
                        url: "/Content/Js/third-party/jquery-ui/datepicker-" + locale + ".js",
                        dataType: "text",
                        type: "GET"
                    }).done((function(e) {
                        datepickerLanguageScript = e
                    }))), $.when(datepickerLanguageGetter || $.Deferred().resolve(), $.getScript(jsLink)).done((function() {
                        eval(datepickerLanguageScript), result.resolve()
                    })), $.ajaxSetup({
                        cache: !1
                    }), result.promise()
                }, StackExchange.patchJqueryUiForTouch = function() {
                    __WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(20428), __webpack_require__(69139)], void 0 === (__WEBPACK_AMD_DEFINE_RESULT__ = "function" == typeof(__WEBPACK_AMD_DEFINE_FACTORY__ = function(e) {
                        if (e.mspointer = window.navigator.msPointerEnabled, e.touch = "ontouchstart" in document || "ontouchstart" in window || window.TouchEvent || window.DocumentTouch && document instanceof DocumentTouch || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0, !e.touch && !e.mspointer || !e.ui.mouse) return;
                        let t, n, i, s, a = e.ui.mouse.prototype,
                            o = a._mouseInit,
                            r = a._mouseDestroy,
                            c = 0;

                        function l(e) {
                            return {
                                x: e.originalEvent.changedTouches[0].pageX,
                                y: e.originalEvent.changedTouches[0].pageY
                            }
                        }

                        function u(t, n) {
                            if (t.originalEvent.touches.length > 1) return;
                            if (e(t.target).is("input") || e(t.target).is("textarea")) return;
                            t.cancelable && t.preventDefault();
                            let i = t.originalEvent.changedTouches[0],
                                s = new MouseEvent(n, {
                                    bubbles: !0,
                                    cancelable: !0,
                                    view: window,
                                    screenX: i.screenX,
                                    screenY: i.screenY,
                                    clientX: i.clientX,
                                    clientY: i.clientY
                                });
                            t.target.dispatchEvent(s)
                        }
                        a._touchStart = function(e) {
                            let n = this;
                            this._startedMove = e.timeStamp, n._startPos = l(e), !t && n._mouseCapture(e.originalEvent.changedTouches[0]) && (t = !0, n._touchMoved = !1, u(e, "mouseover"), u(e, "mousemove"), u(e, "mousedown"))
                        }, a._touchMove = function(e) {
                            t && (this._touchMoved = !0, u(e, "mousemove"))
                        }, a._touchEnd = function(e) {
                            if (!t) return;
                            u(e, "mouseup"), u(e, "mouseout");
                            let n = e.timeStamp - this._startedMove;
                            if (!this._touchMoved || n < 500) e.timeStamp - c < 400 ? u(e, "dblclick") : u(e, "click"), c = e.timeStamp;
                            else {
                                let t = l(e);
                                Math.abs(t.x - this._startPos.x) < 10 && Math.abs(t.y - this._startPos.y) < 10 && (this._touchMoved && "stylus" !== e.originalEvent.changedTouches[0].touchType || u(e, "click"))
                            }
                            this._touchMoved = !1, t = !1
                        }, a._mouseInit = function() {
                            let t = this;
                            e.support.mspointer && (t.element[0].style.msTouchAction = "none"), n = a._touchStart.bind(t), i = a._touchMove.bind(t), s = a._touchEnd.bind(t), t.element.on({
                                touchstart: n,
                                touchmove: i,
                                touchend: s
                            }), o.call(t)
                        }, a._mouseDestroy = function() {
                            let e = this;
                            e.element.off({
                                touchstart: n,
                                touchmove: i,
                                touchend: s
                            }), r.call(e)
                        }
                    }) ? __WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__) : __WEBPACK_AMD_DEFINE_FACTORY__) || (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)
                }
            },
            19425: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.showFlashMessageIfAny = function() {
                    var e = "flash-message-json",
                        t = $.cookie(e);
                    if (t) try {
                        $.cookie(e, null, {
                            path: "/",
                            domain: document.domain
                        }), StackExchange.options.site.cookieDomain && $.cookie(e, null, {
                            path: "/",
                            domain: StackExchange.options.site.cookieDomain
                        });
                        var n = decodeURIComponent(t.replace(/[+]/g, " ")),
                            i = JSON.parse(n);
                        switch (StackExchange.options.enableLogging && console.log("flash message: showing " + n), i.position) {
                            case "toast":
                                StackExchange.helpers.showToast(i.message, {
                                    type: i.type,
                                    transient: i.transient,
                                    transientTimeout: i.transientTimeout,
                                    useRawHtml: i.useRawHtml
                                });
                                break;
                            case "notice":
                                StackExchange.helpers.showStacksNotice(i.message, i.type);
                                break;
                            default:
                                StackExchange.helpers.showBannerMessage(i.message, i.type)
                        }
                    } catch (e) {}
                }
            },
            84935: () => {
                var e, t;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.prepareEditor = (e = function(e) {
                    setTimeout((function() {
                        var t = e.useStacksEditor ? "stacksEditor" : "editor";
                        e.useStacksEditor || styleCode.initializeSpoilers(), StackExchange[t].initIfShown(e)
                    }), 1)
                }, t = function(e) {
                    var t = !1;
                    $("#wmd-input, #title, #tagnames, #edit-comment, #m-address, #display-name, .js-fake-stacks-editor, .js-stacks-editor-container").one("focus click keydown", (function() {
                        t || (t = !0, e())
                    }))
                }, function(n) {
                    n.onDemand ? n.useStacksEditor ? t((function() {
                        $.when(StackExchange.using("highlightjs", $.noop), StackExchange.using("stacksEditor", $.noop)).then((function() {
                            e(n)
                        }))
                    })) : function(n) {
                        for (var i = n.postfix || "", s = `bold-button italic-button spacer1 link-button quote-button code-button ${n.imageUploadEnabled?"image-button ":""}spacer2 olist-button ulist-button heading-button hr-button spacer3 undo-button redo-button`.split(" "), a = $('<ul id="wmd-button-row' + i + '" class="wmd-button-row" />').appendTo(".wmd-button-bar"), o = 0, r = 0; r < s.length; r++) {
                            var c = s[r],
                                l = /spacer/.test(c),
                                u = $("<li id='wmd-" + c + i + "' />").prop("className", "wmd-" + (l ? "spacer" : "button")).css("left", 25 * r).appendTo(a);
                            $("<span />").css("background-position", o + "px -20px").appendTo(u), l || (o -= 20)
                        }
                        var d = document.createElement("li");
                        d.className = "wmd-spacer wmd-spacer-max", a.append(d), t((function() {
                            a.addSpinner({
                                float: "right"
                            }), StackExchange.using("editor", (function() {
                                a.remove(), n.autoShowMarkdownHelp && (n.immediatelyShowMarkdownHelp = !0), e(n)
                            }))
                        }))
                    }(n) : n.useStacksEditor ? $.when(StackExchange.using("highlightjs", $.noop), StackExchange.using("stacksEditor", $.noop)).then((function() {
                        e(n)
                    })) : StackExchange.using("editor", (function() {
                        e(n)
                    }))
                })
            },
            97477: () => {
                var e;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.Auth = {
                    addOrUpdateError: e = function(e, t) {
                        for (var n = !1, i = 0; i < e.length; i++)
                            if (e[i].id == t.id) {
                                t.changed = e[i].message == t.message, e[i].message = t.message, n = !0;
                                break
                            }
                        n || (t.changed = !0, t.index >= e.length ? e.push(t) : e.splice(t.index, 0, t))
                    },
                    passwordStrengthValidation: function(t, n, i) {
                        var s = t.val(),
                            a = /[a-z]/.test(s),
                            o = /[A-Z]/.test(s),
                            r = /\d/.test(s),
                            c = 0;
                        if (a && c++, o && c++, r && c++, /(_|[^\w\d])/.test(s) && c++, 2 === c && s.length >= 15) return i(n, "pw-weak", t), void i(n, "pw-short", t);
                        var l = $("<span><p>" + __tr(["Please add one of the following things to make your password stronger:$pEnd$ $listStart$ $char$ letters $itemEnd$ $num$ numbers $itemEnd$ $listEnd$"], {
                            pEnd: "</p>",
                            listStart: "<ul>",
                            listEnd: "</ul>",
                            itemEnd: "</li>",
                            char: '<li id="ch">',
                            num: '<li id="num">'
                        }, "en", []) + "</span>");
                        (a || o) && r ? i(n, "pw-weak", t) : c < 3 ? ((a || o) && l.find("#ch").remove(), r && l.find("#num").remove(), e(n, {
                            id: "pw-weak",
                            index: 1,
                            attachTo: t,
                            message: l
                        })) : i(n, "pw-weak", t);
                        var u = t.val().length;
                        u < 8 ? e(n, {
                            id: "pw-short",
                            index: 2,
                            attachTo: t,
                            message: __tr(["Must contain at least $remaining$ more character.", "Must contain at least $remaining$ more characters."], {
                                remaining: 8 - u
                            }, "en", ["remaining"])
                        }) : i(n, "pw-short", t)
                    }
                }
            },
            85736: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.checklist = void $(document).on("click", ".js-toggle-completed-requirements", (function(e) {
                    var t = $(e.target),
                        n = t.closest(".js-checklist"),
                        i = t.hasClass("is-visible"),
                        s = t.data("preference");
                    (function(e, t, n) {
                        return $.post(e, {
                            fkey: StackExchange.options.user.fkey,
                            preference: t,
                            hideCompletedOrDismiss: n
                        })
                    })(t.data("url"), s, i).always((function() {
                        n.find(".js-requirement.is-finished").closest("li").toggleClass("dno"), t.toggleClass("is-visible is-hidden").text(i ? __tr(["Show all items"], undefined, "en", []) : __tr(["Hide completed items"], undefined, "en", []))
                    }))
                }))
            },
            84901: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.stacksValidation = function() {
                    function e(e, t = !1) {
                        this.hideIcons = !1, this.insertIconBeforeMessage = t, this.$input = e, this.$container = e.closest(".js-stacks-validation"), this.$container.length ? (this.$message = this.$container.find(".js-stacks-validation-message"), this.messages = []) : this.invalid = !0
                    }

                    function t(e) {
                        return e.html
                    }

                    function n(e) {
                        return e.type
                    }
                    e.prototype = {
                        _updateMessages: function() {
                            var e;
                            (this.$message.empty().toggleClass("d-none", !this.messages.length), this.messages.length) && (e = 1 === this.messages.length ? this.messages[0].html : "<ul><li>" + this.messages.map(t).join("</li><li class='mt8'>") + "</li></ul>", this.$message.html(e).find("a").attr("target", "_blank"))
                        },
                        _updateIcon: function() {
                            if (this.$container.find(".js-stacks-validation-icon").remove(), this.messages.length && !this.hideIcons) {
                                var e = this.highestType(),
                                    t = Svg[i[e]];
                                this.insertIconBeforeMessage ? t.With("js-stacks-validation-icon fc-red-400 mr4").insertBefore(this.$message) : t.With("js-stacks-validation-icon s-input-icon").insertAfter(this.$input)
                            }
                        },
                        _updateClass: function() {
                            this.$container.removeClass("has-error has-warning has-success"), this.messages.length && this.$container.addClass("has-" + this.highestType())
                        },
                        _updateAriaAttributes: function() {
                            const e = this.$container.find("input[type='text'], textarea, [contenteditable='true']"),
                                t = this.$input.add(e);
                            if (t.removeAttr("aria-invalid"), t.removeAttr("aria-describedby"), !this.messages.length) return;
                            t.attr("aria-invalid", !0);
                            const n = this.$message.attr("id");
                            n && t.attr("aria-describedby", n)
                        },
                        _update: function() {
                            this._updateMessages(), this._updateIcon(), this._updateClass(), this._updateAriaAttributes()
                        },
                        highestType: function() {
                            return this.messages.map(n).reduce((function(e, t) {
                                return "error" === e || "error" === t ? "error" : "warning" === e || "warning" === t ? "warning" : "success"
                            }))
                        },
                        hasType: function(e) {
                            return this.messages.some((function(t) {
                                return t.type === e
                            }))
                        },
                        add: function(e, t) {
                            this.messages.some((function(n) {
                                return n.type === e && n.html === t
                            })) || (this.messages.push({
                                type: e,
                                html: t
                            }), this._update())
                        },
                        addText: function(e, t) {
                            this.add(e, $("<span>").text(t).html())
                        },
                        clear: function(e) {
                            this.messages = e ? this.messages.filter((function(t) {
                                return t.type !== e
                            })) : [], this._update()
                        }
                    };
                    var i = {
                        error: "AlertCircle",
                        warning: "Alert",
                        success: "Checkmark"
                    };
                    return {
                        handlerFor: function(t, n = !1) {
                            var i = t.data("stacks-validation-handler");
                            return i || (i = new e(t, n), t.data("stacks-validation-handler", i)), i.invalid ? null : i
                        }
                    }
                }()
            },
            61560: (e, t, n) => {
                "use strict";
                n.r(t);
                var i = n(20428),
                    s = n.n(i);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, s()(".js-homepage-wizard-link").on("click", (function(e) {
                    dispatchEvent(new CustomEvent("homepageWizardShow")), e.preventDefault()
                }))
            },
            26634: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, Stacks.addController("se-char-counter", {
                    targets: ["field", "output"],
                    connect: function() {
                        $(this.fieldTarget).charCounter({
                            min: +(this.data.get("min") || "0"),
                            max: +(this.data.get("max") || "0"),
                            target: $(this.outputTarget),
                            setIsValid: this.setIsValid.bind(this)
                        })
                    },
                    setIsValid: function(e) {
                        var t = "data-is-valid-length",
                            n = $(this.fieldTarget);
                        "true" !== this.data.get("allow-empty") || n.val() || (e = !0);
                        var i = e.toString();
                        n.attr(t) !== i && (n.attr(t, i), this.triggerEvent("validated"))
                    }
                })
            },
            91204: () => {
                var e, t, n, i;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, i = function() {
                    e = t = null, $("body").removeClass("c-move")
                }, Stacks.addController("se-draggable", {
                    targets: ["handle"],
                    connect: function() {
                        if (this.hasHandleTarget) {
                            var s = $(this.element),
                                a = $(this.handleTarget);
                            a.hasClass("c-move") || a.addClass("c-move"), a.off("mousedown").on("mousedown", (function(n) {
                                s.css({
                                    minWidth: s.outerWidth()
                                });
                                var i = s.offset();
                                t = {
                                    x: i.left - n.pageX,
                                    y: i.top - n.pageY
                                };
                                var a = (e = s).offset();
                                e.offset(a).offset(a), $("body").addClass("c-move"), n.preventDefault()
                            })), n || (n = !0, $(document).on("mousemove", (function(n) {
                                if (e) {
                                    e.removeClass("responsively-horizontally-centered-legacy-popup");
                                    var i = n.pageY + t.y,
                                        s = n.pageX + t.x;
                                    e.offset({
                                        top: i,
                                        left: s
                                    })
                                }
                            })).on("keypress", i).on("mouseup", i))
                        }
                    }
                })
            },
            47298: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, Stacks.addController("se-post-editor-text-input", {
                    connect: function() {
                        "INPUT" === this.element.nodeName && "text" === this.element.type ? .toLowerCase() ? StackExchange.settings.site.doNotSubmitOnEnter && (this.keyDownHandler = function(e) {
                            "Enter" === e.key && e.preventDefault()
                        }, this.element.addEventListener("keydown", this.keyDownHandler)) : StackExchange.debug.log("se-no-enter-submit only supports inputs of type=text")
                    },
                    disconnect: function() {
                        this.keyDownHandler && (this.element.removeEventListener("keydown", this.keyDownHandler), delete this.keyDownHandler)
                    }
                })
            },
            57144: () => {
                "use strict";

                function e(e, t, n) {
                    window.open(e, t, n) || (window.location.href = e)
                }

                function t(e, t, n) {
                    t += "=" + (n = void 0 !== n ? n : "1");
                    var i = e.indexOf("?"),
                        s = e.indexOf("#");
                    return -1 == i ? -1 == s ? e + "?" + t : e.substring(0, s) + "?" + t + e.substring(s) : -1 == s ? e + "&" + t : e.substring(0, s) + "&" + t + e.substring(s)
                }
                const n = function(n, i, s, a) {
                        i = t(i, "sfb", a), n.on("click", (function() {
                            e("https://www.facebook.com/sharer.php?u=" + encodeURIComponent(i) + "&ref=fbshare&t=" + encodeURIComponent(s), "sharefacebook", "toolbar=1,status=1,resizable=1,scrollbars=1,width=626,height=436")
                        }))
                    },
                    i = function(n, i, s, a) {
                        i = t(i, "stw", a), s.length > 257 && (s = s.substring(0, 254) + "..."), n.on("click", (function() {
                            e("https://twitter.com/share?url=" + encodeURIComponent(i) + "&ref=twitbtn&text=" + encodeURIComponent(s), "sharetwitter", "toolbar=1,status=1,resizable=1,scrollbars=1,width=800,height=526")
                        }))
                    },
                    s = function(n, i, s, a) {
                        var o, r;
                        o = (r = i.match(/^.*:\/\/stackoverflow\.com\/[qa]\/(\d+)(?:\/\d+)?$/)) ? "{% stackoverflow {postId} %}".formatUnicorn({
                            postId: r[1]
                        }) : (r = i.match(/^.*:\/\/([a-z]*(?:\.meta)?\.stackoverflow)\.com\/[qa]\/(\d+)(?:\/\d+)?$/)) ? "{% stackexchange {postId} {host} %}".formatUnicorn({
                            postId: r[2],
                            host: r[1]
                        }) : (r = i.match(/^.*:\/\/(([a-z0-9]*(?:\.meta)?)\.stackexchange\.com)\/[qa]\/(\d+)(?:\/\d+)?$/)) ? "{% stackexchange {postId} {host} %}".formatUnicorn({
                            postId: r[3],
                            host: r[2] || r[1]
                        }) : (r = i.match(/^.*:\/\/((?:meta\.)?[a-z0-9]*)\.(?:com|net|org)\/[qa]\/(\d+)(?:\/\d+)?$/)) ? "{% stackexchange {postId} {host} %}".formatUnicorn({
                            postId: r[2],
                            host: r[1]
                        }) : t(i, "sdv", a), n.on("click", (function() {
                            e("https://dev.to/new?prefill=---%0Atitle%3A%20{title}%0Apublished%3A%20true%0A---%0A%0A{body}".formatUnicorn({
                                title: encodeURIComponent(s),
                                body: encodeURIComponent(o)
                            }), "sharedev", "toolbar=1,status=1,resizable=1,scrollbars=1,width=800,height=526")
                        }))
                    };
                var a, o;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, a = 0, o = !1, Stacks.addController("se-share-sheet", {
                    get $el() {
                        return $(this.element)
                    },
                    get controlId() {
                        var e = this.$el.attr("aria-controls");
                        return e || (e = "se-share-sheet-" + a++, this.$el.attr("aria-controls", e)), e
                    },
                    get $sheet() {
                        var e = this.controlId,
                            t = $("#" + e);
                        return 0 === t.length && (t = this.generateSheet(e), this.$el.after(t), StackExchange.gps && StackExchange.gps.bindTrackClicks && StackExchange.gps.bindTrackClicks(t)), t
                    },
                    get location() {
                        return +this.data.get("location") || 0
                    },
                    get copyLinkGpsTrackAction() {
                        return this.data.get("gps-track-action") || ""
                    },
                    initialize: function() {
                        var e = this.$el;

                        function t(t, n) {
                            var i = e.attr(t) || ""; - 1 === i.indexOf(n) && e.attr(t, i + " " + n)
                        }
                        this.updateSheet(!1), t("data-action", "s-popover#toggle"), t("data-action", this.identifier + "#preventNavigation"), t("data-action", "s-popover:show->" + this.identifier + "#willShow"), t("data-action", "s-popover:shown->" + this.identifier + "#didShow"), t("data-controller", "s-popover")
                    },
                    generateSheet: function(e) {
                        var t = $('<div class="s-popover z-dropdown s-anchors s-anchors__default share-sheet-popover"><div class="s-popover--arrow"></div></div>').attr("id", e).append('<div><label for="share-sheet-input-' + this.controlId + '"><span class="js-title fw-bold"></span> <span class="js-subtitle"></span></label></div>').append('<div class="my8"><input type="text" id="share-sheet-input-' + this.controlId + '" class="js-input s-input wmn3 sm:wmn-initial bc-black-300 bg-white fc-black-600" readonly /></div>').append('<div class="d-flex jc-space-between ai-center mbn4"><button class="js-copy-link-btn s-btn s-btn__link js-gps-track" data-gps-track="' + this.copyLinkGpsTrackAction + '"></button><a href="#" rel="license" class="js-license s-block-link w-auto d-none" target="_blank"></a><div class="js-social-container d-none"></div></div>').append('<div class="js-copy-status v-visible-sr" role="status" aria-live="polite"></div>').insertAfter($(this.element));
                        return t.find(".js-copy-link-btn").text(__tr(["Copy link"], undefined, "en", [])).on("click", this.copy.bind(this)), t.find(".js-input").on("copy", this.didCopy.bind(this)), t
                    },
                    willShow: function() {
                        this.updateSheet(!0)
                    },
                    didShow: function() {
                        var e = this.$sheet.find(".js-input");
                        setTimeout((function() {
                            e.trigger("focus").trigger("select")
                        }));
                        var t = this.location;
                        t && StackExchange.gps.track("share.show", {
                            location: t
                        })
                    },
                    copy: function() {
                        var e = this;
                        this.tryCopy().then((function() {
                            var t = __tr(["Link copied to clipboard."], undefined, "en", []),
                                n = e.$sheet.find(".js-copy-status");
                            n.text(""), setTimeout((function() {
                                n.text(t)
                            }), 0), StackExchange.helpers.showToast(t, {
                                transientTimeout: 3e3,
                                type: "success"
                            }), e.didCopy()
                        }), (function() {
                            var t = __tr(["Could not copy link to clipboard."], undefined, "en", []),
                                n = e.$sheet.find(".js-copy-status");
                            n.text(""), setTimeout((function() {
                                n.text(t)
                            }), 0), StackExchange.helpers.showToast(t, {
                                transientTimeout: 5e3,
                                type: "danger"
                            })
                        }))
                    },
                    didCopy: function() {
                        if (!o) {
                            var e = this.location;
                            e && StackExchange.gps.track("share.click", {
                                location: e,
                                service: 6
                            })
                        }
                    },
                    tryCopy: function() {
                        var e, t = this.$sheet.find(".js-input");
                        if (navigator.clipboard) return navigator.clipboard.writeText(t.val());
                        t.trigger("focus").trigger("select"), o = !0;
                        try {
                            e = document.execCommand("copy")
                        } catch (t) {
                            e = !1
                        }
                        o = !1;
                        var n = $.Deferred();
                        return e ? n.resolve() : n.reject(), n.promise()
                    },
                    preventNavigation: function(e) {
                        e.ctrlKey || e.metaKey || e.preventDefault()
                    },
                    updateSheet: function(e) {
                        this.triggerEvent("update");
                        var t = this.$sheet;
                        t.find(".js-title").text(this.data.get("title") || __tr(["Copy and share this link:"], undefined, "en", [])), t.find(".js-subtitle").text(this.data.get("subtitle") || ""), t.find(".js-input").val(this.element.href);
                        var a = this.data.get("license-url"),
                            o = t.find(".js-license").toggleClass("d-none", !a);
                        if (a) {
                            o.attr("href", decodeURIComponent(this.data.get("license-url")));
                            var r = this.data.get("license-name");
                            o.text(r), o.attr("title", __tr(["The current license for this post: $licenseName$"], {
                                licenseName: r
                            }, "en", []))
                        }
                        t.find(".js-social-container").addClass("d-none").empty();
                        var c = this.data.get("post-type"),
                            l = this.data.get("message");
                        if (e && ("question" === c || "answer" === c || "announcement" === c || "article" === c || "discussion" === c)) {
                            var u = (this.data.get("social") || "").split(/\s+/); - 1 !== u.indexOf("facebook") && this.addSocialComponent(c, "Facebook", Svg.Facebook.With("native"), __tr(["Share on Facebook"], undefined, "en", []), 2, n, l), -1 !== u.indexOf("twitter") && this.addSocialComponent(c, "Twitter", Svg.Twitter.With("native"), __tr(["Share on Twitter"], undefined, "en", []), 3, i, l), -1 !== u.indexOf("devto") && this.addSocialComponent(c, "DEV", Svg.DevTo.With("native"), __tr(["Share on DEV"], undefined, "en", []), 5, s, l)
                        }
                    },
                    addSocialComponent: function(e, t, n, i, s, a, o) {
                        var r = __tr(["Share link to this $postType$ on $socialNetwork$"], {
                                socialNetwork: t,
                                postType: e
                            }, "en", []),
                            c = $("<button>", {
                                class: "s-btn p4",
                                role: "button",
                                title: r,
                                "aria-label": i
                            }).append(n),
                            l = "";
                        switch (e) {
                            case "question":
                                l = o || $("#question-header a.question-hyperlink").text();
                                break;
                            case "answer":
                                l = o || __tr(["Answer: $title$"], {
                                    title: $("#question-header a.question-hyperlink").text()
                                }, "en", []);
                                break;
                            case "announcement":
                            case "discussion":
                                l = o || ""
                        }
                        a(c, this.element.href, l, "2");
                        var u = this.location;
                        c.on("click", (function() {
                            u && StackExchange.gps.track("share.click", {
                                location: u,
                                service: s
                            })
                        })).appendTo(this.$sheet.find(".js-social-container").removeClass("d-none"))
                    }
                })
            },
            93850: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.bindShowMoreHotNetworkQuestions = function() {
                    let e = $("#hot-network-questions"),
                        t = e.find(".js-show-more"),
                        n = e.find(".js-hidden");
                    if (!e.length || !t.length || !n.length) return;
                    let i = $("#mainbar").height(),
                        s = $("#sidebar").height() + 550;
                    n.attr("style", "visibility:hidden").removeClass("dno");
                    let a = 0,
                        o = [];
                    if (n.each(((e, t) => {
                            let n = $(t).height();
                            o.push(n), a += n
                        })), i >= s + a) return t.remove(), void n.attr("style", "").show();
                    let r = [],
                        c = s;
                    n.each(((e, t) => {
                        let n = $(t),
                            s = o[e];
                        c + s <= i && (r.push(n), c += s)
                    })), n.attr("style", "").addClass("dno"), r.forEach((e => e.show())), t.on("click", (() => (n.show(), t.remove(), !1)))
                }
            },
            20836: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.sidebar = {
                    initCollectionWidget: function(e) {
                        var t = $(".js-in-these-collections-widget").parent();
                        t.on("click", ".js-fetch-add-to-collection-modal", (function(t) {
                            var n = $(t.target);
                            n.hasClass("is-loading") || (n.addClass("is-loading"), StackExchange.helpers.loadModal("/collections/modal-add-to-collection?postId=" + e).always((function() {
                                n.removeClass("is-loading")
                            })))
                        })), t.on("click", ".js-collections-widget--show-all", (function(e) {
                            $(e.target).add(".js-widget-collection.d-none").toggleClass("d-none")
                        }))
                    }
                }
            },
            30375: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.expandableOverflow = {
                    init: function(e, t) {
                        if (!e || !t) return;
                        const n = new ResizeObserver((e => {
                            const n = e[0].target;
                            n.scrollHeight > n.clientHeight ? (n.classList.add("v-truncate-fade"), null == t || t.classList.remove("v-hidden")) : (n.classList.remove("v-truncate-fade"), null == t || t.classList.add("v-hidden"))
                        }));
                        t.addEventListener("click", (() => {
                            n.disconnect(), e.classList.remove("v-truncate-fade"), e.classList.add("h-auto", "hmx-initial"), t.classList.add("v-hidden")
                        }), !1), n.observe(e)
                    }
                }
            },
            43705: () => {
                var e;
                e = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e) {
                        e.bindCommunityWikiConfirmation = function(e) {
                            e.find("input[type=checkbox][name=communitymode]").off("click").one("click", (() => confirm(__tr(["Are you sure you want to make this post Community Wiki?$blankLine$Doing so will remove explicit ownership and you will no longer earn reputation for upvotes on it. Once saved, this option cannot be unchecked without moderator assistance."], {
                                blankLine: "\n\n"
                            }, "en", []))))
                        }
                    }(e || (e = {}))
            },
            71322: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, $(document).on("click", ".js-feed-link", (function(e) {
                    const t = $(this),
                        n = t.siblings(".js-feed-link-modal").clone();
                    n.length > 0 && (e.preventDefault(), StackExchange.helpers.showModal(n, {
                        returnElements: t,
                        shown: function() {
                            n.find(".s-input").trigger("focus").trigger("select")
                        }
                    }))
                }))
            },
            72498: () => {
                var e;
                e = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e) {
                        ! function(t) {
                            class n {
                                constructor(e) {
                                    this.cookieId = e.attr("data-cookie"), this.expireDate = new Date(+e.attr("data-expire-date"))
                                }
                                setCookie(e) {
                                    $.cookie(this.cookieId, e, {
                                        expires: this.expireDate,
                                        path: "/"
                                    })
                                }
                                ctaClicked() {
                                    this.setCookie(`2;${Date.now()}`)
                                }
                                dismissed() {
                                    this.setCookie(`4;${Date.now()}`)
                                }
                            }

                            function i(t, i, s) {
                                const a = new n(t);
                                return t.find(".js-link").on("click", (() => {
                                    a.ctaClicked(), s && window.open(s, "_blank"), i()
                                })), t.find(".js-dismiss").on("click", (n => {
                                    n.preventDefault(), a.dismissed(), i(), "true" === t.attr("data-is-site-sat") ? $.post("/survey/site-satisfaction/dismiss", {
                                        fkey: e.options.user.fkey
                                    }) : "true" === t.attr("data-is-coso-survey") && $.post("/survey/collectives/dismiss", {
                                        fkey: e.options.user.fkey,
                                        slug: t.data("coso-slug")
                                    })
                                })), a
                            }

                            function s() {
                                const e = $(".js-popover-reference");
                                $(".js-announcement-banner").animate({
                                    height: "0",
                                    opacity: 0
                                }, "fast", "linear", (function() {
                                    $(this).remove()
                                })), e.length && Stacks.hidePopover(e[0])
                            }
                            t.announcementBannerInit = function() {
                                i($(".js-announcement-banner"), s)
                            }, t.sidebarPopoverInit = function() {
                                const e = $(".js-notice-sidebar-popover"),
                                    t = $(".js-popover-reference");
                                i(e, s), e.length && t.length && setTimeout((() => {
                                    Stacks.showPopover(t[0])
                                }), 1e3)
                            }
                        }(e.Notice || (e.Notice = {}))
                    }(e || (e = {}))
            },
            31631: () => {
                var e;
                e = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e) {
                        ! function(t) {
                            function n(t) {
                                const n = t.closest(".js-outdated-answers").find(".js-modal-container");
                                let i = t.data("post-id");
                                $.ajax({
                                    url: "/posts/outdated/modal/" + i,
                                    dataType: "html",
                                    type: "GET",
                                    success: function(t) {
                                        n.html(t), setTimeout((() => Stacks.showModal(n.find("#js-outdated-answers-modal")[0])), 50), $(".js-submit-outdated-answer").on("click", (function(t) {
                                            ! function(t) {
                                                let n = 0,
                                                    i = $(".js-outdated-options"),
                                                    s = i.closest(".js-outdated-answers"),
                                                    a = s.data("answer-type"),
                                                    o = s.data("position-on-page"),
                                                    r = s.data("score");
                                                i.find(".s-checkbox:checked").each((function(e, t) {
                                                    let i = $(t).data("answer-flag-value");
                                                    n |= i
                                                })), e.using("gps", (function() {
                                                    e.gps.track("outdated_prompt.yes_detail", {
                                                        OutdatedAnswerOptions: n,
                                                        AnswerType: a,
                                                        PositionOnPage: o,
                                                        AnswerId: t,
                                                        Score: r
                                                    })
                                                }))
                                            }(i)
                                        }))
                                    }
                                })
                            }

                            function i(e) {
                                let t = $(`.js-outdated-answers[data-post-id=${e}]`);
                                t.find(".js-outdated-interactions").addClass("d-none"), t.find(".js-outdated-svg").removeClass("native"), t.find(".js-outdated-answer-prompt").text(__tr(["Thanks for your feedback on this answer."], undefined, "en", []))
                            }
                            t.initAnon = function(e) {
                                e && ($(".js-outdated-yes").on("click", (function(e) {
                                    let t = $(this).data("post-id");
                                    n($(this)), i(t)
                                })), $(".js-outdated-no").on("click", (function() {
                                    i($(this).data("post-id"))
                                })))
                            }, t.openModal = n, t.userVoted = i
                        }(e.OutdatedAnswers || (e.OutdatedAnswers = {}))
                    }(e || (e = {}))
            },
            98297: () => {
                StackExchange = window.StackExchange = window.StackExchange || {},
                    function(e) {
                        ! function(e) {
                            let t;
                            ! function(e) {
                                e[e.Question = 1] = "Question", e[e.Answer = 2] = "Answer", e[e.Wiki = 3] = "Wiki", e[e.TagWikiUsageGuidance = 4] = "TagWikiUsageGuidance", e[e.TagWiki = 5] = "TagWiki", e[e.ModeratorNomination = 6] = "ModeratorNomination", e[e.WikiPlaceholder = 7] = "WikiPlaceholder", e[e.PrivilegeWiki = 8] = "PrivilegeWiki", e[e.Article = 9] = "Article", e[e.HelpArticle = 10] = "HelpArticle", e[e.Collection = 12] = "Collection", e[e.ModeratorQuestionnaireResponse = 13] = "ModeratorQuestionnaireResponse", e[e.Announcement = 14] = "Announcement", e[e.CollectiveDiscussion = 15] = "CollectiveDiscussion", e[e.CollectiveCollection = 17] = "CollectiveCollection", e[e.TagWikiSummary = 18] = "TagWikiSummary", e[e.Challenge = 19] = "Challenge", e[e.ChallengeEntry = 20] = "ChallengeEntry"
                            }(t = e.PostTypeId || (e.PostTypeId = {}))
                        }(e.Models || (e.Models = {}))
                    }((window.StackOverflow = window.StackOverflow || {}) || {})
            },
            27558: () => {
                var StackExchange;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(StackExchange) {
                        var ads;
                        (function(ads) {
                            const modalClass = ".js-ad-report";
                            let adReports;
                            class AdReports {
                                constructor(e, t, n) {
                                    var i;
                                    if (this.googletag = e, this.adReportUrl = t, this.adReportText = n, this.handleSlotRendered = e => {
                                            if (e && e.slot && !e.isEmpty) {
                                                var t = e.slot.getSlotElementId();
                                                if (t) {
                                                    var n = $("#" + t).parent(".js-zone-container").find(".js-report-ad-button-container");
                                                    if ((e.creativeId || e.lineItemId || !e.isEmpty) && (!clc.options.dh || -1 === clc.options.dh.indexOf(e.lineItemId))) {
                                                        var i = $(`<button class="js-report-ad s-btn s-btn__link fs-fine mt2 float-right">${this.adReportText}</button>`);
                                                        n.append(i), i.data("modal-url", this.adReportUrl), i.data("ad-unit", e.slot.getSlotElementId());
                                                        var s = JSON.stringify(e);
                                                        i.data("google-event-data", s), this.initButton(i)
                                                    }
                                                }
                                            }
                                        }, this.googletag.pubads().addEventListener("slotRenderEnded", this.handleSlotRendered), Array.isArray(null === (i = null === clc || void 0 === clc ? void 0 : clc.dfp) || void 0 === i ? void 0 : i.slotsRenderedEvents))
                                        for (var s = 0; s < clc.dfp.slotsRenderedEvents.length; s++) this.handleSlotRendered(clc.dfp.slotsRenderedEvents[s])
                                }
                                initButton(e) {
                                    e.off().on("click", (t => {
                                        t.preventDefault();
                                        const n = e.data("modal-url"),
                                            i = e.data("google-event-data");
                                        return this.loadModal(n, e, i), !1
                                    }))
                                }
                                loadModal(url, $link, googleEventData) {
                                    StackExchange.helpers.loadModal(url, {
                                        returnElements: $link
                                    }).then((() => {
                                        this.initForm(googleEventData)
                                    })).fail((responseText => {
                                        var message = "",
                                            response = eval("(" + responseText + ")");
                                        message = response && response.isLoggedOut ? __tr(["Your login session has expired, please login and try again."], undefined, "en", []) : __tr(["An error occurred when loading the report form - please try again"], undefined, "en", []), StackExchange.helpers.showToast(message, {
                                            type: "danger"
                                        })
                                    }))
                                }
                                removeModal() {
                                    StackExchange.helpers.closePopups($(modalClass), "dismiss")
                                }
                                initForm(e) {
                                    const t = $(".js-ad-report-form"),
                                        n = t.find(".js-json-data"),
                                        i = t.find(".js-ad-report-reason"),
                                        s = t.find(".js-ad-report-reason-other"),
                                        a = t.find(".js-file-uploader-input"),
                                        o = t.find(".js-image-uploader"),
                                        r = t.find(".js-clear-image-upload"),
                                        c = t.find(".js-image-uploader-text"),
                                        l = t.find(".js-image-uploader-preview"),
                                        u = t.find(".js-image-uploader-link"),
                                        d = t.find(".js-file-error"),
                                        h = ["image/png", "image/jpg", "image/jpeg"],
                                        _ = t.find(".js-drag-drop-enabled"),
                                        p = t.find(".js-drag-drop-disabled");
                                    u.on("click", (function(e) {
                                        e.preventDefault(), a.trigger("click")
                                    })), n.val(e), i.on("change", (e => {
                                        s.toggleClass("d-none", "3" !== $(e.target).val())
                                    }));
                                    a.on("change", (function() {
                                        var e = a[0];
                                        f() && m(e.files)
                                    }));
                                    var f = function() {
                                            const e = __tr(["Please select a PNG or JPG file"], undefined, "en", []),
                                                t = __tr(["The file must be under 2 MiB"], undefined, "en", []);
                                            var n = a[0];
                                            if (null == n.files) return !1;
                                            var i = n.files[0];
                                            return null == i ? (g(!0), !1) : h.indexOf(i.type) < 0 ? (d.text(e), d.removeClass("d-none"), g(!0), !1) : i.size > 2097152 ? (d.text(t), d.removeClass("d-none"), g(!0), !1) : (d.addClass("d-none"), g(!1), !0)
                                        },
                                        g = function(e) {
                                            d.parent().toggleClass("has-error", e)
                                        },
                                        m = function(e) {
                                            o.removeClass("p16 ba bas-dashed bc-black-225"), r.removeClass("d-none"), c.addClass("d-none");
                                            var t = new FileReader;
                                            t.onload = function(e) {
                                                null != e.target && (l.prop("src", e.target.result), l.removeClass("d-none"))
                                            }, t.readAsDataURL(e[0])
                                        };
                                    r.on("click", (e => {
                                        e.preventDefault(), a.val(""), l.prop("src", ""), l.addClass("d-none"), r.addClass("d-none"), c.removeClass("d-none"), o.addClass("p16 ba bas-dashed bc-black-225")
                                    }));
                                    try {
                                        a[0].files = null, o.on("dragenter dragover dragleave drop", (function(e) {
                                            e.preventDefault(), e.stopPropagation()
                                        })), o.on("dragenter dragover", (function(e) {
                                            o.removeClass("bas-dashed"), o.addClass("bas-solid bc-black-225")
                                        })), o.on("dragleave drop", (function(e) {
                                            o.removeClass("bas-solid bc-black-225"), o.addClass("bas-dashed")
                                        })), o.on("drop", (function(e) {
                                            var t = e.originalEvent.dataTransfer.files;
                                            FileReader && t && 1 === t.length && (a[0].files = t, f() && m(t))
                                        }))
                                    } catch (e) {
                                        _.addClass("d-none"), p.removeClass("d-none")
                                    }
                                    t.off().on("submit", (e => {
                                        if (e.preventDefault(), !f()) return !1;
                                        t.find("[type=submit]").prop("disabled", !0);
                                        var i = JSON.parse(n.val() || "{}");
                                        i.Reason = parseInt(t.find(".js-ad-report-reason:checked").val(), 10), i.Description = s.val(), n.val(JSON.stringify(i));
                                        var a = new FormData(t[0]);
                                        return $.ajax({
                                            type: t.prop("method"),
                                            url: t.prop("action"),
                                            data: a,
                                            cache: !1,
                                            contentType: !1,
                                            processData: !1
                                        }).then(((e, t, n) => {
                                            const i = n.getResponseHeader("content-type") || "";
                                            if ("string" == typeof e && 0 == i.indexOf("text/html")) {
                                                const t = $(e).find(".js-modal-content");
                                                t.length > 0 && $(".js-modal-content").replaceWith(t)
                                            } else this.removeModal(), StackExchange.helpers.showToast(__tr(["Thanks for your feedback. We’ll review this against our code of conduct and take action if necessary."], undefined, "en", []), {
                                                type: "success"
                                            })
                                        }), (function() {
                                            StackExchange.helpers.showToast(__tr(["Error uploading ad report."], undefined, "en", []), {
                                                type: "danger"
                                            })
                                        })).always((function() {
                                            t.find("[type=submit]").prop("disabled", !1)
                                        })), !1
                                    }))
                                }
                            }

                            function init(e, t, n) {
                                adReports || (adReports = new AdReports(e, t, n))
                            }
                            ads.init = init
                        })(ads = StackExchange.ads || (StackExchange.ads = {}))
                    }(StackExchange || (StackExchange = {}))
            },
            48781: () => {
                var e;
                e = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e) {
                        ! function(t) {
                            t.showConfirmModal = function(n) {
                                var i = $('\n<aside class="s-modal" role="dialog" aria-labelledby="confirm-modal-title" aria-describedby="confirm-modal-body" aria-hidden="true">\n    <div class="s-modal--dialog ps-relative" data-controller="se-draggable" role="document">\n        <h1 class="s-modal--header fw-bold" id="confirm-modal-title" data-se-draggable-target="handle"></h1>\n        <div class="s-modal--body fs-body2" id="confirm-modal-body"></div>\n        <div class="d-flex gs8 gsx s-modal--footer">\n            <button class="flex--item s-btn js-ok-button s-btn__filled" type="button"></button>\n            <button class="flex--item s-btn js-cancel-button js-modal-close js-modal-initial-focus" type="button"></button>\n        </div>\n    </div>\n</aside>\n');
                                const s = (e, t, n) => {
                                    const s = i.find(e);
                                    t ? s.append(t) : n && s.text(n)
                                };
                                return s("#confirm-modal-title", n.titleHtml, n.title), s("#confirm-modal-body", n.bodyHtml, n.body), s(".js-ok-button", n.buttonLabelHtml, n.buttonLabel || __tr(["OK"], undefined, "en", [])), s(".js-cancel-button", void 0, __tr(["Cancel"], undefined, "en", [])), new Promise(((s, a) => {
                                    t.showModal(i, n), i.find(".js-ok-button").on("click", (t => {
                                        t.preventDefault(), s(!0), e.helpers.closePopups(i, "dismiss")
                                    })), i.on("popupClose", (e => s(!1)))
                                }))
                            }
                        }(e.helpers || (e.helpers = {}))
                    }(e || (e = {}))
            },
            53536: (e, t, n) => {
                var i = {
                    "./datepicker-af.js": [60242, 3431, 7334],
                    "./datepicker-ar-DZ.js": [22045, 3431, 9167],
                    "./datepicker-ar.js": [75214, 3431, 9314],
                    "./datepicker-az.js": [72230, 3431, 9754],
                    "./datepicker-be.js": [45856, 3431, 8952],
                    "./datepicker-bg.js": [76650, 3431, 2590],
                    "./datepicker-bs.js": [23334, 3431, 5850],
                    "./datepicker-ca.js": [60677, 3431, 8631],
                    "./datepicker-cs.js": [84115, 3431, 561],
                    "./datepicker-cy-GB.js": [66459, 3431, 9177],
                    "./datepicker-da.js": [71302, 3431, 4714],
                    "./datepicker-de-AT.js": [62706, 3431, 1942],
                    "./datepicker-de.js": [15546, 3431, 7438],
                    "./datepicker-el.js": [4372, 3431, 2844],
                    "./datepicker-en-AU.js": [1773, 3431, 4527],
                    "./datepicker-en-GB.js": [31166, 3431, 8210],
                    "./datepicker-en-NZ.js": [88087, 3431, 6261],
                    "./datepicker-eo.js": [16221, 3431, 6255],
                    "./datepicker-es.js": [38985, 3431, 8155],
                    "./datepicker-et.js": [48508, 3431, 7028],
                    "./datepicker-eu.js": [3971, 3431, 6737],
                    "./datepicker-fa.js": [14136, 3431, 9168],
                    "./datepicker-fi.js": [94832, 3431, 7624],
                    "./datepicker-fo.js": [41830, 3431, 7658],
                    "./datepicker-fr-CA.js": [91766, 3431, 2106],
                    "./datepicker-fr-CH.js": [43773, 3431, 6559],
                    "./datepicker-fr.js": [81121, 3431, 7731],
                    "./datepicker-gl.js": [83702, 3431, 3450],
                    "./datepicker-he.js": [58222, 3431, 9218],
                    "./datepicker-hi.js": [5370, 3431, 8478],
                    "./datepicker-hr.js": [26751, 3431, 1213],
                    "./datepicker-hu.js": [27742, 3431, 6194],
                    "./datepicker-hy.js": [59082, 3431, 6158],
                    "./datepicker-id.js": [65376, 3431, 968],
                    "./datepicker-is.js": [96357, 3431, 8551],
                    "./datepicker-it-CH.js": [34858, 3431, 4158],
                    "./datepicker-it.js": [95856, 3431, 6456],
                    "./datepicker-ja.js": [13828, 3431, 1772],
                    "./datepicker-ka.js": [41885, 3431, 1231],
                    "./datepicker-kk.js": [43699, 3431, 8321],
                    "./datepicker-km.js": [78969, 3431, 2987],
                    "./datepicker-ko.js": [48407, 3431, 5429],
                    "./datepicker-ky.js": [3909, 3431, 39],
                    "./datepicker-lb.js": [987, 3431, 2009],
                    "./datepicker-lt.js": [77873, 3431, 9827],
                    "./datepicker-lv.js": [7471, 3431, 7757],
                    "./datepicker-mk.js": [98889, 3431, 1131],
                    "./datepicker-ml.js": [7900, 3431, 7908],
                    "./datepicker-ms.js": [52225, 3431, 5539],
                    "./datepicker-nb.js": [33641, 3431, 4091],
                    "./datepicker-nl-BE.js": [61285, 3431, 9495],
                    "./datepicker-nl.js": [23595, 3431, 7702],
                    "./datepicker-nn.js": [99981, 3431, 8239],
                    "./datepicker-no.js": [73966, 3431, 4066],
                    "./datepicker-pl.js": [44141, 3431, 6671],
                    "./datepicker-pt-BR.js": [42366, 3431, 2978],
                    "./datepicker-pt.js": [37109, 3431, 8228],
                    "./datepicker-rm.js": [5880, 3431, 7712],
                    "./datepicker-ro.js": [94338, 3431, 4646],
                    "./datepicker-ru.js": [32800, 3431, 5304],
                    "./datepicker-sk.js": [79899, 3431, 4889],
                    "./datepicker-sl.js": [58162, 3431, 2390],
                    "./datepicker-sq.js": [40517, 3431, 9831],
                    "./datepicker-sr-SR.js": [84964, 3431, 7356],
                    "./datepicker-sr.js": [33564, 3431, 503],
                    "./datepicker-sv.js": [74192, 3431, 2552],
                    "./datepicker-ta.js": [81558, 3431, 3274],
                    "./datepicker-th.js": [49917, 3431, 7727],
                    "./datepicker-tj.js": [86011, 3431, 4329],
                    "./datepicker-tr.js": [21315, 3431, 5553],
                    "./datepicker-uk.js": [49393, 3431, 9203],
                    "./datepicker-vi.js": [78208, 3431, 280],
                    "./datepicker-zh-CN.js": [19349, 3431, 5047],
                    "./datepicker-zh-HK.js": [25593, 3431, 5019],
                    "./datepicker-zh-TW.js": [86449, 3431, 5155]
                };

                function s(e) {
                    if (!n.o(i, e)) return Promise.resolve().then((() => {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        s = t[0];
                    return Promise.all(t.slice(1).map(n.e)).then((() => n.t(s, 23)))
                }
                s.keys = () => Object.keys(i), s.id = 53536, e.exports = s
            },
            56883: (e, t, n) => {
                var i, s, a;
                ! function() {
                    "use strict";
                    s = [n(20428)], void 0 === (a = "function" == typeof(i = function(e) {
                        return e.ui = e.ui || {}, e.ui.version = "1.14.1"
                    }) ? i.apply(t, s) : i) || (e.exports = a)
                }()
            },
            69139: (e, t, n) => {
                var i, s, a;
                ! function() {
                    "use strict";
                    s = [n(20428), n(56883)], i = function(e) {
                        var t = 0,
                            n = Array.prototype.hasOwnProperty,
                            i = Array.prototype.slice;
                        return e.cleanData = function(t) {
                            return function(n) {
                                var i, s, a;
                                for (a = 0; null != (s = n[a]); a++)(i = e._data(s, "events")) && i.remove && e(s).triggerHandler("remove");
                                t(n)
                            }
                        }(e.cleanData), e.widget = function(t, n, i) {
                            var s, a, o, r = {},
                                c = t.split(".")[0];
                            if ("__proto__" === (t = t.split(".")[1]) || "constructor" === t) return e.error("Invalid widget name: " + t);
                            var l = c + "-" + t;
                            return i || (i = n, n = e.Widget), Array.isArray(i) && (i = e.extend.apply(null, [{}].concat(i))), e.expr.pseudos[l.toLowerCase()] = function(t) {
                                return !!e.data(t, l)
                            }, e[c] = e[c] || {}, s = e[c][t], a = e[c][t] = function(e, t) {
                                if (!this || !this._createWidget) return new a(e, t);
                                arguments.length && this._createWidget(e, t)
                            }, e.extend(a, s, {
                                version: i.version,
                                _proto: e.extend({}, i),
                                _childConstructors: []
                            }), (o = new n).options = e.widget.extend({}, o.options), e.each(i, (function(e, t) {
                                r[e] = "function" == typeof t ? function() {
                                    function i() {
                                        return n.prototype[e].apply(this, arguments)
                                    }

                                    function s(t) {
                                        return n.prototype[e].apply(this, t)
                                    }
                                    return function() {
                                        var e, n = this._super,
                                            a = this._superApply;
                                        return this._super = i, this._superApply = s, e = t.apply(this, arguments), this._super = n, this._superApply = a, e
                                    }
                                }() : t
                            })), a.prototype = e.widget.extend(o, {
                                widgetEventPrefix: s && o.widgetEventPrefix || t
                            }, r, {
                                constructor: a,
                                namespace: c,
                                widgetName: t,
                                widgetFullName: l
                            }), s ? (e.each(s._childConstructors, (function(t, n) {
                                var i = n.prototype;
                                e.widget(i.namespace + "." + i.widgetName, a, n._proto)
                            })), delete s._childConstructors) : n._childConstructors.push(a), e.widget.bridge(t, a), a
                        }, e.widget.extend = function(t) {
                            for (var s, a, o = i.call(arguments, 1), r = 0, c = o.length; r < c; r++)
                                for (s in o[r]) a = o[r][s], n.call(o[r], s) && void 0 !== a && (e.isPlainObject(a) ? t[s] = e.isPlainObject(t[s]) ? e.widget.extend({}, t[s], a) : e.widget.extend({}, a) : t[s] = a);
                            return t
                        }, e.widget.bridge = function(t, n) {
                            var s = n.prototype.widgetFullName || t;
                            e.fn[t] = function(a) {
                                var o = "string" == typeof a,
                                    r = i.call(arguments, 1),
                                    c = this;
                                return o ? this.length || "instance" !== a ? this.each((function() {
                                    var n, i = e.data(this, s);
                                    return "instance" === a ? (c = i, !1) : i ? "function" != typeof i[a] || "_" === a.charAt(0) ? e.error("no such method '" + a + "' for " + t + " widget instance") : (n = i[a].apply(i, r)) !== i && void 0 !== n ? (c = n && n.jquery ? c.pushStack(n.get()) : n, !1) : void 0 : e.error("cannot call methods on " + t + " prior to initialization; attempted to call method '" + a + "'")
                                })) : c = void 0 : (r.length && (a = e.widget.extend.apply(null, [a].concat(r))), this.each((function() {
                                    var t = e.data(this, s);
                                    t ? (t.option(a || {}), t._init && t._init()) : e.data(this, s, new n(a, this))
                                }))), c
                            }
                        }, e.Widget = function() {}, e.Widget._childConstructors = [], e.Widget.prototype = {
                            widgetName: "widget",
                            widgetEventPrefix: "",
                            defaultElement: "<div>",
                            options: {
                                classes: {},
                                disabled: !1,
                                create: null
                            },
                            _createWidget: function(n, i) {
                                i = e(i || this.defaultElement || this)[0], this.element = e(i), this.uuid = t++, this.eventNamespace = "." + this.widgetName + this.uuid, this.bindings = e(), this.hoverable = e(), this.focusable = e(), this.classesElementLookup = {}, i !== this && (e.data(i, this.widgetFullName, this), this._on(!0, this.element, {
                                    remove: function(e) {
                                        e.target === i && this.destroy()
                                    }
                                }), this.document = e(i.style ? i.ownerDocument : i.document || i), this.window = e(this.document[0].defaultView || this.document[0].parentWindow)), this.options = e.widget.extend({}, this.options, this._getCreateOptions(), n), this._create(), this.options.disabled && this._setOptionDisabled(this.options.disabled), this._trigger("create", null, this._getCreateEventData()), this._init()
                            },
                            _getCreateOptions: function() {
                                return {}
                            },
                            _getCreateEventData: e.noop,
                            _create: e.noop,
                            _init: e.noop,
                            destroy: function() {
                                var t = this;
                                this._destroy(), e.each(this.classesElementLookup, (function(e, n) {
                                    t._removeClass(n, e)
                                })), this.element.off(this.eventNamespace).removeData(this.widgetFullName), this.widget().off(this.eventNamespace).removeAttr("aria-disabled"), this.bindings.off(this.eventNamespace)
                            },
                            _destroy: e.noop,
                            widget: function() {
                                return this.element
                            },
                            option: function(t, n) {
                                var i, s, a, o = t;
                                if (0 === arguments.length) return e.widget.extend({}, this.options);
                                if ("string" == typeof t)
                                    if (o = {}, i = t.split("."), t = i.shift(), i.length) {
                                        for (s = o[t] = e.widget.extend({}, this.options[t]), a = 0; a < i.length - 1; a++) s[i[a]] = s[i[a]] || {}, s = s[i[a]];
                                        if (t = i.pop(), 1 === arguments.length) return void 0 === s[t] ? null : s[t];
                                        s[t] = n
                                    } else {
                                        if (1 === arguments.length) return void 0 === this.options[t] ? null : this.options[t];
                                        o[t] = n
                                    }
                                return this._setOptions(o), this
                            },
                            _setOptions: function(e) {
                                var t;
                                for (t in e) this._setOption(t, e[t]);
                                return this
                            },
                            _setOption: function(e, t) {
                                return "classes" === e && this._setOptionClasses(t), this.options[e] = t, "disabled" === e && this._setOptionDisabled(t), this
                            },
                            _setOptionClasses: function(t) {
                                var n, i, s;
                                for (n in t) s = this.classesElementLookup[n], t[n] !== this.options.classes[n] && s && s.length && (i = e(s.get()), this._removeClass(s, n), i.addClass(this._classes({
                                    element: i,
                                    keys: n,
                                    classes: t,
                                    add: !0
                                })))
                            },
                            _setOptionDisabled: function(e) {
                                this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!e), e && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"))
                            },
                            enable: function() {
                                return this._setOptions({
                                    disabled: !1
                                })
                            },
                            disable: function() {
                                return this._setOptions({
                                    disabled: !0
                                })
                            },
                            _classes: function(t) {
                                var n = [],
                                    i = this;

                                function s() {
                                    var n = [];
                                    t.element.each((function(t, s) {
                                        e.map(i.classesElementLookup, (function(e) {
                                            return e
                                        })).some((function(e) {
                                            return e.is(s)
                                        })) || n.push(s)
                                    })), i._on(e(n), {
                                        remove: "_untrackClassesElement"
                                    })
                                }

                                function a(a, o) {
                                    var r, c;
                                    for (c = 0; c < a.length; c++) r = i.classesElementLookup[a[c]] || e(), t.add ? (s(), r = e(e.uniqueSort(r.get().concat(t.element.get())))) : r = e(r.not(t.element).get()), i.classesElementLookup[a[c]] = r, n.push(a[c]), o && t.classes[a[c]] && n.push(t.classes[a[c]])
                                }
                                return (t = e.extend({
                                    element: this.element,
                                    classes: this.options.classes || {}
                                }, t)).keys && a(t.keys.match(/\S+/g) || [], !0), t.extra && a(t.extra.match(/\S+/g) || []), n.join(" ")
                            },
                            _untrackClassesElement: function(t) {
                                var n = this;
                                e.each(n.classesElementLookup, (function(i, s) {
                                    -1 !== e.inArray(t.target, s) && (n.classesElementLookup[i] = e(s.not(t.target).get()))
                                })), this._off(e(t.target))
                            },
                            _removeClass: function(e, t, n) {
                                return this._toggleClass(e, t, n, !1)
                            },
                            _addClass: function(e, t, n) {
                                return this._toggleClass(e, t, n, !0)
                            },
                            _toggleClass: function(e, t, n, i) {
                                i = "boolean" == typeof i ? i : n;
                                var s = "string" == typeof e || null === e,
                                    a = {
                                        extra: s ? t : n,
                                        keys: s ? e : t,
                                        element: s ? this.element : e,
                                        add: i
                                    };
                                return a.element.toggleClass(this._classes(a), i), this
                            },
                            _on: function(t, n, i) {
                                var s, a = this;
                                "boolean" != typeof t && (i = n, n = t, t = !1), i ? (n = s = e(n), this.bindings = this.bindings.add(n)) : (i = n, n = this.element, s = this.widget()), e.each(i, (function(i, o) {
                                    function r() {
                                        if (t || !0 !== a.options.disabled && !e(this).hasClass("ui-state-disabled")) return ("string" == typeof o ? a[o] : o).apply(a, arguments)
                                    }
                                    "string" != typeof o && (r.guid = o.guid = o.guid || r.guid || e.guid++);
                                    var c = i.match(/^([\w:-]*)\s*(.*)$/),
                                        l = c[1] + a.eventNamespace,
                                        u = c[2];
                                    u ? s.on(l, u, r) : n.on(l, r)
                                }))
                            },
                            _off: function(t, n) {
                                n = (n || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, t.off(n), this.bindings = e(this.bindings.not(t).get()), this.focusable = e(this.focusable.not(t).get()), this.hoverable = e(this.hoverable.not(t).get())
                            },
                            _delay: function(e, t) {
                                function n() {
                                    return ("string" == typeof e ? i[e] : e).apply(i, arguments)
                                }
                                var i = this;
                                return setTimeout(n, t || 0)
                            },
                            _hoverable: function(t) {
                                this.hoverable = this.hoverable.add(t), this._on(t, {
                                    mouseenter: function(t) {
                                        this._addClass(e(t.currentTarget), null, "ui-state-hover")
                                    },
                                    mouseleave: function(t) {
                                        this._removeClass(e(t.currentTarget), null, "ui-state-hover")
                                    }
                                })
                            },
                            _focusable: function(t) {
                                this.focusable = this.focusable.add(t), this._on(t, {
                                    focusin: function(t) {
                                        this._addClass(e(t.currentTarget), null, "ui-state-focus")
                                    },
                                    focusout: function(t) {
                                        this._removeClass(e(t.currentTarget), null, "ui-state-focus")
                                    }
                                })
                            },
                            _trigger: function(t, n, i) {
                                var s, a, o = this.options[t];
                                if (i = i || {}, (n = e.Event(n)).type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), n.target = this.element[0], a = n.originalEvent)
                                    for (s in a) s in n || (n[s] = a[s]);
                                return this.element.trigger(n, i), !("function" == typeof o && !1 === o.apply(this.element[0], [n].concat(i)) || n.isDefaultPrevented())
                            }
                        }, e.each({
                            show: "fadeIn",
                            hide: "fadeOut"
                        }, (function(t, n) {
                            e.Widget.prototype["_" + t] = function(i, s, a) {
                                var o;
                                "string" == typeof s && (s = {
                                    effect: s
                                });
                                var r = s ? !0 === s || "number" == typeof s ? n : s.effect || n : t;
                                "number" == typeof(s = s || {}) ? s = {
                                    duration: s
                                }: !0 === s && (s = {}), o = !e.isEmptyObject(s), s.complete = a, s.delay && i.delay(s.delay), o && e.effects && e.effects.effect[r] ? i[t](s) : r !== t && i[r] ? i[r](s.duration, s.easing, a) : i.queue((function(n) {
                                    e(this)[t](), a && a.call(i[0]), n()
                                }))
                            }
                        })), e.widget
                    }, void 0 === (a = "function" == typeof i ? i.apply(t, s) : i) || (e.exports = a)
                }()
            },
            62418: (e, t, n) => {
                "use strict";
                var i, s;
                i = [n(13617), n(3), n(66675)], void 0 === (s = function(e, t, n) {
                    return function(e, t, n) {
                        var i = function(t, n) {
                            return e.js_beautify(t, n)
                        };
                        return i.js = e.js_beautify, i.css = t.css_beautify, i.html = n.html_beautify, i.js_beautify = e.js_beautify, i.css_beautify = t.css_beautify, i.html_beautify = n.html_beautify, i
                    }(e, t, n)
                }.apply(t, i)) || (e.exports = s)
            },
            3: (e, t) => {
                var n;
                ! function() {
                    var i;
                    ! function() {
                        "use strict";
                        var e = [, , function(e) {
                                function t(e) {
                                    this.__parent = e, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = []
                                }

                                function n(e, t) {
                                    this.__cache = [""], this.__indent_size = e.indent_size, this.__indent_string = e.indent_char, e.indent_with_tabs || (this.__indent_string = new Array(e.indent_size + 1).join(e.indent_char)), t = t || "", e.indent_level > 0 && (t = new Array(e.indent_level + 1).join(this.__indent_string)), this.__base_string = t, this.__base_string_length = t.length
                                }

                                function i(e, i) {
                                    this.__indent_cache = new n(e, i), this.raw = !1, this._end_with_newline = e.end_with_newline, this.indent_size = e.indent_size, this.wrap_line_length = e.wrap_line_length, this.indent_empty_lines = e.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new t(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline()
                                }
                                t.prototype.clone_empty = function() {
                                    var e = new t(this.__parent);
                                    return e.set_indent(this.__indent_count, this.__alignment_count), e
                                }, t.prototype.item = function(e) {
                                    return e < 0 ? this.__items[this.__items.length + e] : this.__items[e]
                                }, t.prototype.has_match = function(e) {
                                    for (var t = this.__items.length - 1; t >= 0; t--)
                                        if (this.__items[t].match(e)) return !0;
                                    return !1
                                }, t.prototype.set_indent = function(e, t) {
                                    this.is_empty() && (this.__indent_count = e || 0, this.__alignment_count = t || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count))
                                }, t.prototype._set_wrap_point = function() {
                                    this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count)
                                }, t.prototype._should_wrap = function() {
                                    return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count
                                }, t.prototype._allow_wrap = function() {
                                    if (this._should_wrap()) {
                                        this.__parent.add_new_line();
                                        var e = this.__parent.current_line;
                                        return e.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), e.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), e.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, " " === e.__items[0] && (e.__items.splice(0, 1), e.__character_count -= 1), !0
                                    }
                                    return !1
                                }, t.prototype.is_empty = function() {
                                    return 0 === this.__items.length
                                }, t.prototype.last = function() {
                                    return this.is_empty() ? null : this.__items[this.__items.length - 1]
                                }, t.prototype.push = function(e) {
                                    this.__items.push(e);
                                    var t = e.lastIndexOf("\n"); - 1 !== t ? this.__character_count = e.length - t : this.__character_count += e.length
                                }, t.prototype.pop = function() {
                                    var e = null;
                                    return this.is_empty() || (e = this.__items.pop(), this.__character_count -= e.length), e
                                }, t.prototype._remove_indent = function() {
                                    this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size)
                                }, t.prototype._remove_wrap_indent = function() {
                                    this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1)
                                }, t.prototype.trim = function() {
                                    for (;
                                        " " === this.last();) this.__items.pop(), this.__character_count -= 1
                                }, t.prototype.toString = function() {
                                    var e = "";
                                    return this.is_empty() ? this.__parent.indent_empty_lines && (e = this.__parent.get_indent_string(this.__indent_count)) : (e = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), e += this.__items.join("")), e
                                }, n.prototype.get_indent_size = function(e, t) {
                                    var n = this.__base_string_length;
                                    return t = t || 0, e < 0 && (n = 0), n += e * this.__indent_size, n += t
                                }, n.prototype.get_indent_string = function(e, t) {
                                    var n = this.__base_string;
                                    return t = t || 0, e < 0 && (e = 0, n = ""), t += e * this.__indent_size, this.__ensure_cache(t), n += this.__cache[t]
                                }, n.prototype.__ensure_cache = function(e) {
                                    for (; e >= this.__cache.length;) this.__add_column()
                                }, n.prototype.__add_column = function() {
                                    var e = this.__cache.length,
                                        t = 0,
                                        n = "";
                                    this.__indent_size && e >= this.__indent_size && (e -= (t = Math.floor(e / this.__indent_size)) * this.__indent_size, n = new Array(t + 1).join(this.__indent_string)), e && (n += new Array(e + 1).join(" ")), this.__cache.push(n)
                                }, i.prototype.__add_outputline = function() {
                                    this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line)
                                }, i.prototype.get_line_number = function() {
                                    return this.__lines.length
                                }, i.prototype.get_indent_string = function(e, t) {
                                    return this.__indent_cache.get_indent_string(e, t)
                                }, i.prototype.get_indent_size = function(e, t) {
                                    return this.__indent_cache.get_indent_size(e, t)
                                }, i.prototype.is_empty = function() {
                                    return !this.previous_line && this.current_line.is_empty()
                                }, i.prototype.add_new_line = function(e) {
                                    return !(this.is_empty() || !e && this.just_added_newline()) && (this.raw || this.__add_outputline(), !0)
                                }, i.prototype.get_code = function(e) {
                                    this.trim(!0);
                                    var t = this.current_line.pop();
                                    t && ("\n" === t[t.length - 1] && (t = t.replace(/\n+$/g, "")), this.current_line.push(t)), this._end_with_newline && this.__add_outputline();
                                    var n = this.__lines.join("\n");
                                    return "\n" !== e && (n = n.replace(/[\n]/g, e)), n
                                }, i.prototype.set_wrap_point = function() {
                                    this.current_line._set_wrap_point()
                                }, i.prototype.set_indent = function(e, t) {
                                    return e = e || 0, t = t || 0, this.next_line.set_indent(e, t), this.__lines.length > 1 ? (this.current_line.set_indent(e, t), !0) : (this.current_line.set_indent(), !1)
                                }, i.prototype.add_raw_token = function(e) {
                                    for (var t = 0; t < e.newlines; t++) this.__add_outputline();
                                    this.current_line.set_indent(-1), this.current_line.push(e.whitespace_before), this.current_line.push(e.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1
                                }, i.prototype.add_token = function(e) {
                                    this.__add_space_before_token(), this.current_line.push(e), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap()
                                }, i.prototype.__add_space_before_token = function() {
                                    this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "))
                                }, i.prototype.remove_indent = function(e) {
                                    for (var t = this.__lines.length; e < t;) this.__lines[e]._remove_indent(), e++;
                                    this.current_line._remove_wrap_indent()
                                }, i.prototype.trim = function(e) {
                                    for (e = void 0 !== e && e, this.current_line.trim(); e && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
                                    this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null
                                }, i.prototype.just_added_newline = function() {
                                    return this.current_line.is_empty()
                                }, i.prototype.just_added_blankline = function() {
                                    return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty()
                                }, i.prototype.ensure_empty_line_above = function(e, n) {
                                    for (var i = this.__lines.length - 2; i >= 0;) {
                                        var s = this.__lines[i];
                                        if (s.is_empty()) break;
                                        if (0 !== s.item(0).indexOf(e) && s.item(-1) !== n) {
                                            this.__lines.splice(i + 1, 0, new t(this)), this.previous_line = this.__lines[this.__lines.length - 2];
                                            break
                                        }
                                        i--
                                    }
                                }, e.exports.Output = i
                            }, , , , function(e) {
                                function t(e, t) {
                                    this.raw_options = n(e, t), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", "\t" === this.indent_char), this.indent_with_tabs && (this.indent_char = "\t", 1 === this.indent_size && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", ["auto", "none", "angular", "django", "erb", "handlebars", "php", "smarty"], ["auto"])
                                }

                                function n(e, t) {
                                    var n, s = {};
                                    for (n in e = i(e)) n !== t && (s[n] = e[n]);
                                    if (t && e[t])
                                        for (n in e[t]) s[n] = e[t][n];
                                    return s
                                }

                                function i(e) {
                                    var t, n = {};
                                    for (t in e) {
                                        n[t.replace(/-/g, "_")] = e[t]
                                    }
                                    return n
                                }
                                t.prototype._get_array = function(e, t) {
                                    var n = this.raw_options[e],
                                        i = t || [];
                                    return "object" == typeof n ? null !== n && "function" == typeof n.concat && (i = n.concat()) : "string" == typeof n && (i = n.split(/[^a-zA-Z0-9_\/\-]+/)), i
                                }, t.prototype._get_boolean = function(e, t) {
                                    var n = this.raw_options[e];
                                    return void 0 === n ? !!t : !!n
                                }, t.prototype._get_characters = function(e, t) {
                                    var n = this.raw_options[e],
                                        i = t || "";
                                    return "string" == typeof n && (i = n.replace(/\\r/, "\r").replace(/\\n/, "\n").replace(/\\t/, "\t")), i
                                }, t.prototype._get_number = function(e, t) {
                                    var n = this.raw_options[e];
                                    t = parseInt(t, 10), isNaN(t) && (t = 0);
                                    var i = parseInt(n, 10);
                                    return isNaN(i) && (i = t), i
                                }, t.prototype._get_selection = function(e, t, n) {
                                    var i = this._get_selection_list(e, t, n);
                                    if (1 !== i.length) throw new Error("Invalid Option Value: The option '" + e + "' can only be one of the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
                                    return i[0]
                                }, t.prototype._get_selection_list = function(e, t, n) {
                                    if (!t || 0 === t.length) throw new Error("Selection list cannot be empty.");
                                    if (n = n || [t[0]], !this._is_valid_selection(n, t)) throw new Error("Invalid Default Value!");
                                    var i = this._get_array(e, n);
                                    if (!this._is_valid_selection(i, t)) throw new Error("Invalid Option Value: The option '" + e + "' can contain only the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
                                    return i
                                }, t.prototype._is_valid_selection = function(e, t) {
                                    return e.length && t.length && !e.some((function(e) {
                                        return -1 === t.indexOf(e)
                                    }))
                                }, e.exports.Options = t, e.exports.normalizeOpts = i, e.exports.mergeOpts = n
                            }, , function(e) {
                                var t = RegExp.prototype.hasOwnProperty("sticky");

                                function n(e) {
                                    this.__input = e || "", this.__input_length = this.__input.length, this.__position = 0
                                }
                                n.prototype.restart = function() {
                                    this.__position = 0
                                }, n.prototype.back = function() {
                                    this.__position > 0 && (this.__position -= 1)
                                }, n.prototype.hasNext = function() {
                                    return this.__position < this.__input_length
                                }, n.prototype.next = function() {
                                    var e = null;
                                    return this.hasNext() && (e = this.__input.charAt(this.__position), this.__position += 1), e
                                }, n.prototype.peek = function(e) {
                                    var t = null;
                                    return e = e || 0, (e += this.__position) >= 0 && e < this.__input_length && (t = this.__input.charAt(e)), t
                                }, n.prototype.__match = function(e, n) {
                                    e.lastIndex = n;
                                    var i = e.exec(this.__input);
                                    return !i || t && e.sticky || i.index !== n && (i = null), i
                                }, n.prototype.test = function(e, t) {
                                    return t = t || 0, (t += this.__position) >= 0 && t < this.__input_length && !!this.__match(e, t)
                                }, n.prototype.testChar = function(e, t) {
                                    var n = this.peek(t);
                                    return e.lastIndex = 0, null !== n && e.test(n)
                                }, n.prototype.match = function(e) {
                                    var t = this.__match(e, this.__position);
                                    return t ? this.__position += t[0].length : t = null, t
                                }, n.prototype.read = function(e, t, n) {
                                    var i, s = "";
                                    return e && (i = this.match(e)) && (s += i[0]), !t || !i && e || (s += this.readUntil(t, n)), s
                                }, n.prototype.readUntil = function(e, t) {
                                    var n, i = this.__position;
                                    e.lastIndex = this.__position;
                                    var s = e.exec(this.__input);
                                    return s ? (i = s.index, t && (i += s[0].length)) : i = this.__input_length, n = this.__input.substring(this.__position, i), this.__position = i, n
                                }, n.prototype.readUntilAfter = function(e) {
                                    return this.readUntil(e, !0)
                                }, n.prototype.get_regexp = function(e, n) {
                                    var i = null,
                                        s = "g";
                                    return n && t && (s = "y"), "string" == typeof e && "" !== e ? i = new RegExp(e, s) : e && (i = new RegExp(e.source, s)), i
                                }, n.prototype.get_literal_regexp = function(e) {
                                    return RegExp(e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
                                }, n.prototype.peekUntilAfter = function(e) {
                                    var t = this.__position,
                                        n = this.readUntilAfter(e);
                                    return this.__position = t, n
                                }, n.prototype.lookBack = function(e) {
                                    var t = this.__position - 1;
                                    return t >= e.length && this.__input.substring(t - e.length, t).toLowerCase() === e
                                }, e.exports.InputScanner = n
                            }, , , , , function(e) {
                                function t(e, t) {
                                    e = "string" == typeof e ? e : e.source, t = "string" == typeof t ? t : t.source, this.__directives_block_pattern = new RegExp(e + / beautify( \w+[:]\w+)+ /.source + t, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(e + /\sbeautify\signore:end\s/.source + t, "g")
                                }
                                t.prototype.get_directives = function(e) {
                                    if (!e.match(this.__directives_block_pattern)) return null;
                                    var t = {};
                                    this.__directive_pattern.lastIndex = 0;
                                    for (var n = this.__directive_pattern.exec(e); n;) t[n[1]] = n[2], n = this.__directive_pattern.exec(e);
                                    return t
                                }, t.prototype.readIgnored = function(e) {
                                    return e.readUntilAfter(this.__directives_end_ignore_pattern)
                                }, e.exports.Directives = t
                            }, , function(e, t, n) {
                                var i = n(16).Beautifier,
                                    s = n(17).Options;
                                e.exports = function(e, t) {
                                    return new i(e, t).beautify()
                                }, e.exports.defaultOptions = function() {
                                    return new s
                                }
                            }, function(e, t, n) {
                                var i = n(17).Options,
                                    s = n(2).Output,
                                    a = n(8).InputScanner,
                                    o = new(0, n(13).Directives)(/\/\*/, /\*\//),
                                    r = /\r\n|[\r\n]/,
                                    c = /\r\n|[\r\n]/g,
                                    l = /\s/,
                                    u = /(?:\s|\n)+/g,
                                    d = /\/\*(?:[\s\S]*?)((?:\*\/)|$)/g,
                                    h = /\/\/(?:[^\n\r\u2028\u2029]*)/g;

                                function _(e, t) {
                                    this._source_text = e || "", this._options = new i(t), this._ch = null, this._input = null, this.NESTED_AT_RULE = {
                                        page: !0,
                                        "font-face": !0,
                                        keyframes: !0,
                                        media: !0,
                                        supports: !0,
                                        document: !0
                                    }, this.CONDITIONAL_GROUP_RULE = {
                                        media: !0,
                                        supports: !0,
                                        document: !0
                                    }, this.NON_SEMICOLON_NEWLINE_PROPERTY = ["grid-template-areas", "grid-template"]
                                }
                                _.prototype.eatString = function(e) {
                                    var t = "";
                                    for (this._ch = this._input.next(); this._ch;) {
                                        if (t += this._ch, "\\" === this._ch) t += this._input.next();
                                        else if (-1 !== e.indexOf(this._ch) || "\n" === this._ch) break;
                                        this._ch = this._input.next()
                                    }
                                    return t
                                }, _.prototype.eatWhitespace = function(e) {
                                    for (var t = l.test(this._input.peek()), n = 0; l.test(this._input.peek());) this._ch = this._input.next(), e && "\n" === this._ch && (0 === n || n < this._options.max_preserve_newlines) && (n++, this._output.add_new_line(!0));
                                    return t
                                }, _.prototype.foundNestedPseudoClass = function() {
                                    for (var e = 0, t = 1, n = this._input.peek(t); n;) {
                                        if ("{" === n) return !0;
                                        if ("(" === n) e += 1;
                                        else if (")" === n) {
                                            if (0 === e) return !1;
                                            e -= 1
                                        } else if (";" === n || "}" === n) return !1;
                                        t++, n = this._input.peek(t)
                                    }
                                    return !1
                                }, _.prototype.print_string = function(e) {
                                    this._output.set_indent(this._indentLevel), this._output.non_breaking_space = !0, this._output.add_token(e)
                                }, _.prototype.preserveSingleSpace = function(e) {
                                    e && (this._output.space_before_token = !0)
                                }, _.prototype.indent = function() {
                                    this._indentLevel++
                                }, _.prototype.outdent = function() {
                                    this._indentLevel > 0 && this._indentLevel--
                                }, _.prototype.beautify = function() {
                                    if (this._options.disabled) return this._source_text;
                                    var e = this._source_text,
                                        t = this._options.eol;
                                    "auto" === t && (t = "\n", e && r.test(e || "") && (t = e.match(r)[0]));
                                    var n = (e = e.replace(c, "\n")).match(/^[\t ]*/)[0];
                                    this._output = new s(this._options, n), this._input = new a(e), this._indentLevel = 0, this._nestedLevel = 0, this._ch = null;
                                    for (var i, _, p = 0, f = !1, g = !1, m = !1, v = !1, w = !1, b = this._ch, k = !1; i = "" !== this._input.read(u), _ = b, this._ch = this._input.next(), "\\" === this._ch && this._input.hasNext() && (this._ch += this._input.next()), b = this._ch, this._ch;)
                                        if ("/" === this._ch && "*" === this._input.peek()) {
                                            this._output.add_new_line(), this._input.back();
                                            var y = this._input.read(d),
                                                x = o.get_directives(y);
                                            x && "start" === x.ignore && (y += o.readIgnored(this._input)), this.print_string(y), this.eatWhitespace(!0), this._output.add_new_line()
                                        } else if ("/" === this._ch && "/" === this._input.peek()) this._output.space_before_token = !0, this._input.back(), this.print_string(this._input.read(h)), this.eatWhitespace(!0);
                                    else if ("$" === this._ch) {
                                        this.preserveSingleSpace(i), this.print_string(this._ch);
                                        var S = this._input.peekUntilAfter(/[: ,;{}()[\]\/='"]/g);
                                        S.match(/[ :]$/) && (S = this.eatString(": ").replace(/\s+$/, ""), this.print_string(S), this._output.space_before_token = !0), 0 === p && -1 !== S.indexOf(":") && (g = !0, this.indent())
                                    } else if ("@" === this._ch)
                                        if (this.preserveSingleSpace(i), "{" === this._input.peek()) this.print_string(this._ch + this.eatString("}"));
                                        else {
                                            this.print_string(this._ch);
                                            var E = this._input.peekUntilAfter(/[: ,;{}()[\]\/='"]/g);
                                            E.match(/[ :]$/) && (E = this.eatString(": ").replace(/\s+$/, ""), this.print_string(E), this._output.space_before_token = !0), 0 === p && -1 !== E.indexOf(":") ? (g = !0, this.indent()) : E in this.NESTED_AT_RULE ? (this._nestedLevel += 1, E in this.CONDITIONAL_GROUP_RULE && (m = !0)) : 0 !== p || g || (v = !0)
                                        }
                                    else if ("#" === this._ch && "{" === this._input.peek()) this.preserveSingleSpace(i), this.print_string(this._ch + this.eatString("}"));
                                    else if ("{" === this._ch) g && (g = !1, this.outdent()), v = !1, m ? (m = !1, f = this._indentLevel >= this._nestedLevel) : f = this._indentLevel >= this._nestedLevel - 1, this._options.newline_between_rules && f && this._output.previous_line && "{" !== this._output.previous_line.item(-1) && this._output.ensure_empty_line_above("/", ","), this._output.space_before_token = !0, "expand" === this._options.brace_style ? (this._output.add_new_line(), this.print_string(this._ch), this.indent(), this._output.set_indent(this._indentLevel)) : ("(" === _ ? this._output.space_before_token = !1 : "," !== _ && this.indent(), this.print_string(this._ch)), this.eatWhitespace(!0), this._output.add_new_line();
                                    else if ("}" === this._ch) this.outdent(), this._output.add_new_line(), "{" === _ && this._output.trim(!0), g && (this.outdent(), g = !1), this.print_string(this._ch), f = !1, this._nestedLevel && this._nestedLevel--, this.eatWhitespace(!0), this._output.add_new_line(), this._options.newline_between_rules && !this._output.just_added_blankline() && "}" !== this._input.peek() && this._output.add_new_line(!0), ")" === this._input.peek() && (this._output.trim(!0), "expand" === this._options.brace_style && this._output.add_new_line(!0));
                                    else if (":" === this._ch) {
                                        for (var C = 0; C < this.NON_SEMICOLON_NEWLINE_PROPERTY.length; C++)
                                            if (this._input.lookBack(this.NON_SEMICOLON_NEWLINE_PROPERTY[C])) {
                                                k = !0;
                                                break
                                            }!f && !m || this._input.lookBack("&") || this.foundNestedPseudoClass() || this._input.lookBack("(") || v || 0 !== p ? (this._input.lookBack(" ") && (this._output.space_before_token = !0), ":" === this._input.peek() ? (this._ch = this._input.next(), this.print_string("::")) : this.print_string(":")) : (this.print_string(":"), g || (g = !0, this._output.space_before_token = !0, this.eatWhitespace(!0), this.indent()))
                                    } else if ('"' === this._ch || "'" === this._ch) {
                                        var T = '"' === _ || "'" === _;
                                        this.preserveSingleSpace(T || i), this.print_string(this._ch + this.eatString(this._ch)), this.eatWhitespace(!0)
                                    } else if (";" === this._ch) k = !1, 0 === p ? (g && (this.outdent(), g = !1), v = !1, this.print_string(this._ch), this.eatWhitespace(!0), "/" !== this._input.peek() && this._output.add_new_line()) : (this.print_string(this._ch), this.eatWhitespace(!0), this._output.space_before_token = !0);
                                    else if ("(" === this._ch)
                                        if (this._input.lookBack("url")) this.print_string(this._ch), this.eatWhitespace(), p++, this.indent(), this._ch = this._input.next(), ")" === this._ch || '"' === this._ch || "'" === this._ch ? this._input.back() : this._ch && (this.print_string(this._ch + this.eatString(")")), p && (p--, this.outdent()));
                                        else {
                                            var O = !1;
                                            this._input.lookBack("with") && (O = !0), this.preserveSingleSpace(i || O), this.print_string(this._ch), g && "$" === _ && this._options.selector_separator_newline ? (this._output.add_new_line(), w = !0) : (this.eatWhitespace(), p++, this.indent())
                                        }
                                    else if (")" === this._ch) p && (p--, this.outdent()), w && ";" === this._input.peek() && this._options.selector_separator_newline && (w = !1, this.outdent(), this._output.add_new_line()), this.print_string(this._ch);
                                    else if ("," === this._ch) this.print_string(this._ch), this.eatWhitespace(!0), !this._options.selector_separator_newline || g && !w || 0 !== p || v ? this._output.space_before_token = !0 : this._output.add_new_line();
                                    else if (">" !== this._ch && "+" !== this._ch && "~" !== this._ch || g || 0 !== p)
                                        if ("]" === this._ch) this.print_string(this._ch);
                                        else if ("[" === this._ch) this.preserveSingleSpace(i), this.print_string(this._ch);
                                    else if ("=" === this._ch) this.eatWhitespace(), this.print_string("="), l.test(this._ch) && (this._ch = "");
                                    else if ("!" !== this._ch || this._input.lookBack("\\")) {
                                        var $ = '"' === _ || "'" === _;
                                        this.preserveSingleSpace($ || i), this.print_string(this._ch), !this._output.just_added_newline() && "\n" === this._input.peek() && k && this._output.add_new_line()
                                    } else this._output.space_before_token = !0, this.print_string(this._ch);
                                    else this._options.space_around_combinator ? (this._output.space_before_token = !0, this.print_string(this._ch), this._output.space_before_token = !0) : (this.print_string(this._ch), this.eatWhitespace(), this._ch && l.test(this._ch) && (this._ch = ""));
                                    return this._output.get_code(t)
                                }, e.exports.Beautifier = _
                            }, function(e, t, n) {
                                var i = n(6).Options;

                                function s(e) {
                                    i.call(this, e, "css"), this.selector_separator_newline = this._get_boolean("selector_separator_newline", !0), this.newline_between_rules = this._get_boolean("newline_between_rules", !0);
                                    var t = this._get_boolean("space_around_selector_separator");
                                    this.space_around_combinator = this._get_boolean("space_around_combinator") || t;
                                    var n = this._get_selection_list("brace_style", ["collapse", "expand", "end-expand", "none", "preserve-inline"]);
                                    this.brace_style = "collapse";
                                    for (var s = 0; s < n.length; s++) "expand" !== n[s] ? this.brace_style = "collapse" : this.brace_style = n[s]
                                }
                                s.prototype = new i, e.exports.Options = s
                            }],
                            t = {};
                        var n = function n(i) {
                            var s = t[i];
                            if (void 0 !== s) return s.exports;
                            var a = t[i] = {
                                exports: {}
                            };
                            return e[i](a, a.exports, n), a.exports
                        }(15);
                        i = n
                    }();
                    var s = i;
                    void 0 === (n = function() {
                        return {
                            css_beautify: s
                        }
                    }.apply(t, [])) || (e.exports = n)
                }()
            },
            66675: (e, t, n) => {
                var i, s;
                ! function() {
                    var a;
                    ! function() {
                        "use strict";
                        var e = [, , function(e) {
                                function t(e) {
                                    this.__parent = e, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = []
                                }

                                function n(e, t) {
                                    this.__cache = [""], this.__indent_size = e.indent_size, this.__indent_string = e.indent_char, e.indent_with_tabs || (this.__indent_string = new Array(e.indent_size + 1).join(e.indent_char)), t = t || "", e.indent_level > 0 && (t = new Array(e.indent_level + 1).join(this.__indent_string)), this.__base_string = t, this.__base_string_length = t.length
                                }

                                function i(e, i) {
                                    this.__indent_cache = new n(e, i), this.raw = !1, this._end_with_newline = e.end_with_newline, this.indent_size = e.indent_size, this.wrap_line_length = e.wrap_line_length, this.indent_empty_lines = e.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new t(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline()
                                }
                                t.prototype.clone_empty = function() {
                                    var e = new t(this.__parent);
                                    return e.set_indent(this.__indent_count, this.__alignment_count), e
                                }, t.prototype.item = function(e) {
                                    return e < 0 ? this.__items[this.__items.length + e] : this.__items[e]
                                }, t.prototype.has_match = function(e) {
                                    for (var t = this.__items.length - 1; t >= 0; t--)
                                        if (this.__items[t].match(e)) return !0;
                                    return !1
                                }, t.prototype.set_indent = function(e, t) {
                                    this.is_empty() && (this.__indent_count = e || 0, this.__alignment_count = t || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count))
                                }, t.prototype._set_wrap_point = function() {
                                    this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count)
                                }, t.prototype._should_wrap = function() {
                                    return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count
                                }, t.prototype._allow_wrap = function() {
                                    if (this._should_wrap()) {
                                        this.__parent.add_new_line();
                                        var e = this.__parent.current_line;
                                        return e.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), e.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), e.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, " " === e.__items[0] && (e.__items.splice(0, 1), e.__character_count -= 1), !0
                                    }
                                    return !1
                                }, t.prototype.is_empty = function() {
                                    return 0 === this.__items.length
                                }, t.prototype.last = function() {
                                    return this.is_empty() ? null : this.__items[this.__items.length - 1]
                                }, t.prototype.push = function(e) {
                                    this.__items.push(e);
                                    var t = e.lastIndexOf("\n"); - 1 !== t ? this.__character_count = e.length - t : this.__character_count += e.length
                                }, t.prototype.pop = function() {
                                    var e = null;
                                    return this.is_empty() || (e = this.__items.pop(), this.__character_count -= e.length), e
                                }, t.prototype._remove_indent = function() {
                                    this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size)
                                }, t.prototype._remove_wrap_indent = function() {
                                    this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1)
                                }, t.prototype.trim = function() {
                                    for (;
                                        " " === this.last();) this.__items.pop(), this.__character_count -= 1
                                }, t.prototype.toString = function() {
                                    var e = "";
                                    return this.is_empty() ? this.__parent.indent_empty_lines && (e = this.__parent.get_indent_string(this.__indent_count)) : (e = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), e += this.__items.join("")), e
                                }, n.prototype.get_indent_size = function(e, t) {
                                    var n = this.__base_string_length;
                                    return t = t || 0, e < 0 && (n = 0), n += e * this.__indent_size, n += t
                                }, n.prototype.get_indent_string = function(e, t) {
                                    var n = this.__base_string;
                                    return t = t || 0, e < 0 && (e = 0, n = ""), t += e * this.__indent_size, this.__ensure_cache(t), n += this.__cache[t]
                                }, n.prototype.__ensure_cache = function(e) {
                                    for (; e >= this.__cache.length;) this.__add_column()
                                }, n.prototype.__add_column = function() {
                                    var e = this.__cache.length,
                                        t = 0,
                                        n = "";
                                    this.__indent_size && e >= this.__indent_size && (e -= (t = Math.floor(e / this.__indent_size)) * this.__indent_size, n = new Array(t + 1).join(this.__indent_string)), e && (n += new Array(e + 1).join(" ")), this.__cache.push(n)
                                }, i.prototype.__add_outputline = function() {
                                    this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line)
                                }, i.prototype.get_line_number = function() {
                                    return this.__lines.length
                                }, i.prototype.get_indent_string = function(e, t) {
                                    return this.__indent_cache.get_indent_string(e, t)
                                }, i.prototype.get_indent_size = function(e, t) {
                                    return this.__indent_cache.get_indent_size(e, t)
                                }, i.prototype.is_empty = function() {
                                    return !this.previous_line && this.current_line.is_empty()
                                }, i.prototype.add_new_line = function(e) {
                                    return !(this.is_empty() || !e && this.just_added_newline()) && (this.raw || this.__add_outputline(), !0)
                                }, i.prototype.get_code = function(e) {
                                    this.trim(!0);
                                    var t = this.current_line.pop();
                                    t && ("\n" === t[t.length - 1] && (t = t.replace(/\n+$/g, "")), this.current_line.push(t)), this._end_with_newline && this.__add_outputline();
                                    var n = this.__lines.join("\n");
                                    return "\n" !== e && (n = n.replace(/[\n]/g, e)), n
                                }, i.prototype.set_wrap_point = function() {
                                    this.current_line._set_wrap_point()
                                }, i.prototype.set_indent = function(e, t) {
                                    return e = e || 0, t = t || 0, this.next_line.set_indent(e, t), this.__lines.length > 1 ? (this.current_line.set_indent(e, t), !0) : (this.current_line.set_indent(), !1)
                                }, i.prototype.add_raw_token = function(e) {
                                    for (var t = 0; t < e.newlines; t++) this.__add_outputline();
                                    this.current_line.set_indent(-1), this.current_line.push(e.whitespace_before), this.current_line.push(e.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1
                                }, i.prototype.add_token = function(e) {
                                    this.__add_space_before_token(), this.current_line.push(e), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap()
                                }, i.prototype.__add_space_before_token = function() {
                                    this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "))
                                }, i.prototype.remove_indent = function(e) {
                                    for (var t = this.__lines.length; e < t;) this.__lines[e]._remove_indent(), e++;
                                    this.current_line._remove_wrap_indent()
                                }, i.prototype.trim = function(e) {
                                    for (e = void 0 !== e && e, this.current_line.trim(); e && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
                                    this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null
                                }, i.prototype.just_added_newline = function() {
                                    return this.current_line.is_empty()
                                }, i.prototype.just_added_blankline = function() {
                                    return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty()
                                }, i.prototype.ensure_empty_line_above = function(e, n) {
                                    for (var i = this.__lines.length - 2; i >= 0;) {
                                        var s = this.__lines[i];
                                        if (s.is_empty()) break;
                                        if (0 !== s.item(0).indexOf(e) && s.item(-1) !== n) {
                                            this.__lines.splice(i + 1, 0, new t(this)), this.previous_line = this.__lines[this.__lines.length - 2];
                                            break
                                        }
                                        i--
                                    }
                                }, e.exports.Output = i
                            }, function(e) {
                                e.exports.Token = function(e, t, n, i) {
                                    this.type = e, this.text = t, this.comments_before = null, this.newlines = n || 0, this.whitespace_before = i || "", this.parent = null, this.next = null, this.previous = null, this.opened = null, this.closed = null, this.directives = null
                                }
                            }, , , function(e) {
                                function t(e, t) {
                                    this.raw_options = n(e, t), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", "\t" === this.indent_char), this.indent_with_tabs && (this.indent_char = "\t", 1 === this.indent_size && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", ["auto", "none", "angular", "django", "erb", "handlebars", "php", "smarty"], ["auto"])
                                }

                                function n(e, t) {
                                    var n, s = {};
                                    for (n in e = i(e)) n !== t && (s[n] = e[n]);
                                    if (t && e[t])
                                        for (n in e[t]) s[n] = e[t][n];
                                    return s
                                }

                                function i(e) {
                                    var t, n = {};
                                    for (t in e) {
                                        n[t.replace(/-/g, "_")] = e[t]
                                    }
                                    return n
                                }
                                t.prototype._get_array = function(e, t) {
                                    var n = this.raw_options[e],
                                        i = t || [];
                                    return "object" == typeof n ? null !== n && "function" == typeof n.concat && (i = n.concat()) : "string" == typeof n && (i = n.split(/[^a-zA-Z0-9_\/\-]+/)), i
                                }, t.prototype._get_boolean = function(e, t) {
                                    var n = this.raw_options[e];
                                    return void 0 === n ? !!t : !!n
                                }, t.prototype._get_characters = function(e, t) {
                                    var n = this.raw_options[e],
                                        i = t || "";
                                    return "string" == typeof n && (i = n.replace(/\\r/, "\r").replace(/\\n/, "\n").replace(/\\t/, "\t")), i
                                }, t.prototype._get_number = function(e, t) {
                                    var n = this.raw_options[e];
                                    t = parseInt(t, 10), isNaN(t) && (t = 0);
                                    var i = parseInt(n, 10);
                                    return isNaN(i) && (i = t), i
                                }, t.prototype._get_selection = function(e, t, n) {
                                    var i = this._get_selection_list(e, t, n);
                                    if (1 !== i.length) throw new Error("Invalid Option Value: The option '" + e + "' can only be one of the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
                                    return i[0]
                                }, t.prototype._get_selection_list = function(e, t, n) {
                                    if (!t || 0 === t.length) throw new Error("Selection list cannot be empty.");
                                    if (n = n || [t[0]], !this._is_valid_selection(n, t)) throw new Error("Invalid Default Value!");
                                    var i = this._get_array(e, n);
                                    if (!this._is_valid_selection(i, t)) throw new Error("Invalid Option Value: The option '" + e + "' can contain only the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
                                    return i
                                }, t.prototype._is_valid_selection = function(e, t) {
                                    return e.length && t.length && !e.some((function(e) {
                                        return -1 === t.indexOf(e)
                                    }))
                                }, e.exports.Options = t, e.exports.normalizeOpts = i, e.exports.mergeOpts = n
                            }, , function(e) {
                                var t = RegExp.prototype.hasOwnProperty("sticky");

                                function n(e) {
                                    this.__input = e || "", this.__input_length = this.__input.length, this.__position = 0
                                }
                                n.prototype.restart = function() {
                                    this.__position = 0
                                }, n.prototype.back = function() {
                                    this.__position > 0 && (this.__position -= 1)
                                }, n.prototype.hasNext = function() {
                                    return this.__position < this.__input_length
                                }, n.prototype.next = function() {
                                    var e = null;
                                    return this.hasNext() && (e = this.__input.charAt(this.__position), this.__position += 1), e
                                }, n.prototype.peek = function(e) {
                                    var t = null;
                                    return e = e || 0, (e += this.__position) >= 0 && e < this.__input_length && (t = this.__input.charAt(e)), t
                                }, n.prototype.__match = function(e, n) {
                                    e.lastIndex = n;
                                    var i = e.exec(this.__input);
                                    return !i || t && e.sticky || i.index !== n && (i = null), i
                                }, n.prototype.test = function(e, t) {
                                    return t = t || 0, (t += this.__position) >= 0 && t < this.__input_length && !!this.__match(e, t)
                                }, n.prototype.testChar = function(e, t) {
                                    var n = this.peek(t);
                                    return e.lastIndex = 0, null !== n && e.test(n)
                                }, n.prototype.match = function(e) {
                                    var t = this.__match(e, this.__position);
                                    return t ? this.__position += t[0].length : t = null, t
                                }, n.prototype.read = function(e, t, n) {
                                    var i, s = "";
                                    return e && (i = this.match(e)) && (s += i[0]), !t || !i && e || (s += this.readUntil(t, n)), s
                                }, n.prototype.readUntil = function(e, t) {
                                    var n, i = this.__position;
                                    e.lastIndex = this.__position;
                                    var s = e.exec(this.__input);
                                    return s ? (i = s.index, t && (i += s[0].length)) : i = this.__input_length, n = this.__input.substring(this.__position, i), this.__position = i, n
                                }, n.prototype.readUntilAfter = function(e) {
                                    return this.readUntil(e, !0)
                                }, n.prototype.get_regexp = function(e, n) {
                                    var i = null,
                                        s = "g";
                                    return n && t && (s = "y"), "string" == typeof e && "" !== e ? i = new RegExp(e, s) : e && (i = new RegExp(e.source, s)), i
                                }, n.prototype.get_literal_regexp = function(e) {
                                    return RegExp(e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
                                }, n.prototype.peekUntilAfter = function(e) {
                                    var t = this.__position,
                                        n = this.readUntilAfter(e);
                                    return this.__position = t, n
                                }, n.prototype.lookBack = function(e) {
                                    var t = this.__position - 1;
                                    return t >= e.length && this.__input.substring(t - e.length, t).toLowerCase() === e
                                }, e.exports.InputScanner = n
                            }, function(e, t, n) {
                                var i = n(8).InputScanner,
                                    s = n(3).Token,
                                    a = n(10).TokenStream,
                                    o = n(11).WhitespacePattern,
                                    r = {
                                        START: "TK_START",
                                        RAW: "TK_RAW",
                                        EOF: "TK_EOF"
                                    },
                                    c = function(e, t) {
                                        this._input = new i(e), this._options = t || {}, this.__tokens = null, this._patterns = {}, this._patterns.whitespace = new o(this._input)
                                    };
                                c.prototype.tokenize = function() {
                                    var e;
                                    this._input.restart(), this.__tokens = new a, this._reset();
                                    for (var t = new s(r.START, ""), n = null, i = [], o = new a; t.type !== r.EOF;) {
                                        for (e = this._get_next_token(t, n); this._is_comment(e);) o.add(e), e = this._get_next_token(t, n);
                                        o.isEmpty() || (e.comments_before = o, o = new a), e.parent = n, this._is_opening(e) ? (i.push(n), n = e) : n && this._is_closing(e, n) && (e.opened = n, n.closed = e, n = i.pop(), e.parent = n), e.previous = t, t.next = e, this.__tokens.add(e), t = e
                                    }
                                    return this.__tokens
                                }, c.prototype._is_first_token = function() {
                                    return this.__tokens.isEmpty()
                                }, c.prototype._reset = function() {}, c.prototype._get_next_token = function(e, t) {
                                    this._readWhitespace();
                                    var n = this._input.read(/.+/g);
                                    return n ? this._create_token(r.RAW, n) : this._create_token(r.EOF, "")
                                }, c.prototype._is_comment = function(e) {
                                    return !1
                                }, c.prototype._is_opening = function(e) {
                                    return !1
                                }, c.prototype._is_closing = function(e, t) {
                                    return !1
                                }, c.prototype._create_token = function(e, t) {
                                    return new s(e, t, this._patterns.whitespace.newline_count, this._patterns.whitespace.whitespace_before_token)
                                }, c.prototype._readWhitespace = function() {
                                    return this._patterns.whitespace.read()
                                }, e.exports.Tokenizer = c, e.exports.TOKEN = r
                            }, function(e) {
                                function t(e) {
                                    this.__tokens = [], this.__tokens_length = this.__tokens.length, this.__position = 0, this.__parent_token = e
                                }
                                t.prototype.restart = function() {
                                    this.__position = 0
                                }, t.prototype.isEmpty = function() {
                                    return 0 === this.__tokens_length
                                }, t.prototype.hasNext = function() {
                                    return this.__position < this.__tokens_length
                                }, t.prototype.next = function() {
                                    var e = null;
                                    return this.hasNext() && (e = this.__tokens[this.__position], this.__position += 1), e
                                }, t.prototype.peek = function(e) {
                                    var t = null;
                                    return e = e || 0, (e += this.__position) >= 0 && e < this.__tokens_length && (t = this.__tokens[e]), t
                                }, t.prototype.add = function(e) {
                                    this.__parent_token && (e.parent = this.__parent_token), this.__tokens.push(e), this.__tokens_length += 1
                                }, e.exports.TokenStream = t
                            }, function(e, t, n) {
                                var i = n(12).Pattern;

                                function s(e, t) {
                                    i.call(this, e, t), t ? this._line_regexp = this._input.get_regexp(t._line_regexp) : this.__set_whitespace_patterns("", ""), this.newline_count = 0, this.whitespace_before_token = ""
                                }
                                s.prototype = new i, s.prototype.__set_whitespace_patterns = function(e, t) {
                                    e += "\\t ", t += "\\n\\r", this._match_pattern = this._input.get_regexp("[" + e + t + "]+", !0), this._newline_regexp = this._input.get_regexp("\\r\\n|[" + t + "]")
                                }, s.prototype.read = function() {
                                    this.newline_count = 0, this.whitespace_before_token = "";
                                    var e = this._input.read(this._match_pattern);
                                    if (" " === e) this.whitespace_before_token = " ";
                                    else if (e) {
                                        var t = this.__split(this._newline_regexp, e);
                                        this.newline_count = t.length - 1, this.whitespace_before_token = t[this.newline_count]
                                    }
                                    return e
                                }, s.prototype.matching = function(e, t) {
                                    var n = this._create();
                                    return n.__set_whitespace_patterns(e, t), n._update(), n
                                }, s.prototype._create = function() {
                                    return new s(this._input, this)
                                }, s.prototype.__split = function(e, t) {
                                    e.lastIndex = 0;
                                    for (var n = 0, i = [], s = e.exec(t); s;) i.push(t.substring(n, s.index)), n = s.index + s[0].length, s = e.exec(t);
                                    return n < t.length ? i.push(t.substring(n, t.length)) : i.push(""), i
                                }, e.exports.WhitespacePattern = s
                            }, function(e) {
                                function t(e, t) {
                                    this._input = e, this._starting_pattern = null, this._match_pattern = null, this._until_pattern = null, this._until_after = !1, t && (this._starting_pattern = this._input.get_regexp(t._starting_pattern, !0), this._match_pattern = this._input.get_regexp(t._match_pattern, !0), this._until_pattern = this._input.get_regexp(t._until_pattern), this._until_after = t._until_after)
                                }
                                t.prototype.read = function() {
                                    var e = this._input.read(this._starting_pattern);
                                    return this._starting_pattern && !e || (e += this._input.read(this._match_pattern, this._until_pattern, this._until_after)), e
                                }, t.prototype.read_match = function() {
                                    return this._input.match(this._match_pattern)
                                }, t.prototype.until_after = function(e) {
                                    var t = this._create();
                                    return t._until_after = !0, t._until_pattern = this._input.get_regexp(e), t._update(), t
                                }, t.prototype.until = function(e) {
                                    var t = this._create();
                                    return t._until_after = !1, t._until_pattern = this._input.get_regexp(e), t._update(), t
                                }, t.prototype.starting_with = function(e) {
                                    var t = this._create();
                                    return t._starting_pattern = this._input.get_regexp(e, !0), t._update(), t
                                }, t.prototype.matching = function(e) {
                                    var t = this._create();
                                    return t._match_pattern = this._input.get_regexp(e, !0), t._update(), t
                                }, t.prototype._create = function() {
                                    return new t(this._input, this)
                                }, t.prototype._update = function() {}, e.exports.Pattern = t
                            }, function(e) {
                                function t(e, t) {
                                    e = "string" == typeof e ? e : e.source, t = "string" == typeof t ? t : t.source, this.__directives_block_pattern = new RegExp(e + / beautify( \w+[:]\w+)+ /.source + t, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(e + /\sbeautify\signore:end\s/.source + t, "g")
                                }
                                t.prototype.get_directives = function(e) {
                                    if (!e.match(this.__directives_block_pattern)) return null;
                                    var t = {};
                                    this.__directive_pattern.lastIndex = 0;
                                    for (var n = this.__directive_pattern.exec(e); n;) t[n[1]] = n[2], n = this.__directive_pattern.exec(e);
                                    return t
                                }, t.prototype.readIgnored = function(e) {
                                    return e.readUntilAfter(this.__directives_end_ignore_pattern)
                                }, e.exports.Directives = t
                            }, function(e, t, n) {
                                var i = n(12).Pattern,
                                    s = {
                                        django: !1,
                                        erb: !1,
                                        handlebars: !1,
                                        php: !1,
                                        smarty: !1,
                                        angular: !1
                                    };

                                function a(e, t) {
                                    i.call(this, e, t), this.__template_pattern = null, this._disabled = Object.assign({}, s), this._excluded = Object.assign({}, s), t && (this.__template_pattern = this._input.get_regexp(t.__template_pattern), this._excluded = Object.assign(this._excluded, t._excluded), this._disabled = Object.assign(this._disabled, t._disabled));
                                    var n = new i(e);
                                    this.__patterns = {
                                        handlebars_comment: n.starting_with(/{{!--/).until_after(/--}}/),
                                        handlebars_unescaped: n.starting_with(/{{{/).until_after(/}}}/),
                                        handlebars: n.starting_with(/{{/).until_after(/}}/),
                                        php: n.starting_with(/<\?(?:[= ]|php)/).until_after(/\?>/),
                                        erb: n.starting_with(/<%[^%]/).until_after(/[^%]%>/),
                                        django: n.starting_with(/{%/).until_after(/%}/),
                                        django_value: n.starting_with(/{{/).until_after(/}}/),
                                        django_comment: n.starting_with(/{#/).until_after(/#}/),
                                        smarty: n.starting_with(/{(?=[^}{\s\n])/).until_after(/[^\s\n]}/),
                                        smarty_comment: n.starting_with(/{\*/).until_after(/\*}/),
                                        smarty_literal: n.starting_with(/{literal}/).until_after(/{\/literal}/)
                                    }
                                }
                                a.prototype = new i, a.prototype._create = function() {
                                    return new a(this._input, this)
                                }, a.prototype._update = function() {
                                    this.__set_templated_pattern()
                                }, a.prototype.disable = function(e) {
                                    var t = this._create();
                                    return t._disabled[e] = !0, t._update(), t
                                }, a.prototype.read_options = function(e) {
                                    var t = this._create();
                                    for (var n in s) t._disabled[n] = -1 === e.templating.indexOf(n);
                                    return t._update(), t
                                }, a.prototype.exclude = function(e) {
                                    var t = this._create();
                                    return t._excluded[e] = !0, t._update(), t
                                }, a.prototype.read = function() {
                                    var e = "";
                                    e = this._match_pattern ? this._input.read(this._starting_pattern) : this._input.read(this._starting_pattern, this.__template_pattern);
                                    for (var t = this._read_template(); t;) this._match_pattern ? t += this._input.read(this._match_pattern) : t += this._input.readUntil(this.__template_pattern), e += t, t = this._read_template();
                                    return this._until_after && (e += this._input.readUntilAfter(this._until_pattern)), e
                                }, a.prototype.__set_templated_pattern = function() {
                                    var e = [];
                                    this._disabled.php || e.push(this.__patterns.php._starting_pattern.source), this._disabled.handlebars || e.push(this.__patterns.handlebars._starting_pattern.source), this._disabled.erb || e.push(this.__patterns.erb._starting_pattern.source), this._disabled.django || (e.push(this.__patterns.django._starting_pattern.source), e.push(this.__patterns.django_value._starting_pattern.source), e.push(this.__patterns.django_comment._starting_pattern.source)), this._disabled.smarty || e.push(this.__patterns.smarty._starting_pattern.source), this._until_pattern && e.push(this._until_pattern.source), this.__template_pattern = this._input.get_regexp("(?:" + e.join("|") + ")")
                                }, a.prototype._read_template = function() {
                                    var e = "",
                                        t = this._input.peek();
                                    if ("<" === t) {
                                        var n = this._input.peek(1);
                                        this._disabled.php || this._excluded.php || "?" !== n || (e = e || this.__patterns.php.read()), this._disabled.erb || this._excluded.erb || "%" !== n || (e = e || this.__patterns.erb.read())
                                    } else "{" === t && (this._disabled.handlebars || this._excluded.handlebars || (e = (e = (e = e || this.__patterns.handlebars_comment.read()) || this.__patterns.handlebars_unescaped.read()) || this.__patterns.handlebars.read()), this._disabled.django || (this._excluded.django || this._excluded.handlebars || (e = e || this.__patterns.django_value.read()), this._excluded.django || (e = (e = e || this.__patterns.django_comment.read()) || this.__patterns.django.read())), this._disabled.smarty || this._disabled.django && this._disabled.handlebars && (e = (e = (e = e || this.__patterns.smarty_comment.read()) || this.__patterns.smarty_literal.read()) || this.__patterns.smarty.read()));
                                    return e
                                }, e.exports.TemplatablePattern = a
                            }, , , , function(e, t, n) {
                                var i = n(19).Beautifier,
                                    s = n(20).Options;
                                e.exports = function(e, t, n, s) {
                                    return new i(e, t, n, s).beautify()
                                }, e.exports.defaultOptions = function() {
                                    return new s
                                }
                            }, function(e, t, n) {
                                var i = n(20).Options,
                                    s = n(2).Output,
                                    a = n(21).Tokenizer,
                                    o = n(21).TOKEN,
                                    r = /\r\n|[\r\n]/,
                                    c = /\r\n|[\r\n]/g,
                                    l = function(e, t) {
                                        this.indent_level = 0, this.alignment_size = 0, this.max_preserve_newlines = e.max_preserve_newlines, this.preserve_newlines = e.preserve_newlines, this._output = new s(e, t)
                                    };
                                l.prototype.current_line_has_match = function(e) {
                                    return this._output.current_line.has_match(e)
                                }, l.prototype.set_space_before_token = function(e, t) {
                                    this._output.space_before_token = e, this._output.non_breaking_space = t
                                }, l.prototype.set_wrap_point = function() {
                                    this._output.set_indent(this.indent_level, this.alignment_size), this._output.set_wrap_point()
                                }, l.prototype.add_raw_token = function(e) {
                                    this._output.add_raw_token(e)
                                }, l.prototype.print_preserved_newlines = function(e) {
                                    var t = 0;
                                    e.type !== o.TEXT && e.previous.type !== o.TEXT && (t = e.newlines ? 1 : 0), this.preserve_newlines && (t = e.newlines < this.max_preserve_newlines + 1 ? e.newlines : this.max_preserve_newlines + 1);
                                    for (var n = 0; n < t; n++) this.print_newline(n > 0);
                                    return 0 !== t
                                }, l.prototype.traverse_whitespace = function(e) {
                                    return !(!e.whitespace_before && !e.newlines) && (this.print_preserved_newlines(e) || (this._output.space_before_token = !0), !0)
                                }, l.prototype.previous_token_wrapped = function() {
                                    return this._output.previous_token_wrapped
                                }, l.prototype.print_newline = function(e) {
                                    this._output.add_new_line(e)
                                }, l.prototype.print_token = function(e) {
                                    e.text && (this._output.set_indent(this.indent_level, this.alignment_size), this._output.add_token(e.text))
                                }, l.prototype.indent = function() {
                                    this.indent_level++
                                }, l.prototype.deindent = function() {
                                    this.indent_level > 0 && (this.indent_level--, this._output.set_indent(this.indent_level, this.alignment_size))
                                }, l.prototype.get_full_indent = function(e) {
                                    return (e = this.indent_level + (e || 0)) < 1 ? "" : this._output.get_indent_string(e)
                                };
                                var u = function(e, t) {
                                    var n = null,
                                        i = null;
                                    return t.closed ? ("script" === e ? n = "text/javascript" : "style" === e && (n = "text/css"), n = function(e) {
                                        for (var t = null, n = e.next; n.type !== o.EOF && e.closed !== n;) {
                                            if (n.type === o.ATTRIBUTE && "type" === n.text) {
                                                n.next && n.next.type === o.EQUALS && n.next.next && n.next.next.type === o.VALUE && (t = n.next.next.text);
                                                break
                                            }
                                            n = n.next
                                        }
                                        return t
                                    }(t) || n, n.search("text/css") > -1 ? i = "css" : n.search(/module|((text|application|dojo)\/(x-)?(javascript|ecmascript|jscript|livescript|(ld\+)?json|method|aspect))/) > -1 ? i = "javascript" : n.search(/(text|application|dojo)\/(x-)?(html)/) > -1 ? i = "html" : n.search(/test\/null/) > -1 && (i = "null"), i) : null
                                };

                                function d(e, t) {
                                    return -1 !== t.indexOf(e)
                                }

                                function h(e, t, n) {
                                    this.parent = e || null, this.tag = t ? t.tag_name : "", this.indent_level = n || 0, this.parser_token = t || null
                                }

                                function _(e) {
                                    this._printer = e, this._current_frame = null
                                }

                                function p(e, t, n, s) {
                                    this._source_text = e || "", t = t || {}, this._js_beautify = n, this._css_beautify = s, this._tag_stack = null;
                                    var a = new i(t, "html");
                                    this._options = a, this._is_wrap_attributes_force = "force" === this._options.wrap_attributes.substr(0, 5), this._is_wrap_attributes_force_expand_multiline = "force-expand-multiline" === this._options.wrap_attributes, this._is_wrap_attributes_force_aligned = "force-aligned" === this._options.wrap_attributes, this._is_wrap_attributes_aligned_multiple = "aligned-multiple" === this._options.wrap_attributes, this._is_wrap_attributes_preserve = "preserve" === this._options.wrap_attributes.substr(0, 8), this._is_wrap_attributes_preserve_aligned = "preserve-aligned" === this._options.wrap_attributes
                                }
                                _.prototype.get_parser_token = function() {
                                    return this._current_frame ? this._current_frame.parser_token : null
                                }, _.prototype.record_tag = function(e) {
                                    var t = new h(this._current_frame, e, this._printer.indent_level);
                                    this._current_frame = t
                                }, _.prototype._try_pop_frame = function(e) {
                                    var t = null;
                                    return e && (t = e.parser_token, this._printer.indent_level = e.indent_level, this._current_frame = e.parent), t
                                }, _.prototype._get_frame = function(e, t) {
                                    for (var n = this._current_frame; n && -1 === e.indexOf(n.tag);) {
                                        if (t && -1 !== t.indexOf(n.tag)) {
                                            n = null;
                                            break
                                        }
                                        n = n.parent
                                    }
                                    return n
                                }, _.prototype.try_pop = function(e, t) {
                                    var n = this._get_frame([e], t);
                                    return this._try_pop_frame(n)
                                }, _.prototype.indent_to_tag = function(e) {
                                    var t = this._get_frame(e);
                                    t && (this._printer.indent_level = t.indent_level)
                                }, p.prototype.beautify = function() {
                                    if (this._options.disabled) return this._source_text;
                                    var e = this._source_text,
                                        t = this._options.eol;
                                    "auto" === this._options.eol && (t = "\n", e && r.test(e) && (t = e.match(r)[0]));
                                    var n = (e = e.replace(c, "\n")).match(/^[\t ]*/)[0],
                                        i = {
                                            text: "",
                                            type: ""
                                        },
                                        s = new f,
                                        u = new l(this._options, n),
                                        d = new a(e, this._options).tokenize();
                                    this._tag_stack = new _(u);
                                    for (var h = null, p = d.next(); p.type !== o.EOF;) p.type === o.TAG_OPEN || p.type === o.COMMENT ? s = h = this._handle_tag_open(u, p, s, i, d) : p.type === o.ATTRIBUTE || p.type === o.EQUALS || p.type === o.VALUE || p.type === o.TEXT && !s.tag_complete ? h = this._handle_inside_tag(u, p, s, i) : p.type === o.TAG_CLOSE ? h = this._handle_tag_close(u, p, s) : p.type === o.TEXT ? h = this._handle_text(u, p, s) : p.type === o.CONTROL_FLOW_OPEN ? h = this._handle_control_flow_open(u, p) : p.type === o.CONTROL_FLOW_CLOSE ? h = this._handle_control_flow_close(u, p) : u.add_raw_token(p), i = h, p = d.next();
                                    return u._output.get_code(t)
                                }, p.prototype._handle_control_flow_open = function(e, t) {
                                    var n = {
                                        text: t.text,
                                        type: t.type
                                    };
                                    return e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), t.newlines ? e.print_preserved_newlines(t) : e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), e.print_token(t), e.indent(), n
                                }, p.prototype._handle_control_flow_close = function(e, t) {
                                    var n = {
                                        text: t.text,
                                        type: t.type
                                    };
                                    return e.deindent(), t.newlines ? e.print_preserved_newlines(t) : e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), e.print_token(t), n
                                }, p.prototype._handle_tag_close = function(e, t, n) {
                                    var i = {
                                        text: t.text,
                                        type: t.type
                                    };
                                    return e.alignment_size = 0, n.tag_complete = !0, e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), n.is_unformatted ? e.add_raw_token(t) : ("<" === n.tag_start_char && (e.set_space_before_token("/" === t.text[0], !0), this._is_wrap_attributes_force_expand_multiline && n.has_wrapped_attrs && e.print_newline(!1)), e.print_token(t)), !n.indent_content || n.is_unformatted || n.is_content_unformatted || (e.indent(), n.indent_content = !1), n.is_inline_element || n.is_unformatted || n.is_content_unformatted || e.set_wrap_point(), i
                                }, p.prototype._handle_inside_tag = function(e, t, n, i) {
                                    var s = n.has_wrapped_attrs,
                                        a = {
                                            text: t.text,
                                            type: t.type
                                        };
                                    return e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), n.is_unformatted ? e.add_raw_token(t) : "{" === n.tag_start_char && t.type === o.TEXT ? e.print_preserved_newlines(t) ? (t.newlines = 0, e.add_raw_token(t)) : e.print_token(t) : (t.type === o.ATTRIBUTE ? e.set_space_before_token(!0) : (t.type === o.EQUALS || t.type === o.VALUE && t.previous.type === o.EQUALS) && e.set_space_before_token(!1), t.type === o.ATTRIBUTE && "<" === n.tag_start_char && ((this._is_wrap_attributes_preserve || this._is_wrap_attributes_preserve_aligned) && (e.traverse_whitespace(t), s = s || 0 !== t.newlines), this._is_wrap_attributes_force && n.attr_count >= this._options.wrap_attributes_min_attrs && (i.type !== o.TAG_OPEN || this._is_wrap_attributes_force_expand_multiline) && (e.print_newline(!1), s = !0)), e.print_token(t), s = s || e.previous_token_wrapped(), n.has_wrapped_attrs = s), a
                                }, p.prototype._handle_text = function(e, t, n) {
                                    var i = {
                                        text: t.text,
                                        type: "TK_CONTENT"
                                    };
                                    return n.custom_beautifier_name ? this._print_custom_beatifier_text(e, t, n) : n.is_unformatted || n.is_content_unformatted ? e.add_raw_token(t) : (e.traverse_whitespace(t), e.print_token(t)), i
                                }, p.prototype._print_custom_beatifier_text = function(e, t, n) {
                                    var i = this;
                                    if ("" !== t.text) {
                                        var s, a = t.text,
                                            o = 1,
                                            r = "",
                                            c = "";
                                        "javascript" === n.custom_beautifier_name && "function" == typeof this._js_beautify ? s = this._js_beautify : "css" === n.custom_beautifier_name && "function" == typeof this._css_beautify ? s = this._css_beautify : "html" === n.custom_beautifier_name && (s = function(e, t) {
                                            return new p(e, t, i._js_beautify, i._css_beautify).beautify()
                                        }), "keep" === this._options.indent_scripts ? o = 0 : "separate" === this._options.indent_scripts && (o = -e.indent_level);
                                        var l = e.get_full_indent(o);
                                        if (a = a.replace(/\n[ \t]*$/, ""), "html" !== n.custom_beautifier_name && "<" === a[0] && a.match(/^(<!--|<!\[CDATA\[)/)) {
                                            var u = /^(<!--[^\n]*|<!\[CDATA\[)(\n?)([ \t\n]*)([\s\S]*)(-->|]]>)$/.exec(a);
                                            if (!u) return void e.add_raw_token(t);
                                            r = l + u[1] + "\n", a = u[4], u[5] && (c = l + u[5]), a = a.replace(/\n[ \t]*$/, ""), (u[2] || -1 !== u[3].indexOf("\n")) && (u = u[3].match(/[ \t]+$/)) && (t.whitespace_before = u[0])
                                        }
                                        if (a)
                                            if (s) {
                                                var d = function() {
                                                    this.eol = "\n"
                                                };
                                                d.prototype = this._options.raw_options, a = s(l + a, new d)
                                            } else {
                                                var h = t.whitespace_before;
                                                h && (a = a.replace(new RegExp("\n(" + h + ")?", "g"), "\n")), a = l + a.replace(/\n/g, "\n" + l)
                                            }
                                        r && (a = a ? r + a + "\n" + c : r + c), e.print_newline(!1), a && (t.text = a, t.whitespace_before = "", t.newlines = 0, e.add_raw_token(t), e.print_newline(!0))
                                    }
                                }, p.prototype._handle_tag_open = function(e, t, n, i, s) {
                                    var a = this._get_tag_open_token(t);
                                    if (!n.is_unformatted && !n.is_content_unformatted || n.is_empty_element || t.type !== o.TAG_OPEN || a.is_start_tag ? (e.traverse_whitespace(t), this._set_tag_position(e, t, a, n, i), a.is_inline_element || e.set_wrap_point(), e.print_token(t)) : (e.add_raw_token(t), a.start_tag_token = this._tag_stack.try_pop(a.tag_name)), a.is_start_tag && this._is_wrap_attributes_force) {
                                        var r, c = 0;
                                        do {
                                            (r = s.peek(c)).type === o.ATTRIBUTE && (a.attr_count += 1), c += 1
                                        } while (r.type !== o.EOF && r.type !== o.TAG_CLOSE)
                                    }
                                    return (this._is_wrap_attributes_force_aligned || this._is_wrap_attributes_aligned_multiple || this._is_wrap_attributes_preserve_aligned) && (a.alignment_size = t.text.length + 1), a.tag_complete || a.is_unformatted || (e.alignment_size = a.alignment_size), a
                                };
                                var f = function(e, t) {
                                    if (this.parent = e || null, this.text = "", this.type = "TK_TAG_OPEN", this.tag_name = "", this.is_inline_element = !1, this.is_unformatted = !1, this.is_content_unformatted = !1, this.is_empty_element = !1, this.is_start_tag = !1, this.is_end_tag = !1, this.indent_content = !1, this.multiline_content = !1, this.custom_beautifier_name = null, this.start_tag_token = null, this.attr_count = 0, this.has_wrapped_attrs = !1, this.alignment_size = 0, this.tag_complete = !1, this.tag_start_char = "", this.tag_check = "", t) {
                                        var n;
                                        this.tag_start_char = t.text[0], this.text = t.text, "<" === this.tag_start_char ? (n = t.text.match(/^<([^\s>]*)/), this.tag_check = n ? n[1] : "") : (n = t.text.match(/^{{~?(?:[\^]|#\*?)?([^\s}]+)/), this.tag_check = n ? n[1] : "", (t.text.startsWith("{{#>") || t.text.startsWith("{{~#>")) && ">" === this.tag_check[0] && (">" === this.tag_check && null !== t.next ? this.tag_check = t.next.text.split(" ")[0] : this.tag_check = t.text.split(">")[1])), this.tag_check = this.tag_check.toLowerCase(), t.type === o.COMMENT && (this.tag_complete = !0), this.is_start_tag = "/" !== this.tag_check.charAt(0), this.tag_name = this.is_start_tag ? this.tag_check : this.tag_check.substr(1), this.is_end_tag = !this.is_start_tag || t.closed && "/>" === t.closed.text;
                                        var i = 2;
                                        "{" === this.tag_start_char && this.text.length >= 3 && "~" === this.text.charAt(2) && (i = 3), this.is_end_tag = this.is_end_tag || "{" === this.tag_start_char && (this.text.length < 3 || /[^#\^]/.test(this.text.charAt(i)))
                                    } else this.tag_complete = !0
                                };
                                p.prototype._get_tag_open_token = function(e) {
                                    var t = new f(this._tag_stack.get_parser_token(), e);
                                    return t.alignment_size = this._options.wrap_attributes_indent_size, t.is_end_tag = t.is_end_tag || d(t.tag_check, this._options.void_elements), t.is_empty_element = t.tag_complete || t.is_start_tag && t.is_end_tag, t.is_unformatted = !t.tag_complete && d(t.tag_check, this._options.unformatted), t.is_content_unformatted = !t.is_empty_element && d(t.tag_check, this._options.content_unformatted), t.is_inline_element = d(t.tag_name, this._options.inline) || this._options.inline_custom_elements && t.tag_name.includes("-") || "{" === t.tag_start_char, t
                                }, p.prototype._set_tag_position = function(e, t, n, i, s) {
                                    if (n.is_empty_element || (n.is_end_tag ? n.start_tag_token = this._tag_stack.try_pop(n.tag_name) : (this._do_optional_end_element(n) && (n.is_inline_element || e.print_newline(!1)), this._tag_stack.record_tag(n), "script" !== n.tag_name && "style" !== n.tag_name || n.is_unformatted || n.is_content_unformatted || (n.custom_beautifier_name = u(n.tag_check, t)))), d(n.tag_check, this._options.extra_liners) && (e.print_newline(!1), e._output.just_added_blankline() || e.print_newline(!0)), n.is_empty_element) {
                                        if ("{" === n.tag_start_char && "else" === n.tag_check) this._tag_stack.indent_to_tag(["if", "unless", "each"]), n.indent_content = !0, e.current_line_has_match(/{{#if/) || e.print_newline(!1);
                                        "!--" === n.tag_name && s.type === o.TAG_CLOSE && i.is_end_tag && -1 === n.text.indexOf("\n") || (n.is_inline_element || n.is_unformatted || e.print_newline(!1), this._calcluate_parent_multiline(e, n))
                                    } else if (n.is_end_tag) {
                                        var a = !1;
                                        a = (a = n.start_tag_token && n.start_tag_token.multiline_content) || !n.is_inline_element && !(i.is_inline_element || i.is_unformatted) && !(s.type === o.TAG_CLOSE && n.start_tag_token === i) && "TK_CONTENT" !== s.type, (n.is_content_unformatted || n.is_unformatted) && (a = !1), a && e.print_newline(!1)
                                    } else n.indent_content = !n.custom_beautifier_name, "<" === n.tag_start_char && ("html" === n.tag_name ? n.indent_content = this._options.indent_inner_html : "head" === n.tag_name ? n.indent_content = this._options.indent_head_inner_html : "body" === n.tag_name && (n.indent_content = this._options.indent_body_inner_html)), n.is_inline_element || n.is_unformatted || "TK_CONTENT" === s.type && !n.is_content_unformatted || e.print_newline(!1), this._calcluate_parent_multiline(e, n)
                                }, p.prototype._calcluate_parent_multiline = function(e, t) {
                                    !t.parent || !e._output.just_added_newline() || (t.is_inline_element || t.is_unformatted) && t.parent.is_inline_element || (t.parent.multiline_content = !0)
                                };
                                var g = ["address", "article", "aside", "blockquote", "details", "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul"],
                                    m = ["a", "audio", "del", "ins", "map", "noscript", "video"];
                                p.prototype._do_optional_end_element = function(e) {
                                    var t = null;
                                    if (!e.is_empty_element && e.is_start_tag && e.parent) {
                                        if ("body" === e.tag_name) t = t || this._tag_stack.try_pop("head");
                                        else if ("li" === e.tag_name) t = t || this._tag_stack.try_pop("li", ["ol", "ul", "menu"]);
                                        else if ("dd" === e.tag_name || "dt" === e.tag_name) t = (t = t || this._tag_stack.try_pop("dt", ["dl"])) || this._tag_stack.try_pop("dd", ["dl"]);
                                        else if ("p" === e.parent.tag_name && -1 !== g.indexOf(e.tag_name)) {
                                            var n = e.parent.parent;
                                            n && -1 !== m.indexOf(n.tag_name) || (t = t || this._tag_stack.try_pop("p"))
                                        } else "rp" === e.tag_name || "rt" === e.tag_name ? t = (t = t || this._tag_stack.try_pop("rt", ["ruby", "rtc"])) || this._tag_stack.try_pop("rp", ["ruby", "rtc"]) : "optgroup" === e.tag_name ? t = t || this._tag_stack.try_pop("optgroup", ["select"]) : "option" === e.tag_name ? t = t || this._tag_stack.try_pop("option", ["select", "datalist", "optgroup"]) : "colgroup" === e.tag_name ? t = t || this._tag_stack.try_pop("caption", ["table"]) : "thead" === e.tag_name ? t = (t = t || this._tag_stack.try_pop("caption", ["table"])) || this._tag_stack.try_pop("colgroup", ["table"]) : "tbody" === e.tag_name || "tfoot" === e.tag_name ? t = (t = (t = (t = t || this._tag_stack.try_pop("caption", ["table"])) || this._tag_stack.try_pop("colgroup", ["table"])) || this._tag_stack.try_pop("thead", ["table"])) || this._tag_stack.try_pop("tbody", ["table"]) : "tr" === e.tag_name ? t = (t = (t = t || this._tag_stack.try_pop("caption", ["table"])) || this._tag_stack.try_pop("colgroup", ["table"])) || this._tag_stack.try_pop("tr", ["table", "thead", "tbody", "tfoot"]) : "th" !== e.tag_name && "td" !== e.tag_name || (t = (t = t || this._tag_stack.try_pop("td", ["table", "thead", "tbody", "tfoot", "tr"])) || this._tag_stack.try_pop("th", ["table", "thead", "tbody", "tfoot", "tr"]));
                                        return e.parent = this._tag_stack.get_parser_token(), t
                                    }
                                }, e.exports.Beautifier = p
                            }, function(e, t, n) {
                                var i = n(6).Options;

                                function s(e) {
                                    i.call(this, e, "html"), 1 === this.templating.length && "auto" === this.templating[0] && (this.templating = ["django", "erb", "handlebars", "php"]), this.indent_inner_html = this._get_boolean("indent_inner_html"), this.indent_body_inner_html = this._get_boolean("indent_body_inner_html", !0), this.indent_head_inner_html = this._get_boolean("indent_head_inner_html", !0), this.indent_handlebars = this._get_boolean("indent_handlebars", !0), this.wrap_attributes = this._get_selection("wrap_attributes", ["auto", "force", "force-aligned", "force-expand-multiline", "aligned-multiple", "preserve", "preserve-aligned"]), this.wrap_attributes_min_attrs = this._get_number("wrap_attributes_min_attrs", 2), this.wrap_attributes_indent_size = this._get_number("wrap_attributes_indent_size", this.indent_size), this.extra_liners = this._get_array("extra_liners", ["head", "body", "/html"]), this.inline = this._get_array("inline", ["a", "abbr", "area", "audio", "b", "bdi", "bdo", "br", "button", "canvas", "cite", "code", "data", "datalist", "del", "dfn", "em", "embed", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "map", "mark", "math", "meter", "noscript", "object", "output", "progress", "q", "ruby", "s", "samp", "select", "small", "span", "strong", "sub", "sup", "svg", "template", "textarea", "time", "u", "var", "video", "wbr", "text", "acronym", "big", "strike", "tt"]), this.inline_custom_elements = this._get_boolean("inline_custom_elements", !0), this.void_elements = this._get_array("void_elements", ["area", "base", "br", "col", "embed", "hr", "img", "input", "keygen", "link", "menuitem", "meta", "param", "source", "track", "wbr", "!doctype", "?xml", "basefont", "isindex"]), this.unformatted = this._get_array("unformatted", []), this.content_unformatted = this._get_array("content_unformatted", ["pre", "textarea"]), this.unformatted_content_delimiter = this._get_characters("unformatted_content_delimiter"), this.indent_scripts = this._get_selection("indent_scripts", ["normal", "keep", "separate"])
                                }
                                s.prototype = new i, e.exports.Options = s
                            }, function(e, t, n) {
                                var i = n(9).Tokenizer,
                                    s = n(9).TOKEN,
                                    a = n(13).Directives,
                                    o = n(14).TemplatablePattern,
                                    r = n(12).Pattern,
                                    c = {
                                        TAG_OPEN: "TK_TAG_OPEN",
                                        TAG_CLOSE: "TK_TAG_CLOSE",
                                        CONTROL_FLOW_OPEN: "TK_CONTROL_FLOW_OPEN",
                                        CONTROL_FLOW_CLOSE: "TK_CONTROL_FLOW_CLOSE",
                                        ATTRIBUTE: "TK_ATTRIBUTE",
                                        EQUALS: "TK_EQUALS",
                                        VALUE: "TK_VALUE",
                                        COMMENT: "TK_COMMENT",
                                        TEXT: "TK_TEXT",
                                        UNKNOWN: "TK_UNKNOWN",
                                        START: s.START,
                                        RAW: s.RAW,
                                        EOF: s.EOF
                                    },
                                    l = new a(/<\!--/, /-->/),
                                    u = function(e, t) {
                                        i.call(this, e, t), this._current_tag_name = "";
                                        var n = new o(this._input).read_options(this._options),
                                            s = new r(this._input);
                                        if (this.__patterns = {
                                                word: n.until(/[\n\r\t <]/),
                                                word_control_flow_close_excluded: n.until(/[\n\r\t <}]/),
                                                single_quote: n.until_after(/'/),
                                                double_quote: n.until_after(/"/),
                                                attribute: n.until(/[\n\r\t =>]|\/>/),
                                                element_name: n.until(/[\n\r\t >\/]/),
                                                angular_control_flow_start: s.matching(/\@[a-zA-Z]+[^({]*[({]/),
                                                handlebars_comment: s.starting_with(/{{!--/).until_after(/--}}/),
                                                handlebars: s.starting_with(/{{/).until_after(/}}/),
                                                handlebars_open: s.until(/[\n\r\t }]/),
                                                handlebars_raw_close: s.until(/}}/),
                                                comment: s.starting_with(/<!--/).until_after(/-->/),
                                                cdata: s.starting_with(/<!\[CDATA\[/).until_after(/]]>/),
                                                conditional_comment: s.starting_with(/<!\[/).until_after(/]>/),
                                                processing: s.starting_with(/<\?/).until_after(/\?>/)
                                            }, this._options.indent_handlebars && (this.__patterns.word = this.__patterns.word.exclude("handlebars"), this.__patterns.word_control_flow_close_excluded = this.__patterns.word_control_flow_close_excluded.exclude("handlebars")), this._unformatted_content_delimiter = null, this._options.unformatted_content_delimiter) {
                                            var a = this._input.get_literal_regexp(this._options.unformatted_content_delimiter);
                                            this.__patterns.unformatted_content_delimiter = s.matching(a).until_after(a)
                                        }
                                    };
                                (u.prototype = new i)._is_comment = function(e) {
                                    return !1
                                }, u.prototype._is_opening = function(e) {
                                    return e.type === c.TAG_OPEN || e.type === c.CONTROL_FLOW_OPEN
                                }, u.prototype._is_closing = function(e, t) {
                                    return e.type === c.TAG_CLOSE && t && ((">" === e.text || "/>" === e.text) && "<" === t.text[0] || "}}" === e.text && "{" === t.text[0] && "{" === t.text[1]) || e.type === c.CONTROL_FLOW_CLOSE && "}" === e.text && t.text.endsWith("{")
                                }, u.prototype._reset = function() {
                                    this._current_tag_name = ""
                                }, u.prototype._get_next_token = function(e, t) {
                                    var n = null;
                                    this._readWhitespace();
                                    var i = this._input.peek();
                                    return null === i ? this._create_token(c.EOF, "") : n = (n = (n = (n = (n = (n = (n = (n = (n = (n = n || this._read_open_handlebars(i, t)) || this._read_attribute(i, e, t)) || this._read_close(i, t)) || this._read_control_flows(i, t)) || this._read_raw_content(i, e, t)) || this._read_content_word(i, t)) || this._read_comment_or_cdata(i)) || this._read_processing(i)) || this._read_open(i, t)) || this._create_token(c.UNKNOWN, this._input.next())
                                }, u.prototype._read_comment_or_cdata = function(e) {
                                    var t = null,
                                        n = null,
                                        i = null;
                                    "<" === e && ("!" === this._input.peek(1) && ((n = this.__patterns.comment.read()) ? (i = l.get_directives(n)) && "start" === i.ignore && (n += l.readIgnored(this._input)) : n = this.__patterns.cdata.read()), n && ((t = this._create_token(c.COMMENT, n)).directives = i));
                                    return t
                                }, u.prototype._read_processing = function(e) {
                                    var t = null,
                                        n = null;
                                    if ("<" === e) {
                                        var i = this._input.peek(1);
                                        "!" !== i && "?" !== i || (n = (n = this.__patterns.conditional_comment.read()) || this.__patterns.processing.read()), n && ((t = this._create_token(c.COMMENT, n)).directives = null)
                                    }
                                    return t
                                }, u.prototype._read_open = function(e, t) {
                                    var n = null,
                                        i = null;
                                    return t && t.type !== c.CONTROL_FLOW_OPEN || "<" === e && (n = this._input.next(), "/" === this._input.peek() && (n += this._input.next()), n += this.__patterns.element_name.read(), i = this._create_token(c.TAG_OPEN, n)), i
                                }, u.prototype._read_open_handlebars = function(e, t) {
                                    var n = null,
                                        i = null;
                                    return t && t.type !== c.CONTROL_FLOW_OPEN || this._options.indent_handlebars && "{" === e && "{" === this._input.peek(1) && ("!" === this._input.peek(2) ? (n = (n = this.__patterns.handlebars_comment.read()) || this.__patterns.handlebars.read(), i = this._create_token(c.COMMENT, n)) : (n = this.__patterns.handlebars_open.read(), i = this._create_token(c.TAG_OPEN, n))), i
                                }, u.prototype._read_control_flows = function(e, t) {
                                    var n = "",
                                        i = null;
                                    if (!this._options.templating.includes("angular") || !this._options.indent_handlebars) return i;
                                    if ("@" === e) {
                                        if ("" === (n = this.__patterns.angular_control_flow_start.read())) return i;
                                        for (var s = n.endsWith("(") ? 1 : 0, a = 0; !n.endsWith("{") || s !== a;) {
                                            var o = this._input.next();
                                            if (null === o) break;
                                            "(" === o ? s++ : ")" === o && a++, n += o
                                        }
                                        i = this._create_token(c.CONTROL_FLOW_OPEN, n)
                                    } else "}" === e && t && t.type === c.CONTROL_FLOW_OPEN && (n = this._input.next(), i = this._create_token(c.CONTROL_FLOW_CLOSE, n));
                                    return i
                                }, u.prototype._read_close = function(e, t) {
                                    var n = null,
                                        i = null;
                                    return t && t.type === c.TAG_OPEN && ("<" === t.text[0] && (">" === e || "/" === e && ">" === this._input.peek(1)) ? (n = this._input.next(), "/" === e && (n += this._input.next()), i = this._create_token(c.TAG_CLOSE, n)) : "{" === t.text[0] && "}" === e && "}" === this._input.peek(1) && (this._input.next(), this._input.next(), i = this._create_token(c.TAG_CLOSE, "}}"))), i
                                }, u.prototype._read_attribute = function(e, t, n) {
                                    var i = null,
                                        s = "";
                                    if (n && "<" === n.text[0])
                                        if ("=" === e) i = this._create_token(c.EQUALS, this._input.next());
                                        else if ('"' === e || "'" === e) {
                                        var a = this._input.next();
                                        a += '"' === e ? this.__patterns.double_quote.read() : this.__patterns.single_quote.read(), i = this._create_token(c.VALUE, a)
                                    } else(s = this.__patterns.attribute.read()) && (i = t.type === c.EQUALS ? this._create_token(c.VALUE, s) : this._create_token(c.ATTRIBUTE, s));
                                    return i
                                }, u.prototype._is_content_unformatted = function(e) {
                                    return -1 === this._options.void_elements.indexOf(e) && (-1 !== this._options.content_unformatted.indexOf(e) || -1 !== this._options.unformatted.indexOf(e))
                                }, u.prototype._read_raw_content = function(e, t, n) {
                                    var i = "";
                                    if (n && "{" === n.text[0]) i = this.__patterns.handlebars_raw_close.read();
                                    else if (t.type === c.TAG_CLOSE && "<" === t.opened.text[0] && "/" !== t.text[0]) {
                                        var s = t.opened.text.substr(1).toLowerCase();
                                        if ("script" === s || "style" === s) {
                                            var a = this._read_comment_or_cdata(e);
                                            if (a) return a.type = c.TEXT, a;
                                            i = this._input.readUntil(new RegExp("</" + s + "[\\n\\r\\t ]*?>", "ig"))
                                        } else this._is_content_unformatted(s) && (i = this._input.readUntil(new RegExp("</" + s + "[\\n\\r\\t ]*?>", "ig")))
                                    }
                                    return i ? this._create_token(c.TEXT, i) : null
                                }, u.prototype._read_content_word = function(e, t) {
                                    var n = "";
                                    if (this._options.unformatted_content_delimiter && e === this._options.unformatted_content_delimiter[0] && (n = this.__patterns.unformatted_content_delimiter.read()), n || (n = t && t.type === c.CONTROL_FLOW_OPEN ? this.__patterns.word_control_flow_close_excluded.read() : this.__patterns.word.read()), n) return this._create_token(c.TEXT, n)
                                }, e.exports.Tokenizer = u, e.exports.TOKEN = c
                            }],
                            t = {};
                        var n = function n(i) {
                            var s = t[i];
                            if (void 0 !== s) return s.exports;
                            var a = t[i] = {
                                exports: {}
                            };
                            return e[i](a, a.exports, n), a.exports
                        }(18);
                        a = n
                    }();
                    var o = a;
                    i = [n, n(13617), n(3)], s = function(e) {
                        var t = n(13617),
                            i = n(3);
                        return {
                            html_beautify: function(e, n) {
                                return o(e, n, t.js_beautify, i.css_beautify)
                            }
                        }
                    }.apply(t, i), void 0 === s || (e.exports = s)
                }()
            },
            13617: (e, t) => {
                var n;
                ! function() {
                    var i;
                    ! function() {
                        "use strict";
                        var e = [function(e, t, n) {
                                var i = n(1).Beautifier,
                                    s = n(5).Options;
                                e.exports = function(e, t) {
                                    return new i(e, t).beautify()
                                }, e.exports.defaultOptions = function() {
                                    return new s
                                }
                            }, function(e, t, n) {
                                var i = n(2).Output,
                                    s = n(3).Token,
                                    a = n(4),
                                    o = n(5).Options,
                                    r = n(7).Tokenizer,
                                    c = n(7).line_starters,
                                    l = n(7).positionable_operators,
                                    u = n(7).TOKEN;

                                function d(e, t) {
                                    return -1 !== t.indexOf(e)
                                }

                                function h(e, t) {
                                    return e && e.type === u.RESERVED && e.text === t
                                }

                                function _(e, t) {
                                    return e && e.type === u.RESERVED && d(e.text, t)
                                }
                                var p = ["case", "return", "do", "if", "throw", "else", "await", "break", "continue", "async"],
                                    f = function(e) {
                                        for (var t = {}, n = 0; n < e.length; n++) t[e[n].replace(/-/g, "_")] = e[n];
                                        return t
                                    }(["before-newline", "after-newline", "preserve-newline"]),
                                    g = [f.before_newline, f.preserve_newline],
                                    m = "BlockStatement",
                                    v = "Statement",
                                    w = "ObjectLiteral",
                                    b = "ArrayLiteral",
                                    k = "ForInitializer",
                                    y = "Conditional",
                                    x = "Expression";

                                function S(e, t) {
                                    t.multiline_frame || t.mode === k || t.mode === y || e.remove_indent(t.start_line_index)
                                }

                                function E(e) {
                                    return e === b
                                }

                                function C(e) {
                                    return d(e, [x, k, y])
                                }

                                function T(e, t) {
                                    t = t || {}, this._source_text = e || "", this._output = null, this._tokens = null, this._last_last_text = null, this._flags = null, this._previous_flags = null, this._flag_store = null, this._options = new o(t)
                                }
                                T.prototype.create_flags = function(e, t) {
                                    var n = 0;
                                    return e && (n = e.indentation_level, !this._output.just_added_newline() && e.line_indent_level > n && (n = e.line_indent_level)), {
                                        mode: t,
                                        parent: e,
                                        last_token: e ? e.last_token : new s(u.START_BLOCK, ""),
                                        last_word: e ? e.last_word : "",
                                        declaration_statement: !1,
                                        declaration_assignment: !1,
                                        multiline_frame: !1,
                                        inline_frame: !1,
                                        if_block: !1,
                                        else_block: !1,
                                        class_start_block: !1,
                                        do_block: !1,
                                        do_while: !1,
                                        import_block: !1,
                                        in_case_statement: !1,
                                        in_case: !1,
                                        case_body: !1,
                                        case_block: !1,
                                        indentation_level: n,
                                        alignment: 0,
                                        line_indent_level: e ? e.line_indent_level : n,
                                        start_line_index: this._output.get_line_number(),
                                        ternary_depth: 0
                                    }
                                }, T.prototype._reset = function(e) {
                                    var t = e.match(/^[\t ]*/)[0];
                                    this._last_last_text = "", this._output = new i(this._options, t), this._output.raw = this._options.test_output_raw, this._flag_store = [], this.set_mode(m);
                                    var n = new r(e, this._options);
                                    return this._tokens = n.tokenize(), e
                                }, T.prototype.beautify = function() {
                                    if (this._options.disabled) return this._source_text;
                                    var e = this._reset(this._source_text),
                                        t = this._options.eol;
                                    "auto" === this._options.eol && (t = "\n", e && a.lineBreak.test(e || "") && (t = e.match(a.lineBreak)[0]));
                                    for (var n = this._tokens.next(); n;) this.handle_token(n), this._last_last_text = this._flags.last_token.text, this._flags.last_token = n, n = this._tokens.next();
                                    return this._output.get_code(t)
                                }, T.prototype.handle_token = function(e, t) {
                                    e.type === u.START_EXPR ? this.handle_start_expr(e) : e.type === u.END_EXPR ? this.handle_end_expr(e) : e.type === u.START_BLOCK ? this.handle_start_block(e) : e.type === u.END_BLOCK ? this.handle_end_block(e) : e.type === u.WORD || e.type === u.RESERVED ? this.handle_word(e) : e.type === u.SEMICOLON ? this.handle_semicolon(e) : e.type === u.STRING ? this.handle_string(e) : e.type === u.EQUALS ? this.handle_equals(e) : e.type === u.OPERATOR ? this.handle_operator(e) : e.type === u.COMMA ? this.handle_comma(e) : e.type === u.BLOCK_COMMENT ? this.handle_block_comment(e, t) : e.type === u.COMMENT ? this.handle_comment(e, t) : e.type === u.DOT ? this.handle_dot(e) : e.type === u.EOF ? this.handle_eof(e) : (e.type, u.UNKNOWN, this.handle_unknown(e, t))
                                }, T.prototype.handle_whitespace_and_comments = function(e, t) {
                                    var n = e.newlines,
                                        i = this._options.keep_array_indentation && E(this._flags.mode);
                                    if (e.comments_before)
                                        for (var s = e.comments_before.next(); s;) this.handle_whitespace_and_comments(s, t), this.handle_token(s, t), s = e.comments_before.next();
                                    if (i)
                                        for (var a = 0; a < n; a += 1) this.print_newline(a > 0, t);
                                    else if (this._options.max_preserve_newlines && n > this._options.max_preserve_newlines && (n = this._options.max_preserve_newlines), this._options.preserve_newlines && n > 1) {
                                        this.print_newline(!1, t);
                                        for (var o = 1; o < n; o += 1) this.print_newline(!0, t)
                                    }
                                };
                                var O = ["async", "break", "continue", "return", "throw", "yield"];
                                T.prototype.allow_wrap_or_preserved_newline = function(e, t) {
                                    if (t = void 0 !== t && t, !this._output.just_added_newline()) {
                                        var n = this._options.preserve_newlines && e.newlines || t;
                                        if (d(this._flags.last_token.text, l) || d(e.text, l)) {
                                            var i = d(this._flags.last_token.text, l) && d(this._options.operator_position, g) || d(e.text, l);
                                            n = n && i
                                        }
                                        if (n) this.print_newline(!1, !0);
                                        else if (this._options.wrap_line_length) {
                                            if (_(this._flags.last_token, O)) return;
                                            this._output.set_wrap_point()
                                        }
                                    }
                                }, T.prototype.print_newline = function(e, t) {
                                    if (!t && ";" !== this._flags.last_token.text && "," !== this._flags.last_token.text && "=" !== this._flags.last_token.text && (this._flags.last_token.type !== u.OPERATOR || "--" === this._flags.last_token.text || "++" === this._flags.last_token.text))
                                        for (var n = this._tokens.peek(); !(this._flags.mode !== v || this._flags.if_block && h(n, "else") || this._flags.do_block);) this.restore_mode();
                                    this._output.add_new_line(e) && (this._flags.multiline_frame = !0)
                                }, T.prototype.print_token_line_indentation = function(e) {
                                    this._output.just_added_newline() && (this._options.keep_array_indentation && e.newlines && ("[" === e.text || E(this._flags.mode)) ? (this._output.current_line.set_indent(-1), this._output.current_line.push(e.whitespace_before), this._output.space_before_token = !1) : this._output.set_indent(this._flags.indentation_level, this._flags.alignment) && (this._flags.line_indent_level = this._flags.indentation_level))
                                }, T.prototype.print_token = function(e) {
                                    if (this._output.raw) this._output.add_raw_token(e);
                                    else {
                                        if (this._options.comma_first && e.previous && e.previous.type === u.COMMA && this._output.just_added_newline() && "," === this._output.previous_line.last()) {
                                            var t = this._output.previous_line.pop();
                                            this._output.previous_line.is_empty() && (this._output.previous_line.push(t), this._output.trim(!0), this._output.current_line.pop(), this._output.trim()), this.print_token_line_indentation(e), this._output.add_token(","), this._output.space_before_token = !0
                                        }
                                        this.print_token_line_indentation(e), this._output.non_breaking_space = !0, this._output.add_token(e.text), this._output.previous_token_wrapped && (this._flags.multiline_frame = !0)
                                    }
                                }, T.prototype.indent = function() {
                                    this._flags.indentation_level += 1, this._output.set_indent(this._flags.indentation_level, this._flags.alignment)
                                }, T.prototype.deindent = function() {
                                    this._flags.indentation_level > 0 && (!this._flags.parent || this._flags.indentation_level > this._flags.parent.indentation_level) && (this._flags.indentation_level -= 1, this._output.set_indent(this._flags.indentation_level, this._flags.alignment))
                                }, T.prototype.set_mode = function(e) {
                                    this._flags ? (this._flag_store.push(this._flags), this._previous_flags = this._flags) : this._previous_flags = this.create_flags(null, e), this._flags = this.create_flags(this._previous_flags, e), this._output.set_indent(this._flags.indentation_level, this._flags.alignment)
                                }, T.prototype.restore_mode = function() {
                                    this._flag_store.length > 0 && (this._previous_flags = this._flags, this._flags = this._flag_store.pop(), this._previous_flags.mode === v && S(this._output, this._previous_flags), this._output.set_indent(this._flags.indentation_level, this._flags.alignment))
                                }, T.prototype.start_of_object_property = function() {
                                    return this._flags.parent.mode === w && this._flags.mode === v && (":" === this._flags.last_token.text && 0 === this._flags.ternary_depth || _(this._flags.last_token, ["get", "set"]))
                                }, T.prototype.start_of_statement = function(e) {
                                    var t = !1;
                                    return !!(t = (t = (t = (t = (t = (t = (t = t || _(this._flags.last_token, ["var", "let", "const"]) && e.type === u.WORD) || h(this._flags.last_token, "do")) || !(this._flags.parent.mode === w && this._flags.mode === v) && _(this._flags.last_token, O) && !e.newlines) || h(this._flags.last_token, "else") && !(h(e, "if") && !e.comments_before)) || this._flags.last_token.type === u.END_EXPR && (this._previous_flags.mode === k || this._previous_flags.mode === y)) || this._flags.last_token.type === u.WORD && this._flags.mode === m && !this._flags.in_case && !("--" === e.text || "++" === e.text) && "function" !== this._last_last_text && e.type !== u.WORD && e.type !== u.RESERVED) || this._flags.mode === w && (":" === this._flags.last_token.text && 0 === this._flags.ternary_depth || _(this._flags.last_token, ["get", "set"]))) && (this.set_mode(v), this.indent(), this.handle_whitespace_and_comments(e, !0), this.start_of_object_property() || this.allow_wrap_or_preserved_newline(e, _(e, ["do", "for", "if", "while"])), !0)
                                }, T.prototype.handle_start_expr = function(e) {
                                    this.start_of_statement(e) || this.handle_whitespace_and_comments(e);
                                    var t = x;
                                    if ("[" === e.text) {
                                        if (this._flags.last_token.type === u.WORD || ")" === this._flags.last_token.text) return _(this._flags.last_token, c) && (this._output.space_before_token = !0), this.print_token(e), this.set_mode(t), this.indent(), void(this._options.space_in_paren && (this._output.space_before_token = !0));
                                        t = b, E(this._flags.mode) && ("[" !== this._flags.last_token.text && ("," !== this._flags.last_token.text || "]" !== this._last_last_text && "}" !== this._last_last_text) || this._options.keep_array_indentation || this.print_newline()), d(this._flags.last_token.type, [u.START_EXPR, u.END_EXPR, u.WORD, u.OPERATOR, u.DOT]) || (this._output.space_before_token = !0)
                                    } else {
                                        if (this._flags.last_token.type === u.RESERVED) "for" === this._flags.last_token.text ? (this._output.space_before_token = this._options.space_before_conditional, t = k) : d(this._flags.last_token.text, ["if", "while", "switch"]) ? (this._output.space_before_token = this._options.space_before_conditional, t = y) : d(this._flags.last_word, ["await", "async"]) ? this._output.space_before_token = !0 : "import" === this._flags.last_token.text && "" === e.whitespace_before ? this._output.space_before_token = !1 : (d(this._flags.last_token.text, c) || "catch" === this._flags.last_token.text) && (this._output.space_before_token = !0);
                                        else if (this._flags.last_token.type === u.EQUALS || this._flags.last_token.type === u.OPERATOR) this.start_of_object_property() || this.allow_wrap_or_preserved_newline(e);
                                        else if (this._flags.last_token.type === u.WORD) {
                                            this._output.space_before_token = !1;
                                            var n = this._tokens.peek(-3);
                                            if (this._options.space_after_named_function && n) {
                                                var i = this._tokens.peek(-4);
                                                _(n, ["async", "function"]) || "*" === n.text && _(i, ["async", "function"]) ? this._output.space_before_token = !0 : this._flags.mode === w ? "{" !== n.text && "," !== n.text && ("*" !== n.text || "{" !== i.text && "," !== i.text) || (this._output.space_before_token = !0) : this._flags.parent && this._flags.parent.class_start_block && (this._output.space_before_token = !0)
                                            }
                                        } else this.allow_wrap_or_preserved_newline(e);
                                        (this._flags.last_token.type === u.RESERVED && ("function" === this._flags.last_word || "typeof" === this._flags.last_word) || "*" === this._flags.last_token.text && (d(this._last_last_text, ["function", "yield"]) || this._flags.mode === w && d(this._last_last_text, ["{", ","]))) && (this._output.space_before_token = this._options.space_after_anon_function)
                                    }
                                    ";" === this._flags.last_token.text || this._flags.last_token.type === u.START_BLOCK ? this.print_newline() : this._flags.last_token.type !== u.END_EXPR && this._flags.last_token.type !== u.START_EXPR && this._flags.last_token.type !== u.END_BLOCK && "." !== this._flags.last_token.text && this._flags.last_token.type !== u.COMMA || this.allow_wrap_or_preserved_newline(e, e.newlines), this.print_token(e), this.set_mode(t), this._options.space_in_paren && (this._output.space_before_token = !0), this.indent()
                                }, T.prototype.handle_end_expr = function(e) {
                                    for (; this._flags.mode === v;) this.restore_mode();
                                    this.handle_whitespace_and_comments(e), this._flags.multiline_frame && this.allow_wrap_or_preserved_newline(e, "]" === e.text && E(this._flags.mode) && !this._options.keep_array_indentation), this._options.space_in_paren && (this._flags.last_token.type !== u.START_EXPR || this._options.space_in_empty_paren ? this._output.space_before_token = !0 : (this._output.trim(), this._output.space_before_token = !1)), this.deindent(), this.print_token(e), this.restore_mode(), S(this._output, this._previous_flags), this._flags.do_while && this._previous_flags.mode === y && (this._previous_flags.mode = x, this._flags.do_block = !1, this._flags.do_while = !1)
                                }, T.prototype.handle_start_block = function(e) {
                                    this.handle_whitespace_and_comments(e);
                                    var t = this._tokens.peek(),
                                        n = this._tokens.peek(1);
                                    "switch" === this._flags.last_word && this._flags.last_token.type === u.END_EXPR ? (this.set_mode(m), this._flags.in_case_statement = !0) : this._flags.case_body ? this.set_mode(m) : n && (d(n.text, [":", ","]) && d(t.type, [u.STRING, u.WORD, u.RESERVED]) || d(t.text, ["get", "set", "..."]) && d(n.type, [u.WORD, u.RESERVED])) ? d(this._last_last_text, ["class", "interface"]) && !d(n.text, [":", ","]) ? this.set_mode(m) : this.set_mode(w) : this._flags.last_token.type === u.OPERATOR && "=>" === this._flags.last_token.text ? this.set_mode(m) : d(this._flags.last_token.type, [u.EQUALS, u.START_EXPR, u.COMMA, u.OPERATOR]) || _(this._flags.last_token, ["return", "throw", "import", "default"]) ? this.set_mode(w) : this.set_mode(m), this._flags.last_token && _(this._flags.last_token.previous, ["class", "extends"]) && (this._flags.class_start_block = !0);
                                    var i = !t.comments_before && "}" === t.text,
                                        s = i && "function" === this._flags.last_word && this._flags.last_token.type === u.END_EXPR;
                                    if (this._options.brace_preserve_inline) {
                                        var a = 0,
                                            o = null;
                                        this._flags.inline_frame = !0;
                                        do {
                                            if (a += 1, (o = this._tokens.peek(a - 1)).newlines) {
                                                this._flags.inline_frame = !1;
                                                break
                                            }
                                        } while (o.type !== u.EOF && (o.type !== u.END_BLOCK || o.opened !== e))
                                    }("expand" === this._options.brace_style || "none" === this._options.brace_style && e.newlines) && !this._flags.inline_frame ? this._flags.last_token.type !== u.OPERATOR && (s || this._flags.last_token.type === u.EQUALS || _(this._flags.last_token, p) && "else" !== this._flags.last_token.text) ? this._output.space_before_token = !0 : this.print_newline(!1, !0) : (!E(this._previous_flags.mode) || this._flags.last_token.type !== u.START_EXPR && this._flags.last_token.type !== u.COMMA || ((this._flags.last_token.type === u.COMMA || this._options.space_in_paren) && (this._output.space_before_token = !0), (this._flags.last_token.type === u.COMMA || this._flags.last_token.type === u.START_EXPR && this._flags.inline_frame) && (this.allow_wrap_or_preserved_newline(e), this._previous_flags.multiline_frame = this._previous_flags.multiline_frame || this._flags.multiline_frame, this._flags.multiline_frame = !1)), this._flags.last_token.type !== u.OPERATOR && this._flags.last_token.type !== u.START_EXPR && (d(this._flags.last_token.type, [u.START_BLOCK, u.SEMICOLON]) && !this._flags.inline_frame ? this.print_newline() : this._output.space_before_token = !0)), this.print_token(e), this.indent(), i || this._options.brace_preserve_inline && this._flags.inline_frame || this.print_newline()
                                }, T.prototype.handle_end_block = function(e) {
                                    for (this.handle_whitespace_and_comments(e); this._flags.mode === v;) this.restore_mode();
                                    var t = this._flags.last_token.type === u.START_BLOCK;
                                    this._flags.inline_frame && !t ? this._output.space_before_token = !0 : "expand" === this._options.brace_style ? t || this.print_newline() : t || (E(this._flags.mode) && this._options.keep_array_indentation ? (this._options.keep_array_indentation = !1, this.print_newline(), this._options.keep_array_indentation = !0) : this.print_newline()), this.restore_mode(), this.print_token(e)
                                }, T.prototype.handle_word = function(e) {
                                    if (e.type === u.RESERVED)
                                        if (d(e.text, ["set", "get"]) && this._flags.mode !== w) e.type = u.WORD;
                                        else if ("import" === e.text && d(this._tokens.peek().text, ["(", "."])) e.type = u.WORD;
                                    else if (d(e.text, ["as", "from"]) && !this._flags.import_block) e.type = u.WORD;
                                    else if (this._flags.mode === w) {
                                        ":" === this._tokens.peek().text && (e.type = u.WORD)
                                    }
                                    if (this.start_of_statement(e) ? _(this._flags.last_token, ["var", "let", "const"]) && e.type === u.WORD && (this._flags.declaration_statement = !0) : !e.newlines || C(this._flags.mode) || this._flags.last_token.type === u.OPERATOR && "--" !== this._flags.last_token.text && "++" !== this._flags.last_token.text || this._flags.last_token.type === u.EQUALS || !this._options.preserve_newlines && _(this._flags.last_token, ["var", "let", "const", "set", "get"]) ? this.handle_whitespace_and_comments(e) : (this.handle_whitespace_and_comments(e), this.print_newline()), this._flags.do_block && !this._flags.do_while) {
                                        if (h(e, "while")) return this._output.space_before_token = !0, this.print_token(e), this._output.space_before_token = !0, void(this._flags.do_while = !0);
                                        this.print_newline(), this._flags.do_block = !1
                                    }
                                    if (this._flags.if_block)
                                        if (!this._flags.else_block && h(e, "else")) this._flags.else_block = !0;
                                        else {
                                            for (; this._flags.mode === v;) this.restore_mode();
                                            this._flags.if_block = !1, this._flags.else_block = !1
                                        }
                                    if (this._flags.in_case_statement && _(e, ["case", "default"])) return this.print_newline(), this._flags.case_block || !this._flags.case_body && !this._options.jslint_happy || this.deindent(), this._flags.case_body = !1, this.print_token(e), void(this._flags.in_case = !0);
                                    if (this._flags.last_token.type !== u.COMMA && this._flags.last_token.type !== u.START_EXPR && this._flags.last_token.type !== u.EQUALS && this._flags.last_token.type !== u.OPERATOR || this.start_of_object_property() || d(this._flags.last_token.text, ["+", "-"]) && ":" === this._last_last_text && this._flags.parent.mode === w || this.allow_wrap_or_preserved_newline(e), h(e, "function")) return (d(this._flags.last_token.text, ["}", ";"]) || this._output.just_added_newline() && !d(this._flags.last_token.text, ["(", "[", "{", ":", "=", ","]) && this._flags.last_token.type !== u.OPERATOR) && (this._output.just_added_blankline() || e.comments_before || (this.print_newline(), this.print_newline(!0))), this._flags.last_token.type === u.RESERVED || this._flags.last_token.type === u.WORD ? _(this._flags.last_token, ["get", "set", "new", "export"]) || _(this._flags.last_token, O) || h(this._flags.last_token, "default") && "export" === this._last_last_text || "declare" === this._flags.last_token.text ? this._output.space_before_token = !0 : this.print_newline() : this._flags.last_token.type === u.OPERATOR || "=" === this._flags.last_token.text ? this._output.space_before_token = !0 : (this._flags.multiline_frame || !C(this._flags.mode) && !E(this._flags.mode)) && this.print_newline(), this.print_token(e), void(this._flags.last_word = e.text);
                                    var t = "NONE";
                                    (this._flags.last_token.type === u.END_BLOCK ? this._previous_flags.inline_frame ? t = "SPACE" : _(e, ["else", "catch", "finally", "from"]) ? "expand" === this._options.brace_style || "end-expand" === this._options.brace_style || "none" === this._options.brace_style && e.newlines ? t = "NEWLINE" : (t = "SPACE", this._output.space_before_token = !0) : t = "NEWLINE" : this._flags.last_token.type === u.SEMICOLON && this._flags.mode === m ? t = "NEWLINE" : this._flags.last_token.type === u.SEMICOLON && C(this._flags.mode) ? t = "SPACE" : this._flags.last_token.type === u.STRING ? t = "NEWLINE" : this._flags.last_token.type === u.RESERVED || this._flags.last_token.type === u.WORD || "*" === this._flags.last_token.text && (d(this._last_last_text, ["function", "yield"]) || this._flags.mode === w && d(this._last_last_text, ["{", ","])) ? t = "SPACE" : this._flags.last_token.type === u.START_BLOCK ? t = this._flags.inline_frame ? "SPACE" : "NEWLINE" : this._flags.last_token.type === u.END_EXPR && (this._output.space_before_token = !0, t = "NEWLINE"), _(e, c) && ")" !== this._flags.last_token.text && (t = this._flags.inline_frame || "else" === this._flags.last_token.text || "export" === this._flags.last_token.text ? "SPACE" : "NEWLINE"), _(e, ["else", "catch", "finally"])) ? (this._flags.last_token.type !== u.END_BLOCK || this._previous_flags.mode !== m || "expand" === this._options.brace_style || "end-expand" === this._options.brace_style || "none" === this._options.brace_style && e.newlines) && !this._flags.inline_frame ? this.print_newline() : (this._output.trim(!0), "}" !== this._output.current_line.last() && this.print_newline(), this._output.space_before_token = !0): "NEWLINE" === t ? _(this._flags.last_token, p) || "declare" === this._flags.last_token.text && _(e, ["var", "let", "const"]) ? this._output.space_before_token = !0 : this._flags.last_token.type !== u.END_EXPR ? this._flags.last_token.type === u.START_EXPR && _(e, ["var", "let", "const"]) || ":" === this._flags.last_token.text || (h(e, "if") && h(e.previous, "else") ? this._output.space_before_token = !0 : this.print_newline()) : _(e, c) && ")" !== this._flags.last_token.text && this.print_newline() : this._flags.multiline_frame && E(this._flags.mode) && "," === this._flags.last_token.text && "}" === this._last_last_text ? this.print_newline() : "SPACE" === t && (this._output.space_before_token = !0);
                                    !e.previous || e.previous.type !== u.WORD && e.previous.type !== u.RESERVED || (this._output.space_before_token = !0), this.print_token(e), this._flags.last_word = e.text, e.type === u.RESERVED && ("do" === e.text ? this._flags.do_block = !0 : "if" === e.text ? this._flags.if_block = !0 : "import" === e.text ? this._flags.import_block = !0 : this._flags.import_block && h(e, "from") && (this._flags.import_block = !1))
                                }, T.prototype.handle_semicolon = function(e) {
                                    this.start_of_statement(e) ? this._output.space_before_token = !1 : this.handle_whitespace_and_comments(e);
                                    for (var t = this._tokens.peek(); !(this._flags.mode !== v || this._flags.if_block && h(t, "else") || this._flags.do_block);) this.restore_mode();
                                    this._flags.import_block && (this._flags.import_block = !1), this.print_token(e)
                                }, T.prototype.handle_string = function(e) {
                                    (!e.text.startsWith("`") || 0 !== e.newlines || "" !== e.whitespace_before || ")" !== e.previous.text && this._flags.last_token.type !== u.WORD) && (this.start_of_statement(e) ? this._output.space_before_token = !0 : (this.handle_whitespace_and_comments(e), this._flags.last_token.type === u.RESERVED || this._flags.last_token.type === u.WORD || this._flags.inline_frame ? this._output.space_before_token = !0 : this._flags.last_token.type === u.COMMA || this._flags.last_token.type === u.START_EXPR || this._flags.last_token.type === u.EQUALS || this._flags.last_token.type === u.OPERATOR ? this.start_of_object_property() || this.allow_wrap_or_preserved_newline(e) : !e.text.startsWith("`") || this._flags.last_token.type !== u.END_EXPR || "]" !== e.previous.text && ")" !== e.previous.text || 0 !== e.newlines ? this.print_newline() : this._output.space_before_token = !0)), this.print_token(e)
                                }, T.prototype.handle_equals = function(e) {
                                    this.start_of_statement(e) || this.handle_whitespace_and_comments(e), this._flags.declaration_statement && (this._flags.declaration_assignment = !0), this._output.space_before_token = !0, this.print_token(e), this._output.space_before_token = !0
                                }, T.prototype.handle_comma = function(e) {
                                    this.handle_whitespace_and_comments(e, !0), this.print_token(e), this._output.space_before_token = !0, this._flags.declaration_statement ? (C(this._flags.parent.mode) && (this._flags.declaration_assignment = !1), this._flags.declaration_assignment ? (this._flags.declaration_assignment = !1, this.print_newline(!1, !0)) : this._options.comma_first && this.allow_wrap_or_preserved_newline(e)) : this._flags.mode === w || this._flags.mode === v && this._flags.parent.mode === w ? (this._flags.mode === v && this.restore_mode(), this._flags.inline_frame || this.print_newline()) : this._options.comma_first && this.allow_wrap_or_preserved_newline(e)
                                }, T.prototype.handle_operator = function(e) {
                                    var t = "*" === e.text && (_(this._flags.last_token, ["function", "yield"]) || d(this._flags.last_token.type, [u.START_BLOCK, u.COMMA, u.END_BLOCK, u.SEMICOLON])),
                                        n = d(e.text, ["-", "+"]) && (d(this._flags.last_token.type, [u.START_BLOCK, u.START_EXPR, u.EQUALS, u.OPERATOR]) || d(this._flags.last_token.text, c) || "," === this._flags.last_token.text);
                                    if (this.start_of_statement(e));
                                    else {
                                        var i = !t;
                                        this.handle_whitespace_and_comments(e, i)
                                    }
                                    if ("*" !== e.text || this._flags.last_token.type !== u.DOT)
                                        if ("::" !== e.text)
                                            if (d(e.text, ["-", "+"]) && this.start_of_object_property()) this.print_token(e);
                                            else {
                                                if (this._flags.last_token.type === u.OPERATOR && d(this._options.operator_position, g) && this.allow_wrap_or_preserved_newline(e), ":" === e.text && this._flags.in_case) return this.print_token(e), this._flags.in_case = !1, this._flags.case_body = !0, void(this._tokens.peek().type !== u.START_BLOCK ? (this.indent(), this.print_newline(), this._flags.case_block = !1) : (this._flags.case_block = !0, this._output.space_before_token = !0));
                                                var s = !0,
                                                    a = !0,
                                                    o = !1;
                                                if (":" === e.text ? 0 === this._flags.ternary_depth ? s = !1 : (this._flags.ternary_depth -= 1, o = !0) : "?" === e.text && (this._flags.ternary_depth += 1), !n && !t && this._options.preserve_newlines && d(e.text, l)) {
                                                    var r = ":" === e.text,
                                                        h = r && o,
                                                        w = r && !o;
                                                    switch (this._options.operator_position) {
                                                        case f.before_newline:
                                                            return this._output.space_before_token = !w, this.print_token(e), r && !h || this.allow_wrap_or_preserved_newline(e), void(this._output.space_before_token = !0);
                                                        case f.after_newline:
                                                            return this._output.space_before_token = !0, !r || h ? this._tokens.peek().newlines ? this.print_newline(!1, !0) : this.allow_wrap_or_preserved_newline(e) : this._output.space_before_token = !1, this.print_token(e), void(this._output.space_before_token = !0);
                                                        case f.preserve_newline:
                                                            return w || this.allow_wrap_or_preserved_newline(e), s = !(this._output.just_added_newline() || w), this._output.space_before_token = s, this.print_token(e), void(this._output.space_before_token = !0)
                                                    }
                                                }
                                                if (t) {
                                                    this.allow_wrap_or_preserved_newline(e), s = !1;
                                                    var b = this._tokens.peek();
                                                    a = b && d(b.type, [u.WORD, u.RESERVED])
                                                } else if ("..." === e.text) this.allow_wrap_or_preserved_newline(e), s = this._flags.last_token.type === u.START_BLOCK, a = !1;
                                                else if (d(e.text, ["--", "++", "!", "~"]) || n) {
                                                    if (this._flags.last_token.type !== u.COMMA && this._flags.last_token.type !== u.START_EXPR || this.allow_wrap_or_preserved_newline(e), s = !1, a = !1, e.newlines && ("--" === e.text || "++" === e.text || "~" === e.text)) {
                                                        var k = _(this._flags.last_token, p) && e.newlines;
                                                        k && (this._previous_flags.if_block || this._previous_flags.else_block) && this.restore_mode(), this.print_newline(k, !0)
                                                    }
                                                    ";" === this._flags.last_token.text && C(this._flags.mode) && (s = !0), this._flags.last_token.type === u.RESERVED ? s = !0 : this._flags.last_token.type === u.END_EXPR ? s = !("]" === this._flags.last_token.text && ("--" === e.text || "++" === e.text)) : this._flags.last_token.type === u.OPERATOR && (s = d(e.text, ["--", "-", "++", "+"]) && d(this._flags.last_token.text, ["--", "-", "++", "+"]), d(e.text, ["+", "-"]) && d(this._flags.last_token.text, ["--", "++"]) && (a = !0)), (this._flags.mode !== m || this._flags.inline_frame) && this._flags.mode !== v || "{" !== this._flags.last_token.text && ";" !== this._flags.last_token.text || this.print_newline()
                                                }
                                                this._output.space_before_token = this._output.space_before_token || s, this.print_token(e), this._output.space_before_token = a
                                            }
                                    else this.print_token(e);
                                    else this.print_token(e)
                                }, T.prototype.handle_block_comment = function(e, t) {
                                    return this._output.raw ? (this._output.add_raw_token(e), void(e.directives && "end" === e.directives.preserve && (this._output.raw = this._options.test_output_raw))) : e.directives ? (this.print_newline(!1, t), this.print_token(e), "start" === e.directives.preserve && (this._output.raw = !0), void this.print_newline(!1, !0)) : a.newline.test(e.text) || e.newlines ? void this.print_block_commment(e, t) : (this._output.space_before_token = !0, this.print_token(e), void(this._output.space_before_token = !0))
                                }, T.prototype.print_block_commment = function(e, t) {
                                    var n, i = function(e) {
                                            for (var t = [], n = (e = e.replace(a.allLineBreaks, "\n")).indexOf("\n"); - 1 !== n;) t.push(e.substring(0, n)), n = (e = e.substring(n + 1)).indexOf("\n");
                                            return e.length && t.push(e), t
                                        }(e.text),
                                        s = !1,
                                        o = !1,
                                        r = e.whitespace_before,
                                        c = r.length;
                                    if (this.print_newline(!1, t), this.print_token_line_indentation(e), this._output.add_token(i[0]), this.print_newline(!1, t), i.length > 1) {
                                        for (s = function(e, t) {
                                                for (var n = 0; n < e.length; n++)
                                                    if (e[n].trim().charAt(0) !== t) return !1;
                                                return !0
                                            }(i = i.slice(1), "*"), o = function(e, t) {
                                                for (var n, i = 0, s = e.length; i < s; i++)
                                                    if ((n = e[i]) && 0 !== n.indexOf(t)) return !1;
                                                return !0
                                            }(i, r), s && (this._flags.alignment = 1), n = 0; n < i.length; n++) s ? (this.print_token_line_indentation(e), this._output.add_token(i[n].replace(/^\s+/g, ""))) : o && i[n] ? (this.print_token_line_indentation(e), this._output.add_token(i[n].substring(c))) : (this._output.current_line.set_indent(-1), this._output.add_token(i[n])), this.print_newline(!1, t);
                                        this._flags.alignment = 0
                                    }
                                }, T.prototype.handle_comment = function(e, t) {
                                    e.newlines ? this.print_newline(!1, t) : this._output.trim(!0), this._output.space_before_token = !0, this.print_token(e), this.print_newline(!1, t)
                                }, T.prototype.handle_dot = function(e) {
                                    this.start_of_statement(e) || this.handle_whitespace_and_comments(e, !0), this._flags.last_token.text.match("^[0-9]+$") && (this._output.space_before_token = !0), _(this._flags.last_token, p) ? this._output.space_before_token = !1 : this.allow_wrap_or_preserved_newline(e, ")" === this._flags.last_token.text && this._options.break_chained_methods), this._options.unindent_chained_methods && this._output.just_added_newline() && this.deindent(), this.print_token(e)
                                }, T.prototype.handle_unknown = function(e, t) {
                                    this.print_token(e), "\n" === e.text[e.text.length - 1] && this.print_newline(!1, t)
                                }, T.prototype.handle_eof = function(e) {
                                    for (; this._flags.mode === v;) this.restore_mode();
                                    this.handle_whitespace_and_comments(e)
                                }, e.exports.Beautifier = T
                            }, function(e) {
                                function t(e) {
                                    this.__parent = e, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = []
                                }

                                function n(e, t) {
                                    this.__cache = [""], this.__indent_size = e.indent_size, this.__indent_string = e.indent_char, e.indent_with_tabs || (this.__indent_string = new Array(e.indent_size + 1).join(e.indent_char)), t = t || "", e.indent_level > 0 && (t = new Array(e.indent_level + 1).join(this.__indent_string)), this.__base_string = t, this.__base_string_length = t.length
                                }

                                function i(e, i) {
                                    this.__indent_cache = new n(e, i), this.raw = !1, this._end_with_newline = e.end_with_newline, this.indent_size = e.indent_size, this.wrap_line_length = e.wrap_line_length, this.indent_empty_lines = e.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new t(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline()
                                }
                                t.prototype.clone_empty = function() {
                                    var e = new t(this.__parent);
                                    return e.set_indent(this.__indent_count, this.__alignment_count), e
                                }, t.prototype.item = function(e) {
                                    return e < 0 ? this.__items[this.__items.length + e] : this.__items[e]
                                }, t.prototype.has_match = function(e) {
                                    for (var t = this.__items.length - 1; t >= 0; t--)
                                        if (this.__items[t].match(e)) return !0;
                                    return !1
                                }, t.prototype.set_indent = function(e, t) {
                                    this.is_empty() && (this.__indent_count = e || 0, this.__alignment_count = t || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count))
                                }, t.prototype._set_wrap_point = function() {
                                    this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count)
                                }, t.prototype._should_wrap = function() {
                                    return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count
                                }, t.prototype._allow_wrap = function() {
                                    if (this._should_wrap()) {
                                        this.__parent.add_new_line();
                                        var e = this.__parent.current_line;
                                        return e.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), e.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), e.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, " " === e.__items[0] && (e.__items.splice(0, 1), e.__character_count -= 1), !0
                                    }
                                    return !1
                                }, t.prototype.is_empty = function() {
                                    return 0 === this.__items.length
                                }, t.prototype.last = function() {
                                    return this.is_empty() ? null : this.__items[this.__items.length - 1]
                                }, t.prototype.push = function(e) {
                                    this.__items.push(e);
                                    var t = e.lastIndexOf("\n"); - 1 !== t ? this.__character_count = e.length - t : this.__character_count += e.length
                                }, t.prototype.pop = function() {
                                    var e = null;
                                    return this.is_empty() || (e = this.__items.pop(), this.__character_count -= e.length), e
                                }, t.prototype._remove_indent = function() {
                                    this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size)
                                }, t.prototype._remove_wrap_indent = function() {
                                    this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1)
                                }, t.prototype.trim = function() {
                                    for (;
                                        " " === this.last();) this.__items.pop(), this.__character_count -= 1
                                }, t.prototype.toString = function() {
                                    var e = "";
                                    return this.is_empty() ? this.__parent.indent_empty_lines && (e = this.__parent.get_indent_string(this.__indent_count)) : (e = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), e += this.__items.join("")), e
                                }, n.prototype.get_indent_size = function(e, t) {
                                    var n = this.__base_string_length;
                                    return t = t || 0, e < 0 && (n = 0), n += e * this.__indent_size, n += t
                                }, n.prototype.get_indent_string = function(e, t) {
                                    var n = this.__base_string;
                                    return t = t || 0, e < 0 && (e = 0, n = ""), t += e * this.__indent_size, this.__ensure_cache(t), n += this.__cache[t]
                                }, n.prototype.__ensure_cache = function(e) {
                                    for (; e >= this.__cache.length;) this.__add_column()
                                }, n.prototype.__add_column = function() {
                                    var e = this.__cache.length,
                                        t = 0,
                                        n = "";
                                    this.__indent_size && e >= this.__indent_size && (e -= (t = Math.floor(e / this.__indent_size)) * this.__indent_size, n = new Array(t + 1).join(this.__indent_string)), e && (n += new Array(e + 1).join(" ")), this.__cache.push(n)
                                }, i.prototype.__add_outputline = function() {
                                    this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line)
                                }, i.prototype.get_line_number = function() {
                                    return this.__lines.length
                                }, i.prototype.get_indent_string = function(e, t) {
                                    return this.__indent_cache.get_indent_string(e, t)
                                }, i.prototype.get_indent_size = function(e, t) {
                                    return this.__indent_cache.get_indent_size(e, t)
                                }, i.prototype.is_empty = function() {
                                    return !this.previous_line && this.current_line.is_empty()
                                }, i.prototype.add_new_line = function(e) {
                                    return !(this.is_empty() || !e && this.just_added_newline()) && (this.raw || this.__add_outputline(), !0)
                                }, i.prototype.get_code = function(e) {
                                    this.trim(!0);
                                    var t = this.current_line.pop();
                                    t && ("\n" === t[t.length - 1] && (t = t.replace(/\n+$/g, "")), this.current_line.push(t)), this._end_with_newline && this.__add_outputline();
                                    var n = this.__lines.join("\n");
                                    return "\n" !== e && (n = n.replace(/[\n]/g, e)), n
                                }, i.prototype.set_wrap_point = function() {
                                    this.current_line._set_wrap_point()
                                }, i.prototype.set_indent = function(e, t) {
                                    return e = e || 0, t = t || 0, this.next_line.set_indent(e, t), this.__lines.length > 1 ? (this.current_line.set_indent(e, t), !0) : (this.current_line.set_indent(), !1)
                                }, i.prototype.add_raw_token = function(e) {
                                    for (var t = 0; t < e.newlines; t++) this.__add_outputline();
                                    this.current_line.set_indent(-1), this.current_line.push(e.whitespace_before), this.current_line.push(e.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1
                                }, i.prototype.add_token = function(e) {
                                    this.__add_space_before_token(), this.current_line.push(e), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap()
                                }, i.prototype.__add_space_before_token = function() {
                                    this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "))
                                }, i.prototype.remove_indent = function(e) {
                                    for (var t = this.__lines.length; e < t;) this.__lines[e]._remove_indent(), e++;
                                    this.current_line._remove_wrap_indent()
                                }, i.prototype.trim = function(e) {
                                    for (e = void 0 !== e && e, this.current_line.trim(); e && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
                                    this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null
                                }, i.prototype.just_added_newline = function() {
                                    return this.current_line.is_empty()
                                }, i.prototype.just_added_blankline = function() {
                                    return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty()
                                }, i.prototype.ensure_empty_line_above = function(e, n) {
                                    for (var i = this.__lines.length - 2; i >= 0;) {
                                        var s = this.__lines[i];
                                        if (s.is_empty()) break;
                                        if (0 !== s.item(0).indexOf(e) && s.item(-1) !== n) {
                                            this.__lines.splice(i + 1, 0, new t(this)), this.previous_line = this.__lines[this.__lines.length - 2];
                                            break
                                        }
                                        i--
                                    }
                                }, e.exports.Output = i
                            }, function(e) {
                                e.exports.Token = function(e, t, n, i) {
                                    this.type = e, this.text = t, this.comments_before = null, this.newlines = n || 0, this.whitespace_before = i || "", this.parent = null, this.next = null, this.previous = null, this.opened = null, this.closed = null, this.directives = null
                                }
                            }, function(e, t) {
                                var n = "\\x24\\x30-\\x39\\x41-\\x5a\\x5f\\x61-\\x7a",
                                    i = "\\xaa\\xb5\\xba\\xc0-\\xd6\\xd8-\\xf6\\xf8-\\u02c1\\u02c6-\\u02d1\\u02e0-\\u02e4\\u02ec\\u02ee\\u0370-\\u0374\\u0376\\u0377\\u037a-\\u037d\\u0386\\u0388-\\u038a\\u038c\\u038e-\\u03a1\\u03a3-\\u03f5\\u03f7-\\u0481\\u048a-\\u0527\\u0531-\\u0556\\u0559\\u0561-\\u0587\\u05d0-\\u05ea\\u05f0-\\u05f2\\u0620-\\u064a\\u066e\\u066f\\u0671-\\u06d3\\u06d5\\u06e5\\u06e6\\u06ee\\u06ef\\u06fa-\\u06fc\\u06ff\\u0710\\u0712-\\u072f\\u074d-\\u07a5\\u07b1\\u07ca-\\u07ea\\u07f4\\u07f5\\u07fa\\u0800-\\u0815\\u081a\\u0824\\u0828\\u0840-\\u0858\\u08a0\\u08a2-\\u08ac\\u0904-\\u0939\\u093d\\u0950\\u0958-\\u0961\\u0971-\\u0977\\u0979-\\u097f\\u0985-\\u098c\\u098f\\u0990\\u0993-\\u09a8\\u09aa-\\u09b0\\u09b2\\u09b6-\\u09b9\\u09bd\\u09ce\\u09dc\\u09dd\\u09df-\\u09e1\\u09f0\\u09f1\\u0a05-\\u0a0a\\u0a0f\\u0a10\\u0a13-\\u0a28\\u0a2a-\\u0a30\\u0a32\\u0a33\\u0a35\\u0a36\\u0a38\\u0a39\\u0a59-\\u0a5c\\u0a5e\\u0a72-\\u0a74\\u0a85-\\u0a8d\\u0a8f-\\u0a91\\u0a93-\\u0aa8\\u0aaa-\\u0ab0\\u0ab2\\u0ab3\\u0ab5-\\u0ab9\\u0abd\\u0ad0\\u0ae0\\u0ae1\\u0b05-\\u0b0c\\u0b0f\\u0b10\\u0b13-\\u0b28\\u0b2a-\\u0b30\\u0b32\\u0b33\\u0b35-\\u0b39\\u0b3d\\u0b5c\\u0b5d\\u0b5f-\\u0b61\\u0b71\\u0b83\\u0b85-\\u0b8a\\u0b8e-\\u0b90\\u0b92-\\u0b95\\u0b99\\u0b9a\\u0b9c\\u0b9e\\u0b9f\\u0ba3\\u0ba4\\u0ba8-\\u0baa\\u0bae-\\u0bb9\\u0bd0\\u0c05-\\u0c0c\\u0c0e-\\u0c10\\u0c12-\\u0c28\\u0c2a-\\u0c33\\u0c35-\\u0c39\\u0c3d\\u0c58\\u0c59\\u0c60\\u0c61\\u0c85-\\u0c8c\\u0c8e-\\u0c90\\u0c92-\\u0ca8\\u0caa-\\u0cb3\\u0cb5-\\u0cb9\\u0cbd\\u0cde\\u0ce0\\u0ce1\\u0cf1\\u0cf2\\u0d05-\\u0d0c\\u0d0e-\\u0d10\\u0d12-\\u0d3a\\u0d3d\\u0d4e\\u0d60\\u0d61\\u0d7a-\\u0d7f\\u0d85-\\u0d96\\u0d9a-\\u0db1\\u0db3-\\u0dbb\\u0dbd\\u0dc0-\\u0dc6\\u0e01-\\u0e30\\u0e32\\u0e33\\u0e40-\\u0e46\\u0e81\\u0e82\\u0e84\\u0e87\\u0e88\\u0e8a\\u0e8d\\u0e94-\\u0e97\\u0e99-\\u0e9f\\u0ea1-\\u0ea3\\u0ea5\\u0ea7\\u0eaa\\u0eab\\u0ead-\\u0eb0\\u0eb2\\u0eb3\\u0ebd\\u0ec0-\\u0ec4\\u0ec6\\u0edc-\\u0edf\\u0f00\\u0f40-\\u0f47\\u0f49-\\u0f6c\\u0f88-\\u0f8c\\u1000-\\u102a\\u103f\\u1050-\\u1055\\u105a-\\u105d\\u1061\\u1065\\u1066\\u106e-\\u1070\\u1075-\\u1081\\u108e\\u10a0-\\u10c5\\u10c7\\u10cd\\u10d0-\\u10fa\\u10fc-\\u1248\\u124a-\\u124d\\u1250-\\u1256\\u1258\\u125a-\\u125d\\u1260-\\u1288\\u128a-\\u128d\\u1290-\\u12b0\\u12b2-\\u12b5\\u12b8-\\u12be\\u12c0\\u12c2-\\u12c5\\u12c8-\\u12d6\\u12d8-\\u1310\\u1312-\\u1315\\u1318-\\u135a\\u1380-\\u138f\\u13a0-\\u13f4\\u1401-\\u166c\\u166f-\\u167f\\u1681-\\u169a\\u16a0-\\u16ea\\u16ee-\\u16f0\\u1700-\\u170c\\u170e-\\u1711\\u1720-\\u1731\\u1740-\\u1751\\u1760-\\u176c\\u176e-\\u1770\\u1780-\\u17b3\\u17d7\\u17dc\\u1820-\\u1877\\u1880-\\u18a8\\u18aa\\u18b0-\\u18f5\\u1900-\\u191c\\u1950-\\u196d\\u1970-\\u1974\\u1980-\\u19ab\\u19c1-\\u19c7\\u1a00-\\u1a16\\u1a20-\\u1a54\\u1aa7\\u1b05-\\u1b33\\u1b45-\\u1b4b\\u1b83-\\u1ba0\\u1bae\\u1baf\\u1bba-\\u1be5\\u1c00-\\u1c23\\u1c4d-\\u1c4f\\u1c5a-\\u1c7d\\u1ce9-\\u1cec\\u1cee-\\u1cf1\\u1cf5\\u1cf6\\u1d00-\\u1dbf\\u1e00-\\u1f15\\u1f18-\\u1f1d\\u1f20-\\u1f45\\u1f48-\\u1f4d\\u1f50-\\u1f57\\u1f59\\u1f5b\\u1f5d\\u1f5f-\\u1f7d\\u1f80-\\u1fb4\\u1fb6-\\u1fbc\\u1fbe\\u1fc2-\\u1fc4\\u1fc6-\\u1fcc\\u1fd0-\\u1fd3\\u1fd6-\\u1fdb\\u1fe0-\\u1fec\\u1ff2-\\u1ff4\\u1ff6-\\u1ffc\\u2071\\u207f\\u2090-\\u209c\\u2102\\u2107\\u210a-\\u2113\\u2115\\u2119-\\u211d\\u2124\\u2126\\u2128\\u212a-\\u212d\\u212f-\\u2139\\u213c-\\u213f\\u2145-\\u2149\\u214e\\u2160-\\u2188\\u2c00-\\u2c2e\\u2c30-\\u2c5e\\u2c60-\\u2ce4\\u2ceb-\\u2cee\\u2cf2\\u2cf3\\u2d00-\\u2d25\\u2d27\\u2d2d\\u2d30-\\u2d67\\u2d6f\\u2d80-\\u2d96\\u2da0-\\u2da6\\u2da8-\\u2dae\\u2db0-\\u2db6\\u2db8-\\u2dbe\\u2dc0-\\u2dc6\\u2dc8-\\u2dce\\u2dd0-\\u2dd6\\u2dd8-\\u2dde\\u2e2f\\u3005-\\u3007\\u3021-\\u3029\\u3031-\\u3035\\u3038-\\u303c\\u3041-\\u3096\\u309d-\\u309f\\u30a1-\\u30fa\\u30fc-\\u30ff\\u3105-\\u312d\\u3131-\\u318e\\u31a0-\\u31ba\\u31f0-\\u31ff\\u3400-\\u4db5\\u4e00-\\u9fcc\\ua000-\\ua48c\\ua4d0-\\ua4fd\\ua500-\\ua60c\\ua610-\\ua61f\\ua62a\\ua62b\\ua640-\\ua66e\\ua67f-\\ua697\\ua6a0-\\ua6ef\\ua717-\\ua71f\\ua722-\\ua788\\ua78b-\\ua78e\\ua790-\\ua793\\ua7a0-\\ua7aa\\ua7f8-\\ua801\\ua803-\\ua805\\ua807-\\ua80a\\ua80c-\\ua822\\ua840-\\ua873\\ua882-\\ua8b3\\ua8f2-\\ua8f7\\ua8fb\\ua90a-\\ua925\\ua930-\\ua946\\ua960-\\ua97c\\ua984-\\ua9b2\\ua9cf\\uaa00-\\uaa28\\uaa40-\\uaa42\\uaa44-\\uaa4b\\uaa60-\\uaa76\\uaa7a\\uaa80-\\uaaaf\\uaab1\\uaab5\\uaab6\\uaab9-\\uaabd\\uaac0\\uaac2\\uaadb-\\uaadd\\uaae0-\\uaaea\\uaaf2-\\uaaf4\\uab01-\\uab06\\uab09-\\uab0e\\uab11-\\uab16\\uab20-\\uab26\\uab28-\\uab2e\\uabc0-\\uabe2\\uac00-\\ud7a3\\ud7b0-\\ud7c6\\ud7cb-\\ud7fb\\uf900-\\ufa6d\\ufa70-\\ufad9\\ufb00-\\ufb06\\ufb13-\\ufb17\\ufb1d\\ufb1f-\\ufb28\\ufb2a-\\ufb36\\ufb38-\\ufb3c\\ufb3e\\ufb40\\ufb41\\ufb43\\ufb44\\ufb46-\\ufbb1\\ufbd3-\\ufd3d\\ufd50-\\ufd8f\\ufd92-\\ufdc7\\ufdf0-\\ufdfb\\ufe70-\\ufe74\\ufe76-\\ufefc\\uff21-\\uff3a\\uff41-\\uff5a\\uff66-\\uffbe\\uffc2-\\uffc7\\uffca-\\uffcf\\uffd2-\\uffd7\\uffda-\\uffdc",
                                    s = "\\u0300-\\u036f\\u0483-\\u0487\\u0591-\\u05bd\\u05bf\\u05c1\\u05c2\\u05c4\\u05c5\\u05c7\\u0610-\\u061a\\u0620-\\u0649\\u0672-\\u06d3\\u06e7-\\u06e8\\u06fb-\\u06fc\\u0730-\\u074a\\u0800-\\u0814\\u081b-\\u0823\\u0825-\\u0827\\u0829-\\u082d\\u0840-\\u0857\\u08e4-\\u08fe\\u0900-\\u0903\\u093a-\\u093c\\u093e-\\u094f\\u0951-\\u0957\\u0962-\\u0963\\u0966-\\u096f\\u0981-\\u0983\\u09bc\\u09be-\\u09c4\\u09c7\\u09c8\\u09d7\\u09df-\\u09e0\\u0a01-\\u0a03\\u0a3c\\u0a3e-\\u0a42\\u0a47\\u0a48\\u0a4b-\\u0a4d\\u0a51\\u0a66-\\u0a71\\u0a75\\u0a81-\\u0a83\\u0abc\\u0abe-\\u0ac5\\u0ac7-\\u0ac9\\u0acb-\\u0acd\\u0ae2-\\u0ae3\\u0ae6-\\u0aef\\u0b01-\\u0b03\\u0b3c\\u0b3e-\\u0b44\\u0b47\\u0b48\\u0b4b-\\u0b4d\\u0b56\\u0b57\\u0b5f-\\u0b60\\u0b66-\\u0b6f\\u0b82\\u0bbe-\\u0bc2\\u0bc6-\\u0bc8\\u0bca-\\u0bcd\\u0bd7\\u0be6-\\u0bef\\u0c01-\\u0c03\\u0c46-\\u0c48\\u0c4a-\\u0c4d\\u0c55\\u0c56\\u0c62-\\u0c63\\u0c66-\\u0c6f\\u0c82\\u0c83\\u0cbc\\u0cbe-\\u0cc4\\u0cc6-\\u0cc8\\u0cca-\\u0ccd\\u0cd5\\u0cd6\\u0ce2-\\u0ce3\\u0ce6-\\u0cef\\u0d02\\u0d03\\u0d46-\\u0d48\\u0d57\\u0d62-\\u0d63\\u0d66-\\u0d6f\\u0d82\\u0d83\\u0dca\\u0dcf-\\u0dd4\\u0dd6\\u0dd8-\\u0ddf\\u0df2\\u0df3\\u0e34-\\u0e3a\\u0e40-\\u0e45\\u0e50-\\u0e59\\u0eb4-\\u0eb9\\u0ec8-\\u0ecd\\u0ed0-\\u0ed9\\u0f18\\u0f19\\u0f20-\\u0f29\\u0f35\\u0f37\\u0f39\\u0f41-\\u0f47\\u0f71-\\u0f84\\u0f86-\\u0f87\\u0f8d-\\u0f97\\u0f99-\\u0fbc\\u0fc6\\u1000-\\u1029\\u1040-\\u1049\\u1067-\\u106d\\u1071-\\u1074\\u1082-\\u108d\\u108f-\\u109d\\u135d-\\u135f\\u170e-\\u1710\\u1720-\\u1730\\u1740-\\u1750\\u1772\\u1773\\u1780-\\u17b2\\u17dd\\u17e0-\\u17e9\\u180b-\\u180d\\u1810-\\u1819\\u1920-\\u192b\\u1930-\\u193b\\u1951-\\u196d\\u19b0-\\u19c0\\u19c8-\\u19c9\\u19d0-\\u19d9\\u1a00-\\u1a15\\u1a20-\\u1a53\\u1a60-\\u1a7c\\u1a7f-\\u1a89\\u1a90-\\u1a99\\u1b46-\\u1b4b\\u1b50-\\u1b59\\u1b6b-\\u1b73\\u1bb0-\\u1bb9\\u1be6-\\u1bf3\\u1c00-\\u1c22\\u1c40-\\u1c49\\u1c5b-\\u1c7d\\u1cd0-\\u1cd2\\u1d00-\\u1dbe\\u1e01-\\u1f15\\u200c\\u200d\\u203f\\u2040\\u2054\\u20d0-\\u20dc\\u20e1\\u20e5-\\u20f0\\u2d81-\\u2d96\\u2de0-\\u2dff\\u3021-\\u3028\\u3099\\u309a\\ua640-\\ua66d\\ua674-\\ua67d\\ua69f\\ua6f0-\\ua6f1\\ua7f8-\\ua800\\ua806\\ua80b\\ua823-\\ua827\\ua880-\\ua881\\ua8b4-\\ua8c4\\ua8d0-\\ua8d9\\ua8f3-\\ua8f7\\ua900-\\ua909\\ua926-\\ua92d\\ua930-\\ua945\\ua980-\\ua983\\ua9b3-\\ua9c0\\uaa00-\\uaa27\\uaa40-\\uaa41\\uaa4c-\\uaa4d\\uaa50-\\uaa59\\uaa7b\\uaae0-\\uaae9\\uaaf2-\\uaaf3\\uabc0-\\uabe1\\uabec\\uabed\\uabf0-\\uabf9\\ufb20-\\ufb28\\ufe00-\\ufe0f\\ufe20-\\ufe26\\ufe33\\ufe34\\ufe4d-\\ufe4f\\uff10-\\uff19\\uff3f",
                                    a = "\\\\u[0-9a-fA-F]{4}|\\\\u\\{[0-9a-fA-F]+\\}",
                                    o = "(?:" + a + "|[\\x23\\x24\\x40\\x41-\\x5a\\x5f\\x61-\\x7a" + i + "])",
                                    r = "(?:" + a + "|[" + n + i + s + "])*";
                                t.identifier = new RegExp(o + r, "g"), t.identifierStart = new RegExp(o), t.identifierMatch = new RegExp("(?:" + a + "|[" + n + i + s + "])+");
                                t.newline = /[\n\r\u2028\u2029]/, t.lineBreak = new RegExp("\r\n|" + t.newline.source), t.allLineBreaks = new RegExp(t.lineBreak.source, "g")
                            }, function(e, t, n) {
                                var i = n(6).Options,
                                    s = ["before-newline", "after-newline", "preserve-newline"];

                                function a(e) {
                                    i.call(this, e, "js");
                                    var t = this.raw_options.brace_style || null;
                                    "expand-strict" === t ? this.raw_options.brace_style = "expand" : "collapse-preserve-inline" === t ? this.raw_options.brace_style = "collapse,preserve-inline" : void 0 !== this.raw_options.braces_on_own_line && (this.raw_options.brace_style = this.raw_options.braces_on_own_line ? "expand" : "collapse");
                                    var n = this._get_selection_list("brace_style", ["collapse", "expand", "end-expand", "none", "preserve-inline"]);
                                    this.brace_preserve_inline = !1, this.brace_style = "collapse";
                                    for (var a = 0; a < n.length; a++) "preserve-inline" === n[a] ? this.brace_preserve_inline = !0 : this.brace_style = n[a];
                                    this.unindent_chained_methods = this._get_boolean("unindent_chained_methods"), this.break_chained_methods = this._get_boolean("break_chained_methods"), this.space_in_paren = this._get_boolean("space_in_paren"), this.space_in_empty_paren = this._get_boolean("space_in_empty_paren"), this.jslint_happy = this._get_boolean("jslint_happy"), this.space_after_anon_function = this._get_boolean("space_after_anon_function"), this.space_after_named_function = this._get_boolean("space_after_named_function"), this.keep_array_indentation = this._get_boolean("keep_array_indentation"), this.space_before_conditional = this._get_boolean("space_before_conditional", !0), this.unescape_strings = this._get_boolean("unescape_strings"), this.e4x = this._get_boolean("e4x"), this.comma_first = this._get_boolean("comma_first"), this.operator_position = this._get_selection("operator_position", s), this.test_output_raw = this._get_boolean("test_output_raw"), this.jslint_happy && (this.space_after_anon_function = !0)
                                }
                                a.prototype = new i, e.exports.Options = a
                            }, function(e) {
                                function t(e, t) {
                                    this.raw_options = n(e, t), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", "\t" === this.indent_char), this.indent_with_tabs && (this.indent_char = "\t", 1 === this.indent_size && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", ["auto", "none", "angular", "django", "erb", "handlebars", "php", "smarty"], ["auto"])
                                }

                                function n(e, t) {
                                    var n, s = {};
                                    for (n in e = i(e)) n !== t && (s[n] = e[n]);
                                    if (t && e[t])
                                        for (n in e[t]) s[n] = e[t][n];
                                    return s
                                }

                                function i(e) {
                                    var t, n = {};
                                    for (t in e) {
                                        n[t.replace(/-/g, "_")] = e[t]
                                    }
                                    return n
                                }
                                t.prototype._get_array = function(e, t) {
                                    var n = this.raw_options[e],
                                        i = t || [];
                                    return "object" == typeof n ? null !== n && "function" == typeof n.concat && (i = n.concat()) : "string" == typeof n && (i = n.split(/[^a-zA-Z0-9_\/\-]+/)), i
                                }, t.prototype._get_boolean = function(e, t) {
                                    var n = this.raw_options[e];
                                    return void 0 === n ? !!t : !!n
                                }, t.prototype._get_characters = function(e, t) {
                                    var n = this.raw_options[e],
                                        i = t || "";
                                    return "string" == typeof n && (i = n.replace(/\\r/, "\r").replace(/\\n/, "\n").replace(/\\t/, "\t")), i
                                }, t.prototype._get_number = function(e, t) {
                                    var n = this.raw_options[e];
                                    t = parseInt(t, 10), isNaN(t) && (t = 0);
                                    var i = parseInt(n, 10);
                                    return isNaN(i) && (i = t), i
                                }, t.prototype._get_selection = function(e, t, n) {
                                    var i = this._get_selection_list(e, t, n);
                                    if (1 !== i.length) throw new Error("Invalid Option Value: The option '" + e + "' can only be one of the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
                                    return i[0]
                                }, t.prototype._get_selection_list = function(e, t, n) {
                                    if (!t || 0 === t.length) throw new Error("Selection list cannot be empty.");
                                    if (n = n || [t[0]], !this._is_valid_selection(n, t)) throw new Error("Invalid Default Value!");
                                    var i = this._get_array(e, n);
                                    if (!this._is_valid_selection(i, t)) throw new Error("Invalid Option Value: The option '" + e + "' can contain only the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
                                    return i
                                }, t.prototype._is_valid_selection = function(e, t) {
                                    return e.length && t.length && !e.some((function(e) {
                                        return -1 === t.indexOf(e)
                                    }))
                                }, e.exports.Options = t, e.exports.normalizeOpts = i, e.exports.mergeOpts = n
                            }, function(e, t, n) {
                                var i = n(8).InputScanner,
                                    s = n(9).Tokenizer,
                                    a = n(9).TOKEN,
                                    o = n(13).Directives,
                                    r = n(4),
                                    c = n(12).Pattern,
                                    l = n(14).TemplatablePattern;

                                function u(e, t) {
                                    return -1 !== t.indexOf(e)
                                }
                                var d = {
                                        START_EXPR: "TK_START_EXPR",
                                        END_EXPR: "TK_END_EXPR",
                                        START_BLOCK: "TK_START_BLOCK",
                                        END_BLOCK: "TK_END_BLOCK",
                                        WORD: "TK_WORD",
                                        RESERVED: "TK_RESERVED",
                                        SEMICOLON: "TK_SEMICOLON",
                                        STRING: "TK_STRING",
                                        EQUALS: "TK_EQUALS",
                                        OPERATOR: "TK_OPERATOR",
                                        COMMA: "TK_COMMA",
                                        BLOCK_COMMENT: "TK_BLOCK_COMMENT",
                                        COMMENT: "TK_COMMENT",
                                        DOT: "TK_DOT",
                                        UNKNOWN: "TK_UNKNOWN",
                                        START: a.START,
                                        RAW: a.RAW,
                                        EOF: a.EOF
                                    },
                                    h = new o(/\/\*/, /\*\//),
                                    _ = /0[xX][0123456789abcdefABCDEF_]*n?|0[oO][01234567_]*n?|0[bB][01_]*n?|\d[\d_]*n|(?:\.\d[\d_]*|\d[\d_]*\.?[\d_]*)(?:[eE][+-]?[\d_]+)?/,
                                    p = /[0-9]/,
                                    f = /[^\d\.]/,
                                    g = ">>> === !== &&= ??= ||= << && >= ** != == <= >> || ?? |> < / - + > : & % ? ^ | *".split(" "),
                                    m = ">>>= ... >>= <<= === >>> !== **= &&= ??= ||= => ^= :: /= << <= == && -= >= >> != -- += ** || ?? ++ %= &= *= |= |> = ! ? > < : / ^ - + * & % ~ |";
                                m = (m = "\\?\\.(?!\\d) " + (m = m.replace(/[-[\]{}()*+?.,\\^$|#]/g, "\\$&"))).replace(/ /g, "|");
                                var v, w = new RegExp(m),
                                    b = "continue,try,throw,return,var,let,const,if,switch,case,default,for,while,break,function,import,export".split(","),
                                    k = b.concat(["do", "in", "of", "else", "get", "set", "new", "catch", "finally", "typeof", "yield", "async", "await", "from", "as", "class", "extends"]),
                                    y = new RegExp("^(?:" + k.join("|") + ")$"),
                                    x = function(e, t) {
                                        s.call(this, e, t), this._patterns.whitespace = this._patterns.whitespace.matching(/\u00A0\u1680\u180e\u2000-\u200a\u202f\u205f\u3000\ufeff/.source, /\u2028\u2029/.source);
                                        var n = new c(this._input),
                                            i = new l(this._input).read_options(this._options);
                                        this.__patterns = {
                                            template: i,
                                            identifier: i.starting_with(r.identifier).matching(r.identifierMatch),
                                            number: n.matching(_),
                                            punct: n.matching(w),
                                            comment: n.starting_with(/\/\//).until(/[\n\r\u2028\u2029]/),
                                            block_comment: n.starting_with(/\/\*/).until_after(/\*\//),
                                            html_comment_start: n.matching(/<!--/),
                                            html_comment_end: n.matching(/-->/),
                                            include: n.starting_with(/#include/).until_after(r.lineBreak),
                                            shebang: n.starting_with(/#!/).until_after(r.lineBreak),
                                            xml: n.matching(/[\s\S]*?<(\/?)([-a-zA-Z:0-9_.]+|{[^}]+?}|!\[CDATA\[[^\]]*?\]\]|)(\s*{[^}]+?}|\s+[-a-zA-Z:0-9_.]+|\s+[-a-zA-Z:0-9_.]+\s*=\s*('[^']*'|"[^"]*"|{([^{}]|{[^}]+?})+?}))*\s*(\/?)\s*>/),
                                            single_quote: i.until(/['\\\n\r\u2028\u2029]/),
                                            double_quote: i.until(/["\\\n\r\u2028\u2029]/),
                                            template_text: i.until(/[`\\$]/),
                                            template_expression: i.until(/[`}\\]/)
                                        }
                                    };
                                (x.prototype = new s)._is_comment = function(e) {
                                    return e.type === d.COMMENT || e.type === d.BLOCK_COMMENT || e.type === d.UNKNOWN
                                }, x.prototype._is_opening = function(e) {
                                    return e.type === d.START_BLOCK || e.type === d.START_EXPR
                                }, x.prototype._is_closing = function(e, t) {
                                    return (e.type === d.END_BLOCK || e.type === d.END_EXPR) && t && ("]" === e.text && "[" === t.text || ")" === e.text && "(" === t.text || "}" === e.text && "{" === t.text)
                                }, x.prototype._reset = function() {
                                    v = !1
                                }, x.prototype._get_next_token = function(e, t) {
                                    var n = null;
                                    this._readWhitespace();
                                    var i = this._input.peek();
                                    return null === i ? this._create_token(d.EOF, "") : n = (n = (n = (n = (n = (n = (n = (n = (n = (n = n || this._read_non_javascript(i)) || this._read_string(i)) || this._read_pair(i, this._input.peek(1))) || this._read_word(e)) || this._read_singles(i)) || this._read_comment(i)) || this._read_regexp(i, e)) || this._read_xml(i, e)) || this._read_punctuation()) || this._create_token(d.UNKNOWN, this._input.next())
                                }, x.prototype._read_word = function(e) {
                                    var t;
                                    return "" !== (t = this.__patterns.identifier.read()) ? (t = t.replace(r.allLineBreaks, "\n"), e.type !== d.DOT && (e.type !== d.RESERVED || "set" !== e.text && "get" !== e.text) && y.test(t) ? "in" !== t && "of" !== t || e.type !== d.WORD && e.type !== d.STRING ? this._create_token(d.RESERVED, t) : this._create_token(d.OPERATOR, t) : this._create_token(d.WORD, t)) : "" !== (t = this.__patterns.number.read()) ? this._create_token(d.WORD, t) : void 0
                                }, x.prototype._read_singles = function(e) {
                                    var t = null;
                                    return "(" === e || "[" === e ? t = this._create_token(d.START_EXPR, e) : ")" === e || "]" === e ? t = this._create_token(d.END_EXPR, e) : "{" === e ? t = this._create_token(d.START_BLOCK, e) : "}" === e ? t = this._create_token(d.END_BLOCK, e) : ";" === e ? t = this._create_token(d.SEMICOLON, e) : "." === e && f.test(this._input.peek(1)) ? t = this._create_token(d.DOT, e) : "," === e && (t = this._create_token(d.COMMA, e)), t && this._input.next(), t
                                }, x.prototype._read_pair = function(e, t) {
                                    var n = null;
                                    return "#" === e && "{" === t && (n = this._create_token(d.START_BLOCK, e + t)), n && (this._input.next(), this._input.next()), n
                                }, x.prototype._read_punctuation = function() {
                                    var e = this.__patterns.punct.read();
                                    if ("" !== e) return "=" === e ? this._create_token(d.EQUALS, e) : "?." === e ? this._create_token(d.DOT, e) : this._create_token(d.OPERATOR, e)
                                }, x.prototype._read_non_javascript = function(e) {
                                    var t = "";
                                    if ("#" === e) {
                                        if (this._is_first_token() && (t = this.__patterns.shebang.read())) return this._create_token(d.UNKNOWN, t.trim() + "\n");
                                        if (t = this.__patterns.include.read()) return this._create_token(d.UNKNOWN, t.trim() + "\n");
                                        e = this._input.next();
                                        var n = "#";
                                        if (this._input.hasNext() && this._input.testChar(p)) {
                                            do {
                                                n += e = this._input.next()
                                            } while (this._input.hasNext() && "#" !== e && "=" !== e);
                                            return "#" === e || ("[" === this._input.peek() && "]" === this._input.peek(1) ? (n += "[]", this._input.next(), this._input.next()) : "{" === this._input.peek() && "}" === this._input.peek(1) && (n += "{}", this._input.next(), this._input.next())), this._create_token(d.WORD, n)
                                        }
                                        this._input.back()
                                    } else if ("<" === e && this._is_first_token()) {
                                        if (t = this.__patterns.html_comment_start.read()) {
                                            for (; this._input.hasNext() && !this._input.testChar(r.newline);) t += this._input.next();
                                            return v = !0, this._create_token(d.COMMENT, t)
                                        }
                                    } else if (v && "-" === e && (t = this.__patterns.html_comment_end.read())) return v = !1, this._create_token(d.COMMENT, t);
                                    return null
                                }, x.prototype._read_comment = function(e) {
                                    var t = null;
                                    if ("/" === e) {
                                        var n = "";
                                        if ("*" === this._input.peek(1)) {
                                            n = this.__patterns.block_comment.read();
                                            var i = h.get_directives(n);
                                            i && "start" === i.ignore && (n += h.readIgnored(this._input)), n = n.replace(r.allLineBreaks, "\n"), (t = this._create_token(d.BLOCK_COMMENT, n)).directives = i
                                        } else "/" === this._input.peek(1) && (n = this.__patterns.comment.read(), t = this._create_token(d.COMMENT, n))
                                    }
                                    return t
                                }, x.prototype._read_string = function(e) {
                                    if ("`" === e || "'" === e || '"' === e) {
                                        var t = this._input.next();
                                        return this.has_char_escapes = !1, t += "`" === e ? this._read_string_recursive("`", !0, "${") : this._read_string_recursive(e), this.has_char_escapes && this._options.unescape_strings && (t = function(e) {
                                            var t = "",
                                                n = 0,
                                                s = new i(e),
                                                a = null;
                                            for (; s.hasNext();)
                                                if ((a = s.match(/([\s]|[^\\]|\\\\)+/g)) && (t += a[0]), "\\" === s.peek()) {
                                                    if (s.next(), "x" === s.peek()) a = s.match(/x([0-9A-Fa-f]{2})/g);
                                                    else {
                                                        if ("u" !== s.peek()) {
                                                            t += "\\", s.hasNext() && (t += s.next());
                                                            continue
                                                        }(a = s.match(/u([0-9A-Fa-f]{4})/g)) || (a = s.match(/u\{([0-9A-Fa-f]+)\}/g))
                                                    }
                                                    if (!a) return e;
                                                    if ((n = parseInt(a[1], 16)) > 126 && n <= 255 && 0 === a[0].indexOf("x")) return e;
                                                    t += n >= 0 && n < 32 || n > 1114111 ? "\\" + a[0] : 34 === n || 39 === n || 92 === n ? "\\" + String.fromCharCode(n) : String.fromCharCode(n)
                                                }
                                            return t
                                        }(t)), this._input.peek() === e && (t += this._input.next()), t = t.replace(r.allLineBreaks, "\n"), this._create_token(d.STRING, t)
                                    }
                                    return null
                                }, x.prototype._allow_regexp_or_xml = function(e) {
                                    return e.type === d.RESERVED && u(e.text, ["return", "case", "throw", "else", "do", "typeof", "yield"]) || e.type === d.END_EXPR && ")" === e.text && e.opened.previous.type === d.RESERVED && u(e.opened.previous.text, ["if", "while", "for"]) || u(e.type, [d.COMMENT, d.START_EXPR, d.START_BLOCK, d.START, d.END_BLOCK, d.OPERATOR, d.EQUALS, d.EOF, d.SEMICOLON, d.COMMA])
                                }, x.prototype._read_regexp = function(e, t) {
                                    if ("/" === e && this._allow_regexp_or_xml(t)) {
                                        for (var n = this._input.next(), i = !1, s = !1; this._input.hasNext() && (i || s || this._input.peek() !== e) && !this._input.testChar(r.newline);) n += this._input.peek(), i ? i = !1 : (i = "\\" === this._input.peek(), "[" === this._input.peek() ? s = !0 : "]" === this._input.peek() && (s = !1)), this._input.next();
                                        return this._input.peek() === e && (n += this._input.next(), n += this._input.read(r.identifier)), this._create_token(d.STRING, n)
                                    }
                                    return null
                                }, x.prototype._read_xml = function(e, t) {
                                    if (this._options.e4x && "<" === e && this._allow_regexp_or_xml(t)) {
                                        var n = "",
                                            i = this.__patterns.xml.read_match();
                                        if (i) {
                                            for (var s = i[2].replace(/^{\s+/, "{").replace(/\s+}$/, "}"), a = 0 === s.indexOf("{"), o = 0; i;) {
                                                var c = !!i[1],
                                                    l = i[2];
                                                if (!(!!i[i.length - 1] || "![CDATA[" === l.slice(0, 8)) && (l === s || a && l.replace(/^{\s+/, "{").replace(/\s+}$/, "}")) && (c ? --o : ++o), n += i[0], o <= 0) break;
                                                i = this.__patterns.xml.read_match()
                                            }
                                            return i || (n += this._input.match(/[\s\S]*/g)[0]), n = n.replace(r.allLineBreaks, "\n"), this._create_token(d.STRING, n)
                                        }
                                    }
                                    return null
                                }, x.prototype._read_string_recursive = function(e, t, n) {
                                    var i, s;
                                    "'" === e ? s = this.__patterns.single_quote : '"' === e ? s = this.__patterns.double_quote : "`" === e ? s = this.__patterns.template_text : "}" === e && (s = this.__patterns.template_expression);
                                    for (var a = s.read(), o = ""; this._input.hasNext();) {
                                        if ((o = this._input.next()) === e || !t && r.newline.test(o)) {
                                            this._input.back();
                                            break
                                        }
                                        "\\" === o && this._input.hasNext() ? ("x" === (i = this._input.peek()) || "u" === i ? this.has_char_escapes = !0 : "\r" === i && "\n" === this._input.peek(1) && this._input.next(), o += this._input.next()) : n && ("${" === n && "$" === o && "{" === this._input.peek() && (o += this._input.next()), n === o && (o += "`" === e ? this._read_string_recursive("}", t, "`") : this._read_string_recursive("`", t, "${"), this._input.hasNext() && (o += this._input.next()))), a += o += s.read()
                                    }
                                    return a
                                }, e.exports.Tokenizer = x, e.exports.TOKEN = d, e.exports.positionable_operators = g.slice(), e.exports.line_starters = b.slice()
                            }, function(e) {
                                var t = RegExp.prototype.hasOwnProperty("sticky");

                                function n(e) {
                                    this.__input = e || "", this.__input_length = this.__input.length, this.__position = 0
                                }
                                n.prototype.restart = function() {
                                    this.__position = 0
                                }, n.prototype.back = function() {
                                    this.__position > 0 && (this.__position -= 1)
                                }, n.prototype.hasNext = function() {
                                    return this.__position < this.__input_length
                                }, n.prototype.next = function() {
                                    var e = null;
                                    return this.hasNext() && (e = this.__input.charAt(this.__position), this.__position += 1), e
                                }, n.prototype.peek = function(e) {
                                    var t = null;
                                    return e = e || 0, (e += this.__position) >= 0 && e < this.__input_length && (t = this.__input.charAt(e)), t
                                }, n.prototype.__match = function(e, n) {
                                    e.lastIndex = n;
                                    var i = e.exec(this.__input);
                                    return !i || t && e.sticky || i.index !== n && (i = null), i
                                }, n.prototype.test = function(e, t) {
                                    return t = t || 0, (t += this.__position) >= 0 && t < this.__input_length && !!this.__match(e, t)
                                }, n.prototype.testChar = function(e, t) {
                                    var n = this.peek(t);
                                    return e.lastIndex = 0, null !== n && e.test(n)
                                }, n.prototype.match = function(e) {
                                    var t = this.__match(e, this.__position);
                                    return t ? this.__position += t[0].length : t = null, t
                                }, n.prototype.read = function(e, t, n) {
                                    var i, s = "";
                                    return e && (i = this.match(e)) && (s += i[0]), !t || !i && e || (s += this.readUntil(t, n)), s
                                }, n.prototype.readUntil = function(e, t) {
                                    var n, i = this.__position;
                                    e.lastIndex = this.__position;
                                    var s = e.exec(this.__input);
                                    return s ? (i = s.index, t && (i += s[0].length)) : i = this.__input_length, n = this.__input.substring(this.__position, i), this.__position = i, n
                                }, n.prototype.readUntilAfter = function(e) {
                                    return this.readUntil(e, !0)
                                }, n.prototype.get_regexp = function(e, n) {
                                    var i = null,
                                        s = "g";
                                    return n && t && (s = "y"), "string" == typeof e && "" !== e ? i = new RegExp(e, s) : e && (i = new RegExp(e.source, s)), i
                                }, n.prototype.get_literal_regexp = function(e) {
                                    return RegExp(e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
                                }, n.prototype.peekUntilAfter = function(e) {
                                    var t = this.__position,
                                        n = this.readUntilAfter(e);
                                    return this.__position = t, n
                                }, n.prototype.lookBack = function(e) {
                                    var t = this.__position - 1;
                                    return t >= e.length && this.__input.substring(t - e.length, t).toLowerCase() === e
                                }, e.exports.InputScanner = n
                            }, function(e, t, n) {
                                var i = n(8).InputScanner,
                                    s = n(3).Token,
                                    a = n(10).TokenStream,
                                    o = n(11).WhitespacePattern,
                                    r = {
                                        START: "TK_START",
                                        RAW: "TK_RAW",
                                        EOF: "TK_EOF"
                                    },
                                    c = function(e, t) {
                                        this._input = new i(e), this._options = t || {}, this.__tokens = null, this._patterns = {}, this._patterns.whitespace = new o(this._input)
                                    };
                                c.prototype.tokenize = function() {
                                    var e;
                                    this._input.restart(), this.__tokens = new a, this._reset();
                                    for (var t = new s(r.START, ""), n = null, i = [], o = new a; t.type !== r.EOF;) {
                                        for (e = this._get_next_token(t, n); this._is_comment(e);) o.add(e), e = this._get_next_token(t, n);
                                        o.isEmpty() || (e.comments_before = o, o = new a), e.parent = n, this._is_opening(e) ? (i.push(n), n = e) : n && this._is_closing(e, n) && (e.opened = n, n.closed = e, n = i.pop(), e.parent = n), e.previous = t, t.next = e, this.__tokens.add(e), t = e
                                    }
                                    return this.__tokens
                                }, c.prototype._is_first_token = function() {
                                    return this.__tokens.isEmpty()
                                }, c.prototype._reset = function() {}, c.prototype._get_next_token = function(e, t) {
                                    this._readWhitespace();
                                    var n = this._input.read(/.+/g);
                                    return n ? this._create_token(r.RAW, n) : this._create_token(r.EOF, "")
                                }, c.prototype._is_comment = function(e) {
                                    return !1
                                }, c.prototype._is_opening = function(e) {
                                    return !1
                                }, c.prototype._is_closing = function(e, t) {
                                    return !1
                                }, c.prototype._create_token = function(e, t) {
                                    return new s(e, t, this._patterns.whitespace.newline_count, this._patterns.whitespace.whitespace_before_token)
                                }, c.prototype._readWhitespace = function() {
                                    return this._patterns.whitespace.read()
                                }, e.exports.Tokenizer = c, e.exports.TOKEN = r
                            }, function(e) {
                                function t(e) {
                                    this.__tokens = [], this.__tokens_length = this.__tokens.length, this.__position = 0, this.__parent_token = e
                                }
                                t.prototype.restart = function() {
                                    this.__position = 0
                                }, t.prototype.isEmpty = function() {
                                    return 0 === this.__tokens_length
                                }, t.prototype.hasNext = function() {
                                    return this.__position < this.__tokens_length
                                }, t.prototype.next = function() {
                                    var e = null;
                                    return this.hasNext() && (e = this.__tokens[this.__position], this.__position += 1), e
                                }, t.prototype.peek = function(e) {
                                    var t = null;
                                    return e = e || 0, (e += this.__position) >= 0 && e < this.__tokens_length && (t = this.__tokens[e]), t
                                }, t.prototype.add = function(e) {
                                    this.__parent_token && (e.parent = this.__parent_token), this.__tokens.push(e), this.__tokens_length += 1
                                }, e.exports.TokenStream = t
                            }, function(e, t, n) {
                                var i = n(12).Pattern;

                                function s(e, t) {
                                    i.call(this, e, t), t ? this._line_regexp = this._input.get_regexp(t._line_regexp) : this.__set_whitespace_patterns("", ""), this.newline_count = 0, this.whitespace_before_token = ""
                                }
                                s.prototype = new i, s.prototype.__set_whitespace_patterns = function(e, t) {
                                    e += "\\t ", t += "\\n\\r", this._match_pattern = this._input.get_regexp("[" + e + t + "]+", !0), this._newline_regexp = this._input.get_regexp("\\r\\n|[" + t + "]")
                                }, s.prototype.read = function() {
                                    this.newline_count = 0, this.whitespace_before_token = "";
                                    var e = this._input.read(this._match_pattern);
                                    if (" " === e) this.whitespace_before_token = " ";
                                    else if (e) {
                                        var t = this.__split(this._newline_regexp, e);
                                        this.newline_count = t.length - 1, this.whitespace_before_token = t[this.newline_count]
                                    }
                                    return e
                                }, s.prototype.matching = function(e, t) {
                                    var n = this._create();
                                    return n.__set_whitespace_patterns(e, t), n._update(), n
                                }, s.prototype._create = function() {
                                    return new s(this._input, this)
                                }, s.prototype.__split = function(e, t) {
                                    e.lastIndex = 0;
                                    for (var n = 0, i = [], s = e.exec(t); s;) i.push(t.substring(n, s.index)), n = s.index + s[0].length, s = e.exec(t);
                                    return n < t.length ? i.push(t.substring(n, t.length)) : i.push(""), i
                                }, e.exports.WhitespacePattern = s
                            }, function(e) {
                                function t(e, t) {
                                    this._input = e, this._starting_pattern = null, this._match_pattern = null, this._until_pattern = null, this._until_after = !1, t && (this._starting_pattern = this._input.get_regexp(t._starting_pattern, !0), this._match_pattern = this._input.get_regexp(t._match_pattern, !0), this._until_pattern = this._input.get_regexp(t._until_pattern), this._until_after = t._until_after)
                                }
                                t.prototype.read = function() {
                                    var e = this._input.read(this._starting_pattern);
                                    return this._starting_pattern && !e || (e += this._input.read(this._match_pattern, this._until_pattern, this._until_after)), e
                                }, t.prototype.read_match = function() {
                                    return this._input.match(this._match_pattern)
                                }, t.prototype.until_after = function(e) {
                                    var t = this._create();
                                    return t._until_after = !0, t._until_pattern = this._input.get_regexp(e), t._update(), t
                                }, t.prototype.until = function(e) {
                                    var t = this._create();
                                    return t._until_after = !1, t._until_pattern = this._input.get_regexp(e), t._update(), t
                                }, t.prototype.starting_with = function(e) {
                                    var t = this._create();
                                    return t._starting_pattern = this._input.get_regexp(e, !0), t._update(), t
                                }, t.prototype.matching = function(e) {
                                    var t = this._create();
                                    return t._match_pattern = this._input.get_regexp(e, !0), t._update(), t
                                }, t.prototype._create = function() {
                                    return new t(this._input, this)
                                }, t.prototype._update = function() {}, e.exports.Pattern = t
                            }, function(e) {
                                function t(e, t) {
                                    e = "string" == typeof e ? e : e.source, t = "string" == typeof t ? t : t.source, this.__directives_block_pattern = new RegExp(e + / beautify( \w+[:]\w+)+ /.source + t, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(e + /\sbeautify\signore:end\s/.source + t, "g")
                                }
                                t.prototype.get_directives = function(e) {
                                    if (!e.match(this.__directives_block_pattern)) return null;
                                    var t = {};
                                    this.__directive_pattern.lastIndex = 0;
                                    for (var n = this.__directive_pattern.exec(e); n;) t[n[1]] = n[2], n = this.__directive_pattern.exec(e);
                                    return t
                                }, t.prototype.readIgnored = function(e) {
                                    return e.readUntilAfter(this.__directives_end_ignore_pattern)
                                }, e.exports.Directives = t
                            }, function(e, t, n) {
                                var i = n(12).Pattern,
                                    s = {
                                        django: !1,
                                        erb: !1,
                                        handlebars: !1,
                                        php: !1,
                                        smarty: !1,
                                        angular: !1
                                    };

                                function a(e, t) {
                                    i.call(this, e, t), this.__template_pattern = null, this._disabled = Object.assign({}, s), this._excluded = Object.assign({}, s), t && (this.__template_pattern = this._input.get_regexp(t.__template_pattern), this._excluded = Object.assign(this._excluded, t._excluded), this._disabled = Object.assign(this._disabled, t._disabled));
                                    var n = new i(e);
                                    this.__patterns = {
                                        handlebars_comment: n.starting_with(/{{!--/).until_after(/--}}/),
                                        handlebars_unescaped: n.starting_with(/{{{/).until_after(/}}}/),
                                        handlebars: n.starting_with(/{{/).until_after(/}}/),
                                        php: n.starting_with(/<\?(?:[= ]|php)/).until_after(/\?>/),
                                        erb: n.starting_with(/<%[^%]/).until_after(/[^%]%>/),
                                        django: n.starting_with(/{%/).until_after(/%}/),
                                        django_value: n.starting_with(/{{/).until_after(/}}/),
                                        django_comment: n.starting_with(/{#/).until_after(/#}/),
                                        smarty: n.starting_with(/{(?=[^}{\s\n])/).until_after(/[^\s\n]}/),
                                        smarty_comment: n.starting_with(/{\*/).until_after(/\*}/),
                                        smarty_literal: n.starting_with(/{literal}/).until_after(/{\/literal}/)
                                    }
                                }
                                a.prototype = new i, a.prototype._create = function() {
                                    return new a(this._input, this)
                                }, a.prototype._update = function() {
                                    this.__set_templated_pattern()
                                }, a.prototype.disable = function(e) {
                                    var t = this._create();
                                    return t._disabled[e] = !0, t._update(), t
                                }, a.prototype.read_options = function(e) {
                                    var t = this._create();
                                    for (var n in s) t._disabled[n] = -1 === e.templating.indexOf(n);
                                    return t._update(), t
                                }, a.prototype.exclude = function(e) {
                                    var t = this._create();
                                    return t._excluded[e] = !0, t._update(), t
                                }, a.prototype.read = function() {
                                    var e = "";
                                    e = this._match_pattern ? this._input.read(this._starting_pattern) : this._input.read(this._starting_pattern, this.__template_pattern);
                                    for (var t = this._read_template(); t;) this._match_pattern ? t += this._input.read(this._match_pattern) : t += this._input.readUntil(this.__template_pattern), e += t, t = this._read_template();
                                    return this._until_after && (e += this._input.readUntilAfter(this._until_pattern)), e
                                }, a.prototype.__set_templated_pattern = function() {
                                    var e = [];
                                    this._disabled.php || e.push(this.__patterns.php._starting_pattern.source), this._disabled.handlebars || e.push(this.__patterns.handlebars._starting_pattern.source), this._disabled.erb || e.push(this.__patterns.erb._starting_pattern.source), this._disabled.django || (e.push(this.__patterns.django._starting_pattern.source), e.push(this.__patterns.django_value._starting_pattern.source), e.push(this.__patterns.django_comment._starting_pattern.source)), this._disabled.smarty || e.push(this.__patterns.smarty._starting_pattern.source), this._until_pattern && e.push(this._until_pattern.source), this.__template_pattern = this._input.get_regexp("(?:" + e.join("|") + ")")
                                }, a.prototype._read_template = function() {
                                    var e = "",
                                        t = this._input.peek();
                                    if ("<" === t) {
                                        var n = this._input.peek(1);
                                        this._disabled.php || this._excluded.php || "?" !== n || (e = e || this.__patterns.php.read()), this._disabled.erb || this._excluded.erb || "%" !== n || (e = e || this.__patterns.erb.read())
                                    } else "{" === t && (this._disabled.handlebars || this._excluded.handlebars || (e = (e = (e = e || this.__patterns.handlebars_comment.read()) || this.__patterns.handlebars_unescaped.read()) || this.__patterns.handlebars.read()), this._disabled.django || (this._excluded.django || this._excluded.handlebars || (e = e || this.__patterns.django_value.read()), this._excluded.django || (e = (e = e || this.__patterns.django_comment.read()) || this.__patterns.django.read())), this._disabled.smarty || this._disabled.django && this._disabled.handlebars && (e = (e = (e = e || this.__patterns.smarty_comment.read()) || this.__patterns.smarty_literal.read()) || this.__patterns.smarty.read()));
                                    return e
                                }, e.exports.TemplatablePattern = a
                            }],
                            t = {};
                        var n = function n(i) {
                            var s = t[i];
                            if (void 0 !== s) return s.exports;
                            var a = t[i] = {
                                exports: {}
                            };
                            return e[i](a, a.exports, n), a.exports
                        }(0);
                        i = n
                    }();
                    var s = i;
                    void 0 === (n = function() {
                        return {
                            js_beautify: s
                        }
                    }.apply(t, [])) || (e.exports = n)
                }()
            },
            13822: (e, t, n) => {
                "use strict";
                n.d(t, {
                    A: () => i
                });
                const i = (0, n(94378).k)("args/options.mod.ts").options
            },
            94378: (e, t, n) => {
                "use strict";

                function i(e) {
                    const t = s(e);
                    return function(e, t) {
                            if (0 === e.length) throw `Couldn't find args for module "${t}". Did you forget to call @JavaScriptHelper.Args?`
                        }(t, e),
                        function(e, t) {
                            if (e.length > 1) throw `Found too many instances of args for module "${t}". Did you call @JavaScriptHelper.Args too many times?`
                        }(t, e), t[0]
                }

                function s(e) {
                    const t = function(e) {
                        const t = e.replace(/\.(t|j)sx?/, ""),
                            n = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                        return document.querySelectorAll(n)
                    }(e);
                    return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
                }
                n.d(t, {
                    _: () => s,
                    k: () => i
                })
            },
            41928: (e, t, n) => {
                "use strict";
                n.d(t, {
                    X: () => s
                });
                var i = n(70243);
                const s = function(e) {
                    const t = e.closest(".js-post-menu"),
                        n = t.attr("data-post-id"),
                        s = t.find(".js-menu-popup-container");
                    if (s.find(".js-cite-popup").length > 0) return;
                    const a = $('\n        <div class="js-cite-popup popup d-block ws6 c-auto">\n            <div class="js-cite-example mb4"></div>\n            <form class="d-flex gs8">\n                <label class="flex--item"><input type="radio" class="s-radio js-cite-bibtex" name="reftype" checked="checked"/> BibTeX</label>\n                <label class="flex--item"><input type="radio" class="s-radio js-cite-amsrefs" name="reftype" /> amsrefs</label>\n            </form>\n            <textarea class="js-cite-text s-textarea w100 d-block mt4" rows="9"></textarea>\n            <button type="button" class="s-btn js-cite-close mt8 mbn4 p2">Close</button>\n        </div>');
                    a.find(".js-cite-close").on("click", (function() {
                        a.fadeOutAndRemove()
                    })), a.find("form").on("submit", (function(e) {
                        e.preventDefault()
                    }));
                    const o = a.find(".js-cite-example"),
                        r = a.find(".js-cite-bibtex"),
                        c = a.find(".js-cite-amsrefs"),
                        l = a.find(".js-cite-text");
                    s.append(a), (0, i.p6)(o), $.ajax({
                        type: "GET",
                        url: "/posts/" + n + "/citation",
                        dataType: "json",
                        success: function(e) {
                            (0, i.Ec)(), o.html(e.example), l.val(e.bibtex), r.on("click", (function() {
                                l.val(e.bibtex)
                            })), c.on("click", (function() {
                                l.val(e.amsref)
                            }))
                        }
                    })
                }
            },
            84356: (e, t, n) => {
                "use strict";
                n.d(t, {
                    A: () => c,
                    H: () => r
                });
                var i = n(4279),
                    s = n(93941);
                class a {
                    constructor(e, t, n) {
                        this.postId = e, this.location = t.closest(".answer").length ? "answer" : t.closest(".question").length ? "question" : "other", this.jDiv = t, this.jCommentsList = t.find(".js-comments-list"), this.jCommentsLinkContainer = $("#comments-link-" + e), this.context = n
                    }
                    checkDiscussion() {}
                    ensureInput() {}
                    renderTextInput() {}
                    alterAddEditDataBeforeSubmit() {}
                    saveEditingComments(e) {}
                    restoreEditingComments() {}
                    isInputShown() {
                        const e = this.jDiv.find('form[id^="add-comment-"]');
                        return e.children().length && e.is(":visible")
                    }
                    commentsShown() {
                        this.remainingCommentsCount(0)
                    }
                    remainingCommentsCount(e) {
                        if (void 0 === e) return parseInt(this.jCommentsList.data("remaining-comments-count")) || 0;
                        this.jCommentsList.data("remaining-comments-count", e)
                    }
                    addShow(e, t) {
                        const n = this,
                            i = this.loadAllComments().done((function() {
                                n.checkDiscussion()
                            }));
                        let s;
                        t && (s = this.ensureInput(), s && !e && s.focus()), i.done((function() {
                            s && s.length > 0 && n.jCommentsLinkContainer.hide()
                        }))
                    }
                    ajax(e, t, n, i) {
                        n && !i && StackExchange.helpers.addSpinner(n, {
                            "margin-left": "10px"
                        });
                        const s = this;
                        return $.ajax(e).fail((function(e) {
                            let a = e.responseText;
                            (!a || a.indexOf("<html") >= 0) && (a = t || __tr(["An error occurred"], undefined, "en", [])), StackExchange.helpers.showErrorMessage(n || s.jDiv, a, {
                                transient: 409 == e.status
                            }), n && !i && StackExchange.helpers.removeSpinner()
                        })).done((() => StackExchange.helpers.removeSpinner())).promise()
                    }
                    setCommentsMenu(e) {
                        let t = "",
                            n = "";
                        e > 0 && (n = __tr(["Show <strong>$count$</strong> more comment", "Show <strong>$count$</strong> more comments"], {
                            count: e
                        }, "en", ["count"])), this.isInputShown() || !this.jCommentsList.data("cansee") && !this.jCommentsList.data("canpost") || (t = StackExchange.settings.comments.addButtonSaysSuggestImprovements ? __tr(["Suggest improvements"], undefined, "en", []) : __tr(["Add a comment"], undefined, "en", [])), t.length || n || !this.jCommentsList.data("comments-unavailable") || (t = __tr(["Comments disabled on deleted / locked posts / reviews"], undefined, "en", [])), StackExchange.options.inReadOnly && (t = "");
                        const i = this.jCommentsLinkContainer.find(".js-add-link"),
                            s = this.jCommentsLinkContainer.find(".js-show-link");
                        i.html(t), s.html(n), t.length ? i.removeClass("dno") : i.addClass("dno"), n.length ? s.removeClass("dno") : s.addClass("dno"), t.length && n.length ? this.jCommentsLinkContainer.find(".js-link-separator").removeClass("dno") : this.jCommentsLinkContainer.find(".js-link-separator").addClass("dno"), this.jCommentsList.data("addlink-disabled") && i.addClass("disabled-link")
                    }
                    clearHighlights() {
                        this.jCommentsList.find(".js-comment").removeClass("new_comment").css("background-color", "")
                    }
                    showComments(e, t, n, o) {
                        this.saveEditingComments(t);
                        const r = !n,
                            c = {},
                            l = [];
                        this.clearHighlights(), r && this.jCommentsList.find(".js-comment").each((function(e, t) {
                            t.id && t.id.length && (c[t.id] = !0)
                        }));
                        const u = this.jCommentsList.find(".js-native-comment-ad");
                        if (0 === u.length) l.push(... function(e) {
                            const t = "string" == typeof e ? $(e) : e,
                                n = [];
                            return t.filter(".js-native-comment-ad").add(t.find(".js-native-comment-ad")).each((function() {
                                const e = $(this).find('div[id^="dfp-nativecomment-"]').first().attr("id");
                                e && n.push(e)
                            })), n
                        }(e)), this.jCommentsList.empty().append(e);
                        else {
                            this.jCommentsList.children(":not(.js-native-comment-ad)").remove();
                            const t = "string" == typeof e ? $(e) : e;
                            let n = [],
                                i = 0;
                            t.each((function() {
                                if ($(this).hasClass("js-native-comment-ad")) {
                                    const e = u.eq(i);
                                    if (e.length) e.before(n), n = [];
                                    else {
                                        n.push(this);
                                        const e = $(this).find('div[id^="dfp-nativecomment-"]').first().attr("id");
                                        e && l.push(e)
                                    }
                                    i++
                                } else n.push(this)
                            })), this.jCommentsList.append(n)
                        }
                        if (function(e) {
                                if (e.length && "object" == typeof cam && null !== cam && "function" == typeof cam.add)
                                    for (const t of e) cam.add(t)
                            }(l), r) {
                            let e = null;
                            this.jCommentsList.find(".js-comment").each((function(t, n) {
                                n.id && n.id.length && !c[n.id] && (e || (e = n), $(n).addClass("new_comment"))
                            }));
                            const t = this.jCommentsList.find(".new_comment");
                            (0, s.A)(t), a.commentHighlightFocus && t.length && !o && t[0].scrollIntoView(!0)
                        }
                        this.restoreEditingComments(), this.setCommentsMenu(0), "undefined" != typeof MathJax && (MathJax.Hub ? MathJax.Hub.Queue(["Typeset", MathJax.Hub]) : MathJax.typeset()), (0, i.A)(), this.commentsShown()
                    }
                    loadAllComments(e, t, n, i) {
                        this.jDiv.removeClass("dno");
                        const s = 0 === this.remainingCommentsCount();
                        if (!e && s) return $.Deferred().resolve().promise();
                        const a = location.href.indexOf("/staging-ground/") > 0 ? "/staging-ground/" + this.postId + "/comments" + (t || "") : "/posts/" + this.postId + "/comments" + (t || ""),
                            o = this;
                        return this.ajax({
                            type: "GET",
                            url: a,
                            dataType: "html"
                        }, __tr(["An error occurred while fetching comments"], undefined, "en", [])).done((function(e) {
                            o.showComments(e, null, n, i)
                        })).promise()
                    }
                }
                a.commentHighlightFocus = !1, a.cache = {};
                let o = null;

                function r(e, t) {
                    t || (o = e), e = e || o || {};
                    for (const t in e) e.hasOwnProperty(t) && (a.prototype[t] = e[t])
                }
                const c = a
            },
            76969: (e, t, n) => {
                "use strict";
                n(70243);
                class i extends Event {
                    constructor(e) {
                        super(i.type, {
                            bubbles: !0
                        }), this.detail = e
                    }
                }
                i.type = "comment:deleted"
            },
            64806: (e, t, n) => {
                "use strict";
                n(70243)
            },
            4279: (e, t, n) => {
                "use strict";
                n.d(t, {
                    A: () => i
                });
                const i = function(e) {
                    const t = location.href.indexOf("/questions/") > 0,
                        n = location.href.indexOf("/staging-ground/") > 0,
                        i = !t && (location.href.endsWith("/election") || location.href.indexOf("/election/") > 0),
                        s = /\/collectives\/.+\/articles\//.test(location.href),
                        a = /\/collectives\/.+\/collections\//.test(location.href);
                    (i || n || t || s || a) && (t && 0 == $(".question[data-questionid]").length || $(".js-comment .comment-date").each((function() {
                        const o = $(this),
                            r = o.closest(".js-comment").attr("id").substr(8);
                        let c = 0;
                        if (t) {
                            const e = o.closest(".answer"),
                                t = e && e.length ? e.data("answerid") : 0;
                            c = t || StackExchange.question.getQuestionId()
                        } else c = s || n || a ? o.closest(".js-comments-container").data("post-id") : o.closest(".js-nomination").data("postid");
                        const l = (e || "") + "#comment" + r + "_" + c;
                        t || n || i || s || a ? o.wrapInner('<a class="comment-link" href="{hash}"></a>'.formatUnicorn({
                            hash: l
                        })) : o.wrapInner('<a class="comment-link" href="/q/{pid}/{hash}"></a>'.formatUnicorn({
                            hash: l,
                            pid: c
                        }))
                    })))
                }
            },
            93941: (e, t, n) => {
                "use strict";
                n.d(t, {
                    A: () => i
                });
                const i = function(e) {
                    dispatchEvent(new CustomEvent("clearFollowUpHighlight")), "string" == typeof e && (e = $("#comment-" + e)), e.addClass("comment__highlight"), setTimeout((function() {
                        e.removeClass("comment__highlight new_comment")
                    }), 0)
                }
            },
            36666: (e, t, n) => {
                "use strict";
                n.d(t, {
                    Ay: () => h
                });
                var i = n(4279),
                    s = n(93941),
                    a = n(84356),
                    o = (n(64806), n(76969), n(1977));

                function r(e) {
                    const t = e.constructor === $ ? e : $(e);
                    let n = t.closest(".js-comments-container");
                    0 === n.length && (n = t.closest(".js-post-comments-component, .question, .answer, div[id^='post-'], .js-article, .js-collective-collection").find(".js-comments-container")), 0 === n.length && (n = $(".js-staging-ground-comments-container"));
                    const i = n.data("post-id"),
                        s = n.data("comment-context") || "none",
                        o = i + "-" + s;
                    if (a.A.cache[o]) return a.A.cache[o];
                    const r = new a.A(i, n, s);
                    return a.A.cache[o] = r, r
                }

                function c(e) {
                    return 0 === window.location.pathname.indexOf("/review") ? 0 : e.closest(".question").length ? 1 : e.closest(".answer").length ? 2 : 0
                }

                function l(e) {
                    e.preventDefault(), u($(this))
                }

                function u(e) {
                    var t;
                    const n = r(e),
                        i = 0 === n.remainingCommentsCount(),
                        s = e.hasClass("disabled-link"),
                        a = n.jCommentsLinkContainer.data("rep");
                    if ("True" == e.attr("data-show-first-time-commenting")) return void document.dispatchEvent(new CustomEvent("firstTimeCommenting", {
                        detail: {
                            postId: n.postId,
                            editorPosition: "legacy-comment"
                        }
                    }));
                    i && n.jCommentsLinkContainer.data("anon") && function(e, t) {
                        if (t.is(":working")) return;
                        t.working(!0), StackExchange.helpers.removeMessages(), StackExchange.using("gps", (function() {
                            StackExchange.gps.track("comment_popup.show", {
                                type: c(t)
                            })
                        })), dispatchEvent(new CustomEvent("signupModalShow", {
                            detail: {
                                location: "commentdialog",
                                overrideTitle: __tr(["Sign up to add a comment"], undefined, "en", [])
                            }
                        }))
                    }(n.postId, e), i && n.jCommentsLinkContainer.data("reg") && (StackExchange.helpers.showMessage(e, __tr(["You must have $linkStart$$rep$ reputation$linkEnd$ to comment", "You must have $linkStart$$rep$ reputation$linkEnd$ to comment"], {
                        rep: a,
                        linkStart: "<a href='/help/privileges/comment'>",
                        linkEnd: "</a>"
                    }, "en", ["rep"]), {
                        type: "info",
                        position: {
                            my: "left top",
                            at: "right center"
                        },
                        relativeToBody: !0
                    }), $.ajax({
                        type: "POST",
                        url: "/posts/popup/attempted-comment/{postId}".formatUnicorn({
                            postId: n.postId
                        }),
                        data: {
                            fkey: StackExchange.options.user.fkey
                        },
                        dataType: "html"
                    })), e.hasClass("js-show-link") && StackExchange.using("gps", (function() {
                        StackExchange.gps.track("comment.show")
                    }));
                    let l = !1;
                    if (e.hasClass("js-add-link")) {
                        if ("Stack Overflow" === StackExchange.options.site.name) {
                            let n, i, s;
                            const a = "True" === e.closest(".js-post-comments-component").data("has-opted-out");
                            e.closest(".js-question").length > 0 ? n = e.closest(".js-question").data("questionid") : (i = e.closest(".js-answer").data("answerid"), n = null === (t = e.closest("#answers")) || void 0 === t ? void 0 : t.siblings(".js-question").data("questionid"), s = $(".js-answer").index(e.closest(".js-answer"))), (0, o.H)("follow_ups_ui_experiment.add_comment_link_click", {
                                source: window.location.href,
                                followUpsUIExperimentGroup: a ? "excluded" : "control",
                                questionId: n,
                                answerId: i,
                                answerPositionOnPage: s
                            })
                        }
                        l = !0;
                        const s = n.location || "other",
                            a = i ? "all_shown" : "hidden";
                        StackExchange.using("gps", (function() {
                            StackExchange.gps.track("comment.add", {
                                location: s,
                                type: a
                            })
                        }))
                    }
                    s || n.addShow(!1, l)
                }

                function d(e, t) {
                    return r(e).loadAllComments(!0, t, !0, !0)
                }
                const h = {
                    init: function(e) {
                        const t = (e = e || {}).post || document;
                        a.A.cache = {}, $(t).off("click", "a.js-add-link:not([id^='comment-add-button'])", l).on("click", "a.js-add-link:not([id^='comment-add-button'])", l), $(t).off("click", "a.js-show-link", l).on("click", "a.js-show-link", l), t == document && (0, i.A)(e.hashPrefix), (0, a.H)(null, !0), e.commentHighlightFocus && (a.A.commentHighlightFocus = e.commentHighlightFocus), document.addEventListener("firstTimeCommenterValidationSuccess", (function(e) {
                            document.querySelectorAll(".js-add-link").forEach((t => {
                                if (t.setAttribute("data-show-first-time-commenting", "False"), e.detail.postId && "legacy-comment" === e.detail.editorPosition && t.parentElement.id === `comments-link-${e.detail.postId}`) {
                                    r($(t)).addShow(!1, !0)
                                }
                            }))
                        })), document.addEventListener("firstTimeCommenterValidationFailed", (function() {
                            document.querySelectorAll(".js-add-link").forEach((e => {
                                e.classList.add("disabled-link")
                            }))
                        }))
                    },
                    loadAll: d,
                    replaceAll: function(e, t) {
                        r(e).showComments(t, null, !0, !0)
                    },
                    realtimeMessage: function(e) {
                        const t = $("#comments-" + e);
                        if (!t.length) return;
                        const n = r(t),
                            i = n.jCommentsLinkContainer;
                        let s = n.remainingCommentsCount();
                        s++, i.data("comments-count", s), i.attr("title", __tr(["Expand to show all comments on this post, or add one of your own"], undefined, "en", [])), n.setCommentsMenu(s), i.removeClass("disabled-link"), n.remainingCommentsCount(s), i.show().fadeTo("fast", .7).fadeTo("fast", 1)
                    },
                    flashHighlight: s.A,
                    highlight: function(e, t) {
                        const n = "#comment-" + e,
                            i = $(n);
                        if (i.length)(0, s.A)(i), i[0].scrollIntoView(!0);
                        else {
                            const i = $("#comments-link-" + t);
                            if (i.length) {
                                let t = null;
                                StackExchange.options.user.isModerator && (t = "?includeDeleted=true"), d(i, t).done((function() {
                                    (0, s.A)(e), ($(n)[0] || i.closest(".question, .answer")[0]).scrollIntoView(!0)
                                }))
                            }
                        }
                    },
                    extendPostUi: a.H,
                    uiForPost: r
                }
            },
            77339: (e, t, n) => {
                "use strict";
                n.d(t, {
                    P: () => y
                });
                var i, s = n(24934),
                    a = n(70243),
                    o = n(13822),
                    r = n(33817),
                    c = n(68911);

                function l(e, t, n, i) {
                    t ? (e.attr("data-is-saved", "true"), e.find(".js-saves-btn-selected").removeClass("d-none"), e.find(".js-saves-btn-unselected").addClass("d-none")) : (e.attr("data-is-saved", "false"), e.find(".js-saves-btn-selected").addClass("d-none"), e.find(".js-saves-btn-unselected").removeClass("d-none")), n && e.attr("aria-label", n), i && (0, s.nT)(e, i)
                }

                function u() {
                    $(document).on("click", ".js-saves-btn", (function() {
                        const e = $(this),
                            t = "true" === e.attr("data-is-saved");
                        m(e.data("post-id"), t, ((n, i) => l(e, !t, n, i))),
                            function(e) {
                                const t = "true" === e.attr("data-is-saved"),
                                    n = e.data("post-type-id"),
                                    i = e.data("user-privilege-for-post-click");
                                r.track("post.click", {
                                    item: t ? 19 : 18,
                                    priv: i,
                                    post_type: n
                                })
                            }(e)
                    }))
                }

                function d() {
                    $(document).on("change", ".js-save-manage-select", (function(e) {
                        const t = $(this).val(),
                            n = $("#save-manage-add-list-textbox");
                        "create" === t ? (n.removeClass("d-none"), n.find("input").trigger("focus")) : n.hasClass("d-none") || n.addClass("d-none")
                    })), $(document).on("submit", ".js-save-manage-form", (function(e) {
                        e.preventDefault();
                        const t = $(this).find("#save-manage-add-list-textbox"),
                            n = t.find("input"),
                            i = $(this).find(".js-save-manage-select option:selected");
                        v($("#save-manage-modal"), "/posts/save/manage-save", n, i, !0, (e => {
                            const s = $(this).closest("#save-manage-modal");
                            if (s.length > 0 && s.data("isMoveto")) {
                                const o = s.data("userId"),
                                    r = s.data("postId"),
                                    c = i.data("listId"),
                                    l = i.data("listName");
                                if (n.length > 0 && n.val().length > 0 && !t.hasClass("d-none")) {
                                    const t = (0, a.U$)(n.val());
                                    return void(e && (_(e.toString(), t, o), "True" === $(".js-saves-lists-posts").data("isAll") ? p(e.toString(), t, r, o) : f(s.data("postId"))))
                                }
                                if ("True" === $(".js-saves-lists-posts").data("isForlater") && "for-later" === i.val()) return;
                                c !== s.data("listId") && ("True" === $(".js-saves-lists-posts").data("isAll") ? p(c, l, r, o) : f(s.data("postId")))
                            }
                        }))
                    }))
                }

                function h(e, t, n = !1) {
                    (0, a.aT)(`/posts/${e}/open-save-modal?${n?"isMoveTo=true":""}${t?"&listId="+t:""}`).fail((() => {
                        var e = $("<span>").text(__tr(["An error occurred"], undefined, "en", [])).html();
                        (0, a.P0)(e, {
                            type: "danger"
                        })
                    }))
                }

                function _(e, t, n) {
                    const i = `/users/saves/${n}/${e}`,
                        s = $(".js-saves-sidebar-nav"),
                        a = $(`<li class="js-saves-sidebar-item" data-list-id="${e}"><a class="s-navigation--item" href="${i}"><span class="s-navigation--item-text" data-text="${t}">${t}</span></a></li>`);
                    s.append(a);
                    const o = $(".js-saves-sidebar-nav-mobile optgroup"),
                        r = $(`<option class="js-saves-sidebar-item-mobile" value="${i}" data-list-id="${e}">${t}</option>`);
                    o.append(r)
                }

                function p(e, t, n, i) {
                    const s = $(`.js-saves-post-summary-${n}`).find(".js-saved-in");
                    s.html(t), s.attr("href", `/users/saves/${i}/${e}`)
                }

                function f(e) {
                    const t = $(`.js-saves-post-summary-${e}`);
                    if (t.length > 0) {
                        t.remove();
                        const e = $(".js-saves-count");
                        var n = parseInt(e.data("saves-count")),
                            i = n -= 1;
                        e.html(__tr(["$savesCount$ saved item", "$savesCount$ saved items"], {
                            savesCount: i
                        }, "en", ["savesCount"])), e.attr("data-saves-count", i), e.data("saves-count", i), 0 == i && ($(".js-saves-post-list").addClass("d-none"), $(".js-saves-empty-state").removeClass("d-none"))
                    }
                }

                function g(e, t, n) {
                    const i = e ? [] : [{
                        labelContents: $("<span>").text(__tr(["Manage"], undefined, "en", [])).html(),
                        click: function() {
                            h(t)
                        }
                    }];
                    n && (0, a.P0)(n, {
                        useRawHtml: !0,
                        actions: i,
                        type: "success"
                    })
                }

                function m(e, t, n) {
                    const i = `/posts/${e}/save${t?"?isUndo=true":""}`,
                        s = $(`.js-saves-btn[data-post-id="${e}"]`);
                    s && s.prop("disabled", !0), $.ajax({
                        type: "POST",
                        url: i,
                        data: {
                            fkey: o.A.user.fkey
                        },
                        dataType: "json",
                        success: function(t) {
                            s && s.prop("disabled", !1);
                            const {
                                NextLabel: i = "",
                                NextTooltip: a = "",
                                ToastMessage: o = "",
                                IsUndo: r = !1
                            } = t;
                            n && n(i, a), g(r, e, o)
                        },
                        error: function() {
                            (0, a.P0)(__tr(["An error occurred"], undefined, "en", []), {
                                type: "danger"
                            }), s && s.prop("disabled", !1)
                        }
                    })
                }

                function v(e, t, n, i, s = !0, r) {
                    let c, l, u, d, h;
                    const _ = e.find(".js-save-manage-submit"),
                        p = e.find(".js-save-add-note"),
                        f = "create" === e.find(".js-save-manage-select").val(),
                        g = n.val() && n.val().length > 0;
                    if (i && "for-later" === i.val() && p.length > 0 && !p.val()) return void Stacks.hideModal(e.get(0));
                    p.length > 0 && (d = p.val()), i ? u = i.data("listId") : e.data("list-id") && (u = e.data("list-id"));
                    const m = _.closest(".js-save-modal");
                    m.length > 0 && null !== m.data("postId") && (c = m.data("postId")), i && i.data("listName") ? l = i.data("listName") : (f || g) && (l = (0, a.U$)(n.val()), null == e.data("modalAction") && (h = !0));
                    const v = {
                        fkey: o.A.user.fkey,
                        listName: l,
                        postId: c,
                        listId: u,
                        isCreating: h,
                        privateNote: d
                    };
                    $.ajax({
                        type: "POST",
                        url: t,
                        data: v,
                        dataType: "json",
                        success: function(t) {
                            if (s) {
                                const {
                                    ToastMessage: e = ""
                                } = t;
                                (0, a.P0)(e, {
                                    useRawHtml: !0,
                                    type: "success"
                                })
                            }
                            const {
                                ListId: n = 0
                            } = t;
                            Stacks.hideModal(e.get(0)), r(n)
                        },
                        error: function(e) {
                            w(e)
                        }
                    })
                }

                function w(e) {
                    let t;
                    const {
                        responseJSON: n
                    } = e;
                    if ("string" == typeof n) t = n;
                    else if ("object" == typeof n) {
                        const {
                            ErrorMessage: e = ""
                        } = n;
                        t = e
                    }
                    t = t && t.length > 0 ? t : __tr(["An error occurred."], undefined, "en", []), (0, a.P0)(t, {
                        type: "danger"
                    })
                }

                function b() {
                    $(".js-saves-btn").on("click", (function() {
                        dispatchEvent(new CustomEvent("signupModalShow", {
                            detail: {
                                location: "save_post"
                            }
                        })), r.track("favorite_popup.show", {})
                    }))
                }

                function k() {
                    const e = $(".question").data("questionid");
                    $(".js-saves-popover-dismiss, .js-saves-popover-link").on("click", (function() {
                        (0, c.hidePopover)(document.getElementById(`saves-btn-${e}`))
                    })), $(`#saves-btn-${e}`).on("s-popover:hidden", (function() {
                        $("#saves-launch-popover").remove(), $("#saves-btn").data("controller", "s-tooltip"), $("#saves-btn").attr("aria-controls", ""), $.cookie("notice-slp", "1", {
                            path: "/",
                            expires: 30
                        }), o.A.user.isAnonymous || $.post("/saves-launch-popover/dismiss", {
                            fkey: o.A.user.fkey
                        })
                    }))
                }

                function y() {
                    $("#saves-launch-popover").length >= 1 && k(), o.A.user.isRegistered ? (u(), d(), window.addEventListener("savesSavePerformed", (e => {
                        const {
                            PostId: t,
                            Success: n,
                            ToastMessage: i,
                            NextLabel: s,
                            NextTooltip: a
                        } = e.detail;
                        t && n && (l($(`.js-saves-btn[data-post-id="${t}"]`), !0, s, a), g(!1, t, i))
                    }))) : b()
                }! function(e) {
                    e[e.ViewNoNote = 0] = "ViewNoNote", e[e.ViewNote = 1] = "ViewNote", e[e.AddingNote = 2] = "AddingNote", e[e.EditingNote = 3] = "EditingNote"
                }(i || (i = {}))
            },
            35148: (e, t, n) => {
                "use strict";
                n.d(t, {
                    f: () => s
                });
                var i = n(13822);

                function s(e, t, n) {
                    const s = i.A.user;
                    return $.post(`/users/toggle-flag/${e}/${!!t}`, {
                        fkey: s.fkey,
                        userId: n || s.proxiedUserId || s.userId
                    }).then((e => !!e.hasFlags))
                }
            },
            73739: (e, t, n) => {
                "use strict";
                var i, s, a, o;
                n.d(t, {
                        nh: () => a
                    }),
                    function(e) {
                        e[e.Daily = 2] = "Daily", e[e.FifteenMinutes = 1] = "FifteenMinutes", e[e.None = 0] = "None"
                    }(i || (i = {})),
                    function(e) {
                        e[e.ArticlesDismissNewBadgeInLeftSideBar = 524288] = "ArticlesDismissNewBadgeInLeftSideBar", e[e.AskStackDismissNewBadgeInLeftSideBar = 4194304] = "AskStackDismissNewBadgeInLeftSideBar", e[e.ChallengesDismissNewBadgeInLeftSideBar = 1048576] = "ChallengesDismissNewBadgeInLeftSideBar", e[e.ChatCTADismissed = 2097152] = "ChatCTADismissed", e[e.ChatDismissNewBadgeInLeftSideBar = 262144] = "ChatDismissNewBadgeInLeftSideBar", e[e.DisableNewsletterPersonalization = 16] = "DisableNewsletterPersonalization", e[e.DisableStacksEditor = 65536] = "DisableStacksEditor", e[e.DismissCollectivesNavbarCTA = 512] = "DismissCollectivesNavbarCTA", e[e.DismissFreemiumTeamsCreationCTA = 32] = "DismissFreemiumTeamsCreationCTA", e[e.DismissReviewQueueNoticeCampaign = 128] = "DismissReviewQueueNoticeCampaign", e[e.EnableKeyboardShortcuts = 2] = "EnableKeyboardShortcuts", e[e.EnableMathJaxV3 = 16384] = "EnableMathJaxV3", e[e.ForYouUnreadOnlyByDefault = 256] = "ForYouUnreadOnlyByDefault", e[e.HideHotNetworkQuestionsSidebar = 8] = "HideHotNetworkQuestionsSidebar", e[e.HideJobsLinkAsNew = 4096] = "HideJobsLinkAsNew", e[e.HideLeftNavigation = 1] = "HideLeftNavigation", e[e.HideSGPostsOutsideOfStagingGround = 2048] = "HideSGPostsOutsideOfStagingGround", e[e.None = 0] = "None", e[e.OptOutOfExperiments = 131072] = "OptOutOfExperiments", e[e.SearchTagNamesOnly = 1024] = "SearchTagNamesOnly", e[e.ShowUsageGuidanceOnTagHover = 32768] = "ShowUsageGuidanceOnTagHover", e[e.SofaDismissNewBadgeInLeftSideBar = 8388608] = "SofaDismissNewBadgeInLeftSideBar", e[e.UnifiedSearchActiveByDefault = 64] = "UnifiedSearchActiveByDefault"
                    }(s || (s = {})),
                    function(e) {
                        e[e.CollectivesCheckedLeaderboard = 2] = "CollectivesCheckedLeaderboard", e[e.CollectivesDiscoveredRecAnswers = 8] = "CollectivesDiscoveredRecAnswers", e[e.CollectivesExploredFeatures = -2147483648] = "CollectivesExploredFeatures", e[e.CollectivesLearnedAboutRoles = 4] = "CollectivesLearnedAboutRoles", e[e.CollectivesReadBulletin = 1] = "CollectivesReadBulletin", e[e.CollectivesSeenAll = 16] = "CollectivesSeenAll", e[e.DisableSideNav = 1073741824] = "DisableSideNav", e[e.DismissAddAdminNotice = 4096] = "DismissAddAdminNotice", e[e.DismissAIPolicyBanner = 32] = "DismissAIPolicyBanner", e[e.DismissClosedEditModal = 1024] = "DismissClosedEditModal", e[e.DismissCloseReopenPrivilegeExplanationModal = 128] = "DismissCloseReopenPrivilegeExplanationModal", e[e.DismissCloseReopenPrivilegePopover = 64] = "DismissCloseReopenPrivilegePopover", e[e.DismissFollowQuestionIntroPopover = 512] = "DismissFollowQuestionIntroPopover", e[e.DismissMarkdownEditorHelp = 2] = "DismissMarkdownEditorHelp", e[e.DismissMentionsCallout = 8] = "DismissMentionsCallout", e[e.DismissModalForCloseVoteQueue = 524288] = "DismissModalForCloseVoteQueue", e[e.DismissModalForCompletedEditOnClosedQuestion = 2048] = "DismissModalForCompletedEditOnClosedQuestion", e[e.DismissModalForContentHealthQueue = 134217728] = "DismissModalForContentHealthQueue", e[e.DismissModalForFirstAnswersQueue = 67108864] = "DismissModalForFirstAnswersQueue", e[e.DismissModalForFirstPostQueue = 131072] = "DismissModalForFirstPostQueue", e[e.DismissModalForFirstQuestionsQueue = 33554432] = "DismissModalForFirstQuestionsQueue", e[e.DismissModalForHelperQueue = 4194304] = "DismissModalForHelperQueue", e[e.DismissModalForLateAnswerQueue = 262144] = "DismissModalForLateAnswerQueue", e[e.DismissModalForLowQualityPostQueue = 16777216] = "DismissModalForLowQualityPostQueue", e[e.DismissModalForReopenVoteQueue = 1048576] = "DismissModalForReopenVoteQueue", e[e.DismissModalForSuggestedEditQueue = 8388608] = "DismissModalForSuggestedEditQueue", e[e.DismissModalForTriageQueue = 2097152] = "DismissModalForTriageQueue", e[e.DismissNewStagingGroundAuthorNotice = 1073741824] = "DismissNewStagingGroundAuthorNotice", e[e.DismissNewStagingGroundAuthorQuestionNotice = 64] = "DismissNewStagingGroundAuthorQuestionNotice", e[e.DismissNewStagingGroundReviewerNotice = 536870912] = "DismissNewStagingGroundReviewerNotice", e[e.DismissPostReactionIntroPopover = 256] = "DismissPostReactionIntroPopover", e[e.DismissQuestionPageProductBanner = 16] = "DismissQuestionPageProductBanner", e[e.DismissReviewOnboarding = 32768] = "DismissReviewOnboarding", e[e.DismissWelcomeModal = 32] = "DismissWelcomeModal", e[e.FreeVotesLearnedAbout = 128] = "FreeVotesLearnedAbout", e[e.HideLeftNavigation = 4] = "HideLeftNavigation", e[e.IsShareFeedbackDefaultSelf = 268435456] = "IsShareFeedbackDefaultSelf", e[e.None = 0] = "None", e[e.ReviewQueueNoticeIsForCampaign = 16384] = "ReviewQueueNoticeIsForCampaign", e[e.ShowNewReviewerOnboarding = 65536] = "ShowNewReviewerOnboarding", e[e.ShowReviewQueueNotice = 8192] = "ShowReviewQueueNotice", e[e.TeamGuide = 1] = "TeamGuide"
                    }(a || (a = {})),
                    function(e) {
                        e.Facebook = "facebook", e.Google = "google", e.Gravatar = "gravatar", e.GravatarIdenticon = "gravatarIdenticon", e.Imgur = "imgur", e.LocalProvider = "localProvider", e.StackOverflowImageService = "stackOverflowImageService"
                    }(o || (o = {}))
            },
            70243: (e, t, n) => {
                "use strict";

                function i(e) {
                    return (...t) => e()(...t)
                }
                n.d(t, {
                    Ec: () => a,
                    Ol: () => u,
                    P0: () => r,
                    U$: () => h,
                    aT: () => o,
                    de: () => l,
                    p6: () => s,
                    wb: () => d,
                    xA: () => c
                });
                const s = i((() => StackExchange.helpers.addSpinner)),
                    a = (i((() => StackExchange.helpers.addStacksSpinner)), i((() => StackExchange.helpers.addLightbox)), i((() => StackExchange.helpers.getLikelyErrorMessage)), i((() => StackExchange.helpers.getRejectedMockXhr)), i((() => StackExchange.helpers.getSpinnerImg)), i((() => StackExchange.helpers.removeMessages)), i((() => StackExchange.helpers.removeSpinner))),
                    o = (i((() => StackExchange.helpers.showErrorMessage)), i((() => StackExchange.helpers.showInfoMessage)), i((() => StackExchange.helpers.showMessage)), i((() => StackExchange.helpers.showSuccessMessage)), i((() => StackExchange.helpers.showModal)), i((() => StackExchange.helpers.loadModal))),
                    r = i((() => StackExchange.helpers.showToast)),
                    c = i((() => StackExchange.helpers.hideToasts)),
                    l = (i((() => StackExchange.helpers.suggestedTransientTimeout)), i((() => StackExchange.helpers.toggleStacksPopover))),
                    u = (i((() => StackExchange.helpers.queueStacksPopover)), i((() => StackExchange.helpers.submitFormOnEnterPress)), i((() => StackExchange.helpers.updateQueryStringParameter)), i((() => StackExchange.helpers.DelayedReaction))),
                    d = (i((() => StackExchange.helpers.closePopups)), i((() => StackExchange.helpers.showStacksNotice)), i((() => StackExchange.helpers.removeParameterFromQueryString)), i((() => StackExchange.helpers.enableSubmitButton)), i((() => StackExchange.helpers.disableSubmitButton)), i((() => StackExchange.helpers.loadTicks)), i((() => StackExchange.helpers.encodeHexHtmlEntities)), i((() => StackExchange.helpers.bindOnHashChange_HighlightDestination)), i((() => StackExchange.helpers.MagicPopup)), i((() => StackExchange.helpers.copyTextToClipboard)), i((() => StackExchange.helpers.noDiacritics)), i((() => StackExchange.helpers.tagSeparator)), i((() => StackExchange.helpers.sanitizeAndSplitTags)), new Promise((e => {
                        "undefined" != typeof window ? StackExchange.ready(e) : e()
                    })));

                function h(e) {
                    return (new DOMParser).parseFromString(e, "text/html").body.textContent || ""
                }
            },
            1977: (e, t, n) => {
                "use strict";

                function i(e, t, n = void 0, i = void 0) {
                    const s = new FormData;
                    s.append("fKey", null != i ? i : StackExchange.options.user.fkey), s.append("data", JSON.stringify(t)), s.append("event", e);
                    let a = {};
                    n && (a["X-Previous-Event-Id"] = n), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                        method: "POST",
                        keepalive: !0,
                        body: s,
                        headers: a
                    }).then((() => {}))
                }
                n.d(t, {
                    H: () => i
                })
            },
            39984: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconAchievementsSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M11 2V1H3v1H0v3c0 1.6 1.4 3 3 3 0 0 .5 2 3 2v1H4s-1 1.5-1 2h8c0-.4-1-2-1-2H8v-1c2.5 0 3-2 3-2 1.6-.2 3-1.4 3-3V2zM3 6c-.5 0-1-.5-1-1V4h1zm9-1c0 .5-.5 1-1 1V4h1zM7 7a2 2 0 1 1 0-4 2 2 0 0 1 0 4"/></svg>'
            },
            55698: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconAlert" width="18" height="18"  viewBox="0 0 18 18"><path  d="M7.95 2.71c.58-.94 1.52-.94 2.1 0l7.69 12.58c.58.94.15 1.71-.96 1.71H1.22C.1 17-.32 16.23.26 15.29zM8 6v5h2V6zm0 7v2h2v-2z"/></svg>'
            },
            46522: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconAlertCircle" width="18" height="18"  viewBox="0 0 18 18"><path  d="M9 17c-4.36 0-8-3.64-8-8s3.64-8 8-8 8 3.64 8 8-3.64 8-8 8M8 4v6h2V4zm0 8v2h2v-2z"/></svg>'
            },
            23314: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconAlertSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M5.97 1.7c.57-.94 1.5-.93 2.05 0l5.73 9.59c.57.94.12 1.71-.98 1.71H1.22c-1.1 0-1.54-.77-.97-1.71zM6 4v5h2V4zm0 6v2h2v-2z"/></svg>'
            },
            81979: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconCheckmark" width="18" height="18"  viewBox="0 0 18 18"><path  d="M16 4.41 14.59 3 6 11.59 2.41 8 1 9.41l5 5z"/></svg>'
            },
            99071: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18"  viewBox="0 0 18 18"><path  d="M15 4.41 13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9z"/></svg>'
            },
            49399: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconClearSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M12 3.41 10.59 2 7 5.59 3.41 2 2 3.41 5.59 7 2 10.59 3.41 12 7 8.41 10.59 12 12 10.59 8.41 7z"/></svg>'
            },
            70854: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconDevTo" width="18" height="18"  viewBox="0 0 18 18"><path fill="#010101" d="M15 1a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V3c0-1.1.9-2 2-2zm-3 5.02h-1.18l1.4 5.24c.36.86 1.16 1.1 1.65.13l.06-.13 1.39-5.24h-1.18l-1.07 4.12zm-1.96 0H7.75a.7.7 0 0 0-.7.65l-.01.1v4.53c0 .37.29.67.65.7l.1.01h2.25v-1.07H8.1V9.26h1.18V8.19H8.1v-1.1h1.93zm-5.32 0H3v5.99h1.68c1.33 0 1.75-1.03 1.75-1.71V7.73c0-.68-.43-1.71-1.71-1.71m.06 1.12a.7.7 0 0 1 .42.16q.21.15.21.47v2.52q0 .32-.2.47a.7.7 0 0 1-.43.16h-.63V7.14z"/></svg>'
            },
            57948: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconFacebook" width="18" height="18"  viewBox="0 0 18 18"><mask id="a" width="24" height="24" x="-3" y="-3" maskUnits="userSpaceOnUse" style="mask-type:luminance"><path fill="var(--white)" d="M-2.2-2.2h22.4v22.4H-2.2z"/></mask><g mask="url(#Facebooka)"><path fill="#0866FF" d="M17 9a8 8 0 1 0-9.93 7.76v-5.32H5.42V9h1.65V7.95c0-2.73 1.23-3.99 3.9-3.99.51 0 1.38.1 1.74.2v2.22q-.3-.03-.92-.03c-1.31 0-1.82.5-1.82 1.79V9h2.61l-.45 2.44H9.97v5.5A8 8 0 0 0 17 9"/><path fill="var(--white)" d="M12.13 11.44 12.58 9H9.97v-.86c0-1.3.5-1.8 1.82-1.8q.62 0 .92.04V4.16c-.36-.1-1.23-.2-1.74-.2-2.67 0-3.9 1.26-3.9 3.99V9H5.42v2.44h1.65v5.32a8 8 0 0 0 2.9.18v-5.5z"/></g></svg>'
            },
            86957: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconHelpSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M7 1C3.74 1 1 3.77 1 7c0 3.26 2.77 6 6 6 3.27 0 6-2.73 6-6s-2.73-6-6-6m1.06 9.06c-.02.63-.48 1.02-1.1 1-.57-.02-1.03-.43-1.01-1.06s.5-1.04 1.08-1.02c.6.02 1.05.45 1.03 1.08m.73-3.07-.47.3q-.31.23-.44.6a4 4 0 0 0-.08.65c0 .04-.03.14-.16.14h-1.4c-.14 0-.16-.09-.16-.13q-.02-.76.36-1.42.53-.64 1.26-1.06c.15-.1.21-.21.3-.33q.27-.32.28-.74c.01-.67-.53-1.14-1.18-1.14-.9 0-1.18.7-1.18 1.46H4.2c0-1.17.31-1.92.98-2.36a3.5 3.5 0 0 1 1.83-.44c.88 0 1.58.16 2.2.62q.88.62.88 1.82-.02.74-.43 1.24-.23.3-.86.79z"/></svg>'
            },
            65306: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconIndustrySm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M2 2a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2h3a1 1 0 0 1 1 1v8H2zm2 1v2h2V3zm2 3H4v2h2zm0 3H4v2h2zm2-3v2h2V6zm2 3H8v2h2z"/></svg>'
            },
            60424: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconLink" width="18" height="18"  viewBox="0 0 18 18"><path  d="M7.22 11.83a6 6 0 0 0 1.62.85l.61-1.8a4.1 4.1 0 1 1 4.04-.8l1.26 1.42a6 6 0 1 0-7.53.33m3.43-5.6a6 6 0 0 0-1.6-.87L8.4 7.15a4.1 4.1 0 1 1-4.05.73L3.12 6.43a6 6 0 1 0 7.53-.2"/></svg>'
            },
            33529: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconPeople" width="18" height="18"  viewBox="0 0 18 18"><path  d="M17 14c0 .44-.45 1-1 1H9a1 1 0 0 1-1-1H2c-.54 0-1-.56-1-1 0-2.63 3-4 3-4s.23-.4 0-1c-.84-.62-1.06-.59-1-3s1.37-3 2.5-3 2.44.58 2.5 3-.16 2.38-1 3c-.23.59 0 1 0 1s1.55.71 2.42 2.09c.78-.72 1.58-1.1 1.58-1.1s.23-.4 0-1c-.84-.61-1.06-.58-1-3s1.37-3 2.5-3 2.44.59 2.5 3c.05 2.42-.16 2.39-1 3-.23.6 0 1 0 1s3 1.38 3 4"/></svg>'
            },
            82421: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconShareSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M5 1H3a2 2 0 0 0-2 2v8c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V9h-2v2H3V3h2zm2 0h6v6h-2V4.5L6.5 9 5 7.5 9.5 3H7z"/></svg>'
            },
            29107: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconTrendingDown" width="18" height="18"  viewBox="0 0 18 18"><path  d="m11 14 2.29-2.29L10.5 9l-3 3L1 5.5 2.5 4l5 5 3-3 4.21 4.29L17 8v6z"/></svg>'
            },
            86045: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconTrendingNone" width="18" height="18"  viewBox="0 0 18 18"><path  d="M5 8V5L1 9l4 4v-3h8v3l4-4-4-4v3z"/></svg>'
            },
            30604: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconTrendingUp" width="18" height="18"  viewBox="0 0 18 18"><path  d="m11 4 2.29 2.29L10.5 9l-3-3L1 12.5 2.5 14l5-5 3 3 4.21-4.29L17 10V4z"/></svg>'
            },
            24381: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconTwitter" width="18" height="18"  viewBox="0 0 18 18"><path fill="#2AA3EF" d="M17 4.04q-.89.4-1.88.52a3.3 3.3 0 0 0 1.44-1.82q-.96.56-2.09.79a3.28 3.28 0 0 0-5.6 2.99A9.3 9.3 0 0 1 2.12 3.1a3.3 3.3 0 0 0 1.02 4.38 3 3 0 0 1-1.49-.4v.03a3.3 3.3 0 0 0 2.64 3.22 3 3 0 0 1-1.48.06 3.3 3.3 0 0 0 3.07 2.28 6.6 6.6 0 0 1-4.85 1.36 9.3 9.3 0 0 0 5.04 1.47c6.04 0 9.34-5 9.34-9.33v-.42a7 7 0 0 0 1.63-1.7z"/></svg>'
            },
            12034: e => {
                "use strict";
                e.exports = '<svg aria-hidden="true" class="svg-icon iconUndoSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M2.76 2.76A6 6 0 1 1 1.09 8h1.93A4.1 4.1 0 1 0 4.1 4.1L6 6H1V1z"/></svg>'
            },
            68911: e => {
                "use strict";
                e.exports = window.Stacks
            },
            20428: e => {
                "use strict";
                e.exports = window.jQuery
            }
        },
        __webpack_module_cache__ = {},
        leafPrototypes, getProto, inProgress, dataWebpackPrefix;

    function __webpack_require__(e) {
        var t = __webpack_module_cache__[e];
        if (void 0 !== t) return t.exports;
        var n = __webpack_module_cache__[e] = {
            exports: {}
        };
        return __webpack_modules__[e].call(n.exports, n, n.exports, __webpack_require__), n.exports
    }
    __webpack_require__.m = __webpack_modules__, __webpack_require__.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return __webpack_require__.d(t, {
            a: t
        }), t
    }, getProto = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, __webpack_require__.t = function(e, t) {
        if (1 & t && (e = this(e)), 8 & t) return e;
        if ("object" == typeof e && e) {
            if (4 & t && e.__esModule) return e;
            if (16 & t && "function" == typeof e.then) return e
        }
        var n = Object.create(null);
        __webpack_require__.r(n);
        var i = {};
        leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
        for (var s = 2 & t && e;
            "object" == typeof s && !~leafPrototypes.indexOf(s); s = getProto(s)) Object.getOwnPropertyNames(s).forEach((t => i[t] = () => e[t]));
        return i.default = () => e, __webpack_require__.d(n, i), n
    }, __webpack_require__.d = (e, t) => {
        for (var n in t) __webpack_require__.o(t, n) && !__webpack_require__.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, __webpack_require__.f = {}, __webpack_require__.e = e => Promise.all(Object.keys(__webpack_require__.f).reduce(((t, n) => (__webpack_require__.f[n](e, t), t)), [])), __webpack_require__.u = e => 3431 === e ? "webpack-chunks/3431.en.js" : "webpack-chunks/" + e + "." + {
        39: "0c327b2a4933649c046f",
        280: "78aa2de8c7354dc19f59",
        503: "d64ce9cb0e1713a97fa0",
        561: "5d0534ecefc1507a56ed",
        636: "d7d94c5d61a8a63e0a8b",
        968: "5e07d1c4e2181dba23cf",
        1131: "1ac785798c33d445a662",
        1213: "a2ab798ed57291783dac",
        1231: "3a50f67686b31fc42c00",
        1772: "4cad33a1785c14f9a3f8",
        1942: "07c0507f73de5c49faab",
        2009: "ab8906781c9641e430f1",
        2106: "f57196f852a2f5fe8564",
        2390: "91d1fc1f591e852502ad",
        2552: "186e91acc01b74603da0",
        2590: "68290cd8d9bf295c44ac",
        2844: "109973b801f6ff8752ed",
        2978: "b3cb5b00813c7361dcf2",
        2987: "31ffa97bd6b596c9dfe3",
        3274: "f7fd16701248cd3d33fd",
        3450: "1eabc856027e72122a22",
        4066: "2c769aa805d195aaec5b",
        4091: "c6daef6e602f996c0bd3",
        4158: "e231bf4644002ecad221",
        4329: "ef75e680701ad98fc0ca",
        4527: "e8a2a8cd61693351582f",
        4646: "82d21bd7b183cdeb5eeb",
        4714: "a9bc14522e19a4030f31",
        4889: "6064f61c508728f860b4",
        5019: "aadd414ab46b6aa8a9ba",
        5045: "9e0e0db5e5735b1f2f3e",
        5047: "73bf2547156e955eed1d",
        5155: "8929efe69bf21677f6d0",
        5304: "159e929c07ef4e1ebd6e",
        5429: "7397817c795d018d5518",
        5539: "eacd9e0d87d445b94a48",
        5553: "6e0b77f1d4267a1d2b02",
        5850: "44d46a18a41f664670c0",
        6158: "ee3f7ff34c5f4af26d74",
        6194: "726078b69c57150105b4",
        6255: "53461cbdbd4563dce184",
        6261: "d7809c75407908e2bd1e",
        6456: "a0e4e8c639b99fe6d1c1",
        6559: "68b1db9ba257d2dc2bef",
        6671: "6055abe67ec3cac19fc6",
        6737: "914fdaf157147acbae26",
        6883: "fa2b954cf29aa505c136",
        7028: "b7ec91fc61f47e301390",
        7334: "0a1297a871633e0bc52c",
        7356: "581d3b59c4106e99cbf4",
        7438: "4f1949cf0291279dc92f",
        7624: "260c52f6459c3cb9a0af",
        7658: "02e00dd8274b7ca7361f",
        7702: "b53d89d820b40f1b57e5",
        7712: "dfdc4d6ad42ee4bbc8b3",
        7727: "ca5d2c1f92acee0993e6",
        7731: "fc571ef82b17c18d772e",
        7757: "15ab0517852b07044871",
        7908: "7579a1e2dad366811297",
        8155: "0c88c373cd037b2cd1b9",
        8210: "c249e93165dbb518fa58",
        8228: "0ef292c6c07b0b03cc3a",
        8239: "0b62eb96110b44b4d34b",
        8321: "4a304adc6b166c75f6b8",
        8478: "1562eba353e358405709",
        8551: "5037a8be9386358ab941",
        8631: "6796827941bd0634a167",
        8952: "f1f8118c003bd9631032",
        9167: "83584f57bbc43cd4f8bf",
        9168: "f0c0a0da5ec398cd73f3",
        9177: "9f3388250bfe030c2379",
        9203: "87f7098190310b8a6707",
        9218: "c925b7a39a4299fdda5c",
        9314: "34b8f0b382c8eec48309",
        9495: "876a79736eb7223a79e3",
        9754: "56c73e2643f19f438688",
        9761: "41c41f9736c42f864c02",
        9827: "28d65e6c88a4f3f023e0",
        9831: "2dd08ae9fc8c832d8b44"
    }[e] + ".en.js", __webpack_require__.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), __webpack_require__.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), inProgress = {}, dataWebpackPrefix = "stackoverflow:", __webpack_require__.l = (e, t, n, i) => {
        if (inProgress[e]) inProgress[e].push(t);
        else {
            var s, a;
            if (void 0 !== n)
                for (var o = document.getElementsByTagName("script"), r = 0; r < o.length; r++) {
                    var c = o[r];
                    if (c.getAttribute("src") == e || c.getAttribute("data-webpack") == dataWebpackPrefix + n) {
                        s = c;
                        break
                    }
                }
            s || (a = !0, (s = document.createElement("script")).charset = "utf-8", s.timeout = 120, __webpack_require__.nc && s.setAttribute("nonce", __webpack_require__.nc), s.setAttribute("data-webpack", dataWebpackPrefix + n), s.src = e), inProgress[e] = [t];
            var l = (t, n) => {
                    s.onerror = s.onload = null, clearTimeout(u);
                    var i = inProgress[e];
                    if (delete inProgress[e], s.parentNode && s.parentNode.removeChild(s), i && i.forEach((e => e(n))), t) return t(n)
                },
                u = setTimeout(l.bind(null, void 0, {
                    type: "timeout",
                    target: s
                }), 12e4);
            s.onerror = l.bind(null, s.onerror), s.onload = l.bind(null, s.onload), a && document.head.appendChild(s)
        }
    }, __webpack_require__.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, __webpack_require__.p = "", (() => {
        var e = {
            579: 0,
            6883: 0
        };
        __webpack_require__.f.j = (t, n) => {
            var i = __webpack_require__.o(e, t) ? e[t] : void 0;
            if (0 !== i)
                if (i) n.push(i[2]);
                else {
                    var s = new Promise(((n, s) => i = e[t] = [n, s]));
                    n.push(i[2] = s);
                    var a = __webpack_require__.p + __webpack_require__.u(t),
                        o = new Error;
                    __webpack_require__.l(a, (n => {
                        if (__webpack_require__.o(e, t) && (0 !== (i = e[t]) && (e[t] = void 0), i)) {
                            var s = n && ("load" === n.type ? "missing" : n.type),
                                a = n && n.target && n.target.src;
                            o.message = "Loading chunk " + t + " failed.\n(" + s + ": " + a + ")", o.name = "ChunkLoadError", o.type = s, o.request = a, i[1](o)
                        }
                    }), "chunk-" + t, t)
                }
        };
        var t = (t, n) => {
                var i, s, [a, o, r] = n,
                    c = 0;
                if (a.some((t => 0 !== e[t]))) {
                    for (i in o) __webpack_require__.o(o, i) && (__webpack_require__.m[i] = o[i]);
                    if (r) r(__webpack_require__)
                }
                for (t && t(n); c < a.length; c++) s = a[c], __webpack_require__.o(e, s) && e[s] && e[s][0](), e[s] = 0
            },
            n = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        n.forEach(t.bind(null, 0)), n.push = t.bind(null, n.push.bind(n))
    })();
    var __webpack_exports__ = {};
    (() => {
        "use strict";
        __webpack_require__.p = document.getElementById("webpack-public-path").innerText + "Js/"
    })(), (() => {
        "use strict";
        var e = __webpack_require__(84155),
            t = __webpack_require__.n(e);
        n = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        var n = n || {};

        function i(e) {
            const t = [...e.keys()];
            t.sort();
            for (const n of t) e(n)
        }
        n.realtime = function() {
            var e, i = null,
                s = {},
                a = [],
                o = 0,
                r = [],
                c = 10,
                l = !1,
                u = !1,
                d = !1,
                h = !1,
                _ = new(t());

            function p() {
                i && (i.dispose(), i = null)
            }

            function f() {
                if (null != i && i.isOpen())
                    for (var e = 0, t = r.length; e < t; e++) g("sending " + r[e]), i.send(r[e])
            }

            function g(e) {
                (n && n.options && n.options.enableLogging || $ && $.cookie && $.cookie("devlog")) && console.log("realtime: " + e)
            }

            function m(e, t) {
                r.push(e), (t = !1 !== t) && f()
            }

            function v(e) {
                g("unsubscribing " + e);
                var t = $.inArray(e, r); - 1 != t && (r.splice(t, 1), null != i && i.isOpen() && i.send("-" + e))
            }

            function w(e, t) {
                $(".js-accepted-answer-indicator").each((function() {
                    var n = !t && $(this).closest(".js-voting-container").data("post-id") === e.answerid;
                    $(this).toggleClass("d-none", !n)
                }))
            }

            function b(e, t, i, a) {
                var o = e + "-" + t;
                m(o), _.addListener(o, (function(e) {
                    g("received (active) on " + o);
                    var r = JSON.parse(e);
                    i && !i(r) || (! function(e, t) {
                        if (null != n.options.user.accountId && n.tagPreferences.isIgnored(e.tags)) return;
                        s[e.id] = {
                            id: e.id,
                            fetch: !0,
                            index: (new Date).getTime(),
                            siteid: e.siteid,
                            channel: t
                        }, $(".js-new-post-activity").remove(), $("#question-mini-list, #questions").prepend(E), $(".tag-sponsorship").length > 0 && $("#question-mini-list, #questions").css("margin-top", "0px")
                    }(r, t), a && a(r))
                }))
            }
            var k = function() {
                var e = Object.keys(a).length;
                0 == e && $(".js-new-answer-activity").remove();
                var t = $('<div class="new-answer-activity ta-center bar-sm mb16 js-new-answer-activity">').append($('<a class="d-block py8" href="#">').text(__tr(["$count$ new answer to this question", "$count$ new answers to this question"], {
                    count: e
                }, "en", ["count"])));
                return t.on("click", (function() {
                    n.realtime.expandAnswers()
                })), t.find("a").on("click", (function(e) {
                    return e.stopPropagation(), n.realtime.expandAnswers(), !1
                })), t
            };

            function y() {
                $(".js-new-answer-activity").remove(), $("#answers-header").prepend(k)
            }
            var x = function(e, t) {
                    var n = [],
                        i = {};
                    if ($(e).each((function(e, t) {
                            var s = $(".question[data-questionid=" + t + "], .answer[data-answerid=" + t + "]");
                            s.length > 0 && (n.push(+t), i[+t] = s)
                        })), 0 === n.length) return $.Deferred().resolve(i);
                    var s = "/posts/ajax-load-realtime/{postIdsSemiColonDelimited}?title=true&includeComments={includeComments}".formatUnicorn({
                        postIdsSemiColonDelimited: n.join(";"),
                        includeComments: !!t
                    });
                    return $.ajax({
                        type: "GET",
                        url: s,
                        dataType: "json"
                    }).then((function(e) {
                        var n = $(e.Html).filter(".question, .answer").map((function() {
                            var e = $(this),
                                n = +(e.data("questionid") || e.data("answerid") || 0),
                                s = i[n];
                            return S(s, e, n, t)
                        })).get();
                        return $.when.apply($, n)
                    })).then((function() {
                        return i
                    }))
                },
                S = function(e, t, i, s) {
                    var a = e.find(".postcell, .answercell"),
                        o = t.find(".postcell, .answercell").css({
                            opacity: 0
                        }),
                        r = e.hasClass("question"),
                        c = $("body").hasClass("question-page"),
                        l = $("h1 a.question-hyperlink"),
                        u = t.data("title"),
                        d = r && c && l.text() ? .trim() !== u,
                        h = e.find(".js-comments-list"),
                        _ = function(e) {
                            return e.animate({
                                opacity: 0
                            }, 150)
                        },
                        p = function(e) {
                            return e.animate({
                                opacity: 1
                            }, 150)
                        };
                    if (window.history && c) {
                        var f = d ? __tr(["$pageTitle$ - $siteName$"], {
                            pageTitle: u,
                            siteName: n.options.site.name
                        }, "en", []) : document.title;
                        window.history.replaceState(window.history.state, f, "#" + i)
                    }
                    return $.when(!d || _(l), !s || _(h), _(a)).then((function() {
                        return e.prop("classList", t.prop("classList")), d && l.text(u), s && n.comments.replaceAll(e, t.find(".js-comment")), a.replaceWith(o), styleCode(), $.when(!d || p(l), !s || p(h), p(o))
                    }))
                };
            var E = function() {
                var e = Object.keys(s).length;
                T(e);
                var t = $('<div class="js-new-post-activity bg-black-150 bar-sm ta-center my8">').append($('<a class="s-btn d-block" href="#">').text(__tr(["$count$ question with new activity", "$count$ questions with new activity"], {
                    count: e
                }, "en", ["count"])));
                return t.on("click", (function() {
                    n.realtime.expandActiveQuestions()
                })), t.find("a").on("click", (function(e) {
                    return e.stopPropagation(), n.realtime.expandActiveQuestions(), !1
                })), t
            };

            function C(e, t) {
                return e.index < t.index ? -1 : e.index > t.index ? 1 : 0
            }

            function T(e) {
                var t = document.title.replace(/^\(\d*\*?\) /, "");
                e > 0 && (t = "(" + e + ") " + t), window.setTimeout((function() {
                    $(document).attr("title", t)
                }), 200)
            }

            function O() {
                d = !0, n.notify.show(__tr(["Instant updates have been disabled due to inactivity "], undefined, "en", []) + '<a href=".">' + __tr(["refresh"], undefined, "en", []) + "</a>" + __tr([" to reconnect"], undefined, "en", []), 312), i.dispose()
            }

            function j() {
                for (var e = $("span.relativetime, span.relativetime-clean"), t = 0; t < e.length; t++)
                    if (e[t].title) {
                        var n = A(e[t].title);
                        n && (e[t].innerHTML = n)
                    }
            }

            function A(e) {
                if (e) {
                    var t = e.match(/^(\d{4}-\d\d-\d\d) (\d\d:\d\d:\d\dZ)/);
                    if (t) {
                        var i = t[1] + "T" + t[2],
                            s = new Date(i),
                            a = ((new Date).getTime() - s.getTime()) / 1e3 + n.options.serverTimeOffsetSec,
                            o = Math.floor(a / 86400);
                        if (!(isNaN(o) || o < 0 || o >= 31)) return 0 == o && (a < 2 && __tr(["just now"], undefined, "en", []) || a < 60 && (u ? __tr(["$seconds$s ago", "$seconds$s ago"], {
                            seconds: Math.floor(a)
                        }, "en", ["seconds"]) : __tr(["$seconds$ sec ago", "$seconds$ secs ago"], {
                            seconds: Math.floor(a)
                        }, "en", ["seconds"])) || a < 120 && (u ? __tr(["1m ago"], undefined, "en", []) : __tr(["1 min ago"], undefined, "en", [])) || a < 3600 && (u ? __tr(["$minutes$m ago", "$minutes$m ago"], {
                            minutes: Math.floor(a / 60)
                        }, "en", ["minutes"]) : __tr(["$minutes$ min ago", "$minutes$ mins ago"], {
                            minutes: Math.floor(a / 60)
                        }, "en", ["minutes"])) || a < 7200 && (u ? __tr(["1h ago"], undefined, "en", []) : __tr(["1 hour ago"], undefined, "en", [])) || a < 86400 && (u ? __tr(["$hours$h ago", "$hours$h ago"], {
                            hours: Math.floor(a / 3600)
                        }, "en", ["hours"]) : __tr(["$hours$ hour ago", "$hours$ hours ago"], {
                            hours: Math.floor(a / 3600)
                        }, "en", ["hours"])))
                    }
                }
            }
            return {
                init: function(e) {
                    var t = e.split(","),
                        s = t.length,
                        a = t[o % s],
                        u = n.options.realtime.staleDisconnectIntervalInHours;
                    if ("WebSocket" in window) {
                        if (i) return;
                        if (i = function(e) {
                                var t;
                                return {
                                    on: {
                                        creationfailed: null,
                                        onopen: null,
                                        onmessage: null,
                                        onclose: null,
                                        onerror: null
                                    },
                                    isOpen: function() {
                                        return t && 1 === t.readyState
                                    },
                                    readyState: function() {
                                        return t ? t.readyState : null
                                    },
                                    start: function() {
                                        if (!t) {
                                            var n = this.on;
                                            try {
                                                t = new WebSocket(e)
                                            } catch (e) {
                                                return void(n.creationfailed && n.creationfailed(e.message))
                                            }
                                            t.onopen = function() {
                                                n.open && n.open()
                                            }, t.onclose = function() {
                                                n.close && n.close(), t = null
                                            }, t.onmessage = function(e) {
                                                n.message && n.message(e)
                                            }, t.onerror = function() {
                                                n.error && n.error(), t = null
                                            }
                                        }
                                    },
                                    close: function() {
                                        t && (t.close(), t = null)
                                    },
                                    dispose: function() {
                                        this.close()
                                    },
                                    send: function(e) {
                                        t && t.send(e)
                                    },
                                    open: function() {}
                                }
                            }(a), null === i) return;
                        i.on.open = function() {
                            if (l || (l = !0), o = 0, g("WebSocket opened"), i && 1 === i.readyState()) {
                                var e = "",
                                    t = n.options;
                                if (t) {
                                    e = "|";
                                    t.routeName && (e += t.routeName.toString()), e += "|", t.user && t.user.userId && (e += t.user.userId.toString()), e += "|", t.user && t.user.accountId && (e += t.user.accountId.toString()), e += "|", t.user && t.user.rep && (e += t.user.rep.toString()), e = e + "|" + window.location.host + "|", t.serverTime && (e += t.serverTime.toString()), g("analytic: " + (e += "|")), i.send(e)
                                }
                            }
                            f(), _.addListener("hb", (function(e) {
                                g("heartbeat received; responding"), i.send(e)
                            })), setInterval(j, 6e4), u > 0 && setTimeout(O, 1e3 * u * 60 * 60)
                        }, i.on.message = function(e) {
                            var t = JSON.parse(e.data || e);
                            if ("realtime-broadcast" === t.action) {
                                g("broadcast message - " + t.data);
                                var n = JSON.parse(t.data).a;
                                "killWebSocket" !== n && "restartWebSocket" !== n || (g("Applying action: " + n), (d = "killWebSocket" === n) ? p() : i.close())
                            } else "debug-info" == t.action ? g(t.data) : _.emitEvent(t.action, [t.data])
                        }, i.on.close = function() {
                            i = null, g("WebSocket closed"), !d && o < 5 && c > 0 && (o++, c--, g("reconnect attempt:" + o + " max retries:" + c), setTimeout((function() {
                                n.realtime.init(e)
                            }), 5 * Math.random() * 60 * 1e3))
                        }, i.on.error = function() {
                            g("WebSocket failed"), p()
                        }, i.on.creationfailed = function(e) {
                            g("Sockets disabled - " + e), p()
                        }, i.start(), r.length > 0 && i && i.open()
                    }
                },
                log: g,
                simulate: function(e) {
                    _.emitEvent(e.action, [e.data]), console.dir(_)
                },
                expandActiveQuestions: function() {
                    var t = [];
                    for (var i in s) s.hasOwnProperty(i) && t.push(s[i]);
                    if (0 !== t.length) {
                        var a = t.sort(C).slice(0, 50);
                        $.post("/posts/ajax-load-realtime-list", {
                            postIdsSemiColonDelimited: a.map((function(e) {
                                return e.id
                            })).join(";"),
                            channel: a[0].channel
                        }).done((function(t) {
                            for (var i = 0; i < a.length; i++) {
                                var s = a[i];
                                s.body = t[s.id], s.body && ($("#question-summary-" + s.id).remove(), $(s.body).prependTo("#question-mini-list, #questions").hide().fadeIn())
                            }
                            T(0), null != n.options.user.accountId && n.tagPreferences.applyPrefs(!0, e), j(), $(".js-new-post-activity").remove()
                        })), s = {}
                    }
                },
                expandAnswers: function() {
                    $("#tabs").show(), $(".js-new-answer-activity").remove();
                    var e = $("#answers #answers-header"),
                        t = e.find(".answers-subheader h2"),
                        i = parseInt(t.text()) + a.length;
                    isNaN(i) && (i = a.length), t.text(__tr(["$answerCount$ Answer", "$answerCount$ Answers"], {
                        answerCount: i
                    }, "en", ["answerCount"])), $.ajax({
                        url: "/posts/ajax-load-realtime/{postIdsSemiColonDelimited}".formatUnicorn({
                            postIdsSemiColonDelimited: a.join(";")
                        })
                    }).done((function(t) {
                        var i = $('<div class="dno" />').append(t.Html);
                        i.insertAfter(e).fadeIn(400, (function() {
                            i.removeClass("dno"), styleCode(), n.vote.init(t.VotesCastJson), i.find(".answer").each((function() {
                                n.comments.init({
                                    post: $(this)
                                })
                            }))
                        }))
                    })), n.question.bindSuggestedEditPopupLinks(), j(), a = []
                },
                subscribeToActiveQuestions: function(t, n, i, s, a, o) {
                    e = i, u = a, b(t, n, (function(e) {
                        if (s)
                            for (var t = 0; t < s.length; t++)
                                if (-1 == $.inArray(s[t], e.tags)) return !1;
                        return !0
                    }), o)
                },
                subscribeToUQL: function(t, n, i, s, a) {
                    var o = function(e) {
                        return s.noAnswers && !e.noAnswers ? (g("ignoring because has answers"), !1) : !(s.hasBounty && !e.hasBounty) || (g("ignoring because no bounty"), !1)
                    };
                    e = a, 0 === i.length ? b(t, "questions-" + n, !1, o) : function(e) {
                        var t = [],
                            n = [];
                        return e.forEach((function(e) {
                            "or" === e ? n.length > 0 && (t.push(n), n = []) : e.length > 0 && "and" !== e && n.push(e)
                        })), n.length > 0 && t.push(n), t
                    }(i).forEach((function(e) {
                        var i = function(e) {
                            for (var t = e.length - 1; t >= 0; t--)
                                if ("-" !== e[t][0]) return e[t];
                            return null
                        }(e);
                        if (null !== i) {
                            var s = "questions-" + n + "-tag-" + i;
                            b(t, s, !1, (function(t) {
                                if (!o(t)) return !1;
                                for (var n = 0; n < e.length; n++) {
                                    var i = e[n];
                                    if ("-" !== i[0]) {
                                        if (-1 === $.inArray(i, t.tags)) return g("ignoring because post does not contain " + i + " in " + s), !1
                                    } else {
                                        var a = i.substr(1);
                                        if (-1 !== $.inArray(a, t.tags)) return g("ignoring because post contains " + a + " in " + s), !1
                                    }
                                }
                                return !0
                            }))
                        }
                    }))
                },
                subscribeToQuestion: function(e, t) {
                    var i = e + "-question-" + t;
                    m(i), _.addListener(i, (function(e) {
                        if (!h) {
                            var t = JSON.parse(e);
                            if (t.acctid != n.options.user.accountId) switch (g(i + " " + e), t.a) {
                                case "score":
                                    ! function(e) {
                                        var t = $(".js-voting-container").filter((function() {
                                            return $(this).data("post-id") === e.id
                                        })).find(".js-vote-count");
                                        if (t.data("value") === e.score) return;
                                        var i = n.vote.normalizePostScore(e.score);
                                        t.data("value", e.score).text(i), 0 === $(":animated").length && t.fadeTo("fast", .7).fadeTo("fast", 1);
                                        n.question.canViewVoteCounts() && n.vote.bindFetchVoteCounts()
                                    }(t);
                                    break;
                                case "comment-add":
                                    ! function(e) {
                                        if (0 != $("#comment-" + e.commentid).length) return;
                                        n.comments.realtimeMessage(e.id)
                                    }(t);
                                    break;
                                case "answer-add":
                                    ! function(e) {
                                        if (0 != $("#answer-" + e.answerid).length) return;
                                        if (a.push(e.answerid), n.cardiologist) {
                                            if (n.cardiologist.isHeartBeating()) n.helpers.DelayedReaction(y, 5e3).trigger();
                                            else y();
                                            n.cardiologist.notifiedOfNewAnswer()
                                        }
                                    }(t);
                                    break;
                                case "accept":
                                    w(t);
                                    break;
                                case "unaccept":
                                    w(t, !0);
                                    break;
                                case "post-edit":
                                    ! function(e) {
                                        var t = $(".question[data-questionid=" + e.id + "], .answer[data-answerid=" + e.id + "]");
                                        if (t.find(".js-new-post-activity[data-postid=" + e.id + "]").length > 0) return;
                                        var n = $('<div class="new-post-activity bar-sm ta-center mb16 js-new-post-activity" data-postid="' + e.id + '">').append($('<a class="d-block py8" href="#">').text(__tr(["An edit has been made to this post"], undefined, "en", []))),
                                            i = 0 === t.find(".inline-editor").length,
                                            s = function() {
                                                $(".js-new-post-activity[data-postid=" + e.id + "]").remove(), i && t.off("click", s), 0 === $("#review-content").length && x([e.id]), $(document).trigger("refreshEdit", e.id)
                                            };
                                        i && t.on("click", s);
                                        n.prependTo(t).find("a").on("click", (function(e) {
                                            return e.stopPropagation(), s(), !1
                                        }))
                                    }(t);
                                    break;
                                case "post-deleted":
                                    ! function(e) {
                                        var t = e.aId || e.qId,
                                            i = !!e.aId,
                                            s = i ? $("#answer-" + e.aId) : $("#question");
                                        s.css("opacity", .1);
                                        var a = $('<div class="realtime-post-deleted-notification" />');
                                        a.insertBefore(s);
                                        var o = n.options.user.canSeeDeletedPosts ? __tr(["This post has been deleted - click to refresh the page"], undefined, "en", []) : __tr(["This post has been deleted and is no longer viewable"], undefined, "en", []);
                                        $("<p>").text(o).appendTo(a).on("click", (function() {
                                            window.location.reload(!0)
                                        })), $(".popup[data-postid=" + t + "]").fadeOutAndRemove()
                                    }(t);
                                    break;
                                case "answers-with-ai-answer-published":
                                    ! function(e) {
                                        const t = $("#answer-" + e.privateAnswerId);
                                        if (!t) return;
                                        t.css("opacity", .1);
                                        const n = $('<div class="realtime-answer-with-ai-published-notification" />');
                                        n.insertBefore(t), $("<p>").text("This answer has been published - click to refresh the page").appendTo(n).on("click", (function() {
                                            window.location.reload()
                                        }))
                                    }(t)
                            }
                        }
                    }))
                },
                unsubscribeToQuestion: function(e, t) {
                    v(e + "-question-" + t)
                },
                pauseQuestionNotifications: function(e) {
                    h = e
                },
                subscribeToStagingGroundQuestion: function(e, t, i, s, a, o) {
                    var r = e + "-question-" + t;
                    m(r), _.addListener(r, (function(e) {
                        if (!h) {
                            var t = JSON.parse(e);
                            if (t.acctid != n.options.user.accountId) switch (g(r + " " + e), t.a) {
                                case "comment-add":
                                    i(t);
                                    break;
                                case "review-action":
                                    s(t);
                                    break;
                                case "post-edit":
                                    a(t);
                                    break;
                                case "post-deleted":
                                    o(t)
                            }
                        }
                    }))
                },
                subscribeToReputationNotifications: function(e) {
                    if (null != n.options.user.accountId) {
                        var t = e + "-" + n.options.user.userId + "-reputation";
                        m(t), _.addListener(t, (function(e) {
                            ! function(e) {
                                var t = $("#hlinks .reputation-score, .links-container .reputation, .js-header-rep");
                                if (t.text() == e.score) return;
                                0 == $(":animated").length && t.fadeTo("fast", .8).fadeTo("fast", 1);
                                t.text(e).attr("title", __tr(["your reputation: $reputation$"], {
                                    reputation: e
                                }, "en", [])), t.trigger("reputationchange")
                            }(e)
                        }))
                    }
                },
                updateRelativeDates: j,
                subscribeToReviewDashboard: function(e) {
                    var t = e + "-review-dashboard-update";
                    m(t), _.addListener(t, (function(e) {
                        var t = JSON.parse(e),
                            n = $('.dashboard-activity[data-review-task="' + t.i + '"]');
                        0 == n.find('.dashboard-user[data-user="' + t.u + '"]').length && (n.find(".dashboard-user:nth-child(6)").remove(), n.css("overflow", "hidden"), n.children().css({
                            left: "-44px"
                        }), n.prepend(t.html).children().animate({
                            left: 0
                        }, (function() {
                            n.css("overflow", "visible")
                        })))
                    }))
                },
                subscribeToTopBarNotifications: function(e) {
                    if (null != n.options.user.accountId) {
                        var t = n.options.user.accountId + "-topbar";
                        m(t), _.addListener(t, (function(e) {
                            n.topbar.handleRealtimeMessage(e)
                        }))
                    }
                },
                subscribeToCounts: function(e) {
                    m(e + "-qcnt-feed"), _.addListener(e + "-qcnt-feed", (function(e) {
                        $("div#q-cnt").html(e)
                    })), m(e + "-evc-feed"), _.addListener(e + "-evc-feed", (function(e) {
                        $("div#evc-cnt").html(e)
                    })), m(e + "-acnt-feed"), _.addListener(e + "-acnt-feed", (function(e) {
                        $("div#a-cnt").html(e)
                    }))
                },
                genericSubscribe: function(e, t) {
                    _.addListener(e, t), m(e)
                },
                genericUnsubscribe: function(e, t) {
                    _.removeListener(e, t), v(e)
                },
                reloadPosts: x,
                debug: function(e) {
                    i ? i.send("debug-" + e) : g("not connected")
                }
            }
        }(), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, i(__webpack_require__(26169)), i(__webpack_require__(96771));
        var s = __webpack_require__(70243);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.helpers.MagicPopup = function(e) {
            var t, n, i, a, o, r = {},
                c = {},
                l = 0;

            function u() {
                if (!o) {
                    o = document.createElement("style");
                    var e = (t = document.querySelector("script[nonce]")) && (t.nonce || t.getAttribute("nonce"));
                    e && o.setAttribute("nonce", e), document.head.appendChild(o)
                }
                var t;
                return o
            }

            function d(e, t) {
                e.data("magic-popup-dynamic-style-class") || (e.data("magic-popup-dynamic-style-class", "magic-popup-dynamic-style-" + ++l), e.addClass(e.data("magic-popup-dynamic-style-class")));
                var n, i = e.data("magic-popup-dynamic-style-class"),
                    s = {
                        zIndex: "z-index"
                    },
                    a = [],
                    o = Object.assign({}, e.data("magic-popup-dynamic-styles") || {}, t);
                for (var r in e.data("magic-popup-dynamic-styles", o), o) Object.prototype.hasOwnProperty.call(o, r) && a.push((s[r] || r) + ":" + (("number" == typeof(n = o[r]) ? n + "px" : n) + ";"));
                c[i] = "." + i + "{" + a.join("") + "}", u().textContent = Object.keys(c).map((function(e) {
                    return c[e]
                })).join("\n")
            }
            var h = (0, s.Ol)((function(n, o) {
                    var c;
                    !a && n && (e.cache && "c_" + n in r ? c = $.Deferred().resolve(r["c_" + n]) : (c = $.ajax({
                        type: "GET",
                        url: n,
                        dataType: "html"
                    }), e.cache && c.done((function(e) {
                        r["c_" + n] = e
                    }))), c.done((function(n) {
                        t && t(), "" != n && function(n, a) {
                            if ($.contains(document.documentElement, n) && (!e.predicate || e.predicate(n))) {
                                var o = $("<div />").attr("id", e.id).addClass(e.className).html(a),
                                    r = $("<div />").addClass("z-popover");
                                d(r, {
                                    position: "absolute",
                                    width: 1,
                                    height: 1,
                                    top: 0,
                                    left: 0
                                }), e.unclipped || d(r, {
                                    overflow: "hidden"
                                }), e.renderInline || !e.hasOwnProperty("renderInline") ? r.append(o).insertAfter(n) : r.append(o).appendTo("body"), void 0 !== window.MathJax && (MathJax.Hub ? window.MathJax.Hub.Typeset(o[0]) : MathJax.typesetPromise([o[0]]).catch((function(e) {
                                    console.error("MathJax typeset failed: " + e.message)
                                })));
                                var c = e.showing(n, o);
                                if (c) {
                                    var l, u = {
                                        left: c.left
                                    };
                                    c.hasOwnProperty("bottom") ? (u.bottom = c.bottom, u.top = "auto") : u.top = c.top || 0, e.shown && (l = function() {
                                        e.shown(n, o)
                                    }), d(r, u);
                                    var h = {
                                        height: o.outerHeight() + 8,
                                        width: o.outerWidth() + 8
                                    };
                                    e.fade ? (r.addClass("d-none"), d(r, h), r.removeClass("d-none"), l && l()) : (d(r, h), l && l()), r.addClass("esc-remove magic-popup").on("popupClosing", (e => {
                                        e.preventDefault(), p()
                                    }))
                                }
                                t = function() {
                                    r.stop().remove(), e.removed && e.removed(n, o), i = null, t = null
                                }, i = (0, s.Ol)(t, e.dismissDelay || 5);
                                var _ = r;
                                c && c.additional && (_ = _.add(...c.additional)), _.on("mouseenter", i.cancel).on("mouseleave", i.trigger), _.on("focusin", i.cancel), _.on("focusout", i.trigger)
                            }
                        }(o, n)
                    })))
                }), 500),
                _ = function() {
                    if (!i || this !== n) return n = this, h.trigger(e.getUrl(this), this), a = !1, !1;
                    i.cancel()
                },
                p = function() {
                    a = !0, h.cancel(), i && i.trigger()
                };
            $(document).on({
                mouseenter: _,
                mouseleave: p,
                focusin: _,
                focusout: p
            }, e.selector)
        };
        __webpack_require__(93850);
        var a = __webpack_require__(76517);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.schematics = function() {
            let e;
            return function(e) {
                e[e.NO = 0] = "NO", e[e.MAYBE = 1] = "MAYBE", e[e.PROBABLY = 2] = "PROBABLY", e[e.YES = 3] = "YES"
            }(e || (e = {})), {
                init: function() {
                    let t;
                    StackExchange.externalEditor.init({
                        thingName: "schematic",
                        getIframeUrl: function(e) {
                            let t = "/plugins/schematics/editor";
                            return e && (t += "?edit=" + encodeURIComponent(e)), t
                        },
                        buttonTooltip: "Schematic",
                        checkSupport: function() {
                            switch (function() {
                                if (!window.postMessage) return e.NO;
                                const t = document.createElement("div");
                                t.innerHTML = "<svg/>";
                                if ("http://www.w3.org/2000/svg" !== (t.firstChild && t.firstChild.namespaceURI)) return e.NO;
                                const n = navigator.userAgent;
                                return /Firefox|Chrome/.test(n) ? e.YES : /Apple/.test(navigator.vendor) || /Opera/.test(n) ? e.PROBABLY : e.MAYBE
                            }()) {
                                case e.YES:
                                    return !0;
                                case e.PROBABLY:
                                    return confirm("Your browser is not officially supported by the schematics editor; however it has been reported to work. Launch the editor?");
                                case e.MAYBE:
                                    return confirm("Your browser is not officially supported by the schematics editor; it may or may not work. Launch the editor anyway?");
                                default:
                                case e.NO:
                                    return alert("Sorry, your browser does not support all the necessary features for the schematics editor."), !1
                            }
                        },
                        onShow: function(e) {
                            const n = $("<div class='popup'>").css("z-index", 1111).text("Loading editor").appendTo("body").show().addSpinner({
                                marginLeft: 5
                            }).center({
                                dy: -200
                            });
                            $("<div style='text-align:right;margin-top: 10px'>").append($("<button>cancel</button>").on("click", (function() {
                                n.remove(), e()
                            }))).appendTo(n), t = function(t) {
                                if ("https://www.circuitlab.com" !== (t = t.originalEvent).origin) return;
                                t.data || e();
                                const i = JSON.parse(t.data);
                                if (i && "success" === i.load) n.remove();
                                else if (i && i.edit_url && i.image_url) {
                                    i.fkey = StackExchange.options.user.fkey;
                                    const t = $("<div class='popup'>").css("z-index", 1111).appendTo("body").show(),
                                        n = function() {
                                            t.text("Storing image").addSpinner({
                                                marginLeft: 5
                                            }).center(), $.post("/plugins/schematics/save", i).done((function(n) {
                                                t.remove(), e(n.img)
                                            })).fail((function(e) {
                                                if (409 === e.status) {
                                                    let i = "Storing aborted";
                                                    e.responseText.length < 200 && (i = e.responseText), t.text(i + ", will retry shortly").addSpinner({
                                                        marginLeft: 5
                                                    }).center(), setTimeout(n, 1e4)
                                                } else t.remove(), alert("Failed to upload the schematic image.")
                                            }))
                                        };
                                    n()
                                }
                            }, $(window).on("message", t)
                        },
                        onRemove: function() {
                            $(window).off("message", t)
                        }
                    })
                }
            }
        }(), StackExchange.externalEditor = function() {
            return {
                init: function(t) {
                    let n = t.thingName,
                        i = function(e) {
                            if ("function" == typeof e) return e;
                            const t = e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
                                n = "\x3c!-- Begin " + t + "[^>]*? --\x3e\\s*!\\[[^\\]]*\\]\\((https?://[^ )]+)[^)]*\\)\\s*\x3c!-- End " + t + " --\x3e";
                            return function(e, t, i, s, a) {
                                return e.replace(new RegExp(n, "g"), (function(e, n, r) {
                                    const c = {
                                        payload: n.replace(/[^-A-Za-z0-9+&@#\/%?=~_|!:,.;\(\)]/g, ""),
                                        pos: o(e, t, r),
                                        len: e.length
                                    };
                                    return -1 === c.pos ? e : (a.push(c), e + "\n\n" + i + s + "-" + (a.length - 1) + "%")
                                }));

                                function o(e, t, n) {
                                    let i = -1,
                                        s = -1;
                                    for (; s = t.indexOf(e, s + 1), -1 !== s;)(i < 0 || Math.abs(s - n) < Math.abs(s - i)) && (i = s);
                                    return i
                                }
                            }
                        }(t.thingFinder || t.thingName),
                        s = t.buttonTooltip,
                        o = t.editLabel || "edit the above " + n,
                        r = t.checkSupport;
                    StackExchange.MarkdownEditor.creationCallbacks.add((function(c, l) {
                        let u, d, h = c.getConverter().hooks,
                            _ = $("#wmd-input" + l);
                        $('<style type="text/css"> .wmd-' + n + "-button span { background-position: 0 0; } .wmd-" + n + "-button:hover span { background-position: 0 -40px; }</style>)").appendTo("head"), _.on("keyup", (function(e) {
                            const t = e.keyCode || e.charCode;
                            if (8 === t || 46 === t) {
                                const e = _.caret().start;
                                _.caret(e, e)
                            }
                        })), h.chain("preConversion", (function(e) {
                            const t = (e.match(/%/g) || []).length,
                                s = _.length && _[0].value || "";
                            return u = new Array(t + 2).join("%"), d = [], i(e, s, u, n, d)
                        })), h.chain("postConversion", (function(e) {
                            return e.replace(new RegExp(u + n + "-(\\d+)%", "g"), (function(e, t) {
                                return "<sup><a href='#' class='edit-" + n + "' data-id='" + t + "'>" + o + "</a></sup>"
                            }))
                        }));
                        const {
                            showEditor: p
                        } = e({
                            initState: e => {
                                let t = _.caret(),
                                    n = _[0].value || "",
                                    i = e ? e.pos : t.start,
                                    s = e ? e.len : t.end - t.start;
                                return {
                                    cursor: t,
                                    preMarkdown: n.substring(0, i),
                                    postMarkdown: n.substring(i + s)
                                }
                            },
                            thingName: t.thingName,
                            onShow: t.onShow,
                            onRemove: (e, n) => {
                                let i = n.preMarkdown.replace(/(?:\r\n|\r|\n){1,2}$/, ""),
                                    s = i + e + n.postMarkdown.replace(/^(?:\r\n|\r|\n){1,2}/, ""),
                                    a = n.cursor.start + e.length - n.preMarkdown.length + i.length;
                                c.textOperation((function() {
                                    _.val(s).trigger("focus").caret(a, a)
                                })), t.onRemove && t.onRemove()
                            },
                            getDivContent: t.getDivContent,
                            getIframeUrl: t.getIframeUrl
                        }), f = "The " + n + " editor does not support touch devices.";
                        let g = !1;
                        $("#wmd-preview" + l).on("touchend", (function() {
                            g = !0
                        })).on("click", "a.edit-" + n, (function(e) {
                            return g ? (alert(f), g = !1, !1) : (g = !1, r && !r() || p(d[$(e.target).attr("data-id")]), !1)
                        })), $("#wmd-input" + l).on("keyup", (function(e) {
                            e.shiftKey || e.altKey || e.metaKey || !e.ctrlKey || e.which !== a.O.M || r && !r() || p()
                        })), setTimeout((function() {
                            const e = $("#wmd-image-button" + l),
                                t = $("<li class='wmd-button wmd-" + n + "-button' id='wmd-" + n + "-button" + l + "' title='" + s + " Ctrl-M'>").insertAfter(e);
                            let i = !1;
                            $("<span>").appendTo(t).on("touchend", (function() {
                                i = !0
                            })).on("click", (function() {
                                if (i) return alert(f), void(i = !1);
                                i = !1, r && !r() || p()
                            }))
                        }), 0)
                    }))
                },
                initModal: e
            };

            function e(e) {
                const t = e.onShow,
                    n = e.onRemove,
                    i = e.thingName,
                    s = e.getIframeUrl,
                    a = e.getDivContent;
                return {
                    showEditor: function(o) {
                        const r = e.initState ? e.initState(o) : {};
                        let c = null;

                        function l(e) {
                            StackExchange.helpers.closePopups(c), n(e, r)
                        }
                        const u = function(e, t) {
                            if (!e) return void setTimeout(l, 0);
                            StackExchange.navPrevention.start();
                            let n = void 0 === t ? ('\n\n\x3c!-- Begin {THING}: In order to preserve an editable {THING}, please\n     don\'t edit this section directly.\n     Click the "edit" link below the image in the preview instead. --\x3e\n\n![{THING}](' + e + ")\n\n\x3c!-- End {THING} --\x3e\n\n").replace(/{THING}/g, i) : t;
                            setTimeout((function() {
                                l(n)
                            }), 0)
                        };
                        if (s) {
                            const e = s(o ? o.payload : null);
                            c = $("<iframe>", {
                                src: e
                            })
                        } else if (a) {
                            const e = a(o ? o.payload : null);
                            c = $(e)
                        }
                        c.addClass("esc-remove").css({
                            position: "fixed",
                            top: "2.5%",
                            left: "2.5%",
                            width: "95%",
                            height: "95%",
                            background: "white",
                            "z-index": 1001
                        }), $("body").loadPopup({
                            html: c,
                            target: $("body"),
                            lightbox: !0
                        }).done((function() {
                            $(window).trigger("resize"), t(u, r)
                        }))
                    }
                }
            }
        }();
        const o = '<svg aria-hidden="true" class="svg-icon iconCopy" width="17" height="18"  viewBox="0 0 17 18"><path  d="M5 6c0-1.09.91-2 2-2h4.5L15 7.5V15c0 1.09-.91 2-2 2H7c-1.09 0-2-.91-2-2zm6-1.25V8h3.25z"/><path  d="M10 1a2 2 0 0 1 2 2H6a2 2 0 0 0-2 2v9a2 2 0 0 1-2-2V4a3 3 0 0 1 3-3z" opacity=".4"/></svg>',
            r = '<svg aria-hidden="true" class="svg-icon iconEye" width="18" height="18"  viewBox="0 0 18 18"><path  d="M9.06 3C4 3 1 9 1 9s3 6 8.06 6C14 15 17 9 17 9s-3-6-7.94-6M9 13a4 4 0 1 1 0-8 4 4 0 0 1 0 8m0-2a2 2 0 0 0 2-2 2 2 0 0 0-2-2 2 2 0 0 0-2 2 2 2 0 0 0 2 2"/></svg>',
            c = '<svg aria-hidden="true" class="svg-icon iconEyeOff" width="18" height="18"  viewBox="0 0 18 18"><path  d="m5.02 9.44-2.22 2.2C1.63 10.25 1 9 1 9s3-6 8.06-6q1.13.01 2.12.38L9.5 5.03 9 5a4 4 0 0 0-3.98 4.44m2.03 3.05A4 4 0 0 0 13 9q-.01-1.1-.54-2l-1.51 1.54q.05.22.05.46a2 2 0 0 1-2.44 1.95zm7.11-7.22A15 15 0 0 1 17 9s-3 6-7.94 6c-1.31 0-2.48-.4-3.5-1l-1.97 2L2 14.41 14.59 2 16 3.41z"/></svg>',
            l = '<svg aria-hidden="true" class="svg-icon iconPlay" width="17" height="18"  viewBox="0 0 17 18"><path  d="M3 2.87a1 1 0 0 1 1.55-.83l9.2 6.13a1 1 0 0 1 0 1.66l-9.2 6.13A1 1 0 0 1 3 15.13z"/></svg>',
            u = '<svg aria-hidden="true" class="svg-icon iconShareSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M5 1H3a2 2 0 0 0-2 2v8c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V9h-2v2H3V3h2zm2 0h6v6h-2V4.5L6.5 9 5 7.5 9.5 3H7z"/></svg>';
        var d = __webpack_require__(20428),
            h = __webpack_require__.n(d);

        function _(e) {
            const t = h()(e);
            return t.extend({
                With(e) {
                    return h()(this).clone().addClass(e)
                },
                WithAttr(e) {
                    const t = h()(this).clone();
                    return t.attr(e), t
                }
            }), t
        }
        var p = __webpack_require__(62418),
            f = __webpack_require__.n(p);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
            function(e, t) {
                if (!StackExchange.settings || !StackExchange.settings.snippets) return;
                let n = !1;
                const i = StackExchange.settings.snippets.renderDomain;
                let s = null;

                function a(t) {
                    return e("<div>").addClass(t)
                }
                let d = 1;

                function h() {
                    const e = "sif" + d;
                    return d++, e
                }

                function p() {
                    return e("<iframe>").attr({
                        name: h(),
                        sandbox: "allow-forms allow-modals allow-scripts",
                        class: "snippet-box-edit snippet-box-result",
                        frameBorder: 0
                    })
                }

                function g(t) {
                    return e("<pre>").addClass("prettyprint-override lang-" + t + " snippet-code-" + t)
                }

                function m(t, n) {
                    return e("<textarea>").attr("name", t).val(n)
                }

                function v(t, n, i) {
                    return e("<form>").css("display", "none").attr({
                        action: t,
                        method: n,
                        target: i
                    })
                }

                function w(t, n) {
                    return e("<input>").attr({
                        type: "text",
                        name: t,
                        value: n
                    })
                }

                function b() {
                    return e('<button type="button" class="s-btn">')
                }

                function k(t) {
                    return e("<code>").text(t)
                }

                function y(d, h) {
                    h = h || {}, d.each((function() {
                        const d = e(this);
                        let g = d.data("_snippet");
                        if (!g) {
                            const k = h.markdownPluginMode;
                            if (g = k ? function() {
                                    const s = {
                                        html: null,
                                        css: null,
                                        js: null,
                                        console: !0,
                                        hide: !1,
                                        babel: null,
                                        babelPresetReact: !1,
                                        babelPresetTS: !1
                                    };
                                    let a = null,
                                        o = null,
                                        r = null,
                                        c = null,
                                        l = null,
                                        u = null,
                                        d = null,
                                        h = null,
                                        _ = !1,
                                        p = !0,
                                        g = null,
                                        b = null,
                                        k = null,
                                        y = null,
                                        x = null,
                                        S = null,
                                        E = null,
                                        C = null,
                                        T = null,
                                        O = null,
                                        $ = null;

                                    function j(e) {
                                        const t = null != e ? e : C.getValue();
                                        return t.indexOf("react") > -1 && t.indexOf("react-dom") > -1 || "" !== a.find("#snpte-react-select").val()
                                    }

                                    function A(e) {
                                        $ = e
                                    }

                                    function R(n, i, a) {
                                        const o = "function" == typeof i ? i : function(e, t) {
                                                return i.replace(/\*version\*/g, e).replace(/\*file\*/g, t)
                                            },
                                            r = o("##version##", "##file##").replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&").replace("cdnjs\\.cloudflare\\.com", "(?:cdnjs\\.cloudflare\\.com|ajax\\.googleapis\\.com)").replace(/##version##/g, "(.*?)").replace(/##file##/g, "(.*?)");
                                        let c;

                                        function l() {
                                            const e = a.getValue().match(r);
                                            e && e.length > 2 ? n.val(e[1] + ":" + e[2]) : n.val("")
                                        }
                                        n.on("change", (function() {
                                            let t = e(this).val().split(":"),
                                                i = t.length > 1 ? t[1] : "";
                                            t = t[0];
                                            let c = a.getValue(),
                                                l = !1;
                                            const u = "" === t ? "" : o(t, i);
                                            c = c.replace(new RegExp(r, "g"), (function() {
                                                return l = !0, u
                                            })), c = c.trim(), l ? a.setValue(c) : ("" !== t && (a.setValue(u + "\n" + c), a.save()), n.is(d) && (s.babelPresetReact = "" !== t))
                                        })), a.on("change", (function() {
                                            t.clearTimeout(c), c = t.setTimeout(l, 1e3)
                                        }))
                                    }

                                    function P(i) {
                                        if (a) return a;

                                        function m(e, i, s) {
                                            const a = CodeMirror.fromTextArea(e, {
                                                electricChars: !1,
                                                smartIndent: !1,
                                                lineNumbers: !0,
                                                lineWrapping: !0,
                                                mode: i,
                                                tabSize: 2,
                                                indentWithTabs: !1,
                                                readOnly: !1
                                            });
                                            let o;
                                            return a.on("change", (function() {
                                                n = !0, t.clearTimeout(o), o = t.setTimeout((function() {
                                                    a.save()
                                                }), 500)
                                            })), a.beautify = function() {
                                                a.setValue(s(a.getValue().trim(), {
                                                    indent_size: a.options.tabSize,
                                                    indent_char: " ",
                                                    unformatted: ["a", "abbr", "area", "audio", "b", "bdi", "bdo", "br", "button", "canvas", "cite", "code", "data", "datalist", "del", "dfn", "em", "embed", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "map", "mark", "math", "meter", "noscript", "object", "output", "progress", "q", "ruby", "s", "samp", "small", "span", "strong", "sub", "sup", "svg", "template", "textarea", "time", "u", "var", "video", "wbr", "text", "acronym", "address", "big", "dt", "ins", "strike", "tt"]
                                                }))
                                            }, a
                                        }

                                        function v(e) {
                                            return '<script src="https://cdnjs.cloudflare.com/ajax/libs/' + e + '/*version*/*file*"><\/script>'
                                        }
                                        a = e($), e(a).find("#snpte-close-button").on("click", (function(t) {
                                            return StackExchange.helpers.closePopups(e(this).closest(".snippet-modal"), "esc"), t.preventDefault(), !1
                                        })), o = a.find("#snpte-jquery-select"), r = a.find("#snpte-d3-select"), c = a.find("#snpte-knockout-select"), l = a.find("#snpte-angular-select"), u = a.find("#snpte-vue-select"), d = a.find("#snpte-react-select"), h = a.find("#snpte-react-dom-select"), _ = a.find("#snpte-hide-snippet"), p = a.find("#snpte-show-console"), g = a.find("#snpte-use-babel"), b = a.find("#snpte-use-babel-preset-ts"), a.find("#snpte-button-run").on("click", (function() {
                                            N()
                                        })), a.find("#snpte-button-tidy").on("click", (function() {
                                            C.beautify(), T.beautify(), O.beautify()
                                        })), a.find("#snpte-button-insert").on("click", (function() {
                                            StackExchange.helpers.closePopups(e(".snippet-modal"))
                                        })), a.find("#snpte-button-reset").on("click", (function() {
                                            D()
                                        })), i.empty().append(a), k = a.find("#snpte-box-edit-html"), y = a.find("#snpte-box-edit-css"), x = a.find("#snpte-box-edit-js"), E = a.find("#snpte-box-edit-result"), S = E.clone(), CodeMirror.commands.insertTab = CodeMirror.commands.insertSoftTab, CodeMirror.keyMap.default["Shift-Tab"] = "indentLess", CodeMirror.commands.indentAuto = function(e) {
                                            e.beautify()
                                        }, C = m(k[0], "htmlmixed", f().html), T = m(y[0], "css", f().css), O = m(x[0], s.babelPresetTS ? {
                                            name: "javascript",
                                            typescript: !0
                                        } : "javascript", f().js), g.on("change", (function({
                                            currentTarget: {
                                                checked: e
                                            }
                                        }) {
                                            e ? b.closest("#babel-preset-ts-input-container").removeClass("d-none") : b.closest("#babel-preset-ts-input-container").addClass("d-none")
                                        })), R(o, v("jquery"), C), R(r, v("d3"), C), R(c, v("knockout"), C), R(l, v("angular.js"), C), R(u, v("vue"), C), R(d, (function(e, t) {
                                            return '<script src="https://cdnjs.cloudflare.com/ajax/libs/react/' + e + "/" + t + '"><\/script>\n<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/' + e + "/" + ((h.find("option[value^='" + e + "']").attr("value") || "").split(":")[1] || t) + '"><\/script>'
                                        }), C), a.find("#snpte-button-extlib").on("click", (function() {
                                            const e = prompt(__tr(["Please enter the URL of an external JS or CSS file"], undefined, "en", []));
                                            if (null == e || "" == e || "" == e.trim()) return;
                                            const t = C.getValue();
                                            if (n(e, ".css")) {
                                                const n = '<link href="' + e + '" rel="stylesheet"/>';
                                                C.setValue(n + "\n" + t)
                                            } else if (n(e, ".js")) {
                                                const n = '<script src="' + e + '"><\/script>';
                                                C.setValue(n + "\n" + t)
                                            } else alert(__tr(["Sorry, but that resource is invalid. Resources must begin with http:// or https:// and allowed extensions are: .css, .js"], undefined, "en", []));

                                            function n(e, t) {
                                                return !(e.length < t.length) && ((0 == (e = e.toLowerCase()).indexOf("https://") || 0 == e.indexOf("http://") || 0 == e.indexOf("//")) && e.substr(e.length - t.length, t.length).toLowerCase() == t.toLowerCase())
                                            }
                                        })), e.each([C, T, O], (function(t, n) {
                                            n.on("focus", (function() {
                                                e(n.getInputField()).parent().parent().parent().children(".js-name").hide()
                                            })), n.on("blur", (function() {
                                                e(n.getInputField()).parent().parent().parent().children(".js-name").show()
                                            }))
                                        }))
                                    }

                                    function N() {
                                        L(), I()
                                    }

                                    function M(e) {
                                        const t = e.html,
                                            i = e.css,
                                            a = e.js,
                                            o = e.console,
                                            r = e.hide,
                                            c = e.babel,
                                            l = e.babelPresetReact,
                                            u = e.babelPresetTS;
                                        null != t && (s.html = t, k.val(t)), null != i && (s.css = i, y.val(i)), null != a && (s.js = a, x.val(a)), null != o && (s.console = o, !1 === o && p.prop("checked", o)), r && (s.hide = r, _.prop("checked", !0)), c && (s.babel = c, g.prop("checked", !0), b.closest("#babel-preset-ts-input-container").removeClass("d-none")), l && (s.babelPresetReact = l), u && (s.babelPresetTS = u, b.prop("checked", !0)), C.setValue(t), T.setValue(i), O.setValue(a), n = !1
                                    }

                                    function D() {
                                        k.val(""), y.val(""), x.val(""), o.val(""), r.val(""), c.val(""), l.val(""), u.val(""), d.val(""), p.prop("checked", !0), _.prop("checked", !1), g.prop("checked", !1), b.prop("checked", !1);
                                        let e = "";
                                        i && (e = "//" + i), U();
                                        v(e + "/js", "GET", E.attr("name")).appendTo("body").submit(), C.setValue(""), T.setValue(""), O.setValue("")
                                    }

                                    function L() {
                                        return s.html = k.val(), s.css = y.val(), s.js = x.val(), s.console = p.prop("checked"), s.hide = _.prop("checked"), s.babel = g.prop("checked"), s.babelPresetReact = j(), s.babelPresetTS = b.prop("checked"), s
                                    }

                                    function I() {
                                        const e = s.css,
                                            t = s.js,
                                            n = s.html,
                                            a = s.console,
                                            o = s.babel,
                                            r = s.babelPresetReact || j(s.html),
                                            c = s.babelPresetTS;
                                        if ("" == e && "" == t && "" == n) return;
                                        let l = "";
                                        i && (l = "//" + i), U();
                                        const u = v(l + "/js", "POST", E.attr("name"));
                                        m("js", t).appendTo(u), m("css", e).appendTo(u), m("html", n).appendTo(u), w("console", "" + (!0 === a)).appendTo(u), w("babel", "" + (!0 === o)).appendTo(u), w("babelPresetReact", "" + (!0 === r)).appendTo(u), w("babelPresetTS", "" + (!0 === c)).appendTo(u), u.appendTo("body"), u.submit().remove()
                                    }

                                    function U() {
                                        if (!S) throw "No template available for result destination";
                                        if (!E) throw "Cannot insert new result destination";
                                        const e = S.clone();
                                        E.replaceWith(e), E = e
                                    }

                                    function F() {
                                        const e = n;
                                        C.refresh(), T.refresh(), O.refresh(), n = e
                                    }
                                    return {
                                        setUIInnerHtml: A,
                                        resize: F,
                                        writeResult: I,
                                        save: L,
                                        clear: D,
                                        load: M,
                                        run: N,
                                        generate: P,
                                        registerExternalLibChange: R
                                    }
                                }() : function() {
                                    const n = {
                                        html: null,
                                        css: null,
                                        js: null,
                                        console: !1,
                                        hide: !1,
                                        babel: null,
                                        babelPresetReact: !1,
                                        babelPresetTS: !1
                                    };
                                    let s = null,
                                        d = null,
                                        h = null,
                                        f = null;

                                    function g(e) {
                                        return e.indexOf("react") > -1 && e.indexOf("react-dom") > -1
                                    }

                                    function k(i) {
                                        let r = null;
                                        if (s) return s;
                                        f = null, h = p(), s = !0;
                                        const g = b().addClass("s-btn__filled flex--item").append(_(l), e("<span>").text(" " + __tr(["Run code snippet"], undefined, "en", []))).on("click", (function() {
                                                y()
                                            })),
                                            m = b().addClass("s-btn__outlined flex--item js-edit-snippet").text("Edit code snippet").hide(),
                                            v = b().addClass("flex--item js-show-hide-results").append(_(c), e("<span>").text(" " + __tr(["Hide Results"], undefined, "en", []))).on("click", (function() {
                                                x(), r.show()
                                            }));
                                        v.hide(), r = b().addClass("flex--item snippet-expand-link popout-code").append(_(u), e("<span>").text(" " + __tr(["Expand"], undefined, "en", []))).on("click", (function() {
                                            const n = f;
                                            if (n) {
                                                const i = n.element;
                                                i.removeClass("expanded-snippet"), i.find(".snippet-expand-link>span").text(" " + __tr(["Expand"], undefined, "en", [])), i.find(".snippet-show-link, .snippet-show-link-chevron").show();
                                                const s = n.parent,
                                                    a = s.children();
                                                a.length ? e(a[n.indexWithinParent]).before(i) : e(s).append(i), f = null, e(".topbar, .container, .js-top-bar, #footer").show(), v.hide(), x(!0), e(t).scrollTop(T)
                                            } else {
                                                T = e(t).scrollTop();
                                                const n = e(this).closest(".snippet");
                                                f = {
                                                    element: n,
                                                    indexWithinParent: n.index(),
                                                    parent: n.parent()
                                                }, n.addClass("expanded-snippet"), n.find(".snippet-expand-link>span").text(" " + __tr(["Return to post"], undefined, "en", [])), n.find(".snippet-show-link, .snippet-show-link-chevron").hide(), x(!0), e(".topbar, .container, .js-top-bar, #footer").hide(), e("body").append(n), w.hide(), v.hide()
                                            }
                                        }));
                                        const w = b().addClass("flex--item copySnippet").append(_(o), e("<span>").text(" " + __tr(["Copy to answer"], undefined, "en", []))).on("click", (function() {
                                                const t = e("#show-editor-button"),
                                                    i = e("textarea.wmd-input").length > 0 ? e("textarea.wmd-input") : e("textarea.js-stacks-editor-backing-textarea");
                                                if (t.is(":visible")) {
                                                    const n = t.offset().top;
                                                    e("html").animate({
                                                        scrollTop: n - 60
                                                    }), e("body").animate({
                                                        scrollTop: n - 60
                                                    }, {
                                                        complete: function() {
                                                            t.children("input").trigger("click")
                                                        }
                                                    })
                                                } else {
                                                    const t = e("#post-editor").offset().top;
                                                    e("html, body").animate({
                                                        scrollTop: t - 60
                                                    })
                                                }
                                                const s = S(n);
                                                i.val(i.val() + "\n\n" + s), StackExchange.MarkdownEditor.refreshAllPreviews()
                                            })),
                                            k = a("snippet-ctas d-flex ai-center").append(a("d-flex gs4").append(g, m), a("d-flex ml-auto gs4").append(v, w, r));
                                        d = a("snippet-result-code").append(h).hide();
                                        const E = a("snippet-result").append(k, d);
                                        return i.append(E), s
                                    }

                                    function y() {
                                        h && h.remove(), h = p(), d.append(h);
                                        h.closest(".snippet-result").find("button.js-show-hide-results").empty().append(_(c)).append(e("<span>").text(" " + __tr(["Hide results"], undefined, "en", []))).show(), h.parent().is(":hidden") && h.parent().slideDown(200, (function() {})), C()
                                    }

                                    function x(t = !1) {
                                        const n = h.parent(),
                                            i = n.closest(".snippet-result").find("button.js-show-hide-results");
                                        n.is(":visible") || t ? n.slideUp(200, (function() {
                                            i.empty().append(_(r)).append(e("<span>").text(" " + __tr(["Show results"], undefined, "en", [])))
                                        })) : n.slideDown(200, (function() {
                                            i.empty().append(_(c)).append(e("<span>").text(" " + __tr(["Hide results"], undefined, "en", [])))
                                        }))
                                    }

                                    function E(e) {
                                        const t = e.css,
                                            i = e.js,
                                            s = e.html,
                                            a = e.console,
                                            o = e.hide,
                                            r = e.babel,
                                            c = e.babelPresetReact,
                                            l = e.babelPresetTS;
                                        null != t && (n.css = t), null != i && (n.js = i), null != s && (n.html = s), a && (n.console = a), o && (n.hide = o), r && (n.babel = r, c && (n.babelPresetReact = c), l && (n.babelPresetTS = l))
                                    }

                                    function C() {
                                        const e = n.css,
                                            t = n.js,
                                            s = n.html,
                                            a = n.console,
                                            o = n.babel,
                                            r = n.babelPresetReact || g(n.html),
                                            c = n.babelPresetTS;
                                        if ("" == e && "" == t && "" == s) return;
                                        var l = "";
                                        i && (l = "//" + i);
                                        return v(l + "/js", "POST", h.attr("name")).append(m("js", t), m("css", e), m("html", s), w("console", "" + (!0 === a)), w("babel", "" + (!0 === o)), w("babelPresetReact", "" + (!0 === r)), w("babelPresetTS", "" + (!0 === c))).appendTo("body").submit().remove(), h
                                    }

                                    function O() {}
                                    return {
                                        resize: O,
                                        writeResult: C,
                                        load: E,
                                        hide: x,
                                        run: y,
                                        generate: k
                                    }
                                }(), k) {
                                const n = function() {
                                    g && (g.setUIInnerHtml(s), g.generate(d), g.resize(), e(t).on("resize", (function() {
                                        g && g.resize()
                                    })), d.data("_snippet", g), h.state && g.load(h.state))
                                };
                                StackExchange.using("snippetsJsCodeMirror", (function() {
                                    setTimeout((function() {
                                        (s ? e.when() : e.ajax("/snippets/editor-ui", {
                                            success: function(e) {
                                                s = e
                                            }
                                        })).then(n)
                                    }), 1)
                                }))
                            } else g.generate(d), d.data("_snippet", g), h.state && g.load(h.state)
                        }
                    }))
                }

                function x(e, t, n) {
                    return e.replace(/^(?=.)/gm, new Array(t * n + 1).join(" "))
                }

                function S(e) {
                    let t = "\n\n\x3c!-- begin snippet: js hide: " + e.hide + " console: " + e.console + " babel: " + e.babel + " babelPresetReact: " + e.babelPresetReact + " babelPresetTS: " + e.babelPresetTS + " --\x3e\n\n";
                    const n = e.js,
                        i = e.css,
                        s = e.html;
                    return "" != n && (t += "\x3c!-- language: lang-js --\x3e\n\n" + x(n, 1, 4) + "\n\n"), "" != i && (t += "\x3c!-- language: lang-css --\x3e\n\n" + x(i, 1, 4) + "\n\n"), "" != s && (t += "\x3c!-- language: lang-html --\x3e\n\n" + x(s, 1, 4) + "\n\n"), t += "\x3c!-- end snippet --\x3e\n\n", t
                }

                function E(e, t, n, i, s, a) {
                    const o = /<!--\s+language:\s*lang-js\s+-->([\s\S]*?)(?:<!--\s+language:|$)/gi,
                        r = /<!--\s+language:\s*lang-css\s+-->([\s\S]*?)(?:<!--\s+language:|$)/gi,
                        c = /<!--\s+language:\s*lang-html\s+-->([\s\S]*?)(?:<!--\s+language:|$)/gi;
                    try {
                        const l = o.exec(e),
                            u = r.exec(e),
                            d = c.exec(e);
                        let h = "",
                            _ = "",
                            p = "";
                        if (l && (h = l[1].trim().replace(/^    /gm, "")), u && (_ = u[1].trim().replace(/^    /gm, "")), d && (p = d[1].trim().replace(/^    /gm, "")), "" == h && "" == _ && "" == p) return null;
                        return {
                            js: h,
                            css: _,
                            html: p,
                            console: n,
                            hide: t,
                            babel: i,
                            babelPresetReact: s,
                            babelPresetTS: a
                        }
                    } catch (e) {
                        return null
                    }
                }
                const C = {};
                let T;

                function O(e) {
                    let t = StackExchange.snippets.renderer;
                    if (!t) return e;
                    let n = t;
                    if (!("sandbox" in document.createElement("iframe"))) return e;
                    return e = e.replace(/<!--\s+begin snippet:\s*[a-z]+\s*(?:hide:\s*([a-zA-Z]+))?\s*(?:console:\s*([a-zA-Z]+))?\s*(?:babel:\s*([a-zA-Z]+))?\s*(?:babelPresetReact:\s*([a-zA-Z]+))?\s*(?:babelPresetTS:\s*([a-zA-Z]+))?\s+-->([\s\S]*?)<!--\s+end snippet\s+-->/gi, (function(e, t, i, s, a, o, r) {
                        return n(r, t, i, s, a, o)
                    }))
                }

                function $() {
                    StackExchange.snippets.renderer && StackExchange.snippets.redraw || (StackExchange.snippets.redraw = function() {
                        e("div.snippet").each((function() {
                            const t = e(this);
                            if (t.closest(".downvoted-answer").length > 0) return !0;
                            j(t)
                        }))
                    }, StackExchange.snippets.renderer = function(e, t, n, i, s, o) {
                        const r = E(e, t = !0 === t || "true" === (t || "").toLowerCase(), n = !0 === n || "true" === (n || "").toLowerCase(), i = !0 === i || "true" === (i || "").toLowerCase(), s = !0 === s || "true" === (s || "").toLowerCase(), o = !0 === o || "true" === (o || "").toLowerCase());
                        if (!r) return e;
                        const c = a("snippet").data({
                                lang: "js",
                                hide: t,
                                console: n
                            }),
                            l = a("snippet-code");
                        t && l.addClass("snippet-currently-hidden"), c.append(l);
                        const u = r.js,
                            d = r.css,
                            _ = r.html;
                        u && l.append(g("js").append(k(u))), d && l.append(g("css").append(k(d))), _ && l.append(g("html").append(k(_)));
                        const p = h();
                        return y(l, {
                            state: r
                        }), C[p] = c, "<pre>" + p + "</pre>"
                    }, StackExchange.snippets.redraw())
                }

                function j(t) {
                    let n = t.find(".snippet-code");
                    0 == n.length && (n = t);
                    const i = {
                        js: n.find("pre.snippet-code-js").text(),
                        css: n.find("pre.snippet-code-css").text(),
                        html: n.find("pre.snippet-code-html").text(),
                        console: !0 === t.data("console"),
                        hide: !0 === t.data("hide"),
                        babel: !0 === t.data("babel"),
                        babelPresetReact: !0 === t.data("babel-preset-react"),
                        babelPresetTS: !0 === t.data("babel-preset-ts")
                    };
                    if (y(n, {
                            state: i
                        }), (StackExchange.options.user.isAnonymous || 0 == t.parent().length || 0 == e("textarea#wmd-input").length && 0 == e("textarea#js-stacks-editor-content").length || e(".js-popup-suggested-edit").length) && t.find(".copySnippet").hide(), 0 == t.parent().length && t.find(".js-edit-snippet").show(), !0 === t.data("hide")) {
                        n.hide(), n.addClass("snippet-currently-hidden"), t.find(".snippet-display").remove();
                        const i = a("snippet-display").attr("style", "vertical-align: center").append(e("<p>").append(e('<a class="snippet-show-link-chevron"><span class="expander-arrow-hide" style="vertical-align: middle;"></span><a class="snippet-show-link"><span class="show-hide" data-ishidden="true" style="vertical-align: middle"></span></a>')));
                        i.find("span.show-hide").text(__tr(["Show code snippet"], undefined, "en", [])), i.on("click", (function() {
                            n.toggle();
                            const t = e(this),
                                i = t.find(".show-hide");
                            !0 === i.data("ishidden") ? (i.text(__tr(["Hide code snippet"], undefined, "en", [])), t.find(".expander-arrow-hide").removeClass("expander-arrow-hide").addClass("expander-arrow-show"), i.data("ishidden", !1)) : (i.text(__tr(["Show code snippet"], undefined, "en", [])), t.find(".expander-arrow-show").removeClass("expander-arrow-show").addClass("expander-arrow-hide"), i.data("ishidden", !0))
                        })), t.prepend(i)
                    } else n.show().removeClass("snippet-currently-hidden"), t.find(".snippet-display").remove()
                }
                StackExchange.snippets = function() {
                    let i = !0;
                    return {
                        init: function() {
                            $();
                            t.StackExchange.MarkdownEditor && t.StackExchange.externalEditor && i && (i = !1, StackExchange.externalEditor.init({
                                thingName: "snippet",
                                thingFinder: o,
                                editLabel: __tr(["edit the above snippet"], undefined, "en", []),
                                getDivContent: function(e) {
                                    const t = e ? E(e.code, e.hide, e.console, e.babel, e.babelPresetReact, e.babelPresetTS) : null;
                                    var n = a("modal auto-center snippet-modal");
                                    return y(n, {
                                        markdownPluginMode: !0,
                                        state: t
                                    }), n
                                },
                                buttonTooltip: __tr(["JavaScript/HTML/CSS snippet"], undefined, "en", []),
                                buttonImageUrl: "/Content/Shared/balsamiq/wmd-mockup-button.png",
                                onShow: s
                            }));
                            StackExchange.MarkdownEditor && StackExchange.MarkdownEditor.creationCallbacks.add((function(t, n) {
                                t.getConverter().hooks.chain("preConversion", O);
                                const i = e("#wmd-preview" + n);
                                i.on("wmdrefresh", (function() {
                                    r(i)
                                }))
                            }))
                        },
                        initModal: function(e) {
                            const {
                                showEditor: t
                            } = StackExchange.externalEditor.initModal({
                                thingName: "snippet",
                                onShow: s,
                                onRemove: e,
                                getDivContent: function(e) {
                                    let t = null;
                                    ((null == e ? void 0 : e.js) || (null == e ? void 0 : e.css) || (null == e ? void 0 : e.html)) && (t = {
                                        js: e.js,
                                        css: e.css,
                                        html: e.html,
                                        console: e.console,
                                        hide: e.hide,
                                        babel: e.babel,
                                        babelPresetReact: e.babelPresetReact,
                                        babelPresetTS: e.babelPresetTS
                                    });
                                    const n = a("modal auto-center snippet-modal");
                                    return y(n, {
                                        markdownPluginMode: !0,
                                        state: t
                                    }), n
                                }
                            });
                            return e => {
                                t({
                                    payload: e
                                })
                            }
                        },
                        initSnippetRenderer: $,
                        makeSnippets: O,
                        refresh: r
                    };

                    function s(t) {
                        const i = e(".snippet-modal");
                        i.on("popupClosing", (function(e) {
                            const s = "esc" == e.closeTrigger;
                            s && !n || (!s || confirm(__tr(["Are you sure you want to abandon any changes?"], undefined, "en", [])) ? ((e, t, n) => {
                                const i = t.data("_snippet").save();
                                if (e || "" == i.html && "" == i.css && "" == i.js) n(null);
                                else {
                                    const e = S(i);
                                    n(e, e)
                                }
                            })(s, i, t) : e.preventDefault())
                        }))
                    }

                    function o(e, t, n, i, s) {
                        return e.replace(/<!--\s+begin snippet:\s*[a-z]+\s*(?:hide:\s*([a-zA-Z]+))?\s*(?:console:\s*([a-zA-Z]+))?\s*(?:babel:\s*([a-zA-Z]+))?\s*(?:babelPresetReact:\s*([a-zA-Z]+))?\s*(?:babelPresetTS:\s*([a-zA-Z]+))?\s+-->([\s\S]*?)<!--\s+end snippet\s+-->/gi, (function(e, o, r, c, l, u, d, h) {
                            const _ = {
                                payload: {
                                    code: d,
                                    hide: "true" === (o || "").toLowerCase(),
                                    console: "true" === (r || "").toLowerCase(),
                                    babel: "true" === (c || "").toLowerCase(),
                                    babelPresetReact: "true" === (l || "").toLowerCase(),
                                    babelPresetTS: "true" === (u || "").toLowerCase()
                                },
                                pos: a(e, t, h),
                                len: e.length
                            };
                            return -1 === _.pos ? e : (s.push(_), e + "\n\n" + n + i + "-" + (s.length - 1) + "%")
                        }));

                        function a(e, t, n) {
                            let i = -1,
                                s = -1;
                            for (; s = t.indexOf(e, s + 1), -1 != s;)(i < 0 || Math.abs(s - n) < Math.abs(s - i)) && (i = s);
                            return i
                        }
                    }

                    function r(t) {
                        t.find("pre").each((function() {
                            const t = e(this),
                                n = t.text();
                            if (C[n]) {
                                const i = C[n];
                                delete C[n], j(i), t.replaceWith(e("<p>").append(i))
                            }
                        }))
                    }
                }()
            }(jQuery, window);
        __webpack_require__(20836), __webpack_require__(30375), __webpack_require__(27558), __webpack_require__(43705), __webpack_require__(71322), __webpack_require__(48781), __webpack_require__(72498), __webpack_require__(31631), __webpack_require__(98297), __webpack_require__(3421);

        function g() {}
        var m = function(e, t, n) {
            return "symbol" == typeof t && (t = t.description ? "[".concat(t.description, "]") : ""), Object.defineProperty(e, "name", {
                configurable: !0,
                value: n ? "".concat(n, " ", t) : t
            })
        };

        function v(e) {
            return w(e, [], {}, [], [])
        }

        function w(e, t, n, i, s) {
            return {
                withTargets: (...a) => {
                    const o = w(e, [...t, ...a], n, i, s),
                        r = () => o;
                    return Object.assign(r, o), r
                },
                withValues: a => w(e, t, { ...n,
                    ...a
                }, i, s),
                withClasses: (...a) => w(e, t, n, [...i, ...a], s),
                withElementType: () => w(e, t, n, i, s),
                withOutlet: a => w(e, t, n, i, [...s, a.controllerName]),
                withNamedOutlet: a => w(e, t, n, i, [...s, a]),
                build: () => {
                    var a;
                    return {
                        Base: (a = class extends b {}, m(a, "Base"), a.controllerName = e, a.targets = t, a.values = n, a.classes = i, a.outlets = s, a),
                        stimulusCallback: g
                    }
                }
            }
        }
        const b = function() {
            const e = new(Stacks.createController({}))({}),
                t = Object.getPrototypeOf(e),
                n = Object.getPrototypeOf(t);
            return Object.getPrototypeOf(n).constructor
        }();
        var k = __webpack_require__(68911);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        const {
            Base: y
        } = v("se-arrow-key-navigation").withTargets("navigableElement").withValues({
            loops: Boolean
        }).build();
        class x extends y {
            constructor() {
                super(...arguments), this.currentIndex = 0, this.focusedItem = null
            }
            navigableElementTargetConnected(e) {
                e.addEventListener("focus", this.handleElementFocused.bind(this, e)), e.addEventListener("blur", this.handleElementBlurred.bind(this))
            }
            navigableElementTargetDisconnected(e) {
                e.removeEventListener("focus", this.handleElementFocused.bind(this, e)), e.removeEventListener("blur", this.handleElementBlurred.bind(this))
            }
            connect() {
                this.currentIndex = 0, document.addEventListener("keydown", this.handleKeyDown.bind(this))
            }
            disconnect() {
                this.currentIndex = 0, document.removeEventListener("keydown", this.handleKeyDown.bind(this))
            }
            handleKeyDown(e) {
                this.focusedItem && ("ArrowUp" === e.key ? this.selectPreviousItem() : "ArrowDown" === e.key && this.selectNextItem())
            }
            selectNextItem() {
                this.loopsValue ? this.currentIndex = (this.currentIndex + 1) % this.navigableElementTargets.length : this.currentIndex < this.navigableElementTargets.length - 1 && this.currentIndex++, this.navigableElementTargets[this.currentIndex].focus()
            }
            selectPreviousItem() {
                this.loopsValue ? this.currentIndex = (this.currentIndex - 1 + this.navigableElementTargets.length) % this.navigableElementTargets.length : this.currentIndex > 0 && this.currentIndex--, this.navigableElementTargets[this.currentIndex].focus()
            }
            handleElementFocused(e) {
                this.focusedItem = e, this.navigableElementTargets.forEach(((t, n) => {
                    e === t && this.currentIndex != n && (this.currentIndex = n)
                }))
            }
            handleElementBlurred() {
                this.focusedItem = null
            }
        }
        var S, E, C, T, O, j, A, R, P, N, M, D, L, I, U, F, B, q, H, z, W, V, K, Q, G, Y, J, X, Z, ee, te, ne, ie, se, ae, oe, re, ce, le, ue;

        function de(e, t, n = {}) {
            let i, s = n.always;
            const a = (...t) => {
                i = null, e(...t)
            };
            return {
                trigger: (...e) => {
                    s && s(e), i ? n.sliding && (clearTimeout(i), i = setTimeout((() => {
                        a(...e)
                    }), t)) : i = setTimeout((() => {
                        a(...e)
                    }), t)
                },
                cancel: () => {
                    i && (clearTimeout(i), i = null)
                }
            }
        }! function(e) {
            e[e.AboutTeam = 13] = "AboutTeam", e[e.AboutYou = 12] = "AboutYou", e[e.Billing = 4] = "Billing", e[e.ChannelName = 3] = "ChannelName", e[e.ContactSales = 7] = "ContactSales", e[e.ContactSales_ThankYou = 8] = "ContactSales_ThankYou", e[e.CreateProfile = 9] = "CreateProfile", e[e.Email = 1] = "Email", e[e.FreemiumVerifyEmail = 15] = "FreemiumVerifyEmail", e[e.Login = 11] = "Login", e[e.Plan = 2] = "Plan", e[e.Signup = 10] = "Signup", e[e.ThankYou = 6] = "ThankYou", e[e.Tools = 14] = "Tools", e[e.VerifyEmail = 5] = "VerifyEmail"
        }(S || (S = {})),
        function(e) {
            e[e.Basic = 0] = "Basic", e[e.Enterprise = 2] = "Enterprise", e[e.Freemium = 3] = "Freemium", e[e.Premium = 1] = "Premium"
        }(E || (E = {})),
        function(e) {
            e[e.BillingAddress1 = 18] = "BillingAddress1", e[e.BillingAddress2 = 19] = "BillingAddress2", e[e.BillingCity = 20] = "BillingCity", e[e.BillingCountry = 17] = "BillingCountry", e[e.BillingEmail = 7] = "BillingEmail", e[e.BillingFirstName = 15] = "BillingFirstName", e[e.BillingLastName = 16] = "BillingLastName", e[e.BillingPostalCode = 22] = "BillingPostalCode", e[e.BillingState = 21] = "BillingState", e[e.CCExpiry = 24] = "CCExpiry", e[e.CCNumber = 23] = "CCNumber", e[e.ChannelId = 28] = "ChannelId", e[e.ChannelName = 2] = "ChannelName", e[e.ChannelUrl = 3] = "ChannelUrl", e[e.CVV = 25] = "CVV", e[e.Email = 1] = "Email", e[e.FirstName = 4] = "FirstName", e[e.LastName = 5] = "LastName", e[e.MailingAddress1 = 10] = "MailingAddress1", e[e.MailingAddress2 = 11] = "MailingAddress2", e[e.MailingCity = 12] = "MailingCity", e[e.MailingCountry = 9] = "MailingCountry", e[e.MailingPostalCode = 14] = "MailingPostalCode", e[e.MailingState = 13] = "MailingState", e[e.None = 0] = "None", e[e.OrganizationName = 6] = "OrganizationName", e[e.PhoneNumber = 8] = "PhoneNumber", e[e.RealName = 29] = "RealName", e[e.SelectedTier = 26] = "SelectedTier"
        }(C || (C = {})),
        function(e) {
            e[e.DataMissingFromCache = 5] = "DataMissingFromCache", e[e.Existing = 3] = "Existing", e[e.Invalid = 2] = "Invalid", e[e.Missing = 1] = "Missing", e[e.None = 0] = "None", e[e.Public = 4] = "Public"
        }(T || (T = {})),
        function(e) {
            e[e.Annual = 2] = "Annual", e[e.Monthly = 1] = "Monthly", e[e.Unknown = 0] = "Unknown"
        }(O || (O = {})),
        function(e) {
            e[e.Basic = 1] = "Basic", e[e.Freemium = 3] = "Freemium", e[e.Premium = 2] = "Premium", e[e.Unknown = 0] = "Unknown"
        }(j || (j = {})),
        function(e) {
            e[e.GitHubEnterprise = 4] = "GitHubEnterprise", e[e.Jira = 3] = "Jira", e[e.MicrosoftTeams = 2] = "MicrosoftTeams", e[e.Slack = 1] = "Slack"
        }(A || (A = {})),
        function(e) {
            e[e.Downgrade = 3] = "Downgrade", e[e.PaymentMethod = 0] = "PaymentMethod", e[e.Plan = 1] = "Plan", e[e.Upgrade = 2] = "Upgrade"
        }(R || (R = {})),
        function(e) {
            e[e.AddUpvote = 7] = "AddUpvote", e[e.ApproveAndPublish = 1] = "ApproveAndPublish", e[e.ApprovePendingMinorEdits = 2] = "ApprovePendingMinorEdits", e[e.BeginEditPost = 11] = "BeginEditPost", e[e.Cancel = 9] = "Cancel", e[e.DeclineReevaluation = 13] = "DeclineReevaluation", e[e.EditPost = 6] = "EditPost", e[e.None = 0] = "None", e[e.Publish = 10] = "Publish", e[e.RequestReevaluation = 14] = "RequestReevaluation", e[e.RequireMajorChanges = 3] = "RequireMajorChanges", e[e.SaveWithoutReview = 12] = "SaveWithoutReview", e[e.Skip = 8] = "Skip", e[e.VoteAsDuplicate = 5] = "VoteAsDuplicate", e[e.VoteAsOffTopic = 4] = "VoteAsOffTopic"
        }(P || (P = {})),
        function(e) {
            e.Descriptive = "descriptive", e.Minimal = "minimal"
        }(N || (N = {})),
        function(e) {
            e[e.Markdown = 1] = "Markdown", e[e.MarkdownWithPreview = 2] = "MarkdownWithPreview", e[e.RichText = 0] = "RichText"
        }(M || (M = {})),
        function(e) {
            e[e.unknown = 0] = "unknown", e[e.v2 = 1] = "v2", e[e.v3 = 3] = "v3", e[e.wizard = 2] = "wizard"
        }(D || (D = {})),
        function(e) {
            e[e.Negative = -1] = "Negative", e[e.NotSet = 0] = "NotSet", e[e.Positive = 1] = "Positive"
        }(L || (L = {})),
        function(e) {
            e[e.FormattingFixes = 2] = "FormattingFixes", e[e.TitleSuggestions = 1] = "TitleSuggestions"
        }(I || (I = {})),
        function(e) {
            e[e.Answer = 2] = "Answer", e[e.Question = 1] = "Question"
        }(U || (U = {})),
        function(e) {
            e[e.NotAvailable = 0] = "NotAvailable"
        }(F || (F = {})),
        function(e) {
            e[e.Body = 6] = "Body", e[e.BottomTitle = 7] = "BottomTitle", e[e.BottomTitleSuggestions = 8] = "BottomTitleSuggestions", e[e.ExpectedResults = 3] = "ExpectedResults", e[e.ProblemDetail = 2] = "ProblemDetail", e[e.SimilarQuestions = 5] = "SimilarQuestions", e[e.StagingGroundSelection = 10] = "StagingGroundSelection", e[e.Tags = 4] = "Tags", e[e.Title = 1] = "Title", e[e.TopTitleSuggestions = 9] = "TopTitleSuggestions"
        }(B || (B = {})),
        function(e) {
            e[e.FifteenHundredOneToTwentyFiveHundred = 4] = "FifteenHundredOneToTwentyFiveHundred", e[e.FiftyThousandAndOnePlus = 8] = "FiftyThousandAndOnePlus", e[e.FiveHundredOneToFifteenHundred = 3] = "FiveHundredOneToFifteenHundred", e[e.FiveThousandOneToTenThousand = 6] = "FiveThousandOneToTenThousand", e[e.OneToTwoHundred = 1] = "OneToTwoHundred", e[e.TenThousandOneToFiftyThousand = 7] = "TenThousandOneToFiftyThousand", e[e.TwentyFiveHundredOneToFiveThousand = 5] = "TwentyFiveHundredOneToFiveThousand", e[e.TwoHundredOneToFiveHundred = 2] = "TwoHundredOneToFiveHundred"
        }(q || (q = {})),
        function(e) {
            e[e.Dark = 1] = "Dark", e[e.HighContrastDark = 5] = "HighContrastDark", e[e.HighContrastLight = 4] = "HighContrastLight", e[e.HighContrastMod = 4] = "HighContrastMod", e[e.HighContrastSystemDefault = 6] = "HighContrastSystemDefault", e[e.Light = 0] = "Light", e[e.SystemDefault = 2] = "SystemDefault"
        }(H || (H = {})),
        function(e) {
            e[e.home_page = 1] = "home_page", e[e.question_page = 3] = "question_page", e[e.questions_list_page = 2] = "questions_list_page", e[e.tagged_questions_page = 5] = "tagged_questions_page", e[e.tags_page = 4] = "tags_page"
        }(z || (z = {})),
        function(e) {
            e[e.browse_other_questions = 4] = "browse_other_questions", e[e.headline = 6] = "headline", e[e.homepage_customize_your_feed = 12] = "homepage_customize_your_feed", e[e.ignored_tags = 8] = "ignored_tags", e[e.question = 3] = "question", e[e.questions_list = 1] = "questions_list", e[e.related_tags = 2] = "related_tags", e[e.tag = 5] = "tag", e[e.watched_tags = 7] = "watched_tags", e[e.watched_tags_widget = 9] = "watched_tags_widget", e[e.watched_tags_widget_cta_button = 10] = "watched_tags_widget_cta_button", e[e.watched_tags_widget_cta_description = 11] = "watched_tags_widget_cta_description"
        }(W || (W = {})),
        function(e) {
            e[e.DownVoteRepRequired = 3] = "DownVoteRepRequired", e[e.FreeVoteOnboarding = 2] = "FreeVoteOnboarding", e[e.None = 0] = "None", e[e.Save = 1] = "Save"
        }(V || (V = {})),
        function(e) {
            e[e.CollectionDeleted = 3] = "CollectionDeleted", e[e.ExistsInCollection = 8] = "ExistsInCollection", e[e.InvalidMentionNames = 10] = "InvalidMentionNames", e[e.InvalidPostType = 11] = "InvalidPostType", e[e.MaxCollectionSize = 9] = "MaxCollectionSize", e[e.MissingOwner = 7] = "MissingOwner", e[e.MissingTitle = 6] = "MissingTitle", e[e.NoCollectionFound = 2] = "NoCollectionFound", e[e.NoDeleteRights = 12] = "NoDeleteRights", e[e.NoEditRights = 13] = "NoEditRights", e[e.NoPermissionGrantRights = 14] = "NoPermissionGrantRights", e[e.NoQuestionFound = 4] = "NoQuestionFound", e[e.NoUserFound = 5] = "NoUserFound", e[e.ServerError = 1] = "ServerError", e[e.Success = 0] = "Success"
        }(K || (K = {})),
        function(e) {
            e[e.ArticleNotFound = 5] = "ArticleNotFound", e[e.CannotLeaveSuggestion = 7] = "CannotLeaveSuggestion", e[e.ExistingDraft = 11] = "ExistingDraft", e[e.InvalidMentionNames = 4] = "InvalidMentionNames", e[e.InvalidSuggestion = 6] = "InvalidSuggestion", e[e.NeedsComment = 8] = "NeedsComment", e[e.NoEditRights = 2] = "NoEditRights", e[e.NoRejectionRights = 3] = "NoRejectionRights", e[e.ServerError = 1] = "ServerError", e[e.Success = 0] = "Success", e[e.TooManyEdits = 9] = "TooManyEdits", e[e.Unauthorized = 10] = "Unauthorized"
        }(Q || (Q = {})),
        function(e) {
            e[e.AdminOnly = 11] = "AdminOnly", e[e.CustomAwardDeleted = 5] = "CustomAwardDeleted", e[e.MaxCustomAwards = 9] = "MaxCustomAwards", e[e.MaxFeatured = 10] = "MaxFeatured", e[e.MaxSizeDescription = 8] = "MaxSizeDescription", e[e.MaxSizeName = 7] = "MaxSizeName", e[e.MissingDescription = 3] = "MissingDescription", e[e.MissingName = 2] = "MissingName", e[e.NoCustomAwardFound = 4] = "NoCustomAwardFound", e[e.NoDeleteRights = 12] = "NoDeleteRights", e[e.ServerError = 1] = "ServerError", e[e.Success = 0] = "Success", e[e.UniqueName = 6] = "UniqueName"
        }(G || (G = {})),
        function(e) {
            e[e.Achievements = 6] = "Achievements", e[e.FaceSmile = 1] = "FaceSmile", e[e.Fire = 5] = "Fire", e[e.Heart = 4] = "Heart", e[e.Medal = 2] = "Medal", e[e.Tada = 3] = "Tada"
        }(Y || (Y = {})),
        function(e) {
            e[e.AddReminder = 3] = "AddReminder", e[e.CancelReminder = 4] = "CancelReminder", e[e.Read = 1] = "Read", e[e.UndoAddReminder = 5] = "UndoAddReminder", e[e.UndoCancelReminder = 6] = "UndoCancelReminder", e[e.Unread = 2] = "Unread"
        }(J || (J = {})),
        function(e) {
            e[e.InvalidUserId = 1] = "InvalidUserId", e[e.Success = 0] = "Success"
        }(X || (X = {})),
        function(e) {
            e[e.All = 2] = "All", e[e.Unread = 1] = "Unread"
        }(Z || (Z = {})),
        function(e) {
            e[e.Topic = 1] = "Topic", e[e.Vendor = 0] = "Vendor"
        }(ee || (ee = {})),
        function(e) {
            e[e.ActivityIndicatorDisabled = 131072] = "ActivityIndicatorDisabled", e[e.InvitationsDisabled = 4096] = "InvitationsDisabled", e[e.LabelEmployee = 8192] = "LabelEmployee", e[e.None = 0] = "None", e[e.NotificationCanEndorse = 1024] = "NotificationCanEndorse", e[e.NotificationNewMember = 512] = "NotificationNewMember", e[e.OnboardingAddPartners = 8] = "OnboardingAddPartners", e[e.OnboardingAnswerQuestion = 16] = "OnboardingAnswerQuestion", e[e.OnboardingCreateReport = 256] = "OnboardingCreateReport", e[e.OnboardingDismissed = 2048] = "OnboardingDismissed", e[e.OnboardingRecommendAnswer = 128] = "OnboardingRecommendAnswer", e[e.OnboardingReviewDashboard = 64] = "OnboardingReviewDashboard", e[e.OnboardingWriteArticle = 32] = "OnboardingWriteArticle", e[e.OrganicInvitation = 16384] = "OrganicInvitation", e[e.RoleAdmin = 1] = "RoleAdmin", e[e.RoleAnalyst = 32768] = "RoleAnalyst", e[e.RoleLimitedPartner = 65536] = "RoleLimitedPartner", e[e.RolePartner = 2] = "RolePartner", e[e.RoleSubscriber = 4] = "RoleSubscriber"
        }(te || (te = {})),
        function(e) {
            e[e.OptIn = 0] = "OptIn", e[e.OptOut = 1] = "OptOut"
        }(ne || (ne = {})),
        function(e) {
            e[e.body_blur = 6] = "body_blur", e[e.body_focus = 5] = "body_focus", e[e.tags_blur = 10] = "tags_blur", e[e.tags_focus = 9] = "tags_focus", e[e.title_blur = 2] = "title_blur", e[e.title_focus = 1] = "title_focus", e[e.undefined_blur = 12] = "undefined_blur", e[e.undefined_focus = 11] = "undefined_focus"
        }(ie || (ie = {})),
        function(e) {
            e[e.AllLevels = 1] = "AllLevels", e[e.Beginner = 2] = "Beginner", e[e.Expert = 4] = "Expert", e[e.Intermediate = 3] = "Intermediate"
        }(se || (se = {})),
        function(e) {
            e[e.BestPractices = 2] = "BestPractices", e[e.GeneralAdviceOther = 3] = "GeneralAdviceOther", e[e.ToolingRecommendation = 1] = "ToolingRecommendation"
        }(ae || (ae = {})),
        function(e) {
            e[e.HomepageCustomizeYourFeed = 1] = "HomepageCustomizeYourFeed", e[e.WatchedTagsWidget = 2] = "WatchedTagsWidget"
        }(oe || (oe = {})),
        function(e) {
            e[e.BountyEndingSoon = 4] = "BountyEndingSoon", e[e.Hot = 5] = "Hot", e[e.HotNoTime = 6] = "HotNoTime", e[e.MostFrequent = 3] = "MostFrequent", e[e.MostVotes = 2] = "MostVotes", e[e.Newest = 0] = "Newest", e[e.RecentActivity = 1] = "RecentActivity"
        }(re || (re = {})),
        function(e) {
            e[e.DeactivatedOwner = 8] = "DeactivatedOwner", e[e.HasBounty = 4] = "HasBounty", e[e.NoAcceptedAnswer = 2] = "NoAcceptedAnswer", e[e.NoAnswers = 1] = "NoAnswers", e[e.None = 0] = "None", e[e.NoStagingGround = 16] = "NoStagingGround"
        }(ce || (ce = {})),
        function(e) {
            e[e.Specified = 0] = "Specified", e[e.Watched = 1] = "Watched"
        }(le || (le = {})),
        function(e) {
            e[e.Condensed = 1] = "Condensed", e[e.Expanded = 0] = "Expanded"
        }(ue || (ue = {})), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        var he = function(e, t, n, i) {
            var s, a = arguments.length,
                o = a < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, n, i);
            else
                for (var r = e.length - 1; r >= 0; r--)(s = e[r]) && (o = (a < 3 ? s(o) : a > 3 ? s(t, n, o) : s(t, n)) || o);
            return a > 3 && o && Object.defineProperty(t, n, o), o
        };
        const _e = ["blur", "focus", "keyup", "paste"],
            pe = ["focus", "paste"],
            fe = ["keyup"],
            ge = ["blur"],
            {
                Base: me,
                stimulusCallback: ve
            } = v("se-character-counter").withElementType().withTargets("visibleMessage", "screenReaderMessage").withValues({
                cssClasses: Object,
                ignoreWhitespace: Boolean,
                invalidState: Boolean,
                maxLength: Number,
                minLength: Number,
                messageMode: String,
                target: String
            }).build();
        class we extends me {
            constructor() {
                super(...arguments), this.breakPoints = [], this.cssClasses = {}, this.srTimer = -1, this.updateVisualMessageImmediate = () => {
                    const e = this.getCurrentCount(),
                        t = this.getMaxLength(),
                        n = this.getMinLength();
                    if (this.messageModeValue === N.Minimal) this.visibleMessageTarget.innerText = this.minimalMessage(e, t);
                    else {
                        if (this.messageModeValue !== N.Descriptive) return this.visibleMessageTarget.innerText = "", void StackExchange.debug.log("Invalid message mode for this Character Counter controller");
                        this.visibleMessageTarget.innerText = this.descriptiveMessage(e, t, n)
                    }
                    this.invalidStateValue = e < n || e > t, this.element.classList.remove(...Object.values(this.cssClasses).flat());
                    const i = this.getCssClass();
                    i && this.element.classList.add(...i)
                }, this.updateVisualMessage = de(this.updateVisualMessageImmediate, 100, {
                    sliding: !0
                }).trigger, this.announceToScreenReaderImmediate = () => {
                    const e = this.getCurrentCount(),
                        t = this.getMaxLength(),
                        n = this.getMinLength();
                    this.screenReaderMessageTarget.innerText = this.screenReaderMessage(e, t, n)
                }, this.debounceUpdateScreenReader = de(this.announceToScreenReaderImmediate, 2e3, {
                    sliding: !0
                }), this.announceToScreenReader = this.debounceUpdateScreenReader.trigger, this.announceToScreenReaderForcefully = () => {
                    this.screenReaderMessageTarget.innerText = "", this.srTimer = window.setTimeout((() => {
                        this.announceToScreenReaderImmediate()
                    }), 100)
                }, this.cancelAnnounceToScreenReader = () => {
                    this.debounceUpdateScreenReader.cancel(), clearTimeout(this.srTimer)
                }, this.cssClassesValueChanged = () => {
                    this.breakPoints = [], this.cssClasses = {}, Object.entries(this.cssClassesValue).forEach((([e, t]) => {
                        this.breakPoints.push(+e), this.cssClasses[+e] = t.split(" ")
                    })), this.breakPoints.sort().reverse()
                }, this.invalidStateValueChanged = () => {
                    this.element.dispatchEvent(new CustomEvent("stateChange", {
                        detail: {
                            invalid: this.invalidStateValue
                        }
                    }))
                }, this.targetValueChanged = (e, t) => {
                    t && this.unbindEvents(document.querySelector(t)), this.loadTarget(e), this.bindEvents(this.targetField)
                }, this.loadTarget = e => {
                    const t = document.querySelector(e);
                    if (null === t) throw new Error(`Selector did not find a DOM element matching: ${e}`);
                    const n = t.tagName.toLowerCase();
                    if ("input" !== n && "textarea" !== n) throw new Error(`Only inputs and text areas are supported as targets. Given: ${n}`);
                    this.targetField = t
                }, this.bindEvents = e => {
                    _e.forEach((t => {
                        e.addEventListener(t, this.updateVisualMessage)
                    })), pe.forEach((t => {
                        e.addEventListener(t, this.announceToScreenReaderForcefully)
                    })), fe.forEach((t => {
                        e.addEventListener(t, this.announceToScreenReader)
                    })), ge.forEach((t => {
                        e.addEventListener(t, this.cancelAnnounceToScreenReader)
                    }))
                }, this.unbindEvents = e => {
                    null !== e && (_e.forEach((t => {
                        e.removeEventListener(t, this.updateVisualMessage)
                    })), pe.forEach((t => {
                        e.removeEventListener(t, this.announceToScreenReaderForcefully)
                    })), fe.forEach((t => {
                        e.removeEventListener(t, this.announceToScreenReader)
                    })), ge.forEach((t => {
                        e.removeEventListener(t, this.cancelAnnounceToScreenReader)
                    })))
                }, this.minimalMessage = (e, t) => __tr(["$current$ / $max$ characters", "$current$ / $max$ characters", "$current$ / $max$ characters", "$current$ / $max$ characters"], {
                    current: e,
                    max: t
                }, "en", ["current", "max"]), this.descriptiveMessage = (e, t, n) => {
                    if (0 === e) return 0 === n ? __tr(["Enter up to $max$ characters", "Enter up to $max$ characters"], {
                        max: t
                    }, "en", ["max"]) : __tr(["Enter at least $min$ character", "Enter at least $min$ characters"], {
                        min: n
                    }, "en", ["min"]);
                    if (e < n) return __tr(["$count$ more to go...", "$count$ more to go..."], {
                        count: n - e
                    }, "en", ["count"]);
                    const i = t - e;
                    return i >= 0 ? __tr(["$count$ character left", "$count$ characters left"], {
                        count: i
                    }, "en", ["count"]) : __tr(["Too long by $count$ character", "Too long by $count$ characters"], {
                        count: Math.abs(i)
                    }, "en", ["count"])
                }, this.screenReaderMessage = (e, t, n) => {
                    if (0 === e && 0 === n) return __tr(["You have $max$ characters remaining", "You have $max$ characters remaining"], {
                        max: t
                    }, "en", ["max"]);
                    if (e < n) return __tr(["You need at least $min$ more characters", "You need at least $min$ more characters"], {
                        min: n
                    }, "en", ["min"]);
                    const i = t - e;
                    return i >= 0 ? __tr(["You have $count$ characters remaining", "You have $count$ characters remaining"], {
                        count: i
                    }, "en", ["count"]) : __tr(["You have $count$ characters too many", "You have $count$ characters too many"], {
                        count: Math.abs(i)
                    }, "en", ["count"])
                }
            }
            connect() {
                this.loadTarget(this.targetValue), this.bindEvents(this.targetField), this.updateVisualMessageImmediate()
            }
            disconnect() {
                this.unbindEvents(this.targetField)
            }
            getCssClass() {
                const e = this.getCurrentCount(),
                    t = this.getMaxLength();
                for (const n of this.breakPoints) {
                    const i = this.cssClasses[n];
                    if (e > t * n) return i
                }
                return []
            }
            getCurrentCount() {
                const e = this.targetField.value;
                return this.ignoreWhitespaceValue ? e.replace(/\s+/g, " ").replace(/^\s+/, "").replace(/\s+$/, "").length : e.replace(/\r\n/g, "\n").replace(/\n/g, "\r\n").length
            }
            getMaxLength() {
                let e;
                return null !== (e = this.targetField.getAttribute("maxlength")) || null !== (e = this.targetField.getAttribute("data-max-length")) ? +e : this.maxLengthValue
            }
            getMinLength() {
                let e;
                return null !== (e = this.targetField.getAttribute("minlength")) || null !== (e = this.targetField.getAttribute("data-min-length")) ? +e : this.minLengthValue
            }
        }
        he([ve], we.prototype, "cssClassesValueChanged", void 0), he([ve], we.prototype, "invalidStateValueChanged", void 0), he([ve], we.prototype, "targetValueChanged", void 0), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        const {
            Base: be
        } = v("se-delayed-popover").withTargets("controller").withValues({
            delay: Number,
            afterVisible: Boolean
        }).build();
        class ke extends be {
            connect() {
                if (!this.hasControllerTarget) throw new Error("No popover controller element selector provided");
                if (this.afterVisibleValue) {
                    new IntersectionObserver(((e, t) => {
                        e[0].isIntersecting && (this.showPopoverAfterDelay(this.delayValue), t.unobserve(this.controllerTarget))
                    })).observe(this.controllerTarget)
                } else this.showPopoverAfterDelay(this.delayValue)
            }
            showPopoverAfterDelay(e) {
                setTimeout((() => {
                    Stacks.showPopover(this.controllerTarget)
                }), e)
            }
        }
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        const {
            Base: ye
        } = v("se-dismiss").withTargets("deletable").withValues({
            endpoint: String,
            fkey: String
        }).build();
        class xe extends ye {
            performDismiss() {
                if (!this.hasEndpointValue) throw new Error("Dismiss endpoint required");
                if (!this.hasDeletableTarget) throw new Error("At least one deletable target required");
                if (!this.hasFkeyValue) throw new Error("fkey value required");
                const e = new FormData;
                e.append("fkey", this.fkeyValue), fetch(this.endpointValue, {
                    method: "POST",
                    body: e
                }).then((() => {
                    this.deletableTargets.forEach((e => e.remove()))
                }))
            }
        }
        var Se, Ee;
        ! function(e) {
            e[e.Question = 1] = "Question", e[e.Answer = 2] = "Answer", e[e.Wiki = 3] = "Wiki", e[e.TagWikiUsageGuidance = 4] = "TagWikiUsageGuidance", e[e.TagWiki = 5] = "TagWiki", e[e.ModeratorNomination = 6] = "ModeratorNomination", e[e.WikiPlaceholder = 7] = "WikiPlaceholder", e[e.PrivilegeWiki = 8] = "PrivilegeWiki", e[e.Article = 9] = "Article", e[e.HelpArticle = 10] = "HelpArticle", e[e.Collection = 12] = "Collection", e[e.ModeratorQuestionnaireResponse = 13] = "ModeratorQuestionnaireResponse", e[e.Announcement = 14] = "Announcement", e[e.CollectiveDiscussion = 15] = "CollectiveDiscussion", e[e.CollectiveCollection = 17] = "CollectiveCollection", e[e.TagWikiSummary = 18] = "TagWikiSummary", e[e.Challenge = 19] = "Challenge", e[e.ChallengeEntry = 20] = "ChallengeEntry"
        }(Se || (Se = {})), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
            function(e) {
                e[e.informModerator = -1] = "informModerator", e[e.undoMod = 0] = "undoMod", e[e.acceptedByOwner = 1] = "acceptedByOwner", e[e.upMod = 2] = "upMod", e[e.downMod = 3] = "downMod", e[e.offensive = 4] = "offensive", e[e.bookmark = 5] = "bookmark", e[e.close = 6] = "close", e[e.reopen = 7] = "reopen", e[e.bountyClose = 9] = "bountyClose", e[e.deletion = 10] = "deletion", e[e.undeletion = 11] = "undeletion", e[e.spam = 12] = "spam", e[e.reaction1 = 17] = "reaction1", e[e.helpful = 18] = "helpful", e[e.thankYou = 19] = "thankYou", e[e.wellWritten = 20] = "wellWritten", e[e.follow = 21] = "follow", e[e.reaction2 = 22] = "reaction2", e[e.reaction3 = 23] = "reaction3", e[e.reaction4 = 24] = "reaction4", e[e.reaction5 = 25] = "reaction5", e[e.reaction6 = 26] = "reaction6", e[e.reaction7 = 27] = "reaction7", e[e.reaction8 = 28] = "reaction8", e[e.outdated = 29] = "outdated", e[e.notOutdated = 30] = "notOutdated", e[e.preVote = 31] = "preVote", e[e.collectiveDiscussionUpvote = 32] = "collectiveDiscussionUpvote", e[e.collectiveDiscussionDownvote = 33] = "collectiveDiscussionDownvote", e[e.privateAiAnswerCorrect = 35] = "privateAiAnswerCorrect", e[e.privateAiAnswerIncorrect = 36] = "privateAiAnswerIncorrect", e[e.privateAiAnswerPartiallyCorrect = 37] = "privateAiAnswerPartiallyCorrect", e[e.challengeUpvote = 38] = "challengeUpvote", e[e.challengeDownvote = 39] = "challengeDownvote"
            }(Ee || (Ee = {}));
        var Ce = __webpack_require__(24934),
            Te = __webpack_require__(13822);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        const {
            Base: Oe
        } = v("se-follow-post").withTargets("follow").withValues({
            postId: Number,
            postTypeId: Number,
            isFollowing: Boolean,
            followSuccessToastOverride: String,
            unfollowSuccessToastOverride: String,
            showPopover: {
                type: Boolean,
                default: !0
            },
            anonymousUrl: String,
            isCodingChallenge: {
                type: Boolean,
                default: !1
            }
        }).build();
        class $e extends Oe {
            connect() {
                this.updateUI(this.isFollowingValue), this.followTarget.onclick = Te.A.user.isAnonymous ? this.bindAnonymousPopup.bind(this) : this.bindFollowUnfollow.bind(this)
            }
            bindFollowUnfollow() {
                const e = this.followTarget,
                    t = "true" === this.followTarget.getAttribute("aria-pressed"),
                    n = !t;
                $.ajax({
                    type: "POST",
                    url: `/posts/${this.postIdValue}/vote/${Ee.follow}`,
                    data: {
                        fkey: Te.A.user.fkey,
                        undo: t
                    },
                    success: i => {
                        if (i.Success) {
                            let t = $("#divFollowingConfirm-" + this.postIdValue).length > 0;
                            i.Message && this.showPopoverValue && (t || ($(i.Message).insertAfter(e), t = !0, this.bindPopoverUnfollow()), e.setAttribute("aria-controls", "divFollowingConfirm-" + this.postIdValue), e.setAttribute("data-controller", "s-popover s-tooltip")), n ? t && this.showPopoverValue ? ((0, s.xA)(), (0, s.de)($(e), !0)) : this.showFollowSuccessToast() : (this.showUnfollowSuccessToast(), t && this.showPopoverValue && (0, s.de)($(e), !1))
                        } else this.updateUI(t), (0, s.P0)(i.Message, {
                            useRawHtml: !0,
                            dismissable: !0,
                            transient: !1,
                            type: "danger"
                        });
                        this.updateUI(n), e.removeAttribute("disabled")
                    },
                    error: () => {
                        this.updateUI(t), e.removeAttribute("disabled")
                    }
                })
            }
            bindAnonymousPopup() {
                dispatchEvent(new CustomEvent("signupModalShow", {
                    detail: {
                        location: "votedialog"
                    }
                }))
            }
            bindPopoverUnfollow() {
                $(".js-unfollow-post-confirm").on("click", (() => {
                    this.bindFollowUnfollow()
                }))
            }
            updateUI(e) {
                this.followTarget && (this.followTarget.setAttribute("aria-pressed", e ? "true" : "false"), this.showPopoverValue && (0, Ce.nT)($(this.followTarget), this.getTooltipText(e)), this.followTarget.innerHTML = e ? __tr(["Following"], undefined, "en", []) : __tr(["Follow"], undefined, "en", []))
            }
            showFollowSuccessToast() {
                if (this.hasFollowSuccessToastOverrideValue)(0, s.P0)(this.followSuccessToastOverrideValue, {
                    transient: !0,
                    useRawHtml: !0,
                    type: "success"
                });
                else if (this.postTypeIdValue === Se.CollectiveDiscussion)(0, s.P0)(this.isCodingChallengeValue ? __tr(["You're now following this challenge"], undefined, "en", []) : __tr(["You're now following this discussion"], undefined, "en", []), {
                    transient: !0
                });
                else(0, s.P0)(__tr(["You’re now following this post"], undefined, "en", []), {
                    transient: !0
                })
            }
            showUnfollowSuccessToast() {
                if (this.hasUnfollowSuccessToastOverrideValue)(0, s.P0)(this.unfollowSuccessToastOverrideValue, {
                    transient: !0
                });
                else if (this.postTypeIdValue === Se.CollectiveDiscussion)(0, s.P0)(this.isCodingChallengeValue ? __tr(["You're no longer following this challenge"], undefined, "en", []) : __tr(["You're no longer following this discussion"], undefined, "en", []), {
                    transient: !0
                });
                else(0, s.P0)(__tr(["You’re no longer following this post"], undefined, "en", []), {
                    transient: !0
                })
            }
            getTooltipText(e) {
                return e ? this.postTypeIdValue === Se.CollectiveDiscussion ? this.isCodingChallengeValue ? __tr(["Unfollow this challenge to stop receiving notifications"], undefined, "en", []) : __tr(["Unfollow this discussion to stop receiving notifications"], undefined, "en", []) : __tr(["Unfollow this post to stop receiving notifications"], undefined, "en", []) : this.postTypeIdValue === Se.CollectiveDiscussion ? this.isCodingChallengeValue ? __tr(["Follow this challenge to receive notifications"], undefined, "en", []) : __tr(["Follow this discussion to receive notifications"], undefined, "en", []) : __tr(["Follow this post to receive notifications"], undefined, "en", [])
            }
        }
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        const {
            Base: je
        } = v("se-nav-prevention").build();
        class Ae extends je {
            constructor() {
                super(...arguments), this._shouldInterruptNav = !1, this._wasInterrupting = !1
            }
            connect() {
                this.windowUnloadHandler = this.windowUnloadHandler.bind(this), this.navPreventionInputHandler = this.navPreventionInputHandler.bind(this), this.pause = this.pause.bind(this), this.resume = this.resume.bind(this), window.addEventListener("beforeunload", this.windowUnloadHandler, {
                    capture: !0
                }), this.element.addEventListener("input", this.navPreventionInputHandler)
            }
            disconnect() {
                window.removeEventListener("beforeunload", this.windowUnloadHandler, {
                    capture: !0
                }), this.element.removeEventListener("input", this.navPreventionInputHandler)
            }
            pause() {
                this._wasInterrupting = this._shouldInterruptNav, this._shouldInterruptNav = !1
            }
            resume() {
                this._shouldInterruptNav = this._wasInterrupting
            }
            windowUnloadHandler(e) {
                this._shouldInterruptNav && (e.preventDefault(), e.returnValue = "")
            }
            navPreventionInputHandler(e) {
                const t = e.target;
                "INPUT" !== t.tagName && "TEXTAREA" !== t.tagName || (this._shouldInterruptNav = !0)
            }
        }
        var Re = __webpack_require__(94378);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
            function(e, t) {
                for (const n of e) {
                    if (t && !n.controllerName.startsWith(t)) throw new Error(`The provided Stimulus controllers must be namespaced with "${t}"`);
                    k.application.register(n.controllerName, n)
                }
            }([x, we, ke, xe, Ae, $e], "se-"), s.wb.then((async () => {
                await async function() {
                    if (window.siteIncludesLoaded) return Promise.resolve([]);
                    window.siteIncludesLoaded = !0;
                    const e = (0, Re._)("legacy/global/site-includes/index.mod.ts");
                    return Promise.all(e.map((e => __webpack_require__(98535)(`./${e.moduleName}.mod`))))
                }()
            })), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, i(__webpack_require__(70957))
    })()
})();