(() => {
    "use strict";
    var e = {
        n: t => {
            var n = t && t.__esModule ? () => t.default : () => t;
            return e.d(n, {
                a: n
            }), n
        },
        d: (t, n) => {
            for (var o in n) e.o(n, o) && !e.o(t, o) && Object.defineProperty(t, o, {
                enumerable: !0,
                get: n[o]
            })
        },
        o: (e, t) => Object.prototype.hasOwnProperty.call(e, t),
        p: ""
    };
    e.p = document.getElementById("webpack-public-path").innerText + "Js/", (() => {
        const t = window.jQuery;
        var n = e.n(t);
        class o {
            constructor() {
                this.categories = ["Other"]
            }
            getVariantNumber() {
                return 0
            }
        }
        class a {
            constructor() {
                this.categories = ["One", "Other"]
            }
            getVariantNumber(e) {
                return 1 === e ? 0 : 1
            }
        }
        class i {
            constructor() {
                this.categories = ["One", "Few", "Many"]
            }
            getVariantNumber(e) {
                const t = e % 10,
                    n = e % 100;
                return [1, -1].includes(t) && ![11, -11].includes(n) ? 0 : [2, 3, 4, -2, -3, -4].includes(t) && ![12, 13, 14, -12, -13, -14].includes(n) ? 1 : 2
            }
        }
        const s = /\$([a-zA-Z_][a-zA-Z0-9_]*)\$/g;
        const r = function(e, t, n, r) {
            const c = function(e) {
                    switch (e.toLowerCase().slice(0, 2)) {
                        case "ja":
                            return new o;
                        case "ru":
                            return new i;
                        default:
                            return new a
                    }
                }(n),
                l = function(e, t, n, o) {
                    let a = 0;
                    for (let e = 0; e < o.length; e++) {
                        const i = t[o[e]];
                        a += n.getVariantNumber(i) * Math.pow(n.categories.length, o.length - e - 1)
                    }
                    return e[a]
                }(e, t, c, r);
            return d = t, l.replace(s, ((e, t) => "" + d[t]));
            var d
        };
        const c = 1,
            l = 9,
            d = 13,
            u = 27;
        if (StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, globalThis.__tr = r, window.StackExchange = window.StackExchange || {}, top !== self && 0 !== window.location.pathname.toLowerCase().indexOf("/integrations/embedded")) throw top.location.replace(document.location), n()((function() {
            n()("body").empty().text(__tr(["For security reasons, framing is not allowed."], undefined, "en", [])), n()("head").remove()
        })), new Error;
        var p, f, h, g, m, v, b;
        if (StackExchange.init = (p = function(e) {
                if (!window.jQuery) {
                    if ("complete" !== document.readyState) return void setTimeout((function() {
                        p(e)
                    }), 1e3);
                    var t = document.createElement("div");
                    t.id = "noscript-warning", t.innerHTML = __tr(["$siteName$ requires external JavaScript from another domain, which is blocked or failed to load. <a href=\"$cookieUrl$\">Retry using another source</a>."], {
                        siteName: e,
                        cookieUrl: "/home/get-jquery-fallback-cookie"
                    }, "en", []), document.body.appendChild(t);
                    var n = document.getElementById("noscript-css");
                    if (!n) return;
                    var o = document.createElement("div");
                    o.innerHTML = n.innerText, document.head.appendChild(o.getElementsByTagName("style")[0])
                }
            }, function() {
                p(StackExchange.options.site.name), n().ajaxSetup({
                    cache: !1
                }), StackExchange.init.createJqueryExtensions(), n()((function() {
                    (function() {
                        try {
                            return window.location.host.endsWith(".kinokrad-co.com") || window.location.host.endsWith(".cryptoo.online")
                        } catch (e) {
                            return !1
                        }
                    })() && (window.location.href = "https://stackexchange.com/about/malware?host=" + window.location.hostname),
                    function() {
                        var e = function(t, o) {
                            if (t) {
                                var a = n()(t).filter(":not(.popup-stack-hidden)");
                                if (!a.length) return;
                                a.each((function(e, t) {
                                    var o = n()(t),
                                        i = o.data("_popup"),
                                        s = o.data("_lightbox");
                                    i && (a = a.add(i)), s && (a = a.add(s))
                                })), a = (a = n()(n().uniqueSort(a.get()))).not(".popup-closing").addClass("popup-closing");
                                var i = {
                                        closeTrigger: o
                                    },
                                    s = n().Event("popupClosing", i);
                                if (a.trigger(s), s.isDefaultPrevented()) return void a.removeClass("popup-closing");
                                (a = a.not(".popup-closed").addClass("popup-closed")).filter(":not(.esc-hide)").fadeOutAndRemove(), a.filter(".esc-hide").fadeOut("fast", (function() {
                                    a.removeClass("popup-closing").removeClass("popup-closed")
                                })), a.trigger("popupClose", i)
                            } else StackExchange.topbar && StackExchange.topbar.hideAll(), e(".lightbox:not(.no-auto-close), .message-dismissable, .popup:not(.no-auto-close), .s-modal.js-stacks-managed-popup:not(.no-auto-close), .esc-remove, .esc-hide", o || "esc")
                        };
                        n()(document).on("keyup", (function(t) {
                            t.which === u && e()
                        })), n()("body").on("mousedown", (function(t) {
                            var o = n()(t.target);
                            if (!o.closest(".ac_results, .popup, .wmd-prompt-dialog, .message, .modal, .body-click-hide").length) {
                                var a = "click outside";
                                if (t.which === c)
                                    if (o.is(".wmd-prompt-background")) e(".wmd-prompt-dialog, .wmd-prompt-background, .popup#image-upload", a);
                                    else {
                                        if (!o.closest(".popup, .modal, .s-modal--dialog, .s-toast").length) {
                                            var i = ".popup:not(.no-auto-close), .lightbox:not(.no-auto-close), .modal:not(.no-auto-close), .s-modal.js-stacks-managed-popup:not(.no-auto-close)",
                                                s = o.closest(".s-modal.js-stacks-managed-popup");
                                            s.length ? e(s.filter(i).add(s.find(i)), a) : e(i, a)
                                        }
                                        o.closest(".message-config").length || e(".message-config.message-dismissable", a), o.closest(".body-click-hide").length || e(".esc-hide")
                                    }
                            }
                        })), n()(document).on("closePopups", (function(t) {
                            e(t.selectorToClose, t.closeTrigger)
                        }));
                        var t = [];
                        n()(document).on("popupLoad", (function(e) {
                            var n = e.popup;
                            if (e.lightbox)
                                for (var o = 0; o < t.length; o++) t[o].css("display", "none").addClass("popup-stack-hidden");
                            var a = n.data("_lightbox");
                            a && (n = n.add(a)), n.data("popup-stack-index", t.length), t.push(n)
                        })).on("popupClosing", (function(o) {
                            if (!o.isDefaultPrevented()) {
                                var a, i = n()(o.target).data("popup-stack-index");
                                if (i && !isNaN(i)) {
                                    for ((i < 0 || i >= t.length) && StackExchange.debug.log("popupStack index out of bounds"); t.length > i;)(a = t.pop()).data("popup-stack-index", null), e(a, o.closeTrigger);
                                    for (; i > 0 && ((a = t[--i]).removeClass("popup-stack-hidden").css("display", "block"), !a.filter(".lightbox").length););
                                }
                            }
                        }))
                    }(),
                    function() {
                        var e = "se:fkey";

                        function t(e) {
                            StackExchange.options.site.prefixFkey && StackExchange.options.site.routePrefix && (e = StackExchange.options.site.routePrefix + "/" + e), StackExchange.options.user.fkey !== e && (StackExchange.options.user.fkey = e, n()("input[name=fkey]").val(e))
                        }
                        n()(window).on("storage", (function(n) {
                            (n = n.originalEvent).key === e && n.newValue && t(n.newValue.split(/,/)[0])
                        }));
                        try {
                            var o = StackExchange.options.user.fkey,
                                a = function() {
                                    var t = localStorage.getItem(e);
                                    if (!t) return {
                                        time: 0
                                    };
                                    var n = t.split(/,/);
                                    return {
                                        fkey: n[0],
                                        time: parseInt(n[1], 10)
                                    }
                                }();
                            a.fkey !== o && (StackExchange.options.serverTime > a.time ? function(t, n) {
                                try {
                                    var o = t.lastIndexOf("/");
                                    o >= 0 && (t = t.substr(o + 1)), localStorage.setItem(e, t + "," + n)
                                } catch (e) {}
                            }(o, StackExchange.options.serverTime) : t(a.fkey))
                        } catch (e) {}
                    }(), n()(document).on("click", ".convert-to-post", (function(e) {
                        e.preventDefault();
                        var t = n()(this).attr("data-confirm");
                        t && !confirm(t) || n()("<form method='post'/>").attr("action", n()(this).attr("href")).appendTo("body").append(n()("<input type='hidden' name='fkey' />").attr("value", n()(this).attr("data-fkey"))).submit()
                    })), StackExchange.using(StackExchange.options.user.isAnonymous ? "anonymous" : "loggedIn", (function() {
                        StackExchange.initialized.resolve()
                    }), 2);
                    var e = StackExchange.settings.site.styleCodeAdditionalLang;
                    e && StackExchange.ifUsing("highlightjs", (function() {
                        return StackExchange.loadJsFile("third-party/highlight.js/additional-langs/" + e)
                    })), StackExchange.scrollPadding.ensureInitialized(), StackExchange.ready((function() {
                        StackExchange.options.user.messages && StackExchange.notify.showMessages(StackExchange.options.user.messages), StackExchange.settings.site.enableUserHovercards && StackExchange.usermenu.init(), StackExchange.options.site.universalAuthDisabled || UniversalAuth.performAuth(), StackExchange.tagPreferences ? StackExchange.tagPreferences.init() : StackExchange.tagmenu.init(), n()("*[data-tracker]").track(), StackExchange.bindShowMoreHotNetworkQuestions();
                        var e = function() {
                            var e = !1;
                            n()("body > script:not([src])").each((function() {
                                if (this.textContent.length > 4e4 && /currentSelectable/.test(this.textContent)) return e = !0, !1
                            })), (e || StackExchange.options.user.keyboardShortcuts) && StackExchange.using("keyboardShortcuts", (function() {
                                StackExchange.keyboardShortcuts.init(e)
                            }))
                        };
                        document.readyState && "complete" !== document.readyState ? n()(window).on("load", (function() {
                            setTimeout(e, 10)
                        })) : setTimeout(e, 10), StackExchange.showFlashMessageIfAny()
                    }))
                }))
            }), StackExchange.debug = {
                log: function(e) {},
                init: function() {
                    this.log = function(e) {
                        n()((function() {
                            var t = n()("#debug-messages");
                            t.length || (t = n()("<div id='debug-messages' class='bg-white bs-sm l48 ps-fixed s-card t64 ws3 z-modal' />").append(n()("<button class='s-btn s-btn__muted s-btn__outlined s-btn__xs'>close debug messages</button>").on("click", (function() {
                                n()("#debug-messages").remove()
                            }))).appendTo("body")), n()("<div class='mt12' />").text(e).appendTo(t)
                        }))
                    }
                }
            }, StackExchange.initialized = n().Deferred(), StackExchange.ready = function(e) {
                StackExchange.initialized.done(e)
            }, window.serq)
            for (var x = 0; x < window.serq.length; x++) StackExchange.ready(window.serq[x]);
        ! function() {
            var e, t = {
                    adops: "adops.js",
                    anonymous: "full-anon.js",
                    autocomplete: "tageditor.js",
                    beginEditEvent: "begin-edit-event.js",
                    editor: "wmd.js",
                    eventCharts: "events.js",
                    exploreQuestions: "explore-qlist.js",
                    externalEditor: ["full-anon.js", "full.js"],
                    ga: "google-analytics.js",
                    gps: ["full-anon.js", "full.js"],
                    highlightjs: "highlightjs-loader.js",
                    inlineEditing: "full.js",
                    inlineTagEditing: "inline-tag-editing.js",
                    keyboardShortcuts: "keyboard-shortcuts.js",
                    loggedIn: "full.js",
                    mathjaxEditing: "mathjax-editing.js",
                    mathjaxEditingV3: "mathjax-editing.v3.js",
                    markdownit: "markdown-it-loader.js",
                    mockups: ["full-anon.js", "full.js"],
                    moderator: "moderator.js",
                    "StackOverflow.Scripts.PostCollections": "postCollections-transpiled.js",
                    "StackOverflow.Scripts.Mentions": "mentions-transpiled.js",
                    postValidation: "post-validation.js",
                    review2: "review-v2-transpiled.js",
                    revisions: "revisions.js",
                    schematics: ["full-anon.js", "full.js"],
                    snippets: ["full-anon.js", "full.js"],
                    snippetsJsCodeMirror: "snippet-javascript-codemirror.js",
                    stacksEditor: "stacks-editor.js",
                    tagAutocomplete: "tageditor.js",
                    tagEditor: "tageditornew.js",
                    tagSuggestions: "tagsuggestions.js",
                    translation: "full.js",
                    virtualKeyboard: "virtual-keyboard.js"
                },
                o = {},
                a = {},
                i = {},
                s = {},
                r = function(e, t) {
                    return function(n) {
                        var o = e[n];
                        return o || (o = e[n] = t(n)), o
                    }
                },
                c = function() {
                    if (!e) {
                        var t = n()("script[src]").filter((function() {
                            return /\/stub.*\.js/.test(n()(this).attr("src"))
                        })).first();
                        0 === t.length ? (StackExchange.debug.log("couldn't figure out location of stub.js"), e = "/Content/Js/") : e = t.attr("src").replace(/\/stub.*\.js.*$/, "/")
                    }
                    return e
                },
                l = function(e) {
                    var t = s["Js/" + e];
                    return t ? "?v=" + t : (StackExchange.debug.log("no cache breaker for " + e), "")
                },
                d = function(e) {
                    return e && StackExchange.options.locale && -1 === e.indexOf("third-party") && (e = e.replace(/^(.*)(\.js)(\?.*)?$/, "$1." + StackExchange.options.locale + "$2$3")), e
                },
                u = function(e, t) {
                    var o = n().Deferred(),
                        a = document.createElement("script");
                    return a.async = "async", a.src = t ? e : d(e), a.onload = a.onreadystatechange = function(e, t) {
                        a.readyState && !/loaded|complete/.test(a.readyState) || (t ? o.reject() : o.resolve())
                    }, a.onerror = function() {
                        o.reject()
                    }, n()("head")[0].appendChild(a), o.promise()
                },
                p = r(o, (function(e) {
                    return u(c() + e + l(d(e)))
                })),
                f = r({}, (function(e) {
                    function i() {
                        if (e) {
                            if ("string" != typeof e || e.indexOf(".") < 0) return StackExchange[e];
                            for (var t = window, n = e.split("."), o = 0; o < n.length && (t = t[n[o]]); o++);
                            return t
                        }
                    }
                    var s = n().Deferred(),
                        r = i(),
                        c = 3;

                    function l() {
                        (function(e) {
                            var t, o, i = a[e],
                                s = n().Deferred(),
                                r = n().when(s);
                            if (i)
                                for (t = 0; t < i.length; t++)(o = i[t].call(null)) && "function" == typeof o.promise && (r = n().when(r, o));
                            return s.resolve(), r
                        })(e).done((function() {
                            s.resolve()
                        }))
                    }
                    return r ? l() : function(e) {
                        var a = t[e];
                        if (!a) return n().Deferred().reject().promise();
                        if (a instanceof Array) {
                            if (0 === a.length) return n().Deferred().reject().promise();
                            for (var i = 0; i < a.length; i++) {
                                var s = a[i],
                                    r = o[s];
                                if (r) return r
                            }
                            return p(a[0])
                        }
                        return p(a)
                    }(e).done((function t() {
                        if (!(r = i())) return c > 0 ? (c--, StackExchange.debug.log("retrying " + e), void setTimeout(t, 20)) : (StackExchange.debug.log("object StackExchange." + e + " not available although file was loaded"), void s.reject());
                        l()
                    })).fail(s.reject), s.promise()
                })),
                h = n().Deferred(),
                g = function(e, o, a) {
                    if (0 !== (a = a || 0) || "resolved" === h.state()) {
                        if (2 === a)
                            for (var i in t)
                                if (t.hasOwnProperty(i)) {
                                    var s = t[i];
                                    if (s instanceof Array) {
                                        for (var r = [], c = 0; c < s.length; c++) r.push(s[c]);
                                        t[i] = r
                                    } else t[i] = s
                                }
                        var l = f(e);
                        return 0 === a ? l = n().when(l, StackExchange.initialized) : 2 === a && h.resolve(), l.done((function() {
                            o()
                        })).fail((function() {
                            StackExchange.debug.log("failed to provide object " + e)
                        })), l
                    }
                    h.done((function() {
                        g(e, o)
                    }))
                };
            g.setCacheBreakers = function(e) {
                for (var t in e) e.hasOwnProperty(t) && (s[t] = e[t])
            };
            StackExchange.getCacheBreaker = l, StackExchange.cacheBreakers = s, StackExchange.using = g, StackExchange.ifUsing = function(e, t, n) {
                if (void 0 !== n) {
                    if (i["u_" + n]) return;
                    i["u_" + n] = !0
                }
                if (StackExchange[e]) t();
                else {
                    var o = a[e];
                    o || (o = a[e] = []), o.push(t)
                }
            }, StackExchange.loadJsFile = function(e, t) {
                return u(c() + e, t)
            }
        }(), String.prototype.formatUnicorn = function() {
            var e = this.toString();
            if (!arguments.length) return e;
            var t = typeof arguments[0],
                n = "string" === t || "number" === t ? Array.prototype.slice.call(arguments) : arguments[0];
            for (var o in n) e = e.replace(new RegExp("\\{" + o + "\\}", "gi"), n[o]);
            return e
        }, String.prototype.truncate = function(e, t) {
            var n = this.toString();
            return e && n.length > e && (n = n.substr(0, e) + t), n
        }, String.prototype.splitOnLast = function(e) {
            var t = this.lastIndexOf(e);
            return t < 0 ? [this] : [this.substring(0, t), this.substring(t)]
        }, String.prototype.contains = function(e) {
            return this.indexOf(e) > -1
        }, String.prototype.endsWith || (String.prototype.endsWith = function(e) {
            return -1 !== this.indexOf(e, this.length - e.length)
        }), StackExchange.init.createJqueryExtensions = function() {
            var e = StackExchange.helpers;
            n().extend(n().expr.pseudos, {
                working: function(e) {
                    var t = n()(e).data("working");
                    return void 0 !== t && t
                },
                data: function(e, t, o) {
                    var a = o[3],
                        i = n()(e).data(a);
                    switch (typeof i) {
                        case "undefined":
                            return !1;
                        case "boolean":
                            return i;
                        case "object":
                            return null !== i
                    }
                    return !0
                },
                containsCI: function(e, t, o) {
                    return n()(e).text().toUpperCase().indexOf(o[3].toUpperCase()) >= 0
                },
                viewport: function(e) {
                    var t = e.getBoundingClientRect();
                    return t.top >= 0 && t.left >= 0 && t.bottom <= (window.innerHeight || document.documentElement.clientHeight) && t.right <= (window.innerWidth || document.documentElement.clientWidth)
                }
            }), n().fn.extend({
                working: function(e) {
                    return this.each((function() {
                        n()(this).data("working", e)
                    }))
                },
                track: function() {
                    return this.each((function() {
                        var e = n()(this),
                            t = e.is("a[href]") ? e : e.find("a[href]"),
                            o = e.data("tracker");
                        t.each((function() {
                            var e = this.href.splitOnLast("#"),
                                t = e[0];
                            t += (t.contains("?") ? "&" : "?") + o + (e[1] || ""), this.href = t
                        }))
                    }))
                },
                fadeOutAndRemove: function() {
                    return this.each((function() {
                        var e = n()(this);
                        e.is(".js-fades-with-aria-hidden") ? (e.attr("aria-hidden", "true"), e.on("transitionend", (function(t) {
                            "opacity" === t.originalEvent.propertyName && e.trigger("removing").remove()
                        }))) : e.fadeOut("fast", (function() {
                            e.trigger("removing").remove()
                        }))
                    }))
                },
                charCounter: function(t) {
                    return this.each((function() {
                        var o = t.target ? n()(t.target) : n()(this).parents("form").find("span.text-counter"),
                            a = this;
                        n()(this).on("blur focus keyup paste charCounterUpdate", e.DelayedReaction((function() {
                            var e = t.min,
                                i = t.max,
                                s = t.startAt,
                                r = (t.setIsValid || function() {}).bind(a),
                                c = t.useJQueryVal,
                                l = 0,
                                d = a.tagName && "DIV" === a.tagName ? a.textContent : c ? n()(a).val() : a.value;
                            d && (l = t.ignoreWhitespace ? d.replace(/\s+/g, " ").replace(/^\s+/, "").replace(/\s+$/, "").length : d.replace(/\r\n/g, "\n").replace(/\n/g, "\r\n").length);
                            var u = l > i ? "fc-red-400" : l > .8 * i ? "supernova" : l > .6 * i ? "hot" : l > .4 * i ? "warm" : "cool",
                                p = "";
                            if (0 === l) 0 === e ? (p = __tr(["Enter up to $max$ characters", "Enter up to $max$ characters"], {
                                max: i
                            }, "en", ["max"]), r(!0)) : (p = __tr(["Enter at least $min$ character", "Enter at least $min$ characters"], {
                                min: e
                            }, "en", ["min"]), r(!1));
                            else if (l < e) p = __tr(["$count$ more to go...", "$count$ more to go..."], {
                                count: e - l
                            }, "en", ["count"]), r(!1);
                            else {
                                var f = i - l;
                                p = f >= 0 ? __tr(["$count$ character left", "$count$ characters left"], {
                                    count: f
                                }, "en", ["count"]) : __tr(["Too long by $count$ character", "Too long by $count$ characters"], {
                                    count: Math.abs(f)
                                }, "en", ["count"]), r(l <= i)
                            }
                            s && l < s && (p = ""), o.text(p), o.hasClass(u) || o.removeClass("fc-red-400 supernova hot warm cool").addClass(u)
                        }), 100, {
                            sliding: !0
                        }).trigger)
                    }))
                },
                addSpinner: function(t) {
                    return this.each((function() {
                        e.addSpinner(this, t)
                    }))
                },
                addSpinnerAfter: function(t) {
                    return this.each((function() {
                        n()(this).after(e.getSpinnerImg(t))
                    }))
                },
                addSpinnerBefore: function(t) {
                    return this.each((function() {
                        n()(this).before(e.getSpinnerImg(t))
                    }))
                },
                addStacksSpinner: function(t, n) {
                    return this.each((function() {
                        e.addStacksSpinner(this, t, n)
                    }))
                },
                setTooltipText: function(e, t) {
                    return this.each((function() {
                        Stacks.setTooltipText(this, e, t)
                    }))
                },
                setTooltipHtml: function(e, t) {
                    return this.each((function() {
                        Stacks.setTooltipHtml(this, e, t)
                    }))
                },
                removeSpinner: function() {
                    return this.each((function() {
                        n()(this).find("img.ajax-loader, .s-spinner").remove()
                    }))
                },
                showErrorMessage: function(t, n) {
                    return this.each((function() {
                        e.showErrorMessage(this, t, n)
                    }))
                },
                showErrorPopup: function(t, n) {
                    return this.each((function() {
                        e.showErrorMessage(this, t, n)
                    }))
                },
                showInfoMessage: function(t, n) {
                    return this.each((function() {
                        e.showInfoMessage(this, t, n)
                    }))
                },
                center: function(e) {
                    e = e || {};
                    var t = this.parent();
                    "static" === t.css("position") && (t = t.offsetParent());
                    var o = t.offset(),
                        a = n()(window),
                        i = e.top || Math.max((a.height() - this.outerHeight()) / 2 + a.scrollTop() - StackExchange.scrollPadding.getPaddingTop() - o.top + (e.dy || 0), 65);
                    this.css("position", "absolute"), this.css("top", i + "px");
                    var s = Math.max(20, (a.width() - this.outerWidth()) / 2 + a.scrollLeft() - o.left);
                    this.css("left", s + "px");
                    var r = "calc(50% - " + this.outerWidth() / 2 + "px)";
                    return this.css("left", r), this.css("left", "-webkit-" + r), this
                },
                enable: function() {
                    return 0 === arguments.length || arguments[0] ? this.prop("disabled", !1).css("cursor", "pointer").removeClass("disabled-button") : this.prop("disabled", !0).css("cursor", "default").addClass("disabled-button"), this
                },
                disable: function() {
                    return this.enable(!1)
                },
                checked: function(e) {
                    return e ? this.prop("checked", !0) : this.prop("checked", !1), this
                },
                loadPopup: function(t) {
                    var o = n().Deferred(),
                        a = this,
                        i = t.target || a.parent();
                    (e.hideToasts(), t.html || t.noSpinner) || (t.addSpinnerFn || n().fn.addSpinnerAfter).call(a, {
                        padding: "0 3px"
                    });
                    t.loaded && o.done(t.loaded);
                    var s = function(s) {
                        var r, c = n()(s).elementNodesOnly();
                        c.find(".popup-actions-cancel, .popup-close a, .modal-close, .js-popup-close").on("click", (function() {
                            StackExchange.helpers.closePopups(r ? c.add(r) : c)
                        })), c.find("input:radio[disabled=disabled] + label.action-label").addClass("action-disabled"), t.hideDescriptions && c.addClass("_hidden-descriptions").find("ul.action-list > li:not(.action-selected) .action-desc").hide();
                        var l = c.find("input:radio:not(.action-subform input)");
                        l.closest("li").on("hide-action", (function() {
                            var e = n()(this),
                                o = ".action-subform" + (t.hideDescriptions ? ", .action-desc" : "");
                            e.removeClass("action-selected").find(o).slideUp("fast")
                        })).on("show-action", (function(e) {
                            var o = n()(this);
                            o.hasClass("action-selected") ? e.stopImmediatePropagation() : (o.siblings(".action-selected").trigger("hide-action"), o.addClass("action-selected").find(".action-subform").slideDown("fast", (function() {
                                if (t.subformShow && t.subformShow(n()(this)), t.subformFocusInput) {
                                    var e = n()(this).find("input[type=text], textarea").not(".actual-edit-overlay").eq(0);
                                    e.length && e.trigger("focus")
                                }
                            })), t.hideDescriptions && o.find(".action-desc").slideDown("fast"), t.actionSelected && t.actionSelected(o), c.find(".popup-submit, .js-popup-submit").enable())
                        })).filter(".show-action-onload").each((function() {
                            var e = n()(this);
                            o.done((function() {
                                e.find("input[type=radio]").trigger("click")
                            }))
                        })), l.on("click", (function() {
                            n()(this).closest("li").trigger("show-action")
                        })), (t.insert || function(e) {
                            t.prepend ? e.prependTo(i) : e.appendTo(i)
                        })(c), t.lightbox && (r = StackExchange.helpers.addLightbox().data("_popup", c), c.css("z-index", +r.css("z-index") + 1).data("_lightbox", r)), o.resolveWith(a, [c, r]), i.trigger(n().Event("popupLoad", {
                            popup: c,
                            lightbox: r
                        }));
                        var d = function() {};
                        if (t.subformShow) {
                            var u = c.find("li.action-selected .action-subform");
                            u.length > 0 && (d = function() {
                                u.each((function() {
                                    t.subformShow(n()(this))
                                }))
                            })
                        }!!t.dontShow || (c.center().fadeIn("fast", d), r && r.fadeIn("fast")), e.bindMovablePopups()
                    };
                    return t.html ? s(t.html) : n().ajax({
                        type: "GET",
                        url: t.url,
                        dataType: "html",
                        data: t.data,
                        success: s,
                        error: function(n, a, s) {
                            var r = n.responseText && n.responseText.length < 200 ? n.responseText : t.defaultErrorMessage || __tr(["Unable to load popup - please try again"], undefined, "en", []),
                                c = {
                                    type: "warning",
                                    transient: 409 === n.status,
                                    $source: i
                                };
                            t.transientTimeout && (c.transientTimeout = t.transientTimeout), e.showToast(r, c), o.reject(r)
                        },
                        complete: e.removeSpinner
                    }), o.promise()
                },
                asyncLoad: function(e) {
                    return e = n().extend({
                        callback: null,
                        cache: {}
                    }, e), this.each((function() {
                        var t = ".js-async-load",
                            o = n()(this),
                            a = o.find(t);
                        o.is(t) && (a = a.add(o)), a.each((function() {
                            var t = n()(this),
                                o = t.data("load-url") || "";
                            if (o && !t.is(":working")) {
                                t.working(!0).addSpinner();
                                var a = function(n) {
                                        t.html(n).removeClass("js-async-load").mathjax();
                                        var o = t.data("after-load") || "";
                                        if (o || e.callback) {
                                            for (var a, i = o ? o.split(".") : [], s = 0; s < i.length; s++) a = (a || window)[i[s]];
                                            "function" == typeof(a = a || e.callback) && a(t)
                                        }
                                    },
                                    i = e.cache[o];
                                i ? window.setTimeout((function() {
                                    a(i)
                                }), 0) : n().ajax({
                                    type: "GET",
                                    url: o,
                                    dataType: "html"
                                }).done((function(t) {
                                    e.cache[o] = t, a(t)
                                })).fail((function() {
                                    t.removeSpinner().showErrorMessage(__tr(["An error has occurred; please try again"], undefined, "en", []))
                                }))
                            }
                        }))
                    }))
                },
                mathjax: function() {
                    return this.each((function() {
                        "undefined" != typeof MathJax && (MathJax.Hub ? MathJax.Hub.Typeset(this) : MathJax.typesetPromise([this]).catch((function(e) {
                            console.error("MathJax typeset failed: " + e.message)
                        })))
                    }))
                },
                elementNodesOnly: function() {
                    return this.filter((function() {
                        return 1 === this.nodeType
                    }))
                },
                scrollIntoView: function(e) {
                    if (0 === this.length) return this;
                    var t = n().extend({}, {
                            duration: 100,
                            complete: null
                        }, e),
                        o = this.first();
                    return "contents" === o.css("display") && (o = o.children().first()), o.is(":viewport") ? "function" == typeof t.complete && t.complete() : n()("html, body").animate({
                        scrollTop: o.offset().top
                    }, t), this
                },
                outerHTML: function() {
                    return n()("<div>").append(this.eq(0).clone()).html()
                },
                unadornedButtonClick: function(e, t) {
                    var o = n().extend({}, {
                        namespace: "button",
                        selector: null
                    }, t);
                    return this.on("keypress." + o.namespace, o.selector, (function(t) {
                        t.keyCode !== KEY_CODE.SPACE && t.keyCode !== KEY_CODE.ENTER || (e.apply(this, arguments), t.preventDefault())
                    })).on("click." + o.namespace, o.selector, (function(t) {
                        this.blur(), e.apply(this, arguments), t.preventDefault()
                    }))
                },
                addAtEnd: function(e) {
                    var t = this.get();
                    return t.push.apply(t, n()(e).get()), this.pushStack(t)
                },
                dispatchEvent: function(e, t) {
                    var n, o = this.get(0);
                    try {
                        n = new CustomEvent(e, {
                            cancelable: !0,
                            bubbles: !0,
                            detail: t || {}
                        })
                    } catch (o) {
                        (n = document.createEvent("CustomEvent")).initCustomEvent(e, !0, !0, t || {})
                    }
                    return o && o.dispatchEvent(n), n
                },
                findExclude: function(e, t) {
                    return this.find(e).not(this.find(t).find(e))
                }
            })
        }, StackExchange.helpers = function() {
            function e(e, t) {
                n()(e).find("input[type='submit'], button[type='submit']").prop("disabled", t);
                const o = n()(e);
                o && o.length > 0 && o.each(((e, o) => {
                    const a = o.id;
                    a && n()(`button[type='submit'][form='${a}']`).prop("disabled", t)
                }))
            }
            var t = {
                addLightbox: function() {
                    return n()('<div class="lightbox"/>').appendTo(n()("body")).css("height", n()(document).height())
                },
                bindMovablePopups: function() {
                    n()("div.popup:not([data-controller~=se-draggable])").attr("data-controller", "se-draggable").find(".handle").attr("data-se-draggable-target", "handle")
                },
                bindOnHashChange_HighlightDestination: function(e, t) {
                    var o = "hashchange.highlightDestination";
                    n()(window).off(o).on(o, (function() {
                        var n = window.location.href;
                        if (!(n.indexOf("#") < 0)) {
                            var o = decodeURI(n).match(/#(\d+|comment(\d+)_(\d+))/i);
                            o && (o[2] && e ? e(o[2], o[3]) : t && t(o[1]))
                        }
                    })).trigger(o)
                },
                onClickDraftSave: function(e) {
                    return n()(e).on("click", (function(e) {
                        if (StackExchange.cardiologist) {
                            e.preventDefault();
                            var t = this.href;
                            return StackExchange.cardiologist.ensureDraftSaved((function() {
                                window.onbeforeunload = null, window.location.href = t
                            })), !1
                        }
                    })), !0
                },
                showMessage: function(e, o, a) {
                    if ((e = n()(e)).length) {
                        var i = n().extend({}, {
                            messageElement: null,
                            position: "inside",
                            dismissable: !0,
                            type: "error",
                            closeOthers: !0,
                            shown: function() {},
                            relativeToBody: !1,
                            lightbox: !1,
                            stopBodyScroll: !1,
                            fixedTo$elem: !1,
                            slideDown: !1
                        }, a);
                        i.closeOthers && n()(".message, .js-stacks-managed-popup").fadeOutAndRemove();
                        var s = n()('<div class="message"><div class="message-inner"><div class="message-text"></div></div></div>'),
                            r = s.find(".message-inner"),
                            c = s.find(".message-text");
                        if (s.addClass("message-" + i.type), i.cssClass && s.addClass(i.cssClass), i.messageElement ? c.append(i.messageElement) : c.html(o), i.dismissable && (s.addClass("message-dismissable"), c.css("padding-right", "48px"), r.prepend(n()("<div />", {
                                title: i.closeTitle || __tr(["close this message (or hit Esc)"], undefined, "en", []),
                                class: "message-close",
                                text: "×"
                            })), s.on("click", (function(e) {
                                var t = n()(e.target);
                                (!0 === i.dismissable && !t.is("a") || "x-or-esc" === i.dismissable && t.is(".message-close, .message-close-inner")) && (i.dismissing && i.dismissing(), s.fadeOutAndRemove(), i.lightbox && n()(".lightbox").fadeOutAndRemove())
                            }))), i.dismissing && s.on("popupClose", (function(e, t) {
                                "esc" === t.closeTrigger && i.dismissing()
                            })), i.css && s.css(i.css), "inside" === i.position || "inline" === i.position || "toast" === i.position || i.tip || (i.tip = i.position.my), i.tip && r.addClass("message-tip message-tip-" + i.tip.replace(" ", "-")), "inline" === i.position) e.append(s);
                        else if ("inside" === i.position) s.css("position", "absolute"), e.append(s);
                        else if ("toast" === i.position) s.addClass("toast").appendTo(e);
                        else {
                            s.css("position", "absolute"), (i.relativeToBody ? n()("body") : e.offsetParent()).append(s);
                            var l, d, u = i.relativeToBody ? e.offset() : e.position(),
                                p = e.outerWidth(!0),
                                f = e.outerHeight(!0),
                                h = s.outerWidth(),
                                g = s.outerHeight(),
                                m = (p - e.outerWidth(!1)) / 2;
                            switch (i.position.at) {
                                case "top left":
                                case "left top":
                                    l = {
                                        top: 0,
                                        left: 0
                                    };
                                    break;
                                case "top center":
                                    l = {
                                        top: 0,
                                        left: p / 2 + m
                                    };
                                    break;
                                case "top right":
                                case "right top":
                                    l = {
                                        top: 0,
                                        left: p
                                    };
                                    break;
                                case "right center":
                                    l = {
                                        top: f / 2,
                                        left: p
                                    };
                                    break;
                                case "right bottom":
                                case "bottom right":
                                    l = {
                                        top: f,
                                        left: p
                                    };
                                    break;
                                case "bottom center":
                                    l = {
                                        top: f,
                                        left: p / 2 + m
                                    };
                                    break;
                                case "bottom left":
                                case "left bottom":
                                    l = {
                                        top: f,
                                        left: 0
                                    };
                                    break;
                                case "left center":
                                    l = {
                                        top: f / 2,
                                        left: 0
                                    }
                            }
                            switch (i.position.my) {
                                case "left top":
                                    d = {
                                        top: 0,
                                        left: -9
                                    };
                                    break;
                                case "top left":
                                    d = {
                                        top: -9,
                                        left: 0
                                    };
                                    break;
                                case "top center":
                                    d = {
                                        top: -9,
                                        left: h / 2 + 9
                                    };
                                    break;
                                case "top right":
                                    d = {
                                        top: -9,
                                        left: h
                                    };
                                    break;
                                case "right top":
                                    d = {
                                        top: 0,
                                        left: h + 9
                                    };
                                    break;
                                case "right bottom":
                                    d = {
                                        top: g,
                                        left: h + 9
                                    };
                                    break;
                                case "bottom right":
                                    d = {
                                        top: g + 9,
                                        left: h
                                    };
                                    break;
                                case "bottom center":
                                    d = {
                                        top: g + 9,
                                        left: h / 2 + 9
                                    };
                                    break;
                                case "bottom left":
                                    d = {
                                        top: g + 9,
                                        left: 0
                                    };
                                    break;
                                case "left bottom":
                                    d = {
                                        top: g,
                                        left: -9
                                    }
                            }
                            var v = {
                                left: u.left + l.left - d.left,
                                top: u.top + l.top - d.top
                            };
                            if (s.data("initialTop", v.top), s.animateOffsetTop = function(e) {
                                    s.animate({
                                        top: s.data("initialTop") + e
                                    })
                                }, i.position.offsetTop && (v.top += i.position.offsetTop), i.position.offsetLeft && (v.left += i.position.offsetLeft), s.css({
                                    top: v.top,
                                    left: v.left
                                }), i.fixedTo$elem) {
                                var b = null,
                                    x = e.offset(),
                                    k = n()(window).width(),
                                    w = "resize.message scroll.message";
                                n()(window).on(w, (function() {
                                    b = b || s.offset();
                                    var t = e.offset().top - x.top,
                                        o = (n()(window).width() - k) / 2;
                                    s.offset({
                                        top: b.top + t,
                                        left: b.left + o
                                    })
                                })), s.on("removing", (function() {
                                    n()(window).off(w)
                                }))
                            }
                        }
                        if (i.showing && i.showing(), i.lightbox) {
                            var y = n()("body"),
                                S = n()('<div class="lightbox"/>').appendTo(y).css("height", n()(document).height()).fadeIn();
                            i.stopBodyScroll && y.addClass("stop-scrolling"), s.on("removing", (function() {
                                S.fadeOutAndRemove(), i.stopBodyScroll && y.removeClass("stop-scrolling")
                            }))
                        }
                        if (i.slideDown) {
                            var E = e.css("margin-top"),
                                T = e.css("margin-bottom");
                            e.css("margin-top", 0), e.css("margin-bottom", 0), s.css("height", 0), e.css("display", "block"), s.css("display", "block"), e.animate({
                                "margin-top": E,
                                "margin-bottom": T
                            }, 500), s.animate({
                                height: s.get(0).scrollHeight
                            }, 500)
                        } else s.fadeIn(i.shown);
                        if (i.transient) {
                            var C = a.transientTimeout || t.suggestedTransientTimeout(o, "toast" === a.position);
                            setTimeout((function() {
                                s.fadeOutAndRemove()
                            }), C)
                        }
                        return i.removing && s.on("removing", i.removing), StackExchange.options.enableLogging && s.data("settings", i), s
                    }
                },
                suggestedTransientTimeout: function(e, t) {
                    var n = 40;
                    return "jp" === StackExchange.options.locale ? n = 80 : t && (n = 55), Math.max(4e3, e.length * n)
                },
                showErrorMessage: function(e, t, o) {
                    var a = n().extend({}, {
                        position: "inside",
                        type: "error"
                    }, o);
                    return this.showMessage(e, t, a)
                },
                showErrorPopup: function(e, t, n) {
                    return this.showErrorMessage(e, t, n)
                },
                showInfoMessage: function(e, t, o) {
                    var a = n().extend({}, {
                        position: "inside",
                        transient: !0,
                        type: "info"
                    }, o);
                    return this.showMessage(e, t, a)
                },
                showSuccessMessage: function(e, t, o) {
                    var a = n().extend({}, {
                        type: "success",
                        position: "toast",
                        transient: !0,
                        transientTimeout: 1e4
                    }, o);
                    return this.showMessage(e, t, a)
                },
                showBannerMessage: function(e, t) {
                    var o = n()(".banner-message-container").last();
                    0 === o.length && (o = n()("<div/>").addClass("top-banner-message-container").css("display", "none").insertAfter("#header"));
                    var a = {
                        type: t,
                        position: "inline",
                        cssClass: "banner-message",
                        slideDown: !0
                    };
                    return this.showMessage(o, e, a)
                },
                showStacksNotice: function(e, t, o) {
                    var a = n().extend({}, {
                            transient: !1,
                            transientTimeout: 2e4
                        }, o),
                        i = a.target || n()(".js-notice-message-container").last();
                    0 === i.length && (i = n()("<div/>").addClass("top-notice-message-container").insertAfter(n()("header").first()));
                    var s = n()('<aside class="s-notice py8" role="status" aria-hidden="false"><div class="d-flex gs16 gsx ai-center jc-space-between" aria-describedby="notice-message"><div class="flex--item message-text" aria-label="notice-message"></div><div class="flex--item mr0 dismiss-btn" aria-label="notice-dismiss"></div></div></aside>'),
                        r = s.find(".message-text"),
                        c = s.find(".dismiss-btn"),
                        l = n()("<a>", {
                            class: "message-close p8 s-btn d-flex flex__center fc-black-600",
                            title: __tr(["Close this message"], undefined, "en", [])
                        });
                    return l.append(Svg.ClearSm.With("pe-none")), c.append(l), c.on("click", (function(e) {
                        n()(e.target).is(".message-close") && (s.remove(), i.addClass("d-none"))
                    })), a.transient && s.delay(a.transientTimeout).slideUp(void 0, (function() {
                        this.remove()
                    })), s.addClass("s-notice__" + t), r.html(e), i.removeClass("d-none").append(s), s
                },
                showModal: function(e, o) {
                    var a = n()(e).addClass("js-stacks-managed-popup");
                    if (0 !== a.length) {
                        var i = n().extend({}, {
                                closeOthers: !0,
                                shown: function() {}
                            }, o),
                            s = n()("body");
                        i.closeOthers && n()(".message, .js-stacks-managed-popup").not(a).fadeOutAndRemove();
                        a.on("popupClose", (function(e, t) {
                            var o;
                            ["esc", "click outside", "dismiss", "submit"].indexOf(t.closeTrigger) >= 0 && (i.dismissing && i.dismissing(t.closeTrigger), (o = i.returnElements) && a.one("transitionend", (function() {
                                o.filter((function(e, t) {
                                    return n().contains(document.body, t)
                                })).first().trigger("focus")
                            })))
                        })), i.showing && i.showing(), a.find(".js-modal-close").on("click", (function(e) {
                            e.preventDefault(), t.closePopups(a, "dismiss")
                        })), a.addClass("s-modal").appendTo(s);
                        var r = a.find("a, button, [tabindex]").filter(":not([disabled]):not([tabindex=-1])"),
                            c = a.find(".js-first-tabbable"),
                            d = a.find(".js-last-tabbable");
                        return 0 === c.length && (c = r.first()), 0 === d.length && (d = r.last()), c.on("keydown", (function(e) {
                            e.keyCode === l && e.shiftKey && (e.preventDefault(), d.trigger("focus"))
                        })), d.on("keydown", (function(e) {
                            e.keyCode !== l || e.shiftKey || (e.preventDefault(), c.trigger("focus"))
                        })), setTimeout((function() {
                            a.addClass("js-fades-with-aria-hidden").attr("aria-hidden", "false"), a.one("transitionend", (function() {
                                a.find(".js-modal-initial-focus:not([disabled])").first().trigger("focus"), i.shown && i.shown()
                            }))
                        }), 16), i.removing && a.on("removing", i.removing), a
                    }
                },
                loadModal: function(e, o) {
                    var a = n().Deferred();
                    return o = o || {}, n().ajax({
                        type: "GET",
                        url: e,
                        dataType: "html",
                        success: function(e) {
                            var i = t.showModal(n()(e).elementNodesOnly(), o);
                            a.resolve(i)
                        },
                        error: function(e, t, n) {
                            var i = e.responseText && e.responseText.length < 200 ? e.responseText : o.defaultErrorMessage || __tr(["Unable to load popup - please try again"], undefined, "en", []);
                            a.reject(i)
                        }
                    }), a.promise()
                },
                toggleStacksPopover: function(e, t) {
                    StackExchange.helpers.DelayedReaction((function() {
                        var n = Stacks.application.getControllerForElementAndIdentifier(e.get(0), "s-popover");
                        !0 === t ? n.show() : !1 === t ? n.hide() : n.toggle()
                    }), 50).trigger()
                },
                queueStacksPopover: function(e, o) {
                    var a = n().Deferred();
                    a.then((function() {
                        t.toggleStacksPopover(e, !0)
                    }));
                    var i = function() {
                        var t, i, s, r;
                        0 === e.closest("body").length ? a.reject() : (t = n()(window).scrollTop(), i = t + n()(window).height() - StackExchange.scrollPadding.getPaddingTop(), s = e.offset().top, r = s + e.height(), s - (o || 0) <= i && r + (o || 0) >= t && (0 === n()(".s-popover.is-visible, .s-modal[aria-hidden=false]").length ? a.resolve() : a.reject()))
                    };
                    i(), "pending" === a.state() && (n()(document).on("scroll.qSP", i), a.done((function() {
                        n()(document).off("scroll.qSP", i)
                    })))
                },
                htmlEncode: function(e) {
                    return n()("<div/>").text(e).html().replace(/"/g, "&quot;").replace(/'/g, "&#39;")
                },
                showToast: function(e, o) {
                    var a = {
                            dismissable: !0,
                            transient: !0,
                            useRawHtml: !1,
                            transientTimeout: 2e4,
                            type: "info",
                            actions: [],
                            important: !1
                        },
                        i = n().extend({}, a, o);
                    /^(?:info|success|warning|danger)$/.test("" + i.type) || (StackExchange.debug.log(o.type + " is not a valid notice type"), i.type = a.type);
                    var s = n()('<div class="s-toast js-toast js-stacks-managed-popup stacks-v2-start" aria-hidden="true" >  <aside class="s-notice s-anchors" role="status">    <div class="d-flex gs16 gsx ai-center jc-space-between fl-grow1">      <div class="flex--item fl-grow1">        <p class="m0 js-toast-body" id="notice-toast-message"></p>      </div>      <div class="flex--item mr0 js-notice-actions d-none">        <div class="d-flex"></div>      </div>    </div>  </aside></div>').css("top", Math.max(StackExchange.scrollPadding.getPaddingTop(), 20)),
                        r = s.find(".s-notice");
                    r.addClass("s-notice__" + i.type), i.important && r.addClass("s-notice__important"), i.useRawHtml || (e = t.htmlEncode(e)), r.find(".js-toast-body").append(e), i.role && r.attr("role", i.role), i.role && "log" !== i.role || r.attr("aria-live", "polite"), i.dismissable && i.actions.push({
                        labelContents: Svg.ClearSm.With("m0"),
                        ariaLabel: __tr(["Dismiss"], undefined, "en", []),
                        jsClass: "js-dismiss",
                        click: function() {
                            s.fadeOutAndRemove()
                        }
                    }), i.actions.forEach((function(e) {
                        var t = n()('<button class="s-btn s-notice--btn" type="button"></button>');
                        t.append(e.labelContents).on("click", (function(t) {
                            t.preventDefault(), e.click(t)
                        })), e.ariaLabel && t.attr("aria-label", e.ariaLabel), e.jsClass && t.addClass(e.jsClass), s.find(".js-notice-actions").removeClass("d-none").children().append(t)
                    })), n()(".js-toast.js-stacks-managed-popup").fadeOutAndRemove();
                    var c = i.$parent || n()();
                    return 0 == c.length && (c = (i.$source || n()()).closest(".s-modal, body")), 0 == c.length && (c = n()("body")), s.appendTo(c), s.delay(16).queue((function() {
                        n()(this).addClass("js-fades-with-aria-hidden").attr("aria-hidden", "false").dequeue()
                    })), i.transient && s.delay(i.transientTimeout).queue((function() {
                        s.fadeOutAndRemove().dequeue()
                    })), s
                },
                hideToasts: function() {
                    n()(".js-toast.js-stacks-managed-popup").fadeOutAndRemove()
                },
                removeMessages: function(e) {
                    e ? n()(".message").remove() : n()(".message").fadeOutAndRemove()
                },
                addSpinner: function(e, o) {
                    n()(e).append(t.getSpinnerImg(o))
                },
                addStacksSpinner: function(e, t, o) {
                    var a = n()('<div class="s-spinner" role="alert" aria-busy="true" />').addClass(o || "");
                    t && a.addClass("s-spinner__" + t), n()("<div />").css({
                        "font-size": "0px",
                        color: "transparent",
                        float: "left"
                    }).text(__tr(["loading..."], undefined, "en", [])).appendTo(a), n()(e).append(a)
                },
                getSpinnerImg: function(e) {
                    var t = n()("<img />", {
                        class: "ajax-loader",
                        src: "/Content/Img/progress-dots.gif",
                        title: __tr(["loading..."], undefined, "en", []),
                        alt: __tr(["loading..."], undefined, "en", [])
                    });
                    return e && t.css(e), t
                },
                removeSpinner: function() {
                    n()("img.ajax-loader, .s-spinner").remove()
                },
                closePopups: function(e, t) {
                    var o = n().Event("closePopups");
                    o.selectorToClose = e, o.closeTrigger = t || "closePopups", n()(document).trigger(o)
                },
                enableSubmitButton: function(t) {
                    e(t, !1)
                },
                disableSubmitButton: function(t) {
                    e(t, !0)
                },
                loadTicks: function(e) {
                    var t;
                    0 === (t = e ? e.find(".edit-block") : n()(".edit-block")).find("input[name=i1l]").length && (t.data("loading-ticks") || (t.data("loading-ticks", !0), n().ajax({
                        url: "/questions/ticks",
                        cache: !1,
                        success: function(e) {
                            t.append("<input type='hidden' name='i1l' value='" + e + "' />")
                        },
                        complete: function() {
                            t.data("loading-ticks", !1)
                        }
                    })))
                },
                DelayedReaction: function(e, t, n) {
                    var o, a, i = (n = n || {}).always,
                        s = function() {
                            o = null, e.apply(null, a)
                        };
                    return {
                        trigger: function() {
                            if (a = arguments, i && i.apply(null, a), o) {
                                if (!n.sliding) return;
                                clearTimeout(o), o = setTimeout(s, t)
                            } else o = setTimeout(s, t)
                        },
                        cancel: function() {
                            o && (clearTimeout(o), o = null)
                        }
                    }
                },
                fireAndForget: function(e) {
                    n().ajax({
                        type: "POST",
                        url: e,
                        data: {
                            fkey: StackExchange.options.user.fkey
                        },
                        async: !0
                    })
                },
                updateQueryStringParameter: function(e, t, n) {
                    var o = new RegExp("([?&])" + t + "=.*?(&|$)", "i"),
                        a = -1 !== e.indexOf("?") ? "&" : "?";
                    return e.match(o) ? e.replace(o, "$1" + t + "=" + n + "$2") : e + a + t + "=" + n
                },
                parseUrl: function(e) {
                    var t = document.createElement("a");
                    return t.href = e, "" === t.host && (t.href = t.href), t
                },
                isEmailAddress: function(e) {
                    return !("string" != typeof e || e.length < 3) && /^[A-Z0-9._%+'-]+@(?:[A-Z0-9-]+.)+[A-Z]{2,63}$/i.test(e)
                },
                getLikelyErrorMessage: function(e) {
                    if (!e || "string" != typeof e.responseText || e.responseText.length > 250) return "";
                    var t = e.responseText;
                    try {
                        var n = JSON.parse(t);
                        return n.ErrorMessage || n.Message || ""
                    } catch (e) {
                        return t
                    }
                },
                getRejectedMockXhr: function(e) {
                    return n().Deferred().reject({
                        responseText: e
                    })
                },
                submitFormOnEnterPress: function(e) {
                    var t = e.find("textarea, div[contenteditable]");
                    if (!t.is("[contenteditable]") || StackExchange.helpers.hasContentEditable(t)) {
                        var n = !1,
                            o = !1,
                            a = !1;
                        t.on("keyup", (function(i) {
                            if (n || o) o = !1;
                            else if (i.which === d && !i.shiftKey) {
                                if (t.prev("#tabcomplete > li:visible").length) return;
                                if (e.hasClass("js-prevent-submit-form-on-enter-press")) return;
                                if (!a) return;
                                if (e.find('input[type="submit"], button[type="submit"]').prop("disabled")) return;
                                e.trigger("submit")
                            }
                        })).on("keypress", (function(e) {
                            return a = !0, e.which !== d || e.shiftKey
                        })), t.on("compositionstart", (function(e) {
                            n = !0
                        })).on("compositionend", (function(e) {
                            n = !1, o = !0
                        })).on("keydown", (function(e) {
                            229 !== e.which && (o = !1)
                        }))
                    }
                },
                isInNetwork: function(e) {
                    if ("string" != typeof e) throw new TypeError;
                    try {
                        var t = StackExchange.helpers.parseUrl(e.trim()).hostname;
                        if (t === window.location.hostname) return !0;
                        for (var n = ["stackoverflow.com", "stackexchange.com", "serverfault.com", "superuser.com", "stackauth.com", "stackapps.com", "askubuntu.com", "askdifferent.com", "mathoverflow.net", "askpatents.com"], o = 0; o < n.length; o++) {
                            var a = n[o];
                            if (t === a || t.endsWith("." + a)) return !0
                        }
                    } catch (e) {}
                    return !1
                },
                removeParameterFromQueryString: function(e) {
                    if ("undefined" != typeof URLSearchParams) {
                        var t = new URLSearchParams(window.location.search);
                        if (window.history && window.history.replaceState && t.has(e)) {
                            t.delete(e);
                            var n = t.toString(),
                                o = window.location.pathname;
                            n.length > 0 && (o += "?" + n), o += window.location.hash;
                            try {
                                window.history.replaceState({}, document.title, o)
                            } catch (e) {}
                        }
                    }
                },
                placeCaretAtEnd: function(e) {
                    if (e.focus(), void 0 !== window.getSelection && void 0 !== document.createRange) {
                        var t = document.createRange();
                        t.selectNodeContents(e), t.collapse(!1);
                        var n = window.getSelection();
                        n.removeAllRanges(), n.addRange(t)
                    }
                },
                hasContentEditable: function(e) {
                    if (!e) return !1;
                    var t = e instanceof HTMLElement ? e : e instanceof n() ? e[0] : null;
                    return t && "true" === t.contentEditable
                },
                copyTextToClipboard: function(e, t) {
                    var o = n()("<textarea>").css("height", "0").appendTo("body");
                    o.val(e).trigger("select"), document.execCommand("copy"), o.remove();
                    t = t ? ? {
                        type: "success",
                        transientTimeout: 3e3
                    };
                    StackExchange.helpers.showToast(__tr(["Text copied to clipboard."], undefined, "en", []), t)
                },
                encodeHexHtmlEntities: function(e) {
                    return e.replace(/[\u00A0-\u9999<>\&]/g, (function(e) {
                        return "&#x" + e.charCodeAt(0).toString(16).toUpperCase() + ";"
                    }))
                }
            };
            return t
        }(), StackExchange.scrollPadding = (f = 0, h = 0, g = 0, m = !1, v = n()(window), {
            setPaddingTop: function(e, t) {
                var o, a, i, s, r, c, l, d, u;
                f = e + (g = t || 0), h = e, m || (m = !0, function() {
                    var e = n().fn.animate;
                    n().fn.animate = r(e, (function(t) {
                        if ("scrollTop" in t && i(this)) {
                            var o = {};
                            n().extend(o, t), o.scrollTop = parseInt(o.scrollTop, 10) - f, arguments[0] = o
                        }
                        return e.apply(this, arguments)
                    }));
                    var t = n().fn.scrollTop;
                    n().fn.scrollTop = r(t, (function() {
                        if (i(this)) {
                            if (0 === arguments.length) return t.apply(this, arguments) + f;
                            arguments[0] -= f
                        }
                        return t.apply(this, arguments)
                    }));
                    for (var o = document.body.__proto__; o && !o.hasOwnProperty("scrollIntoView");) o = o.__proto__;
                    if (o) {
                        var a = o.scrollIntoView;
                        o.scrollIntoView = r(a, (function(e) {
                            var t = this;
                            if ("contents" === getComputedStyle(t).display && (t = t.children[0] || t), !0 === e || null == e || "smooth" !== e.behavior && "end" !== e.block) {
                                var n = document.body.style.marginTop,
                                    o = parseInt(getComputedStyle(document.body).marginTop, 10);
                                document.body.style.marginTop = o - f + "px";
                                var i = a.apply(t, arguments);
                                return document.body.style.marginTop = n, i
                            }
                            a.apply(t, arguments)
                        }))
                    }

                    function i(e) {
                        var t = e.filter((function(e, t) {
                            return t === window || t === document.body || t === document.body.parentElement
                        }));
                        return e.length > 0 && e.length === t.length
                    }
                    var s = !1;

                    function r(e, t) {
                        return function() {
                            if (s) return e.apply(this, arguments);
                            s = !0;
                            try {
                                return t.apply(this, arguments)
                            } finally {
                                s = !1
                            }
                        }
                    }

                    function c() {
                        var e = n()(":target");
                        if (e.length || (location.hash.length > 1 && /edge|msie|trident/i.test(navigator.userAgent) && (e = n()(document.getElementsByName(location.hash.substr(1))).first()), e.length)) {
                            var t = 1;
                            e.is(":empty") && "inline" === e.css("display") && (t += parseInt(e.next().css("margin-top"), 10));
                            var o = e.offset().top;
                            e.length && Math.abs(v.scrollTop() - o - f) < t && v.scrollTop(o)
                        }
                    }
                    n()("body").on("click", "a", (function() {
                        var e = n()(this).attr("href");
                        e && /#/.test(e) && (v.on("scroll", c), setTimeout((function() {
                            v.off("scroll", c)
                        }), 500))
                    })), v.on("hashchange", c), n()((function() {
                        setTimeout(c, 10), setTimeout(c, 100), setTimeout(c, 1e3)
                    }))
                }(), /^mac/i.test(navigator.platform) && !/firefox/i.test(navigator.userAgent) && (r = performance.now ? performance.now.bind(performance) : Date.now.bind(Date), c = null, l = null, d = !1, u = StackExchange.helpers.DelayedReaction((function() {
                    c = null
                }), 100, {
                    sliding: !0
                }), v.on("keydown", (function(e) {
                    if (e.target === document.body) {
                        var t = e.which;
                        t < 32 || t > 34 ? c = null : (o = c = v.scrollTop(), a = 0, s = 0, d = !1, l = null, i = r(), u.trigger())
                    } else c = null
                })), v.on("scroll", (function(e) {
                    if (null !== c)
                        if (d) v.scrollTop(l);
                        else {
                            var t = r(),
                                n = v.scrollTop(),
                                p = t - i,
                                h = n - o,
                                g = h / p,
                                m = h < 0 ? -1 : 1;
                            null === l && (l = c + m * (v.height() - f - 20));
                            var b = (g - a) / p,
                                x = b + (b - s);
                            if (g * x < 0) {
                                var k = -g / x,
                                    w = l - (n + k * (g + .5 * x * k));
                                Math.abs(w) < 100 && (n + (g + .5 * x * p) * p - l) * m > -20 && (v.scrollTop(l), d = !0)
                            }
                            u.trigger(), o = n, i = t, a = g, s = b
                        }
                }))))
            },
            getPaddingTop: function() {
                return f
            },
            getPaddingTopMinimal: function() {
                return h
            },
            getWindowScrollTopMinimal: function() {
                return v.scrollTop() - g
            },
            ensureInitialized: function() {
                m || StackExchange.scrollPadding.setPaddingTop(0, 0)
            }
        }), StackExchange.responsive = function() {
            var e = n()("html").hasClass("html__responsive"),
                t = 980,
                o = 816;
            if (e) {
                var a = matchMedia("(max-width: " + 640 + "px)"),
                    i = matchMedia("(max-width: " + t + "px)"),
                    s = matchMedia("(max-width: " + o + "px)");
                a.addListener(d), i.addListener(d), s.addListener(d)
            }

            function r() {
                if (!e) return "lg";
                var t = "lg";
                return a.matches ? t = "sm" : (e ? n()("html").hasClass("html__unpinned-leftnav") ? s : i : null).matches && (t = "md"), t
            }
            var c = null,
                l = [];

            function d() {
                var e = c,
                    t = r();
                t !== e && (c = t, l.forEach((function(n) {
                    n(t, e)
                })))
            }

            function u(e) {
                l.push(e)
            }
            var p = [Node.ELEMENT_NODE, Node.TEXT_NODE, Node.COMMENT_NODE];

            function f(e) {
                for (var t = document.querySelectorAll("*[data-can-be][data-is-here-when~='" + e + "']"), n = 0; n < t.length; n++) {
                    var o = t[n],
                        a = o.dataset.canBe,
                        i = document.getElementById(a);
                    if (i) o.childNodes.length && StackExchange.debug.log("can-be target for id " + a + " at size '" + e + "' is not empty"), Array.prototype.slice.call(i.childNodes).forEach((function(e) {
                        p.indexOf(e.nodeType) >= 0 && o.appendChild(e)
                    })), i.removeAttribute("id"), i.dataset.canBe = a, delete o.dataset.canBe, o.id = a;
                    else StackExchange.debug.log("no element with id " + a + " found")
                }
            }
            return u(f), "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", d) : setTimeout(d, 0), {
                addBreakpointListener: u,
                removeBreakpointListener: function(e) {
                    var t = l.indexOf(e);
                    t >= 0 && l.splice(t, 1)
                },
                currentRange: function() {
                    return c || r()
                },
                forceCheck: function() {
                    var e = c;
                    d(), e === c && f(e)
                }
            }
        }(), n().cookie = function(e, t, n) {
            if (void 0 === t) {
                var o = null;
                if (document.cookie && "" !== document.cookie)
                    for (var a = document.cookie.split(";"), i = 0; i < a.length; i++) {
                        var s = a[i].trim();
                        if (s.substring(0, e.length + 1) === e + "=") {
                            o = decodeURIComponent(s.substring(e.length + 1));
                            break
                        }
                    }
                return o
            }
            n = n || {}, null === t && (t = "", n.expires = -1);
            var r = "";
            if (n.expires && ("number" == typeof n.expires || n.expires.toUTCString)) {
                var c;
                if ("number" == typeof n.expires) {
                    c = new Date;
                    var l = 24 * n.expires * 60 * 60 * 1e3;
                    c.setTime(c.getTime() + l)
                } else c = n.expires;
                r = "; expires=" + c.toUTCString()
            }
            var d = n.path ? "; path=" + n.path : "",
                u = n.domain ? "; domain=" + n.domain : "",
                p = n.secure ? "; secure" : "";
            document.cookie = [e, "=", encodeURIComponent(t), r, d, u, p].join("")
        }, n().expr.pseudos.regex = function(e, t, o) {
            var a = o[3].split(","),
                i = /^(data|css):/,
                s = {
                    method: a[0].match(i) ? a[0].split(":")[0] : "attr",
                    property: a.shift().replace(i, "")
                };
            return new RegExp(a.join("").replace(/^\s+|\s+$/g, ""), "ig").test(n()(e)[s.method](s.property))
        }, n().extend(n().expr.pseudos, {
            containsExact: function(e, t, n) {
                return e.innerHTML.trim().toLowerCase() === n[3].toLowerCase()
            },
            containsExactCase: function(e, t, n) {
                return e.innerHTML.trim() === n[3]
            },
            containsRegex: function(e, t, n) {
                var o = /^\/((?:\\\/|[^\/])+)\/([mig]{0,3})$/.exec(n[3]);
                return RegExp(o[1], o[2]).test(e.innerHTML.trim())
            }
        }), (b = n()).fn.typeWatch = function(e) {
            var t = b.extend({
                wait: 750,
                callback: function() {},
                highlight: !0,
                captureLength: 2
            }, e);

            function n(e) {
                if ("TEXT" === e.type.toUpperCase() || "TEXTAREA" === e.nodeName.toUpperCase()) {
                    var n = {
                        timer: null,
                        text: b(e).val().toUpperCase(),
                        cb: t.callback,
                        el: e,
                        wait: t.wait
                    };
                    t.highlight && b(e).on("focus", (function() {
                        this.select()
                    }));
                    var o = function(e) {
                        var o = n.wait,
                            a = !1;
                        e.keyCode === d && "TEXT" === this.type.toUpperCase() && (o = 1, a = !0), clearTimeout(n.timer), n.timer = setTimeout((function() {
                            ! function(e, n) {
                                var o = b(e.el).val();
                                (o.length > t.captureLength && o.toUpperCase() !== e.text || n && o.length > t.captureLength) && (e.text = o.toUpperCase(), e.cb(o))
                            }(n, a)
                        }), o)
                    };
                    b(e).on("keydown", o).on("paste", null, (function(e) {
                        e.which || o(this)
                    })).on("input", null, (function(e) {
                        e.which || o(this)
                    }))
                }
            }
            return this.each((function(e) {
                n(this)
            }))
        }, StackExchange.gps = function() {
            function e(e, t, n, o) {
                t = t || {};
                var a = null;
                StackExchange.options && StackExchange.options.user && (t.user_type = StackExchange.options.user.userType, a = StackExchange.options.user.ab);
                var i = {
                    evt: e,
                    properties: t,
                    now: (new Date).getTime()
                };
                a && (i.ab = a), StackExchange._gps_track.push(i), o && o()
            }
            return StackExchange._gps_track = [], window.location.href.indexOf("utm_") >= 0 && StackExchange.ready((function() {
                if (StackExchange.options && StackExchange.options.utm);
                else {
                    var t = function(e) {
                            var t = new RegExp("[\\?&]utm_" + e + "=([^&#]*)").exec(window.location.href);
                            if (t) return decodeURIComponent(t[1]) || void 0
                        },
                        n = {
                            source: t("source"),
                            medium: t("medium") || "unknown",
                            medium_s: t("medium") || "unknown",
                            campaign: t("campaign"),
                            content: t("content"),
                            term: t("term")
                        };
                    n.source && n.campaign && e("utm.view", n), StackExchange.using("gps", (function() {
                        StackExchange.gps.sendPending()
                    }))
                }
            })), {
                track: e,
                sendPending: function(e) {
                    e && e()
                }
            }
        }()
    })()
})();