(() => {
    var e, t, a, n, o = {
            89621: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.gps = function() {
                    if (StackExchange.gps && StackExchange.gps.inited) return StackExchange.gps;
                    var e = {};

                    function t() {
                        return StackExchange && StackExchange.options && StackExchange.options.site && StackExchange.options.site.routePrefix && StackExchange.options.site.routePrefix.length ? StackExchange.options.site.routePrefix : ""
                    }

                    function a(e, t, a, n) {
                        $(e).find(t).each((function() {
                            var e = $(this).find(a);
                            e.each((function(t) {
                                var a;
                                $(this).addClass("js-gps-track").data("gps-track", "question_tags.click({ " + (a = {
                                    tagName: $(this).text(),
                                    position_in_list: t + 1,
                                    total_number_in_list: e.length,
                                    ...n
                                }, (Object.entries(a).map((([e, t]) => `${e}:${t}`)).join(", ") ? ? "") + " })"))
                            }))
                        }))
                    }

                    function n(e) {
                        l("bindTrackClicks bound {0} elements in {1}", $(e || document).find(".js-gps-track").off("click.gps").one("click.gps", (function() {
                            var e = $(this).data("gps-track") ? .trim();
                            if (e)
                                for (var t = o(e), a = 0; a < t.length; a++) {
                                    var n = t[a];
                                    StackExchange.gps.track(n[0], n[1], !0)
                                }
                        })).length, e || "document")
                    }

                    function o(e) {
                        for (var t = [], a = e.match(/([a-z._-]+)(\([^)]+\))?/gi), n = 0; n < a.length; n++) {
                            var o = a[n];
                            if (o.indexOf("{") < 0) t.push([o, {}]);
                            else {
                                for (var s = o.match(/([a-z._-]+)\s*\(\s*\{([^}]+)\}\s*\)/i) || [], r = s[1], i = (s[2].trim() || "").match(/[^,]+/gi) || [], c = {}, d = 0; d < i.length; d++) {
                                    var l = i[d],
                                        p = l.indexOf(":"),
                                        g = l.substr(0, p).trim(),
                                        f = u(l.substr(p + 1).trim());
                                    c[g] = f
                                }
                                t.push([r, c])
                            }
                        }
                        return t;

                        function u(e) {
                            if ("true" === e) return !0;
                            if ("false" === e) return !1;
                            if ("'" === e[0] || '"' === e[0]) return e.substring(1, e.length - 1);
                            var t = parseFloat(e);
                            return isNaN(t) ? e : t
                        }
                    }

                    function s(a) {
                        var n = function() {
                            var e = i(),
                                t = localStorage[e];
                            return t ? JSON.parse(t) : []
                        }();
                        if (n.length > 0) {
                            for (var o = (new Date).getTime(), s = [], r = 0; r < n.length && s.length < 20; r++) {
                                var c = n[r],
                                    p = o - c.now;
                                p < 0 || p > 36e5 ? d(c) : s.push(c)
                            }
                            s.length > 0 ? function(a, n) {
                                Array.isArray(a) || (a = [a]);
                                for (var o = 0; o < a.length; o++) {
                                    var s = JSON.stringify(a[o]);
                                    e[s] && (a.splice(o, 1), o--)
                                }
                                for (o = 0; o < a.length; o++) {
                                    s = JSON.stringify(a[o]);
                                    e[s] = !0
                                }
                                var r = JSON.stringify(a);
                                if (navigator && navigator.sendBeacon) try {
                                    l("sending (beacon): " + r);
                                    var i = t() + "/gps/event";
                                    if (navigator && navigator.sendBeacon(i, r)) {
                                        for (o = 0; o < a.length; o++) {
                                            d(a[o]);
                                            s = JSON.stringify(a[o]);
                                            delete e[s]
                                        }
                                        return void(n && n())
                                    }
                                } catch (e) {
                                    l(e)
                                }
                                l("sending (AJAX): " + r), $.ajax({
                                    type: "POST",
                                    url: "/gps/event",
                                    data: {
                                        data: r
                                    },
                                    success: function(e, t, n) {
                                        for (var o = 0; o < a.length; o++) d(a[o])
                                    },
                                    complete: function() {
                                        for (var t = 0; t < a.length; t++) {
                                            var o = JSON.stringify(a[t]);
                                            delete e[o]
                                        }
                                        n && n()
                                    }
                                })
                            }(s, a) : a && a()
                        }
                    }

                    function r(e, t, a, n) {
                        c({
                            evt: e,
                            properties: t || {},
                            now: (new Date).getTime()
                        }), navigator && navigator.sendBeacon && (a = !1), a ? (n && n(), window.setTimeout(s, 1e4)) : s(n)
                    }

                    function i() {
                        return "gps-pending" + t()
                    }

                    function c(e) {
                        var t;
                        (t = e) && StackExchange.options && StackExchange.options.user && (t.properties && !t.properties.user_type && (t.properties.user_type = StackExchange.options.user.user_type), !t.ab && StackExchange.options.user.ab && (t.ab = StackExchange.options.user.ab));
                        var a, n = i(),
                            o = localStorage[n];
                        if (o) {
                            var s = JSON.parse(o);
                            s.push(e), a = JSON.stringify(s)
                        } else a = JSON.stringify([e]);
                        l("addToPending " + JSON.stringify(e)), localStorage[n] = a
                    }

                    function d(e) {
                        var t = i(),
                            a = localStorage[t];
                        if (a) {
                            for (var n = JSON.parse(a), o = JSON.stringify(e), s = -1, r = 0; r < n.length; r++) {
                                if (o == JSON.stringify(n[r])) {
                                    s = r;
                                    break
                                }
                            } - 1 != s && (n.splice(s, 1), 0 != n.length ? localStorage[t] = JSON.stringify(n) : localStorage.removeItem(t))
                        }
                    }

                    function l(e) {
                        if ((StackExchange.options && StackExchange.options.enableLogging || $.cookie("devlog")) && "string" == typeof e) {
                            if (arguments.length > 1) {
                                var t = Array.prototype.slice.call(arguments, 1);
                                e = String.prototype.formatUnicorn.apply(e, t)
                            }
                            console.log("gps: " + e)
                        }
                    }
                    return {
                        inited: !1,
                        init: function(e) {
                            return !!StackExchange.gps.inited || (StackExchange.gps.inited = !0, e && function() {
                                try {
                                    if (!window.localStorage) return !1;
                                    if (window.localStorage["gps-probe"] = "1", "1" != window.localStorage["gps-probe"]) return !1;
                                    window.localStorage.removeItem("gps-probe")
                                } catch (e) {
                                    return !1
                                }
                                return !0
                            }() ? (StackExchange.gps.sendPending = s, StackExchange.gps.track = r, StackExchange._gps_track && ($.each(StackExchange._gps_track, (function(e, t) {
                                c(t)
                            })), delete StackExchange._gps_track), s(), t = ".js-gps-related-tags .post-tag", o = "related_tags.click", i = ", item_type:1", $(".tagged-questions-page, .questions-page, .tags-page").find(t).each((function(e) {
                                $(this).addClass("js-gps-track").data("gps-track", o + "({ position:" + (e + 1) + i + " })")
                            })), a(".home-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 1,
                                location_on_page: 1
                            }), a(".home-page", "#recent-tags-list", ".post-tag", {
                                page: 1,
                                location_on_page: 2
                            }), a(".home-page", "#watched-tags-list", ".s-tag", {
                                page: 1,
                                location_on_page: 9
                            }), a(".questions-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 2,
                                location_on_page: 1
                            }), a(".questions-page", ".js-gps-related-tags", ".post-tag", {
                                page: 2,
                                location_on_page: 2
                            }), a(".question-page", ".post-taglist .js-post-tag-list-wrapper", ".post-tag", {
                                page: 3,
                                location_on_page: 3
                            }), a(".question-page", ".js-bottom-notice .js-post-tag-list-wrapper", ".post-tag", {
                                page: 3,
                                location_on_page: 4
                            }), a(".tags-page", "#tags_list", ".post-tag", {
                                page: 4,
                                location_on_page: 5
                            }), a(".tagged-questions-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 5,
                                location_on_page: 1
                            }), a(".tagged-questions-page", ".js-gps-related-tags", ".post-tag", {
                                page: 5,
                                location_on_page: 2
                            }), a(".tagged-questions-page", ".js-watched-tag-list", ".post-tag", {
                                page: 5,
                                location_on_page: 7
                            }), a(".tagged-questions-page", ".js-ignored-tag-list", ".post-tag", {
                                page: 5,
                                location_on_page: 8
                            }), n(), !0) : (StackExchange.gps.track = function(e, t, a, n) {
                                n && n()
                            }, delete StackExchange._gps_track, !1));
                            var t, o, i
                        },
                        bindTrackClicks: n,
                        track: StackExchange.gps.track,
                        sendPending: StackExchange.gps.sendPending,
                        trackOutboundClicks: function(e, t) {
                            $(e).on("click", t + " a[href]:not(.question-hyperlink, .answer-hyperlink)", (function() {
                                var e = $(this).attr("href");
                                StackExchange.helpers.isInNetwork(e) || ("undefined" == typeof ga ? l("outbound link clicked " + e) : ga("send", "event", "outbound", "click", e, {
                                    useBeacon: !0
                                }))
                            }))
                        },
                        parseTrackData: o
                    }
                }()
            },
            48781: () => {
                var e;
                e = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e) {
                        ! function(t) {
                            t.showConfirmModal = function(a) {
                                var n = $('\n<aside class="s-modal" role="dialog" aria-labelledby="confirm-modal-title" aria-describedby="confirm-modal-body" aria-hidden="true">\n    <div class="s-modal--dialog ps-relative" data-controller="se-draggable" role="document">\n        <h1 class="s-modal--header fw-bold" id="confirm-modal-title" data-se-draggable-target="handle"></h1>\n        <div class="s-modal--body fs-body2" id="confirm-modal-body"></div>\n        <div class="d-flex gs8 gsx s-modal--footer">\n            <button class="flex--item s-btn js-ok-button s-btn__filled" type="button"></button>\n            <button class="flex--item s-btn js-cancel-button js-modal-close js-modal-initial-focus" type="button"></button>\n        </div>\n    </div>\n</aside>\n');
                                const o = (e, t, a) => {
                                    const o = n.find(e);
                                    t ? o.append(t) : a && o.text(a)
                                };
                                return o("#confirm-modal-title", a.titleHtml, a.title), o("#confirm-modal-body", a.bodyHtml, a.body), o(".js-ok-button", a.buttonLabelHtml, a.buttonLabel || __tr(["OK"], undefined, "en", [])), o(".js-cancel-button", void 0, __tr(["Cancel"], undefined, "en", [])), new Promise(((o, s) => {
                                    t.showModal(n, a), n.find(".js-ok-button").on("click", (t => {
                                        t.preventDefault(), o(!0), e.helpers.closePopups(n, "dismiss")
                                    })), n.on("popupClose", (e => o(!1)))
                                }))
                            }
                        }(e.helpers || (e.helpers = {}))
                    }(e || (e = {}))
            },
            53536: (e, t, a) => {
                var n = {
                    "./datepicker-af.js": [60242, 3431, 7334],
                    "./datepicker-ar-DZ.js": [22045, 3431, 9167],
                    "./datepicker-ar.js": [75214, 3431, 9314],
                    "./datepicker-az.js": [72230, 3431, 9754],
                    "./datepicker-be.js": [45856, 3431, 8952],
                    "./datepicker-bg.js": [76650, 3431, 2590],
                    "./datepicker-bs.js": [23334, 3431, 5850],
                    "./datepicker-ca.js": [60677, 3431, 8631],
                    "./datepicker-cs.js": [84115, 3431, 561],
                    "./datepicker-cy-GB.js": [66459, 3431, 9177],
                    "./datepicker-da.js": [71302, 3431, 4714],
                    "./datepicker-de-AT.js": [62706, 3431, 1942],
                    "./datepicker-de.js": [15546, 3431, 7438],
                    "./datepicker-el.js": [4372, 3431, 2844],
                    "./datepicker-en-AU.js": [1773, 3431, 4527],
                    "./datepicker-en-GB.js": [31166, 3431, 8210],
                    "./datepicker-en-NZ.js": [88087, 3431, 6261],
                    "./datepicker-eo.js": [16221, 3431, 6255],
                    "./datepicker-es.js": [38985, 3431, 8155],
                    "./datepicker-et.js": [48508, 3431, 7028],
                    "./datepicker-eu.js": [3971, 3431, 6737],
                    "./datepicker-fa.js": [14136, 3431, 9168],
                    "./datepicker-fi.js": [94832, 3431, 7624],
                    "./datepicker-fo.js": [41830, 3431, 7658],
                    "./datepicker-fr-CA.js": [91766, 3431, 2106],
                    "./datepicker-fr-CH.js": [43773, 3431, 6559],
                    "./datepicker-fr.js": [81121, 3431, 7731],
                    "./datepicker-gl.js": [83702, 3431, 3450],
                    "./datepicker-he.js": [58222, 3431, 9218],
                    "./datepicker-hi.js": [5370, 3431, 8478],
                    "./datepicker-hr.js": [26751, 3431, 1213],
                    "./datepicker-hu.js": [27742, 3431, 6194],
                    "./datepicker-hy.js": [59082, 3431, 6158],
                    "./datepicker-id.js": [65376, 3431, 968],
                    "./datepicker-is.js": [96357, 3431, 8551],
                    "./datepicker-it-CH.js": [34858, 3431, 4158],
                    "./datepicker-it.js": [95856, 3431, 6456],
                    "./datepicker-ja.js": [13828, 3431, 1772],
                    "./datepicker-ka.js": [41885, 3431, 1231],
                    "./datepicker-kk.js": [43699, 3431, 8321],
                    "./datepicker-km.js": [78969, 3431, 2987],
                    "./datepicker-ko.js": [48407, 3431, 5429],
                    "./datepicker-ky.js": [3909, 3431, 39],
                    "./datepicker-lb.js": [987, 3431, 2009],
                    "./datepicker-lt.js": [77873, 3431, 9827],
                    "./datepicker-lv.js": [7471, 3431, 7757],
                    "./datepicker-mk.js": [98889, 3431, 1131],
                    "./datepicker-ml.js": [7900, 3431, 7908],
                    "./datepicker-ms.js": [52225, 3431, 5539],
                    "./datepicker-nb.js": [33641, 3431, 4091],
                    "./datepicker-nl-BE.js": [61285, 3431, 9495],
                    "./datepicker-nl.js": [23595, 3431, 7702],
                    "./datepicker-nn.js": [99981, 3431, 8239],
                    "./datepicker-no.js": [73966, 3431, 4066],
                    "./datepicker-pl.js": [44141, 3431, 6671],
                    "./datepicker-pt-BR.js": [42366, 3431, 2978],
                    "./datepicker-pt.js": [37109, 3431, 8228],
                    "./datepicker-rm.js": [5880, 3431, 7712],
                    "./datepicker-ro.js": [94338, 3431, 4646],
                    "./datepicker-ru.js": [32800, 3431, 5304],
                    "./datepicker-sk.js": [79899, 3431, 4889],
                    "./datepicker-sl.js": [58162, 3431, 2390],
                    "./datepicker-sq.js": [40517, 3431, 9831],
                    "./datepicker-sr-SR.js": [84964, 3431, 7356],
                    "./datepicker-sr.js": [33564, 3431, 503],
                    "./datepicker-sv.js": [74192, 3431, 2552],
                    "./datepicker-ta.js": [81558, 3431, 3274],
                    "./datepicker-th.js": [49917, 3431, 7727],
                    "./datepicker-tj.js": [86011, 3431, 4329],
                    "./datepicker-tr.js": [21315, 3431, 5553],
                    "./datepicker-uk.js": [49393, 3431, 9203],
                    "./datepicker-vi.js": [78208, 3431, 280],
                    "./datepicker-zh-CN.js": [19349, 3431, 5047],
                    "./datepicker-zh-HK.js": [25593, 3431, 5019],
                    "./datepicker-zh-TW.js": [86449, 3431, 5155]
                };

                function o(e) {
                    if (!a.o(n, e)) return Promise.resolve().then((() => {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = n[e],
                        o = t[0];
                    return Promise.all(t.slice(1).map(a.e)).then((() => a.t(o, 23)))
                }
                o.keys = () => Object.keys(n), o.id = 53536, e.exports = o
            },
            20428: e => {
                "use strict";
                e.exports = window.jQuery
            }
        },
        s = {};

    function r(e) {
        var t = s[e];
        if (void 0 !== t) return t.exports;
        var a = s[e] = {
            exports: {}
        };
        return o[e](a, a.exports, r), a.exports
    }
    r.m = o, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, r.t = function(a, n) {
        if (1 & n && (a = this(a)), 8 & n) return a;
        if ("object" == typeof a && a) {
            if (4 & n && a.__esModule) return a;
            if (16 & n && "function" == typeof a.then) return a
        }
        var o = Object.create(null);
        r.r(o);
        var s = {};
        e = e || [null, t({}), t([]), t(t)];
        for (var i = 2 & n && a;
            "object" == typeof i && !~e.indexOf(i); i = t(i)) Object.getOwnPropertyNames(i).forEach((e => s[e] = () => a[e]));
        return s.default = () => a, r.d(o, s), o
    }, r.d = (e, t) => {
        for (var a in t) r.o(t, a) && !r.o(e, a) && Object.defineProperty(e, a, {
            enumerable: !0,
            get: t[a]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce(((t, a) => (r.f[a](e, t), t)), [])), r.u = e => 3431 === e ? "webpack-chunks/3431.en.js" : "webpack-chunks/" + e + "." + {
        39: "0c327b2a4933649c046f",
        280: "78aa2de8c7354dc19f59",
        503: "d64ce9cb0e1713a97fa0",
        561: "5d0534ecefc1507a56ed",
        968: "5e07d1c4e2181dba23cf",
        1131: "1ac785798c33d445a662",
        1213: "a2ab798ed57291783dac",
        1231: "3a50f67686b31fc42c00",
        1772: "4cad33a1785c14f9a3f8",
        1942: "07c0507f73de5c49faab",
        2009: "ab8906781c9641e430f1",
        2106: "f57196f852a2f5fe8564",
        2390: "91d1fc1f591e852502ad",
        2552: "186e91acc01b74603da0",
        2590: "68290cd8d9bf295c44ac",
        2844: "109973b801f6ff8752ed",
        2978: "b3cb5b00813c7361dcf2",
        2987: "31ffa97bd6b596c9dfe3",
        3274: "f7fd16701248cd3d33fd",
        3450: "1eabc856027e72122a22",
        4066: "2c769aa805d195aaec5b",
        4091: "c6daef6e602f996c0bd3",
        4158: "e231bf4644002ecad221",
        4329: "ef75e680701ad98fc0ca",
        4527: "e8a2a8cd61693351582f",
        4646: "82d21bd7b183cdeb5eeb",
        4714: "a9bc14522e19a4030f31",
        4889: "6064f61c508728f860b4",
        5019: "aadd414ab46b6aa8a9ba",
        5047: "73bf2547156e955eed1d",
        5155: "8929efe69bf21677f6d0",
        5304: "159e929c07ef4e1ebd6e",
        5429: "7397817c795d018d5518",
        5539: "eacd9e0d87d445b94a48",
        5553: "6e0b77f1d4267a1d2b02",
        5850: "44d46a18a41f664670c0",
        6158: "ee3f7ff34c5f4af26d74",
        6194: "726078b69c57150105b4",
        6255: "53461cbdbd4563dce184",
        6261: "d7809c75407908e2bd1e",
        6456: "a0e4e8c639b99fe6d1c1",
        6559: "68b1db9ba257d2dc2bef",
        6671: "6055abe67ec3cac19fc6",
        6737: "914fdaf157147acbae26",
        6883: "fa2b954cf29aa505c136",
        7028: "b7ec91fc61f47e301390",
        7334: "0a1297a871633e0bc52c",
        7356: "581d3b59c4106e99cbf4",
        7438: "4f1949cf0291279dc92f",
        7624: "260c52f6459c3cb9a0af",
        7658: "02e00dd8274b7ca7361f",
        7702: "b53d89d820b40f1b57e5",
        7712: "dfdc4d6ad42ee4bbc8b3",
        7727: "ca5d2c1f92acee0993e6",
        7731: "fc571ef82b17c18d772e",
        7757: "15ab0517852b07044871",
        7908: "7579a1e2dad366811297",
        8155: "0c88c373cd037b2cd1b9",
        8210: "c249e93165dbb518fa58",
        8228: "0ef292c6c07b0b03cc3a",
        8239: "0b62eb96110b44b4d34b",
        8321: "4a304adc6b166c75f6b8",
        8478: "1562eba353e358405709",
        8551: "5037a8be9386358ab941",
        8631: "6796827941bd0634a167",
        8952: "f1f8118c003bd9631032",
        9167: "83584f57bbc43cd4f8bf",
        9168: "f0c0a0da5ec398cd73f3",
        9177: "9f3388250bfe030c2379",
        9203: "87f7098190310b8a6707",
        9218: "c925b7a39a4299fdda5c",
        9314: "34b8f0b382c8eec48309",
        9495: "876a79736eb7223a79e3",
        9754: "56c73e2643f19f438688",
        9827: "28d65e6c88a4f3f023e0",
        9831: "2dd08ae9fc8c832d8b44"
    }[e] + ".en.js", r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), a = {}, n = "stackoverflow:", r.l = (e, t, o, s) => {
        if (a[e]) a[e].push(t);
        else {
            var i, c;
            if (void 0 !== o)
                for (var d = document.getElementsByTagName("script"), l = 0; l < d.length; l++) {
                    var p = d[l];
                    if (p.getAttribute("src") == e || p.getAttribute("data-webpack") == n + o) {
                        i = p;
                        break
                    }
                }
            i || (c = !0, (i = document.createElement("script")).charset = "utf-8", i.timeout = 120, r.nc && i.setAttribute("nonce", r.nc), i.setAttribute("data-webpack", n + o), i.src = e), a[e] = [t];
            var g = (t, n) => {
                    i.onerror = i.onload = null, clearTimeout(f);
                    var o = a[e];
                    if (delete a[e], i.parentNode && i.parentNode.removeChild(i), o && o.forEach((e => e(n))), t) return t(n)
                },
                f = setTimeout(g.bind(null, void 0, {
                    type: "timeout",
                    target: i
                }), 12e4);
            i.onerror = g.bind(null, i.onerror), i.onload = g.bind(null, i.onload), c && document.head.appendChild(i)
        }
    }, r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.p = "", (() => {
        var e = {
            382: 0
        };
        r.f.j = (t, a) => {
            var n = r.o(e, t) ? e[t] : void 0;
            if (0 !== n)
                if (n) a.push(n[2]);
                else {
                    var o = new Promise(((a, o) => n = e[t] = [a, o]));
                    a.push(n[2] = o);
                    var s = r.p + r.u(t),
                        i = new Error;
                    r.l(s, (a => {
                        if (r.o(e, t) && (0 !== (n = e[t]) && (e[t] = void 0), n)) {
                            var o = a && ("load" === a.type ? "missing" : a.type),
                                s = a && a.target && a.target.src;
                            i.message = "Loading chunk " + t + " failed.\n(" + o + ": " + s + ")", i.name = "ChunkLoadError", i.type = o, i.request = s, n[1](i)
                        }
                    }), "chunk-" + t, t)
                }
        };
        var t = (t, a) => {
                var n, o, [s, i, c] = a,
                    d = 0;
                if (s.some((t => 0 !== e[t]))) {
                    for (n in i) r.o(i, n) && (r.m[n] = i[n]);
                    if (c) c(r)
                }
                for (t && t(a); d < s.length; d++) o = s[d], r.o(e, o) && e[o] && e[o][0](), e[o] = 0
            },
            a = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        a.forEach(t.bind(null, 0)), a.push = t.bind(null, a.push.bind(a))
    })(), (() => {
        "use strict";
        r.p = document.getElementById("webpack-public-path").innerText + "Js/"
    })(), (() => {
        "use strict";

        function e(e) {
            return (...t) => e()(...t)
        }
        e((() => StackExchange.helpers.addSpinner)), e((() => StackExchange.helpers.addStacksSpinner)), e((() => StackExchange.helpers.addLightbox)), e((() => StackExchange.helpers.getLikelyErrorMessage)), e((() => StackExchange.helpers.getRejectedMockXhr)), e((() => StackExchange.helpers.getSpinnerImg)), e((() => StackExchange.helpers.removeMessages)), e((() => StackExchange.helpers.removeSpinner)), e((() => StackExchange.helpers.showErrorMessage)), e((() => StackExchange.helpers.showInfoMessage)), e((() => StackExchange.helpers.showMessage)), e((() => StackExchange.helpers.showSuccessMessage)), e((() => StackExchange.helpers.showModal)), e((() => StackExchange.helpers.loadModal));
        const t = e((() => StackExchange.helpers.showToast)),
            a = (e((() => StackExchange.helpers.hideToasts)), e((() => StackExchange.helpers.suggestedTransientTimeout)), e((() => StackExchange.helpers.toggleStacksPopover)), e((() => StackExchange.helpers.queueStacksPopover)), e((() => StackExchange.helpers.submitFormOnEnterPress)), e((() => StackExchange.helpers.updateQueryStringParameter)), e((() => StackExchange.helpers.DelayedReaction)), e((() => StackExchange.helpers.closePopups)), e((() => StackExchange.helpers.showStacksNotice)), e((() => StackExchange.helpers.removeParameterFromQueryString)), e((() => StackExchange.helpers.enableSubmitButton)), e((() => StackExchange.helpers.disableSubmitButton)), e((() => StackExchange.helpers.loadTicks)), e((() => StackExchange.helpers.encodeHexHtmlEntities)), e((() => StackExchange.helpers.bindOnHashChange_HighlightDestination)), e((() => StackExchange.helpers.MagicPopup)), e((() => StackExchange.helpers.copyTextToClipboard)), e((() => StackExchange.helpers.noDiacritics)), e((() => StackExchange.helpers.tagSeparator)), e((() => StackExchange.helpers.sanitizeAndSplitTags)), new Promise((e => {
                "undefined" != typeof window ? StackExchange.ready(e) : e()
            })));
        r(48781);
        const n = StackExchange.helpers.showConfirmModal;
        async function o(e) {
            let a = Number($(e.target).attr("data-post-id")),
                o = "True" === $(e.target).attr("data-mark-obsolete") || "true" === $(e.target).attr("data-mark-obsolete");
            await
            function(e, a) {
                let o = {
                    title: a ? "Mark this post as obsolete?" : "Remove obsolete status?",
                    body: a ? "Marking a post as obsolete means that it is out of date, but should be kept for historical context." : "You can reopen questions or articles that should no longer be marked as obsolete.",
                    buttonLabel: a ? "Yes, mark obsolete" : "Yes, remove"
                };
                return n(o).then((async n => {
                    n && await async function(e, a) {
                        let n = `/posts/mark-obsolete/toggle/${e}`,
                            o = await $.post(n, {
                                fkey: StackExchange.options.user.fkey,
                                markObsolete: a
                            }).promise();
                        o.success ? window.location.reload() : o.message && t(o.message, {
                            type: "danger"
                        })
                    }(e, a)
                }))
            }(a, o)
        }

        function s(e) {
            const t = function(e) {
                const t = function(e) {
                    const t = e.replace(/\.(t|j)sx?/, ""),
                        a = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                    return document.querySelectorAll(a)
                }(e);
                return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
            }(e);
            return function(e, t) {
                    if (0 === e.length) throw `Couldn't find args for module "${t}". Did you forget to call @JavaScriptHelper.Args?`
                }(t, e),
                function(e, t) {
                    if (e.length > 1) throw `Found too many instances of args for module "${t}". Did you call @JavaScriptHelper.Args too many times?`
                }(t, e), t[0]
        }
        class i {
            constructor(e, t = 1e3, a = void 0) {
                this.intervalId = 0, this.maxRuntimeMilliseconds = e, this.remainingRuntimeMilliseconds = e, this.intervalMilliseconds = t, this.onTimerEnds = a
            }
            updateTimer() {
                this.remainingRuntimeMilliseconds -= this.intervalMilliseconds, this.remainingRuntimeMilliseconds <= 0 && this.endTimer()
            }
            start() {
                this.intervalId > 0 && clearInterval(this.intervalId), this.intervalId = window.setInterval((() => this.updateTimer()), this.intervalMilliseconds)
            }
            stop() {
                clearInterval(this.intervalId), this.intervalId = 0
            }
            endTimer() {
                this.stop(), this.onTimerEnds && this.onTimerEnds()
            }
            getElapsedTime() {
                return this.maxRuntimeMilliseconds - this.remainingRuntimeMilliseconds
            }
        }
        var c, d, l = !1;

        function p() {
            if (!l) {
                l = !0;
                var e = {
                    questionId: c.questionId,
                    durationMilliseconds: d.getElapsedTime()
                };
                e.durationMilliseconds > 1e3 && StackExchange.using("gps", (function() {
                    StackExchange.gps.track("related_questions.page_visit_length", e)
                }))
            }
        }

        function g(e) {
            const t = (c = e).intervalMilliseconds ? c.intervalMilliseconds : 1e3;
            d = new i(c.maxRuntimeMilliseconds, t, p), window.onload = () => d.start(), window.onfocus = () => d.start(), window.onblur = () => d.stop(), window.onbeforeunload = () => d.endTimer()
        }

        function f(e, t, a = void 0, n = void 0) {
            const o = new FormData;
            o.append("fKey", null != n ? n : StackExchange.options.user.fkey), o.append("data", JSON.stringify(t)), o.append("event", e);
            let s = {};
            a && (s["X-Previous-Event-Id"] = a), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                method: "POST",
                keepalive: !0,
                body: o,
                headers: s
            }).then((() => {}))
        }
        r(89621);

        function u(...e) {
            return StackExchange.gps.track(...e)
        }
        const h = (e, t, a, n, o) => {
                let s = !1,
                    r = !1,
                    i = !1;
                const c = {
                    stacksEditorEnabled: o,
                    questionId: n
                };
                e.addEventListener("input", (function(n) {
                    r || (t && f("questions_show.answer_editor_typed_one_character", {
                        source: window.location.href,
                        ...c
                    }), a && u("questions_show.answer_editor_typed_one_character", {
                        props: c
                    }), r = !0), !i && e.textLength >= 5 && (t && f("questions_show.answer_editor_typed_multiple_characters", {
                        source: window.location.href,
                        ...c
                    }), a && u("questions_show.answer_editor_typed_multiple_characters", {
                        props: c
                    }), i = !0)
                })), e.addEventListener("focus", (function() {
                    s || (t && f("questions_show.answer_editor_focus", {
                        source: window.location.href,
                        ...c
                    }), a && u("questions_show.answer_editor_focus", {
                        props: c
                    }), s = !0)
                })), e.addEventListener("paste", (function(e) {
                    t && f("questions_show.answer_editor_paste", {
                        source: window.location.href,
                        ...c
                    }), a && u("questions_show.answer_editor_paste", {
                        props: c
                    })
                }))
            },
            k = (e, t, a, n) => {
                e.addEventListener("StacksEditor:view-change", (function(e) {
                    const o = {
                        stacksEditorMode: e.detail.editorType,
                        previewShown: e.detail.previewShown,
                        questionId: n,
                        stacksEditorEnabled: !0
                    };
                    t && f("questions_show.answer_editor_view_changed", {
                        source: window.location.href,
                        ...o
                    }), a && u("questions_show.answer_editor_view_changed", o)
                }))
            },
            b = () => {
                var e;
                null === (e = document.querySelector("#join-the-conversation-bar button")) || void 0 === e || e.addEventListener("click", (() => {
                    (() => {
                        var e;
                        const t = document.querySelector("#post-form");
                        if (!t) return;
                        const a = t.querySelector(".js-post-body-field[data-post-type-id='2']");
                        if (!a) return;
                        t.classList.remove("d-none"), t.scrollIntoView();
                        const n = a.parentElement.querySelector("#js-stacks-editor-container");
                        null === (e = StackExchange.stacksEditor.getInstanceFromElement(n)) || void 0 === e || e.focus()
                    })()
                }))
            };
        a.then((() => {
            const e = s("entry-points/questions/show.mod.ts");
            e.doMarkObsolete && $(".js-mark-obsolete-button").on("click", o), e.doTimeOnPage && g(e.timeOnPageArgs), $("#join-the-conversation-bar button").on("click", (function() {
                f("join_conversation.click", {
                    source: window.location.href
                })
            })), b(), ((e, t, a, n, o, s) => {
                const r = {
                    postId: e,
                    answerCount: n,
                    followUpsUIExperimentGroup: o,
                    tags: s
                };
                a && u("question.visit.authenticated", r), t && f("question.visit.authenticated", {
                    source: window.location.href,
                    ...r
                })
            })(e.questionId, e.sendAuthQuestionVisitToAEH, e.sendAuthQuestionVisitToPrizm, e.answerCount, e.followUpsUIExperimentGroup, e.tags), ((e, t, a) => {
                if (!e && !t) return;
                const n = document.querySelector("#post-form .js-post-body-field[data-post-type-id='2']");
                if (!n) return;
                const o = n.parentElement.querySelector("#js-stacks-editor-container");
                h(n, e, t, a, !!o), o && k(o, e, t, a)
            })(e.sendAnswerEditorEventsToAEH, e.sendAnswerEditorEventsToPrizm, e.questionId)
        }))
    })()
})();