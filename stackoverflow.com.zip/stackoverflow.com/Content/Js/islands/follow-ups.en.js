(() => {
    var e, a, t, c, r, s = {
            53536: (e, a, t) => {
                var c = {
                    "./datepicker-af.js": [60242, 3431, 7334],
                    "./datepicker-ar-DZ.js": [22045, 3431, 9167],
                    "./datepicker-ar.js": [75214, 3431, 9314],
                    "./datepicker-az.js": [72230, 3431, 9754],
                    "./datepicker-be.js": [45856, 3431, 8952],
                    "./datepicker-bg.js": [76650, 3431, 2590],
                    "./datepicker-bs.js": [23334, 3431, 5850],
                    "./datepicker-ca.js": [60677, 3431, 8631],
                    "./datepicker-cs.js": [84115, 3431, 561],
                    "./datepicker-cy-GB.js": [66459, 3431, 9177],
                    "./datepicker-da.js": [71302, 3431, 4714],
                    "./datepicker-de-AT.js": [62706, 3431, 1942],
                    "./datepicker-de.js": [15546, 3431, 7438],
                    "./datepicker-el.js": [4372, 3431, 2844],
                    "./datepicker-en-AU.js": [1773, 3431, 4527],
                    "./datepicker-en-GB.js": [31166, 3431, 8210],
                    "./datepicker-en-NZ.js": [88087, 3431, 6261],
                    "./datepicker-eo.js": [16221, 3431, 6255],
                    "./datepicker-es.js": [38985, 3431, 8155],
                    "./datepicker-et.js": [48508, 3431, 7028],
                    "./datepicker-eu.js": [3971, 3431, 6737],
                    "./datepicker-fa.js": [14136, 3431, 9168],
                    "./datepicker-fi.js": [94832, 3431, 7624],
                    "./datepicker-fo.js": [41830, 3431, 7658],
                    "./datepicker-fr-CA.js": [91766, 3431, 2106],
                    "./datepicker-fr-CH.js": [43773, 3431, 6559],
                    "./datepicker-fr.js": [81121, 3431, 7731],
                    "./datepicker-gl.js": [83702, 3431, 3450],
                    "./datepicker-he.js": [58222, 3431, 9218],
                    "./datepicker-hi.js": [5370, 3431, 8478],
                    "./datepicker-hr.js": [26751, 3431, 1213],
                    "./datepicker-hu.js": [27742, 3431, 6194],
                    "./datepicker-hy.js": [59082, 3431, 6158],
                    "./datepicker-id.js": [65376, 3431, 968],
                    "./datepicker-is.js": [96357, 3431, 8551],
                    "./datepicker-it-CH.js": [34858, 3431, 4158],
                    "./datepicker-it.js": [95856, 3431, 6456],
                    "./datepicker-ja.js": [13828, 3431, 1772],
                    "./datepicker-ka.js": [41885, 3431, 1231],
                    "./datepicker-kk.js": [43699, 3431, 8321],
                    "./datepicker-km.js": [78969, 3431, 2987],
                    "./datepicker-ko.js": [48407, 3431, 5429],
                    "./datepicker-ky.js": [3909, 3431, 39],
                    "./datepicker-lb.js": [987, 3431, 2009],
                    "./datepicker-lt.js": [77873, 3431, 9827],
                    "./datepicker-lv.js": [7471, 3431, 7757],
                    "./datepicker-mk.js": [98889, 3431, 1131],
                    "./datepicker-ml.js": [7900, 3431, 7908],
                    "./datepicker-ms.js": [52225, 3431, 5539],
                    "./datepicker-nb.js": [33641, 3431, 4091],
                    "./datepicker-nl-BE.js": [61285, 3431, 9495],
                    "./datepicker-nl.js": [23595, 3431, 7702],
                    "./datepicker-nn.js": [99981, 3431, 8239],
                    "./datepicker-no.js": [73966, 3431, 4066],
                    "./datepicker-pl.js": [44141, 3431, 6671],
                    "./datepicker-pt-BR.js": [42366, 3431, 2978],
                    "./datepicker-pt.js": [37109, 3431, 8228],
                    "./datepicker-rm.js": [5880, 3431, 7712],
                    "./datepicker-ro.js": [94338, 3431, 4646],
                    "./datepicker-ru.js": [32800, 3431, 5304],
                    "./datepicker-sk.js": [79899, 3431, 4889],
                    "./datepicker-sl.js": [58162, 3431, 2390],
                    "./datepicker-sq.js": [40517, 3431, 9831],
                    "./datepicker-sr-SR.js": [84964, 3431, 7356],
                    "./datepicker-sr.js": [33564, 3431, 503],
                    "./datepicker-sv.js": [74192, 3431, 2552],
                    "./datepicker-ta.js": [81558, 3431, 3274],
                    "./datepicker-th.js": [49917, 3431, 7727],
                    "./datepicker-tj.js": [86011, 3431, 4329],
                    "./datepicker-tr.js": [21315, 3431, 5553],
                    "./datepicker-uk.js": [49393, 3431, 9203],
                    "./datepicker-vi.js": [78208, 3431, 280],
                    "./datepicker-zh-CN.js": [19349, 3431, 5047],
                    "./datepicker-zh-HK.js": [25593, 3431, 5019],
                    "./datepicker-zh-TW.js": [86449, 3431, 5155]
                };

                function r(e) {
                    if (!t.o(c, e)) return Promise.resolve().then((() => {
                        var a = new Error("Cannot find module '" + e + "'");
                        throw a.code = "MODULE_NOT_FOUND", a
                    }));
                    var a = c[e],
                        r = a[0];
                    return Promise.all(a.slice(1).map(t.e)).then((() => t.t(r, 23)))
                }
                r.keys = () => Object.keys(c), r.id = 53536, e.exports = r
            },
            95768: (e, a, t) => {
                "use strict";
                var c, r = t(22024),
                    s = t(7660);
                const d = document.querySelectorAll('script[type="application/json"][data-role="module-args"][data-module-name="islands/follow-ups/index.mod"]'),
                    i = (null === (c = document.getElementById("js-follow-ups-experiment-group")) || void 0 === c ? void 0 : c.getAttribute("data-site-url")) || "";
                d.forEach((e => {
                    const a = JSON.parse(e.textContent || "{}"),
                        t = document.getElementById(a.containerElementId),
                        c = {
                            target: t,
                            props: { ...a,
                                siteUrl: i
                            }
                        };
                    (null == t ? void 0 : t.children.length) > 0 ? (0, r.Qv)(s.A, c) : (0, r.Or)(s.A, c)
                }))
            },
            53117: (e, a, t) => {
                "use strict";
                t.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            70243: (e, a, t) => {
                "use strict";

                function c(e) {
                    return (...a) => e()(...a)
                }
                t.d(a, {
                    P0: () => r
                });
                c((() => StackExchange.helpers.addSpinner)), c((() => StackExchange.helpers.addStacksSpinner)), c((() => StackExchange.helpers.addLightbox)), c((() => StackExchange.helpers.getLikelyErrorMessage)), c((() => StackExchange.helpers.getRejectedMockXhr)), c((() => StackExchange.helpers.getSpinnerImg)), c((() => StackExchange.helpers.removeMessages)), c((() => StackExchange.helpers.removeSpinner)), c((() => StackExchange.helpers.showErrorMessage)), c((() => StackExchange.helpers.showInfoMessage)), c((() => StackExchange.helpers.showMessage)), c((() => StackExchange.helpers.showSuccessMessage)), c((() => StackExchange.helpers.showModal)), c((() => StackExchange.helpers.loadModal));
                const r = c((() => StackExchange.helpers.showToast));
                c((() => StackExchange.helpers.hideToasts)), c((() => StackExchange.helpers.suggestedTransientTimeout)), c((() => StackExchange.helpers.toggleStacksPopover)), c((() => StackExchange.helpers.queueStacksPopover)), c((() => StackExchange.helpers.submitFormOnEnterPress)), c((() => StackExchange.helpers.updateQueryStringParameter)), c((() => StackExchange.helpers.DelayedReaction)), c((() => StackExchange.helpers.closePopups)), c((() => StackExchange.helpers.showStacksNotice)), c((() => StackExchange.helpers.removeParameterFromQueryString)), c((() => StackExchange.helpers.enableSubmitButton)), c((() => StackExchange.helpers.disableSubmitButton)), c((() => StackExchange.helpers.loadTicks)), c((() => StackExchange.helpers.encodeHexHtmlEntities)), c((() => StackExchange.helpers.bindOnHashChange_HighlightDestination)), c((() => StackExchange.helpers.MagicPopup)), c((() => StackExchange.helpers.copyTextToClipboard)), c((() => StackExchange.helpers.noDiacritics)), c((() => StackExchange.helpers.tagSeparator)), c((() => StackExchange.helpers.sanitizeAndSplitTags)), new Promise((e => {
                    "undefined" != typeof window ? StackExchange.ready(e) : e()
                }))
            },
            1977: (e, a, t) => {
                "use strict";

                function c(e, a, t = void 0, c = void 0) {
                    const r = new FormData;
                    r.append("fKey", null != c ? c : StackExchange.options.user.fkey), r.append("data", JSON.stringify(a)), r.append("event", e);
                    let s = {};
                    t && (s["X-Previous-Event-Id"] = t), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                        method: "POST",
                        keepalive: !0,
                        body: r,
                        headers: s
                    }).then((() => {}))
                }
                t.d(a, {
                    H: () => c
                })
            },
            20428: e => {
                "use strict";
                e.exports = window.jQuery
            },
            54152: (e, a, t) => {
                "use strict";
                t.d(a, {
                    UPF: () => r,
                    b4L: () => d,
                    dpN: () => s,
                    pSV: () => n,
                    pjm: () => i,
                    q0e: () => c
                });
                const c = '<svg aria-hidden="true" class="svg-icon iconArrowDownAlt" width="18" height="18"  viewBox="0 0 18 18"><path  d="m16.01 7.43-1.4-1.41L9 11.6 3.42 6l-1.4 1.42 7 7z"/></svg>',
                    r = '<svg aria-hidden="true" class="svg-icon iconArrowUp" width="18" height="18"  viewBox="0 0 18 18"><path  d="M1 12h16L9 4z"/></svg>',
                    s = '<svg aria-hidden="true" class="svg-icon iconArrowUpAlt" width="18" height="18"  viewBox="0 0 18 18"><path  d="m16.01 10.62-1.4 1.4L9 6.45l-5.59 5.59-1.4-1.41 7-7z"/></svg>',
                    d = '<svg aria-hidden="true" class="svg-icon iconEllipsisHorizontal" width="17" height="18"  viewBox="0 0 17 18"><path  d="M3.5 10a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3m5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3M12 8.5a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0"/></svg>',
                    i = '<svg aria-hidden="true" class="svg-icon iconMessage" width="18" height="18"  viewBox="0 0 18 18"><path  d="M1 4v14l3-3h11c1.09 0 2-.91 2-2V4c0-1.09-.91-2-2-2H3a2 2 0 0 0-2 2m3 9-1 1V4h12v9zm1-6a1 1 0 0 1 1-1h6a1 1 0 1 1 0 2H6a1 1 0 0 1-1-1m1 2a1 1 0 1 0 0 2h4a1 1 0 1 0 0-2z"/></svg>',
                    n = '<svg aria-hidden="true" class="svg-icon iconPencilSm" width="14" height="14"  viewBox="0 0 14 14"><path fill="#F1B600" d="m2 10.12 6.37-6.43 1.88 1.88L3.88 12H2z"/><path fill="#E87C87" d="m11.1 1.71 1.13 1.12c.2.2.2.51 0 .71L11.1 4.7 9.21 2.86l1.17-1.15c.2-.2.51-.2.71 0"/></svg>'
            },
            23626: (e, a, t) => {
                "use strict";
                var c = t(40060);

                function r(e) {
                    return function a(t, c = 1, r) {
                        if (0 === c || !(e => null !== e && "object" == typeof e)(t)) return t;
                        if (Array.isArray(t)) return t.map((e => a(e, c - 1, r)));
                        const s = Object.create(Object.getPrototypeOf(t));
                        return Object.keys(t).forEach((d => {
                            const i = t[d],
                                n = e(d, r),
                                o = a(i, c - 1, r);
                            s[n] = o
                        })), s
                    }
                }
                r(c.xQ), r(c.De), r(c.FU), r(c.a_), r(c.to), r(c.W7), r(c.kW), r(c.fL), r(c.yj), r(c.o3), r(c.LW)
            },
            2322: (e, a, t) => {
                "use strict";
                t.d(a, {
                    Kf: () => d,
                    UE: () => i
                });
                var c = t(17663),
                    r = t(85630),
                    s = t(22024);
                const d = e => {
                        let a, t;
                        const r = {
                            autoUpdate: !0
                        };
                        let d = e ? ? {};
                        const i = a => ({ ...r,
                                ...e || {},
                                ...a || {}
                            }),
                            n = e => {
                                a && t && (d = i(e), (0, c.rD)(a, t, d).then((e => {
                                    Object.assign(t.style, {
                                        position: e.strategy,
                                        left: `${e.x}px`,
                                        top: `${e.y}px`
                                    }), d ? .onComputed && d.onComputed(e)
                                })))
                            },
                            o = e => {
                                const t = e.subscribe((e => {
                                    void 0 === a ? (a = e, n()) : (Object.assign(a, e), n())
                                }));
                                (0, s.sA)(t)
                            };
                        return [e => {
                            if ("subscribe" in e) return o(e), {};
                            a = e, n()
                        }, (e, r) => {
                            let o;
                            t = e, d = i(r), setTimeout((() => n(r)), 0), n(r);
                            const p = () => {
                                    o && (o(), o = void 0)
                                },
                                f = (e = d) => new Promise((r => {
                                    const {
                                        autoUpdate: d
                                    } = e || {};
                                    p(), !1 !== d && (0, s.io)().then((() => {
                                        r((0, c.ll)(a, t, (() => n(e)), !0 === d ? {} : d))
                                    }))
                                }));
                            return f().then((e => o = e)), {
                                update(e) {
                                    n(e), f().then((e => o = e))
                                },
                                destroy() {
                                    p()
                                }
                            }
                        }, n]
                    },
                    i = e => ({
                        name: "arrow",
                        options: e,
                        fn(a) {
                            const t = (0, r.Jt)(e.element);
                            return t ? (0, c.UE)({
                                element: t,
                                padding: e.padding
                            }).fn(a) : {}
                        }
                    })
            }
        },
        d = {};

    function i(e) {
        var a = d[e];
        if (void 0 !== a) return a.exports;
        var t = d[e] = {
            exports: {}
        };
        return s[e].call(t.exports, t, t.exports, i), t.exports
    }
    i.m = s, e = [], i.O = (a, t, c, r) => {
        if (!t) {
            var s = 1 / 0;
            for (p = 0; p < e.length; p++) {
                for (var [t, c, r] = e[p], d = !0, n = 0; n < t.length; n++)(!1 & r || s >= r) && Object.keys(i.O).every((e => i.O[e](t[n]))) ? t.splice(n--, 1) : (d = !1, r < s && (s = r));
                if (d) {
                    e.splice(p--, 1);
                    var o = c();
                    void 0 !== o && (a = o)
                }
            }
            return a
        }
        r = r || 0;
        for (var p = e.length; p > 0 && e[p - 1][2] > r; p--) e[p] = e[p - 1];
        e[p] = [t, c, r]
    }, i.n = e => {
        var a = e && e.__esModule ? () => e.default : () => e;
        return i.d(a, {
            a
        }), a
    }, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, i.t = function(e, c) {
        if (1 & c && (e = this(e)), 8 & c) return e;
        if ("object" == typeof e && e) {
            if (4 & c && e.__esModule) return e;
            if (16 & c && "function" == typeof e.then) return e
        }
        var r = Object.create(null);
        i.r(r);
        var s = {};
        a = a || [null, t({}), t([]), t(t)];
        for (var d = 2 & c && e;
            "object" == typeof d && !~a.indexOf(d); d = t(d)) Object.getOwnPropertyNames(d).forEach((a => s[a] = () => e[a]));
        return s.default = () => e, i.d(r, s), r
    }, i.d = (e, a) => {
        for (var t in a) i.o(a, t) && !i.o(e, t) && Object.defineProperty(e, t, {
            enumerable: !0,
            get: a[t]
        })
    }, i.f = {}, i.e = e => Promise.all(Object.keys(i.f).reduce(((a, t) => (i.f[t](e, a), a)), [])), i.u = e => 3431 === e ? "webpack-chunks/3431.en.js" : "webpack-chunks/" + e + "." + {
        39: "0c327b2a4933649c046f",
        280: "78aa2de8c7354dc19f59",
        503: "d64ce9cb0e1713a97fa0",
        561: "5d0534ecefc1507a56ed",
        968: "5e07d1c4e2181dba23cf",
        1131: "1ac785798c33d445a662",
        1213: "a2ab798ed57291783dac",
        1231: "3a50f67686b31fc42c00",
        1772: "4cad33a1785c14f9a3f8",
        1942: "07c0507f73de5c49faab",
        2009: "ab8906781c9641e430f1",
        2106: "f57196f852a2f5fe8564",
        2390: "91d1fc1f591e852502ad",
        2552: "186e91acc01b74603da0",
        2590: "68290cd8d9bf295c44ac",
        2844: "109973b801f6ff8752ed",
        2978: "b3cb5b00813c7361dcf2",
        2987: "31ffa97bd6b596c9dfe3",
        3274: "f7fd16701248cd3d33fd",
        3450: "1eabc856027e72122a22",
        4066: "2c769aa805d195aaec5b",
        4091: "c6daef6e602f996c0bd3",
        4158: "e231bf4644002ecad221",
        4329: "ef75e680701ad98fc0ca",
        4527: "e8a2a8cd61693351582f",
        4646: "82d21bd7b183cdeb5eeb",
        4714: "a9bc14522e19a4030f31",
        4889: "6064f61c508728f860b4",
        5019: "aadd414ab46b6aa8a9ba",
        5047: "73bf2547156e955eed1d",
        5155: "8929efe69bf21677f6d0",
        5304: "159e929c07ef4e1ebd6e",
        5429: "7397817c795d018d5518",
        5539: "eacd9e0d87d445b94a48",
        5553: "6e0b77f1d4267a1d2b02",
        5850: "44d46a18a41f664670c0",
        6158: "ee3f7ff34c5f4af26d74",
        6194: "726078b69c57150105b4",
        6255: "53461cbdbd4563dce184",
        6261: "d7809c75407908e2bd1e",
        6456: "a0e4e8c639b99fe6d1c1",
        6559: "68b1db9ba257d2dc2bef",
        6671: "6055abe67ec3cac19fc6",
        6737: "914fdaf157147acbae26",
        6883: "fa2b954cf29aa505c136",
        7028: "b7ec91fc61f47e301390",
        7334: "0a1297a871633e0bc52c",
        7356: "581d3b59c4106e99cbf4",
        7438: "4f1949cf0291279dc92f",
        7624: "260c52f6459c3cb9a0af",
        7658: "02e00dd8274b7ca7361f",
        7702: "b53d89d820b40f1b57e5",
        7712: "dfdc4d6ad42ee4bbc8b3",
        7727: "ca5d2c1f92acee0993e6",
        7731: "fc571ef82b17c18d772e",
        7757: "15ab0517852b07044871",
        7908: "7579a1e2dad366811297",
        8155: "0c88c373cd037b2cd1b9",
        8210: "c249e93165dbb518fa58",
        8228: "0ef292c6c07b0b03cc3a",
        8239: "0b62eb96110b44b4d34b",
        8321: "4a304adc6b166c75f6b8",
        8478: "1562eba353e358405709",
        8551: "5037a8be9386358ab941",
        8631: "6796827941bd0634a167",
        8952: "f1f8118c003bd9631032",
        9167: "83584f57bbc43cd4f8bf",
        9168: "f0c0a0da5ec398cd73f3",
        9177: "9f3388250bfe030c2379",
        9203: "87f7098190310b8a6707",
        9218: "c925b7a39a4299fdda5c",
        9314: "34b8f0b382c8eec48309",
        9495: "876a79736eb7223a79e3",
        9754: "56c73e2643f19f438688",
        9827: "28d65e6c88a4f3f023e0",
        9831: "2dd08ae9fc8c832d8b44"
    }[e] + ".en.js", i.o = (e, a) => Object.prototype.hasOwnProperty.call(e, a), c = {}, r = "stackoverflow:", i.l = (e, a, t, s) => {
        if (c[e]) c[e].push(a);
        else {
            var d, n;
            if (void 0 !== t)
                for (var o = document.getElementsByTagName("script"), p = 0; p < o.length; p++) {
                    var f = o[p];
                    if (f.getAttribute("src") == e || f.getAttribute("data-webpack") == r + t) {
                        d = f;
                        break
                    }
                }
            d || (n = !0, (d = document.createElement("script")).charset = "utf-8", d.timeout = 120, i.nc && d.setAttribute("nonce", i.nc), d.setAttribute("data-webpack", r + t), d.src = e), c[e] = [a];
            var l = (a, t) => {
                    d.onerror = d.onload = null, clearTimeout(h);
                    var r = c[e];
                    if (delete c[e], d.parentNode && d.parentNode.removeChild(d), r && r.forEach((e => e(t))), a) return a(t)
                },
                h = setTimeout(l.bind(null, void 0, {
                    type: "timeout",
                    target: d
                }), 12e4);
            d.onerror = l.bind(null, d.onerror), d.onload = l.bind(null, d.onload), n && document.head.appendChild(d)
        }
    }, i.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, i.j = 4468, i.p = "", (() => {
        var e = {
            4468: 0
        };
        i.f.j = (a, t) => {
            var c = i.o(e, a) ? e[a] : void 0;
            if (0 !== c)
                if (c) t.push(c[2]);
                else {
                    var r = new Promise(((t, r) => c = e[a] = [t, r]));
                    t.push(c[2] = r);
                    var s = i.p + i.u(a),
                        d = new Error;
                    i.l(s, (t => {
                        if (i.o(e, a) && (0 !== (c = e[a]) && (e[a] = void 0), c)) {
                            var r = t && ("load" === t.type ? "missing" : t.type),
                                s = t && t.target && t.target.src;
                            d.message = "Loading chunk " + a + " failed.\n(" + r + ": " + s + ")", d.name = "ChunkLoadError", d.type = r, d.request = s, c[1](d)
                        }
                    }), "chunk-" + a, a)
                }
        }, i.O.j = a => 0 === e[a];
        var a = (a, t) => {
                var c, r, [s, d, n] = t,
                    o = 0;
                if (s.some((a => 0 !== e[a]))) {
                    for (c in d) i.o(d, c) && (i.m[c] = d[c]);
                    if (n) var p = n(i)
                }
                for (a && a(t); o < s.length; o++) r = s[o], i.o(e, r) && e[r] && e[r][0](), e[r] = 0;
                return i.O(p)
            },
            t = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        t.forEach(a.bind(null, 0)), t.push = a.bind(null, t.push.bind(t))
    })(), i.O(void 0, [5622, 8112, 4365, 8339, 7663, 3696, 2458, 620, 7660], (() => i(53117)));
    var n = i.O(void 0, [5622, 8112, 4365, 8339, 7663, 3696, 2458, 620, 7660], (() => i(95768)));
    n = i.O(n)
})();