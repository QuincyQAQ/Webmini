(() => {
    "use strict";
    var e, t = {
            23738: (e, t, n) => {
                var a = n(22024);

                function i(e) {
                    const t = function(e) {
                        const t = e.replace(/\.(t|j)sx?/, ""),
                            n = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                        return document.querySelectorAll(n)
                    }(e);
                    return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
                }
                n(82170);
                var o = n(67578),
                    s = n(99724),
                    r = n(85630);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const l = {
                        step: 1,
                        theme: "light",
                        selectedPopularTags: [],
                        selectedSearchTags: []
                    },
                    c = (() => {
                        const {
                            subscribe: e,
                            set: t,
                            update: n
                        } = (0, r.T5)({ ...l
                        });
                        return {
                            subscribe: e,
                            set: t,
                            reset: () => {
                                t({ ...l
                                })
                            },
                            incrementStep: () => {
                                n((e => (e.step += 1, e)))
                            },
                            selectTag: (e, t) => {
                                n((n => (n.selectedPopularTags.length + n.selectedSearchTags.length <= 30 && ("popular" === t ? n.selectedPopularTags.includes(e) || (n.selectedPopularTags = [...n.selectedPopularTags, e]) : n.selectedSearchTags = [...n.selectedSearchTags, e]), n)))
                            },
                            deselectTag: (e, t) => {
                                n((n => ("popular" === t ? n.selectedPopularTags = n.selectedPopularTags.filter((t => t !== e)) : n.selectedSearchTags = n.selectedSearchTags.filter((t => t !== e)), n)))
                            }
                        }
                    })(),
                    d = (0, r.un)(c, (e => [...e.selectedPopularTags, ...e.selectedSearchTags]));
                var u, g, p, v, h, m, f, w, b, S, y, k, x, _, C, T, O, N, P, E, A, B, U, F, R, Y, M, I, j, L, $, z, H, J, D, q, V, G, K, Z;
                ! function(e) {
                    e[e.AboutTeam = 13] = "AboutTeam", e[e.AboutYou = 12] = "AboutYou", e[e.Billing = 4] = "Billing", e[e.ChannelName = 3] = "ChannelName", e[e.ContactSales = 7] = "ContactSales", e[e.ContactSales_ThankYou = 8] = "ContactSales_ThankYou", e[e.CreateProfile = 9] = "CreateProfile", e[e.Email = 1] = "Email", e[e.FreemiumVerifyEmail = 15] = "FreemiumVerifyEmail", e[e.Login = 11] = "Login", e[e.Plan = 2] = "Plan", e[e.Signup = 10] = "Signup", e[e.ThankYou = 6] = "ThankYou", e[e.Tools = 14] = "Tools", e[e.VerifyEmail = 5] = "VerifyEmail"
                }(u || (u = {})),
                function(e) {
                    e[e.Basic = 0] = "Basic", e[e.Enterprise = 2] = "Enterprise", e[e.Freemium = 3] = "Freemium", e[e.Premium = 1] = "Premium"
                }(g || (g = {})),
                function(e) {
                    e[e.BillingAddress1 = 18] = "BillingAddress1", e[e.BillingAddress2 = 19] = "BillingAddress2", e[e.BillingCity = 20] = "BillingCity", e[e.BillingCountry = 17] = "BillingCountry", e[e.BillingEmail = 7] = "BillingEmail", e[e.BillingFirstName = 15] = "BillingFirstName", e[e.BillingLastName = 16] = "BillingLastName", e[e.BillingPostalCode = 22] = "BillingPostalCode", e[e.BillingState = 21] = "BillingState", e[e.CCExpiry = 24] = "CCExpiry", e[e.CCNumber = 23] = "CCNumber", e[e.ChannelId = 28] = "ChannelId", e[e.ChannelName = 2] = "ChannelName", e[e.ChannelUrl = 3] = "ChannelUrl", e[e.CVV = 25] = "CVV", e[e.Email = 1] = "Email", e[e.FirstName = 4] = "FirstName", e[e.LastName = 5] = "LastName", e[e.MailingAddress1 = 10] = "MailingAddress1", e[e.MailingAddress2 = 11] = "MailingAddress2", e[e.MailingCity = 12] = "MailingCity", e[e.MailingCountry = 9] = "MailingCountry", e[e.MailingPostalCode = 14] = "MailingPostalCode", e[e.MailingState = 13] = "MailingState", e[e.None = 0] = "None", e[e.OrganizationName = 6] = "OrganizationName", e[e.PhoneNumber = 8] = "PhoneNumber", e[e.RealName = 29] = "RealName", e[e.SelectedTier = 26] = "SelectedTier"
                }(p || (p = {})),
                function(e) {
                    e[e.DataMissingFromCache = 5] = "DataMissingFromCache", e[e.Existing = 3] = "Existing", e[e.Invalid = 2] = "Invalid", e[e.Missing = 1] = "Missing", e[e.None = 0] = "None", e[e.Public = 4] = "Public"
                }(v || (v = {})),
                function(e) {
                    e[e.Annual = 2] = "Annual", e[e.Monthly = 1] = "Monthly", e[e.Unknown = 0] = "Unknown"
                }(h || (h = {})),
                function(e) {
                    e[e.Basic = 1] = "Basic", e[e.Freemium = 3] = "Freemium", e[e.Premium = 2] = "Premium", e[e.Unknown = 0] = "Unknown"
                }(m || (m = {})),
                function(e) {
                    e[e.GitHubEnterprise = 4] = "GitHubEnterprise", e[e.Jira = 3] = "Jira", e[e.MicrosoftTeams = 2] = "MicrosoftTeams", e[e.Slack = 1] = "Slack"
                }(f || (f = {})),
                function(e) {
                    e[e.Downgrade = 3] = "Downgrade", e[e.PaymentMethod = 0] = "PaymentMethod", e[e.Plan = 1] = "Plan", e[e.Upgrade = 2] = "Upgrade"
                }(w || (w = {})),
                function(e) {
                    e[e.AddUpvote = 7] = "AddUpvote", e[e.ApproveAndPublish = 1] = "ApproveAndPublish", e[e.ApprovePendingMinorEdits = 2] = "ApprovePendingMinorEdits", e[e.BeginEditPost = 11] = "BeginEditPost", e[e.Cancel = 9] = "Cancel", e[e.DeclineReevaluation = 13] = "DeclineReevaluation", e[e.EditPost = 6] = "EditPost", e[e.None = 0] = "None", e[e.Publish = 10] = "Publish", e[e.RequestReevaluation = 14] = "RequestReevaluation", e[e.RequireMajorChanges = 3] = "RequireMajorChanges", e[e.SaveWithoutReview = 12] = "SaveWithoutReview", e[e.Skip = 8] = "Skip", e[e.VoteAsDuplicate = 5] = "VoteAsDuplicate", e[e.VoteAsOffTopic = 4] = "VoteAsOffTopic"
                }(b || (b = {})),
                function(e) {
                    e.Descriptive = "descriptive", e.Minimal = "minimal"
                }(S || (S = {})),
                function(e) {
                    e[e.Markdown = 1] = "Markdown", e[e.MarkdownWithPreview = 2] = "MarkdownWithPreview", e[e.RichText = 0] = "RichText"
                }(y || (y = {})),
                function(e) {
                    e[e.unknown = 0] = "unknown", e[e.v2 = 1] = "v2", e[e.v3 = 3] = "v3", e[e.wizard = 2] = "wizard"
                }(k || (k = {})),
                function(e) {
                    e[e.Negative = -1] = "Negative", e[e.NotSet = 0] = "NotSet", e[e.Positive = 1] = "Positive"
                }(x || (x = {})),
                function(e) {
                    e[e.FormattingFixes = 2] = "FormattingFixes", e[e.TitleSuggestions = 1] = "TitleSuggestions"
                }(_ || (_ = {})),
                function(e) {
                    e[e.Answer = 2] = "Answer", e[e.Question = 1] = "Question"
                }(C || (C = {})),
                function(e) {
                    e[e.NotAvailable = 0] = "NotAvailable"
                }(T || (T = {})),
                function(e) {
                    e[e.Body = 6] = "Body", e[e.BottomTitle = 7] = "BottomTitle", e[e.BottomTitleSuggestions = 8] = "BottomTitleSuggestions", e[e.ExpectedResults = 3] = "ExpectedResults", e[e.ProblemDetail = 2] = "ProblemDetail", e[e.SimilarQuestions = 5] = "SimilarQuestions", e[e.StagingGroundSelection = 10] = "StagingGroundSelection", e[e.Tags = 4] = "Tags", e[e.Title = 1] = "Title", e[e.TopTitleSuggestions = 9] = "TopTitleSuggestions"
                }(O || (O = {})),
                function(e) {
                    e[e.FifteenHundredOneToTwentyFiveHundred = 4] = "FifteenHundredOneToTwentyFiveHundred", e[e.FiftyThousandAndOnePlus = 8] = "FiftyThousandAndOnePlus", e[e.FiveHundredOneToFifteenHundred = 3] = "FiveHundredOneToFifteenHundred", e[e.FiveThousandOneToTenThousand = 6] = "FiveThousandOneToTenThousand", e[e.OneToTwoHundred = 1] = "OneToTwoHundred", e[e.TenThousandOneToFiftyThousand = 7] = "TenThousandOneToFiftyThousand", e[e.TwentyFiveHundredOneToFiveThousand = 5] = "TwentyFiveHundredOneToFiveThousand", e[e.TwoHundredOneToFiveHundred = 2] = "TwoHundredOneToFiveHundred"
                }(N || (N = {})),
                function(e) {
                    e[e.Dark = 1] = "Dark", e[e.HighContrastDark = 5] = "HighContrastDark", e[e.HighContrastLight = 4] = "HighContrastLight", e[e.HighContrastMod = 4] = "HighContrastMod", e[e.HighContrastSystemDefault = 6] = "HighContrastSystemDefault", e[e.Light = 0] = "Light", e[e.SystemDefault = 2] = "SystemDefault"
                }(P || (P = {})),
                function(e) {
                    e[e.home_page = 1] = "home_page", e[e.question_page = 3] = "question_page", e[e.questions_list_page = 2] = "questions_list_page", e[e.tagged_questions_page = 5] = "tagged_questions_page", e[e.tags_page = 4] = "tags_page"
                }(E || (E = {})),
                function(e) {
                    e[e.browse_other_questions = 4] = "browse_other_questions", e[e.headline = 6] = "headline", e[e.homepage_customize_your_feed = 12] = "homepage_customize_your_feed", e[e.ignored_tags = 8] = "ignored_tags", e[e.question = 3] = "question", e[e.questions_list = 1] = "questions_list", e[e.related_tags = 2] = "related_tags", e[e.tag = 5] = "tag", e[e.watched_tags = 7] = "watched_tags", e[e.watched_tags_widget = 9] = "watched_tags_widget", e[e.watched_tags_widget_cta_button = 10] = "watched_tags_widget_cta_button", e[e.watched_tags_widget_cta_description = 11] = "watched_tags_widget_cta_description"
                }(A || (A = {})),
                function(e) {
                    e[e.DownVoteRepRequired = 3] = "DownVoteRepRequired", e[e.FreeVoteOnboarding = 2] = "FreeVoteOnboarding", e[e.None = 0] = "None", e[e.Save = 1] = "Save"
                }(B || (B = {})),
                function(e) {
                    e[e.CollectionDeleted = 3] = "CollectionDeleted", e[e.ExistsInCollection = 8] = "ExistsInCollection", e[e.InvalidMentionNames = 10] = "InvalidMentionNames", e[e.InvalidPostType = 11] = "InvalidPostType", e[e.MaxCollectionSize = 9] = "MaxCollectionSize", e[e.MissingOwner = 7] = "MissingOwner", e[e.MissingTitle = 6] = "MissingTitle", e[e.NoCollectionFound = 2] = "NoCollectionFound", e[e.NoDeleteRights = 12] = "NoDeleteRights", e[e.NoEditRights = 13] = "NoEditRights", e[e.NoPermissionGrantRights = 14] = "NoPermissionGrantRights", e[e.NoQuestionFound = 4] = "NoQuestionFound", e[e.NoUserFound = 5] = "NoUserFound", e[e.ServerError = 1] = "ServerError", e[e.Success = 0] = "Success"
                }(U || (U = {})),
                function(e) {
                    e[e.ArticleNotFound = 5] = "ArticleNotFound", e[e.CannotLeaveSuggestion = 7] = "CannotLeaveSuggestion", e[e.ExistingDraft = 11] = "ExistingDraft", e[e.InvalidMentionNames = 4] = "InvalidMentionNames", e[e.InvalidSuggestion = 6] = "InvalidSuggestion", e[e.NeedsComment = 8] = "NeedsComment", e[e.NoEditRights = 2] = "NoEditRights", e[e.NoRejectionRights = 3] = "NoRejectionRights", e[e.ServerError = 1] = "ServerError", e[e.Success = 0] = "Success", e[e.TooManyEdits = 9] = "TooManyEdits", e[e.Unauthorized = 10] = "Unauthorized"
                }(F || (F = {})),
                function(e) {
                    e[e.AdminOnly = 11] = "AdminOnly", e[e.CustomAwardDeleted = 5] = "CustomAwardDeleted", e[e.MaxCustomAwards = 9] = "MaxCustomAwards", e[e.MaxFeatured = 10] = "MaxFeatured", e[e.MaxSizeDescription = 8] = "MaxSizeDescription", e[e.MaxSizeName = 7] = "MaxSizeName", e[e.MissingDescription = 3] = "MissingDescription", e[e.MissingName = 2] = "MissingName", e[e.NoCustomAwardFound = 4] = "NoCustomAwardFound", e[e.NoDeleteRights = 12] = "NoDeleteRights", e[e.ServerError = 1] = "ServerError", e[e.Success = 0] = "Success", e[e.UniqueName = 6] = "UniqueName"
                }(R || (R = {})),
                function(e) {
                    e[e.Achievements = 6] = "Achievements", e[e.FaceSmile = 1] = "FaceSmile", e[e.Fire = 5] = "Fire", e[e.Heart = 4] = "Heart", e[e.Medal = 2] = "Medal", e[e.Tada = 3] = "Tada"
                }(Y || (Y = {})),
                function(e) {
                    e[e.AddReminder = 3] = "AddReminder", e[e.CancelReminder = 4] = "CancelReminder", e[e.Read = 1] = "Read", e[e.UndoAddReminder = 5] = "UndoAddReminder", e[e.UndoCancelReminder = 6] = "UndoCancelReminder", e[e.Unread = 2] = "Unread"
                }(M || (M = {})),
                function(e) {
                    e[e.InvalidUserId = 1] = "InvalidUserId", e[e.Success = 0] = "Success"
                }(I || (I = {})),
                function(e) {
                    e[e.All = 2] = "All", e[e.Unread = 1] = "Unread"
                }(j || (j = {})),
                function(e) {
                    e[e.Topic = 1] = "Topic", e[e.Vendor = 0] = "Vendor"
                }(L || (L = {})),
                function(e) {
                    e[e.ActivityIndicatorDisabled = 131072] = "ActivityIndicatorDisabled", e[e.InvitationsDisabled = 4096] = "InvitationsDisabled", e[e.LabelEmployee = 8192] = "LabelEmployee", e[e.None = 0] = "None", e[e.NotificationCanEndorse = 1024] = "NotificationCanEndorse", e[e.NotificationNewMember = 512] = "NotificationNewMember", e[e.OnboardingAddPartners = 8] = "OnboardingAddPartners", e[e.OnboardingAnswerQuestion = 16] = "OnboardingAnswerQuestion", e[e.OnboardingCreateReport = 256] = "OnboardingCreateReport", e[e.OnboardingDismissed = 2048] = "OnboardingDismissed", e[e.OnboardingRecommendAnswer = 128] = "OnboardingRecommendAnswer", e[e.OnboardingReviewDashboard = 64] = "OnboardingReviewDashboard", e[e.OnboardingWriteArticle = 32] = "OnboardingWriteArticle", e[e.OrganicInvitation = 16384] = "OrganicInvitation", e[e.RoleAdmin = 1] = "RoleAdmin", e[e.RoleAnalyst = 32768] = "RoleAnalyst", e[e.RoleLimitedPartner = 65536] = "RoleLimitedPartner", e[e.RolePartner = 2] = "RolePartner", e[e.RoleSubscriber = 4] = "RoleSubscriber"
                }($ || ($ = {})),
                function(e) {
                    e[e.OptIn = 0] = "OptIn", e[e.OptOut = 1] = "OptOut"
                }(z || (z = {})),
                function(e) {
                    e[e.body_blur = 6] = "body_blur", e[e.body_focus = 5] = "body_focus", e[e.tags_blur = 10] = "tags_blur", e[e.tags_focus = 9] = "tags_focus", e[e.title_blur = 2] = "title_blur", e[e.title_focus = 1] = "title_focus", e[e.undefined_blur = 12] = "undefined_blur", e[e.undefined_focus = 11] = "undefined_focus"
                }(H || (H = {})),
                function(e) {
                    e[e.AllLevels = 1] = "AllLevels", e[e.Beginner = 2] = "Beginner", e[e.Expert = 4] = "Expert", e[e.Intermediate = 3] = "Intermediate"
                }(J || (J = {})),
                function(e) {
                    e[e.BestPractices = 2] = "BestPractices", e[e.GeneralAdviceOther = 3] = "GeneralAdviceOther", e[e.ToolingRecommendation = 1] = "ToolingRecommendation"
                }(D || (D = {})),
                function(e) {
                    e[e.HomepageCustomizeYourFeed = 1] = "HomepageCustomizeYourFeed", e[e.WatchedTagsWidget = 2] = "WatchedTagsWidget"
                }(q || (q = {})),
                function(e) {
                    e[e.BountyEndingSoon = 4] = "BountyEndingSoon", e[e.Hot = 5] = "Hot", e[e.HotNoTime = 6] = "HotNoTime", e[e.MostFrequent = 3] = "MostFrequent", e[e.MostVotes = 2] = "MostVotes", e[e.Newest = 0] = "Newest", e[e.RecentActivity = 1] = "RecentActivity"
                }(V || (V = {})),
                function(e) {
                    e[e.DeactivatedOwner = 8] = "DeactivatedOwner", e[e.HasBounty = 4] = "HasBounty", e[e.NoAcceptedAnswer = 2] = "NoAcceptedAnswer", e[e.NoAnswers = 1] = "NoAnswers", e[e.None = 0] = "None", e[e.NoStagingGround = 16] = "NoStagingGround"
                }(G || (G = {})),
                function(e) {
                    e[e.Specified = 0] = "Specified", e[e.Watched = 1] = "Watched"
                }(K || (K = {})),
                function(e) {
                    e[e.Condensed = 1] = "Condensed", e[e.Expanded = 0] = "Expanded"
                }(Z || (Z = {})), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const Q = (e, t, n) => {
                        ! function(e, t, n, a) {
                            const i = new FormData;
                            i.append("fKey", null != a ? a : StackExchange.options.user.fkey), i.append("data", JSON.stringify(t)), i.append("event", e);
                            let o = {};
                            n && (o["X-Previous-Event-Id"] = n), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                                method: "POST",
                                keepalive: !0,
                                body: i,
                                headers: o
                            }).then((() => {}))
                        }(e, {
                            source: window.location.href,
                            ...t
                        }, void 0, n)
                    },
                    W = (e, t) => {
                        window.StackExchange.using("gps", (() => {
                            window.StackExchange.gps.track(e, t)
                        }))
                    },
                    X = {
                        openCenteredPopup: function(e, t, n, a, i) {
                            const o = n.top.outerHeight / 2 + n.top.screenY - i / 2,
                                s = n.top.outerWidth / 2 + n.top.screenX - a / 2;
                            return n.open(e, t, `toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=${a}, height=${i}, top=${o}, left=${s}`)
                        }
                    };
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                let ee = !1;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const te = (e, t) => {
                    W("signup.start", {
                        openid_provider: e,
                        location: t
                    }), ee && Q("signup.start", {
                        openIdProvider: e,
                        location: t
                    })
                };
                var ne = n(47287),
                    ae = o.vUu('<div class="d-flex fd-column g8"><span class="flex--item fs-title fw-bold"></span> <span class="flex--item fs-body2"></span></div>'),
                    ie = o.vUu('<button class="m8 s-tag s-tag__md post-tag c-pointer bg-blue-200 bc-blue-400 fc-blue-400 c-pointer h:bg-blue-300"> </button>'),
                    oe = o.vUu('<button class="m8 s-tag s-tag__md post-tag c-pointer h:bg-black-200"> </button>'),
                    se = o.vUu('<div class="d-flex fd-column g8" data-testid="tag-step-body"><div id="popular-tags" class="mb8 mln8"></div> <div class="d-flex fd-column g8 ps-relative"><span class="flex--item fs-body2"></span> <!></div></div>'),
                    re = o.vUu('<span class="fc-black-400 fs-caption px16"> </span>'),
                    le = o.vUu('<div class="w100 ta-center"><!> <!></div>');

                function ce(e, t) {
                    o.VCO(t, !0);
                    const [n, a] = o.DZI(), i = () => o.Hzn(d, "$allSelectedTags", n), l = () => o.Hzn(c, "$wizardStore", n);
                    let u = o._w2(t, "visible", 15, !1),
                        g = o._w2(t, "tags", 19, (() => [])),
                        p = o.unG((() => !t.isAnonymousUser)),
                        v = o.unG((() => t.isAnonymousUser ? __tr(["You’ll be prompted to create an account to view your personalized homepage."], undefined, "en", []) : null)),
                        h = o.wk1(""),
                        m = ["python", "javascript", "c#", "reactjs", "java", "android", "html", "flutter", "c++", "node.js", "typescript", "css", "r", "php", "angular", "next.js", "spring-boot", "machine-learning", "sql", "excel", "ios", "azure", "docker"],
                        f = o.unG((() => g().filter((e => !i().includes(e)))));
                    const w = e => Promise.resolve(o.JtY(f).filter((t => !e || t.toLowerCase().includes(e)))); {
                        const n = e => {
                                var t = ae(),
                                    n = o.jfp(t);
                                n.textContent = __tr(["Let's set up your homepage"], undefined, "en", []), o.hg4(n, 2).textContent = __tr(["Select a few topics you're interested in:"], undefined, "en", []), o.cLc(t), o.BCw(e, t)
                            },
                            a = e => {
                                var t = se(),
                                    n = o.jfp(t);
                                o.__1(n, 20, (() => m), (e => e), ((e, t) => {
                                    var n = o.Imx(),
                                        a = o.esp(n),
                                        i = e => {
                                            var n = ie();
                                            n.__click = () => c.deselectTag(t, "popular");
                                            var a = o.jfp(n, !0);
                                            o.cLc(n), o.vNg((() => o.jax(a, t))), o.BCw(e, n)
                                        },
                                        s = e => {
                                            var n = oe();
                                            n.__click = () => c.selectTag(t, "popular");
                                            var a = o.jfp(n, !0);
                                            o.cLc(n), o.vNg((() => o.jax(a, t))), o.BCw(e, n)
                                        };
                                    o.if(a, (e => {
                                        l().selectedPopularTags.includes(t) ? e(i) : e(s, !1)
                                    })), o.BCw(e, n)
                                })), o.cLc(n);
                                var a = o.hg4(n, 2),
                                    i = o.jfp(a);
                                i.textContent = __tr(["Or search from our full list:"], undefined, "en", []);
                                var r = o.hg4(i, 2);
                                (0, ne.Sj)(r, {
                                    searchItems: w,
                                    onItemSearchSelected: ({
                                        item: e
                                    }) => {
                                        e && c.selectTag(e, "searchable")
                                    },
                                    get filterString() {
                                        return o.JtY(h)
                                    },
                                    set filterString(e) {
                                        o.hZp(h, e, !0)
                                    },
                                    children: (e, t) => {
                                        const n = o.unG((() => 0 === l().selectedSearchTags.length ? __tr(["Search"], undefined, "en", []) : ""));
                                        ! function(e, t) {
                                            o.VCO(t, !0), o.kZQ(e, tt);
                                            let n = o._w2(t, "disabled", 3, !1),
                                                a = o._w2(t, "fillSide", 3, "prepend"),
                                                i = o._w2(t, "name", 3, void 0),
                                                r = o._w2(t, "placeholder", 3, ""),
                                                l = o._w2(t, "readonly", 3, !1),
                                                c = o._w2(t, "required", 3, !1),
                                                d = o._w2(t, "size", 3, ""),
                                                u = o._w2(t, "state", 3, ""),
                                                g = o._w2(t, "type", 3, "text"),
                                                p = o._w2(t, "class", 3, ""),
                                                v = o._w2(t, "value", 3, ""),
                                                h = o._w2(t, "chips", 19, (() => [])),
                                                m = o._w2(t, "chipsClasses", 3, ""),
                                                f = o.iRd(t, ["$$slots", "$$events", "$$legacy", "id", "disabled", "fillSide", "name", "placeholder", "readonly", "required", "size", "state", "type", "class", "value", "chips", "chipsClasses", "description", "fill", "message", "onRemoveChip", "onkeydown"]);
                                            const w = (e, t) => {
                                                const n = "s-input";
                                                let a = n;
                                                return e && (a += " " + e), t && (a += ` ${n}__${t}`), a += " bc-transparent bs-none p0 h100 fl-grow1 w-auto py4", a
                                            };
                                            let b = o.unG((() => w(p(), d())));
                                            var S = et();
                                            let y;
                                            var k = o.jfp(S),
                                                x = e => {
                                                    var n = Ve(),
                                                        a = o.jfp(n);
                                                    o.UAl(a, (() => t.description ? ? o.lQ1)), o.cLc(n), o.vNg((() => o.aIK(n, "id", `${t.id}-description`))), o.BCw(e, n)
                                                };
                                            o.if(k, (e => {
                                                t.description && e(x)
                                            }));
                                            var _ = o.hg4(k, 2),
                                                C = o.jfp(_),
                                                T = e => {
                                                    var n = Ge();
                                                    let i;
                                                    var s = o.jfp(n);
                                                    o.UAl(s, (() => t.fill ? ? o.lQ1)), o.cLc(n), o.vNg((e => i = o.ysU(n, 1, "s-input-fill", null, i, e)), [() => ({
                                                        "order-first": "prepend" === a(),
                                                        "order-last": "append" === a()
                                                    })]), o.BCw(e, n)
                                                };
                                            o.if(C, (e => {
                                                t.fill && e(T)
                                            }));
                                            var O = o.hg4(C, 2),
                                                N = o.jfp(O),
                                                P = e => {
                                                    var t = Ke();
                                                    let n;
                                                    var a = o.jfp(t);
                                                    const i = o.unG((() => "credit-card" === g() ? Fe.Bln : Fe.C0l));
                                                    (0, s.In)(a, {
                                                        get src() {
                                                            return o.JtY(i)
                                                        }
                                                    }), o.cLc(t), o.vNg((e => n = o.ysU(t, 1, "s-input-icon svelte-12r9hfl", null, n, e)), [() => ({
                                                        "s-input-icon__creditcard": "credit-card" === g(),
                                                        "s-input-icon__search": "search" === g()
                                                    })]), o.BCw(e, t)
                                                };
                                            o.if(N, (e => {
                                                "search" !== g() && "credit-card" !== g() || e(P)
                                            }));
                                            var E = o.hg4(N, 2),
                                                A = o.jfp(E);
                                            o.__1(A, 16, h, (e => e), ((e, n) => {
                                                var a = Qe(),
                                                    i = o.jfp(a);
                                                o.hg4(i).__click = [Ze, t, n], o.cLc(a), o.vNg((() => {
                                                    o.ysU(a, 1, `s-tag post-tag lh-sm ${m()}`, "svelte-12r9hfl"), o.jax(i, `${n??""} `)
                                                })), o.BCw(e, a)
                                            }));
                                            var B = o.hg4(A, 2);
                                            o.R0j(B), o.p_Y(B, (e => ({
                                                id: t.id,
                                                "aria-describedby": t.message ? `${t.id}-message` : t.description ? `${t.id}-description` : void 0,
                                                "aria-invalid": "error" === u(),
                                                class: o.JtY(b),
                                                type: "credit-card" === g() ? "text" : g(),
                                                disabled: n(),
                                                name: i(),
                                                placeholder: r(),
                                                readonly: l(),
                                                required: c(),
                                                value: v(),
                                                onkeydown: t.onkeydown,
                                                ...f,
                                                [o.tpM]: e
                                            })), [() => ({
                                                "s-input__creditcard": "credit-card" === g(),
                                                "s-input__search": "search" === g(),
                                                blr0: t.fill && "prepend" === a(),
                                                brr0: t.fill && "append" === a()
                                            })], "svelte-12r9hfl"), o.cLc(E);
                                            var U = o.hg4(E, 2),
                                                F = e => {
                                                    var t = We(),
                                                        n = o.jfp(t),
                                                        a = e => {
                                                            (0, s.In)(e, {
                                                                get src() {
                                                                    return Fe.GBC
                                                                }
                                                            })
                                                        },
                                                        i = (e, t) => {
                                                            var n = e => {
                                                                    (0, s.In)(e, {
                                                                        get src() {
                                                                            return Fe.VsF
                                                                        }
                                                                    })
                                                                },
                                                                a = e => {
                                                                    (0, s.In)(e, {
                                                                        get src() {
                                                                            return Fe.O7Z
                                                                        }
                                                                    })
                                                                };
                                                            o.if(e, (e => {
                                                                "success" === u() ? e(n) : e(a, !1)
                                                            }), t)
                                                        };
                                                    o.if(n, (e => {
                                                        "error" === u() ? e(a) : e(i, !1)
                                                    })), o.cLc(t), o.BCw(e, t)
                                                };
                                            o.if(U, (e => {
                                                u() && e(F)
                                            })), o.cLc(O), o.cLc(_);
                                            var R = o.hg4(_, 2),
                                                Y = e => {
                                                    var n = Xe(),
                                                        a = o.jfp(n);
                                                    o.UAl(a, (() => t.message ? ? o.lQ1)), o.cLc(n), o.vNg((() => o.aIK(n, "id", `${t.id}-message`))), o.BCw(e, n)
                                                };
                                            o.if(R, (e => {
                                                t.message && e(Y)
                                            })), o.cLc(S), o.vNg((e => y = o.ysU(S, 1, "d-flex fd-column gy4", null, y, e)), [() => ({
                                                "has-error": "error" === u(),
                                                "has-success": "success" === u(),
                                                "has-warning": "warning" === u()
                                            })]), o.BCw(e, S), o.uYY()
                                        }(e, {
                                            id: "filterInput",
                                            role: "search",
                                            "aria-label": "tags",
                                            get placeholder() {
                                                return o.JtY(n)
                                            },
                                            type: "search",
                                            get value() {
                                                return o.JtY(h)
                                            },
                                            get chips() {
                                                return l().selectedSearchTags
                                            },
                                            chipsClasses: "bg-blue-200 bc-blue-400 fc-blue-400",
                                            onRemoveChip: e => c.deselectTag(e, "searchable"),
                                            onkeydown: e => (e => {
                                                "Backspace" === e.key && "" === o.JtY(h) && o.hYb(c, o.vzK(l).selectedSearchTags = l().selectedSearchTags.slice(0, -1), o.vzK(l))
                                            })(e)
                                        })
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                }), o.cLc(a), o.cLc(t), o.BCw(e, t)
                            },
                            d = e => {
                                var t = le(),
                                    n = o.jfp(t);
                                const a = o.unG((() => !o.JtY(p) && 0 === i().length));
                                (0, s.$n)(n, {
                                    class: "w100 mb16",
                                    weight: "filled",
                                    get disabled() {
                                        return o.JtY(a)
                                    },
                                    "data-testid": "next-button",
                                    onclick: () => {
                                        W("homepage_wizard.tag_step.next", {
                                            selectedTagsClicked: (0, r.Jt)(c).selectedPopularTags.length,
                                            selectedTagsSearched: (0, r.Jt)(c).selectedSearchTags.length
                                        }), c.incrementStep()
                                    },
                                    children: (e, t) => {
                                        o.K2T();
                                        var n = o.Qq7();
                                        n.nodeValue = __tr(["Next"], undefined, "en", []), o.BCw(e, n)
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                });
                                var l = o.hg4(n, 2),
                                    d = e => {
                                        var t = re(),
                                            n = o.jfp(t, !0);
                                        o.cLc(t), o.vNg((() => o.jax(n, o.JtY(v)))), o.BCw(e, t)
                                    };
                                o.if(l, (e => {
                                    null !== o.JtY(v) && e(d)
                                })), o.cLc(t), o.BCw(e, t)
                            };
                        (0, s.aF)(e, o.DuQ({
                            id: "signup-modal",
                            class: "pt32 pr32 pb32 ws4 overflow-visible",
                            preventCloseOnClickOutside: !0
                        }, {}, {
                            get visible() {
                                return u()
                            },
                            set visible(e) {
                                u(e)
                            },
                            $$events: {
                                close: [() => o.hZp(h, ""), function(e) {
                                    o.Ibr.call(this, t, e)
                                }]
                            },
                            header: n,
                            body: a,
                            footer: d,
                            $$slots: {
                                header: !0,
                                body: !0,
                                footer: !0
                            }
                        }))
                    }
                    o.uYY(), a()
                }
                o.MmH(["click"]), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const de = [{
                    id: "light",
                    displayName: "Light mode",
                    link: "https://cdn.sstatic.net/Img/preferences/theme-light.svg?v=2d017a78abab"
                }, {
                    id: "systemSetting",
                    displayName: "System setting",
                    link: "https://cdn.sstatic.net/Img/preferences/theme-system@2x.png?v=358fa5ee5f7b"
                }, {
                    id: "dark",
                    displayName: "Dark mode",
                    link: "https://cdn.sstatic.net/Img/preferences/theme-dark.svg?v=9a46fd615a91"
                }];
                var ue = o.vUu('<span class="fs-title fw-bold">Choose your theme</span>'),
                    ge = o.vUu('<div class="flex__item fl-grow1"><label class="d-flex gs8 flex__start ai-center c-pointer sm:jc-start"><div class="flex--item"><input class="s-radio mtn4 js-theme-option" type="radio" name="displayPreference"/></div> <div class="flex--item"><div class="d-flex ai-center g8"><img class="flex--item bar-sm bs-sm mb4" width="100" height="68" alt=""/> <div class="flex--item fs-body2 ml12"> </div></div></div></label></div>'),
                    pe = o.vUu('<div data-testid="theme-step-body" class="d-flex fd-column g24"></div>'),
                    ve = o.vUu('<div class="w100"><!></div>');

                function he(e, t) {
                    o.VCO(t, !0);
                    const [n, a] = o.DZI(), i = () => o.Hzn(c, "$wizardStore", n), r = [];
                    let l = o._w2(t, "visible", 15, !1); {
                        const n = e => {
                                var t = ue();
                                o.BCw(e, t)
                            },
                            a = e => {
                                var t = pe();
                                o.__1(t, 21, (() => de), (e => e.id), ((e, t) => {
                                    var n, a = ge(),
                                        s = o.jfp(a),
                                        l = o.jfp(s),
                                        d = o.jfp(l);
                                    o.R0j(d), o.cLc(l);
                                    var u = o.hg4(l, 2),
                                        g = o.jfp(u),
                                        p = o.jfp(g),
                                        v = o.hg4(p, 2),
                                        h = o.jfp(v, !0);
                                    o.cLc(v), o.cLc(g), o.cLc(u), o.cLc(s), o.cLc(a), o.vNg((() => {
                                        o.aIK(s, "for", o.JtY(t).id), n !== (n = o.JtY(t).id) && (d.value = (d.__value = o.JtY(t).id) ? ? ""), o.aIK(d, "id", o.JtY(t).id), o.aIK(p, "src", o.JtY(t).link), o.jax(h, o.JtY(t).displayName)
                                    })), o.CJk(r, [], d, (() => (o.JtY(t).id, i().theme)), (e => o.hYb(c, o.vzK(i).theme = e, o.vzK(i)))), o.BCw(e, a)
                                })), o.cLc(t), o.BCw(e, t)
                            },
                            d = e => {
                                var t = ve(),
                                    n = o.jfp(t);
                                (0, s.$n)(n, {
                                    class: "w100",
                                    weight: "filled",
                                    "data-testid": "next-button",
                                    onclick: () => {
                                        var e;
                                        e = i().theme, W("homepage_wizard.theme_step.next", {
                                            selectedTheme: e
                                        }), c.incrementStep()
                                    },
                                    children: (e, t) => {
                                        o.K2T();
                                        var n = o.Qq7("Next");
                                        o.BCw(e, n)
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                }), o.cLc(t), o.BCw(e, t)
                            };
                        (0, s.aF)(e, o.DuQ({
                            id: "signup-modal",
                            class: "pt32 pr32 pb32 ws4",
                            preventCloseOnClickOutside: !0
                        }, {}, {
                            get visible() {
                                return l()
                            },
                            set visible(e) {
                                l(e)
                            },
                            $$events: {
                                close(e) {
                                    o.Ibr.call(this, t, e)
                                }
                            },
                            header: n,
                            body: a,
                            footer: d,
                            $$slots: {
                                header: !0,
                                body: !0,
                                footer: !0
                            }
                        }))
                    }
                    o.uYY(), a()
                }
                var me = n(69980),
                    fe = n(5159),
                    we = o.vUu('<span class="fs-title fw-bold">Setting up your experience...</span>'),
                    be = o.vUu("<div><!></div>"),
                    Se = o.vUu("<div><!></div>"),
                    ye = o.vUu("<div><!></div>"),
                    ke = o.vUu("<div><!></div>"),
                    xe = o.vUu("<div><!></div>"),
                    _e = o.vUu('<div data-testid="setting-up-body"><div class="hs1 overflow-hidden d-flex fd-column ai-center mt48"><!></div></div>');
                var Ce = o.vUu('<h1 class="svelte-1mm1u63"> </h1>');
                const Te = {
                    hash: "svelte-1mm1u63",
                    code: "h1.svelte-1mm1u63 {font-size:13px;font-weight:400;overflow:hidden;text-align:center;color:var(--black-400);}h1.svelte-1mm1u63:before,\n    h1.svelte-1mm1u63:after {content:'';display:inline-block;width:50%;margin:0 0.5em 0 -55%;vertical-align:middle;border-bottom:1px solid;border-color:var(--black-225);}h1.svelte-1mm1u63:after {margin:0 -55% 0 0.5em;}"
                };
                var Oe = o.vUu('<input type="hidden" name="vote"/> <input type="hidden" name="votehash"/>', 1),
                    Ne = o.vUu('<input type="hidden" name="tagAction"/> <input type="hidden" name="tagNames"/>', 1),
                    Pe = o.vUu('<input type="hidden" name="anonTheme"/>'),
                    Ee = o.vUu('<div class="d-flex ai-center jc-center gx8"><!> </div>'),
                    Ae = o.vUu('<form class="flex--item" method="POST"><input type="hidden" name="fkey"/> <input type="hidden" name="legalLinksShown" value="1"/> <input type="hidden" name="ssrc"/> <!> <!> <!> <input type="hidden" name="oauth_version"/> <input type="hidden" name="oauth_server"/> <div class="d-flex fd-column gy12"></div></form>');

                function Be(e, t) {
                    o.VCO(t, !0);
                    const n = o._w2(t, "fkey", 3, ""),
                        a = o._w2(t, "providers", 19, (() => []));
                    let i = t.oauthInPopup ? "oauth-frame" : "_self";
                    var r = Ae(),
                        l = o.jfp(r);
                    o.R0j(l);
                    var c = o.hg4(l, 2),
                        d = o.hg4(c, 2);
                    o.R0j(d);
                    var u = o.hg4(d, 2),
                        g = e => {
                            var n = Oe(),
                                a = o.esp(n);
                            o.R0j(a);
                            var i = o.hg4(a, 2);
                            o.R0j(i), o.vNg((() => {
                                o.to4(a, t.signupFormProps.vote), o.to4(i, t.signupFormProps.voteHash)
                            })), o.BCw(e, n)
                        };
                    o.if(u, (e => {
                        t.signupFormProps ? .vote && t.signupFormProps ? .voteHash && e(g)
                    }));
                    var p = o.hg4(u, 2),
                        v = e => {
                            var n = Ne(),
                                a = o.esp(n);
                            o.R0j(a);
                            var i = o.hg4(a, 2);
                            o.R0j(i), o.vNg((() => {
                                o.to4(a, t.signupFormProps.tagAction), o.to4(i, t.signupFormProps.tagNames)
                            })), o.BCw(e, n)
                        };
                    o.if(p, (e => {
                        t.signupFormProps ? .tagNames && t.signupFormProps ? .tagAction && e(v)
                    }));
                    var h = o.hg4(p, 2),
                        m = e => {
                            var n = Pe();
                            o.R0j(n), o.vNg((() => o.to4(n, t.signupFormProps.theme))), o.BCw(e, n)
                        };
                    o.if(h, (e => {
                        t.signupFormProps ? .theme && e(m)
                    }));
                    var f = o.hg4(h, 2);
                    o.R0j(f), o.to4(f, "2.0");
                    var w = o.hg4(f, 4);
                    o.__1(w, 21, a, (({
                        name: e,
                        nativeStyling: t,
                        icon: n,
                        branding: a
                    }) => e), ((e, t) => {
                        let n = () => o.JtY(t).name;
                        const a = o.unG((() => `signup-${n().toLowerCase()}`));
                        (0, s.$n)(e, {
                            class: "w100",
                            type: "submit",
                            get branding() {
                                return o.JtY(t).branding
                            },
                            get "data-testid" () {
                                return o.JtY(a)
                            },
                            get "data-provider" () {
                                return n()
                            },
                            children: (e, a) => {
                                var i = Ee(),
                                    r = o.jfp(i);
                                const l = o.unG((() => o.JtY(t).nativeStyling ? "native" : ""));
                                (0, s.In)(r, {
                                    get class() {
                                        return o.JtY(l)
                                    },
                                    get src() {
                                        return o.JtY(t).icon
                                    }
                                });
                                var c = o.hg4(r);
                                o.cLc(i), o.vNg((e => o.jax(c, ` ${e??""}`)), [() => __tr(["Sign up with $name$"], {
                                    name: n()
                                }, "en", [])]), o.BCw(e, i)
                            },
                            $$slots: {
                                default: !0
                            }
                        })
                    })), o.cLc(w), o.cLc(r), o.vNg((e => {
                        o.aIK(r, "action", e), o.aIK(r, "target", i), o.to4(l, n()), o.to4(d, t.signupFormProps ? .location)
                    }), [() => `/users/signup?ssrc=${t.signupFormProps?.location}&returnurl=${encodeURIComponent(t.returnUrl)}`]), o.f0J("submit", r, (function(...e) {
                        t.onsubmit ? .apply(this, e)
                    })), o.BCw(e, r), o.uYY()
                }
                var Ue = n(39366);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                var Fe = n(54152),
                    Re = (n(76467), o.vUu('<span class="fs-caption fc-black-400 ta-left"> <a href="/legal/terms-of-service/public" target="_blank" rel="noopener noreferrer" class="s-link svelte-9quauz"></a> <a href="/legal/privacy-policy" target="_blank" rel="noopener noreferrer" class="s-link svelte-9quauz"></a>.</span>'));
                const Ye = {
                    hash: "svelte-9quauz",
                    code: "a.svelte-9quauz {outline:none;}"
                };
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const Me = (e, t) => {
                    o.hZp(t, !o.JtY(t))
                };
                var Ie = o.vUu('<p class="flex--item s-input-message" aria-live="assertive"> </p>'),
                    je = o.vUu('<p class="flex--item s-input-message" aria-live="assertive"> </p>'),
                    Le = o.vUu('<form id="signup-modal-signup-form" class="mt32 d-flex fd-column gy16" method="POST"><input type="hidden" name="fkey"/> <input type="hidden" name="legalLinksShown" value="1"/> <input type="hidden" name="ssrc"/> <input type="hidden" name="vote"/> <input type="hidden" name="votehash"/> <input type="hidden" name="tagAction"/> <input type="hidden" name="tagNames"/> <input type="hidden" name="anonTheme"/> <div><label class="flex--item s-label" for="signup-modal-email"></label> <div class="d-flex ps-relative"><input class="s-input" id="signup-modal-email" size="30" maxlength="100" name="email" autocomplete="off"/></div> <!></div> <div><label class="flex--item s-label" for="signup-modal-password"></label> <div class="d-flex ps-relative"><input id="signup-modal-password" class="flex--item s-input" autocomplete="new-password" name="password"/> <button type="button" class="show-hide-password svelte-1rlgrxv"><!></button></div> <!></div> <!> <div><!> <p aria-live="assertive"> </p></div></form>');
                const $e = {
                    hash: "svelte-1rlgrxv",
                    code: ".show-hide-password.svelte-1rlgrxv {position:absolute;top:8px;right:8px;border:none;background:none;padding:0;cursor:pointer;}"
                };

                function ze(e, t) {
                    o.VCO(t, !0), o.kZQ(e, $e);
                    const [n, i] = o.DZI(), l = () => o.Hzn(m, "$errors", n);
                    let c = o._w2(t, "visible", 15),
                        d = o._w2(t, "fkey", 3, ""),
                        u = o._w2(t, "showTermsAndConditions", 3, !1),
                        g = o.wk1(!1),
                        p = o.wk1(""),
                        v = o.wk1(!0);
                    const {
                        form: h,
                        errors: m,
                        reset: f,
                        setFields: w,
                        cleanup: b
                    } = function(e) {
                        const {
                            startStores: t,
                            ...n
                        } = (0, Ue.D)(null != e ? e : {}, {
                            storeFactory: r.T5
                        });
                        return n
                    }({
                        debounced: {
                            timeout: 1e3,
                            validate: (S = () => c(), ({
                                email: e,
                                password: t
                            }) => {
                                const n = {};
                                if (!S()) return {};
                                if (e && "" !== e ? e.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) || (n.email = `${e} is not a valid email address.`) : n.email = "Email cannot be empty.", t && "" !== t)
                                    if (t.length < 8) n.password = "Password must be at least 8 characters long.";
                                    else {
                                        const e = /\d/.test(t),
                                            a = /[a-zA-Z]/.test(t);
                                        e && a || (n.password = "Password must contain at least 1 letter and 1 number.")
                                    }
                                else n.password = "Password cannot be empty.";
                                return n
                            })
                        },
                        onSubmit: (e, {
                            form: t
                        }) => {
                            t && (o.hZp(g, !0), t.submit())
                        },
                        onSuccess: () => {
                            o.hZp(g, !1), c(!1)
                        },
                        onError: () => {
                            o.hZp(g, !1), o.hZp(p, "Something went wrong. Please try again.")
                        }
                    });
                    var S;
                    (0, a.sA)(b), o.MWq((() => {
                        !1 === c() && (f(), o.hZp(p, ""))
                    })), o.MWq((() => {
                        if (t.signupFormProps) {
                            const {
                                location: e,
                                vote: n,
                                voteHash: a,
                                tagAction: i,
                                tagNames: o,
                                theme: s
                            } = t.signupFormProps;
                            w((t => ({ ...t,
                                ssrc: e,
                                vote: n,
                                voteHash: a,
                                tagAction: i,
                                tagNames: o,
                                anonTheme: s
                            })))
                        }
                    }));
                    var y = Le(),
                        k = o.jfp(y);
                    o.R0j(k);
                    var x = o.hg4(k, 2),
                        _ = o.hg4(x, 14),
                        C = o.jfp(_);
                    C.textContent = __tr(["Email"], undefined, "en", []);
                    var T = o.hg4(C, 4),
                        O = e => {
                            var t = Ie(),
                                n = o.jfp(t, !0);
                            o.cLc(t), o.vNg((() => o.jax(n, l().email))), o.BCw(e, t)
                        };
                    o.if(T, (e => {
                        l().email && e(O)
                    })), o.cLc(_);
                    var N = o.hg4(_, 2),
                        P = o.jfp(N);
                    P.textContent = __tr(["Password"], undefined, "en", []);
                    var E = o.hg4(P, 2),
                        A = o.jfp(E);
                    o.aIK(A, "placeholder", __tr(["8+ characters (at least 1 letter & 1 number)"], undefined, "en", []));
                    var B = o.hg4(A, 2);
                    B.__click = [Me, v];
                    var U = o.jfp(B);
                    const F = o.unG((() => o.JtY(v) ? Fe.C7u : Fe.HvQ));
                    (0, s.In)(U, {
                        get src() {
                            return o.JtY(F)
                        }
                    }), o.cLc(B), o.cLc(E);
                    var R = o.hg4(E, 2),
                        Y = e => {
                            var t = je(),
                                n = o.jfp(t, !0);
                            o.cLc(t), o.vNg((() => o.jax(n, l().password))), o.BCw(e, t)
                        };
                    o.if(R, (e => {
                        l().password && e(Y)
                    })), o.cLc(N);
                    var M = o.hg4(N, 2),
                        I = e => {
                            ! function(e) {
                                o.kZQ(e, Ye);
                                var t = Re(),
                                    n = o.jfp(t);
                                n.nodeValue = `${__tr(["By clicking “Sign up”, you agree to our"], undefined, "en", [])??""} `;
                                var a = o.hg4(n);
                                a.textContent = __tr(["terms of service"], undefined, "en", []);
                                var i = o.hg4(a);
                                i.nodeValue = ` ${__tr([" and acknowledge you have read our"], undefined, "en", [])??""} `, o.hg4(i).textContent = __tr(["privacy policy"], undefined, "en", []), o.K2T(), o.cLc(t), o.BCw(e, t)
                            }(e)
                        };
                    o.if(M, (e => {
                        u() && e(I)
                    }));
                    var j = o.hg4(M, 2),
                        L = o.jfp(j);
                    const $ = o.unG((() => `flex--item${u()?"":" mt12"}${o.JtY(g)?" is-loading":""}`));
                    (0, s.$n)(L, {
                        get class() {
                            return o.JtY($)
                        },
                        id: "signup-modal-submit-button",
                        type: "submit",
                        get onclick() {
                            return t.onSubmitButtonClick
                        },
                        weight: "filled",
                        children: (e, t) => {
                            o.K2T();
                            var n = o.Qq7();
                            n.nodeValue = __tr(["Sign up"], undefined, "en", []), o.BCw(e, n)
                        },
                        $$slots: {
                            default: !0
                        }
                    });
                    var z = o.hg4(L, 2),
                        H = o.jfp(z, !0);
                    o.cLc(z), o.cLc(j), o.cLc(y), o.XId(y, (e => h ? .(e))), o.vNg((e => {
                        o.aIK(y, "action", e), o.to4(k, d()), o.ysU(_, 1, "flex--item d-flex fd-column gs4 gsy " + (l().email ? "has-error" : ""), "svelte-1rlgrxv"), o.ysU(N, 1, "flex--item d-flex fd-column gs4 gsy " + (l().password ? "has-error" : ""), "svelte-1rlgrxv"), o.aIK(A, "type", o.JtY(v) ? "password" : "text"), o.ysU(j, 1, "flex--item d-flex gs4 gsy fd-column" + (o.JtY(p) ? " has-error" : ""), "svelte-1rlgrxv"), o.ysU(z, 1, "flex--item s-input-message " + (o.JtY(p) ? "" : "d-none"), "svelte-1rlgrxv"), o.aIK(z, "aria-hidden", o.JtY(p) ? "false" : "true"), o.jax(H, o.JtY(p))
                    }), [() => `/users/signup?ssrc=${t.signupFormProps?.location}&returnurl=${encodeURIComponent(t.returnUrl)}`]), o.BCw(e, y), o.uYY(), i()
                }
                o.MmH(["click"]), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const He = {
                    Google: {
                        name: "Google",
                        oauthServer: "https://accounts.google.com/o/oauth2/auth",
                        icon: Fe.zof,
                        nativeStyling: !0,
                        branding: "google"
                    },
                    GitHub: {
                        name: "GitHub",
                        oauthServer: "https://github.com/login/oauth/authorize",
                        icon: Fe.tx1,
                        nativeStyling: !0,
                        branding: "google"
                    },
                    Facebook: {
                        name: "Facebook",
                        oauthServer: "https://www.facebook.com/v2.0/dialog/oauth",
                        icon: Fe.GAq,
                        nativeStyling: !1,
                        branding: "facebook"
                    }
                };
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                var Je = o.vUu('<div class="d-flex fd-column g8"><span class="flex--item fs-title fw-bold">Your homepage is ready to go!</span> <span class="flex--item fs-body2">Create an account to see your personalized Stack Overflow\n                experience</span></div>'),
                    De = o.vUu('<div data-testid="signup-modal-body"><div class="pb32"><!></div> <!> <!></div>');

                function qe(e, t) {
                    o.VCO(t, !0);
                    const [n, i] = o.DZI();
                    let r = o._w2(t, "visible", 15),
                        l = o.wk1(void 0);
                    (0, a.Rc)((() => {
                        o.hZp(l, {
                            location: "homepage_wizard",
                            tagNames: o.Hzn(d, "$allSelectedTags", n).join(" "),
                            tagAction: "favorite",
                            theme: o.Hzn(c, "$wizardStore", n).theme
                        }, !0)
                    }));
                    const u = e => {
                        let n = e.target;
                        const a = e.submitter.dataset.provider;
                        te(a, "homepage_wizard");
                        n.elements.namedItem("oauth_server").value = He[a].oauthServer, t.oauthInPopup && X.openCenteredPopup("", "oauth-frame", window, 500, 550), n.submit()
                    }; {
                        const n = e => {
                                var t = Je();
                                o.BCw(e, t)
                            },
                            a = e => {
                                var n = De(),
                                    a = o.jfp(n),
                                    i = o.jfp(a);
                                const s = o.unG((() => t.oauthInPopup ? t.returnUrlForPopup : t.returnUrl)),
                                    c = o.unG((() => t.authProviders.map((e => He[e] || null))));
                                Be(i, {
                                    get returnUrl() {
                                        return o.JtY(s)
                                    },
                                    onsubmit: u,
                                    get signupFormProps() {
                                        return o.JtY(l)
                                    },
                                    get fkey() {
                                        return t.fkey
                                    },
                                    get oauthInPopup() {
                                        return t.oauthInPopup
                                    },
                                    get providers() {
                                        return o.JtY(c)
                                    }
                                }), o.cLc(a);
                                var d = o.hg4(a, 2);
                                ! function(e, t) {
                                    o.kZQ(e, Te);
                                    var n = o.Imx(),
                                        a = o.esp(n),
                                        i = e => {
                                            var n = Ce(),
                                                a = o.jfp(n, !0);
                                            o.cLc(n), o.vNg((() => o.jax(a, t.text))), o.BCw(e, n)
                                        };
                                    o.if(a, (e => {
                                        t.text && e(i)
                                    })), o.BCw(e, n)
                                }(d, {
                                    text: "OR"
                                }), ze(o.hg4(d, 2), {
                                    onSubmitButtonClick: () => te("Stack Exchange", "homepage_wizard"),
                                    get signupFormProps() {
                                        return o.JtY(l)
                                    },
                                    get fkey() {
                                        return t.fkey
                                    },
                                    get returnUrl() {
                                        return t.returnUrl
                                    },
                                    showTermsAndConditions: !0,
                                    get visible() {
                                        return r()
                                    },
                                    set visible(e) {
                                        r(e)
                                    }
                                }), o.cLc(n), o.BCw(e, n)
                            };
                        (0, s.aF)(e, o.DuQ({
                            id: "signup-modal",
                            class: "pt32 pr32 pb8 wmx4",
                            preventCloseOnClickOutside: !0
                        }, {}, {
                            get visible() {
                                return r()
                            },
                            set visible(e) {
                                r(e)
                            },
                            $$events: {
                                close(e) {
                                    o.Ibr.call(this, t, e)
                                }
                            },
                            header: n,
                            body: a,
                            $$slots: {
                                header: !0,
                                body: !0
                            }
                        }))
                    }
                    o.uYY(), i()
                }
                var Ve = o.vUu('<p class="s-description mb0 mtn2"><!></p>'),
                    Ge = o.vUu("<div><!></div>"),
                    Ke = o.vUu("<div><!></div>"),
                    Ze = (e, t, n) => t.onRemoveChip(n),
                    Qe = o.vUu('<span role=""> <button class="s-tag--dismiss" type="button" title="Remove chip">x</button></span>'),
                    We = o.vUu('<div class="s-input-icon"><!></div>'),
                    Xe = o.vUu('<p class="s-input-message"><!></p>'),
                    et = o.vUu('<div id="text-input-container"><!> <div class="d-flex"><!> <div class="d-flex ps-relative w100 s-input fw-wrap py4"><!> <span class="chips d-flex gx8 fw-wrap as-start flex__fl-equal svelte-12r9hfl"><!> <input/></span> <!></div></div> <!></div>');
                const tt = {
                    hash: "svelte-12r9hfl",
                    code: ".s-input-icon.svelte-12r9hfl + .chips:where(.svelte-12r9hfl) {margin-left:25px;}"
                };
                o.MmH(["click"]), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const nt = async (e, t) => {
                        await fetch("/users/save-preference", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded"
                            },
                            body: new URLSearchParams({
                                fkey: t,
                                key: "20",
                                value: e.join(" ")
                            }).toString()
                        })
                    },
                    at = async (e, t, n, a) => {
                        const i = function(e, t) {
                            let n = 0;
                            return "dark" === e ? n |= P.Dark : "systemSetting" === e && (n |= P.SystemDefault), t && (n |= P.HighContrastMod), n
                        }(e, t);
                        await fetch("/account/set-theme-preference", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded"
                            },
                            body: new URLSearchParams({
                                fkey: a,
                                accountId: n.toString(),
                                theme: i.toString()
                            }).toString()
                        })
                    };
                var it = o.vUu("<div><!></div>");

                function ot(e, t) {
                    o.VCO(t, !0);
                    const [n, i] = o.DZI(), r = () => o.Hzn(c, "$wizardStore", n);
                    let l = o.wk1(!1),
                        u = o.wk1(void 0),
                        g = o.unG((() => r().step));
                    const p = !Number.isInteger(t.accountId);
                    o.hYb(c, o.vzK(r).theme = t.themePreference, o.vzK(r)), o.MWq((() => {
                        3 === o.JtY(g) && (p ? o.hZp(u, window.setTimeout((() => {
                            c.incrementStep()
                        }), 3e3), !0) : Promise.all([nt(o.Hzn(d, "$allSelectedTags", n), t.fkey), at(r().theme, t.useHighContrastTheme, t.accountId, t.fkey), new Promise((e => setTimeout(e, 3e3)))]).finally((() => window.location.assign(t.homepageUrl))))
                    }));
                    const v = () => {
                        c.reset(), o.hYb(c, o.vzK(r).theme = t.themePreference, o.vzK(r)), clearTimeout(o.JtY(u)), (e => {
                            W("homepage_wizard.dropout", {
                                step: e
                            })
                        })(o.JtY(g)), p || setTimeout((() => window.location.assign(t.homepageUrl)), 0)
                    };
                    (0, a.Rc)((() => {
                        window.addEventListener(t.triggerEvent, (() => {
                            o.hZp(l, !0), W("homepage_wizard.show", {})
                        }))
                    }));
                    var h = it(),
                        m = o.jfp(h),
                        f = e => {
                            ce(e, {
                                get tags() {
                                    return t.tags
                                },
                                get isAnonymousUser() {
                                    return p
                                },
                                get visible() {
                                    return o.JtY(l)
                                },
                                set visible(e) {
                                    o.hZp(l, e, !0)
                                },
                                $$events: {
                                    close: v
                                }
                            })
                        },
                        w = (e, n) => {
                            var a = e => {
                                    he(e, {
                                        get visible() {
                                            return o.JtY(l)
                                        },
                                        set visible(e) {
                                            o.hZp(l, e, !0)
                                        },
                                        $$events: {
                                            close: v
                                        }
                                    })
                                },
                                i = (e, n) => {
                                    var a = e => {
                                            ! function(e, t) {
                                                o.VCO(t, !0);
                                                let n = o._w2(t, "visible", 15, !1),
                                                    a = o.wk1(1);
                                                o.MWq((() => {
                                                    setTimeout((() => {
                                                        o.hZp(a, (o.JtY(a) + 1) % 5 + 1)
                                                    }), 500)
                                                })); {
                                                    const i = e => {
                                                            var t = we();
                                                            o.BCw(e, t)
                                                        },
                                                        r = e => {
                                                            var t = _e(),
                                                                n = o.jfp(t),
                                                                i = o.jfp(n),
                                                                r = e => {
                                                                    var t = be(),
                                                                        n = o.jfp(t);
                                                                    (0, s.In)(n, {
                                                                        get src() {
                                                                            return fe.G28
                                                                        },
                                                                        class: "fc-blue-500"
                                                                    }), o.cLc(t), o.kYK(2, t, (() => me.Rv), (() => ({
                                                                        duration: 200
                                                                    }))), o.kYK(1, t, (() => me.Rv), (() => ({
                                                                        delay: 200
                                                                    }))), o.BCw(e, t)
                                                                },
                                                                l = (e, t) => {
                                                                    var n = e => {
                                                                            var t = Se(),
                                                                                n = o.jfp(t);
                                                                            (0, s.In)(n, {
                                                                                get src() {
                                                                                    return fe.biA
                                                                                },
                                                                                class: "fc-blue-500"
                                                                            }), o.cLc(t), o.kYK(2, t, (() => me.Rv), (() => ({
                                                                                duration: 200
                                                                            }))), o.kYK(1, t, (() => me.Rv), (() => ({
                                                                                delay: 200
                                                                            }))), o.BCw(e, t)
                                                                        },
                                                                        i = (e, t) => {
                                                                            var n = e => {
                                                                                    var t = ye(),
                                                                                        n = o.jfp(t);
                                                                                    (0, s.In)(n, {
                                                                                        get src() {
                                                                                            return fe.GEo
                                                                                        },
                                                                                        class: "fc-blue-500"
                                                                                    }), o.cLc(t), o.kYK(2, t, (() => me.Rv), (() => ({
                                                                                        duration: 200
                                                                                    }))), o.kYK(1, t, (() => me.Rv), (() => ({
                                                                                        delay: 200
                                                                                    }))), o.BCw(e, t)
                                                                                },
                                                                                i = (e, t) => {
                                                                                    var n = e => {
                                                                                            var t = ke(),
                                                                                                n = o.jfp(t);
                                                                                            (0, s.In)(n, {
                                                                                                get src() {
                                                                                                    return fe.dAM
                                                                                                },
                                                                                                class: "fc-blue-500"
                                                                                            }), o.cLc(t), o.kYK(2, t, (() => me.Rv), (() => ({
                                                                                                duration: 200
                                                                                            }))), o.kYK(1, t, (() => me.Rv), (() => ({
                                                                                                delay: 200
                                                                                            }))), o.BCw(e, t)
                                                                                        },
                                                                                        i = (e, t) => {
                                                                                            var n = e => {
                                                                                                var t = xe(),
                                                                                                    n = o.jfp(t);
                                                                                                (0, s.In)(n, {
                                                                                                    get src() {
                                                                                                        return fe.obA
                                                                                                    },
                                                                                                    class: "fc-blue-500"
                                                                                                }), o.cLc(t), o.kYK(2, t, (() => me.Rv), (() => ({
                                                                                                    duration: 200
                                                                                                }))), o.kYK(1, t, (() => me.Rv), (() => ({
                                                                                                    delay: 200
                                                                                                }))), o.BCw(e, t)
                                                                                            };
                                                                                            o.if(e, (e => {
                                                                                                5 === o.JtY(a) && e(n)
                                                                                            }), t)
                                                                                        };
                                                                                    o.if(e, (e => {
                                                                                        4 === o.JtY(a) ? e(n) : e(i, !1)
                                                                                    }), t)
                                                                                };
                                                                            o.if(e, (e => {
                                                                                3 === o.JtY(a) ? e(n) : e(i, !1)
                                                                            }), t)
                                                                        };
                                                                    o.if(e, (e => {
                                                                        2 === o.JtY(a) ? e(n) : e(i, !1)
                                                                    }), t)
                                                                };
                                                            o.if(i, (e => {
                                                                1 === o.JtY(a) ? e(r) : e(l, !1)
                                                            })), o.cLc(n), o.cLc(t), o.BCw(e, t)
                                                        };
                                                    (0, s.aF)(e, o.DuQ({
                                                        id: "signup-modal",
                                                        class: "pt32 pr32 pb32 ws4",
                                                        preventCloseOnClickOutside: !0,
                                                        hideCloseButton: !0
                                                    }, {}, {
                                                        get visible() {
                                                            return n()
                                                        },
                                                        set visible(e) {
                                                            n(e)
                                                        },
                                                        $$events: {
                                                            close(e) {
                                                                o.Ibr.call(this, t, e)
                                                            }
                                                        },
                                                        header: i,
                                                        body: r,
                                                        $$slots: {
                                                            header: !0,
                                                            body: !0
                                                        }
                                                    }))
                                                }
                                                o.uYY()
                                            }(e, {
                                                get visible() {
                                                    return o.JtY(l)
                                                },
                                                set visible(e) {
                                                    o.hZp(l, e, !0)
                                                },
                                                $$events: {
                                                    close: v
                                                }
                                            })
                                        },
                                        i = (e, n) => {
                                            var a = e => {
                                                qe(e, {
                                                    get oauthInPopup() {
                                                        return t.oauthInPopup
                                                    },
                                                    get returnUrlForPopup() {
                                                        return t.returnUrlForPopup
                                                    },
                                                    get returnUrl() {
                                                        return t.returnUrl
                                                    },
                                                    get fkey() {
                                                        return t.fkey
                                                    },
                                                    authProviders: ["Google", "GitHub"],
                                                    get visible() {
                                                        return o.JtY(l)
                                                    },
                                                    set visible(e) {
                                                        o.hZp(l, e, !0)
                                                    },
                                                    $$events: {
                                                        close: v
                                                    }
                                                })
                                            };
                                            o.if(e, (e => {
                                                4 === o.JtY(g) && e(a)
                                            }), n)
                                        };
                                    o.if(e, (e => {
                                        3 === o.JtY(g) ? e(a) : e(i, !1)
                                    }), n)
                                };
                            o.if(e, (e => {
                                2 === o.JtY(g) ? e(a) : e(i, !1)
                            }), n)
                        };
                    o.if(m, (e => {
                        1 === o.JtY(g) ? e(f) : e(w, !1)
                    })), o.cLc(h), o.vNg((() => o.ysU(h, 1, o.$z$(o.JtY(l) ? "disable-document-scroll" : "")))), o.BCw(e, h), o.uYY(), i()
                }
                i("islands/homepage-wizard/index.mod.ts").forEach((e => {
                    var t;
                    t = {
                        isSignupProductEventsEnabled: e.IsSignupProductEventsEnabled
                    }, ee = t.isSignupProductEventsEnabled;
                    const n = document.getElementById(e.ContainerElementId),
                        [i, o] = function(e) {
                            const t = !!(e & P.HighContrastMod);
                            return e & P.Dark ? ["dark", t] : e & P.SystemDefault ? ["systemSetting", t] : ["light", t]
                        }(e.ThemePreferenceFlags);
                    (0, a.Or)(ot, {
                        target: n,
                        props: {
                            fkey: e.FKey,
                            triggerEvent: e.TriggerEvent,
                            oauthInPopup: e.OauthInPopup,
                            returnUrl: e.ReturnUrl,
                            tags: e.Tags,
                            returnUrlForPopup: e.ReturnUrlForPopup,
                            homepageUrl: "/",
                            themePreference: i,
                            useHighContrastTheme: o,
                            accountId: e.AccountId
                        }
                    })
                }))
            },
            53117: (e, t, n) => {
                n.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            54152: (e, t, n) => {
                n.d(t, {
                    Bln: () => r,
                    C0l: () => p,
                    C7u: () => c,
                    GAq: () => d,
                    GBC: () => i,
                    HvQ: () => l,
                    O7Z: () => a,
                    VsF: () => o,
                    nFV: () => s,
                    tx1: () => u,
                    zof: () => g
                });
                const a = '<svg aria-hidden="true" class="svg-icon iconAlert" width="18" height="18"  viewBox="0 0 18 18"><path  d="M7.95 2.71c.58-.94 1.52-.94 2.1 0l7.69 12.58c.58.94.15 1.71-.96 1.71H1.22C.1 17-.32 16.23.26 15.29zM8 6v5h2V6zm0 7v2h2v-2z"/></svg>',
                    i = '<svg aria-hidden="true" class="svg-icon iconAlertCircle" width="18" height="18"  viewBox="0 0 18 18"><path  d="M9 17c-4.36 0-8-3.64-8-8s3.64-8 8-8 8 3.64 8 8-3.64 8-8 8M8 4v6h2V4zm0 8v2h2v-2z"/></svg>',
                    o = '<svg aria-hidden="true" class="svg-icon iconCheckmark" width="18" height="18"  viewBox="0 0 18 18"><path  d="M16 4.41 14.59 3 6 11.59 2.41 8 1 9.41l5 5z"/></svg>',
                    s = '<svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18"  viewBox="0 0 18 18"><path  d="M15 4.41 13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9z"/></svg>',
                    r = '<svg aria-hidden="true" class="svg-icon iconCreditCard" width="18" height="18"  viewBox="0 0 18 18"><path  d="M3 3h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2m0 6v4h12V9zm0-3h12V5H3z"/></svg>',
                    l = '<svg aria-hidden="true" class="svg-icon iconEye" width="18" height="18"  viewBox="0 0 18 18"><path  d="M9.06 3C4 3 1 9 1 9s3 6 8.06 6C14 15 17 9 17 9s-3-6-7.94-6M9 13a4 4 0 1 1 0-8 4 4 0 0 1 0 8m0-2a2 2 0 0 0 2-2 2 2 0 0 0-2-2 2 2 0 0 0-2 2 2 2 0 0 0 2 2"/></svg>',
                    c = '<svg aria-hidden="true" class="svg-icon iconEyeOff" width="18" height="18"  viewBox="0 0 18 18"><path  d="m5.02 9.44-2.22 2.2C1.63 10.25 1 9 1 9s3-6 8.06-6q1.13.01 2.12.38L9.5 5.03 9 5a4 4 0 0 0-3.98 4.44m2.03 3.05A4 4 0 0 0 13 9q-.01-1.1-.54-2l-1.51 1.54q.05.22.05.46a2 2 0 0 1-2.44 1.95zm7.11-7.22A15 15 0 0 1 17 9s-3 6-7.94 6c-1.31 0-2.48-.4-3.5-1l-1.97 2L2 14.41 14.59 2 16 3.41z"/></svg>',
                    d = '<svg aria-hidden="true" class="svg-icon iconFacebook" width="18" height="18"  viewBox="0 0 18 18"><mask id="a" width="24" height="24" x="-3" y="-3" maskUnits="userSpaceOnUse" style="mask-type:luminance"><path fill="var(--white)" d="M-2.2-2.2h22.4v22.4H-2.2z"/></mask><g mask="url(#Facebooka)"><path fill="#0866FF" d="M17 9a8 8 0 1 0-9.93 7.76v-5.32H5.42V9h1.65V7.95c0-2.73 1.23-3.99 3.9-3.99.51 0 1.38.1 1.74.2v2.22q-.3-.03-.92-.03c-1.31 0-1.82.5-1.82 1.79V9h2.61l-.45 2.44H9.97v5.5A8 8 0 0 0 17 9"/><path fill="var(--white)" d="M12.13 11.44 12.58 9H9.97v-.86c0-1.3.5-1.8 1.82-1.8q.62 0 .92.04V4.16c-.36-.1-1.23-.2-1.74-.2-2.67 0-3.9 1.26-3.9 3.99V9H5.42v2.44h1.65v5.32a8 8 0 0 0 2.9.18v-5.5z"/></g></svg>',
                    u = '<svg aria-hidden="true" class="svg-icon iconGitHub" width="18" height="18"  viewBox="0 0 18 18"><path fill="#010101" d="M9 1a8 8 0 0 0-2.53 15.59c.4.07.55-.17.55-.38l-.01-1.49c-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82a7.4 7.4 0 0 1 4 0c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48l-.01 2.2c0 .21.15.46.55.38A8.01 8.01 0 0 0 9 1"/></svg>',
                    g = '<svg aria-hidden="true" class="svg-icon iconGoogle" width="18" height="18"  viewBox="0 0 18 18"><path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18"/><path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 0 1-7.18-2.54H1.83v2.07A8 8 0 0 0 8.98 17"/><path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 0 1 0-3.04V5.41H1.83a8 8 0 0 0 0 7.18z"/><path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 1.83 5.4L4.5 7.49a4.8 4.8 0 0 1 4.48-3.3"/></svg>',
                    p = '<svg aria-hidden="true" class="svg-icon iconSearch" width="18" height="18"  viewBox="0 0 18 18"><path  d="m18 16.5-5.14-5.18h-.35a7 7 0 1 0-1.19 1.19v.35L16.5 18zM12 7A5 5 0 1 1 2 7a5 5 0 0 1 10 0"/></svg>'
            }
        },
        n = {};

    function a(e) {
        var i = n[e];
        if (void 0 !== i) return i.exports;
        var o = n[e] = {
            exports: {}
        };
        return t[e].call(o.exports, o, o.exports, a), o.exports
    }
    a.m = t, e = [], a.O = (t, n, i, o) => {
        if (!n) {
            var s = 1 / 0;
            for (d = 0; d < e.length; d++) {
                for (var [n, i, o] = e[d], r = !0, l = 0; l < n.length; l++)(!1 & o || s >= o) && Object.keys(a.O).every((e => a.O[e](n[l]))) ? n.splice(l--, 1) : (r = !1, o < s && (s = o));
                if (r) {
                    e.splice(d--, 1);
                    var c = i();
                    void 0 !== c && (t = c)
                }
            }
            return t
        }
        o = o || 0;
        for (var d = e.length; d > 0 && e[d - 1][2] > o; d--) e[d] = e[d - 1];
        e[d] = [n, i, o]
    }, a.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return a.d(t, {
            a: t
        }), t
    }, a.d = (e, t) => {
        for (var n in t) a.o(t, n) && !a.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, a.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), a.j = 6894, a.p = "", (() => {
        var e = {
            6894: 0
        };
        a.O.j = t => 0 === e[t];
        var t = (t, n) => {
                var i, o, [s, r, l] = n,
                    c = 0;
                if (s.some((t => 0 !== e[t]))) {
                    for (i in r) a.o(r, i) && (a.m[i] = r[i]);
                    if (l) var d = l(a)
                }
                for (t && t(n); c < s.length; c++) o = s[c], a.o(e, o) && e[o] && e[o][0](), e[o] = 0;
                return a.O(d)
            },
            n = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        n.forEach(t.bind(null, 0)), n.push = t.bind(null, n.push.bind(n))
    })(), a.O(void 0, [5622, 8112, 4365, 8339, 7663, 3696, 2458, 620, 9366, 9001], (() => a(53117)));
    var i = a.O(void 0, [5622, 8112, 4365, 8339, 7663, 3696, 2458, 620, 9366, 9001], (() => a(23738)));
    i = a.O(i)
})();