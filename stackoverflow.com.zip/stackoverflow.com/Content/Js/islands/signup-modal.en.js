(() => {
    "use strict";
    var e, t = {
            92278: (e, t, a) => {
                var o = a(22024);

                function n(e) {
                    const t = function(e) {
                        const t = e.replace(/\.(t|j)sx?/, ""),
                            a = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                        return document.querySelectorAll(a)
                    }(e);
                    return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
                }
                a(82170);
                var r = a(67578),
                    s = a(99724),
                    i = r.vUu('<h1 class="svelte-1mm1u63"> </h1>');
                const l = {
                    hash: "svelte-1mm1u63",
                    code: "h1.svelte-1mm1u63 {font-size:13px;font-weight:400;overflow:hidden;text-align:center;color:var(--black-400);}h1.svelte-1mm1u63:before,\n    h1.svelte-1mm1u63:after {content:'';display:inline-block;width:50%;margin:0 0.5em 0 -55%;vertical-align:middle;border-bottom:1px solid;border-color:var(--black-225);}h1.svelte-1mm1u63:after {margin:0 -55% 0 0.5em;}"
                };
                var c = r.vUu('<input type="hidden" name="vote"/> <input type="hidden" name="votehash"/>', 1),
                    d = r.vUu('<input type="hidden" name="tagAction"/> <input type="hidden" name="tagNames"/>', 1),
                    p = r.vUu('<input type="hidden" name="anonTheme"/>'),
                    u = r.vUu('<div class="d-flex ai-center jc-center gx8"><!> </div>'),
                    g = r.vUu('<form class="flex--item" method="POST"><input type="hidden" name="fkey"/> <input type="hidden" name="legalLinksShown" value="1"/> <input type="hidden" name="ssrc"/> <!> <!> <!> <input type="hidden" name="oauth_version"/> <input type="hidden" name="oauth_server"/> <div class="d-flex fd-column gy12"></div></form>');

                function v(e, t) {
                    r.VCO(t, !0);
                    const a = r._w2(t, "fkey", 3, ""),
                        o = r._w2(t, "providers", 19, (() => []));
                    let n = t.oauthInPopup ? "oauth-frame" : "_self";
                    var i = g(),
                        l = r.jfp(i);
                    r.R0j(l);
                    var v = r.hg4(l, 2),
                        h = r.hg4(v, 2);
                    r.R0j(h);
                    var m = r.hg4(h, 2),
                        f = e => {
                            var a = c(),
                                o = r.esp(a);
                            r.R0j(o);
                            var n = r.hg4(o, 2);
                            r.R0j(n), r.vNg((() => {
                                r.to4(o, t.signupFormProps.vote), r.to4(n, t.signupFormProps.voteHash)
                            })), r.BCw(e, a)
                        };
                    r.if(m, (e => {
                        t.signupFormProps ? .vote && t.signupFormProps ? .voteHash && e(f)
                    }));
                    var w = r.hg4(m, 2),
                        k = e => {
                            var a = d(),
                                o = r.esp(a);
                            r.R0j(o);
                            var n = r.hg4(o, 2);
                            r.R0j(n), r.vNg((() => {
                                r.to4(o, t.signupFormProps.tagAction), r.to4(n, t.signupFormProps.tagNames)
                            })), r.BCw(e, a)
                        };
                    r.if(w, (e => {
                        t.signupFormProps ? .tagNames && t.signupFormProps ? .tagAction && e(k)
                    }));
                    var b = r.hg4(w, 2),
                        x = e => {
                            var a = p();
                            r.R0j(a), r.vNg((() => r.to4(a, t.signupFormProps.theme))), r.BCw(e, a)
                        };
                    r.if(b, (e => {
                        t.signupFormProps ? .theme && e(x)
                    }));
                    var y = r.hg4(b, 2);
                    r.R0j(y), r.to4(y, "2.0");
                    var S = r.hg4(y, 4);
                    r.__1(S, 21, o, (({
                        name: e,
                        nativeStyling: t,
                        icon: a,
                        branding: o
                    }) => e), ((e, t) => {
                        let a = () => r.JtY(t).name;
                        const o = r.unG((() => `signup-${a().toLowerCase()}`));
                        (0, s.$n)(e, {
                            class: "w100",
                            type: "submit",
                            get branding() {
                                return r.JtY(t).branding
                            },
                            get "data-testid" () {
                                return r.JtY(o)
                            },
                            get "data-provider" () {
                                return a()
                            },
                            children: (e, o) => {
                                var n = u(),
                                    i = r.jfp(n);
                                const l = r.unG((() => r.JtY(t).nativeStyling ? "native" : ""));
                                (0, s.In)(i, {
                                    get class() {
                                        return r.JtY(l)
                                    },
                                    get src() {
                                        return r.JtY(t).icon
                                    }
                                });
                                var c = r.hg4(i);
                                r.cLc(n), r.vNg((e => r.jax(c, ` ${e??""}`)), [() => __tr(["Sign up with $name$"], {
                                    name: a()
                                }, "en", [])]), r.BCw(e, n)
                            },
                            $$slots: {
                                default: !0
                            }
                        })
                    })), r.cLc(S), r.cLc(i), r.vNg((e => {
                        r.aIK(i, "action", e), r.aIK(i, "target", n), r.to4(l, a()), r.to4(h, t.signupFormProps ? .location)
                    }), [() => `/users/signup?ssrc=${t.signupFormProps?.location}&returnurl=${encodeURIComponent(t.returnUrl)}`]), r.f0J("submit", i, (function(...e) {
                        t.onsubmit ? .apply(this, e)
                    })), r.BCw(e, i), r.uYY()
                }
                var h = a(39366),
                    m = a(85630);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                var f = a(54152),
                    w = (a(76467), r.vUu('<span class="fs-caption fc-black-400 ta-left"> <a href="/legal/terms-of-service/public" target="_blank" rel="noopener noreferrer" class="s-link svelte-9quauz"></a> <a href="/legal/privacy-policy" target="_blank" rel="noopener noreferrer" class="s-link svelte-9quauz"></a>.</span>'));
                const k = {
                    hash: "svelte-9quauz",
                    code: "a.svelte-9quauz {outline:none;}"
                };

                function b(e) {
                    r.kZQ(e, k);
                    var t = w(),
                        a = r.jfp(t);
                    a.nodeValue = `${__tr(["By clicking “Sign up”, you agree to our"], undefined, "en", [])??""} `;
                    var o = r.hg4(a);
                    o.textContent = __tr(["terms of service"], undefined, "en", []);
                    var n = r.hg4(o);
                    n.nodeValue = ` ${__tr([" and acknowledge you have read our"], undefined, "en", [])??""} `, r.hg4(n).textContent = __tr(["privacy policy"], undefined, "en", []), r.K2T(), r.cLc(t), r.BCw(e, t)
                }
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const x = (e, t) => {
                    r.hZp(t, !r.JtY(t))
                };
                var y = r.vUu('<p class="flex--item s-input-message" aria-live="assertive"> </p>'),
                    S = r.vUu('<p class="flex--item s-input-message" aria-live="assertive"> </p>'),
                    _ = r.vUu('<form id="signup-modal-signup-form" class="mt32 d-flex fd-column gy16" method="POST"><input type="hidden" name="fkey"/> <input type="hidden" name="legalLinksShown" value="1"/> <input type="hidden" name="ssrc"/> <input type="hidden" name="vote"/> <input type="hidden" name="votehash"/> <input type="hidden" name="tagAction"/> <input type="hidden" name="tagNames"/> <input type="hidden" name="anonTheme"/> <div><label class="flex--item s-label" for="signup-modal-email"></label> <div class="d-flex ps-relative"><input class="s-input" id="signup-modal-email" size="30" maxlength="100" name="email" autocomplete="off"/></div> <!></div> <div><label class="flex--item s-label" for="signup-modal-password"></label> <div class="d-flex ps-relative"><input id="signup-modal-password" class="flex--item s-input" autocomplete="new-password" name="password"/> <button type="button" class="show-hide-password svelte-1rlgrxv"><!></button></div> <!></div> <!> <div><!> <p aria-live="assertive"> </p></div></form>');
                const E = {
                    hash: "svelte-1rlgrxv",
                    code: ".show-hide-password.svelte-1rlgrxv {position:absolute;top:8px;right:8px;border:none;background:none;padding:0;cursor:pointer;}"
                };

                function P(e, t) {
                    r.VCO(t, !0), r.kZQ(e, E);
                    const [a, n] = r.DZI(), i = () => r.Hzn(w, "$errors", a);
                    let l = r._w2(t, "visible", 15),
                        c = r._w2(t, "fkey", 3, ""),
                        d = r._w2(t, "showTermsAndConditions", 3, !1),
                        p = r.wk1(!1),
                        u = r.wk1(""),
                        g = r.wk1(!0);
                    const {
                        form: v,
                        errors: w,
                        reset: k,
                        setFields: P,
                        cleanup: C
                    } = function(e) {
                        const {
                            startStores: t,
                            ...a
                        } = (0, h.D)(null != e ? e : {}, {
                            storeFactory: m.T5
                        });
                        return a
                    }({
                        debounced: {
                            timeout: 1e3,
                            validate: (O = () => l(), ({
                                email: e,
                                password: t
                            }) => {
                                const a = {};
                                if (!O()) return {};
                                if (e && "" !== e ? e.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) || (a.email = `${e} is not a valid email address.`) : a.email = "Email cannot be empty.", t && "" !== t)
                                    if (t.length < 8) a.password = "Password must be at least 8 characters long.";
                                    else {
                                        const e = /\d/.test(t),
                                            o = /[a-zA-Z]/.test(t);
                                        e && o || (a.password = "Password must contain at least 1 letter and 1 number.")
                                    }
                                else a.password = "Password cannot be empty.";
                                return a
                            })
                        },
                        onSubmit: (e, {
                            form: t
                        }) => {
                            t && (r.hZp(p, !0), t.submit())
                        },
                        onSuccess: () => {
                            r.hZp(p, !1), l(!1)
                        },
                        onError: () => {
                            r.hZp(p, !1), r.hZp(u, "Something went wrong. Please try again.")
                        }
                    });
                    var O;
                    (0, o.sA)(C), r.MWq((() => {
                        !1 === l() && (k(), r.hZp(u, ""))
                    })), r.MWq((() => {
                        if (t.signupFormProps) {
                            const {
                                location: e,
                                vote: a,
                                voteHash: o,
                                tagAction: n,
                                tagNames: r,
                                theme: s
                            } = t.signupFormProps;
                            P((t => ({ ...t,
                                ssrc: e,
                                vote: a,
                                voteHash: o,
                                tagAction: n,
                                tagNames: r,
                                anonTheme: s
                            })))
                        }
                    }));
                    var j = _(),
                        U = r.jfp(j);
                    r.R0j(U);
                    var L = r.hg4(U, 2),
                        $ = r.hg4(L, 14),
                        I = r.jfp($);
                    I.textContent = __tr(["Email"], undefined, "en", []);
                    var N = r.hg4(I, 4),
                        F = e => {
                            var t = y(),
                                a = r.jfp(t, !0);
                            r.cLc(t), r.vNg((() => r.jax(a, i().email))), r.BCw(e, t)
                        };
                    r.if(N, (e => {
                        i().email && e(F)
                    })), r.cLc($);
                    var B = r.hg4($, 2),
                        J = r.jfp(B);
                    J.textContent = __tr(["Password"], undefined, "en", []);
                    var Y = r.hg4(J, 2),
                        A = r.jfp(Y);
                    r.aIK(A, "placeholder", __tr(["8+ characters (at least 1 letter & 1 number)"], undefined, "en", []));
                    var H = r.hg4(A, 2);
                    H.__click = [x, g];
                    var V = r.jfp(H);
                    const z = r.unG((() => r.JtY(g) ? f.C7u : f.HvQ));
                    (0, s.In)(V, {
                        get src() {
                            return r.JtY(z)
                        }
                    }), r.cLc(H), r.cLc(Y);
                    var D = r.hg4(Y, 2),
                        q = e => {
                            var t = S(),
                                a = r.jfp(t, !0);
                            r.cLc(t), r.vNg((() => r.jax(a, i().password))), r.BCw(e, t)
                        };
                    r.if(D, (e => {
                        i().password && e(q)
                    })), r.cLc(B);
                    var M = r.hg4(B, 2),
                        R = e => {
                            b(e)
                        };
                    r.if(M, (e => {
                        d() && e(R)
                    }));
                    var T = r.hg4(M, 2),
                        G = r.jfp(T);
                    const K = r.unG((() => `flex--item${d()?"":" mt12"}${r.JtY(p)?" is-loading":""}`));
                    (0, s.$n)(G, {
                        get class() {
                            return r.JtY(K)
                        },
                        id: "signup-modal-submit-button",
                        type: "submit",
                        get onclick() {
                            return t.onSubmitButtonClick
                        },
                        weight: "filled",
                        children: (e, t) => {
                            r.K2T();
                            var a = r.Qq7();
                            a.nodeValue = __tr(["Sign up"], undefined, "en", []), r.BCw(e, a)
                        },
                        $$slots: {
                            default: !0
                        }
                    });
                    var Z = r.hg4(G, 2),
                        Q = r.jfp(Z, !0);
                    r.cLc(Z), r.cLc(T), r.cLc(j), r.XId(j, (e => v ? .(e))), r.vNg((e => {
                        r.aIK(j, "action", e), r.to4(U, c()), r.ysU($, 1, "flex--item d-flex fd-column gs4 gsy " + (i().email ? "has-error" : ""), "svelte-1rlgrxv"), r.ysU(B, 1, "flex--item d-flex fd-column gs4 gsy " + (i().password ? "has-error" : ""), "svelte-1rlgrxv"), r.aIK(A, "type", r.JtY(g) ? "password" : "text"), r.ysU(T, 1, "flex--item d-flex gs4 gsy fd-column" + (r.JtY(u) ? " has-error" : ""), "svelte-1rlgrxv"), r.ysU(Z, 1, "flex--item s-input-message " + (r.JtY(u) ? "" : "d-none"), "svelte-1rlgrxv"), r.aIK(Z, "aria-hidden", r.JtY(u) ? "false" : "true"), r.jax(Q, r.JtY(u))
                    }), [() => `/users/signup?ssrc=${t.signupFormProps?.location}&returnurl=${encodeURIComponent(t.returnUrl)}`]), r.BCw(e, j), r.uYY(), n()
                }
                r.MmH(["click"]), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const C = {
                    Google: {
                        name: "Google",
                        oauthServer: "https://accounts.google.com/o/oauth2/auth",
                        icon: f.zof,
                        nativeStyling: !0,
                        branding: "google"
                    },
                    GitHub: {
                        name: "GitHub",
                        oauthServer: "https://github.com/login/oauth/authorize",
                        icon: f.tx1,
                        nativeStyling: !0,
                        branding: "google"
                    },
                    Facebook: {
                        name: "Facebook",
                        oauthServer: "https://www.facebook.com/v2.0/dialog/oauth",
                        icon: f.GAq,
                        nativeStyling: !1,
                        branding: "facebook"
                    }
                };
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const O = (e, t) => {
                        window.StackExchange.using("gps", (() => {
                            window.StackExchange.gps.track(e, t)
                        }))
                    },
                    j = (e, t, a) => {
                        ! function(e, t, a, o) {
                            const n = new FormData;
                            n.append("fKey", null != o ? o : StackExchange.options.user.fkey), n.append("data", JSON.stringify(t)), n.append("event", e);
                            let r = {};
                            a && (r["X-Previous-Event-Id"] = a), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                                method: "POST",
                                keepalive: !0,
                                body: n,
                                headers: r
                            }).then((() => {}))
                        }(e, {
                            source: window.location.href,
                            ...t
                        }, void 0, a)
                    },
                    U = {
                        openCenteredPopup: function(e, t, a, o, n) {
                            const r = a.top.outerHeight / 2 + a.top.screenY - n / 2,
                                s = a.top.outerWidth / 2 + a.top.screenX - o / 2;
                            return a.open(e, t, `toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=${o}, height=${n}, top=${r}, left=${s}`)
                        }
                    };
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                let L = !1;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const $ = (e, t) => {
                    O("signup.start", {
                        openid_provider: e,
                        location: t
                    }), L && j("signup.start", {
                        openIdProvider: e,
                        location: t
                    })
                };
                var I = r.vUu('<div class="s-modal--header d-flex g4 mt8 ai-center"><img class="h48 w48 native" alt="site logo"/> <span class="fs-headline1 mb0 fc-black-700"><strong> </strong></span></div>'),
                    N = r.vUu('<div class="pb32"><!></div> <!>', 1),
                    F = r.vUu('<div class="wmx4 pl8"><div class="mb24"><!></div> <!> <!></div>'),
                    B = r.vUu('<div class="fs-body1 pl8"> <a href="/users/login" class="s-link"></a></div>');

                function J(e, t) {
                    r.VCO(t, !0);
                    let a = r._w2(t, "visible", 15),
                        o = r._w2(t, "siteName", 3, "Stack Exchange"),
                        n = r._w2(t, "authProviders", 19, (() => [])),
                        c = r._w2(t, "title", 19, (() => __tr(["Join $siteName$"], {
                            siteName: o()
                        }, "en", [])));
                    const d = e => {
                            e.target.src = "https://stackoverflow.com/Content/Img/SE-logo75.png"
                        },
                        p = e => {
                            let a = e.target;
                            const o = e.submitter.dataset.provider;
                            $(o, t.triggerEventDetails.location);
                            a.elements.namedItem("oauth_server").value = C[o].oauthServer, t.oauthInPopup && U.openCenteredPopup("", "oauth-frame", window, 500, 550), a.submit()
                        },
                        u = () => {
                            $("Stack Exchange", t.triggerEventDetails.location)
                        }; {
                        const o = e => {
                                var a = I(),
                                    o = r.jfp(a),
                                    n = r.hg4(o, 2),
                                    s = r.jfp(n),
                                    i = r.jfp(s, !0);
                                r.cLc(s), r.cLc(n), r.cLc(a), r.vNg((() => {
                                    r.aIK(o, "src", t.siteLogoPath), r.jax(i, c())
                                })), r.f0J("error", o, d), r.ES0(o), r.BCw(e, a)
                            },
                            g = e => {
                                var o = F(),
                                    s = r.jfp(o);
                                b(r.jfp(s)), r.cLc(s);
                                var c = r.hg4(s, 2),
                                    d = e => {
                                        var a = N(),
                                            o = r.esp(a),
                                            s = r.jfp(o);
                                        const c = r.unG((() => t.oauthInPopup ? t.returnUrlForPopup : t.returnUrl)),
                                            d = r.unG((() => n().map((e => C[e] || null))));
                                        v(s, {
                                                get returnUrl() {
                                                    return r.JtY(c)
                                                },
                                                onsubmit: p,
                                                get fkey() {
                                                    return t.fkey
                                                },
                                                get oauthInPopup() {
                                                    return t.oauthInPopup
                                                },
                                                get signupFormProps() {
                                                    return t.triggerEventDetails
                                                },
                                                get providers() {
                                                    return r.JtY(d)
                                                }
                                            }), r.cLc(o),
                                            function(e, t) {
                                                r.kZQ(e, l);
                                                var a = r.Imx(),
                                                    o = r.esp(a),
                                                    n = e => {
                                                        var a = i(),
                                                            o = r.jfp(a, !0);
                                                        r.cLc(a), r.vNg((() => r.jax(o, t.text))), r.BCw(e, a)
                                                    };
                                                r.if(o, (e => {
                                                    t.text && e(n)
                                                })), r.BCw(e, a)
                                            }(r.hg4(o, 2), {
                                                text: "OR"
                                            }), r.BCw(e, a)
                                    };
                                r.if(c, (e => {
                                    n().length && e(d)
                                })), P(r.hg4(c, 2), {
                                    onSubmitButtonClick: u,
                                    get fkey() {
                                        return t.fkey
                                    },
                                    get signupFormProps() {
                                        return t.triggerEventDetails
                                    },
                                    get returnUrl() {
                                        return t.returnUrl
                                    },
                                    get visible() {
                                        return a()
                                    },
                                    set visible(e) {
                                        a(e)
                                    }
                                }), r.cLc(o), r.BCw(e, o)
                            },
                            h = e => {
                                var t = B(),
                                    a = r.jfp(t);
                                a.nodeValue = `${__tr(["Already have an account?"], undefined, "en", [])??""}  `, r.hg4(a).textContent = __tr(["Log in"], undefined, "en", []), r.cLc(t), r.BCw(e, t)
                            };
                        (0, s.aF)(e, r.DuQ({
                            id: "signup-modal",
                            class: "pt32 pr32 pb32"
                        }, {}, {
                            get visible() {
                                return a()
                            },
                            set visible(e) {
                                a(e)
                            },
                            $$events: {
                                close(...e) {
                                    t.onDismiss ? .apply(this, e)
                                }
                            },
                            header: o,
                            body: g,
                            footer: h,
                            $$slots: {
                                header: !0,
                                body: !0,
                                footer: !0
                            }
                        }))
                    }
                    r.uYY()
                }
                var Y = r.vUu('<div class="s-modal--header d-flex g4 mt8 ai-center"><img class="h48 w48 native" alt="site logo"/> <span class="fs-headline1 mb0 fc-black-700"><strong> </strong></span></div>'),
                    A = (e, t) => $("Stack Exchange", t.triggerEventDetails.location),
                    H = r.vUu('<div class="wmx4 pl8"><p></p> <a class="flex--item s-btn s-btn__filled mt12 w100" id="signup-modal-signup-link"></a></div>'),
                    V = r.vUu('<div class="fs-body1 pl8"> <a class="s-link"></a></div>');

                function z(e, t) {
                    r.VCO(t, !0);
                    let a = r._w2(t, "fkey", 3, ""),
                        n = r._w2(t, "oauthInPopup", 3, !0),
                        i = r._w2(t, "visible", 15, !1),
                        l = r.wk1(void 0),
                        c = r.wk1("");
                    const d = e => {
                            const a = e.detail;
                            r.hZp(l, { ...a
                            }, !0), r.hZp(c, r.JtY(l).overrideTitle ? ? __tr(["Join $siteName$"], {
                                siteName: t.siteName
                            }, "en", []), !0), i(!0), O("signup_modal.show", {})
                        },
                        p = () => {
                            i(!1), O("signup_modal.dismiss", {})
                        };
                    (0, o.Rc)((() => (window.addEventListener(t.triggerEvent, d), () => {
                        window.removeEventListener(t.triggerEvent, d)
                    })));
                    var u = r.Imx(),
                        g = r.esp(u),
                        v = e => {
                            ! function(e, t) {
                                r.VCO(t, !0);
                                let a = r._w2(t, "visible", 15),
                                    o = r._w2(t, "siteName", 3, "Stack Exchange"),
                                    n = r._w2(t, "parentSiteUrl", 3, "");
                                const i = e => {
                                    e.target.src = "https://stackoverflow.com/Content/Img/SE-logo75.png"
                                }; {
                                    const l = e => {
                                            var a = Y(),
                                                n = r.jfp(a),
                                                s = r.hg4(n, 2),
                                                l = r.jfp(s),
                                                c = r.jfp(l, !0);
                                            r.cLc(l), r.cLc(s), r.cLc(a), r.vNg((e => {
                                                r.aIK(n, "src", t.siteLogoPath), r.jax(c, e)
                                            }), [() => __tr(["Join $siteName$"], {
                                                siteName: o()
                                            }, "en", [])]), r.f0J("error", n, i), r.ES0(n), r.BCw(e, a)
                                        },
                                        c = e => {
                                            var a = H(),
                                                o = r.jfp(a);
                                            o.textContent = __tr(["Joining the parent site gives you automatic access to this meta. Please follow the link below to sign up."], undefined, "en", []);
                                            var s = r.hg4(o, 2);
                                            s.__click = [A, t], s.textContent = __tr(["Continue to sign up"], undefined, "en", []), r.cLc(a), r.vNg((() => r.aIK(s, "href", `${n()}?signup=true`))), r.BCw(e, a)
                                        },
                                        d = e => {
                                            var t = V(),
                                                a = r.jfp(t);
                                            a.nodeValue = `${__tr(["Already have an account?"], undefined, "en", [])??""}  `;
                                            var o = r.hg4(a);
                                            o.textContent = __tr(["Log in"], undefined, "en", []), r.cLc(t), r.vNg((() => r.aIK(o, "href", `${n()}/users/login`))), r.BCw(e, t)
                                        };
                                    (0, s.aF)(e, r.DuQ({
                                        id: "signup-modal",
                                        class: "pt32 pr32 pb32"
                                    }, {}, {
                                        get visible() {
                                            return a()
                                        },
                                        set visible(e) {
                                            a(e)
                                        },
                                        $$events: {
                                            close(...e) {
                                                t.onDismiss ? .apply(this, e)
                                            }
                                        },
                                        header: l,
                                        body: c,
                                        footer: d,
                                        $$slots: {
                                            header: !0,
                                            body: !0,
                                            footer: !0
                                        }
                                    }))
                                }
                                r.uYY()
                            }(e, {
                                get visible() {
                                    return i()
                                },
                                onDismiss: p,
                                get triggerEventDetails() {
                                    return r.JtY(l)
                                },
                                get siteName() {
                                    return t.siteName
                                },
                                get siteLogoPath() {
                                    return t.siteLogoPath
                                },
                                get parentSiteUrl() {
                                    return t.parentSiteUrl
                                }
                            })
                        },
                        h = e => {
                            J(e, {
                                get visible() {
                                    return i()
                                },
                                onDismiss: p,
                                get returnUrl() {
                                    return t.returnUrl
                                },
                                get returnUrlForPopup() {
                                    return t.returnUrlForPopup
                                },
                                get fkey() {
                                    return a()
                                },
                                get oauthInPopup() {
                                    return n()
                                },
                                get triggerEventDetails() {
                                    return r.JtY(l)
                                },
                                get siteName() {
                                    return t.siteName
                                },
                                get siteLogoPath() {
                                    return t.siteLogoPath
                                },
                                get authProviders() {
                                    return t.authProviders
                                },
                                get title() {
                                    return r.JtY(c)
                                }
                            })
                        };
                    r.if(g, (e => {
                        t.parentSiteUrl ? e(v) : e(h, !1)
                    })), r.BCw(e, u), r.uYY()
                }
                r.MmH(["click"]), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                n("islands/signup-modal/index.mod.ts").forEach((e => {
                    var t;
                    t = {
                        isSignupProductEventsEnabled: e.IsSignupProductEventsEnabled
                    }, L = t.isSignupProductEventsEnabled;
                    const a = document.getElementById(e.ContainerElementId);
                    (0, o.Or)(z, {
                        target: a,
                        props: {
                            fkey: e.FKey,
                            triggerEvent: e.TriggerEvent,
                            oauthInPopup: e.OauthInPopup,
                            returnUrl: e.ReturnUrl,
                            returnUrlForPopup: e.ReturnUrlForPopup,
                            siteName: e.SiteName,
                            siteLogoPath: e.SiteLogoPath,
                            authProviders: e.AuthProviders,
                            parentSiteUrl: e.ParentSiteUrl,
                            visible: e.IsInitiallyVisible
                        }
                    })
                }))
            },
            53117: (e, t, a) => {
                a.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            54152: (e, t, a) => {
                a.d(t, {
                    C7u: () => r,
                    GAq: () => s,
                    HvQ: () => n,
                    nFV: () => o,
                    tx1: () => i,
                    zof: () => l
                });
                const o = '<svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18"  viewBox="0 0 18 18"><path  d="M15 4.41 13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9z"/></svg>',
                    n = '<svg aria-hidden="true" class="svg-icon iconEye" width="18" height="18"  viewBox="0 0 18 18"><path  d="M9.06 3C4 3 1 9 1 9s3 6 8.06 6C14 15 17 9 17 9s-3-6-7.94-6M9 13a4 4 0 1 1 0-8 4 4 0 0 1 0 8m0-2a2 2 0 0 0 2-2 2 2 0 0 0-2-2 2 2 0 0 0-2 2 2 2 0 0 0 2 2"/></svg>',
                    r = '<svg aria-hidden="true" class="svg-icon iconEyeOff" width="18" height="18"  viewBox="0 0 18 18"><path  d="m5.02 9.44-2.22 2.2C1.63 10.25 1 9 1 9s3-6 8.06-6q1.13.01 2.12.38L9.5 5.03 9 5a4 4 0 0 0-3.98 4.44m2.03 3.05A4 4 0 0 0 13 9q-.01-1.1-.54-2l-1.51 1.54q.05.22.05.46a2 2 0 0 1-2.44 1.95zm7.11-7.22A15 15 0 0 1 17 9s-3 6-7.94 6c-1.31 0-2.48-.4-3.5-1l-1.97 2L2 14.41 14.59 2 16 3.41z"/></svg>',
                    s = '<svg aria-hidden="true" class="svg-icon iconFacebook" width="18" height="18"  viewBox="0 0 18 18"><mask id="a" width="24" height="24" x="-3" y="-3" maskUnits="userSpaceOnUse" style="mask-type:luminance"><path fill="var(--white)" d="M-2.2-2.2h22.4v22.4H-2.2z"/></mask><g mask="url(#Facebooka)"><path fill="#0866FF" d="M17 9a8 8 0 1 0-9.93 7.76v-5.32H5.42V9h1.65V7.95c0-2.73 1.23-3.99 3.9-3.99.51 0 1.38.1 1.74.2v2.22q-.3-.03-.92-.03c-1.31 0-1.82.5-1.82 1.79V9h2.61l-.45 2.44H9.97v5.5A8 8 0 0 0 17 9"/><path fill="var(--white)" d="M12.13 11.44 12.58 9H9.97v-.86c0-1.3.5-1.8 1.82-1.8q.62 0 .92.04V4.16c-.36-.1-1.23-.2-1.74-.2-2.67 0-3.9 1.26-3.9 3.99V9H5.42v2.44h1.65v5.32a8 8 0 0 0 2.9.18v-5.5z"/></g></svg>',
                    i = '<svg aria-hidden="true" class="svg-icon iconGitHub" width="18" height="18"  viewBox="0 0 18 18"><path fill="#010101" d="M9 1a8 8 0 0 0-2.53 15.59c.4.07.55-.17.55-.38l-.01-1.49c-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82a7.4 7.4 0 0 1 4 0c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48l-.01 2.2c0 .21.15.46.55.38A8.01 8.01 0 0 0 9 1"/></svg>',
                    l = '<svg aria-hidden="true" class="svg-icon iconGoogle" width="18" height="18"  viewBox="0 0 18 18"><path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18"/><path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 0 1-7.18-2.54H1.83v2.07A8 8 0 0 0 8.98 17"/><path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 0 1 0-3.04V5.41H1.83a8 8 0 0 0 0 7.18z"/><path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 1.83 5.4L4.5 7.49a4.8 4.8 0 0 1 4.48-3.3"/></svg>'
            },
            34164: (e, t, a) => {
                function o(e) {
                    var t, a, n = "";
                    if ("string" == typeof e || "number" == typeof e) n += e;
                    else if ("object" == typeof e)
                        if (Array.isArray(e)) {
                            var r = e.length;
                            for (t = 0; t < r; t++) e[t] && (a = o(e[t])) && (n && (n += " "), n += a)
                        } else
                            for (a in e) e[a] && (n && (n += " "), n += a);
                    return n
                }

                function n() {
                    for (var e, t, a = 0, n = "", r = arguments.length; a < r; a++)(e = arguments[a]) && (t = o(e)) && (n && (n += " "), n += t);
                    return n
                }
                a.d(t, {
                    $: () => n
                })
            },
            74488: (e, t, a) => {
                a.d(t, {
                    h5: () => o,
                    IJ: () => r
                });
                const o = !0,
                    n = globalThis.process ? .env ? .NODE_ENV,
                    r = n && !n.toLowerCase().startsWith("prod")
            },
            2322: (e, t, a) => {
                a(85630), a(22024)
            }
        },
        a = {};

    function o(e) {
        var n = a[e];
        if (void 0 !== n) return n.exports;
        var r = a[e] = {
            exports: {}
        };
        return t[e](r, r.exports, o), r.exports
    }
    o.m = t, e = [], o.O = (t, a, n, r) => {
        if (!a) {
            var s = 1 / 0;
            for (d = 0; d < e.length; d++) {
                for (var [a, n, r] = e[d], i = !0, l = 0; l < a.length; l++)(!1 & r || s >= r) && Object.keys(o.O).every((e => o.O[e](a[l]))) ? a.splice(l--, 1) : (i = !1, r < s && (s = r));
                if (i) {
                    e.splice(d--, 1);
                    var c = n();
                    void 0 !== c && (t = c)
                }
            }
            return t
        }
        r = r || 0;
        for (var d = e.length; d > 0 && e[d - 1][2] > r; d--) e[d] = e[d - 1];
        e[d] = [a, n, r]
    }, o.d = (e, t) => {
        for (var a in t) o.o(t, a) && !o.o(e, a) && Object.defineProperty(e, a, {
            enumerable: !0,
            get: t[a]
        })
    }, o.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), o.j = 5878, o.p = "", (() => {
        var e = {
            5878: 0
        };
        o.O.j = t => 0 === e[t];
        var t = (t, a) => {
                var n, r, [s, i, l] = a,
                    c = 0;
                if (s.some((t => 0 !== e[t]))) {
                    for (n in i) o.o(i, n) && (o.m[n] = i[n]);
                    if (l) var d = l(o)
                }
                for (t && t(a); c < s.length; c++) r = s[c], o.o(e, r) && e[r] && e[r][0](), e[r] = 0;
                return o.O(d)
            },
            a = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        a.forEach(t.bind(null, 0)), a.push = t.bind(null, a.push.bind(a))
    })(), o.O(void 0, [5622, 8112, 9366], (() => o(53117)));
    var n = o.O(void 0, [5622, 8112, 9366], (() => o(92278)));
    n = o.O(n)
})();