(() => {
    var e, t, a, r, o, n = {
            53536: (e, t, a) => {
                var r = {
                    "./datepicker-af.js": [60242, 3431, 7334],
                    "./datepicker-ar-DZ.js": [22045, 3431, 9167],
                    "./datepicker-ar.js": [75214, 3431, 9314],
                    "./datepicker-az.js": [72230, 3431, 9754],
                    "./datepicker-be.js": [45856, 3431, 8952],
                    "./datepicker-bg.js": [76650, 3431, 2590],
                    "./datepicker-bs.js": [23334, 3431, 5850],
                    "./datepicker-ca.js": [60677, 3431, 8631],
                    "./datepicker-cs.js": [84115, 3431, 561],
                    "./datepicker-cy-GB.js": [66459, 3431, 9177],
                    "./datepicker-da.js": [71302, 3431, 4714],
                    "./datepicker-de-AT.js": [62706, 3431, 1942],
                    "./datepicker-de.js": [15546, 3431, 7438],
                    "./datepicker-el.js": [4372, 3431, 2844],
                    "./datepicker-en-AU.js": [1773, 3431, 4527],
                    "./datepicker-en-GB.js": [31166, 3431, 8210],
                    "./datepicker-en-NZ.js": [88087, 3431, 6261],
                    "./datepicker-eo.js": [16221, 3431, 6255],
                    "./datepicker-es.js": [38985, 3431, 8155],
                    "./datepicker-et.js": [48508, 3431, 7028],
                    "./datepicker-eu.js": [3971, 3431, 6737],
                    "./datepicker-fa.js": [14136, 3431, 9168],
                    "./datepicker-fi.js": [94832, 3431, 7624],
                    "./datepicker-fo.js": [41830, 3431, 7658],
                    "./datepicker-fr-CA.js": [91766, 3431, 2106],
                    "./datepicker-fr-CH.js": [43773, 3431, 6559],
                    "./datepicker-fr.js": [81121, 3431, 7731],
                    "./datepicker-gl.js": [83702, 3431, 3450],
                    "./datepicker-he.js": [58222, 3431, 9218],
                    "./datepicker-hi.js": [5370, 3431, 8478],
                    "./datepicker-hr.js": [26751, 3431, 1213],
                    "./datepicker-hu.js": [27742, 3431, 6194],
                    "./datepicker-hy.js": [59082, 3431, 6158],
                    "./datepicker-id.js": [65376, 3431, 968],
                    "./datepicker-is.js": [96357, 3431, 8551],
                    "./datepicker-it-CH.js": [34858, 3431, 4158],
                    "./datepicker-it.js": [95856, 3431, 6456],
                    "./datepicker-ja.js": [13828, 3431, 1772],
                    "./datepicker-ka.js": [41885, 3431, 1231],
                    "./datepicker-kk.js": [43699, 3431, 8321],
                    "./datepicker-km.js": [78969, 3431, 2987],
                    "./datepicker-ko.js": [48407, 3431, 5429],
                    "./datepicker-ky.js": [3909, 3431, 39],
                    "./datepicker-lb.js": [987, 3431, 2009],
                    "./datepicker-lt.js": [77873, 3431, 9827],
                    "./datepicker-lv.js": [7471, 3431, 7757],
                    "./datepicker-mk.js": [98889, 3431, 1131],
                    "./datepicker-ml.js": [7900, 3431, 7908],
                    "./datepicker-ms.js": [52225, 3431, 5539],
                    "./datepicker-nb.js": [33641, 3431, 4091],
                    "./datepicker-nl-BE.js": [61285, 3431, 9495],
                    "./datepicker-nl.js": [23595, 3431, 7702],
                    "./datepicker-nn.js": [99981, 3431, 8239],
                    "./datepicker-no.js": [73966, 3431, 4066],
                    "./datepicker-pl.js": [44141, 3431, 6671],
                    "./datepicker-pt-BR.js": [42366, 3431, 2978],
                    "./datepicker-pt.js": [37109, 3431, 8228],
                    "./datepicker-rm.js": [5880, 3431, 7712],
                    "./datepicker-ro.js": [94338, 3431, 4646],
                    "./datepicker-ru.js": [32800, 3431, 5304],
                    "./datepicker-sk.js": [79899, 3431, 4889],
                    "./datepicker-sl.js": [58162, 3431, 2390],
                    "./datepicker-sq.js": [40517, 3431, 9831],
                    "./datepicker-sr-SR.js": [84964, 3431, 7356],
                    "./datepicker-sr.js": [33564, 3431, 503],
                    "./datepicker-sv.js": [74192, 3431, 2552],
                    "./datepicker-ta.js": [81558, 3431, 3274],
                    "./datepicker-th.js": [49917, 3431, 7727],
                    "./datepicker-tj.js": [86011, 3431, 4329],
                    "./datepicker-tr.js": [21315, 3431, 5553],
                    "./datepicker-uk.js": [49393, 3431, 9203],
                    "./datepicker-vi.js": [78208, 3431, 280],
                    "./datepicker-zh-CN.js": [19349, 3431, 5047],
                    "./datepicker-zh-HK.js": [25593, 3431, 5019],
                    "./datepicker-zh-TW.js": [86449, 3431, 5155]
                };

                function o(e) {
                    if (!a.o(r, e)) return Promise.resolve().then((() => {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = r[e],
                        o = t[0];
                    return Promise.all(t.slice(1).map(a.e)).then((() => a.t(o, 23)))
                }
                o.keys = () => Object.keys(r), o.id = 53536, e.exports = o
            },
            71028: (e, t, a) => {
                "use strict";
                var r = a(22024);
                a(82170);
                var o = a(67578);

                function n(e) {
                    return (...t) => e()(...t)
                }
                n((() => StackExchange.helpers.addSpinner)), n((() => StackExchange.helpers.addStacksSpinner)), n((() => StackExchange.helpers.addLightbox)), n((() => StackExchange.helpers.getLikelyErrorMessage)), n((() => StackExchange.helpers.getRejectedMockXhr)), n((() => StackExchange.helpers.getSpinnerImg)), n((() => StackExchange.helpers.removeMessages)), n((() => StackExchange.helpers.removeSpinner)), n((() => StackExchange.helpers.showErrorMessage)), n((() => StackExchange.helpers.showInfoMessage)), n((() => StackExchange.helpers.showMessage)), n((() => StackExchange.helpers.showSuccessMessage)), n((() => StackExchange.helpers.showModal)), n((() => StackExchange.helpers.loadModal));
                const s = n((() => StackExchange.helpers.showToast)),
                    c = n((() => StackExchange.helpers.hideToasts));
                n((() => StackExchange.helpers.suggestedTransientTimeout)), n((() => StackExchange.helpers.toggleStacksPopover)), n((() => StackExchange.helpers.queueStacksPopover)), n((() => StackExchange.helpers.submitFormOnEnterPress)), n((() => StackExchange.helpers.updateQueryStringParameter)), n((() => StackExchange.helpers.DelayedReaction)), n((() => StackExchange.helpers.closePopups)), n((() => StackExchange.helpers.showStacksNotice)), n((() => StackExchange.helpers.removeParameterFromQueryString)), n((() => StackExchange.helpers.enableSubmitButton)), n((() => StackExchange.helpers.disableSubmitButton)), n((() => StackExchange.helpers.loadTicks)), n((() => StackExchange.helpers.encodeHexHtmlEntities)), n((() => StackExchange.helpers.bindOnHashChange_HighlightDestination)), n((() => StackExchange.helpers.MagicPopup)), n((() => StackExchange.helpers.copyTextToClipboard)), n((() => StackExchange.helpers.noDiacritics)), n((() => StackExchange.helpers.tagSeparator)), n((() => StackExchange.helpers.sanitizeAndSplitTags)), new Promise((e => {
                    "undefined" != typeof window ? StackExchange.ready(e) : e()
                }));
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                const i = (e, t, a) => {
                        ! function(e, t, a, r) {
                            const o = new FormData;
                            o.append("fKey", null != r ? r : StackExchange.options.user.fkey), o.append("data", JSON.stringify(t)), o.append("event", e);
                            let n = {};
                            a && (n["X-Previous-Event-Id"] = a), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                                method: "POST",
                                keepalive: !0,
                                body: o,
                                headers: n
                            }).then((() => {}))
                        }(e, {
                            source: window.location.href,
                            ...t
                        }, void 0, a)
                    },
                    d = {
                        showToast: s,
                        hideToasts: c
                    };
                var l = a(99724),
                    p = o.vUu('<div class="mrn24"><img class="w100" alt="Illustration of upvote icon after it is clicked"/></div>'),
                    h = o.vUu('<div class="mx32 mt24"><h1 class="fs-title fw-bold mb16 fc-black-600"><!></h1> <!></div>'),
                    f = o.vUu('<div class="w100 mx32 d-flex fd-column ai-center"><!> <!></div>'),
                    u = o.vUu('<div class="redirect-modal-wrapper svelte-3dcwtb"><!></div>');
                const v = {
                    hash: "svelte-3dcwtb",
                    code: "\n    /* Currently, the Modal component does not allow styling of the close button. Until we create a new variant,\n     * we have to add the box shadow to it here.\n     */.redirect-modal-wrapper.svelte-3dcwtb .s-modal--close {box-shadow:var(--bs-lg);background-color:var(--black-150);}"
                };

                function b(e, t) {
                    o.VCO(t, !0), o.kZQ(e, v);
                    let a, n, s, c, i, b, g = o._w2(t, "visible", 15);
                    if (!t.headerImageUrl) throw new Error("Must provide a header image URL");
                    if (!t.triggerEventName) throw new Error("Must provide the name of the event to trigger opening");
                    (0, r.Rc)((() => {
                        window.addEventListener(t.triggerEventName, (e => {
                            g(!0), a = e.detail.postId, n = e.detail.voteSessionId
                        })), window.addEventListener("messageAfterModal", (e => {
                            const t = e.detail;
                            s = t.message, c = t.messageType, i = t.messageTransient, b = t.messageUseRawHtml
                        }))
                    }));
                    let k = o.wk1(!1);
                    o.MWq((() => {
                        !g() && o.JtY(k) ? (t.onClose(a, n), o.hZp(k, !1), null != s && null != c && null != i && null != b && (d.showToast(s ? ? "", {
                            type: c,
                            transient: i,
                            useRawHtml: b
                        }), s = void 0, c = void 0, i = void 0, b = void 0)) : g() && o.hZp(k, !0)
                    }));
                    var w = u();
                    o.f0J("keydown", o.xa8, (e => {
                        "Escape" === e.key && g(!1)
                    }));
                    var m = o.jfp(w); {
                        const e = e => {
                                var a = p(),
                                    r = o.jfp(a);
                                o.cLc(a), o.vNg((() => o.aIK(r, "src", t.headerImageUrl))), o.BCw(e, a)
                            },
                            r = e => {
                                var a = h(),
                                    r = o.jfp(a),
                                    n = o.jfp(r);
                                o.UAl(n, (() => t.headerContent)), o.cLc(r);
                                var s = o.hg4(r, 2);
                                o.UAl(s, (() => t.bodyContent)), o.cLc(a), o.BCw(e, a)
                            },
                            s = e => {
                                var r = f(),
                                    s = o.jfp(r);
                                (0, l.$n)(s, {
                                    class: "w100 mb4",
                                    weight: "filled",
                                    icon: !0,
                                    onclick: () => t.onPrimaryButton(a, n),
                                    children: (e, a) => {
                                        var r = o.Imx(),
                                            n = o.esp(r);
                                        o.UAl(n, (() => t.primaryButtonContent)), o.BCw(e, r)
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                });
                                var c = o.hg4(s, 2);
                                (0, l.$n)(c, {
                                    class: "w100 mb32",
                                    onclick: () => t.onSecondaryButton(a, n),
                                    children: (e, a) => {
                                        var r = o.Imx(),
                                            n = o.esp(r);
                                        o.UAl(n, (() => t.secondaryButtonContent)), o.BCw(e, r)
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                }), o.cLc(r), o.BCw(e, r)
                            };
                        (0, l.aF)(m, o.DuQ({
                            get id() {
                                return t.id
                            },
                            class: "wmx4 p0"
                        }, {}, {
                            get visible() {
                                return g()
                            },
                            set visible(e) {
                                g(e)
                            },
                            header: e,
                            body: r,
                            footer: s,
                            $$slots: {
                                header: !0,
                                body: !0,
                                footer: !0
                            }
                        }))
                    }
                    o.cLc(w), o.BCw(e, w), o.uYY()
                }
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                class g extends Error {
                    constructor(e, t) {
                        super(e), this.response = t, this.name = "SavePostException"
                    }
                }
                var k = a(54152);
                const w = e => {
                        o.K2T();
                        var t = o.Qq7("Hang on, you can't upvote just yet.");
                        o.BCw(e, t)
                    },
                    m = e => {
                        var t = y();
                        o.K2T(2), o.BCw(e, t)
                    },
                    j = e => {
                        var t = E(),
                            a = o.esp(t);
                        (0, l.In)(a, {
                            get src() {
                                return k.tL2
                            }
                        }), o.K2T(), o.BCw(e, t)
                    },
                    S = e => {
                        o.K2T();
                        var t = o.Qq7("Not now");
                        o.BCw(e, t)
                    };
                var y = o.vUu('<p class="fs-body2">You\'ll need to complete a few actions and gain 15 reputation points\n        before being able to upvote. <strong>Upvoting</strong> indicates when questions and answers are useful. <a class="s-link s-link__underlined s-link__muted" href="https://stackoverflow.com/help/whats-reputation">What\'s reputation and how do I get it?</a></p> <p class="fs-body2">Instead, you can save this post to reference later.</p>', 1),
                    E = o.vUu("<!> Save this post for later", 1),
                    x = o.vUu('<div class="redirect-modal-wrapper"><!></div>');
                const C = e => {
                        o.K2T();
                        var t = o.Qq7("Got it!");
                        o.BCw(e, t)
                    },
                    _ = e => {
                        o.K2T();
                        var t = o.Qq7("Go to help center to learn more");
                        o.BCw(e, t)
                    };
                var B = o.vUu(" <br/> ", 1),
                    U = o.vUu(" <br/> ", 1),
                    O = o.vUu('<div class="fs-body2"><!></div>'),
                    I = o.vUu('<div class="redirect-modal-wrapper"><!></div>');
                const $ = window.Stacks;
                var L = o.vUu('<div class="s-popover fs-body1 wmn4 p16" id="downvote-rep-required-popover"><div class="s-popover--arrow"></div> <button type="button" class="s-popover--close s-btn s-btn__muted"><!></button> <div class="d-flex"><div class="flex--item mr12"><!></div> <div class="flex--item"><div class="d-flex ai-center"><h2 class="fs-body1 fw-bold mb4 mt2"></h2></div> <p class="mb4"> </p> <br/> <p class="mb4"><!></p></div></div></div>');
                o.MmH(["click"]);
                const P = function(e) {
                        const t = function(e) {
                            const t = function(e) {
                                const t = e.replace(/\.(t|j)sx?/, ""),
                                    a = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                                return document.querySelectorAll(a)
                            }(e);
                            return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
                        }(e);
                        return function(e, t) {
                                if (0 === e.length) throw `Couldn't find args for module "${t}". Did you forget to call @JavaScriptHelper.Args?`
                            }(t, e),
                            function(e, t) {
                                if (e.length > 1) throw `Found too many instances of args for module "${t}". Did you call @JavaScriptHelper.Args too many times?`
                            }(t, e), t[0]
                    }("islands/redirect-action-modal/index.mod.ts"),
                    T = document.getElementById(P.ContainerElementId);
                P.EnableUpvoteModal && (0, r.Or)((function(e, t) {
                    o.VCO(t, !0);
                    let a = o.wk1(!1);
                    var r = x();
                    b(o.jfp(r), {
                        id: "upvote-redirect-action-modal",
                        get headerContent() {
                            return w
                        },
                        get bodyContent() {
                            return m
                        },
                        get headerImageUrl() {
                            return t.headerImageUrl
                        },
                        triggerEventName: "upvoteRedirectActionModalShow",
                        onPrimaryButton: (e, r) => {
                            (async (e, t) => {
                                const a = await fetch(`/posts/${e}/save`, {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/x-www-form-urlencoded"
                                    },
                                    body: new URLSearchParams({
                                        fkey: t
                                    }).toString()
                                });
                                if (200 !== a.status) throw new g(`Failed to save post with status: ${a.status}`, a);
                                const r = await a.json();
                                if (!(null == r ? void 0 : r.Success)) throw new g("Failed to save post - not marked as successful", a);
                                return r
                            })(e, t.fKey).then((t => {
                                (async (e, t) => {
                                    dispatchEvent(new CustomEvent("savesSavePerformed", {
                                        detail: {
                                            PostId: e,
                                            ...t
                                        }
                                    }))
                                })(e, t)
                            })).then((() => {
                                i("redirect_action_experiment.upvote_to_save.completed", {
                                    postId: e,
                                    voteSessionId: r
                                })
                            })).finally((() => {
                                o.hZp(a, !1)
                            }))
                        },
                        onSecondaryButton: () => {
                            o.hZp(a, !1)
                        },
                        onClose: (e, t) => {
                            i("redirect_action_experiment.upvote_to_save.dismissed", {
                                postId: e,
                                voteSessionId: t
                            })
                        },
                        get primaryButtonContent() {
                            return j
                        },
                        get secondaryButtonContent() {
                            return S
                        },
                        get visible() {
                            return o.JtY(a)
                        },
                        set visible(e) {
                            o.hZp(a, e, !0)
                        }
                    }), o.cLc(r), o.BCw(e, r), o.uYY()
                }), {
                    target: T,
                    props: {
                        fKey: P.FKey,
                        headerImageUrl: P.UpvoteHeaderImageUrl
                    }
                }), P.EnableFreeVotesModal && (0, r.Or)((function(e, t) {
                    o.VCO(t, !0);
                    const a = e => {
                            var a = o.Imx(),
                                r = o.esp(a),
                                n = e => {
                                    var t = B(),
                                        a = o.esp(t);
                                    a.nodeValue = `${__tr(["Thanks for your vote!"], undefined, "en", [])??""} `, o.hg4(a, 2).nodeValue = ` ${__tr(["You now have 5 downvotes per week."], undefined, "en", [])??""}`, o.BCw(e, t)
                                },
                                s = e => {
                                    var t = U(),
                                        a = o.esp(t);
                                    a.nodeValue = `${__tr(["Thanks for your vote!"], undefined, "en", [])??""} `, o.hg4(a, 2).nodeValue = ` ${__tr(["You now have 5 free votes weekly."], undefined, "en", [])??""}`, o.BCw(e, t)
                                };
                            o.if(r, (e => {
                                t.hasUpvotePrivilege ? e(n) : e(s, !1)
                            })), o.BCw(e, a)
                        },
                        r = e => {
                            var a = O(),
                                r = o.jfp(a),
                                n = e => {
                                    var a = o.Imx(),
                                        r = o.esp(a);
                                    o.qyt(r, (() => __tr(["Free downvotes$listStart$count toward the total vote score$listSeparator$don't take away reputation from the author$listSeparator$cost 1 rep on answers$listEnd$Continue to help good content that is interesting, well-researched, and useful, rise to the top! To gain full voting privileges, <a href=\"$earnReputationHelpCenterLink$\">earn reputation</a>."], {
                                        earnReputationHelpCenterLink: t.freeVotesEarnReputationHelpCenterUrl,
                                        listStart: "<ul><li>",
                                        listSeparator: "</li><li>",
                                        listEnd: "</li></ul>"
                                    }, "en", []))), o.BCw(e, a)
                                },
                                s = e => {
                                    var a = o.Imx(),
                                        r = o.esp(a);
                                    o.qyt(r, (() => __tr(["Free votes$listStart$count toward the total vote score$listSeparator$does not give reputation to the author$listEnd$Continue to help good content that is interesting, well-researched, and useful, rise to the top! To gain full voting privileges, <a href=\"$earnReputationHelpCenterLink$\">earn reputation</a>."], {
                                        earnReputationHelpCenterLink: t.freeVotesEarnReputationHelpCenterUrl,
                                        listStart: "<ul><li>",
                                        listSeparator: "</li><li>",
                                        listEnd: "</li></ul>"
                                    }, "en", []))), o.BCw(e, a)
                                };
                            o.if(r, (e => {
                                t.hasUpvotePrivilege ? e(n) : e(s, !1)
                            })), o.cLc(a), o.BCw(e, a)
                        };
                    let n = o.wk1(!1);
                    var s = I();
                    b(o.jfp(s), {
                        id: "upvote-redirect-action-modal",
                        get headerContent() {
                            return a
                        },
                        get bodyContent() {
                            return r
                        },
                        get headerImageUrl() {
                            return t.headerImageUrl
                        },
                        triggerEventName: "freeVotesModalShow",
                        onPrimaryButton: () => {
                            o.hZp(n, !1)
                        },
                        onSecondaryButton: (e, a) => {
                            i("redirect_action_experiment.vote_to_free_votes_onboarding.learn_more", {
                                postId: e,
                                voteSessionId: a
                            }), window.open(t.freeVotesLearnMoreHelpCenterUrl, "_blank")
                        },
                        onClose: (e, t) => {
                            i("redirect_action_experiment.vote_to_free_votes_onboarding.dismissed", {
                                postId: e,
                                voteSessionId: t
                            })
                        },
                        get primaryButtonContent() {
                            return C
                        },
                        get secondaryButtonContent() {
                            return _
                        },
                        get visible() {
                            return o.JtY(n)
                        },
                        set visible(e) {
                            o.hZp(n, e, !0)
                        }
                    }), o.cLc(s), o.BCw(e, s), o.uYY()
                }), {
                    target: T,
                    props: {
                        headerImageUrl: P.FreeVotesHeaderImageUrl,
                        freeVotesEarnReputationHelpCenterUrl: P.FreeVotesEarnReputationHelpCenterUrl,
                        freeVotesLearnMoreHelpCenterUrl: P.FreeVotesLearnMoreHelpCenterUrl,
                        hasUpvotePrivilege: P.HasUpvotePrivilege
                    }
                }), P.EnableDownVoteRepRequiredRedirectActionPopover && (0, r.Or)((function(e, t) {
                    o.VCO(t, !0);
                    let a = o.wk1(void 0),
                        n = o.wk1(void 0);
                    (0, r.Rc)((() => (window.addEventListener("downVoteRepRequiredPopoverShow", s), () => {
                        window.removeEventListener("downVoteRepRequiredPopoverShow", s)
                    })));
                    const s = e => {
                            if (o.JtY(a) && c(), o.hZp(a, e.detail.idToBind, !0), o.hZp(n, document.querySelector(`#${o.JtY(a)}`), !0), !o.JtY(n)) return o.hZp(a, void 0), void o.hZp(n, void 0);
                            i("aria-controls", "downvote-rep-required-popover"), i("data-controller", "s-popover"), i("data-s-popover-placement", "right-start"), i("data-s-popover-auto-show", "false"), i("data-s-popover-hide-on-outside-click", "never"), (0, $.showPopover)(o.JtY(n))
                        },
                        c = () => {
                            (0, $.hidePopover)(o.JtY(n)), d("aria-controls", "downvote-rep-required-popover"), d("data-controller", "s-popover"), d("data-s-popover-placement", "right-start"), d("data-s-popover-auto-show", "false"), d("data-s-popover-hide-on-outside-click", "never"), o.hZp(a, void 0), o.hZp(n, void 0)
                        },
                        i = (e, t) => {
                            if (!o.JtY(n)) return;
                            let a = o.JtY(n).getAttribute(e);
                            if (null == a) o.JtY(n).setAttribute(e, t);
                            else {
                                let r = a.split(" ").filter(Boolean);
                                r.includes(t) || r.push(t), o.JtY(n).setAttribute(e, r.join(" "))
                            }
                        },
                        d = (e, t) => {
                            if (!o.JtY(n)) return;
                            let a = o.JtY(n).getAttribute(e),
                                r = a ? .split(" ").filter((e => e != t)).join(" ");
                            r ? o.JtY(n).setAttribute(e, r) : o.JtY(n).removeAttribute(e)
                        };
                    var p = o.Imx(),
                        h = o.esp(p),
                        f = e => {
                            var a = L(),
                                r = o.hg4(o.jfp(a), 2);
                            r.__click = c, o.aIK(r, "aria-label", __tr(["Dismiss"], undefined, "en", []));
                            var n = o.jfp(r);
                            (0, l.In)(n, {
                                class: "fc-black-600",
                                get src() {
                                    return k.j5$
                                }
                            }), o.cLc(r);
                            var s = o.hg4(r, 2),
                                i = o.jfp(s),
                                d = o.jfp(i);
                            (0, l.In)(d, {
                                get src() {
                                    return k.O7Z
                                }
                            }), o.cLc(i);
                            var p = o.hg4(i, 2),
                                h = o.jfp(p);
                            o.jfp(h).textContent = __tr(["Just a little more rep needed to downvote!"], undefined, "en", []), o.cLc(h);
                            var f = o.hg4(h, 2),
                                u = o.jfp(f, !0);
                            o.cLc(f);
                            var v = o.hg4(f, 4),
                                b = o.jfp(v);
                            o.qyt(b, (() => __tr(["Keep participating to <a href=\"$repLink$\">earn reputation.</a>"], {
                                repLink: t.whatIsRepUrl
                            }, "en", []))), o.cLc(v), o.cLc(p), o.cLc(s), o.cLc(a), o.vNg((e => o.jax(u, e)), [() => __tr(["Downvoting an answer costs $repCost$ rep and it looks like you don’t have enough at the moment.", "Downvoting an answer costs $repCost$ rep and it looks like you don’t have enough at the moment."], {
                                repCost: t.repChange
                            }, "en", ["repCost"])]), o.BCw(e, a)
                        };
                    o.if(h, (e => {
                        o.JtY(a) && e(f)
                    })), o.BCw(e, p), o.uYY()
                }), {
                    target: T,
                    props: {
                        repChange: P.AnswerDownVoteRepChange,
                        whatIsRepUrl: P.FreeVotesEarnReputationHelpCenterUrl
                    }
                })
            },
            53117: (e, t, a) => {
                "use strict";
                a.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            20428: e => {
                "use strict";
                e.exports = window.jQuery
            },
            54152: (e, t, a) => {
                "use strict";
                a.d(t, {
                    O7Z: () => r,
                    j5$: () => s,
                    nFV: () => n,
                    tL2: () => o
                });
                const r = '<svg aria-hidden="true" class="svg-icon iconAlert" width="18" height="18"  viewBox="0 0 18 18"><path  d="M7.95 2.71c.58-.94 1.52-.94 2.1 0l7.69 12.58c.58.94.15 1.71-.96 1.71H1.22C.1 17-.32 16.23.26 15.29zM8 6v5h2V6zm0 7v2h2v-2z"/></svg>',
                    o = '<svg aria-hidden="true" class="svg-icon iconBookmarkAlt" width="18" height="18"  viewBox="0 0 18 18"><path  d="m9 10.6 4 2.66V3H5v10.26zM3 17V3c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v14l-6-4z"/></svg>',
                    n = '<svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18"  viewBox="0 0 18 18"><path  d="M15 4.41 13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9z"/></svg>',
                    s = '<svg aria-hidden="true" class="svg-icon iconClearSm" width="14" height="14"  viewBox="0 0 14 14"><path  d="M12 3.41 10.59 2 7 5.59 3.41 2 2 3.41 5.59 7 2 10.59 3.41 12 7 8.41 10.59 12 12 10.59 8.41 7z"/></svg>'
            },
            34164: (e, t, a) => {
                "use strict";

                function r(e) {
                    var t, a, o = "";
                    if ("string" == typeof e || "number" == typeof e) o += e;
                    else if ("object" == typeof e)
                        if (Array.isArray(e)) {
                            var n = e.length;
                            for (t = 0; t < n; t++) e[t] && (a = r(e[t])) && (o && (o += " "), o += a)
                        } else
                            for (a in e) e[a] && (o && (o += " "), o += a);
                    return o
                }

                function o() {
                    for (var e, t, a = 0, o = "", n = arguments.length; a < n; a++)(e = arguments[a]) && (t = r(e)) && (o && (o += " "), o += t);
                    return o
                }
                a.d(t, {
                    $: () => o
                })
            },
            74488: (e, t, a) => {
                "use strict";
                a.d(t, {
                    h5: () => r,
                    IJ: () => n
                });
                const r = !0,
                    o = globalThis.process ? .env ? .NODE_ENV,
                    n = o && !o.toLowerCase().startsWith("prod")
            },
            2322: (e, t, a) => {
                "use strict";
                a(85630), a(22024)
            }
        },
        s = {};

    function c(e) {
        var t = s[e];
        if (void 0 !== t) return t.exports;
        var a = s[e] = {
            exports: {}
        };
        return n[e](a, a.exports, c), a.exports
    }
    c.m = n, e = [], c.O = (t, a, r, o) => {
        if (!a) {
            var n = 1 / 0;
            for (l = 0; l < e.length; l++) {
                for (var [a, r, o] = e[l], s = !0, i = 0; i < a.length; i++)(!1 & o || n >= o) && Object.keys(c.O).every((e => c.O[e](a[i]))) ? a.splice(i--, 1) : (s = !1, o < n && (n = o));
                if (s) {
                    e.splice(l--, 1);
                    var d = r();
                    void 0 !== d && (t = d)
                }
            }
            return t
        }
        o = o || 0;
        for (var l = e.length; l > 0 && e[l - 1][2] > o; l--) e[l] = e[l - 1];
        e[l] = [a, r, o]
    }, a = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, c.t = function(e, r) {
        if (1 & r && (e = this(e)), 8 & r) return e;
        if ("object" == typeof e && e) {
            if (4 & r && e.__esModule) return e;
            if (16 & r && "function" == typeof e.then) return e
        }
        var o = Object.create(null);
        c.r(o);
        var n = {};
        t = t || [null, a({}), a([]), a(a)];
        for (var s = 2 & r && e;
            "object" == typeof s && !~t.indexOf(s); s = a(s)) Object.getOwnPropertyNames(s).forEach((t => n[t] = () => e[t]));
        return n.default = () => e, c.d(o, n), o
    }, c.d = (e, t) => {
        for (var a in t) c.o(t, a) && !c.o(e, a) && Object.defineProperty(e, a, {
            enumerable: !0,
            get: t[a]
        })
    }, c.f = {}, c.e = e => Promise.all(Object.keys(c.f).reduce(((t, a) => (c.f[a](e, t), t)), [])), c.u = e => 3431 === e ? "webpack-chunks/3431.en.js" : "webpack-chunks/" + e + "." + {
        39: "0c327b2a4933649c046f",
        280: "78aa2de8c7354dc19f59",
        503: "d64ce9cb0e1713a97fa0",
        561: "5d0534ecefc1507a56ed",
        968: "5e07d1c4e2181dba23cf",
        1131: "1ac785798c33d445a662",
        1213: "a2ab798ed57291783dac",
        1231: "3a50f67686b31fc42c00",
        1772: "4cad33a1785c14f9a3f8",
        1942: "07c0507f73de5c49faab",
        2009: "ab8906781c9641e430f1",
        2106: "f57196f852a2f5fe8564",
        2390: "91d1fc1f591e852502ad",
        2552: "186e91acc01b74603da0",
        2590: "68290cd8d9bf295c44ac",
        2844: "109973b801f6ff8752ed",
        2978: "b3cb5b00813c7361dcf2",
        2987: "31ffa97bd6b596c9dfe3",
        3274: "f7fd16701248cd3d33fd",
        3450: "1eabc856027e72122a22",
        4066: "2c769aa805d195aaec5b",
        4091: "c6daef6e602f996c0bd3",
        4158: "e231bf4644002ecad221",
        4329: "ef75e680701ad98fc0ca",
        4527: "e8a2a8cd61693351582f",
        4646: "82d21bd7b183cdeb5eeb",
        4714: "a9bc14522e19a4030f31",
        4889: "6064f61c508728f860b4",
        5019: "aadd414ab46b6aa8a9ba",
        5047: "73bf2547156e955eed1d",
        5155: "8929efe69bf21677f6d0",
        5304: "159e929c07ef4e1ebd6e",
        5429: "7397817c795d018d5518",
        5539: "eacd9e0d87d445b94a48",
        5553: "6e0b77f1d4267a1d2b02",
        5850: "44d46a18a41f664670c0",
        6158: "ee3f7ff34c5f4af26d74",
        6194: "726078b69c57150105b4",
        6255: "53461cbdbd4563dce184",
        6261: "d7809c75407908e2bd1e",
        6456: "a0e4e8c639b99fe6d1c1",
        6559: "68b1db9ba257d2dc2bef",
        6671: "6055abe67ec3cac19fc6",
        6737: "914fdaf157147acbae26",
        6883: "fa2b954cf29aa505c136",
        7028: "b7ec91fc61f47e301390",
        7334: "0a1297a871633e0bc52c",
        7356: "581d3b59c4106e99cbf4",
        7438: "4f1949cf0291279dc92f",
        7624: "260c52f6459c3cb9a0af",
        7658: "02e00dd8274b7ca7361f",
        7702: "b53d89d820b40f1b57e5",
        7712: "dfdc4d6ad42ee4bbc8b3",
        7727: "ca5d2c1f92acee0993e6",
        7731: "fc571ef82b17c18d772e",
        7757: "15ab0517852b07044871",
        7908: "7579a1e2dad366811297",
        8155: "0c88c373cd037b2cd1b9",
        8210: "c249e93165dbb518fa58",
        8228: "0ef292c6c07b0b03cc3a",
        8239: "0b62eb96110b44b4d34b",
        8321: "4a304adc6b166c75f6b8",
        8478: "1562eba353e358405709",
        8551: "5037a8be9386358ab941",
        8631: "6796827941bd0634a167",
        8952: "f1f8118c003bd9631032",
        9167: "83584f57bbc43cd4f8bf",
        9168: "f0c0a0da5ec398cd73f3",
        9177: "9f3388250bfe030c2379",
        9203: "87f7098190310b8a6707",
        9218: "c925b7a39a4299fdda5c",
        9314: "34b8f0b382c8eec48309",
        9495: "876a79736eb7223a79e3",
        9754: "56c73e2643f19f438688",
        9827: "28d65e6c88a4f3f023e0",
        9831: "2dd08ae9fc8c832d8b44"
    }[e] + ".en.js", c.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), r = {}, o = "stackoverflow:", c.l = (e, t, a, n) => {
        if (r[e]) r[e].push(t);
        else {
            var s, i;
            if (void 0 !== a)
                for (var d = document.getElementsByTagName("script"), l = 0; l < d.length; l++) {
                    var p = d[l];
                    if (p.getAttribute("src") == e || p.getAttribute("data-webpack") == o + a) {
                        s = p;
                        break
                    }
                }
            s || (i = !0, (s = document.createElement("script")).charset = "utf-8", s.timeout = 120, c.nc && s.setAttribute("nonce", c.nc), s.setAttribute("data-webpack", o + a), s.src = e), r[e] = [t];
            var h = (t, a) => {
                    s.onerror = s.onload = null, clearTimeout(f);
                    var o = r[e];
                    if (delete r[e], s.parentNode && s.parentNode.removeChild(s), o && o.forEach((e => e(a))), t) return t(a)
                },
                f = setTimeout(h.bind(null, void 0, {
                    type: "timeout",
                    target: s
                }), 12e4);
            s.onerror = h.bind(null, s.onerror), s.onload = h.bind(null, s.onload), i && document.head.appendChild(s)
        }
    }, c.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, c.j = 4901, c.p = "", (() => {
        var e = {
            4901: 0
        };
        c.f.j = (t, a) => {
            var r = c.o(e, t) ? e[t] : void 0;
            if (0 !== r)
                if (r) a.push(r[2]);
                else {
                    var o = new Promise(((a, o) => r = e[t] = [a, o]));
                    a.push(r[2] = o);
                    var n = c.p + c.u(t),
                        s = new Error;
                    c.l(n, (a => {
                        if (c.o(e, t) && (0 !== (r = e[t]) && (e[t] = void 0), r)) {
                            var o = a && ("load" === a.type ? "missing" : a.type),
                                n = a && a.target && a.target.src;
                            s.message = "Loading chunk " + t + " failed.\n(" + o + ": " + n + ")", s.name = "ChunkLoadError", s.type = o, s.request = n, r[1](s)
                        }
                    }), "chunk-" + t, t)
                }
        }, c.O.j = t => 0 === e[t];
        var t = (t, a) => {
                var r, o, [n, s, i] = a,
                    d = 0;
                if (n.some((t => 0 !== e[t]))) {
                    for (r in s) c.o(s, r) && (c.m[r] = s[r]);
                    if (i) var l = i(c)
                }
                for (t && t(a); d < n.length; d++) o = n[d], c.o(e, o) && e[o] && e[o][0](), e[o] = 0;
                return c.O(l)
            },
            a = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        a.forEach(t.bind(null, 0)), a.push = t.bind(null, a.push.bind(a))
    })(), c.O(void 0, [5622, 8112], (() => c(53117)));
    var i = c.O(void 0, [5622, 8112], (() => c(71028)));
    i = c.O(i)
})();