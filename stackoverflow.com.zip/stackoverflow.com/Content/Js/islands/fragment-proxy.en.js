(() => {
    "use strict";
    var e, t = {
            37136: (e, t, r) => {
                var a = r(22024);
                r(82170);
                var n, o = r(67578),
                    c = r(69980);
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {},
                    function(e) {
                        e[e.Unknown = 0] = "Unknown", e[e.Success = 1] = "Success", e[e.Error = 2] = "Error", e[e.TimeOut = 3] = "TimeOut", e[e.Unavailable = 4] = "Unavailable"
                    }(n || (n = {}));
                var s = o.vUu('<div data-testid="fragment-wrapper"><!></div>'),
                    i = o.vUu('<div class="d-flex fd-column gy16"><div class="flex--item w100" data-testid="fragment-proxy"><!></div></div>');
                const d = function(e) {
                        const t = function(e) {
                            const t = function(e) {
                                const t = e.replace(/\.(t|j)sx?/, ""),
                                    r = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                                return document.querySelectorAll(r)
                            }(e);
                            return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
                        }(e);
                        return function(e, t) {
                                if (0 === e.length) throw `Couldn't find args for module "${t}". Did you forget to call @JavaScriptHelper.Args?`
                            }(t, e),
                            function(e, t) {
                                if (e.length > 1) throw `Found too many instances of args for module "${t}". Did you call @JavaScriptHelper.Args too many times?`
                            }(t, e), t[0]
                    }("islands/fragment-proxy/index.mod.ts"),
                    l = document.getElementById(d.ContainerElementId);
                (0, a.Or)((function(e, t) {
                    o.VCO(t, !0);
                    let r = t.targetContainerId + "-wrapper",
                        d = o.wk1(o.BXG(n.Unknown)),
                        l = o.wk1(""),
                        p = o.wk1(void 0);
                    (0, a.Rc)((async () => {
                        await (async e => {
                            const t = e.TraceHeaders.reduce(((e, t) => (e[t.Key] = t.Value, e)), {});
                            t["X-SO-FragmentMode"] = "fragment";
                            const r = {
                                method: "GET",
                                headers: t
                            };
                            try {
                                const t = await fetch(e.FragmentAddress, r);
                                t.ok && (o.hZp(l, await t.text(), !0), o.hZp(d, n.Success, !0))
                            } catch (e) {
                                o.hZp(d, n.Error, !0)
                            }
                        })({
                            FragmentAddress: t.fragmentAddress,
                            TraceHeaders: t.traceHeaders
                        })
                    })), o.MWq((() => {
                        o.JtY(p) ? .querySelectorAll("script").forEach(((e, t) => {
                            const a = e,
                                n = document.createElement("script");
                            n.setAttribute("type", a.type), n.text = `//# sourceURL=${r}-dynamic-script-${t}.js\n\n` + a.text, a.replaceWith(n)
                        }))
                    }));
                    var u = i(),
                        f = o.jfp(u),
                        v = o.jfp(f),
                        m = e => {
                            var t = s(),
                                a = o.jfp(t);
                            o.qyt(a, (() => o.JtY(l))), o.cLc(t), o.Lcc(t, (e => o.hZp(p, e)), (() => o.JtY(p))), o.vNg((() => o.aIK(t, "id", r))), o.BCw(e, t)
                        };
                    o.if(v, (e => {
                        o.JtY(d) === n.Success && e(m)
                    })), o.cLc(f), o.cLc(u), o.kYK(1, f, (() => c.hs)), o.kYK(2, f, (() => c.Rv)), o.BCw(e, u), o.uYY()
                }), {
                    target: l,
                    props: {
                        fragmentAddress: d.FragmentAddress,
                        traceHeaders: d.TraceHeaders,
                        targetContainerId: d.ContainerElementId
                    }
                })
            },
            53117: (e, t, r) => {
                r.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            74488: (e, t, r) => {
                r.d(t, {
                    h5: () => a,
                    IJ: () => o
                });
                const a = !0,
                    n = globalThis.process ? .env ? .NODE_ENV,
                    o = n && !n.toLowerCase().startsWith("prod")
            }
        },
        r = {};

    function a(e) {
        var n = r[e];
        if (void 0 !== n) return n.exports;
        var o = r[e] = {
            exports: {}
        };
        return t[e](o, o.exports, a), o.exports
    }
    a.m = t, e = [], a.O = (t, r, n, o) => {
        if (!r) {
            var c = 1 / 0;
            for (l = 0; l < e.length; l++) {
                for (var [r, n, o] = e[l], s = !0, i = 0; i < r.length; i++)(!1 & o || c >= o) && Object.keys(a.O).every((e => a.O[e](r[i]))) ? r.splice(i--, 1) : (s = !1, o < c && (c = o));
                if (s) {
                    e.splice(l--, 1);
                    var d = n();
                    void 0 !== d && (t = d)
                }
            }
            return t
        }
        o = o || 0;
        for (var l = e.length; l > 0 && e[l - 1][2] > o; l--) e[l] = e[l - 1];
        e[l] = [r, n, o]
    }, a.d = (e, t) => {
        for (var r in t) a.o(t, r) && !a.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, a.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), a.j = 4949, a.p = "", (() => {
        var e = {
            4949: 0
        };
        a.O.j = t => 0 === e[t];
        var t = (t, r) => {
                var n, o, [c, s, i] = r,
                    d = 0;
                if (c.some((t => 0 !== e[t]))) {
                    for (n in s) a.o(s, n) && (a.m[n] = s[n]);
                    if (i) var l = i(a)
                }
                for (t && t(r); d < c.length; d++) o = c[d], a.o(e, o) && e[o] && e[o][0](), e[o] = 0;
                return a.O(l)
            },
            r = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        r.forEach(t.bind(null, 0)), r.push = t.bind(null, r.push.bind(r))
    })(), a.O(void 0, [5622], (() => a(53117)));
    var n = a.O(void 0, [5622], (() => a(37136)));
    n = a.O(n)
})();