(() => {
    "use strict";
    var e, a = {
            72706: (e, a, t) => {
                var o = t(22024);
                t(82170);
                var r = t(67578),
                    n = t(99724),
                    l = r.vUu("<span> </span>");

                function s(e, a) {
                    const t = Math.round(2 * a.maxCount / 5),
                        o = Math.round(3 * a.maxCount / 5),
                        n = Math.round(4 * a.maxCount / 5);
                    let s = r.unG((() => 0 === a.currentLength ? {
                        message: __tr(["Enter at least $minCount$ characters", "Enter at least $minCount$ characters"], {
                            minCount: a.minCount
                        }, "en", ["minCount"]),
                        classes: "fs-caption fc-black-400"
                    } : a.currentLength < a.minCount ? {
                        message: __tr(["$amountLeftToMin$ more to go...", "$amountLeftToMin$ more to go..."], {
                            amountLeftToMin: a.minCount - a.currentLength
                        }, "en", ["amountLeftToMin"]),
                        classes: "fs-caption fc-black-400"
                    } : a.currentLength >= a.minCount && a.currentLength <= t ? {
                        message: __tr(["$amountLeftToMax$ characters left", "$amountLeftToMax$ characters left"], {
                            amountLeftToMax: a.maxCount - a.currentLength
                        }, "en", ["amountLeftToMax"]),
                        classes: "fs-caption fc-black-400"
                    } : a.currentLength > t && a.currentLength <= o ? {
                        message: __tr(["$amountLeftToMax$ characters left", "$amountLeftToMax$ characters left"], {
                            amountLeftToMax: a.maxCount - a.currentLength
                        }, "en", ["amountLeftToMax"]),
                        classes: "fs-caption fc-orange-600"
                    } : a.currentLength > o && a.currentLength <= n ? {
                        message: __tr(["$amountLeftToMax$ characters left", "$amountLeftToMax$ characters left"], {
                            amountLeftToMax: a.maxCount - a.currentLength
                        }, "en", ["amountLeftToMax"]),
                        classes: "fs-caption fc-orange-500"
                    } : a.currentLength > n && a.currentLength <= a.maxCount ? {
                        message: __tr(["$amountLeftToMax$ characters left", "$amountLeftToMax$ characters left"], {
                            amountLeftToMax: a.maxCount - a.currentLength
                        }, "en", ["amountLeftToMax"]),
                        classes: "fs-caption fc-orange-400"
                    } : {
                        message: __tr(["Too long by $amountOver$ characters", "Too long by $amountOver$ characters"], {
                            amountOver: a.currentLength - a.maxCount
                        }, "en", ["amountOver"]),
                        classes: "fs-caption fc-red-400"
                    }));
                    var c = l(),
                        d = r.jfp(c, !0);
                    r.cLc(c), r.vNg((() => {
                        r.ysU(c, 1, r.$z$(r.JtY(s).classes)), r.jax(d, r.JtY(s).message)
                    })), r.BCw(e, c)
                }
                const c = window.jQuery;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
                let d = "";
                var i = r.vUu('<span class="s-input-message fw-bold fc-red-400">This is the flag you currently have raised</span>'),
                    p = r.vUu('<div><input class="s-radio" type="radio" name="flag-reason" id="CommentProbableSpam"/> <label class="s-label" for="CommentProbableSpam"> <p class="s-description"><!></p></label> <!></div>'),
                    h = r.vUu('<div><input class="s-radio" type="radio" name="flag-reason" id="CommentRudeOrOffensive"/> <label class="s-label" for="CommentRudeOrOffensive"> <p class="s-description"><!></p></label> <!></div>'),
                    u = r.vUu(' <p class="s-description"><!></p>', 1),
                    f = r.vUu(' <p class="s-description"><!></p>', 1),
                    g = r.vUu('<div><input class="s-radio" type="radio" name="flag-reason" id="CommentUnwelcoming"/> <label class="s-label" for="CommentUnwelcoming"> <p class="s-description"><!></p></label> <!></div>'),
                    v = r.vUu('<div><input class="s-radio" type="radio" name="flag-reason" id="CommentRudeOrOffensive"/> <label class="s-label" for="CommentRudeOrOffensive"><!></label> <!></div> <!>', 1),
                    m = r.vUu('<fieldset class="s-check-group mt8"><!> <!> <div><input class="s-radio" type="radio" name="flag-reason" id="CommentNoLongerNeeded"/> <div class="d-flex fd-column g12 fl-grow1"><label class="s-label" for="CommentNoLongerNeeded"> <p class="s-description"></p></label> <div><!> <!></div> <!></div></div> <div><input class="s-radio" type="radio" name="flag-reason" id="CommentOther"/> <div class="d-flex fd-column g12 fl-grow1"><label class="s-label" for="CommentOther"> <p class="s-description"></p></label> <div><!> <!></div> <!></div></div></fieldset>'),
                    w = r.vUu('<span class="fc-black-400"> </span>'),
                    _ = r.vUu('<div class="d-flex jc-space-between g8 ai-center w100"><div><!> <!></div> <!></div>');
                const y = function(e) {
                        const a = function(e) {
                            const a = function(e) {
                                const a = e.replace(/\.(t|j)sx?/, ""),
                                    t = `script[type="application/json"][data-role="module-args"][data-module-name="${a}"]`;
                                return document.querySelectorAll(t)
                            }(e);
                            return Array.from(a).map((e => JSON.parse(e.textContent || e.innerText)))
                        }(e);
                        return function(e, a) {
                                if (0 === e.length) throw `Couldn't find args for module "${a}". Did you forget to call @JavaScriptHelper.Args?`
                            }(a, e),
                            function(e, a) {
                                if (e.length > 1) throw `Found too many instances of args for module "${a}". Did you call @JavaScriptHelper.Args too many times?`
                            }(a, e), a[0]
                    }("islands/follow-ups-flag-modal/index.mod.ts"),
                    b = document.getElementById(y.ContainerElementId);
                (0, o.Or)((function(e, a) {
                    r.VCO(a, !0);
                    const t = [],
                        l = (e, a = r.lQ1) => {
                            var t = r.Imx(),
                                o = r.esp(t),
                                n = e => {
                                    var a = i();
                                    r.BCw(e, a)
                                };
                            r.if(o, (e => {
                                r.JtY(j) && r.JtY(x) === a() && e(n)
                            })), r.BCw(e, t)
                        };
                    let y = r.wk1(!1),
                        b = r.wk1(""),
                        C = r.wk1(""),
                        k = r.wk1(0),
                        J = r.wk1(!1),
                        x = r.wk1(""),
                        L = r.wk1(""),
                        Y = r.wk1(""),
                        j = r.wk1(!1);
                    const T = e => {
                            const {
                                detail: a
                            } = e;
                            r.hZp(b, a.postId, !0), r.hZp(C, a.followUpId, !0), a.retracting && (r.hZp(j, !0), r.JtY(C) && async function(e) {
                                try {
                                    const a = await fetch(`/flags/follow-ups/${e}`);
                                    if (!a.ok) throw new Error("Network response was not ok");
                                    const t = await a.json();
                                    t && r.hZp(x, t.flagTypeId.toString(), !0)
                                } catch {
                                    r.hZp(y, !1), StackExchange.helpers.showToast("Error retrieving flag details", {
                                        type: "danger",
                                        dismissable: !0
                                    })
                                }
                            }(r.JtY(C))), r.hZp(k, a.commentFlagsRemainingToday, !0), r.hZp(J, a.currentUserIsMod, !0), r.hZp(y, !0)
                        },
                        O = () => {
                            r.hZp(b, null), r.hZp(C, null), r.hZp(k, 0), r.hZp(J, !1), r.hZp(x, ""), r.hZp(L, ""), r.hZp(Y, ""), r.hZp(j, !1)
                        };
                    async function $() {
                        const e = S(),
                            t = await (async ({
                                fkey: e,
                                otherText: a,
                                followUpId: t,
                                flagReasonSelected: o
                            }) => {
                                if (!t || !o || !e) throw new Error;
                                if ("19" === o && "" === (0, c.trim)(a)) return StackExchange.helpers.showToast("Flag reason is required.", {
                                    type: "danger"
                                }), {
                                    success: !1
                                };
                                const r = new FormData;
                                r.append("fkey", e), r.append("otherText", a);
                                const n = a === d;
                                d = a, r.append("overrideWarning", n.toString());
                                try {
                                    const e = await fetch(`/flags/comments/${t}/add/${o}`, {
                                        method: "POST",
                                        body: r
                                    });
                                    if (!e.ok) {
                                        const a = await e.text();
                                        throw new Error(a)
                                    }
                                    const a = await e.json();
                                    if (!a.Success) {
                                        if (1 === a.Outcome) return StackExchange.helpers.showToast(a.Message, {
                                            type: "warning"
                                        }), {
                                            success: !1
                                        };
                                        throw new Error(a.Message)
                                    }
                                    return StackExchange.helpers.showToast(__tr(["Thanks for flagging! We take your reports seriously."], undefined, "en", []), {
                                        type: "success",
                                        transientTimeout: 3e3
                                    }), {
                                        success: !0,
                                        resultChangedState: a.ResultChangedState
                                    }
                                } catch (e) {
                                    let a = __tr(["An error occurred during flagging."], undefined, "en", []);
                                    return e instanceof Error && e.message && (a = e.message), StackExchange.helpers.showToast(a, {
                                        type: "danger",
                                        useRawHtml: !0
                                    }), {
                                        success: !1
                                    }
                                }
                            })({
                                flagReasonSelected: r.JtY(x),
                                otherText: e,
                                followUpId: r.JtY(C),
                                fkey: a.fkey
                            });
                        t.success && window.dispatchEvent(new CustomEvent("flagSubmitted", {
                            detail: {
                                postId: r.JtY(b),
                                followUpId: r.JtY(C),
                                followUpDeleted: t.resultChangedState
                            }
                        })), r.hZp(y, !1), O()
                    }

                    function S() {
                        return "39" === r.JtY(x) ? r.JtY(L) : "19" === r.JtY(x) ? r.JtY(Y) : ""
                    }
                    async function E() {
                        const e = await (async ({
                            fkey: e,
                            followUpId: a,
                            flagReasonSelected: t
                        }) => {
                            if (!a || !t || !e) throw new Error;
                            const o = new FormData;
                            o.append("fkey", e);
                            try {
                                const e = await fetch(`/flags/comments/${a}/retract/${t}`, {
                                    method: "POST",
                                    body: o
                                });
                                if (!e.ok) {
                                    const a = await e.text();
                                    throw new Error(a)
                                }
                                const r = await e.json();
                                if (!r.Success) throw new Error(r.Message);
                                return StackExchange.helpers.showToast(__tr(["Your flag has been retracted."], undefined, "en", []), {
                                    type: "success",
                                    transientTimeout: 3e3
                                }), !0
                            } catch (e) {
                                let a = __tr(["An error occurred while trying to retract your flag."], undefined, "en", []);
                                return e instanceof Error && e.message && (a = e.message), StackExchange.helpers.showToast(a, {
                                    type: "danger",
                                    useRawHtml: !0
                                }), !1
                            }
                        })({
                            flagReasonSelected: r.JtY(x),
                            followUpId: r.JtY(C),
                            fkey: a.fkey
                        });
                        e && window.dispatchEvent(new CustomEvent("flagRetract", {
                            detail: {
                                postId: r.JtY(b),
                                followUpId: r.JtY(C)
                            }
                        })), r.hZp(y, !1), O()
                    }(0, o.Rc)((() => (window.addEventListener("flagModalOpen", T), () => {
                        window.removeEventListener("flagModalOpen", T)
                    }))), r.MWq((() => {
                        const e = document.getElementById("no-longer-needed-text-input");
                        "39" === r.JtY(x) ? e.focus() : r.hZp(L, "");
                        const a = document.getElementById("other-text-input");
                        "19" === r.JtY(x) ? a.focus() : r.hZp(Y, "")
                    })); {
                        const o = e => {
                                var a = r.Imx(),
                                    t = r.esp(a),
                                    o = e => {
                                        var a = r.Qq7();
                                        a.nodeValue = __tr(["You already have a pending flag"], undefined, "en", []), r.BCw(e, a)
                                    },
                                    n = e => {
                                        var a = r.Qq7();
                                        a.nodeValue = __tr(["Why are you flagging this comment?"], undefined, "en", []), r.BCw(e, a)
                                    };
                                r.if(t, (e => {
                                    r.JtY(j) ? e(o) : e(n, !1)
                                })), r.BCw(e, a)
                            },
                            c = e => {
                                var o = m(),
                                    c = r.jfp(o),
                                    d = e => {
                                        var a = p();
                                        let o;
                                        var n = r.jfp(a);
                                        r.R0j(n), n.value = n.__value = "45";
                                        var s = r.hg4(n, 2),
                                            c = r.jfp(s);
                                        c.nodeValue = `${__tr(["Probable spam."], undefined, "en", [])??""} `;
                                        var d = r.hg4(c),
                                            i = r.jfp(d);
                                        r.qyt(i, (() => __tr(["This comment promotes a product, service or website while <a href=\"$url$\">failing to disclose the author's affiliation</a>."], {
                                            url: "/help/promotion"
                                        }, "en", []))), r.cLc(d), r.cLc(s);
                                        var h = r.hg4(s, 2);
                                        l(h, (() => "45")), r.cLc(a), r.vNg((e => {
                                            o = r.ysU(a, 1, "s-check-control", null, o, e), n.disabled = r.JtY(j)
                                        }), [() => ({
                                            "is-disabled": r.JtY(j)
                                        })]), r.CJk(t, [], n, (() => r.JtY(x)), (e => r.hZp(x, e))), r.BCw(e, a)
                                    };
                                r.if(c, (e => {
                                    a.showSpamFlag && e(d)
                                }));
                                var i = r.hg4(c, 2),
                                    w = e => {
                                        var a = h();
                                        let o;
                                        var n = r.jfp(a);
                                        r.R0j(n), n.value = n.__value = "20";
                                        var s = r.hg4(n, 2),
                                            c = r.jfp(s);
                                        c.nodeValue = `${__tr(["Unfriendly or contains harassment/bigotry/abuse."], undefined, "en", [])??""} `;
                                        var d = r.hg4(c),
                                            i = r.jfp(d);
                                        r.qyt(i, (() => __tr(["This comment is unkind, insulting or attacks another person or group. Learn more in our  <a href=\"$url$\">Abusive behavior policy</a>."], {
                                            url: "/conduct/abusive-behavior"
                                        }, "en", []))), r.cLc(d), r.cLc(s);
                                        var p = r.hg4(s, 2);
                                        l(p, (() => "20")), r.cLc(a), r.vNg((e => {
                                            o = r.ysU(a, 1, "s-check-control", null, o, e), n.disabled = r.JtY(j)
                                        }), [() => ({
                                            "is-disabled": r.JtY(j)
                                        })]), r.CJk(t, [], n, (() => r.JtY(x)), (e => r.hZp(x, e))), r.BCw(e, a)
                                    },
                                    _ = e => {
                                        var o = v(),
                                            n = r.esp(o);
                                        let s;
                                        var c = r.jfp(n);
                                        r.R0j(c), c.value = c.__value = "20";
                                        var d = r.hg4(c, 2),
                                            i = r.jfp(d),
                                            p = e => {
                                                var a = u(),
                                                    t = r.esp(a);
                                                t.nodeValue = `${__tr(["It contains harassment, bigotry or abuse."], undefined, "en", [])??""} `;
                                                var o = r.hg4(t),
                                                    n = r.jfp(o);
                                                r.qyt(n, (() => __tr(["This comment attacks a person or group. Learn more in our <a href=\"$url$\">Abusive behavior policy</a>."], {
                                                    url: "/conduct/abusive-behavior"
                                                }, "en", []))), r.cLc(o), r.BCw(e, a)
                                            },
                                            h = e => {
                                                var a = f(),
                                                    t = r.esp(a);
                                                t.nodeValue = `${__tr(["It's rude or abusive."], undefined, "en", [])??""} `;
                                                var o = r.hg4(t),
                                                    n = r.jfp(o);
                                                r.qyt(n, (() => __tr(["A reasonable person would find this content inappropriate for respectful discourse."], undefined, "en", []))), r.cLc(o), r.BCw(e, a)
                                            };
                                        r.if(i, (e => {
                                            a.enableCodeOfConduct ? e(p) : e(h, !1)
                                        })), r.cLc(d);
                                        var m = r.hg4(d, 2);
                                        l(m, (() => "20")), r.cLc(n);
                                        var w = r.hg4(n, 2),
                                            _ = e => {
                                                var a = g();
                                                let o;
                                                var n = r.jfp(a);
                                                r.R0j(n), n.value = n.__value = "40";
                                                var s = r.hg4(n, 2),
                                                    c = r.jfp(s);
                                                c.nodeValue = `${__tr(["It's unfriendly or unkind."], undefined, "en", [])??""} `;
                                                var d = r.hg4(c),
                                                    i = r.jfp(d);
                                                r.qyt(i, (() => __tr(["This comment is rude or condescending. Learn more in our <a href=\"$url$\">Code of Conduct</a>."], {
                                                    url: "/conduct/abusive-behavior"
                                                }, "en", []))), r.cLc(d), r.cLc(s);
                                                var p = r.hg4(s, 2);
                                                l(p, (() => "40")), r.cLc(a), r.vNg((e => {
                                                    o = r.ysU(a, 1, "s-check-control", null, o, e), n.disabled = r.JtY(j)
                                                }), [() => ({
                                                    "is-disabled": r.JtY(j)
                                                })]), r.CJk(t, [], n, (() => r.JtY(x)), (e => r.hZp(x, e))), r.BCw(e, a)
                                            };
                                        r.if(w, (e => {
                                            a.enableCodeOfConduct && e(_)
                                        })), r.vNg((e => {
                                            s = r.ysU(n, 1, "s-check-control", null, s, e), c.disabled = r.JtY(j)
                                        }), [() => ({
                                            "is-disabled": r.JtY(j)
                                        })]), r.CJk(t, [], c, (() => r.JtY(x)), (e => r.hZp(x, e))), r.BCw(e, o)
                                    };
                                r.if(i, (e => {
                                    a.mergeUnfriendlyAndRudeFlags ? e(w) : e(_, !1)
                                }));
                                var y = r.hg4(i, 2);
                                let b;
                                var C = r.jfp(y);
                                r.R0j(C), C.value = C.__value = "39";
                                var k = r.hg4(C, 2),
                                    J = r.jfp(k),
                                    T = r.jfp(J);
                                T.nodeValue = `${__tr(["Not needed."], undefined, "en", [])??""} `, r.hg4(T).textContent = __tr(["This comment is not relevant to the post."], undefined, "en", []), r.cLc(J);
                                var O = r.hg4(J, 2);
                                let $;
                                var S = r.jfp(O);
                                (0, n.Z_)(S, {
                                    id: "no-longer-needed-text-input",
                                    placeholder: __tr(["e.g., “This comment has nothing to do with the post.” (optional)"], undefined, "en", []),
                                    get value() {
                                        return r.JtY(L)
                                    },
                                    set value(e) {
                                        r.hZp(L, e, !0)
                                    }
                                }), s(r.hg4(S, 2), {
                                    get currentLength() {
                                        return r.JtY(L).length
                                    },
                                    minCount: 6,
                                    maxCount: 500
                                }), r.cLc(O);
                                var E = r.hg4(O, 2);
                                l(E, (() => "39")), r.cLc(k), r.cLc(y);
                                var U = r.hg4(y, 2);
                                let Z;
                                var R = r.jfp(U);
                                r.R0j(R), R.value = R.__value = "19";
                                var B = r.hg4(R, 2),
                                    I = r.jfp(B),
                                    M = r.jfp(I);
                                M.nodeValue = `${__tr(["Something else."], undefined, "en", [])??""} `, r.hg4(M).textContent = __tr(["A problem not listed above. Try to be as specific as possible."], undefined, "en", []), r.cLc(I);
                                var N = r.hg4(I, 2);
                                let A;
                                var F = r.jfp(N);
                                (0, n.Z_)(F, {
                                    id: "other-text-input",
                                    placeholder: __tr(["e.g., “This comment says my question is spam, even though it’s not.”"], undefined, "en", []),
                                    get value() {
                                        return r.JtY(Y)
                                    },
                                    set value(e) {
                                        r.hZp(Y, e, !0)
                                    }
                                }), s(r.hg4(F, 2), {
                                    get currentLength() {
                                        return r.JtY(Y).length
                                    },
                                    minCount: 6,
                                    maxCount: 500
                                }), r.cLc(N);
                                var V = r.hg4(N, 2);
                                l(V, (() => "19")), r.cLc(B), r.cLc(U), r.cLc(o), r.vNg(((e, a, t, o) => {
                                    b = r.ysU(y, 1, "s-check-control", null, b, e), C.disabled = r.JtY(j), $ = r.ysU(O, 1, "d-flex fd-column g8", null, $, a), Z = r.ysU(U, 1, "s-check-control", null, Z, t), R.disabled = r.JtY(j), A = r.ysU(N, 1, "d-flex fd-column g8", null, A, o)
                                }), [() => ({
                                    "is-disabled": r.JtY(j)
                                }), () => ({
                                    "d-none": "39" !== r.JtY(x) || r.JtY(j)
                                }), () => ({
                                    "is-disabled": r.JtY(j)
                                }), () => ({
                                    "d-none": "19" !== r.JtY(x) || r.JtY(j)
                                })]), r.CJk(t, [], C, (() => r.JtY(x)), (e => r.hZp(x, e))), r.CJk(t, [], R, (() => r.JtY(x)), (e => r.hZp(x, e))), r.BCw(e, o)
                            },
                            d = e => {
                                var a = _(),
                                    t = r.jfp(a),
                                    o = r.jfp(t),
                                    l = e => {
                                        (0, n.$n)(e, {
                                            class: "flex--item",
                                            weight: "filled",
                                            onclick: E,
                                            children: (e, a) => {
                                                r.K2T();
                                                var t = r.Qq7();
                                                t.nodeValue = __tr(["Retract flag"], undefined, "en", []), r.BCw(e, t)
                                            },
                                            $$slots: {
                                                default: !0
                                            }
                                        })
                                    },
                                    s = e => {
                                        (0, n.$n)(e, {
                                            class: "flex--item",
                                            weight: "filled",
                                            onclick: $,
                                            "data-testid": "confirm-button",
                                            children: (e, a) => {
                                                r.K2T();
                                                var t = r.Qq7();
                                                t.nodeValue = __tr(["Flag comment"], undefined, "en", []), r.BCw(e, t)
                                            },
                                            $$slots: {
                                                default: !0
                                            }
                                        })
                                    };
                                r.if(o, (e => {
                                    r.JtY(j) ? e(l) : e(s, !1)
                                }));
                                var c = r.hg4(o, 2);
                                (0, n.$n)(c, {
                                    class: "flex--item",
                                    onclick: () => {
                                        r.hZp(y, !1), O()
                                    },
                                    children: (e, a) => {
                                        r.K2T();
                                        var t = r.Qq7();
                                        t.nodeValue = __tr(["Cancel"], undefined, "en", []), r.BCw(e, t)
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                }), r.cLc(t);
                                var d = r.hg4(t, 2),
                                    i = e => {
                                        var a = w(),
                                            t = r.jfp(a);
                                        r.cLc(a), r.vNg((() => r.jax(t, `You have ${r.JtY(k)??""} flags left today`))), r.BCw(e, a)
                                    };
                                r.if(d, (e => {
                                    r.JtY(j) || r.JtY(J) || e(i)
                                })), r.cLc(a), r.BCw(e, a)
                            };
                        (0, n.aF)(e, r.DuQ({
                            id: "follow-ups-flag-modal",
                            class: "ps-relative ws5"
                        }, {}, {
                            get visible() {
                                return r.JtY(y)
                            },
                            set visible(e) {
                                r.hZp(y, e, !0)
                            },
                            $$events: {
                                close: O
                            },
                            header: o,
                            body: c,
                            footer: d,
                            $$slots: {
                                header: !0,
                                body: !0,
                                footer: !0
                            }
                        }))
                    }
                    r.uYY()
                }), {
                    target: b,
                    props: {
                        showSpamFlag: y.ShowSpamFlag,
                        mergeUnfriendlyAndRudeFlags: y.MergeUnfriendlyAndRudeFlags,
                        fkey: y.FKey,
                        enableCodeOfConduct: y.EnableCodeOfConduct
                    }
                })
            },
            53117: (e, a, t) => {
                t.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            54152: (e, a, t) => {
                t.d(a, {
                    nFV: () => o
                });
                const o = '<svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18"  viewBox="0 0 18 18"><path  d="M15 4.41 13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9z"/></svg>'
            },
            34164: (e, a, t) => {
                function o(e) {
                    var a, t, r = "";
                    if ("string" == typeof e || "number" == typeof e) r += e;
                    else if ("object" == typeof e)
                        if (Array.isArray(e)) {
                            var n = e.length;
                            for (a = 0; a < n; a++) e[a] && (t = o(e[a])) && (r && (r += " "), r += t)
                        } else
                            for (t in e) e[t] && (r && (r += " "), r += t);
                    return r
                }

                function r() {
                    for (var e, a, t = 0, r = "", n = arguments.length; t < n; t++)(e = arguments[t]) && (a = o(e)) && (r && (r += " "), r += a);
                    return r
                }
                t.d(a, {
                    $: () => r
                })
            },
            74488: (e, a, t) => {
                t.d(a, {
                    h5: () => o,
                    IJ: () => n
                });
                const o = !0,
                    r = globalThis.process ? .env ? .NODE_ENV,
                    n = r && !r.toLowerCase().startsWith("prod")
            },
            2322: (e, a, t) => {
                t(85630), t(22024)
            }
        },
        t = {};

    function o(e) {
        var r = t[e];
        if (void 0 !== r) return r.exports;
        var n = t[e] = {
            exports: {}
        };
        return a[e](n, n.exports, o), n.exports
    }
    o.m = a, e = [], o.O = (a, t, r, n) => {
        if (!t) {
            var l = 1 / 0;
            for (i = 0; i < e.length; i++) {
                for (var [t, r, n] = e[i], s = !0, c = 0; c < t.length; c++)(!1 & n || l >= n) && Object.keys(o.O).every((e => o.O[e](t[c]))) ? t.splice(c--, 1) : (s = !1, n < l && (l = n));
                if (s) {
                    e.splice(i--, 1);
                    var d = r();
                    void 0 !== d && (a = d)
                }
            }
            return a
        }
        n = n || 0;
        for (var i = e.length; i > 0 && e[i - 1][2] > n; i--) e[i] = e[i - 1];
        e[i] = [t, r, n]
    }, o.d = (e, a) => {
        for (var t in a) o.o(a, t) && !o.o(e, t) && Object.defineProperty(e, t, {
            enumerable: !0,
            get: a[t]
        })
    }, o.o = (e, a) => Object.prototype.hasOwnProperty.call(e, a), o.j = 987, o.p = "", (() => {
        var e = {
            987: 0
        };
        o.O.j = a => 0 === e[a];
        var a = (a, t) => {
                var r, n, [l, s, c] = t,
                    d = 0;
                if (l.some((a => 0 !== e[a]))) {
                    for (r in s) o.o(s, r) && (o.m[r] = s[r]);
                    if (c) var i = c(o)
                }
                for (a && a(t); d < l.length; d++) n = l[d], o.o(e, n) && e[n] && e[n][0](), e[n] = 0;
                return o.O(i)
            },
            t = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        t.forEach(a.bind(null, 0)), t.push = a.bind(null, t.push.bind(t))
    })(), o.O(void 0, [5622, 8112], (() => o(53117)));
    var r = o.O(void 0, [5622, 8112], (() => o(72706)));
    r = o.O(r)
})();