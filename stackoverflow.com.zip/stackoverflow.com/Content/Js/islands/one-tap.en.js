(() => {
    "use strict";
    var e, t = {
            29209: (e, t, o) => {
                var r = o(22024);

                function n(e) {
                    const t = function(e) {
                        const t = e.replace(/\.(t|j)sx?/, ""),
                            o = `script[type="application/json"][data-role="module-args"][data-module-name="${t}"]`;
                        return document.querySelectorAll(o)
                    }(e);
                    return Array.from(t).map((e => JSON.parse(e.textContent || e.innerText)))
                }
                o(82170);
                var a = o(67578),
                    c = a.jBe(a.vUu('<script src="https://accounts.google.com/gsi/client" async><\/script><!>', 1)),
                    i = a.vUu('<form id="one-tap-form" name="one-tap-form" method="post"><input type="hidden" name="fKey"/> <input type="hidden" name="googleIdToken" value=""/></form>');

                function l(e, t) {
                    a.VCO(t, !0);
                    const o = a._w2(t, "returnUrl", 3, ""),
                        n = a._w2(t, "fKey", 3, ""),
                        l = a._w2(t, "googleClientId", 3, ""),
                        s = a._w2(t, "autoselect", 3, !1);
                    let p = a.wk1(void 0),
                        u = a.wk1(void 0);

                    function d(e) {
                        a.JtY(u).value = e.credential, a.JtY(p).submit()
                    }(0, r.Rc)((() => {
                        window.onload = function() {
                            const e = {
                                client_id: l(),
                                callback: d,
                                cancel_on_tap_outside: !1,
                                auto_select: s(),
                                use_fedcm_for_prompt: !0
                            };
                            google.accounts.id.initialize(e), google.accounts.id.prompt()
                        }
                    }));
                    var f = i();
                    a.d5f((e => {
                        var t = c();
                        a.hg4(a.esp(t));
                        a.BCw(e, t)
                    }));
                    var v = a.jfp(f);
                    a.R0j(v);
                    var g = a.hg4(v, 2);
                    a.Lcc(g, (e => a.hZp(u, e)), (() => a.JtY(u))), a.cLc(f), a.Lcc(f, (e => a.hZp(p, e)), (() => a.JtY(p))), a.vNg((() => {
                        a.aIK(f, "action", `/users/auth/gcp?ssrc=google-one-tap&returnurl=${o()??""}`), a.to4(v, n())
                    })), a.BCw(e, f), a.uYY()
                }
                n("islands/one-tap/index.mod.ts").forEach((e => {
                    const t = document.getElementById(e.ContainerElementId);
                    (0, r.Or)(l, {
                        target: t,
                        props: {
                            fKey: e.FKey,
                            googleClientId: e.GoogleClientId,
                            autoselect: e.Autoselect,
                            returnUrl: e.ReturnUrl
                        }
                    })
                }))
            },
            53117: (e, t, o) => {
                o.p = document.getElementById("webpack-public-path").innerText + "Js/"
            },
            74488: (e, t, o) => {
                o.d(t, {
                    h5: () => r,
                    IJ: () => a
                });
                const r = !0,
                    n = globalThis.process ? .env ? .NODE_ENV,
                    a = n && !n.toLowerCase().startsWith("prod")
            }
        },
        o = {};

    function r(e) {
        var n = o[e];
        if (void 0 !== n) return n.exports;
        var a = o[e] = {
            exports: {}
        };
        return t[e](a, a.exports, r), a.exports
    }
    r.m = t, e = [], r.O = (t, o, n, a) => {
        if (!o) {
            var c = 1 / 0;
            for (p = 0; p < e.length; p++) {
                for (var [o, n, a] = e[p], i = !0, l = 0; l < o.length; l++)(!1 & a || c >= a) && Object.keys(r.O).every((e => r.O[e](o[l]))) ? o.splice(l--, 1) : (i = !1, a < c && (c = a));
                if (i) {
                    e.splice(p--, 1);
                    var s = n();
                    void 0 !== s && (t = s)
                }
            }
            return t
        }
        a = a || 0;
        for (var p = e.length; p > 0 && e[p - 1][2] > a; p--) e[p] = e[p - 1];
        e[p] = [o, n, a]
    }, r.d = (e, t) => {
        for (var o in t) r.o(t, o) && !r.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: t[o]
        })
    }, r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), r.j = 2434, r.p = "", (() => {
        var e = {
            2434: 0
        };
        r.O.j = t => 0 === e[t];
        var t = (t, o) => {
                var n, a, [c, i, l] = o,
                    s = 0;
                if (c.some((t => 0 !== e[t]))) {
                    for (n in i) r.o(i, n) && (r.m[n] = i[n]);
                    if (l) var p = l(r)
                }
                for (t && t(o); s < c.length; s++) a = c[s], r.o(e, a) && e[a] && e[a][0](), e[a] = 0;
                return r.O(p)
            },
            o = self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || [];
        o.forEach(t.bind(null, 0)), o.push = t.bind(null, o.push.bind(o))
    })(), r.O(void 0, [5622], (() => r(53117)));
    var n = r.O(void 0, [5622], (() => r(29209)));
    n = r.O(n)
})();