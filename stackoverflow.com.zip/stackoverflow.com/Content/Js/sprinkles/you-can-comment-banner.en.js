(() => {
    "use strict";
    var e = {
            99296: () => {
                ! function() {
                    const e = document.querySelector(".js-clear-you-can-comment-banner-anon");
                    e && e.addEventListener("click", (async () => {
                        const e = document.querySelector(".js-you-can-comment-banner-anon");
                        null == e || e.classList.add("d-none");
                        const n = new Date;
                        n.setTime(n.getTime() + 31536e6), document.cookie = `you-can-comment-dismissed=1; path=/; expires=${n.toUTCString()};`
                    }))
                }(),
                function() {
                    const e = document.querySelector(".js-clear-you-can-comment-banner");
                    e && e.addEventListener("click", (async () => {
                        const e = document.querySelector(".js-you-can-comment-banner");
                        null == e || e.classList.add("d-none");
                        const n = new FormData;
                        n.append("fkey", StackExchange.options.user.fkey), await fetch("/comments/dismiss-you-can-comment-banner", {
                            method: "POST",
                            body: n
                        })
                    }))
                }()
            }
        },
        n = {};

    function t(o) {
        var c = n[o];
        if (void 0 !== c) return c.exports;
        var r = n[o] = {
            exports: {}
        };
        return e[o](r, r.exports, t), r.exports
    }
    t.n = e => {
        var n = e && e.__esModule ? () => e.default : () => e;
        return t.d(n, {
            a: n
        }), n
    }, t.d = (e, n) => {
        for (var o in n) t.o(n, o) && !t.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: n[o]
        })
    }, t.o = (e, n) => Object.prototype.hasOwnProperty.call(e, n), t.p = "", t.p = document.getElementById("webpack-public-path").innerText + "Js/", t(99296)
})();