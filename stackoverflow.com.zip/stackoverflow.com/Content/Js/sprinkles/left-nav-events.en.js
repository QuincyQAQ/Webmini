(() => {
    "use strict";
    var t = {
        p: ""
    };
    t.p = document.getElementById("webpack-public-path").innerText + "Js/", (() => {
        function t() {}
        var e = function(t, e, n) {
            return "symbol" == typeof e && (e = e.description ? "[".concat(e.description, "]") : ""), Object.defineProperty(t, "name", {
                configurable: !0,
                value: n ? "".concat(n, " ", e) : e
            })
        };

        function n(o, c, i, s, r) {
            return {
                withTargets: (...t) => {
                    const e = n(o, [...c, ...t], i, s, r),
                        a = () => e;
                    return Object.assign(a, e), a
                },
                withValues: t => n(o, c, { ...i,
                    ...t
                }, s, r),
                withClasses: (...t) => n(o, c, i, [...s, ...t], r),
                withElementType: () => n(o, c, i, s, r),
                withOutlet: t => n(o, c, i, s, [...r, t.controllerName]),
                withNamedOutlet: t => n(o, c, i, s, [...r, t]),
                build: () => {
                    var n;
                    return {
                        Base: (n = class extends a {}, e(n, "Base"), n.controllerName = o, n.targets = c, n.values = i, n.classes = s, n.outlets = r, n),
                        stimulusCallback: t
                    }
                }
            }
        }
        const a = function() {
            const t = new(Stacks.createController({}))({}),
                e = Object.getPrototypeOf(t),
                n = Object.getPrototypeOf(e);
            return Object.getPrototypeOf(n).constructor
        }();
        window.Stacks;
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        const {
            Base: o
        } = (c = "left-nav-events-navigation", n(c, [], {}, [], [])).withValues({
            destination: Number,
            location: Number,
            activityNotification: Number
        }).build();
        var c;
        const i = [class extends o {
            send() {
                ! function(t, e, n, a) {
                    const o = new FormData;
                    o.append("fKey", null != a ? a : StackExchange.options.user.fkey), o.append("data", JSON.stringify(e)), o.append("event", t);
                    let c = {};
                    n && (c["X-Previous-Event-Id"] = n), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                        method: "POST",
                        keepalive: !0,
                        body: o,
                        headers: c
                    }).then((() => {}))
                }("left_nav.click", {
                    source: window.location.href,
                    destination: this.destinationValue,
                    activityNotification: this.activityNotificationValue,
                    location: this.locationValue
                })
            }
        }];
        for (const t of i) {
            if (!t.controllerName.startsWith("left-nav-events")) throw new Error("all stimulus controllers in the stack events module should be namespaced with `left-nav-events-`");
            Stacks.application.register(t.controllerName, t)
        }
    })()
})();