(() => {
    var t = {
            23383: () => {
                let t;
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.gaInitialized = new Promise((e => {
                    t = e
                })), StackExchange.gaReady = function(t) {
                    StackExchange.gaInitialized.then(t)
                }, StackExchange.ga = function() {
                    if (StackExchange.ga && StackExchange.ga.inited) return StackExchange.ga;
                    var e, n = 0,
                        a = null;
                    const r = {};
                    var c = function(t) {
                            t.querySelectorAll("[data-ga]").forEach((t => {
                                const e = "FORM" === t.tagName,
                                    n = e ? "submit" : "click";
                                t.addEventListener(n, (() => {
                                    const n = g(t);
                                    null !== n && (o(t, n), e && l(t, n))
                                }))
                            }));
                            t.querySelectorAll("[data-ga-action]").forEach((t => {
                                t.addEventListener("change", (() => u(t)))
                            }))
                        },
                        i = function(t, n, a, r) {
                            setTimeout((() => function(t, n, a, r) {
                                try {
                                    if (s(`track: category: '${t}', action: '${n}', label: '${a}'`), !e) return;
                                    if (null == t || null == n) return;
                                    e && e.tracker && e.tracker("event", t, {
                                        category: t,
                                        action: n,
                                        label: a,
                                        fields: r
                                    })
                                } catch (e) {
                                    d(`track: category: '${t}', action: '${n}', label: '${a}'`, e)
                                }
                            }(t, n, a, r)), 0)
                        },
                        o = function(t, n) {
                            e && (void 0 === n && (n = g(t)), null !== n && i(n.category, n.action, n.label, n.fields))
                        },
                        l = function(t, n) {
                            if (!e) return;
                            if (void 0 === n && (n = g(t)), null === n) return;
                            const a = t.getAttribute("id"),
                                c = r[a];
                            if (void 0 !== c) {
                                for (var o in c) {
                                    const t = `${n.inputActionPrefix} | ${o}`,
                                        e = c[o];
                                    i(n.category, t, e, {
                                        nonInteraction: !1
                                    })
                                }
                                r[a] = {}
                            }
                        },
                        u = function(t) {
                            if (!e) return;
                            var a;
                            if ("checkbox" === t.type) a = t.checked;
                            else if ("SELECT" === t.tagName) {
                                const e = t;
                                a = Array.from(e.selectedOptions).map((t => t.getAttribute("data-ga-value") || t.value)).join(" ")
                            } else a = t.getAttribute("data-ga-value") || t.value;
                            const c = t.closest("form");
                            if (!c || null === a) return;
                            var i = c.getAttribute("id");
                            i || (i = "ga-form-" + n++, c.setAttribute("id", i));
                            let o = r[i];
                            void 0 === o && (o = r[i] = {});
                            const l = t.getAttribute("data-ga-action"),
                                u = "false" !== t.getAttribute("data-ga-is-pii");
                            o[l] = u ? "PII Omitted" : a
                        },
                        g = function(t) {
                            const e = t.getAttribute("data-ga");
                            if (!e) return null;
                            try {
                                const t = JSON.parse(e);
                                return {
                                    category: t[0],
                                    action: t[1],
                                    label: t[2],
                                    inputActionPrefix: t[3],
                                    fields: t[4]
                                }
                            } catch (e) {
                                const n = t,
                                    a = n.__gaData || n.dataset.ga;
                                return void 0 === a ? null : {
                                    category: a[0],
                                    action: a[1],
                                    label: a[2],
                                    inputActionPrefix: a[3],
                                    fields: a[4]
                                }
                            }
                        };

                    function s(t) {
                        try {
                            if (!StackExchange.options.enableLogging) return;
                            console.log("StackExchange.ga: " + t)
                        } catch (t) {}
                    }

                    function d(t, e) {
                        try {
                            if (!StackExchange.options.enableLogging) return;
                            console.error(`StackExchange.ga: ${t}`, e)
                        } catch (t) {}
                    }

                    function k(t) {
                        s("initGA4"), f(t.consentsToPerformanceCookies, t.consentsToTargetingCookies), t.checkForAdBlock && (t.eventParameters.ads_blocked = function() {
                            let t, e = document.createElement("ins");
                            return e.className = "AdSense", e.style.display = "block", e.style.position = "absolute", e.style.top = "-1px", e.style.height = "1px", document.body.appendChild(e), t = !e.clientHeight, document.body.removeChild(e), t
                        }()), t.tracker("js", new Date), t.sendTitles || (t.eventParameters.page_title = "Channel Page"), t.tracker("set", t.eventParameters), t.tracker("config", t.trackingCodes[0], t.eventParameters), t.trackClicks && function() {
                            function t(t) {
                                let e;
                                try {
                                    e = new URL(t)
                                } catch (e) {
                                    return {
                                        href: t,
                                        outbound: !1
                                    }
                                }
                                return { ...e,
                                    outbound: !(e.host === window.location.host)
                                }
                            }

                            function e(t) {
                                for (var e; t;) {
                                    if ("A" === t.nodeName) return t;
                                    if ("BUTTON" === t.nodeName) return t;
                                    if ("INPUT" === t.nodeName) {
                                        var n = null === (e = t.getAttribute("type")) || void 0 === e ? void 0 : e.toUpperCase();
                                        if ("BUTTON" === n || "SUBMIT" === n) return t
                                    }
                                    t = t.parentNode
                                }
                                return null
                            }
                            window.addEventListener("click", (n => {
                                const a = e(n.target);
                                if (a && "getAttribute" in a) {
                                    let e = t(a.getAttribute("href") || "");
                                    StackExchange.gaReady((() => h("click", {
                                        outbound: e.outbound,
                                        link_text: a.innerText,
                                        link_classes: a.getAttribute("class"),
                                        link_id: a.getAttribute("id"),
                                        link_url: a.getAttribute("href")
                                    })))
                                }
                                return !0
                            }), {
                                capture: !0,
                                passive: !0
                            })
                        }(), s("initGA4 done")
                    }

                    function f(t, n) {
                        e.tracker("consent", "update", {
                            analytics_storage: t,
                            ad_storage: n,
                            ad_user_data: n,
                            ad_personalization: n
                        })
                    }

                    function h(t, n) {
                        try {
                            s(`trackGA4: eventName: '${t}'`), navigator && navigator.sendBeacon && (n = Object.assign({}, n, {
                                transport_type: "beacon"
                            })), (null == e ? void 0 : e.tracker) && (null == e || e.tracker("event", t, n))
                        } catch (e) {
                            d(`trackGA4: eventName: '${t}'`, e)
                        }
                    }
                    return {
                        inited: !1,
                        init: function(n) {
                            if (!n) return;
                            const r = n.GA4;
                            r && r.tracker && r.trackingCodes && r.trackingCodes.length > 0 && (k(e = r), e.tracker("get", r.trackingCodes[0], "client_id", (t => {
                                t && (a = t)
                            })), t()), c(document), StackExchange.ga.inited = !0
                        },
                        bindHandlers: c,
                        track: i,
                        trackElement: o,
                        trackFormInputs: l,
                        trackGA4: h,
                        recordInputChange: u,
                        getGA4ClientId: function() {
                            if (e) return a
                        },
                        updateGA4Consent: f
                    }
                }()
            }
        },
        e = {};

    function n(a) {
        var r = e[a];
        if (void 0 !== r) return r.exports;
        var c = e[a] = {
            exports: {}
        };
        return t[a](c, c.exports, n), c.exports
    }
    n.n = t => {
        var e = t && t.__esModule ? () => t.default : () => t;
        return n.d(e, {
            a: e
        }), e
    }, n.d = (t, e) => {
        for (var a in e) n.o(e, a) && !n.o(t, a) && Object.defineProperty(t, a, {
            enumerable: !0,
            get: e[a]
        })
    }, n.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e), n.p = "", (() => {
        "use strict";
        n.p = document.getElementById("webpack-public-path").innerText + "Js/"
    })(), (() => {
        "use strict";
        n(23383);
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
        StackExchange.ga.init, StackExchange.ga.bindHandlers, StackExchange.ga.track, StackExchange.ga.trackElement, StackExchange.ga.trackFormInputs, StackExchange.ga.recordInputChange
    })()
})();