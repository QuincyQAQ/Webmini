(() => {
    var e = {
            84124: (e, u) => {
                "use strict";

                function n(e) {
                    var u = "function" == typeof Map ? new Map : void 0;
                    return n = function(e) {
                        if (null === e || ! function(e) {
                                try {
                                    return -1 !== Function.toString.call(e).indexOf("[native code]")
                                } catch (u) {
                                    return "function" == typeof e
                                }
                            }(e)) return e;
                        if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                        if (void 0 !== u) {
                            if (u.has(e)) return u.get(e);
                            u.set(e, n)
                        }

                        function n() {
                            return function(e, u, n) {
                                if (r()) return Reflect.construct.apply(null, arguments);
                                var t = [null];
                                t.push.apply(t, u);
                                var a = new(e.bind.apply(e, t));
                                return n && s(a, n.prototype), a
                            }(e, arguments, i(this).constructor)
                        }
                        return n.prototype = Object.create(e.prototype, {
                            constructor: {
                                value: n,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), s(n, e)
                    }, n(e)
                }

                function t(e, u) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, u) {
                        var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                        if (null != n) {
                            var t, a, r, i, D = [],
                                s = !0,
                                o = !1;
                            try {
                                if (r = (n = n.call(e)).next, 0 === u) {
                                    if (Object(n) !== n) return;
                                    s = !1
                                } else
                                    for (; !(s = (t = r.call(n)).done) && (D.push(t.value), D.length !== u); s = !0);
                            } catch (e) {
                                o = !0, a = e
                            } finally {
                                try {
                                    if (!s && null != n.return && (i = n.return(), Object(i) !== i)) return
                                } finally {
                                    if (o) throw a
                                }
                            }
                            return D
                        }
                    }(e, u) || c(e, u) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function a(e, u, n) {
                    return u = i(u),
                        function(e, u) {
                            if (u && ("object" == C(u) || "function" == typeof u)) return u;
                            if (void 0 !== u) throw new TypeError("Derived constructors may only return object or undefined");
                            return function(e) {
                                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return e
                            }(e)
                        }(e, r() ? Reflect.construct(u, n || [], i(e).constructor) : u.apply(e, n))
                }

                function r() {
                    try {
                        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {})))
                    } catch (e) {}
                    return (r = function() {
                        return !!e
                    })()
                }

                function i(e) {
                    return i = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    }, i(e)
                }

                function D(e, u) {
                    if ("function" != typeof u && null !== u) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(u && u.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), u && s(e, u)
                }

                function s(e, u) {
                    return s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, u) {
                        return e.__proto__ = u, e
                    }, s(e, u)
                }

                function o(e) {
                    return function(e) {
                        if (Array.isArray(e)) return l(e)
                    }(e) || function(e) {
                        if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                    }(e) || c(e) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function c(e, u) {
                    if (e) {
                        if ("string" == typeof e) return l(e, u);
                        var n = {}.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, u) : void 0
                    }
                }

                function l(e, u) {
                    (null == u || u > e.length) && (u = e.length);
                    for (var n = 0, t = Array(u); n < u; n++) t[n] = e[n];
                    return t
                }

                function d(e, u) {
                    if (!(e instanceof u)) throw new TypeError("Cannot call a class as a function")
                }

                function E(e, u) {
                    for (var n = 0; n < u.length; n++) {
                        var t = u[n];
                        t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(e, A(t.key), t)
                    }
                }

                function F(e, u, n) {
                    return u && E(e.prototype, u), n && E(e, n), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), e
                }

                function A(e) {
                    var u = function(e, u) {
                        if ("object" != C(e) || !e) return e;
                        var n = e[Symbol.toPrimitive];
                        if (void 0 !== n) {
                            var t = n.call(e, u || "default");
                            if ("object" != C(t)) return t;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === u ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == C(u) ? u : u + ""
                }

                function C(e) {
                    return C = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    }, C(e)
                }
                var g = function() {
                    function e(u) {
                        return u instanceof Map ? u.clear = u.delete = u.set = function() {
                            throw new Error("map is read-only")
                        } : u instanceof Set && (u.add = u.clear = u.delete = function() {
                            throw new Error("set is read-only")
                        }), Object.freeze(u), Object.getOwnPropertyNames(u).forEach((function(n) {
                            var t = u[n],
                                a = C(t);
                            "object" !== a && "function" !== a || Object.isFrozen(t) || e(t)
                        })), u
                    }
                    var u = function() {
                        return F((function e(u) {
                            d(this, e), void 0 === u.data && (u.data = {}), this.data = u.data, this.isMatchIgnored = !1
                        }), [{
                            key: "ignoreMatch",
                            value: function() {
                                this.isMatchIgnored = !0
                            }
                        }])
                    }();

                    function r(e) {
                        return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;")
                    }

                    function i(e) {
                        var u = Object.create(null);
                        for (var n in e) u[n] = e[n];
                        for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) a[r - 1] = arguments[r];
                        return a.forEach((function(e) {
                            for (var n in e) u[n] = e[n]
                        })), u
                    }
                    var s = function(e) {
                            return !!e.scope
                        },
                        l = function() {
                            return F((function e(u, n) {
                                d(this, e), this.buffer = "", this.classPrefix = n.classPrefix, u.walk(this)
                            }), [{
                                key: "addText",
                                value: function(e) {
                                    this.buffer += r(e)
                                }
                            }, {
                                key: "openNode",
                                value: function(e) {
                                    if (s(e)) {
                                        var u = function(e, u) {
                                            var n = u.prefix;
                                            if (e.startsWith("language:")) return e.replace("language:", "language-");
                                            if (e.includes(".")) {
                                                var t = e.split(".");
                                                return ["".concat(n).concat(t.shift())].concat(o(t.map((function(e, u) {
                                                    return "".concat(e).concat("_".repeat(u + 1))
                                                })))).join(" ")
                                            }
                                            return "".concat(n).concat(e)
                                        }(e.scope, {
                                            prefix: this.classPrefix
                                        });
                                        this.span(u)
                                    }
                                }
                            }, {
                                key: "closeNode",
                                value: function(e) {
                                    s(e) && (this.buffer += "</span>")
                                }
                            }, {
                                key: "value",
                                value: function() {
                                    return this.buffer
                                }
                            }, {
                                key: "span",
                                value: function(e) {
                                    this.buffer += '<span class="'.concat(e, '">')
                                }
                            }])
                        }(),
                        E = function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                u = {
                                    children: []
                                };
                            return Object.assign(u, e), u
                        },
                        A = function(e) {
                            function u(e) {
                                var n;
                                return d(this, u), (n = a(this, u)).options = e, n
                            }
                            return D(u, e), F(u, [{
                                key: "addText",
                                value: function(e) {
                                    "" !== e && this.add(e)
                                }
                            }, {
                                key: "startScope",
                                value: function(e) {
                                    this.openNode(e)
                                }
                            }, {
                                key: "endScope",
                                value: function() {
                                    this.closeNode()
                                }
                            }, {
                                key: "__addSublanguage",
                                value: function(e, u) {
                                    var n = e.root;
                                    u && (n.scope = "language:".concat(u)), this.add(n)
                                }
                            }, {
                                key: "toHTML",
                                value: function() {
                                    return new l(this, this.options).value()
                                }
                            }, {
                                key: "finalize",
                                value: function() {
                                    return this.closeAllNodes(), !0
                                }
                            }])
                        }(function() {
                            function e() {
                                d(this, e), this.rootNode = E(), this.stack = [this.rootNode]
                            }
                            return F(e, [{
                                key: "top",
                                get: function() {
                                    return this.stack[this.stack.length - 1]
                                }
                            }, {
                                key: "root",
                                get: function() {
                                    return this.rootNode
                                }
                            }, {
                                key: "add",
                                value: function(e) {
                                    this.top.children.push(e)
                                }
                            }, {
                                key: "openNode",
                                value: function(e) {
                                    var u = E({
                                        scope: e
                                    });
                                    this.add(u), this.stack.push(u)
                                }
                            }, {
                                key: "closeNode",
                                value: function() {
                                    if (this.stack.length > 1) return this.stack.pop()
                                }
                            }, {
                                key: "closeAllNodes",
                                value: function() {
                                    for (; this.closeNode(););
                                }
                            }, {
                                key: "toJSON",
                                value: function() {
                                    return JSON.stringify(this.rootNode, null, 4)
                                }
                            }, {
                                key: "walk",
                                value: function(e) {
                                    return this.constructor._walk(e, this.rootNode)
                                }
                            }], [{
                                key: "_walk",
                                value: function(e, u) {
                                    var n = this;
                                    return "string" == typeof u ? e.addText(u) : u.children && (e.openNode(u), u.children.forEach((function(u) {
                                        return n._walk(e, u)
                                    })), e.closeNode(u)), e
                                }
                            }, {
                                key: "_collapse",
                                value: function(u) {
                                    "string" != typeof u && u.children && (u.children.every((function(e) {
                                        return "string" == typeof e
                                    })) ? u.children = [u.children.join("")] : u.children.forEach((function(u) {
                                        e._collapse(u)
                                    })))
                                }
                            }])
                        }());

                    function g(e) {
                        return e ? "string" == typeof e ? e : e.source : null
                    }

                    function b(e) {
                        return f("(?=", e, ")")
                    }

                    function m(e) {
                        return f("(?:", e, ")*")
                    }

                    function p(e) {
                        return f("(?:", e, ")?")
                    }

                    function f() {
                        for (var e = arguments.length, u = new Array(e), n = 0; n < e; n++) u[n] = arguments[n];
                        return u.map((function(e) {
                            return g(e)
                        })).join("")
                    }

                    function B() {
                        for (var e = arguments.length, u = new Array(e), n = 0; n < e; n++) u[n] = arguments[n];
                        var t = function(e) {
                            var u = e[e.length - 1];
                            return "object" === C(u) && u.constructor === Object ? (e.splice(e.length - 1, 1), u) : {}
                        }(u);
                        return "(" + (t.capture ? "" : "?:") + u.map((function(e) {
                            return g(e)
                        })).join("|") + ")"
                    }

                    function h(e) {
                        return new RegExp(e.toString() + "|").exec("").length - 1
                    }
                    var _ = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;

                    function v(e, u) {
                        var n = u.joinWith,
                            t = 0;
                        return e.map((function(e) {
                            for (var u = t += 1, n = g(e), a = ""; n.length > 0;) {
                                var r = _.exec(n);
                                if (!r) {
                                    a += n;
                                    break
                                }
                                a += n.substring(0, r.index), n = n.substring(r.index + r[0].length), "\\" === r[0][0] && r[1] ? a += "\\" + String(Number(r[1]) + u) : (a += r[0], "(" === r[0] && t++)
                            }
                            return a
                        })).map((function(e) {
                            return "(".concat(e, ")")
                        })).join(n)
                    }
                    var y = "[a-zA-Z]\\w*",
                        w = "[a-zA-Z_]\\w*",
                        N = "\\b\\d+(\\.\\d+)?",
                        x = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)",
                        k = "\\b(0b[01]+)",
                        O = {
                            begin: "\\\\[\\s\\S]",
                            relevance: 0
                        },
                        M = {
                            scope: "string",
                            begin: "'",
                            end: "'",
                            illegal: "\\n",
                            contains: [O]
                        },
                        S = {
                            scope: "string",
                            begin: '"',
                            end: '"',
                            illegal: "\\n",
                            contains: [O]
                        },
                        T = function(e, u) {
                            var n = i({
                                scope: "comment",
                                begin: e,
                                end: u,
                                contains: []
                            }, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {});
                            n.contains.push({
                                scope: "doctag",
                                begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
                                end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
                                excludeBegin: !0,
                                relevance: 0
                            });
                            var t = B("I", "a", "is", "so", "us", "to", "at", "if", "in", "it", "on", /[A-Za-z]+['](d|ve|re|ll|t|s|n)/, /[A-Za-z]+[-][a-z]+/, /[A-Za-z][a-z]{2,}/);
                            return n.contains.push({
                                begin: f(/[ ]+/, "(", t, /[.]?[:]?([.][ ]|[ ])/, "){3}")
                            }), n
                        },
                        R = T("//", "$"),
                        I = T("/\\*", "\\*/"),
                        L = T("#", "$"),
                        z = {
                            scope: "number",
                            begin: N,
                            relevance: 0
                        },
                        j = {
                            scope: "number",
                            begin: x,
                            relevance: 0
                        },
                        P = {
                            scope: "number",
                            begin: k,
                            relevance: 0
                        },
                        U = {
                            scope: "regexp",
                            begin: /\/(?=[^/\n]*\/)/,
                            end: /\/[gimuy]*/,
                            contains: [O, {
                                begin: /\[/,
                                end: /\]/,
                                relevance: 0,
                                contains: [O]
                            }]
                        },
                        $ = {
                            scope: "title",
                            begin: y,
                            relevance: 0
                        },
                        K = {
                            scope: "title",
                            begin: w,
                            relevance: 0
                        },
                        q = {
                            begin: "\\.\\s*" + w,
                            relevance: 0
                        },
                        H = Object.freeze({
                            __proto__: null,
                            APOS_STRING_MODE: M,
                            BACKSLASH_ESCAPE: O,
                            BINARY_NUMBER_MODE: P,
                            BINARY_NUMBER_RE: k,
                            COMMENT: T,
                            C_BLOCK_COMMENT_MODE: I,
                            C_LINE_COMMENT_MODE: R,
                            C_NUMBER_MODE: j,
                            C_NUMBER_RE: x,
                            END_SAME_AS_BEGIN: function(e) {
                                return Object.assign(e, {
                                    "on:begin": function(e, u) {
                                        u.data._beginMatch = e[1]
                                    },
                                    "on:end": function(e, u) {
                                        u.data._beginMatch !== e[1] && u.ignoreMatch()
                                    }
                                })
                            },
                            HASH_COMMENT_MODE: L,
                            IDENT_RE: y,
                            MATCH_NOTHING_RE: /\b\B/,
                            METHOD_GUARD: q,
                            NUMBER_MODE: z,
                            NUMBER_RE: N,
                            PHRASAL_WORDS_MODE: {
                                begin: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/
                            },
                            QUOTE_STRING_MODE: S,
                            REGEXP_MODE: U,
                            RE_STARTERS_RE: "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~",
                            SHEBANG: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                    u = /^#![ ]*\//;
                                return e.binary && (e.begin = f(u, /.*\b/, e.binary, /\b.*/)), i({
                                    scope: "meta",
                                    begin: u,
                                    end: /$/,
                                    relevance: 0,
                                    "on:begin": function(e, u) {
                                        0 !== e.index && u.ignoreMatch()
                                    }
                                }, e)
                            },
                            TITLE_MODE: $,
                            UNDERSCORE_IDENT_RE: w,
                            UNDERSCORE_TITLE_MODE: K
                        });

                    function Z(e, u) {
                        "." === e.input[e.index - 1] && u.ignoreMatch()
                    }

                    function G(e, u) {
                        void 0 !== e.className && (e.scope = e.className, delete e.className)
                    }

                    function W(e, u) {
                        u && e.beginKeywords && (e.begin = "\\b(" + e.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", e.__beforeBegin = Z, e.keywords = e.keywords || e.beginKeywords, delete e.beginKeywords, void 0 === e.relevance && (e.relevance = 0))
                    }

                    function Q(e, u) {
                        Array.isArray(e.illegal) && (e.illegal = B.apply(void 0, o(e.illegal)))
                    }

                    function V(e, u) {
                        if (e.match) {
                            if (e.begin || e.end) throw new Error("begin & end are not supported with match");
                            e.begin = e.match, delete e.match
                        }
                    }

                    function X(e, u) {
                        void 0 === e.relevance && (e.relevance = 1)
                    }
                    var J = function(e, u) {
                            if (e.beforeMatch) {
                                if (e.starts) throw new Error("beforeMatch cannot be used with starts");
                                var n = Object.assign({}, e);
                                Object.keys(e).forEach((function(u) {
                                    delete e[u]
                                })), e.keywords = n.keywords, e.begin = f(n.beforeMatch, b(n.begin)), e.starts = {
                                    relevance: 0,
                                    contains: [Object.assign(n, {
                                        endsParent: !0
                                    })]
                                }, e.relevance = 0, delete n.beforeMatch
                            }
                        },
                        Y = ["of", "and", "for", "in", "not", "or", "if", "then", "parent", "list", "value"];

                    function ee(e, u) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "keyword",
                            t = Object.create(null);
                        return "string" == typeof e ? a(n, e.split(" ")) : Array.isArray(e) ? a(n, e) : Object.keys(e).forEach((function(n) {
                            Object.assign(t, ee(e[n], u, n))
                        })), t;

                        function a(e, n) {
                            u && (n = n.map((function(e) {
                                return e.toLowerCase()
                            }))), n.forEach((function(u) {
                                var n = u.split("|");
                                t[n[0]] = [e, ue(n[0], n[1])]
                            }))
                        }
                    }

                    function ue(e, u) {
                        return u ? Number(u) : function(e) {
                            return Y.includes(e.toLowerCase())
                        }(e) ? 0 : 1
                    }
                    var ne = {},
                        te = function(e) {
                            console.error(e)
                        },
                        ae = function(e) {
                            for (var u, n = arguments.length, t = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) t[a - 1] = arguments[a];
                            (u = console).log.apply(u, ["WARN: ".concat(e)].concat(t))
                        },
                        re = function(e, u) {
                            ne["".concat(e, "/").concat(u)] || (console.log("Deprecated as of ".concat(e, ". ").concat(u)), ne["".concat(e, "/").concat(u)] = !0)
                        },
                        ie = new Error;

                    function De(e, u, n) {
                        for (var t = n.key, a = 0, r = e[t], i = {}, D = {}, s = 1; s <= u.length; s++) D[s + a] = r[s], i[s + a] = !0, a += h(u[s - 1]);
                        e[t] = D, e[t]._emit = i, e[t]._multi = !0
                    }

                    function se(e) {
                        ! function(e) {
                            e.scope && "object" === C(e.scope) && null !== e.scope && (e.beginScope = e.scope, delete e.scope)
                        }(e), "string" == typeof e.beginScope && (e.beginScope = {
                                _wrap: e.beginScope
                            }), "string" == typeof e.endScope && (e.endScope = {
                                _wrap: e.endScope
                            }),
                            function(e) {
                                if (Array.isArray(e.begin)) {
                                    if (e.skip || e.excludeBegin || e.returnBegin) throw te("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), ie;
                                    if ("object" !== C(e.beginScope) || null === e.beginScope) throw te("beginScope must be object"), ie;
                                    De(e, e.begin, {
                                        key: "beginScope"
                                    }), e.begin = v(e.begin, {
                                        joinWith: ""
                                    })
                                }
                            }(e),
                            function(e) {
                                if (Array.isArray(e.end)) {
                                    if (e.skip || e.excludeEnd || e.returnEnd) throw te("skip, excludeEnd, returnEnd not compatible with endScope: {}"), ie;
                                    if ("object" !== C(e.endScope) || null === e.endScope) throw te("endScope must be object"), ie;
                                    De(e, e.end, {
                                        key: "endScope"
                                    }), e.end = v(e.end, {
                                        joinWith: ""
                                    })
                                }
                            }(e)
                    }

                    function oe(e) {
                        function u(u, n) {
                            return new RegExp(g(u), "m" + (e.case_insensitive ? "i" : "") + (e.unicodeRegex ? "u" : "") + (n ? "g" : ""))
                        }
                        var n = function() {
                                return F((function e() {
                                    d(this, e), this.matchIndexes = {}, this.regexes = [], this.matchAt = 1, this.position = 0
                                }), [{
                                    key: "addRule",
                                    value: function(e, u) {
                                        u.position = this.position++, this.matchIndexes[this.matchAt] = u, this.regexes.push([u, e]), this.matchAt += h(e) + 1
                                    }
                                }, {
                                    key: "compile",
                                    value: function() {
                                        0 === this.regexes.length && (this.exec = function() {
                                            return null
                                        });
                                        var e = this.regexes.map((function(e) {
                                            return e[1]
                                        }));
                                        this.matcherRe = u(v(e, {
                                            joinWith: "|"
                                        }), !0), this.lastIndex = 0
                                    }
                                }, {
                                    key: "exec",
                                    value: function(e) {
                                        this.matcherRe.lastIndex = this.lastIndex;
                                        var u = this.matcherRe.exec(e);
                                        if (!u) return null;
                                        var n = u.findIndex((function(e, u) {
                                                return u > 0 && void 0 !== e
                                            })),
                                            t = this.matchIndexes[n];
                                        return u.splice(0, n), Object.assign(u, t)
                                    }
                                }])
                            }(),
                            a = function() {
                                return F((function e() {
                                    d(this, e), this.rules = [], this.multiRegexes = [], this.count = 0, this.lastIndex = 0, this.regexIndex = 0
                                }), [{
                                    key: "getMatcher",
                                    value: function(e) {
                                        if (this.multiRegexes[e]) return this.multiRegexes[e];
                                        var u = new n;
                                        return this.rules.slice(e).forEach((function(e) {
                                            var n = t(e, 2),
                                                a = n[0],
                                                r = n[1];
                                            return u.addRule(a, r)
                                        })), u.compile(), this.multiRegexes[e] = u, u
                                    }
                                }, {
                                    key: "resumingScanAtSamePosition",
                                    value: function() {
                                        return 0 !== this.regexIndex
                                    }
                                }, {
                                    key: "considerAll",
                                    value: function() {
                                        this.regexIndex = 0
                                    }
                                }, {
                                    key: "addRule",
                                    value: function(e, u) {
                                        this.rules.push([e, u]), "begin" === u.type && this.count++
                                    }
                                }, {
                                    key: "exec",
                                    value: function(e) {
                                        var u = this.getMatcher(this.regexIndex);
                                        u.lastIndex = this.lastIndex;
                                        var n = u.exec(e);
                                        if (this.resumingScanAtSamePosition())
                                            if (n && n.index === this.lastIndex);
                                            else {
                                                var t = this.getMatcher(0);
                                                t.lastIndex = this.lastIndex + 1, n = t.exec(e)
                                            }
                                        return n && (this.regexIndex += n.position + 1, this.regexIndex === this.count && this.considerAll()), n
                                    }
                                }])
                            }();
                        if (e.compilerExtensions || (e.compilerExtensions = []), e.contains && e.contains.includes("self")) throw new Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation.");
                        return e.classNameAliases = i(e.classNameAliases || {}),
                            function n(t, r) {
                                var D, s = t;
                                if (t.isCompiled) return s;
                                [G, V, se, J].forEach((function(e) {
                                    return e(t, r)
                                })), e.compilerExtensions.forEach((function(e) {
                                    return e(t, r)
                                })), t.__beforeBegin = null, [W, Q, X].forEach((function(e) {
                                    return e(t, r)
                                })), t.isCompiled = !0;
                                var c = null;
                                return "object" === C(t.keywords) && t.keywords.$pattern && (t.keywords = Object.assign({}, t.keywords), c = t.keywords.$pattern, delete t.keywords.$pattern), c = c || /\w+/, t.keywords && (t.keywords = ee(t.keywords, e.case_insensitive)), s.keywordPatternRe = u(c, !0), r && (t.begin || (t.begin = /\B|\b/), s.beginRe = u(s.begin), t.end || t.endsWithParent || (t.end = /\B|\b/), t.end && (s.endRe = u(s.end)), s.terminatorEnd = g(s.end) || "", t.endsWithParent && r.terminatorEnd && (s.terminatorEnd += (t.end ? "|" : "") + r.terminatorEnd)), t.illegal && (s.illegalRe = u(t.illegal)), t.contains || (t.contains = []), t.contains = (D = []).concat.apply(D, o(t.contains.map((function(e) {
                                    return function(e) {
                                        e.variants && !e.cachedVariants && (e.cachedVariants = e.variants.map((function(u) {
                                            return i(e, {
                                                variants: null
                                            }, u)
                                        })));
                                        if (e.cachedVariants) return e.cachedVariants;
                                        if (ce(e)) return i(e, {
                                            starts: e.starts ? i(e.starts) : null
                                        });
                                        if (Object.isFrozen(e)) return i(e);
                                        return e
                                    }("self" === e ? t : e)
                                })))), t.contains.forEach((function(e) {
                                    n(e, s)
                                })), t.starts && n(t.starts, r), s.matcher = function(e) {
                                    var u = new a;
                                    return e.contains.forEach((function(e) {
                                        return u.addRule(e.begin, {
                                            rule: e,
                                            type: "begin"
                                        })
                                    })), e.terminatorEnd && u.addRule(e.terminatorEnd, {
                                        type: "end"
                                    }), e.illegal && u.addRule(e.illegal, {
                                        type: "illegal"
                                    }), u
                                }(s), s
                            }(e)
                    }

                    function ce(e) {
                        return !!e && (e.endsWithParent || ce(e.starts))
                    }
                    var le = function(e) {
                            function u(e, n) {
                                var t;
                                return d(this, u), (t = a(this, u, [e])).name = "HTMLInjectionError", t.html = n, t
                            }
                            return D(u, e), F(u)
                        }(n(Error)),
                        de = r,
                        Ee = i,
                        Fe = Symbol("nomatch"),
                        Ae = function(n) {
                            var a = Object.create(null),
                                r = Object.create(null),
                                i = [],
                                D = !0,
                                s = "Could not find the language '{}', did you forget to load/include a language module?",
                                o = {
                                    disableAutodetect: !0,
                                    name: "Plain text",
                                    contains: []
                                },
                                c = {
                                    ignoreUnescapedHTML: !1,
                                    throwUnescapedHTML: !1,
                                    noHighlightRe: /^(no-?highlight)$/i,
                                    languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
                                    classPrefix: "hljs-",
                                    cssSelector: "pre code",
                                    languages: null,
                                    __emitter: A
                                };

                            function l(e) {
                                return c.noHighlightRe.test(e)
                            }

                            function d(e, u, n) {
                                var t = "",
                                    a = "";
                                "object" === C(u) ? (t = e, n = u.ignoreIllegals, a = u.language) : (re("10.7.0", "highlight(lang, code, ...args) has been deprecated."), re("10.7.0", "Please use highlight(code, options) instead.\nhttps://github.com/highlightjs/highlight.js/issues/2277"), a = e, t = u), void 0 === n && (n = !0);
                                var r = {
                                    code: t,
                                    language: a
                                };
                                N("before:highlight", r);
                                var i = r.result ? r.result : E(r.language, r.code, n);
                                return i.code = r.code, N("after:highlight", i), i
                            }

                            function E(e, n, r, i) {
                                var o = Object.create(null);

                                function l() {
                                    if (w.keywords) {
                                        var e = 0;
                                        w.keywordPatternRe.lastIndex = 0;
                                        for (var u, n = w.keywordPatternRe.exec(k), a = ""; n;) {
                                            a += k.substring(e, n.index);
                                            var r = h.case_insensitive ? n[0].toLowerCase() : n[0],
                                                i = (u = r, w.keywords[u]);
                                            if (i) {
                                                var D = t(i, 2),
                                                    s = D[0],
                                                    c = D[1];
                                                if (x.addText(a), a = "", o[r] = (o[r] || 0) + 1, o[r] <= 7 && (O += c), s.startsWith("_")) a += n[0];
                                                else {
                                                    var l = h.classNameAliases[s] || s;
                                                    A(n[0], l)
                                                }
                                            } else a += n[0];
                                            e = w.keywordPatternRe.lastIndex, n = w.keywordPatternRe.exec(k)
                                        }
                                        a += k.substring(e), x.addText(a)
                                    } else x.addText(k)
                                }

                                function d() {
                                    null != w.subLanguage ? function() {
                                        if ("" !== k) {
                                            var e = null;
                                            if ("string" == typeof w.subLanguage) {
                                                if (!a[w.subLanguage]) return void x.addText(k);
                                                e = E(w.subLanguage, k, !0, N[w.subLanguage]), N[w.subLanguage] = e._top
                                            } else e = F(k, w.subLanguage.length ? w.subLanguage : null);
                                            w.relevance > 0 && (O += e.relevance), x.__addSublanguage(e._emitter, e.language)
                                        }
                                    }() : l(), k = ""
                                }

                                function A(e, u) {
                                    "" !== e && (x.startScope(u), x.addText(e), x.endScope())
                                }

                                function C(e, u) {
                                    for (var n = 1, t = u.length - 1; n <= t;)
                                        if (e._emit[n]) {
                                            var a = h.classNameAliases[e[n]] || e[n],
                                                r = u[n];
                                            a ? A(r, a) : (k = r, l(), k = ""), n++
                                        } else n++
                                }

                                function g(e, u) {
                                    return e.scope && "string" == typeof e.scope && x.openNode(h.classNameAliases[e.scope] || e.scope), e.beginScope && (e.beginScope._wrap ? (A(k, h.classNameAliases[e.beginScope._wrap] || e.beginScope._wrap), k = "") : e.beginScope._multi && (C(e.beginScope, u), k = "")), w = Object.create(e, {
                                        parent: {
                                            value: w
                                        }
                                    })
                                }

                                function b(e, n, t) {
                                    var a = function(e, u) {
                                        var n = e && e.exec(u);
                                        return n && 0 === n.index
                                    }(e.endRe, t);
                                    if (a) {
                                        if (e["on:end"]) {
                                            var r = new u(e);
                                            e["on:end"](n, r), r.isMatchIgnored && (a = !1)
                                        }
                                        if (a) {
                                            for (; e.endsParent && e.parent;) e = e.parent;
                                            return e
                                        }
                                    }
                                    if (e.endsWithParent) return b(e.parent, n, t)
                                }

                                function m(e) {
                                    return 0 === w.matcher.regexIndex ? (k += e[0], 1) : (T = !0, 0)
                                }

                                function p(e) {
                                    var u = e[0],
                                        t = n.substring(e.index),
                                        a = b(w, e, t);
                                    if (!a) return Fe;
                                    var r = w;
                                    w.endScope && w.endScope._wrap ? (d(), A(u, w.endScope._wrap)) : w.endScope && w.endScope._multi ? (d(), C(w.endScope, e)) : r.skip ? k += u : (r.returnEnd || r.excludeEnd || (k += u), d(), r.excludeEnd && (k = u));
                                    do {
                                        w.scope && x.closeNode(), w.skip || w.subLanguage || (O += w.relevance), w = w.parent
                                    } while (w !== a.parent);
                                    return a.starts && g(a.starts, e), r.returnEnd ? 0 : u.length
                                }
                                var f = {};

                                function B(t, a) {
                                    var i = a && a[0];
                                    if (k += t, null == i) return d(), 0;
                                    if ("begin" === f.type && "end" === a.type && f.index === a.index && "" === i) {
                                        if (k += n.slice(a.index, a.index + 1), !D) {
                                            var s = new Error("0 width match regex (".concat(e, ")"));
                                            throw s.languageName = e, s.badRule = f.rule, s
                                        }
                                        return 1
                                    }
                                    if (f = a, "begin" === a.type) return function(e) {
                                        for (var n = e[0], t = e.rule, a = new u(t), r = 0, i = [t.__beforeBegin, t["on:begin"]]; r < i.length; r++) {
                                            var D = i[r];
                                            if (D && (D(e, a), a.isMatchIgnored)) return m(n)
                                        }
                                        return t.skip ? k += n : (t.excludeBegin && (k += n), d(), t.returnBegin || t.excludeBegin || (k = n)), g(t, e), t.returnBegin ? 0 : n.length
                                    }(a);
                                    if ("illegal" === a.type && !r) {
                                        var o = new Error('Illegal lexeme "' + i + '" for mode "' + (w.scope || "<unnamed>") + '"');
                                        throw o.mode = w, o
                                    }
                                    if ("end" === a.type) {
                                        var c = p(a);
                                        if (c !== Fe) return c
                                    }
                                    if ("illegal" === a.type && "" === i) return 1;
                                    if (S > 1e5 && S > 3 * a.index) throw new Error("potential infinite loop, way more iterations than matches");
                                    return k += i, i.length
                                }
                                var h = v(e);
                                if (!h) throw te(s.replace("{}", e)), new Error('Unknown language: "' + e + '"');
                                var _ = oe(h),
                                    y = "",
                                    w = i || _,
                                    N = {},
                                    x = new c.__emitter(c);
                                ! function() {
                                    for (var e = [], u = w; u !== h; u = u.parent) u.scope && e.unshift(u.scope);
                                    e.forEach((function(e) {
                                        return x.openNode(e)
                                    }))
                                }();
                                var k = "",
                                    O = 0,
                                    M = 0,
                                    S = 0,
                                    T = !1;
                                try {
                                    if (h.__emitTokens) h.__emitTokens(n, x);
                                    else {
                                        for (w.matcher.considerAll();;) {
                                            S++, T ? T = !1 : w.matcher.considerAll(), w.matcher.lastIndex = M;
                                            var R = w.matcher.exec(n);
                                            if (!R) break;
                                            var I = B(n.substring(M, R.index), R);
                                            M = R.index + I
                                        }
                                        B(n.substring(M))
                                    }
                                    return x.finalize(), y = x.toHTML(), {
                                        language: e,
                                        value: y,
                                        relevance: O,
                                        illegal: !1,
                                        _emitter: x,
                                        _top: w
                                    }
                                } catch (u) {
                                    if (u.message && u.message.includes("Illegal")) return {
                                        language: e,
                                        value: de(n),
                                        illegal: !0,
                                        relevance: 0,
                                        _illegalBy: {
                                            message: u.message,
                                            index: M,
                                            context: n.slice(M - 100, M + 100),
                                            mode: u.mode,
                                            resultSoFar: y
                                        },
                                        _emitter: x
                                    };
                                    if (D) return {
                                        language: e,
                                        value: de(n),
                                        illegal: !1,
                                        relevance: 0,
                                        errorRaised: u,
                                        _emitter: x,
                                        _top: w
                                    };
                                    throw u
                                }
                            }

                            function F(e, u) {
                                u = u || c.languages || Object.keys(a);
                                var n = function(e) {
                                        var u = {
                                            value: de(e),
                                            illegal: !1,
                                            relevance: 0,
                                            _top: o,
                                            _emitter: new c.__emitter(c)
                                        };
                                        return u._emitter.addText(e), u
                                    }(e),
                                    r = u.filter(v).filter(w).map((function(u) {
                                        return E(u, e, !1)
                                    }));
                                r.unshift(n);
                                var i = t(r.sort((function(e, u) {
                                        if (e.relevance !== u.relevance) return u.relevance - e.relevance;
                                        if (e.language && u.language) {
                                            if (v(e.language).supersetOf === u.language) return 1;
                                            if (v(u.language).supersetOf === e.language) return -1
                                        }
                                        return 0
                                    })), 2),
                                    D = i[0],
                                    s = i[1],
                                    l = D;
                                return l.secondBest = s, l
                            }

                            function g(e) {
                                var u = function(e) {
                                    var u = e.className + " ";
                                    u += e.parentNode ? e.parentNode.className : "";
                                    var n = c.languageDetectRe.exec(u);
                                    if (n) {
                                        var t = v(n[1]);
                                        return t || (ae(s.replace("{}", n[1])), ae("Falling back to no-highlight mode for this block.", e)), t ? n[1] : "no-highlight"
                                    }
                                    return u.split(/\s+/).find((function(e) {
                                        return l(e) || v(e)
                                    }))
                                }(e);
                                if (!l(u))
                                    if (N("before:highlightElement", {
                                            el: e,
                                            language: u
                                        }), e.dataset.highlighted) console.log("Element previously highlighted. To highlight again, first unset `dataset.highlighted`.", e);
                                    else {
                                        if (e.children.length > 0)
                                            if (c.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(e)), c.throwUnescapedHTML) throw new le("One of your code blocks includes unescaped HTML.", e.innerHTML);
                                        var n = e.textContent,
                                            t = u ? d(n, {
                                                language: u,
                                                ignoreIllegals: !0
                                            }) : F(n);
                                        e.innerHTML = t.value, e.dataset.highlighted = "yes",
                                            function(e, u, n) {
                                                var t = u && r[u] || n;
                                                e.classList.add("hljs"), e.classList.add("language-".concat(t))
                                            }(e, u, t.language), e.result = {
                                                language: t.language,
                                                re: t.relevance,
                                                relevance: t.relevance
                                            }, t.secondBest && (e.secondBest = {
                                                language: t.secondBest.language,
                                                relevance: t.secondBest.relevance
                                            }), N("after:highlightElement", {
                                                el: e,
                                                result: t,
                                                text: n
                                            })
                                    }
                            }
                            var h = !1;

                            function _() {
                                "loading" !== document.readyState ? document.querySelectorAll(c.cssSelector).forEach(g) : h = !0
                            }

                            function v(e) {
                                return e = (e || "").toLowerCase(), a[e] || a[r[e]]
                            }

                            function y(e, u) {
                                var n = u.languageName;
                                "string" == typeof e && (e = [e]), e.forEach((function(e) {
                                    r[e.toLowerCase()] = n
                                }))
                            }

                            function w(e) {
                                var u = v(e);
                                return u && !u.disableAutodetect
                            }

                            function N(e, u) {
                                var n = e;
                                i.forEach((function(e) {
                                    e[n] && e[n](u)
                                }))
                            }
                            for (var x in "undefined" != typeof window && window.addEventListener && window.addEventListener("DOMContentLoaded", (function() {
                                    h && _()
                                }), !1), Object.assign(n, {
                                    highlight: d,
                                    highlightAuto: F,
                                    highlightAll: _,
                                    highlightElement: g,
                                    highlightBlock: function(e) {
                                        return re("10.7.0", "highlightBlock will be removed entirely in v12.0"), re("10.7.0", "Please use highlightElement now."), g(e)
                                    },
                                    configure: function(e) {
                                        c = Ee(c, e)
                                    },
                                    initHighlighting: function() {
                                        _(), re("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now.")
                                    },
                                    initHighlightingOnLoad: function() {
                                        _(), re("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now.")
                                    },
                                    registerLanguage: function(e, u) {
                                        var t = null;
                                        try {
                                            t = u(n)
                                        } catch (u) {
                                            if (te("Language definition for '{}' could not be registered.".replace("{}", e)), !D) throw u;
                                            te(u), t = o
                                        }
                                        t.name || (t.name = e), a[e] = t, t.rawDefinition = u.bind(null, n), t.aliases && y(t.aliases, {
                                            languageName: e
                                        })
                                    },
                                    unregisterLanguage: function(e) {
                                        delete a[e];
                                        for (var u = 0, n = Object.keys(r); u < n.length; u++) {
                                            var t = n[u];
                                            r[t] === e && delete r[t]
                                        }
                                    },
                                    listLanguages: function() {
                                        return Object.keys(a)
                                    },
                                    getLanguage: v,
                                    registerAliases: y,
                                    autoDetection: w,
                                    inherit: Ee,
                                    addPlugin: function(e) {
                                        ! function(e) {
                                            e["before:highlightBlock"] && !e["before:highlightElement"] && (e["before:highlightElement"] = function(u) {
                                                e["before:highlightBlock"](Object.assign({
                                                    block: u.el
                                                }, u))
                                            }), e["after:highlightBlock"] && !e["after:highlightElement"] && (e["after:highlightElement"] = function(u) {
                                                e["after:highlightBlock"](Object.assign({
                                                    block: u.el
                                                }, u))
                                            })
                                        }(e), i.push(e)
                                    },
                                    removePlugin: function(e) {
                                        var u = i.indexOf(e); - 1 !== u && i.splice(u, 1)
                                    }
                                }), n.debugMode = function() {
                                    D = !1
                                }, n.safeMode = function() {
                                    D = !0
                                }, n.versionString = "11.9.0", n.regex = {
                                    concat: f,
                                    lookahead: b,
                                    either: B,
                                    optional: p,
                                    anyNumberOfTimes: m
                                }, H) "object" === C(H[x]) && e(H[x]);
                            return Object.assign(n, H), n
                        },
                        Ce = Ae({});
                    Ce.newInstance = function() {
                        return Ae({})
                    };
                    var ge = Ce;
                    var be = function(e) {
                            return {
                                IMPORTANT: {
                                    scope: "meta",
                                    begin: "!important"
                                },
                                BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
                                HEXCOLOR: {
                                    scope: "number",
                                    begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
                                },
                                FUNCTION_DISPATCH: {
                                    className: "built_in",
                                    begin: /[\w-]+(?=\()/
                                },
                                ATTRIBUTE_SELECTOR_MODE: {
                                    scope: "selector-attr",
                                    begin: /\[/,
                                    end: /\]/,
                                    illegal: "$",
                                    contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
                                },
                                CSS_NUMBER_MODE: {
                                    scope: "number",
                                    begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
                                    relevance: 0
                                },
                                CSS_VARIABLE: {
                                    className: "attr",
                                    begin: /--[A-Za-z_][A-Za-z0-9_-]*/
                                }
                            }
                        },
                        me = ["a", "abbr", "address", "article", "aside", "audio", "b", "blockquote", "body", "button", "canvas", "caption", "cite", "code", "dd", "del", "details", "dfn", "div", "dl", "dt", "em", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "html", "i", "iframe", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "mark", "menu", "nav", "object", "ol", "p", "q", "quote", "samp", "section", "span", "strong", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "tr", "ul", "var", "video"],
                        pe = ["any-hover", "any-pointer", "aspect-ratio", "color", "color-gamut", "color-index", "device-aspect-ratio", "device-height", "device-width", "display-mode", "forced-colors", "grid", "height", "hover", "inverted-colors", "monochrome", "orientation", "overflow-block", "overflow-inline", "pointer", "prefers-color-scheme", "prefers-contrast", "prefers-reduced-motion", "prefers-reduced-transparency", "resolution", "scan", "scripting", "update", "width", "min-width", "max-width", "min-height", "max-height"],
                        fe = ["active", "any-link", "blank", "checked", "current", "default", "defined", "dir", "disabled", "drop", "empty", "enabled", "first", "first-child", "first-of-type", "fullscreen", "future", "focus", "focus-visible", "focus-within", "has", "host", "host-context", "hover", "indeterminate", "in-range", "invalid", "is", "lang", "last-child", "last-of-type", "left", "link", "local-link", "not", "nth-child", "nth-col", "nth-last-child", "nth-last-col", "nth-last-of-type", "nth-of-type", "only-child", "only-of-type", "optional", "out-of-range", "past", "placeholder-shown", "read-only", "read-write", "required", "right", "root", "scope", "target", "target-within", "user-invalid", "valid", "visited", "where"],
                        Be = ["after", "backdrop", "before", "cue", "cue-region", "first-letter", "first-line", "grammar-error", "marker", "part", "placeholder", "selection", "slotted", "spelling-error"],
                        he = ["align-content", "align-items", "align-self", "all", "animation", "animation-delay", "animation-direction", "animation-duration", "animation-fill-mode", "animation-iteration-count", "animation-name", "animation-play-state", "animation-timing-function", "backface-visibility", "background", "background-attachment", "background-blend-mode", "background-clip", "background-color", "background-image", "background-origin", "background-position", "background-repeat", "background-size", "block-size", "border", "border-block", "border-block-color", "border-block-end", "border-block-end-color", "border-block-end-style", "border-block-end-width", "border-block-start", "border-block-start-color", "border-block-start-style", "border-block-start-width", "border-block-style", "border-block-width", "border-bottom", "border-bottom-color", "border-bottom-left-radius", "border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-collapse", "border-color", "border-image", "border-image-outset", "border-image-repeat", "border-image-slice", "border-image-source", "border-image-width", "border-inline", "border-inline-color", "border-inline-end", "border-inline-end-color", "border-inline-end-style", "border-inline-end-width", "border-inline-start", "border-inline-start-color", "border-inline-start-style", "border-inline-start-width", "border-inline-style", "border-inline-width", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius", "border-right", "border-right-color", "border-right-style", "border-right-width", "border-spacing", "border-style", "border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style", "border-top-width", "border-width", "bottom", "box-decoration-break", "box-shadow", "box-sizing", "break-after", "break-before", "break-inside", "caption-side", "caret-color", "clear", "clip", "clip-path", "clip-rule", "color", "column-count", "column-fill", "column-gap", "column-rule", "column-rule-color", "column-rule-style", "column-rule-width", "column-span", "column-width", "columns", "contain", "content", "content-visibility", "counter-increment", "counter-reset", "cue", "cue-after", "cue-before", "cursor", "direction", "display", "empty-cells", "filter", "flex", "flex-basis", "flex-direction", "flex-flow", "flex-grow", "flex-shrink", "flex-wrap", "float", "flow", "font", "font-display", "font-family", "font-feature-settings", "font-kerning", "font-language-override", "font-size", "font-size-adjust", "font-smoothing", "font-stretch", "font-style", "font-synthesis", "font-variant", "font-variant-caps", "font-variant-east-asian", "font-variant-ligatures", "font-variant-numeric", "font-variant-position", "font-variation-settings", "font-weight", "gap", "glyph-orientation-vertical", "grid", "grid-area", "grid-auto-columns", "grid-auto-flow", "grid-auto-rows", "grid-column", "grid-column-end", "grid-column-start", "grid-gap", "grid-row", "grid-row-end", "grid-row-start", "grid-template", "grid-template-areas", "grid-template-columns", "grid-template-rows", "hanging-punctuation", "height", "hyphens", "icon", "image-orientation", "image-rendering", "image-resolution", "ime-mode", "inline-size", "isolation", "justify-content", "left", "letter-spacing", "line-break", "line-height", "list-style", "list-style-image", "list-style-position", "list-style-type", "margin", "margin-block", "margin-block-end", "margin-block-start", "margin-bottom", "margin-inline", "margin-inline-end", "margin-inline-start", "margin-left", "margin-right", "margin-top", "marks", "mask", "mask-border", "mask-border-mode", "mask-border-outset", "mask-border-repeat", "mask-border-slice", "mask-border-source", "mask-border-width", "mask-clip", "mask-composite", "mask-image", "mask-mode", "mask-origin", "mask-position", "mask-repeat", "mask-size", "mask-type", "max-block-size", "max-height", "max-inline-size", "max-width", "min-block-size", "min-height", "min-inline-size", "min-width", "mix-blend-mode", "nav-down", "nav-index", "nav-left", "nav-right", "nav-up", "none", "normal", "object-fit", "object-position", "opacity", "order", "orphans", "outline", "outline-color", "outline-offset", "outline-style", "outline-width", "overflow", "overflow-wrap", "overflow-x", "overflow-y", "padding", "padding-block", "padding-block-end", "padding-block-start", "padding-bottom", "padding-inline", "padding-inline-end", "padding-inline-start", "padding-left", "padding-right", "padding-top", "page-break-after", "page-break-before", "page-break-inside", "pause", "pause-after", "pause-before", "perspective", "perspective-origin", "pointer-events", "position", "quotes", "resize", "rest", "rest-after", "rest-before", "right", "row-gap", "scroll-margin", "scroll-margin-block", "scroll-margin-block-end", "scroll-margin-block-start", "scroll-margin-bottom", "scroll-margin-inline", "scroll-margin-inline-end", "scroll-margin-inline-start", "scroll-margin-left", "scroll-margin-right", "scroll-margin-top", "scroll-padding", "scroll-padding-block", "scroll-padding-block-end", "scroll-padding-block-start", "scroll-padding-bottom", "scroll-padding-inline", "scroll-padding-inline-end", "scroll-padding-inline-start", "scroll-padding-left", "scroll-padding-right", "scroll-padding-top", "scroll-snap-align", "scroll-snap-stop", "scroll-snap-type", "scrollbar-color", "scrollbar-gutter", "scrollbar-width", "shape-image-threshold", "shape-margin", "shape-outside", "speak", "speak-as", "src", "tab-size", "table-layout", "text-align", "text-align-all", "text-align-last", "text-combine-upright", "text-decoration", "text-decoration-color", "text-decoration-line", "text-decoration-style", "text-emphasis", "text-emphasis-color", "text-emphasis-position", "text-emphasis-style", "text-indent", "text-justify", "text-orientation", "text-overflow", "text-rendering", "text-shadow", "text-transform", "text-underline-position", "top", "transform", "transform-box", "transform-origin", "transform-style", "transition", "transition-delay", "transition-duration", "transition-property", "transition-timing-function", "unicode-bidi", "vertical-align", "visibility", "voice-balance", "voice-duration", "voice-family", "voice-pitch", "voice-range", "voice-rate", "voice-stress", "voice-volume", "white-space", "widows", "width", "will-change", "word-break", "word-spacing", "word-wrap", "writing-mode", "z-index"].reverse(),
                        _e = fe.concat(Be);
                    var ve = "[A-Za-z$_][0-9A-Za-z$_]*",
                        ye = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends"],
                        we = ["true", "false", "null", "undefined", "NaN", "Infinity"],
                        Ne = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
                        xe = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
                        ke = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
                        Oe = ["arguments", "this", "super", "console", "window", "document", "localStorage", "sessionStorage", "module", "global"],
                        Me = [].concat(ke, Ne, xe);
                    var Se = "[0-9](_*[0-9])*",
                        Te = "\\.(".concat(Se, ")"),
                        Re = "[0-9a-fA-F](_*[0-9a-fA-F])*",
                        Ie = {
                            className: "number",
                            variants: [{
                                begin: "(\\b(".concat(Se, ")((").concat(Te, ")|\\.)?|(").concat(Te, "))") + "[eE][+-]?(".concat(Se, ")[fFdD]?\\b")
                            }, {
                                begin: "\\b(".concat(Se, ")((").concat(Te, ")[fFdD]?\\b|\\.([fFdD]\\b)?)")
                            }, {
                                begin: "(".concat(Te, ")[fFdD]?\\b")
                            }, {
                                begin: "\\b(".concat(Se, ")[fFdD]\\b")
                            }, {
                                begin: "\\b0[xX]((".concat(Re, ")\\.?|(").concat(Re, ")?\\.(").concat(Re, "))") + "[pP][+-]?(".concat(Se, ")[fFdD]?\\b")
                            }, {
                                begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b"
                            }, {
                                begin: "\\b0[xX](".concat(Re, ")[lL]?\\b")
                            }, {
                                begin: "\\b0(_*[0-7])*[lL]?\\b"
                            }, {
                                begin: "\\b0[bB][01](_*[01])*[lL]?\\b"
                            }],
                            relevance: 0
                        };

                    function Le(e, u, n) {
                        return -1 === n ? "" : e.replace(u, (function(t) {
                            return Le(e, u, n - 1)
                        }))
                    }

                    function ze(e) {
                        var u = e.regex,
                            n = ve,
                            t = "<>",
                            a = "</>",
                            r = {
                                begin: /<[A-Za-z0-9\\._:-]+/,
                                end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
                                isTrulyOpeningTag: function(e, u) {
                                    var n = e[0].length + e.index,
                                        t = e.input[n];
                                    if ("<" !== t && "," !== t) {
                                        var a;
                                        ">" === t && (function(e, u) {
                                            var n = u.after,
                                                t = "</" + e[0].slice(1);
                                            return -1 !== e.input.indexOf(t, n)
                                        }(e, {
                                            after: n
                                        }) || u.ignoreMatch());
                                        var r = e.input.substring(n);
                                        (r.match(/^\s*=/) || (a = r.match(/^\s+extends\s+/)) && 0 === a.index) && u.ignoreMatch()
                                    } else u.ignoreMatch()
                                }
                            },
                            i = {
                                $pattern: ve,
                                keyword: ye,
                                literal: we,
                                built_in: Me,
                                "variable.language": Oe
                            },
                            D = "[0-9](_?[0-9])*",
                            s = "\\.(".concat(D, ")"),
                            o = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
                            c = {
                                className: "number",
                                variants: [{
                                    begin: "(\\b(".concat(o, ")((").concat(s, ")|\\.)?|(").concat(s, "))") + "[eE][+-]?(".concat(D, ")\\b")
                                }, {
                                    begin: "\\b(".concat(o, ")\\b((").concat(s, ")\\b|\\.)?|(").concat(s, ")\\b")
                                }, {
                                    begin: "\\b(0|[1-9](_?[0-9])*)n\\b"
                                }, {
                                    begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
                                }, {
                                    begin: "\\b0[bB][0-1](_?[0-1])*n?\\b"
                                }, {
                                    begin: "\\b0[oO][0-7](_?[0-7])*n?\\b"
                                }, {
                                    begin: "\\b0[0-7]+n?\\b"
                                }],
                                relevance: 0
                            },
                            l = {
                                className: "subst",
                                begin: "\\$\\{",
                                end: "\\}",
                                keywords: i,
                                contains: []
                            },
                            d = {
                                begin: "html`",
                                end: "",
                                starts: {
                                    end: "`",
                                    returnEnd: !1,
                                    contains: [e.BACKSLASH_ESCAPE, l],
                                    subLanguage: "xml"
                                }
                            },
                            E = {
                                begin: "css`",
                                end: "",
                                starts: {
                                    end: "`",
                                    returnEnd: !1,
                                    contains: [e.BACKSLASH_ESCAPE, l],
                                    subLanguage: "css"
                                }
                            },
                            F = {
                                begin: "gql`",
                                end: "",
                                starts: {
                                    end: "`",
                                    returnEnd: !1,
                                    contains: [e.BACKSLASH_ESCAPE, l],
                                    subLanguage: "graphql"
                                }
                            },
                            A = {
                                className: "string",
                                begin: "`",
                                end: "`",
                                contains: [e.BACKSLASH_ESCAPE, l]
                            },
                            C = {
                                className: "comment",
                                variants: [e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
                                    relevance: 0,
                                    contains: [{
                                        begin: "(?=@[A-Za-z]+)",
                                        relevance: 0,
                                        contains: [{
                                            className: "doctag",
                                            begin: "@[A-Za-z]+"
                                        }, {
                                            className: "type",
                                            begin: "\\{",
                                            end: "\\}",
                                            excludeEnd: !0,
                                            excludeBegin: !0,
                                            relevance: 0
                                        }, {
                                            className: "variable",
                                            begin: n + "(?=\\s*(-)|$)",
                                            endsParent: !0,
                                            relevance: 0
                                        }, {
                                            begin: /(?=[^\n])\s/,
                                            relevance: 0
                                        }]
                                    }]
                                }), e.C_BLOCK_COMMENT_MODE, e.C_LINE_COMMENT_MODE]
                            },
                            g = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, d, E, F, A, {
                                match: /\$\d+/
                            }, c];
                        l.contains = g.concat({
                            begin: /\{/,
                            end: /\}/,
                            keywords: i,
                            contains: ["self"].concat(g)
                        });
                        var b = [].concat(C, l.contains),
                            m = b.concat([{
                                begin: /\(/,
                                end: /\)/,
                                keywords: i,
                                contains: ["self"].concat(b)
                            }]),
                            p = {
                                className: "params",
                                begin: /\(/,
                                end: /\)/,
                                excludeBegin: !0,
                                excludeEnd: !0,
                                keywords: i,
                                contains: m
                            },
                            f = {
                                variants: [{
                                    match: [/class/, /\s+/, n, /\s+/, /extends/, /\s+/, u.concat(n, "(", u.concat(/\./, n), ")*")],
                                    scope: {
                                        1: "keyword",
                                        3: "title.class",
                                        5: "keyword",
                                        7: "title.class.inherited"
                                    }
                                }, {
                                    match: [/class/, /\s+/, n],
                                    scope: {
                                        1: "keyword",
                                        3: "title.class"
                                    }
                                }]
                            },
                            B = {
                                relevance: 0,
                                match: u.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
                                className: "title.class",
                                keywords: {
                                    _: [].concat(Ne, xe)
                                }
                            },
                            h = {
                                variants: [{
                                    match: [/function/, /\s+/, n, /(?=\s*\()/]
                                }, {
                                    match: [/function/, /\s*(?=\()/]
                                }],
                                className: {
                                    1: "keyword",
                                    3: "title.function"
                                },
                                label: "func.def",
                                contains: [p],
                                illegal: /%/
                            };
                        var _, v = {
                                match: u.concat(/\b/, (_ = [].concat(ke, ["super", "import"]), u.concat("(?!", _.join("|"), ")")), n, u.lookahead(/\(/)),
                                className: "title.function",
                                relevance: 0
                            },
                            y = {
                                begin: u.concat(/\./, u.lookahead(u.concat(n, /(?![0-9A-Za-z$_(])/))),
                                end: n,
                                excludeBegin: !0,
                                keywords: "prototype",
                                className: "property",
                                relevance: 0
                            },
                            w = {
                                match: [/get|set/, /\s+/, n, /(?=\()/],
                                className: {
                                    1: "keyword",
                                    3: "title.function"
                                },
                                contains: [{
                                    begin: /\(\)/
                                }, p]
                            },
                            N = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>",
                            x = {
                                match: [/const|var|let/, /\s+/, n, /\s*/, /=\s*/, /(async\s*)?/, u.lookahead(N)],
                                keywords: "async",
                                className: {
                                    1: "keyword",
                                    3: "title.function"
                                },
                                contains: [p]
                            };
                        return {
                            name: "JavaScript",
                            aliases: ["js", "jsx", "mjs", "cjs"],
                            keywords: i,
                            exports: {
                                PARAMS_CONTAINS: m,
                                CLASS_REFERENCE: B
                            },
                            illegal: /#(?![$_A-z])/,
                            contains: [e.SHEBANG({
                                label: "shebang",
                                binary: "node",
                                relevance: 5
                            }), {
                                label: "use_strict",
                                className: "meta",
                                relevance: 10,
                                begin: /^\s*['"]use (strict|asm)['"]/
                            }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, d, E, F, A, C, {
                                match: /\$\d+/
                            }, c, B, {
                                className: "attr",
                                begin: n + u.lookahead(":"),
                                relevance: 0
                            }, x, {
                                begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
                                keywords: "return throw case",
                                relevance: 0,
                                contains: [C, e.REGEXP_MODE, {
                                    className: "function",
                                    begin: N,
                                    returnBegin: !0,
                                    end: "\\s*=>",
                                    contains: [{
                                        className: "params",
                                        variants: [{
                                            begin: e.UNDERSCORE_IDENT_RE,
                                            relevance: 0
                                        }, {
                                            className: null,
                                            begin: /\(\s*\)/,
                                            skip: !0
                                        }, {
                                            begin: /\(/,
                                            end: /\)/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            keywords: i,
                                            contains: m
                                        }]
                                    }]
                                }, {
                                    begin: /,/,
                                    relevance: 0
                                }, {
                                    match: /\s+/,
                                    relevance: 0
                                }, {
                                    variants: [{
                                        begin: t,
                                        end: a
                                    }, {
                                        match: /<[A-Za-z0-9\\._:-]+\s*\/>/
                                    }, {
                                        begin: r.begin,
                                        "on:begin": r.isTrulyOpeningTag,
                                        end: r.end
                                    }],
                                    subLanguage: "xml",
                                    contains: [{
                                        begin: r.begin,
                                        end: r.end,
                                        skip: !0,
                                        contains: ["self"]
                                    }]
                                }]
                            }, h, {
                                beginKeywords: "while if switch catch for"
                            }, {
                                begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
                                returnBegin: !0,
                                label: "func.def",
                                contains: [p, e.inherit(e.TITLE_MODE, {
                                    begin: n,
                                    className: "title.function"
                                })]
                            }, {
                                match: /\.\.\./,
                                relevance: 0
                            }, y, {
                                match: "\\$" + n,
                                relevance: 0
                            }, {
                                match: [/\bconstructor(?=\s*\()/],
                                className: {
                                    1: "title.function"
                                },
                                contains: [p]
                            }, v, {
                                relevance: 0,
                                match: /\b[A-Z][A-Z_0-9]+\b/,
                                className: "variable.constant"
                            }, f, w, {
                                match: /\$[(.]/
                            }]
                        }
                    }
                    var je = function(e) {
                            return f(/\b/, e, /\w$/.test(e) ? /\b/ : /\B/)
                        },
                        Pe = ["Protocol", "Type"].map(je),
                        Ue = ["init", "self"].map(je),
                        $e = ["Any", "Self"],
                        Ke = ["actor", "any", "associatedtype", "async", "await", /as\?/, /as!/, "as", "borrowing", "break", "case", "catch", "class", "consume", "consuming", "continue", "convenience", "copy", "default", "defer", "deinit", "didSet", "distributed", "do", "dynamic", "each", "else", "enum", "extension", "fallthrough", /fileprivate\(set\)/, "fileprivate", "final", "for", "func", "get", "guard", "if", "import", "indirect", "infix", /init\?/, /init!/, "inout", /internal\(set\)/, "internal", "in", "is", "isolated", "nonisolated", "lazy", "let", "macro", "mutating", "nonmutating", /open\(set\)/, "open", "operator", "optional", "override", "postfix", "precedencegroup", "prefix", /private\(set\)/, "private", "protocol", /public\(set\)/, "public", "repeat", "required", "rethrows", "return", "set", "some", "static", "struct", "subscript", "super", "switch", "throws", "throw", /try\?/, /try!/, "try", "typealias", /unowned\(safe\)/, /unowned\(unsafe\)/, "unowned", "var", "weak", "where", "while", "willSet"],
                        qe = ["false", "nil", "true"],
                        He = ["assignment", "associativity", "higherThan", "left", "lowerThan", "none", "right"],
                        Ze = ["#colorLiteral", "#column", "#dsohandle", "#else", "#elseif", "#endif", "#error", "#file", "#fileID", "#fileLiteral", "#filePath", "#function", "#if", "#imageLiteral", "#keyPath", "#line", "#selector", "#sourceLocation", "#warning"],
                        Ge = ["abs", "all", "any", "assert", "assertionFailure", "debugPrint", "dump", "fatalError", "getVaList", "isKnownUniquelyReferenced", "max", "min", "numericCast", "pointwiseMax", "pointwiseMin", "precondition", "preconditionFailure", "print", "readLine", "repeatElement", "sequence", "stride", "swap", "swift_unboxFromSwiftValueWithType", "transcode", "type", "unsafeBitCast", "unsafeDowncast", "withExtendedLifetime", "withUnsafeMutablePointer", "withUnsafePointer", "withVaList", "withoutActuallyEscaping", "zip"],
                        We = B(/[/=\-+!*%<>&|^~?]/, /[\u00A1-\u00A7]/, /[\u00A9\u00AB]/, /[\u00AC\u00AE]/, /[\u00B0\u00B1]/, /[\u00B6\u00BB\u00BF\u00D7\u00F7]/, /[\u2016-\u2017]/, /[\u2020-\u2027]/, /[\u2030-\u203E]/, /[\u2041-\u2053]/, /[\u2055-\u205E]/, /[\u2190-\u23FF]/, /[\u2500-\u2775]/, /[\u2794-\u2BFF]/, /[\u2E00-\u2E7F]/, /[\u3001-\u3003]/, /[\u3008-\u3020]/, /[\u3030]/),
                        Qe = B(We, /[\u0300-\u036F]/, /[\u1DC0-\u1DFF]/, /[\u20D0-\u20FF]/, /[\uFE00-\uFE0F]/, /[\uFE20-\uFE2F]/),
                        Ve = f(We, Qe, "*"),
                        Xe = B(/[a-zA-Z_]/, /[\u00A8\u00AA\u00AD\u00AF\u00B2-\u00B5\u00B7-\u00BA]/, /[\u00BC-\u00BE\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]/, /[\u0100-\u02FF\u0370-\u167F\u1681-\u180D\u180F-\u1DBF]/, /[\u1E00-\u1FFF]/, /[\u200B-\u200D\u202A-\u202E\u203F-\u2040\u2054\u2060-\u206F]/, /[\u2070-\u20CF\u2100-\u218F\u2460-\u24FF\u2776-\u2793]/, /[\u2C00-\u2DFF\u2E80-\u2FFF]/, /[\u3004-\u3007\u3021-\u302F\u3031-\u303F\u3040-\uD7FF]/, /[\uF900-\uFD3D\uFD40-\uFDCF\uFDF0-\uFE1F\uFE30-\uFE44]/, /[\uFE47-\uFEFE\uFF00-\uFFFD]/),
                        Je = B(Xe, /\d/, /[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/),
                        Ye = f(Xe, Je, "*"),
                        eu = f(/[A-Z]/, Je, "*"),
                        uu = ["attached", "autoclosure", f(/convention\(/, B("swift", "block", "c"), /\)/), "discardableResult", "dynamicCallable", "dynamicMemberLookup", "escaping", "freestanding", "frozen", "GKInspectable", "IBAction", "IBDesignable", "IBInspectable", "IBOutlet", "IBSegueAction", "inlinable", "main", "nonobjc", "NSApplicationMain", "NSCopying", "NSManaged", f(/objc\(/, Ye, /\)/), "objc", "objcMembers", "propertyWrapper", "requires_stored_property_inits", "resultBuilder", "Sendable", "testable", "UIApplicationMain", "unchecked", "unknown", "usableFromInline", "warn_unqualified_access"],
                        nu = ["iOS", "iOSApplicationExtension", "macOS", "macOSApplicationExtension", "macCatalyst", "macCatalystApplicationExtension", "watchOS", "watchOSApplicationExtension", "tvOS", "tvOSApplicationExtension", "swift"];
                    for (var tu = Object.freeze({
                            __proto__: null,
                            grmr_bash: function(e) {
                                var u = e.regex,
                                    n = {},
                                    t = {
                                        begin: /\$\{/,
                                        end: /\}/,
                                        contains: ["self", {
                                            begin: /:-/,
                                            contains: [n]
                                        }]
                                    };
                                Object.assign(n, {
                                    className: "variable",
                                    variants: [{
                                        begin: u.concat(/\$[\w\d#@][\w\d_]*/, "(?![\\w\\d])(?![$])")
                                    }, t]
                                });
                                var a = {
                                        className: "subst",
                                        begin: /\$\(/,
                                        end: /\)/,
                                        contains: [e.BACKSLASH_ESCAPE]
                                    },
                                    r = {
                                        begin: /<<-?\s*(?=\w+)/,
                                        starts: {
                                            contains: [e.END_SAME_AS_BEGIN({
                                                begin: /(\w+)/,
                                                end: /(\w+)/,
                                                className: "string"
                                            })]
                                        }
                                    },
                                    i = {
                                        className: "string",
                                        begin: /"/,
                                        end: /"/,
                                        contains: [e.BACKSLASH_ESCAPE, n, a]
                                    };
                                a.contains.push(i);
                                var D = {
                                        begin: /\$?\(\(/,
                                        end: /\)\)/,
                                        contains: [{
                                            begin: /\d+#[0-9a-f]+/,
                                            className: "number"
                                        }, e.NUMBER_MODE, n]
                                    },
                                    s = e.SHEBANG({
                                        binary: "(".concat(["fish", "bash", "zsh", "sh", "csh", "ksh", "tcsh", "dash", "scsh"].join("|"), ")"),
                                        relevance: 10
                                    }),
                                    o = {
                                        className: "function",
                                        begin: /\w[\w\d_]*\s*\(\s*\)\s*\{/,
                                        returnBegin: !0,
                                        contains: [e.inherit(e.TITLE_MODE, {
                                            begin: /\w[\w\d_]*/
                                        })],
                                        relevance: 0
                                    };
                                return {
                                    name: "Bash",
                                    aliases: ["sh"],
                                    keywords: {
                                        $pattern: /\b[a-z][a-z0-9._-]+\b/,
                                        keyword: ["if", "then", "else", "elif", "fi", "for", "while", "until", "in", "do", "done", "case", "esac", "function", "select"],
                                        literal: ["true", "false"],
                                        built_in: [].concat(["break", "cd", "continue", "eval", "exec", "exit", "export", "getopts", "hash", "pwd", "readonly", "return", "shift", "test", "times", "trap", "umask", "unset"], ["alias", "bind", "builtin", "caller", "command", "declare", "echo", "enable", "help", "let", "local", "logout", "mapfile", "printf", "read", "readarray", "source", "type", "typeset", "ulimit", "unalias"], ["set", "shopt"], ["autoload", "bg", "bindkey", "bye", "cap", "chdir", "clone", "comparguments", "compcall", "compctl", "compdescribe", "compfiles", "compgroups", "compquote", "comptags", "comptry", "compvalues", "dirs", "disable", "disown", "echotc", "echoti", "emulate", "fc", "fg", "float", "functions", "getcap", "getln", "history", "integer", "jobs", "kill", "limit", "log", "noglob", "popd", "print", "pushd", "pushln", "rehash", "sched", "setcap", "setopt", "stat", "suspend", "ttyctl", "unfunction", "unhash", "unlimit", "unsetopt", "vared", "wait", "whence", "where", "which", "zcompile", "zformat", "zftp", "zle", "zmodload", "zparseopts", "zprof", "zpty", "zregexparse", "zsocket", "zstyle", "ztcp"], ["chcon", "chgrp", "chown", "chmod", "cp", "dd", "df", "dir", "dircolors", "ln", "ls", "mkdir", "mkfifo", "mknod", "mktemp", "mv", "realpath", "rm", "rmdir", "shred", "sync", "touch", "truncate", "vdir", "b2sum", "base32", "base64", "cat", "cksum", "comm", "csplit", "cut", "expand", "fmt", "fold", "head", "join", "md5sum", "nl", "numfmt", "od", "paste", "ptx", "pr", "sha1sum", "sha224sum", "sha256sum", "sha384sum", "sha512sum", "shuf", "sort", "split", "sum", "tac", "tail", "tr", "tsort", "unexpand", "uniq", "wc", "arch", "basename", "chroot", "date", "dirname", "du", "echo", "env", "expr", "factor", "groups", "hostid", "id", "link", "logname", "nice", "nohup", "nproc", "pathchk", "pinky", "printenv", "printf", "pwd", "readlink", "runcon", "seq", "sleep", "stat", "stdbuf", "stty", "tee", "test", "timeout", "tty", "uname", "unlink", "uptime", "users", "who", "whoami", "yes"])
                                    },
                                    contains: [s, e.SHEBANG(), o, D, e.HASH_COMMENT_MODE, r, {
                                        match: /(\/[a-z._-]+)+/
                                    }, i, {
                                        match: /\\"/
                                    }, {
                                        className: "string",
                                        begin: /'/,
                                        end: /'/
                                    }, {
                                        match: /\\'/
                                    }, n]
                                }
                            },
                            grmr_c: function(e) {
                                var u = e.regex,
                                    n = e.COMMENT("//", "$", {
                                        contains: [{
                                            begin: /\\\n/
                                        }]
                                    }),
                                    t = "decltype\\(auto\\)",
                                    a = "[a-zA-Z_]\\w*::",
                                    r = "(" + t + "|" + u.optional(a) + "[a-zA-Z_]\\w*" + u.optional("<[^<>]+>") + ")",
                                    i = {
                                        className: "type",
                                        variants: [{
                                            begin: "\\b[a-z\\d_]*_t\\b"
                                        }, {
                                            match: /\batomic_[a-z]{3,6}\b/
                                        }]
                                    },
                                    D = {
                                        className: "string",
                                        variants: [{
                                            begin: '(u8?|U|L)?"',
                                            end: '"',
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
                                            end: "'",
                                            illegal: "."
                                        }, e.END_SAME_AS_BEGIN({
                                            begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                                            end: /\)([^()\\ ]{0,16})"/
                                        })]
                                    },
                                    s = {
                                        className: "number",
                                        variants: [{
                                            begin: "\\b(0b[01']+)"
                                        }, {
                                            begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)"
                                        }, {
                                            begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
                                        }],
                                        relevance: 0
                                    },
                                    o = {
                                        className: "meta",
                                        begin: /#\s*[a-z]+\b/,
                                        end: /$/,
                                        keywords: {
                                            keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include"
                                        },
                                        contains: [{
                                            begin: /\\\n/,
                                            relevance: 0
                                        }, e.inherit(D, {
                                            className: "string"
                                        }), {
                                            className: "string",
                                            begin: /<.*?>/
                                        }, n, e.C_BLOCK_COMMENT_MODE]
                                    },
                                    c = {
                                        className: "title",
                                        begin: u.optional(a) + e.IDENT_RE,
                                        relevance: 0
                                    },
                                    l = u.optional(a) + e.IDENT_RE + "\\s*\\(",
                                    d = {
                                        keyword: ["asm", "auto", "break", "case", "continue", "default", "do", "else", "enum", "extern", "for", "fortran", "goto", "if", "inline", "register", "restrict", "return", "sizeof", "struct", "switch", "typedef", "union", "volatile", "while", "_Alignas", "_Alignof", "_Atomic", "_Generic", "_Noreturn", "_Static_assert", "_Thread_local", "alignas", "alignof", "noreturn", "static_assert", "thread_local", "_Pragma"],
                                        type: ["float", "double", "signed", "unsigned", "int", "short", "long", "char", "void", "_Bool", "_Complex", "_Imaginary", "_Decimal32", "_Decimal64", "_Decimal128", "const", "static", "complex", "bool", "imaginary"],
                                        literal: "true false NULL",
                                        built_in: "std string wstring cin cout cerr clog stdin stdout stderr stringstream istringstream ostringstream auto_ptr deque list queue stack vector map set pair bitset multiset multimap unordered_set unordered_map unordered_multiset unordered_multimap priority_queue make_pair array shared_ptr abort terminate abs acos asin atan2 atan calloc ceil cosh cos exit exp fabs floor fmod fprintf fputs free frexp fscanf future isalnum isalpha iscntrl isdigit isgraph islower isprint ispunct isspace isupper isxdigit tolower toupper labs ldexp log10 log malloc realloc memchr memcmp memcpy memset modf pow printf putchar puts scanf sinh sin snprintf sprintf sqrt sscanf strcat strchr strcmp strcpy strcspn strlen strncat strncmp strncpy strpbrk strrchr strspn strstr tanh tan vfprintf vprintf vsprintf endl initializer_list unique_ptr"
                                    },
                                    E = [o, i, n, e.C_BLOCK_COMMENT_MODE, s, D],
                                    F = {
                                        variants: [{
                                            begin: /=/,
                                            end: /;/
                                        }, {
                                            begin: /\(/,
                                            end: /\)/
                                        }, {
                                            beginKeywords: "new throw return else",
                                            end: /;/
                                        }],
                                        keywords: d,
                                        contains: E.concat([{
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: d,
                                            contains: E.concat(["self"]),
                                            relevance: 0
                                        }]),
                                        relevance: 0
                                    },
                                    A = {
                                        begin: "(" + r + "[\\*&\\s]+)+" + l,
                                        returnBegin: !0,
                                        end: /[{;=]/,
                                        excludeEnd: !0,
                                        keywords: d,
                                        illegal: /[^\w\s\*&:<>.]/,
                                        contains: [{
                                            begin: t,
                                            keywords: d,
                                            relevance: 0
                                        }, {
                                            begin: l,
                                            returnBegin: !0,
                                            contains: [e.inherit(c, {
                                                className: "title.function"
                                            })],
                                            relevance: 0
                                        }, {
                                            relevance: 0,
                                            match: /,/
                                        }, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: d,
                                            relevance: 0,
                                            contains: [n, e.C_BLOCK_COMMENT_MODE, D, s, i, {
                                                begin: /\(/,
                                                end: /\)/,
                                                keywords: d,
                                                relevance: 0,
                                                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, D, s, i]
                                            }]
                                        }, i, n, e.C_BLOCK_COMMENT_MODE, o]
                                    };
                                return {
                                    name: "C",
                                    aliases: ["h"],
                                    keywords: d,
                                    disableAutodetect: !0,
                                    illegal: "</",
                                    contains: [].concat(F, A, E, [o, {
                                        begin: e.IDENT_RE + "::",
                                        keywords: d
                                    }, {
                                        className: "class",
                                        beginKeywords: "enum class struct union",
                                        end: /[{;:<>=]/,
                                        contains: [{
                                            beginKeywords: "final class struct"
                                        }, e.TITLE_MODE]
                                    }]),
                                    exports: {
                                        preprocessor: o,
                                        strings: D,
                                        keywords: d
                                    }
                                }
                            },
                            grmr_clojure: function(e) {
                                var u = "a-zA-Z_\\-!.?+*=<>&'",
                                    n = "[#]?[" + u + "][" + u + "0-9/;:$#]*",
                                    t = "def defonce defprotocol defstruct defmulti defmethod defn- defn defmacro deftype defrecord",
                                    a = {
                                        $pattern: n,
                                        built_in: t + " cond apply if-not if-let if not not= =|0 <|0 >|0 <=|0 >=|0 ==|0 +|0 /|0 *|0 -|0 rem quot neg? pos? delay? symbol? keyword? true? false? integer? empty? coll? list? set? ifn? fn? associative? sequential? sorted? counted? reversible? number? decimal? class? distinct? isa? float? rational? reduced? ratio? odd? even? char? seq? vector? string? map? nil? contains? zero? instance? not-every? not-any? libspec? -> ->> .. . inc compare do dotimes mapcat take remove take-while drop letfn drop-last take-last drop-while while intern condp case reduced cycle split-at split-with repeat replicate iterate range merge zipmap declare line-seq sort comparator sort-by dorun doall nthnext nthrest partition eval doseq await await-for let agent atom send send-off release-pending-sends add-watch mapv filterv remove-watch agent-error restart-agent set-error-handler error-handler set-error-mode! error-mode shutdown-agents quote var fn loop recur throw try monitor-enter monitor-exit macroexpand macroexpand-1 for dosync and or when when-not when-let comp juxt partial sequence memoize constantly complement identity assert peek pop doto proxy first rest cons cast coll last butlast sigs reify second ffirst fnext nfirst nnext meta with-meta ns in-ns create-ns import refer keys select-keys vals key val rseq name namespace promise into transient persistent! conj! assoc! dissoc! pop! disj! use class type num float double short byte boolean bigint biginteger bigdec print-method print-dup throw-if printf format load compile get-in update-in pr pr-on newline flush read slurp read-line subvec with-open memfn time re-find re-groups rand-int rand mod locking assert-valid-fdecl alias resolve ref deref refset swap! reset! set-validator! compare-and-set! alter-meta! reset-meta! commute get-validator alter ref-set ref-history-count ref-min-history ref-max-history ensure sync io! new next conj set! to-array future future-call into-array aset gen-class reduce map filter find empty hash-map hash-set sorted-map sorted-map-by sorted-set sorted-set-by vec vector seq flatten reverse assoc dissoc list disj get union difference intersection extend extend-type extend-protocol int nth delay count concat chunk chunk-buffer chunk-append chunk-first chunk-rest max min dec unchecked-inc-int unchecked-inc unchecked-dec-inc unchecked-dec unchecked-negate unchecked-add-int unchecked-add unchecked-subtract-int unchecked-subtract chunk-next chunk-cons chunked-seq? prn vary-meta lazy-seq spread list* str find-keyword keyword symbol gensym force rationalize"
                                    },
                                    r = {
                                        begin: n,
                                        relevance: 0
                                    },
                                    i = {
                                        scope: "number",
                                        relevance: 0,
                                        variants: [{
                                            match: /[-+]?0[xX][0-9a-fA-F]+N?/
                                        }, {
                                            match: /[-+]?0[0-7]+N?/
                                        }, {
                                            match: /[-+]?[1-9][0-9]?[rR][0-9a-zA-Z]+N?/
                                        }, {
                                            match: /[-+]?[0-9]+\/[0-9]+N?/
                                        }, {
                                            match: /[-+]?[0-9]+((\.[0-9]*([eE][+-]?[0-9]+)?M?)|([eE][+-]?[0-9]+M?|M))/
                                        }, {
                                            match: /[-+]?([1-9][0-9]*|0)N?/
                                        }]
                                    },
                                    D = {
                                        scope: "character",
                                        variants: [{
                                            match: /\\o[0-3]?[0-7]{1,2}/
                                        }, {
                                            match: /\\u[0-9a-fA-F]{4}/
                                        }, {
                                            match: /\\(newline|space|tab|formfeed|backspace|return)/
                                        }, {
                                            match: /\\\S/,
                                            relevance: 0
                                        }]
                                    },
                                    s = {
                                        scope: "regex",
                                        begin: /#"/,
                                        end: /"/,
                                        contains: [e.BACKSLASH_ESCAPE]
                                    },
                                    o = e.inherit(e.QUOTE_STRING_MODE, {
                                        illegal: null
                                    }),
                                    c = {
                                        scope: "punctuation",
                                        match: /,/,
                                        relevance: 0
                                    },
                                    l = e.COMMENT(";", "$", {
                                        relevance: 0
                                    }),
                                    d = {
                                        className: "literal",
                                        begin: /\b(true|false|nil)\b/
                                    },
                                    E = {
                                        begin: "\\[|(#::?" + n + ")?\\{",
                                        end: "[\\]\\}]",
                                        relevance: 0
                                    },
                                    F = {
                                        className: "symbol",
                                        begin: "[:]{1,2}" + n
                                    },
                                    A = {
                                        begin: "\\(",
                                        end: "\\)"
                                    },
                                    C = {
                                        endsWithParent: !0,
                                        relevance: 0
                                    },
                                    g = {
                                        keywords: a,
                                        className: "name",
                                        begin: n,
                                        relevance: 0,
                                        starts: C
                                    },
                                    b = [c, A, D, s, o, l, F, E, i, d, r],
                                    m = {
                                        beginKeywords: t,
                                        keywords: {
                                            $pattern: n,
                                            keyword: t
                                        },
                                        end: '(\\[|#|\\d|"|:|\\{|\\)|\\(|$)',
                                        contains: [{
                                            className: "title",
                                            begin: n,
                                            relevance: 0,
                                            excludeEnd: !0,
                                            endsParent: !0
                                        }].concat(b)
                                    };
                                return A.contains = [m, g, C], C.contains = b, E.contains = b, {
                                    name: "Clojure",
                                    aliases: ["clj", "edn"],
                                    illegal: /\S/,
                                    contains: [c, A, D, s, o, l, F, E, i, d]
                                }
                            },
                            grmr_coffeescript: function(e) {
                                var u, n = {
                                        keyword: ye.concat(["then", "unless", "until", "loop", "by", "when", "and", "or", "is", "isnt", "not"]).filter((u = ["var", "const", "let", "function", "static"], function(e) {
                                            return !u.includes(e)
                                        })),
                                        literal: we.concat(["yes", "no", "on", "off"]),
                                        built_in: Me.concat(["npm", "print"])
                                    },
                                    t = "[A-Za-z$_][0-9A-Za-z$_]*",
                                    a = {
                                        className: "subst",
                                        begin: /#\{/,
                                        end: /\}/,
                                        keywords: n
                                    },
                                    r = [e.BINARY_NUMBER_MODE, e.inherit(e.C_NUMBER_MODE, {
                                        starts: {
                                            end: "(\\s*/)?",
                                            relevance: 0
                                        }
                                    }), {
                                        className: "string",
                                        variants: [{
                                            begin: /'''/,
                                            end: /'''/,
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: /'/,
                                            end: /'/,
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: /"""/,
                                            end: /"""/,
                                            contains: [e.BACKSLASH_ESCAPE, a]
                                        }, {
                                            begin: /"/,
                                            end: /"/,
                                            contains: [e.BACKSLASH_ESCAPE, a]
                                        }]
                                    }, {
                                        className: "regexp",
                                        variants: [{
                                            begin: "///",
                                            end: "///",
                                            contains: [a, e.HASH_COMMENT_MODE]
                                        }, {
                                            begin: "//[gim]{0,3}(?=\\W)",
                                            relevance: 0
                                        }, {
                                            begin: /\/(?![ *]).*?(?![\\]).\/[gim]{0,3}(?=\W)/
                                        }]
                                    }, {
                                        begin: "@" + t
                                    }, {
                                        subLanguage: "javascript",
                                        excludeBegin: !0,
                                        excludeEnd: !0,
                                        variants: [{
                                            begin: "```",
                                            end: "```"
                                        }, {
                                            begin: "`",
                                            end: "`"
                                        }]
                                    }];
                                a.contains = r;
                                var i = e.inherit(e.TITLE_MODE, {
                                        begin: t
                                    }),
                                    D = "(\\(.*\\)\\s*)?\\B[-=]>",
                                    s = {
                                        className: "params",
                                        begin: "\\([^\\(]",
                                        returnBegin: !0,
                                        contains: [{
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: n,
                                            contains: ["self"].concat(r)
                                        }]
                                    },
                                    o = {
                                        variants: [{
                                            match: [/class\s+/, t, /\s+extends\s+/, t]
                                        }, {
                                            match: [/class\s+/, t]
                                        }],
                                        scope: {
                                            2: "title.class",
                                            4: "title.class.inherited"
                                        },
                                        keywords: n
                                    };
                                return {
                                    name: "CoffeeScript",
                                    aliases: ["coffee", "cson", "iced"],
                                    keywords: n,
                                    illegal: /\/\*/,
                                    contains: [].concat(r, [e.COMMENT("###", "###"), e.HASH_COMMENT_MODE, {
                                        className: "function",
                                        begin: "^\\s*" + t + "\\s*=\\s*" + D,
                                        end: "[-=]>",
                                        returnBegin: !0,
                                        contains: [i, s]
                                    }, {
                                        begin: /[:\(,=]\s*/,
                                        relevance: 0,
                                        contains: [{
                                            className: "function",
                                            begin: D,
                                            end: "[-=]>",
                                            returnBegin: !0,
                                            contains: [s]
                                        }]
                                    }, o, {
                                        begin: t + ":",
                                        end: ":",
                                        returnBegin: !0,
                                        returnEnd: !0,
                                        relevance: 0
                                    }])
                                }
                            },
                            grmr_cpp: function(e) {
                                var u = e.regex,
                                    n = e.COMMENT("//", "$", {
                                        contains: [{
                                            begin: /\\\n/
                                        }]
                                    }),
                                    t = "decltype\\(auto\\)",
                                    a = "[a-zA-Z_]\\w*::",
                                    r = "(?!struct)(" + t + "|" + u.optional(a) + "[a-zA-Z_]\\w*" + u.optional("<[^<>]+>") + ")",
                                    i = {
                                        className: "type",
                                        begin: "\\b[a-z\\d_]*_t\\b"
                                    },
                                    D = {
                                        className: "string",
                                        variants: [{
                                            begin: '(u8?|U|L)?"',
                                            end: '"',
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
                                            end: "'",
                                            illegal: "."
                                        }, e.END_SAME_AS_BEGIN({
                                            begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                                            end: /\)([^()\\ ]{0,16})"/
                                        })]
                                    },
                                    s = {
                                        className: "number",
                                        variants: [{
                                            begin: "\\b(0b[01']+)"
                                        }, {
                                            begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)"
                                        }, {
                                            begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
                                        }],
                                        relevance: 0
                                    },
                                    o = {
                                        className: "meta",
                                        begin: /#\s*[a-z]+\b/,
                                        end: /$/,
                                        keywords: {
                                            keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include"
                                        },
                                        contains: [{
                                            begin: /\\\n/,
                                            relevance: 0
                                        }, e.inherit(D, {
                                            className: "string"
                                        }), {
                                            className: "string",
                                            begin: /<.*?>/
                                        }, n, e.C_BLOCK_COMMENT_MODE]
                                    },
                                    c = {
                                        className: "title",
                                        begin: u.optional(a) + e.IDENT_RE,
                                        relevance: 0
                                    },
                                    l = u.optional(a) + e.IDENT_RE + "\\s*\\(",
                                    d = {
                                        type: ["bool", "char", "char16_t", "char32_t", "char8_t", "double", "float", "int", "long", "short", "void", "wchar_t", "unsigned", "signed", "const", "static"],
                                        keyword: ["alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel", "atomic_commit", "atomic_noexcept", "auto", "bitand", "bitor", "break", "case", "catch", "class", "co_await", "co_return", "co_yield", "compl", "concept", "const_cast|10", "consteval", "constexpr", "constinit", "continue", "decltype", "default", "delete", "do", "dynamic_cast|10", "else", "enum", "explicit", "export", "extern", "false", "final", "for", "friend", "goto", "if", "import", "inline", "module", "mutable", "namespace", "new", "noexcept", "not", "not_eq", "nullptr", "operator", "or", "or_eq", "override", "private", "protected", "public", "reflexpr", "register", "reinterpret_cast|10", "requires", "return", "sizeof", "static_assert", "static_cast|10", "struct", "switch", "synchronized", "template", "this", "thread_local", "throw", "transaction_safe", "transaction_safe_dynamic", "true", "try", "typedef", "typeid", "typename", "union", "using", "virtual", "volatile", "while", "xor", "xor_eq"],
                                        literal: ["NULL", "false", "nullopt", "nullptr", "true"],
                                        built_in: ["_Pragma"],
                                        _type_hints: ["any", "auto_ptr", "barrier", "binary_semaphore", "bitset", "complex", "condition_variable", "condition_variable_any", "counting_semaphore", "deque", "false_type", "future", "imaginary", "initializer_list", "istringstream", "jthread", "latch", "lock_guard", "multimap", "multiset", "mutex", "optional", "ostringstream", "packaged_task", "pair", "promise", "priority_queue", "queue", "recursive_mutex", "recursive_timed_mutex", "scoped_lock", "set", "shared_future", "shared_lock", "shared_mutex", "shared_timed_mutex", "shared_ptr", "stack", "string_view", "stringstream", "timed_mutex", "thread", "true_type", "tuple", "unique_lock", "unique_ptr", "unordered_map", "unordered_multimap", "unordered_multiset", "unordered_set", "variant", "vector", "weak_ptr", "wstring", "wstring_view"]
                                    },
                                    E = {
                                        className: "function.dispatch",
                                        relevance: 0,
                                        keywords: {
                                            _hint: ["abort", "abs", "acos", "apply", "as_const", "asin", "atan", "atan2", "calloc", "ceil", "cerr", "cin", "clog", "cos", "cosh", "cout", "declval", "endl", "exchange", "exit", "exp", "fabs", "floor", "fmod", "forward", "fprintf", "fputs", "free", "frexp", "fscanf", "future", "invoke", "isalnum", "isalpha", "iscntrl", "isdigit", "isgraph", "islower", "isprint", "ispunct", "isspace", "isupper", "isxdigit", "labs", "launder", "ldexp", "log", "log10", "make_pair", "make_shared", "make_shared_for_overwrite", "make_tuple", "make_unique", "malloc", "memchr", "memcmp", "memcpy", "memset", "modf", "move", "pow", "printf", "putchar", "puts", "realloc", "scanf", "sin", "sinh", "snprintf", "sprintf", "sqrt", "sscanf", "std", "stderr", "stdin", "stdout", "strcat", "strchr", "strcmp", "strcpy", "strcspn", "strlen", "strncat", "strncmp", "strncpy", "strpbrk", "strrchr", "strspn", "strstr", "swap", "tan", "tanh", "terminate", "to_underlying", "tolower", "toupper", "vfprintf", "visit", "vprintf", "vsprintf"]
                                        },
                                        begin: u.concat(/\b/, /(?!decltype)/, /(?!if)/, /(?!for)/, /(?!switch)/, /(?!while)/, e.IDENT_RE, u.lookahead(/(<[^<>]+>|)\s*\(/))
                                    },
                                    F = [E, o, i, n, e.C_BLOCK_COMMENT_MODE, s, D],
                                    A = {
                                        variants: [{
                                            begin: /=/,
                                            end: /;/
                                        }, {
                                            begin: /\(/,
                                            end: /\)/
                                        }, {
                                            beginKeywords: "new throw return else",
                                            end: /;/
                                        }],
                                        keywords: d,
                                        contains: F.concat([{
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: d,
                                            contains: F.concat(["self"]),
                                            relevance: 0
                                        }]),
                                        relevance: 0
                                    },
                                    C = {
                                        className: "function",
                                        begin: "(" + r + "[\\*&\\s]+)+" + l,
                                        returnBegin: !0,
                                        end: /[{;=]/,
                                        excludeEnd: !0,
                                        keywords: d,
                                        illegal: /[^\w\s\*&:<>.]/,
                                        contains: [{
                                            begin: t,
                                            keywords: d,
                                            relevance: 0
                                        }, {
                                            begin: l,
                                            returnBegin: !0,
                                            contains: [c],
                                            relevance: 0
                                        }, {
                                            begin: /::/,
                                            relevance: 0
                                        }, {
                                            begin: /:/,
                                            endsWithParent: !0,
                                            contains: [D, s]
                                        }, {
                                            relevance: 0,
                                            match: /,/
                                        }, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: d,
                                            relevance: 0,
                                            contains: [n, e.C_BLOCK_COMMENT_MODE, D, s, i, {
                                                begin: /\(/,
                                                end: /\)/,
                                                keywords: d,
                                                relevance: 0,
                                                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, D, s, i]
                                            }]
                                        }, i, n, e.C_BLOCK_COMMENT_MODE, o]
                                    };
                                return {
                                    name: "C++",
                                    aliases: ["cc", "c++", "h++", "hpp", "hh", "hxx", "cxx"],
                                    keywords: d,
                                    illegal: "</",
                                    classNameAliases: {
                                        "function.dispatch": "built_in"
                                    },
                                    contains: [].concat(A, C, E, F, [o, {
                                        begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function)\\s*<(?!<)",
                                        end: ">",
                                        keywords: d,
                                        contains: ["self", i]
                                    }, {
                                        begin: e.IDENT_RE + "::",
                                        keywords: d
                                    }, {
                                        match: [/\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/, /\s+/, /\w+/],
                                        className: {
                                            1: "keyword",
                                            3: "title.class"
                                        }
                                    }])
                                }
                            },
                            grmr_csharp: function(e) {
                                var u = {
                                        keyword: ["abstract", "as", "base", "break", "case", "catch", "class", "const", "continue", "do", "else", "event", "explicit", "extern", "finally", "fixed", "for", "foreach", "goto", "if", "implicit", "in", "interface", "internal", "is", "lock", "namespace", "new", "operator", "out", "override", "params", "private", "protected", "public", "readonly", "record", "ref", "return", "scoped", "sealed", "sizeof", "stackalloc", "static", "struct", "switch", "this", "throw", "try", "typeof", "unchecked", "unsafe", "using", "virtual", "void", "volatile", "while"].concat(["add", "alias", "and", "ascending", "async", "await", "by", "descending", "equals", "from", "get", "global", "group", "init", "into", "join", "let", "nameof", "not", "notnull", "on", "or", "orderby", "partial", "remove", "select", "set", "unmanaged", "value|0", "var", "when", "where", "with", "yield"]),
                                        built_in: ["bool", "byte", "char", "decimal", "delegate", "double", "dynamic", "enum", "float", "int", "long", "nint", "nuint", "object", "sbyte", "short", "string", "ulong", "uint", "ushort"],
                                        literal: ["default", "false", "null", "true"]
                                    },
                                    n = e.inherit(e.TITLE_MODE, {
                                        begin: "[a-zA-Z](\\.?\\w)*"
                                    }),
                                    t = {
                                        className: "number",
                                        variants: [{
                                            begin: "\\b(0b[01']+)"
                                        }, {
                                            begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)(u|U|l|L|ul|UL|f|F|b|B)"
                                        }, {
                                            begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
                                        }],
                                        relevance: 0
                                    },
                                    a = {
                                        className: "string",
                                        begin: '@"',
                                        end: '"',
                                        contains: [{
                                            begin: '""'
                                        }]
                                    },
                                    r = e.inherit(a, {
                                        illegal: /\n/
                                    }),
                                    i = {
                                        className: "subst",
                                        begin: /\{/,
                                        end: /\}/,
                                        keywords: u
                                    },
                                    D = e.inherit(i, {
                                        illegal: /\n/
                                    }),
                                    s = {
                                        className: "string",
                                        begin: /\$"/,
                                        end: '"',
                                        illegal: /\n/,
                                        contains: [{
                                            begin: /\{\{/
                                        }, {
                                            begin: /\}\}/
                                        }, e.BACKSLASH_ESCAPE, D]
                                    },
                                    o = {
                                        className: "string",
                                        begin: /\$@"/,
                                        end: '"',
                                        contains: [{
                                            begin: /\{\{/
                                        }, {
                                            begin: /\}\}/
                                        }, {
                                            begin: '""'
                                        }, i]
                                    },
                                    c = e.inherit(o, {
                                        illegal: /\n/,
                                        contains: [{
                                            begin: /\{\{/
                                        }, {
                                            begin: /\}\}/
                                        }, {
                                            begin: '""'
                                        }, D]
                                    });
                                i.contains = [o, s, a, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, t, e.C_BLOCK_COMMENT_MODE], D.contains = [c, s, r, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, t, e.inherit(e.C_BLOCK_COMMENT_MODE, {
                                    illegal: /\n/
                                })];
                                var l = {
                                        variants: [o, s, a, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
                                    },
                                    d = {
                                        begin: "<",
                                        end: ">",
                                        contains: [{
                                            beginKeywords: "in out"
                                        }, n]
                                    },
                                    E = e.IDENT_RE + "(<" + e.IDENT_RE + "(\\s*,\\s*" + e.IDENT_RE + ")*>)?(\\[\\])?",
                                    F = {
                                        begin: "@" + e.IDENT_RE,
                                        relevance: 0
                                    };
                                return {
                                    name: "C#",
                                    aliases: ["cs", "c#"],
                                    keywords: u,
                                    illegal: /::/,
                                    contains: [e.COMMENT("///", "$", {
                                        returnBegin: !0,
                                        contains: [{
                                            className: "doctag",
                                            variants: [{
                                                begin: "///",
                                                relevance: 0
                                            }, {
                                                begin: "\x3c!--|--\x3e"
                                            }, {
                                                begin: "</?",
                                                end: ">"
                                            }]
                                        }]
                                    }), e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                                        className: "meta",
                                        begin: "#",
                                        end: "$",
                                        keywords: {
                                            keyword: "if else elif endif define undef warning error line region endregion pragma checksum"
                                        }
                                    }, l, t, {
                                        beginKeywords: "class interface",
                                        relevance: 0,
                                        end: /[{;=]/,
                                        illegal: /[^\s:,]/,
                                        contains: [{
                                            beginKeywords: "where class"
                                        }, n, d, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, {
                                        beginKeywords: "namespace",
                                        relevance: 0,
                                        end: /[{;=]/,
                                        illegal: /[^\s:]/,
                                        contains: [n, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, {
                                        beginKeywords: "record",
                                        relevance: 0,
                                        end: /[{;=]/,
                                        illegal: /[^\s:]/,
                                        contains: [n, d, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, {
                                        className: "meta",
                                        begin: "^\\s*\\[(?=[\\w])",
                                        excludeBegin: !0,
                                        end: "\\]",
                                        excludeEnd: !0,
                                        contains: [{
                                            className: "string",
                                            begin: /"/,
                                            end: /"/
                                        }]
                                    }, {
                                        beginKeywords: "new return throw await else",
                                        relevance: 0
                                    }, {
                                        className: "function",
                                        begin: "(" + E + "\\s+)+" + e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
                                        returnBegin: !0,
                                        end: /\s*[{;=]/,
                                        excludeEnd: !0,
                                        keywords: u,
                                        contains: [{
                                            beginKeywords: ["public", "private", "protected", "static", "internal", "protected", "abstract", "async", "extern", "override", "unsafe", "virtual", "new", "sealed", "partial"].join(" "),
                                            relevance: 0
                                        }, {
                                            begin: e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
                                            returnBegin: !0,
                                            contains: [e.TITLE_MODE, d],
                                            relevance: 0
                                        }, {
                                            match: /\(\)/
                                        }, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            keywords: u,
                                            relevance: 0,
                                            contains: [l, t, e.C_BLOCK_COMMENT_MODE]
                                        }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, F]
                                }
                            },
                            grmr_css: function(e) {
                                var u = e.regex,
                                    n = be(e),
                                    t = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE];
                                return {
                                    name: "CSS",
                                    case_insensitive: !0,
                                    illegal: /[=|'\$]/,
                                    keywords: {
                                        keyframePosition: "from to"
                                    },
                                    classNameAliases: {
                                        keyframePosition: "selector-tag"
                                    },
                                    contains: [n.BLOCK_COMMENT, {
                                        begin: /-(webkit|moz|ms|o)-(?=[a-z])/
                                    }, n.CSS_NUMBER_MODE, {
                                        className: "selector-id",
                                        begin: /#[A-Za-z0-9_-]+/,
                                        relevance: 0
                                    }, {
                                        className: "selector-class",
                                        begin: "\\.[a-zA-Z-][a-zA-Z0-9_-]*",
                                        relevance: 0
                                    }, n.ATTRIBUTE_SELECTOR_MODE, {
                                        className: "selector-pseudo",
                                        variants: [{
                                            begin: ":(" + fe.join("|") + ")"
                                        }, {
                                            begin: ":(:)?(" + Be.join("|") + ")"
                                        }]
                                    }, n.CSS_VARIABLE, {
                                        className: "attribute",
                                        begin: "\\b(" + he.join("|") + ")\\b"
                                    }, {
                                        begin: /:/,
                                        end: /[;}{]/,
                                        contains: [n.BLOCK_COMMENT, n.HEXCOLOR, n.IMPORTANT, n.CSS_NUMBER_MODE].concat(t, [{
                                            begin: /(url|data-uri)\(/,
                                            end: /\)/,
                                            relevance: 0,
                                            keywords: {
                                                built_in: "url data-uri"
                                            },
                                            contains: [].concat(t, [{
                                                className: "string",
                                                begin: /[^)]/,
                                                endsWithParent: !0,
                                                excludeEnd: !0
                                            }])
                                        }, n.FUNCTION_DISPATCH])
                                    }, {
                                        begin: u.lookahead(/@/),
                                        end: "[{;]",
                                        relevance: 0,
                                        illegal: /:/,
                                        contains: [{
                                            className: "keyword",
                                            begin: /@-?\w[\w]*(-\w+)*/
                                        }, {
                                            begin: /\s/,
                                            endsWithParent: !0,
                                            excludeEnd: !0,
                                            relevance: 0,
                                            keywords: {
                                                $pattern: /[a-z-]+/,
                                                keyword: "and or not only",
                                                attribute: pe.join(" ")
                                            },
                                            contains: [{
                                                begin: /[a-z-]+(?=:)/,
                                                className: "attribute"
                                            }].concat(t, [n.CSS_NUMBER_MODE])
                                        }]
                                    }, {
                                        className: "selector-tag",
                                        begin: "\\b(" + me.join("|") + ")\\b"
                                    }]
                                }
                            },
                            grmr_dart: function(e) {
                                var u = {
                                        className: "subst",
                                        variants: [{
                                            begin: "\\$[A-Za-z0-9_]+"
                                        }]
                                    },
                                    n = {
                                        className: "subst",
                                        variants: [{
                                            begin: /\$\{/,
                                            end: /\}/
                                        }],
                                        keywords: "true false null this is new super"
                                    },
                                    t = {
                                        className: "string",
                                        variants: [{
                                            begin: "r'''",
                                            end: "'''"
                                        }, {
                                            begin: 'r"""',
                                            end: '"""'
                                        }, {
                                            begin: "r'",
                                            end: "'",
                                            illegal: "\\n"
                                        }, {
                                            begin: 'r"',
                                            end: '"',
                                            illegal: "\\n"
                                        }, {
                                            begin: "'''",
                                            end: "'''",
                                            contains: [e.BACKSLASH_ESCAPE, u, n]
                                        }, {
                                            begin: '"""',
                                            end: '"""',
                                            contains: [e.BACKSLASH_ESCAPE, u, n]
                                        }, {
                                            begin: "'",
                                            end: "'",
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE, u, n]
                                        }, {
                                            begin: '"',
                                            end: '"',
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE, u, n]
                                        }]
                                    };
                                n.contains = [e.C_NUMBER_MODE, t];
                                var a = ["Comparable", "DateTime", "Duration", "Function", "Iterable", "Iterator", "List", "Map", "Match", "Object", "Pattern", "RegExp", "Set", "Stopwatch", "String", "StringBuffer", "StringSink", "Symbol", "Type", "Uri", "bool", "double", "int", "num", "Element", "ElementList"],
                                    r = a.map((function(e) {
                                        return "".concat(e, "?")
                                    }));
                                return {
                                    name: "Dart",
                                    keywords: {
                                        keyword: ["abstract", "as", "assert", "async", "await", "base", "break", "case", "catch", "class", "const", "continue", "covariant", "default", "deferred", "do", "dynamic", "else", "enum", "export", "extends", "extension", "external", "factory", "false", "final", "finally", "for", "Function", "get", "hide", "if", "implements", "import", "in", "interface", "is", "late", "library", "mixin", "new", "null", "on", "operator", "part", "required", "rethrow", "return", "sealed", "set", "show", "static", "super", "switch", "sync", "this", "throw", "true", "try", "typedef", "var", "void", "when", "while", "with", "yield"],
                                        built_in: a.concat(r).concat(["Never", "Null", "dynamic", "print", "document", "querySelector", "querySelectorAll", "window"]),
                                        $pattern: /[A-Za-z][A-Za-z0-9_]*\??/
                                    },
                                    contains: [t, e.COMMENT(/\/\*\*(?!\/)/, /\*\//, {
                                        subLanguage: "markdown",
                                        relevance: 0
                                    }), e.COMMENT(/\/{3,} ?/, /$/, {
                                        contains: [{
                                            subLanguage: "markdown",
                                            begin: ".",
                                            end: "$",
                                            relevance: 0
                                        }]
                                    }), e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                                        className: "class",
                                        beginKeywords: "class interface",
                                        end: /\{/,
                                        excludeEnd: !0,
                                        contains: [{
                                            beginKeywords: "extends implements"
                                        }, e.UNDERSCORE_TITLE_MODE]
                                    }, e.C_NUMBER_MODE, {
                                        className: "meta",
                                        begin: "@[A-Za-z]+"
                                    }, {
                                        begin: "=>"
                                    }]
                                }
                            },
                            grmr_delphi: function(e) {
                                var u = ["exports", "register", "file", "shl", "array", "record", "property", "for", "mod", "while", "set", "ally", "label", "uses", "raise", "not", "stored", "class", "safecall", "var", "interface", "or", "private", "static", "exit", "index", "inherited", "to", "else", "stdcall", "override", "shr", "asm", "far", "resourcestring", "finalization", "packed", "virtual", "out", "and", "protected", "library", "do", "xorwrite", "goto", "near", "function", "end", "div", "overload", "object", "unit", "begin", "string", "on", "inline", "repeat", "until", "destructor", "write", "message", "program", "with", "read", "initialization", "except", "default", "nil", "if", "case", "cdecl", "in", "downto", "threadvar", "of", "try", "pascal", "const", "external", "constructor", "type", "public", "then", "implementation", "finally", "published", "procedure", "absolute", "reintroduce", "operator", "as", "is", "abstract", "alias", "assembler", "bitpacked", "break", "continue", "cppdecl", "cvar", "enumerator", "experimental", "platform", "deprecated", "unimplemented", "dynamic", "export", "far16", "forward", "generic", "helper", "implements", "interrupt", "iochecks", "local", "name", "nodefault", "noreturn", "nostackframe", "oldfpccall", "otherwise", "saveregisters", "softfloat", "specialize", "strict", "unaligned", "varargs"],
                                    n = [e.C_LINE_COMMENT_MODE, e.COMMENT(/\{/, /\}/, {
                                        relevance: 0
                                    }), e.COMMENT(/\(\*/, /\*\)/, {
                                        relevance: 10
                                    })],
                                    t = {
                                        className: "meta",
                                        variants: [{
                                            begin: /\{\$/,
                                            end: /\}/
                                        }, {
                                            begin: /\(\*\$/,
                                            end: /\*\)/
                                        }]
                                    },
                                    a = {
                                        className: "string",
                                        begin: /'/,
                                        end: /'/,
                                        contains: [{
                                            begin: /''/
                                        }]
                                    },
                                    r = {
                                        className: "string",
                                        begin: /(#\d+)+/
                                    },
                                    i = {
                                        begin: e.IDENT_RE + "\\s*=\\s*class\\s*\\(",
                                        returnBegin: !0,
                                        contains: [e.TITLE_MODE]
                                    },
                                    D = {
                                        className: "function",
                                        beginKeywords: "function constructor destructor procedure",
                                        end: /[:;]/,
                                        keywords: "function constructor|10 destructor|10 procedure|10",
                                        contains: [e.TITLE_MODE, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: u,
                                            contains: [a, r, t].concat(n)
                                        }, t].concat(n)
                                    };
                                return {
                                    name: "Delphi",
                                    aliases: ["dpr", "dfm", "pas", "pascal"],
                                    case_insensitive: !0,
                                    keywords: u,
                                    illegal: /"|\$[G-Zg-z]|\/\*|<\/|\|/,
                                    contains: [a, r, e.NUMBER_MODE, {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            begin: "\\$[0-9A-Fa-f]+"
                                        }, {
                                            begin: "&[0-7]+"
                                        }, {
                                            begin: "%[01]+"
                                        }]
                                    }, i, D, t].concat(n)
                                }
                            },
                            grmr_erlang: function(e) {
                                var u = "[a-z'][a-zA-Z0-9_']*",
                                    n = "(" + u + ":" + u + "|" + u + ")",
                                    t = {
                                        keyword: "after and andalso|10 band begin bnot bor bsl bzr bxor case catch cond div end fun if let not of orelse|10 query receive rem try when xor",
                                        literal: "false true"
                                    },
                                    a = e.COMMENT("%", "$"),
                                    r = {
                                        className: "number",
                                        begin: "\\b(\\d+(_\\d+)*#[a-fA-F0-9]+(_[a-fA-F0-9]+)*|\\d+(_\\d+)*(\\.\\d+(_\\d+)*)?([eE][-+]?\\d+)?)",
                                        relevance: 0
                                    },
                                    i = {
                                        begin: "fun\\s+" + u + "/\\d+"
                                    },
                                    D = {
                                        begin: n + "\\(",
                                        end: "\\)",
                                        returnBegin: !0,
                                        relevance: 0,
                                        contains: [{
                                            begin: n,
                                            relevance: 0
                                        }, {
                                            begin: "\\(",
                                            end: "\\)",
                                            endsWithParent: !0,
                                            returnEnd: !0,
                                            relevance: 0
                                        }]
                                    },
                                    s = {
                                        begin: /\{/,
                                        end: /\}/,
                                        relevance: 0
                                    },
                                    o = {
                                        begin: "\\b_([A-Z][A-Za-z0-9_]*)?",
                                        relevance: 0
                                    },
                                    c = {
                                        begin: "[A-Z][a-zA-Z0-9_]*",
                                        relevance: 0
                                    },
                                    l = {
                                        begin: "#" + e.UNDERSCORE_IDENT_RE,
                                        relevance: 0,
                                        returnBegin: !0,
                                        contains: [{
                                            begin: "#" + e.UNDERSCORE_IDENT_RE,
                                            relevance: 0
                                        }, {
                                            begin: /\{/,
                                            end: /\}/,
                                            relevance: 0
                                        }]
                                    },
                                    d = {
                                        beginKeywords: "fun receive if try case",
                                        end: "end",
                                        keywords: t
                                    };
                                d.contains = [a, i, e.inherit(e.APOS_STRING_MODE, {
                                    className: ""
                                }), d, D, e.QUOTE_STRING_MODE, r, s, o, c, l];
                                var E = [a, i, d, D, e.QUOTE_STRING_MODE, r, s, o, c, l];
                                D.contains[1].contains = E, s.contains = E, l.contains[1].contains = E;
                                var F = {
                                    className: "params",
                                    begin: "\\(",
                                    end: "\\)",
                                    contains: E
                                };
                                return {
                                    name: "Erlang",
                                    aliases: ["erl"],
                                    keywords: t,
                                    illegal: "(</|\\*=|\\+=|-=|/\\*|\\*/|\\(\\*|\\*\\))",
                                    contains: [{
                                        className: "function",
                                        begin: "^" + u + "\\s*\\(",
                                        end: "->",
                                        returnBegin: !0,
                                        illegal: "\\(|#|//|/\\*|\\\\|:|;",
                                        contains: [F, e.inherit(e.TITLE_MODE, {
                                            begin: u
                                        })],
                                        starts: {
                                            end: ";|\\.",
                                            keywords: t,
                                            contains: E
                                        }
                                    }, a, {
                                        begin: "^-",
                                        end: "\\.",
                                        relevance: 0,
                                        excludeEnd: !0,
                                        returnBegin: !0,
                                        keywords: {
                                            $pattern: "-" + e.IDENT_RE,
                                            keyword: ["-module", "-record", "-undef", "-export", "-ifdef", "-ifndef", "-author", "-copyright", "-doc", "-vsn", "-import", "-include", "-include_lib", "-compile", "-define", "-else", "-endif", "-file", "-behaviour", "-behavior", "-spec"].map((function(e) {
                                                return "".concat(e, "|1.5")
                                            })).join(" ")
                                        },
                                        contains: [F]
                                    }, r, e.QUOTE_STRING_MODE, l, o, c, s, {
                                        begin: /\.$/
                                    }]
                                }
                            },
                            grmr_go: function(e) {
                                var u = {
                                    keyword: ["break", "case", "chan", "const", "continue", "default", "defer", "else", "fallthrough", "for", "func", "go", "goto", "if", "import", "interface", "map", "package", "range", "return", "select", "struct", "switch", "type", "var"],
                                    type: ["bool", "byte", "complex64", "complex128", "error", "float32", "float64", "int8", "int16", "int32", "int64", "string", "uint8", "uint16", "uint32", "uint64", "int", "uint", "uintptr", "rune"],
                                    literal: ["true", "false", "iota", "nil"],
                                    built_in: ["append", "cap", "close", "complex", "copy", "imag", "len", "make", "new", "panic", "print", "println", "real", "recover", "delete"]
                                };
                                return {
                                    name: "Go",
                                    aliases: ["golang"],
                                    keywords: u,
                                    illegal: "</",
                                    contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                                        className: "string",
                                        variants: [e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, {
                                            begin: "`",
                                            end: "`"
                                        }]
                                    }, {
                                        className: "number",
                                        variants: [{
                                            begin: e.C_NUMBER_RE + "[i]",
                                            relevance: 1
                                        }, e.C_NUMBER_MODE]
                                    }, {
                                        begin: /:=/
                                    }, {
                                        className: "function",
                                        beginKeywords: "func",
                                        end: "\\s*(\\{|$)",
                                        excludeEnd: !0,
                                        contains: [e.TITLE_MODE, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            endsParent: !0,
                                            keywords: u,
                                            illegal: /["']/
                                        }]
                                    }]
                                }
                            },
                            grmr_haskell: function(e) {
                                var u = "([0-9]_*)+",
                                    n = "([0-9a-fA-F]_*)+",
                                    t = "(".concat("[!#$%&*+.\\/<=>?@\\\\^~-]", "|(?!(").concat("[(),;\\[\\]`|{}]", "|[_:\"']))").concat("(\\p{S}|\\p{P})", ")"),
                                    a = {
                                        variants: [e.COMMENT("--+", "$"), e.COMMENT(/\{-/, /-\}/, {
                                            contains: ["self"]
                                        })]
                                    },
                                    r = {
                                        className: "meta",
                                        begin: /\{-#/,
                                        end: /#-\}/
                                    },
                                    i = {
                                        className: "meta",
                                        begin: "^#",
                                        end: "$"
                                    },
                                    D = {
                                        className: "type",
                                        begin: "\\b[A-Z][\\w']*",
                                        relevance: 0
                                    },
                                    s = {
                                        begin: "\\(",
                                        end: "\\)",
                                        illegal: '"',
                                        contains: [r, i, {
                                            className: "type",
                                            begin: "\\b[A-Z][\\w]*(\\((\\.\\.|,|\\w+)\\))?"
                                        }, e.inherit(e.TITLE_MODE, {
                                            begin: "[_a-z][\\w']*"
                                        }), a]
                                    },
                                    o = {
                                        begin: /\{/,
                                        end: /\}/,
                                        contains: s.contains
                                    },
                                    c = {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            match: "\\b(".concat(u, ")(\\.(").concat(u, "))?") + "([eE][+-]?(".concat(u, "))?\\b")
                                        }, {
                                            match: "\\b0[xX]_*(".concat(n, ")(\\.(").concat(n, "))?") + "([pP][+-]?(".concat(u, "))?\\b")
                                        }, {
                                            match: "\\b0[oO](".concat("([0-7]_*)+", ")\\b")
                                        }, {
                                            match: "\\b0[bB](".concat("([01]_*)+", ")\\b")
                                        }]
                                    };
                                return {
                                    name: "Haskell",
                                    aliases: ["hs"],
                                    keywords: "let in if then else case of where do module import hiding qualified type data newtype deriving class instance as default infix infixl infixr foreign export ccall stdcall cplusplus jvm dotnet safe unsafe family forall mdo proc rec",
                                    unicodeRegex: !0,
                                    contains: [{
                                        beginKeywords: "module",
                                        end: "where",
                                        keywords: "module where",
                                        contains: [s, a],
                                        illegal: "\\W\\.|;"
                                    }, {
                                        begin: "\\bimport\\b",
                                        end: "$",
                                        keywords: "import qualified as hiding",
                                        contains: [s, a],
                                        illegal: "\\W\\.|;"
                                    }, {
                                        className: "class",
                                        begin: "^(\\s*)?(class|instance)\\b",
                                        end: "where",
                                        keywords: "class family instance where",
                                        contains: [D, s, a]
                                    }, {
                                        className: "class",
                                        begin: "\\b(data|(new)?type)\\b",
                                        end: "$",
                                        keywords: "data family type newtype deriving",
                                        contains: [r, D, s, o, a]
                                    }, {
                                        beginKeywords: "default",
                                        end: "$",
                                        contains: [D, s, a]
                                    }, {
                                        beginKeywords: "infix infixl infixr",
                                        end: "$",
                                        contains: [e.C_NUMBER_MODE, a]
                                    }, {
                                        begin: "\\bforeign\\b",
                                        end: "$",
                                        keywords: "foreign import export ccall stdcall cplusplus jvm dotnet safe unsafe",
                                        contains: [D, e.QUOTE_STRING_MODE, a]
                                    }, {
                                        className: "meta",
                                        begin: "#!\\/usr\\/bin\\/env runhaskell",
                                        end: "$"
                                    }, r, i, {
                                        scope: "string",
                                        begin: /'(?=\\?.')/,
                                        end: /'/,
                                        contains: [{
                                            scope: "char.escape",
                                            match: /\\./
                                        }]
                                    }, e.QUOTE_STRING_MODE, c, D, e.inherit(e.TITLE_MODE, {
                                        begin: "^[_a-z][\\w']*"
                                    }), {
                                        begin: "(?!-)".concat(t, "--+|--+(?!-)").concat(t)
                                    }, a, {
                                        begin: "->|<-"
                                    }]
                                }
                            },
                            grmr_http: function(e) {
                                var u = "HTTP/([32]|1\\.[01])",
                                    n = {
                                        className: "attribute",
                                        begin: e.regex.concat("^", /[A-Za-z][A-Za-z0-9-]*/, "(?=\\:\\s)"),
                                        starts: {
                                            contains: [{
                                                className: "punctuation",
                                                begin: /: /,
                                                relevance: 0,
                                                starts: {
                                                    end: "$",
                                                    relevance: 0
                                                }
                                            }]
                                        }
                                    },
                                    t = [n, {
                                        begin: "\\n\\n",
                                        starts: {
                                            subLanguage: [],
                                            endsWithParent: !0
                                        }
                                    }];
                                return {
                                    name: "HTTP",
                                    aliases: ["https"],
                                    illegal: /\S/,
                                    contains: [{
                                        begin: "^(?=" + u + " \\d{3})",
                                        end: /$/,
                                        contains: [{
                                            className: "meta",
                                            begin: u
                                        }, {
                                            className: "number",
                                            begin: "\\b\\d{3}\\b"
                                        }],
                                        starts: {
                                            end: /\b\B/,
                                            illegal: /\S/,
                                            contains: t
                                        }
                                    }, {
                                        begin: "(?=^[A-Z]+ (.*?) " + u + "$)",
                                        end: /$/,
                                        contains: [{
                                            className: "string",
                                            begin: " ",
                                            end: " ",
                                            excludeBegin: !0,
                                            excludeEnd: !0
                                        }, {
                                            className: "meta",
                                            begin: u
                                        }, {
                                            className: "keyword",
                                            begin: "[A-Z]+"
                                        }],
                                        starts: {
                                            end: /\b\B/,
                                            illegal: /\S/,
                                            contains: t
                                        }
                                    }, e.inherit(n, {
                                        relevance: 0
                                    })]
                                }
                            },
                            grmr_ini: function(e) {
                                var u = e.regex,
                                    n = {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            begin: /([+-]+)?[\d]+_[\d_]+/
                                        }, {
                                            begin: e.NUMBER_RE
                                        }]
                                    },
                                    t = e.COMMENT();
                                t.variants = [{
                                    begin: /;/,
                                    end: /$/
                                }, {
                                    begin: /#/,
                                    end: /$/
                                }];
                                var a = {
                                        className: "variable",
                                        variants: [{
                                            begin: /\$[\w\d"][\w\d_]*/
                                        }, {
                                            begin: /\$\{(.*?)\}/
                                        }]
                                    },
                                    r = {
                                        className: "literal",
                                        begin: /\bon|off|true|false|yes|no\b/
                                    },
                                    i = {
                                        className: "string",
                                        contains: [e.BACKSLASH_ESCAPE],
                                        variants: [{
                                            begin: "'''",
                                            end: "'''",
                                            relevance: 10
                                        }, {
                                            begin: '"""',
                                            end: '"""',
                                            relevance: 10
                                        }, {
                                            begin: '"',
                                            end: '"'
                                        }, {
                                            begin: "'",
                                            end: "'"
                                        }]
                                    },
                                    D = {
                                        begin: /\[/,
                                        end: /\]/,
                                        contains: [t, r, a, i, n, "self"],
                                        relevance: 0
                                    },
                                    s = u.either(/[A-Za-z0-9_-]+/, /"(\\"|[^"])*"/, /'[^']*'/);
                                return {
                                    name: "TOML, also INI",
                                    aliases: ["toml"],
                                    case_insensitive: !0,
                                    illegal: /\S/,
                                    contains: [t, {
                                        className: "section",
                                        begin: /\[+/,
                                        end: /\]+/
                                    }, {
                                        begin: u.concat(s, "(\\s*\\.\\s*", s, ")*", u.lookahead(/\s*=\s*[^#\s]/)),
                                        className: "attr",
                                        starts: {
                                            end: /$/,
                                            contains: [t, D, r, a, i, n]
                                        }
                                    }]
                                }
                            },
                            grmr_java: function(e) {
                                var u = e.regex,
                                    n = "[À-ʸa-zA-Z_$][À-ʸa-zA-Z_$0-9]*",
                                    t = n + Le("(?:<" + n + "~~~(?:\\s*,\\s*" + n + "~~~)*>)?", /~~~/g, 2),
                                    a = {
                                        keyword: ["synchronized", "abstract", "private", "var", "static", "if", "const ", "for", "while", "strictfp", "finally", "protected", "import", "native", "final", "void", "enum", "else", "break", "transient", "catch", "instanceof", "volatile", "case", "assert", "package", "default", "public", "try", "switch", "continue", "throws", "protected", "public", "private", "module", "requires", "exports", "do", "sealed", "yield", "permits"],
                                        literal: ["false", "true", "null"],
                                        type: ["char", "boolean", "long", "float", "int", "byte", "short", "double"],
                                        built_in: ["super", "this"]
                                    },
                                    r = {
                                        className: "meta",
                                        begin: "@" + n,
                                        contains: [{
                                            begin: /\(/,
                                            end: /\)/,
                                            contains: ["self"]
                                        }]
                                    },
                                    i = {
                                        className: "params",
                                        begin: /\(/,
                                        end: /\)/,
                                        keywords: a,
                                        relevance: 0,
                                        contains: [e.C_BLOCK_COMMENT_MODE],
                                        endsParent: !0
                                    };
                                return {
                                    name: "Java",
                                    aliases: ["jsp"],
                                    keywords: a,
                                    illegal: /<\/|#/,
                                    contains: [e.COMMENT("/\\*\\*", "\\*/", {
                                        relevance: 0,
                                        contains: [{
                                            begin: /\w+@/,
                                            relevance: 0
                                        }, {
                                            className: "doctag",
                                            begin: "@[A-Za-z]+"
                                        }]
                                    }), {
                                        begin: /import java\.[a-z]+\./,
                                        keywords: "import",
                                        relevance: 2
                                    }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                                        begin: /"""/,
                                        end: /"""/,
                                        className: "string",
                                        contains: [e.BACKSLASH_ESCAPE]
                                    }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, {
                                        match: [/\b(?:class|interface|enum|extends|implements|new)/, /\s+/, n],
                                        className: {
                                            1: "keyword",
                                            3: "title.class"
                                        }
                                    }, {
                                        match: /non-sealed/,
                                        scope: "keyword"
                                    }, {
                                        begin: [u.concat(/(?!else)/, n), /\s+/, n, /\s+/, /=(?!=)/],
                                        className: {
                                            1: "type",
                                            3: "variable",
                                            5: "operator"
                                        }
                                    }, {
                                        begin: [/record/, /\s+/, n],
                                        className: {
                                            1: "keyword",
                                            3: "title.class"
                                        },
                                        contains: [i, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, {
                                        beginKeywords: "new throw return else",
                                        relevance: 0
                                    }, {
                                        begin: ["(?:" + t + "\\s+)", e.UNDERSCORE_IDENT_RE, /\s*(?=\()/],
                                        className: {
                                            2: "title.function"
                                        },
                                        keywords: a,
                                        contains: [{
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            keywords: a,
                                            relevance: 0,
                                            contains: [r, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, Ie, e.C_BLOCK_COMMENT_MODE]
                                        }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, Ie, r]
                                }
                            },
                            grmr_javascript: ze,
                            grmr_json: function(e) {
                                var u = ["true", "false", "null"],
                                    n = {
                                        scope: "literal",
                                        beginKeywords: u.join(" ")
                                    };
                                return {
                                    name: "JSON",
                                    keywords: {
                                        literal: u
                                    },
                                    contains: [{
                                        className: "attr",
                                        begin: /"(\\.|[^\\"\r\n])*"(?=\s*:)/,
                                        relevance: 1.01
                                    }, {
                                        match: /[{}[\],:]/,
                                        className: "punctuation",
                                        relevance: 0
                                    }, e.QUOTE_STRING_MODE, n, e.C_NUMBER_MODE, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE],
                                    illegal: "\\S"
                                }
                            },
                            grmr_julia: function(e) {
                                var u = "[A-Za-z_\\u00A1-\\uFFFF][A-Za-z_0-9\\u00A1-\\uFFFF]*",
                                    n = {
                                        $pattern: u,
                                        keyword: ["baremodule", "begin", "break", "catch", "ccall", "const", "continue", "do", "else", "elseif", "end", "export", "false", "finally", "for", "function", "global", "if", "import", "in", "isa", "let", "local", "macro", "module", "quote", "return", "true", "try", "using", "where", "while"],
                                        literal: ["ARGS", "C_NULL", "DEPOT_PATH", "ENDIAN_BOM", "ENV", "Inf", "Inf16", "Inf32", "Inf64", "InsertionSort", "LOAD_PATH", "MergeSort", "NaN", "NaN16", "NaN32", "NaN64", "PROGRAM_FILE", "QuickSort", "RoundDown", "RoundFromZero", "RoundNearest", "RoundNearestTiesAway", "RoundNearestTiesUp", "RoundToZero", "RoundUp", "VERSION|0", "devnull", "false", "im", "missing", "nothing", "pi", "stderr", "stdin", "stdout", "true", "undef", "π", "ℯ"],
                                        built_in: ["AbstractArray", "AbstractChannel", "AbstractChar", "AbstractDict", "AbstractDisplay", "AbstractFloat", "AbstractIrrational", "AbstractMatrix", "AbstractRange", "AbstractSet", "AbstractString", "AbstractUnitRange", "AbstractVecOrMat", "AbstractVector", "Any", "ArgumentError", "Array", "AssertionError", "BigFloat", "BigInt", "BitArray", "BitMatrix", "BitSet", "BitVector", "Bool", "BoundsError", "CapturedException", "CartesianIndex", "CartesianIndices", "Cchar", "Cdouble", "Cfloat", "Channel", "Char", "Cint", "Cintmax_t", "Clong", "Clonglong", "Cmd", "Colon", "Complex", "ComplexF16", "ComplexF32", "ComplexF64", "CompositeException", "Condition", "Cptrdiff_t", "Cshort", "Csize_t", "Cssize_t", "Cstring", "Cuchar", "Cuint", "Cuintmax_t", "Culong", "Culonglong", "Cushort", "Cvoid", "Cwchar_t", "Cwstring", "DataType", "DenseArray", "DenseMatrix", "DenseVecOrMat", "DenseVector", "Dict", "DimensionMismatch", "Dims", "DivideError", "DomainError", "EOFError", "Enum", "ErrorException", "Exception", "ExponentialBackOff", "Expr", "Float16", "Float32", "Float64", "Function", "GlobalRef", "HTML", "IO", "IOBuffer", "IOContext", "IOStream", "IdDict", "IndexCartesian", "IndexLinear", "IndexStyle", "InexactError", "InitError", "Int", "Int128", "Int16", "Int32", "Int64", "Int8", "Integer", "InterruptException", "InvalidStateException", "Irrational", "KeyError", "LinRange", "LineNumberNode", "LinearIndices", "LoadError", "MIME", "Matrix", "Method", "MethodError", "Missing", "MissingException", "Module", "NTuple", "NamedTuple", "Nothing", "Number", "OrdinalRange", "OutOfMemoryError", "OverflowError", "Pair", "PartialQuickSort", "PermutedDimsArray", "Pipe", "ProcessFailedException", "Ptr", "QuoteNode", "Rational", "RawFD", "ReadOnlyMemoryError", "Real", "ReentrantLock", "Ref", "Regex", "RegexMatch", "RoundingMode", "SegmentationFault", "Set", "Signed", "Some", "StackOverflowError", "StepRange", "StepRangeLen", "StridedArray", "StridedMatrix", "StridedVecOrMat", "StridedVector", "String", "StringIndexError", "SubArray", "SubString", "SubstitutionString", "Symbol", "SystemError", "Task", "TaskFailedException", "Text", "TextDisplay", "Timer", "Tuple", "Type", "TypeError", "TypeVar", "UInt", "UInt128", "UInt16", "UInt32", "UInt64", "UInt8", "UndefInitializer", "UndefKeywordError", "UndefRefError", "UndefVarError", "Union", "UnionAll", "UnitRange", "Unsigned", "Val", "Vararg", "VecElement", "VecOrMat", "Vector", "VersionNumber", "WeakKeyDict", "WeakRef"]
                                    },
                                    t = {
                                        keywords: n,
                                        illegal: /<\//
                                    },
                                    a = {
                                        className: "subst",
                                        begin: /\$\(/,
                                        end: /\)/,
                                        keywords: n
                                    },
                                    r = {
                                        className: "variable",
                                        begin: "\\$" + u
                                    },
                                    i = {
                                        className: "string",
                                        contains: [e.BACKSLASH_ESCAPE, a, r],
                                        variants: [{
                                            begin: /\w*"""/,
                                            end: /"""\w*/,
                                            relevance: 10
                                        }, {
                                            begin: /\w*"/,
                                            end: /"\w*/
                                        }]
                                    },
                                    D = {
                                        className: "string",
                                        contains: [e.BACKSLASH_ESCAPE, a, r],
                                        begin: "`",
                                        end: "`"
                                    },
                                    s = {
                                        className: "meta",
                                        begin: "@" + u
                                    };
                                return t.name = "Julia", t.contains = [{
                                    className: "number",
                                    begin: /(\b0x[\d_]*(\.[\d_]*)?|0x\.\d[\d_]*)p[-+]?\d+|\b0[box][a-fA-F0-9][a-fA-F0-9_]*|(\b\d[\d_]*(\.[\d_]*)?|\.\d[\d_]*)([eEfF][-+]?\d+)?/,
                                    relevance: 0
                                }, {
                                    className: "string",
                                    begin: /'(.|\\[xXuU][a-zA-Z0-9]+)'/
                                }, i, D, s, {
                                    className: "comment",
                                    variants: [{
                                        begin: "#=",
                                        end: "=#",
                                        relevance: 10
                                    }, {
                                        begin: "#",
                                        end: "$"
                                    }]
                                }, e.HASH_COMMENT_MODE, {
                                    className: "keyword",
                                    begin: "\\b(((abstract|primitive)\\s+)type|(mutable\\s+)?struct)\\b"
                                }, {
                                    begin: /<:/
                                }], a.contains = t.contains, t
                            },
                            grmr_kotlin: function(e) {
                                var u = {
                                        keyword: "abstract as val var vararg get set class object open private protected public noinline crossinline dynamic final enum if else do while for when throw try catch finally import package is in fun override companion reified inline lateinit init interface annotation data sealed internal infix operator out by constructor super tailrec where const inner suspend typealias external expect actual",
                                        built_in: "Byte Short Char Int Long Boolean Float Double Void Unit Nothing",
                                        literal: "true false null"
                                    },
                                    n = {
                                        className: "symbol",
                                        begin: e.UNDERSCORE_IDENT_RE + "@"
                                    },
                                    t = {
                                        className: "subst",
                                        begin: /\$\{/,
                                        end: /\}/,
                                        contains: [e.C_NUMBER_MODE]
                                    },
                                    a = {
                                        className: "variable",
                                        begin: "\\$" + e.UNDERSCORE_IDENT_RE
                                    },
                                    r = {
                                        className: "string",
                                        variants: [{
                                            begin: '"""',
                                            end: '"""(?=[^"])',
                                            contains: [a, t]
                                        }, {
                                            begin: "'",
                                            end: "'",
                                            illegal: /\n/,
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: '"',
                                            end: '"',
                                            illegal: /\n/,
                                            contains: [e.BACKSLASH_ESCAPE, a, t]
                                        }]
                                    };
                                t.contains.push(r);
                                var i = {
                                        className: "meta",
                                        begin: "@(?:file|property|field|get|set|receiver|param|setparam|delegate)\\s*:(?:\\s*" + e.UNDERSCORE_IDENT_RE + ")?"
                                    },
                                    D = {
                                        className: "meta",
                                        begin: "@" + e.UNDERSCORE_IDENT_RE,
                                        contains: [{
                                            begin: /\(/,
                                            end: /\)/,
                                            contains: [e.inherit(r, {
                                                className: "string"
                                            }), "self"]
                                        }]
                                    },
                                    s = Ie,
                                    o = e.COMMENT("/\\*", "\\*/", {
                                        contains: [e.C_BLOCK_COMMENT_MODE]
                                    }),
                                    c = {
                                        variants: [{
                                            className: "type",
                                            begin: e.UNDERSCORE_IDENT_RE
                                        }, {
                                            begin: /\(/,
                                            end: /\)/,
                                            contains: []
                                        }]
                                    },
                                    l = c;
                                return l.variants[1].contains = [c], c.variants[1].contains = [l], {
                                    name: "Kotlin",
                                    aliases: ["kt", "kts"],
                                    keywords: u,
                                    contains: [e.COMMENT("/\\*\\*", "\\*/", {
                                        relevance: 0,
                                        contains: [{
                                            className: "doctag",
                                            begin: "@[A-Za-z]+"
                                        }]
                                    }), e.C_LINE_COMMENT_MODE, o, {
                                        className: "keyword",
                                        begin: /\b(break|continue|return|this)\b/,
                                        starts: {
                                            contains: [{
                                                className: "symbol",
                                                begin: /@\w+/
                                            }]
                                        }
                                    }, n, i, D, {
                                        className: "function",
                                        beginKeywords: "fun",
                                        end: "[(]|$",
                                        returnBegin: !0,
                                        excludeEnd: !0,
                                        keywords: u,
                                        relevance: 5,
                                        contains: [{
                                            begin: e.UNDERSCORE_IDENT_RE + "\\s*\\(",
                                            returnBegin: !0,
                                            relevance: 0,
                                            contains: [e.UNDERSCORE_TITLE_MODE]
                                        }, {
                                            className: "type",
                                            begin: /</,
                                            end: />/,
                                            keywords: "reified",
                                            relevance: 0
                                        }, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            endsParent: !0,
                                            keywords: u,
                                            relevance: 0,
                                            contains: [{
                                                begin: /:/,
                                                end: /[=,\/]/,
                                                endsWithParent: !0,
                                                contains: [c, e.C_LINE_COMMENT_MODE, o],
                                                relevance: 0
                                            }, e.C_LINE_COMMENT_MODE, o, i, D, r, e.C_NUMBER_MODE]
                                        }, o]
                                    }, {
                                        begin: [/class|interface|trait/, /\s+/, e.UNDERSCORE_IDENT_RE],
                                        beginScope: {
                                            3: "title.class"
                                        },
                                        keywords: "class interface trait",
                                        end: /[:\{(]|$/,
                                        excludeEnd: !0,
                                        illegal: "extends implements",
                                        contains: [{
                                            beginKeywords: "public protected internal private constructor"
                                        }, e.UNDERSCORE_TITLE_MODE, {
                                            className: "type",
                                            begin: /</,
                                            end: />/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            relevance: 0
                                        }, {
                                            className: "type",
                                            begin: /[,:]\s*/,
                                            end: /[<\(,){\s]|$/,
                                            excludeBegin: !0,
                                            returnEnd: !0
                                        }, i, D]
                                    }, r, {
                                        className: "meta",
                                        begin: "^#!/usr/bin/env",
                                        end: "$",
                                        illegal: "\n"
                                    }, s]
                                }
                            },
                            grmr_latex: function(e) {
                                var u, n = e.regex,
                                    t = [{
                                        begin: /\^{6}[0-9a-f]{6}/
                                    }, {
                                        begin: /\^{5}[0-9a-f]{5}/
                                    }, {
                                        begin: /\^{4}[0-9a-f]{4}/
                                    }, {
                                        begin: /\^{3}[0-9a-f]{3}/
                                    }, {
                                        begin: /\^{2}[0-9a-f]{2}/
                                    }, {
                                        begin: /\^{2}[\u0000-\u007f]/
                                    }],
                                    a = [{
                                        className: "keyword",
                                        begin: /\\/,
                                        relevance: 0,
                                        contains: [{
                                            endsParent: !0,
                                            begin: n.either.apply(n, o(["(?:NeedsTeXFormat|RequirePackage|GetIdInfo)", "Provides(?:Expl)?(?:Package|Class|File)", "(?:DeclareOption|ProcessOptions)", "(?:documentclass|usepackage|input|include)", "makeat(?:letter|other)", "ExplSyntax(?:On|Off)", "(?:new|renew|provide)?command", "(?:re)newenvironment", "(?:New|Renew|Provide|Declare)(?:Expandable)?DocumentCommand", "(?:New|Renew|Provide|Declare)DocumentEnvironment", "(?:(?:e|g|x)?def|let)", "(?:begin|end)", "(?:part|chapter|(?:sub){0,2}section|(?:sub)?paragraph)", "caption", "(?:label|(?:eq|page|name)?ref|(?:paren|foot|super)?cite)", "(?:alpha|beta|[Gg]amma|[Dd]elta|(?:var)?epsilon|zeta|eta|[Tt]heta|vartheta)", "(?:iota|(?:var)?kappa|[Ll]ambda|mu|nu|[Xx]i|[Pp]i|varpi|(?:var)rho)", "(?:[Ss]igma|varsigma|tau|[Uu]psilon|[Pp]hi|varphi|chi|[Pp]si|[Oo]mega)", "(?:frac|sum|prod|lim|infty|times|sqrt|leq|geq|left|right|middle|[bB]igg?)", "(?:[lr]angle|q?quad|[lcvdi]?dots|d?dot|hat|tilde|bar)"].map((function(e) {
                                                return e + "(?![a-zA-Z@:_])"
                                            }))))
                                        }, {
                                            endsParent: !0,
                                            begin: new RegExp(["(?:__)?[a-zA-Z]{2,}_[a-zA-Z](?:_?[a-zA-Z])+:[a-zA-Z]*", "[lgc]__?[a-zA-Z](?:_?[a-zA-Z])*_[a-zA-Z]{2,}", "[qs]__?[a-zA-Z](?:_?[a-zA-Z])+", "use(?:_i)?:[a-zA-Z]*", "(?:else|fi|or):", "(?:if|cs|exp):w", "(?:hbox|vbox):n", "::[a-zA-Z]_unbraced", "::[a-zA-Z:]"].map((function(e) {
                                                return e + "(?![a-zA-Z:_])"
                                            })).join("|"))
                                        }, {
                                            endsParent: !0,
                                            variants: t
                                        }, {
                                            endsParent: !0,
                                            relevance: 0,
                                            variants: [{
                                                begin: /[a-zA-Z@]+/
                                            }, {
                                                begin: /[^a-zA-Z@]?/
                                            }]
                                        }]
                                    }, {
                                        className: "params",
                                        relevance: 0,
                                        begin: /#+\d?/
                                    }, {
                                        variants: t
                                    }, {
                                        className: "built_in",
                                        relevance: 0,
                                        begin: /[$&^_]/
                                    }, {
                                        className: "meta",
                                        begin: /% ?!(T[eE]X|tex|BIB|bib)/,
                                        end: "$",
                                        relevance: 10
                                    }, e.COMMENT("%", "$", {
                                        relevance: 0
                                    })],
                                    r = {
                                        begin: /\{/,
                                        end: /\}/,
                                        relevance: 0,
                                        contains: ["self"].concat(a)
                                    },
                                    i = e.inherit(r, {
                                        relevance: 0,
                                        endsParent: !0,
                                        contains: [r].concat(a)
                                    }),
                                    D = {
                                        begin: /\[/,
                                        end: /\]/,
                                        endsParent: !0,
                                        relevance: 0,
                                        contains: [r].concat(a)
                                    },
                                    s = {
                                        begin: /\s+/,
                                        relevance: 0
                                    },
                                    c = [i],
                                    l = [D],
                                    d = function(e, u) {
                                        return {
                                            contains: [s],
                                            starts: {
                                                relevance: 0,
                                                contains: e,
                                                starts: u
                                            }
                                        }
                                    },
                                    E = function(e, u) {
                                        return {
                                            begin: "\\\\" + e + "(?![a-zA-Z@:_])",
                                            keywords: {
                                                $pattern: /\\[a-zA-Z]+/,
                                                keyword: "\\" + e
                                            },
                                            relevance: 0,
                                            contains: [s],
                                            starts: u
                                        }
                                    },
                                    F = function(u, n) {
                                        return e.inherit({
                                            begin: "\\\\begin(?=[ \t]*(\\r?\\n[ \t]*)?\\{" + u + "\\})",
                                            keywords: {
                                                $pattern: /\\[a-zA-Z]+/,
                                                keyword: "\\begin"
                                            },
                                            relevance: 0
                                        }, d(c, n))
                                    },
                                    A = function() {
                                        var u = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "string";
                                        return e.END_SAME_AS_BEGIN({
                                            className: u,
                                            begin: /(.|\r?\n)/,
                                            end: /(.|\r?\n)/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            endsParent: !0
                                        })
                                    },
                                    C = function(e) {
                                        return {
                                            className: "string",
                                            end: "(?=\\\\end\\{" + e + "\\})"
                                        }
                                    },
                                    g = function() {
                                        return {
                                            relevance: 0,
                                            begin: /\{/,
                                            starts: {
                                                endsParent: !0,
                                                contains: [{
                                                    className: arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "string",
                                                    end: /(?=\})/,
                                                    endsParent: !0,
                                                    contains: [{
                                                        begin: /\{/,
                                                        end: /\}/,
                                                        relevance: 0,
                                                        contains: ["self"]
                                                    }]
                                                }]
                                            }
                                        }
                                    },
                                    b = [].concat(o(["verb", "lstinline"].map((function(e) {
                                        return E(e, {
                                            contains: [A()]
                                        })
                                    }))), [E("mint", d(c, {
                                        contains: [A()]
                                    })), E("mintinline", d(c, {
                                        contains: [g(), A()]
                                    })), E("url", {
                                        contains: [g("link"), g("link")]
                                    }), E("hyperref", {
                                        contains: [g("link")]
                                    }), E("href", d(l, {
                                        contains: [g("link")]
                                    }))], o((u = []).concat.apply(u, o(["", "\\*"].map((function(e) {
                                        return [F("verbatim" + e, C("verbatim" + e)), F("filecontents" + e, d(c, C("filecontents" + e)))].concat(o(["", "B", "L"].map((function(u) {
                                            return F(u + "Verbatim" + e, d(l, C(u + "Verbatim" + e)))
                                        }))))
                                    }))))), [F("minted", d(l, d(c, C("minted"))))]);
                                return {
                                    name: "LaTeX",
                                    aliases: ["tex"],
                                    contains: [].concat(o(b), a)
                                }
                            },
                            grmr_less: function(e) {
                                var u = be(e),
                                    n = _e,
                                    t = "[\\w-]+",
                                    a = "(" + t + "|@\\{" + t + "\\})",
                                    r = [],
                                    i = [],
                                    D = function(e) {
                                        return {
                                            className: "string",
                                            begin: "~?" + e + ".*?" + e
                                        }
                                    },
                                    s = function(e, u, n) {
                                        return {
                                            className: e,
                                            begin: u,
                                            relevance: n
                                        }
                                    },
                                    o = {
                                        $pattern: /[a-z-]+/,
                                        keyword: "and or not only",
                                        attribute: pe.join(" ")
                                    },
                                    c = {
                                        begin: "\\(",
                                        end: "\\)",
                                        contains: i,
                                        keywords: o,
                                        relevance: 0
                                    };
                                i.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, D("'"), D('"'), u.CSS_NUMBER_MODE, {
                                    begin: "(url|data-uri)\\(",
                                    starts: {
                                        className: "string",
                                        end: "[\\)\\n]",
                                        excludeEnd: !0
                                    }
                                }, u.HEXCOLOR, c, s("variable", "@@?" + t, 10), s("variable", "@\\{" + t + "\\}"), s("built_in", "~?`[^`]*?`"), {
                                    className: "attribute",
                                    begin: t + "\\s*:",
                                    end: ":",
                                    returnBegin: !0,
                                    excludeEnd: !0
                                }, u.IMPORTANT, {
                                    beginKeywords: "and not"
                                }, u.FUNCTION_DISPATCH);
                                var l = i.concat({
                                        begin: /\{/,
                                        end: /\}/,
                                        contains: r
                                    }),
                                    d = {
                                        beginKeywords: "when",
                                        endsWithParent: !0,
                                        contains: [{
                                            beginKeywords: "and not"
                                        }].concat(i)
                                    },
                                    E = {
                                        begin: a + "\\s*:",
                                        returnBegin: !0,
                                        end: /[;}]/,
                                        relevance: 0,
                                        contains: [{
                                            begin: /-(webkit|moz|ms|o)-/
                                        }, u.CSS_VARIABLE, {
                                            className: "attribute",
                                            begin: "\\b(" + he.join("|") + ")\\b",
                                            end: /(?=:)/,
                                            starts: {
                                                endsWithParent: !0,
                                                illegal: "[<=$]",
                                                relevance: 0,
                                                contains: i
                                            }
                                        }]
                                    },
                                    F = {
                                        className: "keyword",
                                        begin: "@(import|media|charset|font-face|(-[a-z]+-)?keyframes|supports|document|namespace|page|viewport|host)\\b",
                                        starts: {
                                            end: "[;{}]",
                                            keywords: o,
                                            returnEnd: !0,
                                            contains: i,
                                            relevance: 0
                                        }
                                    },
                                    A = {
                                        className: "variable",
                                        variants: [{
                                            begin: "@" + t + "\\s*:",
                                            relevance: 15
                                        }, {
                                            begin: "@" + t
                                        }],
                                        starts: {
                                            end: "[;}]",
                                            returnEnd: !0,
                                            contains: l
                                        }
                                    },
                                    C = {
                                        variants: [{
                                            begin: "[\\.#:&\\[>]",
                                            end: "[;{}]"
                                        }, {
                                            begin: a,
                                            end: /\{/
                                        }],
                                        returnBegin: !0,
                                        returnEnd: !0,
                                        illegal: "[<='$\"]",
                                        relevance: 0,
                                        contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, d, s("keyword", "all\\b"), s("variable", "@\\{" + t + "\\}"), {
                                            begin: "\\b(" + me.join("|") + ")\\b",
                                            className: "selector-tag"
                                        }, u.CSS_NUMBER_MODE, s("selector-tag", a, 0), s("selector-id", "#" + a), s("selector-class", "\\." + a, 0), s("selector-tag", "&", 0), u.ATTRIBUTE_SELECTOR_MODE, {
                                            className: "selector-pseudo",
                                            begin: ":(" + fe.join("|") + ")"
                                        }, {
                                            className: "selector-pseudo",
                                            begin: ":(:)?(" + Be.join("|") + ")"
                                        }, {
                                            begin: /\(/,
                                            end: /\)/,
                                            relevance: 0,
                                            contains: l
                                        }, {
                                            begin: "!important"
                                        }, u.FUNCTION_DISPATCH]
                                    },
                                    g = {
                                        begin: t + ":(:)?" + "(".concat(n.join("|"), ")"),
                                        returnBegin: !0,
                                        contains: [C]
                                    };
                                return r.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, F, A, g, E, C, d, u.FUNCTION_DISPATCH), {
                                    name: "Less",
                                    case_insensitive: !0,
                                    illegal: "[=>'/<($\"]",
                                    contains: r
                                }
                            },
                            grmr_lisp: function(e) {
                                var u = "[a-zA-Z_\\-+\\*\\/<=>&#][a-zA-Z0-9_\\-+*\\/<=>&#!]*",
                                    n = "\\|[^]*?\\|",
                                    t = "(-|\\+)?\\d+(\\.\\d+|\\/\\d+)?((d|e|f|l|s|D|E|F|L|S)(\\+|-)?\\d+)?",
                                    a = {
                                        className: "literal",
                                        begin: "\\b(t{1}|nil)\\b"
                                    },
                                    r = {
                                        className: "number",
                                        variants: [{
                                            begin: t,
                                            relevance: 0
                                        }, {
                                            begin: "#(b|B)[0-1]+(/[0-1]+)?"
                                        }, {
                                            begin: "#(o|O)[0-7]+(/[0-7]+)?"
                                        }, {
                                            begin: "#(x|X)[0-9a-fA-F]+(/[0-9a-fA-F]+)?"
                                        }, {
                                            begin: "#(c|C)\\(" + t + " +" + t,
                                            end: "\\)"
                                        }]
                                    },
                                    i = e.inherit(e.QUOTE_STRING_MODE, {
                                        illegal: null
                                    }),
                                    D = e.COMMENT(";", "$", {
                                        relevance: 0
                                    }),
                                    s = {
                                        begin: "\\*",
                                        end: "\\*"
                                    },
                                    o = {
                                        className: "symbol",
                                        begin: "[:&]" + u
                                    },
                                    c = {
                                        begin: u,
                                        relevance: 0
                                    },
                                    l = {
                                        begin: n
                                    },
                                    d = {
                                        contains: [r, i, s, o, {
                                            begin: "\\(",
                                            end: "\\)",
                                            contains: ["self", a, i, r, c]
                                        }, c],
                                        variants: [{
                                            begin: "['`]\\(",
                                            end: "\\)"
                                        }, {
                                            begin: "\\(quote ",
                                            end: "\\)",
                                            keywords: {
                                                name: "quote"
                                            }
                                        }, {
                                            begin: "'" + n
                                        }]
                                    },
                                    E = {
                                        variants: [{
                                            begin: "'" + u
                                        }, {
                                            begin: "#'" + u + "(::" + u + ")*"
                                        }]
                                    },
                                    F = {
                                        begin: "\\(\\s*",
                                        end: "\\)"
                                    },
                                    A = {
                                        endsWithParent: !0,
                                        relevance: 0
                                    };
                                return F.contains = [{
                                    className: "name",
                                    variants: [{
                                        begin: u,
                                        relevance: 0
                                    }, {
                                        begin: n
                                    }]
                                }, A], A.contains = [d, E, F, a, r, i, D, s, o, l, c], {
                                    name: "Lisp",
                                    illegal: /\S/,
                                    contains: [r, e.SHEBANG(), a, i, D, d, E, F, c]
                                }
                            },
                            grmr_lua: function(e) {
                                var u = "\\[=*\\[",
                                    n = "\\]=*\\]",
                                    t = {
                                        begin: u,
                                        end: n,
                                        contains: ["self"]
                                    },
                                    a = [e.COMMENT("--(?!" + u + ")", "$"), e.COMMENT("--" + u, n, {
                                        contains: [t],
                                        relevance: 10
                                    })];
                                return {
                                    name: "Lua",
                                    keywords: {
                                        $pattern: e.UNDERSCORE_IDENT_RE,
                                        literal: "true false nil",
                                        keyword: "and break do else elseif end for goto if in local not or repeat return then until while",
                                        built_in: "_G _ENV _VERSION __index __newindex __mode __call __metatable __tostring __len __gc __add __sub __mul __div __mod __pow __concat __unm __eq __lt __le assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring type unpack xpcall arg self coroutine resume yield status wrap create running debug getupvalue debug sethook getmetatable gethook setmetatable setlocal traceback setfenv getinfo setupvalue getlocal getregistry getfenv io lines write close flush open output type read stderr stdin input stdout popen tmpfile math log max acos huge ldexp pi cos tanh pow deg tan cosh sinh random randomseed frexp ceil floor rad abs sqrt modf asin min mod fmod log10 atan2 exp sin atan os exit setlocale date getenv difftime remove time clock tmpname rename execute package preload loadlib loaded loaders cpath config path seeall string sub upper len gfind rep find match char dump gmatch reverse byte format gsub lower table setn insert getn foreachi maxn foreach concat sort remove"
                                    },
                                    contains: a.concat([{
                                        className: "function",
                                        beginKeywords: "function",
                                        end: "\\)",
                                        contains: [e.inherit(e.TITLE_MODE, {
                                            begin: "([_a-zA-Z]\\w*\\.)*([_a-zA-Z]\\w*:)?[_a-zA-Z]\\w*"
                                        }), {
                                            className: "params",
                                            begin: "\\(",
                                            endsWithParent: !0,
                                            contains: a
                                        }].concat(a)
                                    }, e.C_NUMBER_MODE, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, {
                                        className: "string",
                                        begin: u,
                                        end: n,
                                        contains: [t],
                                        relevance: 5
                                    }])
                                }
                            },
                            grmr_makefile: function(e) {
                                var u = {
                                        className: "variable",
                                        variants: [{
                                            begin: "\\$\\(" + e.UNDERSCORE_IDENT_RE + "\\)",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: /\$[@%<?\^\+\*]/
                                        }]
                                    },
                                    n = {
                                        className: "string",
                                        begin: /"/,
                                        end: /"/,
                                        contains: [e.BACKSLASH_ESCAPE, u]
                                    },
                                    t = {
                                        className: "variable",
                                        begin: /\$\([\w-]+\s/,
                                        end: /\)/,
                                        keywords: {
                                            built_in: "subst patsubst strip findstring filter filter-out sort word wordlist firstword lastword dir notdir suffix basename addsuffix addprefix join wildcard realpath abspath error warning shell origin flavor foreach if or and call eval file value"
                                        },
                                        contains: [u]
                                    },
                                    a = {
                                        begin: "^" + e.UNDERSCORE_IDENT_RE + "\\s*(?=[:+?]?=)"
                                    },
                                    r = {
                                        className: "section",
                                        begin: /^[^\s]+:/,
                                        end: /$/,
                                        contains: [u]
                                    };
                                return {
                                    name: "Makefile",
                                    aliases: ["mk", "mak", "make"],
                                    keywords: {
                                        $pattern: /[\w-]+/,
                                        keyword: "define endef undefine ifdef ifndef ifeq ifneq else endif include -include sinclude override export unexport private vpath"
                                    },
                                    contains: [e.HASH_COMMENT_MODE, u, n, t, a, {
                                        className: "meta",
                                        begin: /^\.PHONY:/,
                                        end: /$/,
                                        keywords: {
                                            $pattern: /[\.\w]+/,
                                            keyword: ".PHONY"
                                        }
                                    }, r]
                                }
                            },
                            grmr_markdown: function(e) {
                                var u = {
                                        begin: /<\/?[A-Za-z_]/,
                                        end: ">",
                                        subLanguage: "xml",
                                        relevance: 0
                                    },
                                    n = {
                                        variants: [{
                                            begin: /\[.+?\]\[.*?\]/,
                                            relevance: 0
                                        }, {
                                            begin: /\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,
                                            relevance: 2
                                        }, {
                                            begin: e.regex.concat(/\[.+?\]\(/, /[A-Za-z][A-Za-z0-9+.-]*/, /:\/\/.*?\)/),
                                            relevance: 2
                                        }, {
                                            begin: /\[.+?\]\([./?&#].*?\)/,
                                            relevance: 1
                                        }, {
                                            begin: /\[.*?\]\(.*?\)/,
                                            relevance: 0
                                        }],
                                        returnBegin: !0,
                                        contains: [{
                                            match: /\[(?=\])/
                                        }, {
                                            className: "string",
                                            relevance: 0,
                                            begin: "\\[",
                                            end: "\\]",
                                            excludeBegin: !0,
                                            returnEnd: !0
                                        }, {
                                            className: "link",
                                            relevance: 0,
                                            begin: "\\]\\(",
                                            end: "\\)",
                                            excludeBegin: !0,
                                            excludeEnd: !0
                                        }, {
                                            className: "symbol",
                                            relevance: 0,
                                            begin: "\\]\\[",
                                            end: "\\]",
                                            excludeBegin: !0,
                                            excludeEnd: !0
                                        }]
                                    },
                                    t = {
                                        className: "strong",
                                        contains: [],
                                        variants: [{
                                            begin: /_{2}(?!\s)/,
                                            end: /_{2}/
                                        }, {
                                            begin: /\*{2}(?!\s)/,
                                            end: /\*{2}/
                                        }]
                                    },
                                    a = {
                                        className: "emphasis",
                                        contains: [],
                                        variants: [{
                                            begin: /\*(?![*\s])/,
                                            end: /\*/
                                        }, {
                                            begin: /_(?![_\s])/,
                                            end: /_/,
                                            relevance: 0
                                        }]
                                    },
                                    r = e.inherit(t, {
                                        contains: []
                                    }),
                                    i = e.inherit(a, {
                                        contains: []
                                    });
                                t.contains.push(i), a.contains.push(r);
                                var D = [u, n];
                                return [t, a, r, i].forEach((function(e) {
                                    e.contains = e.contains.concat(D)
                                })), {
                                    name: "Markdown",
                                    aliases: ["md", "mkdown", "mkd"],
                                    contains: [{
                                        className: "section",
                                        variants: [{
                                            begin: "^#{1,6}",
                                            end: "$",
                                            contains: D = D.concat(t, a)
                                        }, {
                                            begin: "(?=^.+?\\n[=-]{2,}$)",
                                            contains: [{
                                                begin: "^[=-]*$"
                                            }, {
                                                begin: "^",
                                                end: "\\n",
                                                contains: D
                                            }]
                                        }]
                                    }, u, {
                                        className: "bullet",
                                        begin: "^[ \t]*([*+-]|(\\d+\\.))(?=\\s+)",
                                        end: "\\s+",
                                        excludeEnd: !0
                                    }, t, a, {
                                        className: "quote",
                                        begin: "^>\\s+",
                                        contains: D,
                                        end: "$"
                                    }, {
                                        className: "code",
                                        variants: [{
                                            begin: "(`{3,})[^`](.|\\n)*?\\1`*[ ]*"
                                        }, {
                                            begin: "(~{3,})[^~](.|\\n)*?\\1~*[ ]*"
                                        }, {
                                            begin: "```",
                                            end: "```+[ ]*$"
                                        }, {
                                            begin: "~~~",
                                            end: "~~~+[ ]*$"
                                        }, {
                                            begin: "`.+?`"
                                        }, {
                                            begin: "(?=^( {4}|\\t))",
                                            contains: [{
                                                begin: "^( {4}|\\t)",
                                                end: "(\\n)$"
                                            }],
                                            relevance: 0
                                        }]
                                    }, {
                                        begin: "^[-\\*]{3,}",
                                        end: "$"
                                    }, n, {
                                        begin: /^\[[^\n]+\]:/,
                                        returnBegin: !0,
                                        contains: [{
                                            className: "symbol",
                                            begin: /\[/,
                                            end: /\]/,
                                            excludeBegin: !0,
                                            excludeEnd: !0
                                        }, {
                                            className: "link",
                                            begin: /:\s*/,
                                            end: /$/,
                                            excludeBegin: !0
                                        }]
                                    }]
                                }
                            },
                            grmr_matlab: function(e) {
                                var u = "('|\\.')+",
                                    n = {
                                        relevance: 0,
                                        contains: [{
                                            begin: u
                                        }]
                                    };
                                return {
                                    name: "Matlab",
                                    keywords: {
                                        keyword: "arguments break case catch classdef continue else elseif end enumeration events for function global if methods otherwise parfor persistent properties return spmd switch try while",
                                        built_in: "sin sind sinh asin asind asinh cos cosd cosh acos acosd acosh tan tand tanh atan atand atan2 atanh sec secd sech asec asecd asech csc cscd csch acsc acscd acsch cot cotd coth acot acotd acoth hypot exp expm1 log log1p log10 log2 pow2 realpow reallog realsqrt sqrt nthroot nextpow2 abs angle complex conj imag real unwrap isreal cplxpair fix floor ceil round mod rem sign airy besselj bessely besselh besseli besselk beta betainc betaln ellipj ellipke erf erfc erfcx erfinv expint gamma gammainc gammaln psi legendre cross dot factor isprime primes gcd lcm rat rats perms nchoosek factorial cart2sph cart2pol pol2cart sph2cart hsv2rgb rgb2hsv zeros ones eye repmat rand randn linspace logspace freqspace meshgrid accumarray size length ndims numel disp isempty isequal isequalwithequalnans cat reshape diag blkdiag tril triu fliplr flipud flipdim rot90 find sub2ind ind2sub bsxfun ndgrid permute ipermute shiftdim circshift squeeze isscalar isvector ans eps realmax realmin pi i|0 inf nan isnan isinf isfinite j|0 why compan gallery hadamard hankel hilb invhilb magic pascal rosser toeplitz vander wilkinson max min nanmax nanmin mean nanmean type table readtable writetable sortrows sort figure plot plot3 scatter scatter3 cellfun legend intersect ismember procrustes hold num2cell "
                                    },
                                    illegal: '(//|"|#|/\\*|\\s+/\\w+)',
                                    contains: [{
                                        className: "function",
                                        beginKeywords: "function",
                                        end: "$",
                                        contains: [e.UNDERSCORE_TITLE_MODE, {
                                            className: "params",
                                            variants: [{
                                                begin: "\\(",
                                                end: "\\)"
                                            }, {
                                                begin: "\\[",
                                                end: "\\]"
                                            }]
                                        }]
                                    }, {
                                        className: "built_in",
                                        begin: /true|false/,
                                        relevance: 0,
                                        starts: n
                                    }, {
                                        begin: "[a-zA-Z][a-zA-Z_0-9]*" + u,
                                        relevance: 0
                                    }, {
                                        className: "number",
                                        begin: e.C_NUMBER_RE,
                                        relevance: 0,
                                        starts: n
                                    }, {
                                        className: "string",
                                        begin: "'",
                                        end: "'",
                                        contains: [{
                                            begin: "''"
                                        }]
                                    }, {
                                        begin: /\]|\}|\)/,
                                        relevance: 0,
                                        starts: n
                                    }, {
                                        className: "string",
                                        begin: '"',
                                        end: '"',
                                        contains: [{
                                            begin: '""'
                                        }],
                                        starts: n
                                    }, e.COMMENT("^\\s*%\\{\\s*$", "^\\s*%\\}\\s*$"), e.COMMENT("%", "$")]
                                }
                            },
                            grmr_objectivec: function(e) {
                                var u = /[a-zA-Z@][a-zA-Z0-9_]*/,
                                    n = {
                                        $pattern: u,
                                        keyword: ["@interface", "@class", "@protocol", "@implementation"]
                                    };
                                return {
                                    name: "Objective-C",
                                    aliases: ["mm", "objc", "obj-c", "obj-c++", "objective-c++"],
                                    keywords: {
                                        "variable.language": ["this", "super"],
                                        $pattern: u,
                                        keyword: ["while", "export", "sizeof", "typedef", "const", "struct", "for", "union", "volatile", "static", "mutable", "if", "do", "return", "goto", "enum", "else", "break", "extern", "asm", "case", "default", "register", "explicit", "typename", "switch", "continue", "inline", "readonly", "assign", "readwrite", "self", "@synchronized", "id", "typeof", "nonatomic", "IBOutlet", "IBAction", "strong", "weak", "copy", "in", "out", "inout", "bycopy", "byref", "oneway", "__strong", "__weak", "__block", "__autoreleasing", "@private", "@protected", "@public", "@try", "@property", "@end", "@throw", "@catch", "@finally", "@autoreleasepool", "@synthesize", "@dynamic", "@selector", "@optional", "@required", "@encode", "@package", "@import", "@defs", "@compatibility_alias", "__bridge", "__bridge_transfer", "__bridge_retained", "__bridge_retain", "__covariant", "__contravariant", "__kindof", "_Nonnull", "_Nullable", "_Null_unspecified", "__FUNCTION__", "__PRETTY_FUNCTION__", "__attribute__", "getter", "setter", "retain", "unsafe_unretained", "nonnull", "nullable", "null_unspecified", "null_resettable", "class", "instancetype", "NS_DESIGNATED_INITIALIZER", "NS_UNAVAILABLE", "NS_REQUIRES_SUPER", "NS_RETURNS_INNER_POINTER", "NS_INLINE", "NS_AVAILABLE", "NS_DEPRECATED", "NS_ENUM", "NS_OPTIONS", "NS_SWIFT_UNAVAILABLE", "NS_ASSUME_NONNULL_BEGIN", "NS_ASSUME_NONNULL_END", "NS_REFINED_FOR_SWIFT", "NS_SWIFT_NAME", "NS_SWIFT_NOTHROW", "NS_DURING", "NS_HANDLER", "NS_ENDHANDLER", "NS_VALUERETURN", "NS_VOIDRETURN"],
                                        literal: ["false", "true", "FALSE", "TRUE", "nil", "YES", "NO", "NULL"],
                                        built_in: ["dispatch_once_t", "dispatch_queue_t", "dispatch_sync", "dispatch_async", "dispatch_once"],
                                        type: ["int", "float", "char", "unsigned", "signed", "short", "long", "double", "wchar_t", "unichar", "void", "bool", "BOOL", "id|0", "_Bool"]
                                    },
                                    illegal: "</",
                                    contains: [{
                                        className: "built_in",
                                        begin: "\\b(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)\\w+"
                                    }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, e.C_NUMBER_MODE, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, {
                                        className: "string",
                                        variants: [{
                                            begin: '@"',
                                            end: '"',
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }]
                                    }, {
                                        className: "meta",
                                        begin: /#\s*[a-z]+\b/,
                                        end: /$/,
                                        keywords: {
                                            keyword: "if else elif endif define undef warning error line pragma ifdef ifndef include"
                                        },
                                        contains: [{
                                            begin: /\\\n/,
                                            relevance: 0
                                        }, e.inherit(e.QUOTE_STRING_MODE, {
                                            className: "string"
                                        }), {
                                            className: "string",
                                            begin: /<.*?>/,
                                            end: /$/,
                                            illegal: "\\n"
                                        }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                    }, {
                                        className: "class",
                                        begin: "(" + n.keyword.join("|") + ")\\b",
                                        end: /(\{|$)/,
                                        excludeEnd: !0,
                                        keywords: n,
                                        contains: [e.UNDERSCORE_TITLE_MODE]
                                    }, {
                                        begin: "\\." + e.UNDERSCORE_IDENT_RE,
                                        relevance: 0
                                    }]
                                }
                            },
                            grmr_ocaml: function(e) {
                                return {
                                    name: "OCaml",
                                    aliases: ["ml"],
                                    keywords: {
                                        $pattern: "[a-z_]\\w*!?",
                                        keyword: "and as assert asr begin class constraint do done downto else end exception external for fun function functor if in include inherit! inherit initializer land lazy let lor lsl lsr lxor match method!|10 method mod module mutable new object of open! open or private rec sig struct then to try type val! val virtual when while with parser value",
                                        built_in: "array bool bytes char exn|5 float int int32 int64 list lazy_t|5 nativeint|5 string unit in_channel out_channel ref",
                                        literal: "true false"
                                    },
                                    illegal: /\/\/|>>/,
                                    contains: [{
                                        className: "literal",
                                        begin: "\\[(\\|\\|)?\\]|\\(\\)",
                                        relevance: 0
                                    }, e.COMMENT("\\(\\*", "\\*\\)", {
                                        contains: ["self"]
                                    }), {
                                        className: "symbol",
                                        begin: "'[A-Za-z_](?!')[\\w']*"
                                    }, {
                                        className: "type",
                                        begin: "`[A-Z][\\w']*"
                                    }, {
                                        className: "type",
                                        begin: "\\b[A-Z][\\w']*",
                                        relevance: 0
                                    }, {
                                        begin: "[a-z_]\\w*'[\\w']*",
                                        relevance: 0
                                    }, e.inherit(e.APOS_STRING_MODE, {
                                        className: "string",
                                        relevance: 0
                                    }), e.inherit(e.QUOTE_STRING_MODE, {
                                        illegal: null
                                    }), {
                                        className: "number",
                                        begin: "\\b(0[xX][a-fA-F0-9_]+[Lln]?|0[oO][0-7_]+[Lln]?|0[bB][01_]+[Lln]?|[0-9][0-9_]*([Lln]|(\\.[0-9_]*)?([eE][-+]?[0-9_]+)?)?)",
                                        relevance: 0
                                    }, {
                                        begin: /->/
                                    }]
                                }
                            },
                            grmr_perl: function(e) {
                                var u = e.regex,
                                    n = /[dualxmsipngr]{0,12}/,
                                    t = {
                                        $pattern: /[\w.]+/,
                                        keyword: ["abs", "accept", "alarm", "and", "atan2", "bind", "binmode", "bless", "break", "caller", "chdir", "chmod", "chomp", "chop", "chown", "chr", "chroot", "close", "closedir", "connect", "continue", "cos", "crypt", "dbmclose", "dbmopen", "defined", "delete", "die", "do", "dump", "each", "else", "elsif", "endgrent", "endhostent", "endnetent", "endprotoent", "endpwent", "endservent", "eof", "eval", "exec", "exists", "exit", "exp", "fcntl", "fileno", "flock", "for", "foreach", "fork", "format", "formline", "getc", "getgrent", "getgrgid", "getgrnam", "gethostbyaddr", "gethostbyname", "gethostent", "getlogin", "getnetbyaddr", "getnetbyname", "getnetent", "getpeername", "getpgrp", "getpriority", "getprotobyname", "getprotobynumber", "getprotoent", "getpwent", "getpwnam", "getpwuid", "getservbyname", "getservbyport", "getservent", "getsockname", "getsockopt", "given", "glob", "gmtime", "goto", "grep", "gt", "hex", "if", "index", "int", "ioctl", "join", "keys", "kill", "last", "lc", "lcfirst", "length", "link", "listen", "local", "localtime", "log", "lstat", "lt", "ma", "map", "mkdir", "msgctl", "msgget", "msgrcv", "msgsnd", "my", "ne", "next", "no", "not", "oct", "open", "opendir", "or", "ord", "our", "pack", "package", "pipe", "pop", "pos", "print", "printf", "prototype", "push", "q|0", "qq", "quotemeta", "qw", "qx", "rand", "read", "readdir", "readline", "readlink", "readpipe", "recv", "redo", "ref", "rename", "require", "reset", "return", "reverse", "rewinddir", "rindex", "rmdir", "say", "scalar", "seek", "seekdir", "select", "semctl", "semget", "semop", "send", "setgrent", "sethostent", "setnetent", "setpgrp", "setpriority", "setprotoent", "setpwent", "setservent", "setsockopt", "shift", "shmctl", "shmget", "shmread", "shmwrite", "shutdown", "sin", "sleep", "socket", "socketpair", "sort", "splice", "split", "sprintf", "sqrt", "srand", "stat", "state", "study", "sub", "substr", "symlink", "syscall", "sysopen", "sysread", "sysseek", "system", "syswrite", "tell", "telldir", "tie", "tied", "time", "times", "tr", "truncate", "uc", "ucfirst", "umask", "undef", "unless", "unlink", "unpack", "unshift", "untie", "until", "use", "utime", "values", "vec", "wait", "waitpid", "wantarray", "warn", "when", "while", "write", "x|0", "xor", "y|0"].join(" ")
                                    },
                                    a = {
                                        className: "subst",
                                        begin: "[$@]\\{",
                                        end: "\\}",
                                        keywords: t
                                    },
                                    r = {
                                        begin: /->\{/,
                                        end: /\}/
                                    },
                                    i = {
                                        variants: [{
                                            begin: /\$\d/
                                        }, {
                                            begin: u.concat(/[$%@](\^\w\b|#\w+(::\w+)*|\{\w+\}|\w+(::\w*)*)/, "(?![A-Za-z])(?![@$%])")
                                        }, {
                                            begin: /[$%@][^\s\w{]/,
                                            relevance: 0
                                        }]
                                    },
                                    D = [e.BACKSLASH_ESCAPE, a, i],
                                    s = [/!/, /\//, /\|/, /\?/, /'/, /"/, /#/],
                                    o = function(e, t) {
                                        var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "\\1",
                                            r = "\\1" === a ? a : u.concat(a, t);
                                        return u.concat(u.concat("(?:", e, ")"), t, /(?:\\.|[^\\\/])*?/, r, /(?:\\.|[^\\\/])*?/, a, n)
                                    },
                                    c = function(e, t, a) {
                                        return u.concat(u.concat("(?:", e, ")"), t, /(?:\\.|[^\\\/])*?/, a, n)
                                    },
                                    l = [i, e.HASH_COMMENT_MODE, e.COMMENT(/^=\w/, /=cut/, {
                                        endsWithParent: !0
                                    }), r, {
                                        className: "string",
                                        contains: D,
                                        variants: [{
                                            begin: "q[qwxr]?\\s*\\(",
                                            end: "\\)",
                                            relevance: 5
                                        }, {
                                            begin: "q[qwxr]?\\s*\\[",
                                            end: "\\]",
                                            relevance: 5
                                        }, {
                                            begin: "q[qwxr]?\\s*\\{",
                                            end: "\\}",
                                            relevance: 5
                                        }, {
                                            begin: "q[qwxr]?\\s*\\|",
                                            end: "\\|",
                                            relevance: 5
                                        }, {
                                            begin: "q[qwxr]?\\s*<",
                                            end: ">",
                                            relevance: 5
                                        }, {
                                            begin: "qw\\s+q",
                                            end: "q",
                                            relevance: 5
                                        }, {
                                            begin: "'",
                                            end: "'",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: '"',
                                            end: '"'
                                        }, {
                                            begin: "`",
                                            end: "`",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: /\{\w+\}/,
                                            relevance: 0
                                        }, {
                                            begin: "-?\\w+\\s*=>",
                                            relevance: 0
                                        }]
                                    }, {
                                        className: "number",
                                        begin: "(\\b0[0-7_]+)|(\\b0x[0-9a-fA-F_]+)|(\\b[1-9][0-9_]*(\\.[0-9_]+)?)|[0_]\\b",
                                        relevance: 0
                                    }, {
                                        begin: "(\\/\\/|" + e.RE_STARTERS_RE + "|\\b(split|return|print|reverse|grep)\\b)\\s*",
                                        keywords: "split return print reverse grep",
                                        relevance: 0,
                                        contains: [e.HASH_COMMENT_MODE, {
                                            className: "regexp",
                                            variants: [{
                                                begin: o("s|tr|y", u.either.apply(u, s.concat([{
                                                    capture: !0
                                                }])))
                                            }, {
                                                begin: o("s|tr|y", "\\(", "\\)")
                                            }, {
                                                begin: o("s|tr|y", "\\[", "\\]")
                                            }, {
                                                begin: o("s|tr|y", "\\{", "\\}")
                                            }],
                                            relevance: 2
                                        }, {
                                            className: "regexp",
                                            variants: [{
                                                begin: /(m|qr)\/\//,
                                                relevance: 0
                                            }, {
                                                begin: c("(?:m|qr)?", /\//, /\//)
                                            }, {
                                                begin: c("m|qr", u.either.apply(u, s.concat([{
                                                    capture: !0
                                                }])), /\1/)
                                            }, {
                                                begin: c("m|qr", /\(/, /\)/)
                                            }, {
                                                begin: c("m|qr", /\[/, /\]/)
                                            }, {
                                                begin: c("m|qr", /\{/, /\}/)
                                            }]
                                        }]
                                    }, {
                                        className: "function",
                                        beginKeywords: "sub",
                                        end: "(\\s*\\(.*?\\))?[;{]",
                                        excludeEnd: !0,
                                        relevance: 5,
                                        contains: [e.TITLE_MODE]
                                    }, {
                                        begin: "-\\w\\b",
                                        relevance: 0
                                    }, {
                                        begin: "^__DATA__$",
                                        end: "^__END__$",
                                        subLanguage: "mojolicious",
                                        contains: [{
                                            begin: "^@@.*",
                                            end: "$",
                                            className: "comment"
                                        }]
                                    }];
                                return a.contains = l, r.contains = l, {
                                    name: "Perl",
                                    aliases: ["pl", "pm"],
                                    keywords: t,
                                    contains: l
                                }
                            },
                            grmr_php: function(e) {
                                var u, n, t = e.regex,
                                    a = /(?![A-Za-z0-9])(?![$])/,
                                    r = t.concat(/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/, a),
                                    i = t.concat(/(\\?[A-Z][a-z0-9_\x7f-\xff]+|\\?[A-Z]+(?=[A-Z][a-z0-9_\x7f-\xff])){1,}/, a),
                                    D = {
                                        scope: "variable",
                                        match: "\\$+" + r
                                    },
                                    s = {
                                        scope: "subst",
                                        variants: [{
                                            begin: /\$\w+/
                                        }, {
                                            begin: /\{\$/,
                                            end: /\}/
                                        }]
                                    },
                                    o = e.inherit(e.APOS_STRING_MODE, {
                                        illegal: null
                                    }),
                                    c = "[ \t\n]",
                                    l = {
                                        scope: "string",
                                        variants: [e.inherit(e.QUOTE_STRING_MODE, {
                                            illegal: null,
                                            contains: e.QUOTE_STRING_MODE.contains.concat(s)
                                        }), o, {
                                            begin: /<<<[ \t]*(?:(\w+)|"(\w+)")\n/,
                                            end: /[ \t]*(\w+)\b/,
                                            contains: e.QUOTE_STRING_MODE.contains.concat(s),
                                            "on:begin": function(e, u) {
                                                u.data._beginMatch = e[1] || e[2]
                                            },
                                            "on:end": function(e, u) {
                                                u.data._beginMatch !== e[1] && u.ignoreMatch()
                                            }
                                        }, e.END_SAME_AS_BEGIN({
                                            begin: /<<<[ \t]*'(\w+)'\n/,
                                            end: /[ \t]*(\w+)\b/
                                        })]
                                    },
                                    d = {
                                        scope: "number",
                                        variants: [{
                                            begin: "\\b0[bB][01]+(?:_[01]+)*\\b"
                                        }, {
                                            begin: "\\b0[oO][0-7]+(?:_[0-7]+)*\\b"
                                        }, {
                                            begin: "\\b0[xX][\\da-fA-F]+(?:_[\\da-fA-F]+)*\\b"
                                        }, {
                                            begin: "(?:\\b\\d+(?:_\\d+)*(\\.(?:\\d+(?:_\\d+)*))?|\\B\\.\\d+)(?:[eE][+-]?\\d+)?"
                                        }],
                                        relevance: 0
                                    },
                                    E = ["false", "null", "true"],
                                    F = ["__CLASS__", "__DIR__", "__FILE__", "__FUNCTION__", "__COMPILER_HALT_OFFSET__", "__LINE__", "__METHOD__", "__NAMESPACE__", "__TRAIT__", "die", "echo", "exit", "include", "include_once", "print", "require", "require_once", "array", "abstract", "and", "as", "binary", "bool", "boolean", "break", "callable", "case", "catch", "class", "clone", "const", "continue", "declare", "default", "do", "double", "else", "elseif", "empty", "enddeclare", "endfor", "endforeach", "endif", "endswitch", "endwhile", "enum", "eval", "extends", "final", "finally", "float", "for", "foreach", "from", "global", "goto", "if", "implements", "instanceof", "insteadof", "int", "integer", "interface", "isset", "iterable", "list", "match|0", "mixed", "new", "never", "object", "or", "private", "protected", "public", "readonly", "real", "return", "string", "switch", "throw", "trait", "try", "unset", "use", "var", "void", "while", "xor", "yield"],
                                    A = ["Error|0", "AppendIterator", "ArgumentCountError", "ArithmeticError", "ArrayIterator", "ArrayObject", "AssertionError", "BadFunctionCallException", "BadMethodCallException", "CachingIterator", "CallbackFilterIterator", "CompileError", "Countable", "DirectoryIterator", "DivisionByZeroError", "DomainException", "EmptyIterator", "ErrorException", "Exception", "FilesystemIterator", "FilterIterator", "GlobIterator", "InfiniteIterator", "InvalidArgumentException", "IteratorIterator", "LengthException", "LimitIterator", "LogicException", "MultipleIterator", "NoRewindIterator", "OutOfBoundsException", "OutOfRangeException", "OuterIterator", "OverflowException", "ParentIterator", "ParseError", "RangeException", "RecursiveArrayIterator", "RecursiveCachingIterator", "RecursiveCallbackFilterIterator", "RecursiveDirectoryIterator", "RecursiveFilterIterator", "RecursiveIterator", "RecursiveIteratorIterator", "RecursiveRegexIterator", "RecursiveTreeIterator", "RegexIterator", "RuntimeException", "SeekableIterator", "SplDoublyLinkedList", "SplFileInfo", "SplFileObject", "SplFixedArray", "SplHeap", "SplMaxHeap", "SplMinHeap", "SplObjectStorage", "SplObserver", "SplPriorityQueue", "SplQueue", "SplStack", "SplSubject", "SplTempFileObject", "TypeError", "UnderflowException", "UnexpectedValueException", "UnhandledMatchError", "ArrayAccess", "BackedEnum", "Closure", "Fiber", "Generator", "Iterator", "IteratorAggregate", "Serializable", "Stringable", "Throwable", "Traversable", "UnitEnum", "WeakReference", "WeakMap", "Directory", "__PHP_Incomplete_Class", "parent", "php_user_filter", "self", "static", "stdClass"],
                                    C = {
                                        keyword: F,
                                        literal: (u = E, n = [], u.forEach((function(e) {
                                            n.push(e), e.toLowerCase() === e ? n.push(e.toUpperCase()) : n.push(e.toLowerCase())
                                        })), n),
                                        built_in: A
                                    },
                                    g = function(e) {
                                        return e.map((function(e) {
                                            return e.replace(/\|\d+$/, "")
                                        }))
                                    },
                                    b = {
                                        variants: [{
                                            match: [/new/, t.concat(c, "+"), t.concat("(?!", g(A).join("\\b|"), "\\b)"), i],
                                            scope: {
                                                1: "keyword",
                                                4: "title.class"
                                            }
                                        }]
                                    },
                                    m = t.concat(r, "\\b(?!\\()"),
                                    p = {
                                        variants: [{
                                            match: [t.concat(/::/, t.lookahead(/(?!class\b)/)), m],
                                            scope: {
                                                2: "variable.constant"
                                            }
                                        }, {
                                            match: [/::/, /class/],
                                            scope: {
                                                2: "variable.language"
                                            }
                                        }, {
                                            match: [i, t.concat(/::/, t.lookahead(/(?!class\b)/)), m],
                                            scope: {
                                                1: "title.class",
                                                3: "variable.constant"
                                            }
                                        }, {
                                            match: [i, t.concat("::", t.lookahead(/(?!class\b)/))],
                                            scope: {
                                                1: "title.class"
                                            }
                                        }, {
                                            match: [i, /::/, /class/],
                                            scope: {
                                                1: "title.class",
                                                3: "variable.language"
                                            }
                                        }]
                                    },
                                    f = {
                                        scope: "attr",
                                        match: t.concat(r, t.lookahead(":"), t.lookahead(/(?!::)/))
                                    },
                                    B = {
                                        relevance: 0,
                                        begin: /\(/,
                                        end: /\)/,
                                        keywords: C,
                                        contains: [f, D, p, e.C_BLOCK_COMMENT_MODE, l, d, b]
                                    },
                                    h = {
                                        relevance: 0,
                                        match: [/\b/, t.concat("(?!fn\\b|function\\b|", g(F).join("\\b|"), "|", g(A).join("\\b|"), "\\b)"), r, t.concat(c, "*"), t.lookahead(/(?=\()/)],
                                        scope: {
                                            3: "title.function.invoke"
                                        },
                                        contains: [B]
                                    };
                                B.contains.push(h);
                                var _ = [f, p, e.C_BLOCK_COMMENT_MODE, l, d, b];
                                return {
                                    case_insensitive: !1,
                                    keywords: C,
                                    contains: [{
                                        begin: t.concat(/#\[\s*/, i),
                                        beginScope: "meta",
                                        end: /]/,
                                        endScope: "meta",
                                        keywords: {
                                            literal: E,
                                            keyword: ["new", "array"]
                                        },
                                        contains: [{
                                            begin: /\[/,
                                            end: /]/,
                                            keywords: {
                                                literal: E,
                                                keyword: ["new", "array"]
                                            },
                                            contains: ["self"].concat(_)
                                        }].concat(_, [{
                                            scope: "meta",
                                            match: i
                                        }])
                                    }, e.HASH_COMMENT_MODE, e.COMMENT("//", "$"), e.COMMENT("/\\*", "\\*/", {
                                        contains: [{
                                            scope: "doctag",
                                            match: "@[A-Za-z]+"
                                        }]
                                    }), {
                                        match: /__halt_compiler\(\);/,
                                        keywords: "__halt_compiler",
                                        starts: {
                                            scope: "comment",
                                            end: e.MATCH_NOTHING_RE,
                                            contains: [{
                                                match: /\?>/,
                                                scope: "meta",
                                                endsParent: !0
                                            }]
                                        }
                                    }, {
                                        scope: "meta",
                                        variants: [{
                                            begin: /<\?php/,
                                            relevance: 10
                                        }, {
                                            begin: /<\?=/
                                        }, {
                                            begin: /<\?/,
                                            relevance: .1
                                        }, {
                                            begin: /\?>/
                                        }]
                                    }, {
                                        scope: "variable.language",
                                        match: /\$this\b/
                                    }, D, h, p, {
                                        match: [/const/, /\s/, r],
                                        scope: {
                                            1: "keyword",
                                            3: "variable.constant"
                                        }
                                    }, b, {
                                        scope: "function",
                                        relevance: 0,
                                        beginKeywords: "fn function",
                                        end: /[;{]/,
                                        excludeEnd: !0,
                                        illegal: "[$%\\[]",
                                        contains: [{
                                            beginKeywords: "use"
                                        }, e.UNDERSCORE_TITLE_MODE, {
                                            begin: "=>",
                                            endsParent: !0
                                        }, {
                                            scope: "params",
                                            begin: "\\(",
                                            end: "\\)",
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            keywords: C,
                                            contains: ["self", D, p, e.C_BLOCK_COMMENT_MODE, l, d]
                                        }]
                                    }, {
                                        scope: "class",
                                        variants: [{
                                            beginKeywords: "enum",
                                            illegal: /[($"]/
                                        }, {
                                            beginKeywords: "class interface trait",
                                            illegal: /[:($"]/
                                        }],
                                        relevance: 0,
                                        end: /\{/,
                                        excludeEnd: !0,
                                        contains: [{
                                            beginKeywords: "extends implements"
                                        }, e.UNDERSCORE_TITLE_MODE]
                                    }, {
                                        beginKeywords: "namespace",
                                        relevance: 0,
                                        end: ";",
                                        illegal: /[.']/,
                                        contains: [e.inherit(e.UNDERSCORE_TITLE_MODE, {
                                            scope: "title.class"
                                        })]
                                    }, {
                                        beginKeywords: "use",
                                        relevance: 0,
                                        end: ";",
                                        contains: [{
                                            match: /\b(as|const|function)\b/,
                                            scope: "keyword"
                                        }, e.UNDERSCORE_TITLE_MODE]
                                    }, l, d]
                                }
                            },
                            grmr_php_template: function(e) {
                                return {
                                    name: "PHP template",
                                    subLanguage: "xml",
                                    contains: [{
                                        begin: /<\?(php|=)?/,
                                        end: /\?>/,
                                        subLanguage: "php",
                                        contains: [{
                                            begin: "/\\*",
                                            end: "\\*/",
                                            skip: !0
                                        }, {
                                            begin: 'b"',
                                            end: '"',
                                            skip: !0
                                        }, {
                                            begin: "b'",
                                            end: "'",
                                            skip: !0
                                        }, e.inherit(e.APOS_STRING_MODE, {
                                            illegal: null,
                                            className: null,
                                            contains: null,
                                            skip: !0
                                        }), e.inherit(e.QUOTE_STRING_MODE, {
                                            illegal: null,
                                            className: null,
                                            contains: null,
                                            skip: !0
                                        })]
                                    }]
                                }
                            },
                            grmr_plaintext: function(e) {
                                return {
                                    name: "Plain text",
                                    aliases: ["text", "txt"],
                                    disableAutodetect: !0
                                }
                            },
                            grmr_protobuf: function(e) {
                                var u = {
                                    match: [/(message|enum|service)\s+/, e.IDENT_RE],
                                    scope: {
                                        1: "keyword",
                                        2: "title.class"
                                    }
                                };
                                return {
                                    name: "Protocol Buffers",
                                    aliases: ["proto"],
                                    keywords: {
                                        keyword: ["package", "import", "option", "optional", "required", "repeated", "group", "oneof"],
                                        type: ["double", "float", "int32", "int64", "uint32", "uint64", "sint32", "sint64", "fixed32", "fixed64", "sfixed32", "sfixed64", "bool", "string", "bytes"],
                                        literal: ["true", "false"]
                                    },
                                    contains: [e.QUOTE_STRING_MODE, e.NUMBER_MODE, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, u, {
                                        className: "function",
                                        beginKeywords: "rpc",
                                        end: /[{;]/,
                                        excludeEnd: !0,
                                        keywords: "rpc returns"
                                    }, {
                                        begin: /^\s*[A-Z_]+(?=\s*=[^\n]+;$)/
                                    }]
                                }
                            },
                            grmr_python: function(e) {
                                var u = e.regex,
                                    n = /(?:[A-Z_a-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037B-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFC5D\uFC64-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDF9\uFE71\uFE73\uFE77\uFE79\uFE7B\uFE7D\uFE7F-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFF9D\uFFA0-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD887][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF39\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD888[\uDC00-\uDFAF])(?:[0-9A-Z_a-z\xAA\xB5\xB7\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037B-\u037D\u037F\u0386-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05EF-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u07FD\u0800-\u082D\u0840-\u085B\u0860-\u086A\u0870-\u0887\u0889-\u088E\u0898-\u08E1\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u09FC\u09FE\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9-\u0AFF\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B55-\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3C-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C5D\u0C60-\u0C63\u0C66-\u0C6F\u0C80-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDD\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1-\u0CF3\u0D00-\u0D0C\u0D0E-\u0D10\u0D12-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D54-\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D81-\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECE\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1369-\u1371\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1715\u171F-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u180F-\u1819\u1820-\u1878\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1ABF-\u1ACE\u1B00-\u1B4C\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CD0-\u1CD2\u1CD4-\u1CFA\u1D00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200C\u200D\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099\u309A\u309D-\u309F\u30A1-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA827\uA82C\uA840-\uA873\uA880-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFC5D\uFC64-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDF9\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE71\uFE73\uFE77\uFE79\uFE7B\uFE7D\uFE7F-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF65-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD27\uDD30-\uDD39\uDE80-\uDEA9\uDEAB\uDEAC\uDEB0\uDEB1\uDEFD-\uDF1C\uDF27\uDF30-\uDF50\uDF70-\uDF85\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC00-\uDC46\uDC66-\uDC75\uDC7F-\uDCBA\uDCC2\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD44-\uDD47\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDC9-\uDDCC\uDDCE-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE3E-\uDE41\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3B-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC00-\uDC4A\uDC50-\uDC59\uDC5E-\uDC61\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB8\uDEC0-\uDEC9\uDF00-\uDF1A\uDF1D-\uDF2B\uDF30-\uDF39\uDF40-\uDF46]|\uD806[\uDC00-\uDC3A\uDCA0-\uDCE9\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD35\uDD37\uDD38\uDD3B-\uDD43\uDD50-\uDD59\uDDA0-\uDDA7\uDDAA-\uDDD7\uDDDA-\uDDE1\uDDE3\uDDE4\uDE00-\uDE3E\uDE47\uDE50-\uDE99\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC36\uDC38-\uDC40\uDC50-\uDC59\uDC72-\uDC8F\uDC92-\uDCA7\uDCA9-\uDCB6\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD36\uDD3A\uDD3C\uDD3D\uDD3F-\uDD47\uDD50-\uDD59\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD8E\uDD90\uDD91\uDD93-\uDD98\uDDA0-\uDDA9\uDEE0-\uDEF6\uDF00-\uDF10\uDF12-\uDF3A\uDF3E-\uDF42\uDF50-\uDF59\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD887][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC40-\uDC55]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDE70-\uDEBE\uDEC0-\uDEC9\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF4F-\uDF87\uDF8F-\uDF9F\uDFE0\uDFE1\uDFE3\uDFE4\uDFF0\uDFF1]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD833[\uDF00-\uDF2D\uDF30-\uDF46]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC00-\uDC06\uDC08-\uDC18\uDC1B-\uDC21\uDC23\uDC24\uDC26-\uDC2A\uDC30-\uDC6D\uDC8F\uDD00-\uDD2C\uDD30-\uDD3D\uDD40-\uDD49\uDD4E\uDE90-\uDEAE\uDEC0-\uDEF9]|\uD839[\uDCD0-\uDCF9\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6\uDD00-\uDD4B\uDD50-\uDD59]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD83E[\uDFF0-\uDFF9]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF39\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD888[\uDC00-\uDFAF]|\uDB40[\uDD00-\uDDEF])*/,
                                    t = ["and", "as", "assert", "async", "await", "break", "case", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "match", "nonlocal|10", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield"],
                                    a = {
                                        $pattern: /[A-Za-z]\w+|__\w+__/,
                                        keyword: t,
                                        built_in: ["__import__", "abs", "all", "any", "ascii", "bin", "bool", "breakpoint", "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex", "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct", "open", "ord", "pow", "print", "property", "range", "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip"],
                                        literal: ["__debug__", "Ellipsis", "False", "None", "NotImplemented", "True"],
                                        type: ["Any", "Callable", "Coroutine", "Dict", "List", "Literal", "Generic", "Optional", "Sequence", "Set", "Tuple", "Type", "Union"]
                                    },
                                    r = {
                                        className: "meta",
                                        begin: /^(>>>|\.\.\.) /
                                    },
                                    i = {
                                        className: "subst",
                                        begin: /\{/,
                                        end: /\}/,
                                        keywords: a,
                                        illegal: /#/
                                    },
                                    D = {
                                        begin: /\{\{/,
                                        relevance: 0
                                    },
                                    s = {
                                        className: "string",
                                        contains: [e.BACKSLASH_ESCAPE],
                                        variants: [{
                                            begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,
                                            end: /'''/,
                                            contains: [e.BACKSLASH_ESCAPE, r],
                                            relevance: 10
                                        }, {
                                            begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,
                                            end: /"""/,
                                            contains: [e.BACKSLASH_ESCAPE, r],
                                            relevance: 10
                                        }, {
                                            begin: /([fF][rR]|[rR][fF]|[fF])'''/,
                                            end: /'''/,
                                            contains: [e.BACKSLASH_ESCAPE, r, D, i]
                                        }, {
                                            begin: /([fF][rR]|[rR][fF]|[fF])"""/,
                                            end: /"""/,
                                            contains: [e.BACKSLASH_ESCAPE, r, D, i]
                                        }, {
                                            begin: /([uU]|[rR])'/,
                                            end: /'/,
                                            relevance: 10
                                        }, {
                                            begin: /([uU]|[rR])"/,
                                            end: /"/,
                                            relevance: 10
                                        }, {
                                            begin: /([bB]|[bB][rR]|[rR][bB])'/,
                                            end: /'/
                                        }, {
                                            begin: /([bB]|[bB][rR]|[rR][bB])"/,
                                            end: /"/
                                        }, {
                                            begin: /([fF][rR]|[rR][fF]|[fF])'/,
                                            end: /'/,
                                            contains: [e.BACKSLASH_ESCAPE, D, i]
                                        }, {
                                            begin: /([fF][rR]|[rR][fF]|[fF])"/,
                                            end: /"/,
                                            contains: [e.BACKSLASH_ESCAPE, D, i]
                                        }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
                                    },
                                    o = "[0-9](_?[0-9])*",
                                    c = "(\\b(".concat(o, "))?\\.(").concat(o, ")|\\b(").concat(o, ")\\."),
                                    l = "\\b|".concat(t.join("|")),
                                    d = {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            begin: "(\\b(".concat(o, ")|(").concat(c, "))[eE][+-]?(").concat(o, ")[jJ]?(?=").concat(l, ")")
                                        }, {
                                            begin: "(".concat(c, ")[jJ]?")
                                        }, {
                                            begin: "\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=".concat(l, ")")
                                        }, {
                                            begin: "\\b0[bB](_?[01])+[lL]?(?=".concat(l, ")")
                                        }, {
                                            begin: "\\b0[oO](_?[0-7])+[lL]?(?=".concat(l, ")")
                                        }, {
                                            begin: "\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=".concat(l, ")")
                                        }, {
                                            begin: "\\b(".concat(o, ")[jJ](?=").concat(l, ")")
                                        }]
                                    },
                                    E = {
                                        className: "comment",
                                        begin: u.lookahead(/# type:/),
                                        end: /$/,
                                        keywords: a,
                                        contains: [{
                                            begin: /# type:/
                                        }, {
                                            begin: /#/,
                                            end: /\b\B/,
                                            endsWithParent: !0
                                        }]
                                    },
                                    F = {
                                        className: "params",
                                        variants: [{
                                            className: "",
                                            begin: /\(\s*\)/,
                                            skip: !0
                                        }, {
                                            begin: /\(/,
                                            end: /\)/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            keywords: a,
                                            contains: ["self", r, d, s, e.HASH_COMMENT_MODE]
                                        }]
                                    };
                                return i.contains = [s, d, r], {
                                    name: "Python",
                                    aliases: ["py", "gyp", "ipython"],
                                    unicodeRegex: !0,
                                    keywords: a,
                                    illegal: /(<\/|\?)|=>/,
                                    contains: [r, d, {
                                        begin: /\bself\b/
                                    }, {
                                        beginKeywords: "if",
                                        relevance: 0
                                    }, s, E, e.HASH_COMMENT_MODE, {
                                        match: [/\bdef/, /\s+/, n],
                                        scope: {
                                            1: "keyword",
                                            3: "title.function"
                                        },
                                        contains: [F]
                                    }, {
                                        variants: [{
                                            match: [/\bclass/, /\s+/, n, /\s*/, /\(\s*/, n, /\s*\)/]
                                        }, {
                                            match: [/\bclass/, /\s+/, n]
                                        }],
                                        scope: {
                                            1: "keyword",
                                            3: "title.class",
                                            6: "title.class.inherited"
                                        }
                                    }, {
                                        className: "meta",
                                        begin: /^[\t ]*@/,
                                        end: /(?=#)|$/,
                                        contains: [d, F, s]
                                    }]
                                }
                            },
                            grmr_r: function(e) {
                                var u = e.regex,
                                    n = /(?:(?:[a-zA-Z]|\.[._a-zA-Z])[._a-zA-Z0-9]*)|\.(?!\d)/,
                                    t = u.either(/0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/, /0[xX][0-9a-fA-F]+(?:[pP][+-]?\d+)?[Li]?/, /(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?[Li]?/),
                                    a = /[=!<>:]=|\|\||&&|:::?|<-|<<-|->>|->|\|>|[-+*\/?!$&|:<=>@^~]|\*\*/,
                                    r = u.either(/[()]/, /[{}]/, /\[\[/, /[[\]]/, /\\/, /,/);
                                return {
                                    name: "R",
                                    keywords: {
                                        $pattern: n,
                                        keyword: "function if in break next repeat else for while",
                                        literal: "NULL NA TRUE FALSE Inf NaN NA_integer_|10 NA_real_|10 NA_character_|10 NA_complex_|10",
                                        built_in: "LETTERS letters month.abb month.name pi T F abs acos acosh all any anyNA Arg as.call as.character as.complex as.double as.environment as.integer as.logical as.null.default as.numeric as.raw asin asinh atan atanh attr attributes baseenv browser c call ceiling class Conj cos cosh cospi cummax cummin cumprod cumsum digamma dim dimnames emptyenv exp expression floor forceAndCall gamma gc.time globalenv Im interactive invisible is.array is.atomic is.call is.character is.complex is.double is.environment is.expression is.finite is.function is.infinite is.integer is.language is.list is.logical is.matrix is.na is.name is.nan is.null is.numeric is.object is.pairlist is.raw is.recursive is.single is.symbol lazyLoadDBfetch length lgamma list log max min missing Mod names nargs nzchar oldClass on.exit pos.to.env proc.time prod quote range Re rep retracemem return round seq_along seq_len seq.int sign signif sin sinh sinpi sqrt standardGeneric substitute sum switch tan tanh tanpi tracemem trigamma trunc unclass untracemem UseMethod xtfrm"
                                    },
                                    contains: [e.COMMENT(/#'/, /$/, {
                                        contains: [{
                                            scope: "doctag",
                                            match: /@examples/,
                                            starts: {
                                                end: u.lookahead(u.either(/\n^#'\s*(?=@[a-zA-Z]+)/, /\n^(?!#')/)),
                                                endsParent: !0
                                            }
                                        }, {
                                            scope: "doctag",
                                            begin: "@param",
                                            end: /$/,
                                            contains: [{
                                                scope: "variable",
                                                variants: [{
                                                    match: n
                                                }, {
                                                    match: /`(?:\\.|[^`\\])+`/
                                                }],
                                                endsParent: !0
                                            }]
                                        }, {
                                            scope: "doctag",
                                            match: /@[a-zA-Z]+/
                                        }, {
                                            scope: "keyword",
                                            match: /\\[a-zA-Z]+/
                                        }]
                                    }), e.HASH_COMMENT_MODE, {
                                        scope: "string",
                                        contains: [e.BACKSLASH_ESCAPE],
                                        variants: [e.END_SAME_AS_BEGIN({
                                            begin: /[rR]"(-*)\(/,
                                            end: /\)(-*)"/
                                        }), e.END_SAME_AS_BEGIN({
                                            begin: /[rR]"(-*)\{/,
                                            end: /\}(-*)"/
                                        }), e.END_SAME_AS_BEGIN({
                                            begin: /[rR]"(-*)\[/,
                                            end: /\](-*)"/
                                        }), e.END_SAME_AS_BEGIN({
                                            begin: /[rR]'(-*)\(/,
                                            end: /\)(-*)'/
                                        }), e.END_SAME_AS_BEGIN({
                                            begin: /[rR]'(-*)\{/,
                                            end: /\}(-*)'/
                                        }), e.END_SAME_AS_BEGIN({
                                            begin: /[rR]'(-*)\[/,
                                            end: /\](-*)'/
                                        }), {
                                            begin: '"',
                                            end: '"',
                                            relevance: 0
                                        }, {
                                            begin: "'",
                                            end: "'",
                                            relevance: 0
                                        }]
                                    }, {
                                        relevance: 0,
                                        variants: [{
                                            scope: {
                                                1: "operator",
                                                2: "number"
                                            },
                                            match: [a, t]
                                        }, {
                                            scope: {
                                                1: "operator",
                                                2: "number"
                                            },
                                            match: [/%[^%]*%/, t]
                                        }, {
                                            scope: {
                                                1: "punctuation",
                                                2: "number"
                                            },
                                            match: [r, t]
                                        }, {
                                            scope: {
                                                2: "number"
                                            },
                                            match: [/[^a-zA-Z0-9._]|^/, t]
                                        }]
                                    }, {
                                        scope: {
                                            3: "operator"
                                        },
                                        match: [n, /\s+/, /<-/, /\s+/]
                                    }, {
                                        scope: "operator",
                                        relevance: 0,
                                        variants: [{
                                            match: a
                                        }, {
                                            match: /%[^%]*%/
                                        }]
                                    }, {
                                        scope: "punctuation",
                                        relevance: 0,
                                        match: r
                                    }, {
                                        begin: "`",
                                        end: "`",
                                        contains: [{
                                            begin: /\\./
                                        }]
                                    }]
                                }
                            },
                            grmr_ruby: function(e) {
                                var u = e.regex,
                                    n = "([a-zA-Z_]\\w*[!?=]?|[-+~]@|<<|>>|=~|===?|<=>|[<>]=?|\\*\\*|[-/+%^&*~`|]|\\[\\]=?)",
                                    t = u.either(/\b([A-Z]+[a-z0-9]+)+/, /\b([A-Z]+[a-z0-9]+)+[A-Z]+/),
                                    a = u.concat(t, /(::\w+)*/),
                                    r = {
                                        "variable.constant": ["__FILE__", "__LINE__", "__ENCODING__"],
                                        "variable.language": ["self", "super"],
                                        keyword: ["alias", "and", "begin", "BEGIN", "break", "case", "class", "defined", "do", "else", "elsif", "end", "END", "ensure", "for", "if", "in", "module", "next", "not", "or", "redo", "require", "rescue", "retry", "return", "then", "undef", "unless", "until", "when", "while", "yield"].concat(["include", "extend", "prepend", "public", "private", "protected", "raise", "throw"]),
                                        built_in: ["proc", "lambda", "attr_accessor", "attr_reader", "attr_writer", "define_method", "private_constant", "module_function"],
                                        literal: ["true", "false", "nil"]
                                    },
                                    i = {
                                        className: "doctag",
                                        begin: "@[A-Za-z]+"
                                    },
                                    D = {
                                        begin: "#<",
                                        end: ">"
                                    },
                                    s = [e.COMMENT("#", "$", {
                                        contains: [i]
                                    }), e.COMMENT("^=begin", "^=end", {
                                        contains: [i],
                                        relevance: 10
                                    }), e.COMMENT("^__END__", e.MATCH_NOTHING_RE)],
                                    o = {
                                        className: "subst",
                                        begin: /#\{/,
                                        end: /\}/,
                                        keywords: r
                                    },
                                    c = {
                                        className: "string",
                                        contains: [e.BACKSLASH_ESCAPE, o],
                                        variants: [{
                                            begin: /'/,
                                            end: /'/
                                        }, {
                                            begin: /"/,
                                            end: /"/
                                        }, {
                                            begin: /`/,
                                            end: /`/
                                        }, {
                                            begin: /%[qQwWx]?\(/,
                                            end: /\)/
                                        }, {
                                            begin: /%[qQwWx]?\[/,
                                            end: /\]/
                                        }, {
                                            begin: /%[qQwWx]?\{/,
                                            end: /\}/
                                        }, {
                                            begin: /%[qQwWx]?</,
                                            end: />/
                                        }, {
                                            begin: /%[qQwWx]?\//,
                                            end: /\//
                                        }, {
                                            begin: /%[qQwWx]?%/,
                                            end: /%/
                                        }, {
                                            begin: /%[qQwWx]?-/,
                                            end: /-/
                                        }, {
                                            begin: /%[qQwWx]?\|/,
                                            end: /\|/
                                        }, {
                                            begin: /\B\?(\\\d{1,3})/
                                        }, {
                                            begin: /\B\?(\\x[A-Fa-f0-9]{1,2})/
                                        }, {
                                            begin: /\B\?(\\u\{?[A-Fa-f0-9]{1,6}\}?)/
                                        }, {
                                            begin: /\B\?(\\M-\\C-|\\M-\\c|\\c\\M-|\\M-|\\C-\\M-)[\x20-\x7e]/
                                        }, {
                                            begin: /\B\?\\(c|C-)[\x20-\x7e]/
                                        }, {
                                            begin: /\B\?\\?\S/
                                        }, {
                                            begin: u.concat(/<<[-~]?'?/, u.lookahead(/(\w+)(?=\W)[^\n]*\n(?:[^\n]*\n)*?\s*\1\b/)),
                                            contains: [e.END_SAME_AS_BEGIN({
                                                begin: /(\w+)/,
                                                end: /(\w+)/,
                                                contains: [e.BACKSLASH_ESCAPE, o]
                                            })]
                                        }]
                                    },
                                    l = "[0-9](_?[0-9])*",
                                    d = {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            begin: "\\b(".concat("[1-9](_?[0-9])*|0", ")(\\.(").concat(l, "))?([eE][+-]?(").concat(l, ")|r)?i?\\b")
                                        }, {
                                            begin: "\\b0[dD][0-9](_?[0-9])*r?i?\\b"
                                        }, {
                                            begin: "\\b0[bB][0-1](_?[0-1])*r?i?\\b"
                                        }, {
                                            begin: "\\b0[oO][0-7](_?[0-7])*r?i?\\b"
                                        }, {
                                            begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*r?i?\\b"
                                        }, {
                                            begin: "\\b0(_?[0-7])+r?i?\\b"
                                        }]
                                    },
                                    E = {
                                        variants: [{
                                            match: /\(\)/
                                        }, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /(?=\))/,
                                            excludeBegin: !0,
                                            endsParent: !0,
                                            keywords: r
                                        }]
                                    },
                                    F = [c, {
                                        variants: [{
                                            match: [/class\s+/, a, /\s+<\s+/, a]
                                        }, {
                                            match: [/\b(class|module)\s+/, a]
                                        }],
                                        scope: {
                                            2: "title.class",
                                            4: "title.class.inherited"
                                        },
                                        keywords: r
                                    }, {
                                        match: [/(include|extend)\s+/, a],
                                        scope: {
                                            2: "title.class"
                                        },
                                        keywords: r
                                    }, {
                                        relevance: 0,
                                        match: [a, /\.new[. (]/],
                                        scope: {
                                            1: "title.class"
                                        }
                                    }, {
                                        relevance: 0,
                                        match: /\b[A-Z][A-Z_0-9]+\b/,
                                        className: "variable.constant"
                                    }, {
                                        relevance: 0,
                                        match: t,
                                        scope: "title.class"
                                    }, {
                                        match: [/def/, /\s+/, n],
                                        scope: {
                                            1: "keyword",
                                            3: "title.function"
                                        },
                                        contains: [E]
                                    }, {
                                        begin: e.IDENT_RE + "::"
                                    }, {
                                        className: "symbol",
                                        begin: e.UNDERSCORE_IDENT_RE + "(!|\\?)?:",
                                        relevance: 0
                                    }, {
                                        className: "symbol",
                                        begin: ":(?!\\s)",
                                        contains: [c, {
                                            begin: n
                                        }],
                                        relevance: 0
                                    }, d, {
                                        className: "variable",
                                        begin: "(\\$\\W)|((\\$|@@?)(\\w+))(?=[^@$?])(?![A-Za-z])(?![@$?'])"
                                    }, {
                                        className: "params",
                                        begin: /\|/,
                                        end: /\|/,
                                        excludeBegin: !0,
                                        excludeEnd: !0,
                                        relevance: 0,
                                        keywords: r
                                    }, {
                                        begin: "(" + e.RE_STARTERS_RE + "|unless)\\s*",
                                        keywords: "unless",
                                        contains: [{
                                            className: "regexp",
                                            contains: [e.BACKSLASH_ESCAPE, o],
                                            illegal: /\n/,
                                            variants: [{
                                                begin: "/",
                                                end: "/[a-z]*"
                                            }, {
                                                begin: /%r\{/,
                                                end: /\}[a-z]*/
                                            }, {
                                                begin: "%r\\(",
                                                end: "\\)[a-z]*"
                                            }, {
                                                begin: "%r!",
                                                end: "![a-z]*"
                                            }, {
                                                begin: "%r\\[",
                                                end: "\\][a-z]*"
                                            }]
                                        }].concat(D, s),
                                        relevance: 0
                                    }].concat(D, s);
                                o.contains = F, E.contains = F;
                                var A = [{
                                    begin: /^\s*=>/,
                                    starts: {
                                        end: "$",
                                        contains: F
                                    }
                                }, {
                                    className: "meta.prompt",
                                    begin: "^([>?]>|[\\w#]+\\(\\w+\\):\\d+:\\d+[>*]|(\\w+-)?\\d+\\.\\d+\\.\\d+(p\\d+)?[^\\d][^>]+>)(?=[ ])",
                                    starts: {
                                        end: "$",
                                        keywords: r,
                                        contains: F
                                    }
                                }];
                                return s.unshift(D), {
                                    name: "Ruby",
                                    aliases: ["rb", "gemspec", "podspec", "thor", "irb"],
                                    keywords: r,
                                    illegal: /\/\*/,
                                    contains: [e.SHEBANG({
                                        binary: "ruby"
                                    })].concat(A).concat(s).concat(F)
                                }
                            },
                            grmr_rust: function(e) {
                                var u = e.regex,
                                    n = {
                                        className: "title.function.invoke",
                                        relevance: 0,
                                        begin: u.concat(/\b/, /(?!let|for|while|if|else|match\b)/, e.IDENT_RE, u.lookahead(/\s*\(/))
                                    },
                                    t = "([ui](8|16|32|64|128|size)|f(32|64))?",
                                    a = ["drop ", "Copy", "Send", "Sized", "Sync", "Drop", "Fn", "FnMut", "FnOnce", "ToOwned", "Clone", "Debug", "PartialEq", "PartialOrd", "Eq", "Ord", "AsRef", "AsMut", "Into", "From", "Default", "Iterator", "Extend", "IntoIterator", "DoubleEndedIterator", "ExactSizeIterator", "SliceConcatExt", "ToString", "assert!", "assert_eq!", "bitflags!", "bytes!", "cfg!", "col!", "concat!", "concat_idents!", "debug_assert!", "debug_assert_eq!", "env!", "eprintln!", "panic!", "file!", "format!", "format_args!", "include_bytes!", "include_str!", "line!", "local_data_key!", "module_path!", "option_env!", "print!", "println!", "select!", "stringify!", "try!", "unimplemented!", "unreachable!", "vec!", "write!", "writeln!", "macro_rules!", "assert_ne!", "debug_assert_ne!"],
                                    r = ["i8", "i16", "i32", "i64", "i128", "isize", "u8", "u16", "u32", "u64", "u128", "usize", "f32", "f64", "str", "char", "bool", "Box", "Option", "Result", "String", "Vec"];
                                return {
                                    name: "Rust",
                                    aliases: ["rs"],
                                    keywords: {
                                        $pattern: e.IDENT_RE + "!?",
                                        type: r,
                                        keyword: ["abstract", "as", "async", "await", "become", "box", "break", "const", "continue", "crate", "do", "dyn", "else", "enum", "extern", "false", "final", "fn", "for", "if", "impl", "in", "let", "loop", "macro", "match", "mod", "move", "mut", "override", "priv", "pub", "ref", "return", "self", "Self", "static", "struct", "super", "trait", "true", "try", "type", "typeof", "unsafe", "unsized", "use", "virtual", "where", "while", "yield"],
                                        literal: ["true", "false", "Some", "None", "Ok", "Err"],
                                        built_in: a
                                    },
                                    illegal: "</",
                                    contains: [e.C_LINE_COMMENT_MODE, e.COMMENT("/\\*", "\\*/", {
                                        contains: ["self"]
                                    }), e.inherit(e.QUOTE_STRING_MODE, {
                                        begin: /b?"/,
                                        illegal: null
                                    }), {
                                        className: "string",
                                        variants: [{
                                            begin: /b?r(#*)"(.|\n)*?"\1(?!#)/
                                        }, {
                                            begin: /b?'\\?(x\w{2}|u\w{4}|U\w{8}|.)'/
                                        }]
                                    }, {
                                        className: "symbol",
                                        begin: /'[a-zA-Z_][a-zA-Z0-9_]*/
                                    }, {
                                        className: "number",
                                        variants: [{
                                            begin: "\\b0b([01_]+)" + t
                                        }, {
                                            begin: "\\b0o([0-7_]+)" + t
                                        }, {
                                            begin: "\\b0x([A-Fa-f0-9_]+)" + t
                                        }, {
                                            begin: "\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)" + t
                                        }],
                                        relevance: 0
                                    }, {
                                        begin: [/fn/, /\s+/, e.UNDERSCORE_IDENT_RE],
                                        className: {
                                            1: "keyword",
                                            3: "title.function"
                                        }
                                    }, {
                                        className: "meta",
                                        begin: "#!?\\[",
                                        end: "\\]",
                                        contains: [{
                                            className: "string",
                                            begin: /"/,
                                            end: /"/
                                        }]
                                    }, {
                                        begin: [/let/, /\s+/, /(?:mut\s+)?/, e.UNDERSCORE_IDENT_RE],
                                        className: {
                                            1: "keyword",
                                            3: "keyword",
                                            4: "variable"
                                        }
                                    }, {
                                        begin: [/for/, /\s+/, e.UNDERSCORE_IDENT_RE, /\s+/, /in/],
                                        className: {
                                            1: "keyword",
                                            3: "variable",
                                            5: "keyword"
                                        }
                                    }, {
                                        begin: [/type/, /\s+/, e.UNDERSCORE_IDENT_RE],
                                        className: {
                                            1: "keyword",
                                            3: "title.class"
                                        }
                                    }, {
                                        begin: [/(?:trait|enum|struct|union|impl|for)/, /\s+/, e.UNDERSCORE_IDENT_RE],
                                        className: {
                                            1: "keyword",
                                            3: "title.class"
                                        }
                                    }, {
                                        begin: e.IDENT_RE + "::",
                                        keywords: {
                                            keyword: "Self",
                                            built_in: a,
                                            type: r
                                        }
                                    }, {
                                        className: "punctuation",
                                        begin: "->"
                                    }, n]
                                }
                            },
                            grmr_scala: function(e) {
                                var u = e.regex,
                                    n = {
                                        className: "subst",
                                        variants: [{
                                            begin: "\\$[A-Za-z0-9_]+"
                                        }, {
                                            begin: /\$\{/,
                                            end: /\}/
                                        }]
                                    },
                                    t = {
                                        className: "string",
                                        variants: [{
                                            begin: '"""',
                                            end: '"""'
                                        }, {
                                            begin: '"',
                                            end: '"',
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE]
                                        }, {
                                            begin: '[a-z]+"',
                                            end: '"',
                                            illegal: "\\n",
                                            contains: [e.BACKSLASH_ESCAPE, n]
                                        }, {
                                            className: "string",
                                            begin: '[a-z]+"""',
                                            end: '"""',
                                            contains: [n],
                                            relevance: 10
                                        }]
                                    },
                                    a = {
                                        className: "type",
                                        begin: "\\b[A-Z][A-Za-z0-9_]*",
                                        relevance: 0
                                    },
                                    r = {
                                        className: "title",
                                        begin: /[^0-9\n\t "'(),.`{}\[\]:;][^\n\t "'(),.`{}\[\]:;]+|[^0-9\n\t "'(),.`{}\[\]:;=]/,
                                        relevance: 0
                                    },
                                    i = {
                                        className: "class",
                                        beginKeywords: "class object trait type",
                                        end: /[:={\[\n;]/,
                                        excludeEnd: !0,
                                        contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                                            beginKeywords: "extends with",
                                            relevance: 10
                                        }, {
                                            begin: /\[/,
                                            end: /\]/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            relevance: 0,
                                            contains: [a, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                        }, {
                                            className: "params",
                                            begin: /\(/,
                                            end: /\)/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            relevance: 0,
                                            contains: [a, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                                        }, r]
                                    },
                                    D = {
                                        className: "function",
                                        beginKeywords: "def",
                                        end: u.lookahead(/[:={\[(\n;]/),
                                        contains: [r]
                                    };
                                return {
                                    name: "Scala",
                                    keywords: {
                                        literal: "true false null",
                                        keyword: "type yield lazy override def with val var sealed abstract private trait object if then forSome for while do throw finally protected extends import final return else break new catch super class case package default try this match continue throws implicit export enum given transparent"
                                    },
                                    contains: [{
                                        begin: ["//>", /\s+/, /using/, /\s+/, /\S+/],
                                        beginScope: {
                                            1: "comment",
                                            3: "keyword",
                                            5: "type"
                                        },
                                        end: /$/,
                                        contains: [{
                                            className: "string",
                                            begin: /\S+/
                                        }]
                                    }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, t, a, D, i, e.C_NUMBER_MODE, {
                                        begin: [/^\s*/, "extension", /\s+(?=[[(])/],
                                        beginScope: {
                                            2: "keyword"
                                        }
                                    }, {
                                        begin: [/^\s*/, /end/, /\s+/, /(extension\b)?/],
                                        beginScope: {
                                            2: "keyword",
                                            4: "keyword"
                                        }
                                    }].concat([{
                                        match: /\.inline\b/
                                    }, {
                                        begin: /\binline(?=\s)/,
                                        keywords: "inline"
                                    }], [{
                                        begin: [/\(\s*/, /using/, /\s+(?!\))/],
                                        beginScope: {
                                            2: "keyword"
                                        }
                                    }, {
                                        className: "meta",
                                        begin: "@[A-Za-z]+"
                                    }])
                                }
                            },
                            grmr_scheme: function(e) {
                                var u = "[^\\(\\)\\[\\]\\{\\}\",'`;#|\\\\\\s]+",
                                    n = "(-|\\+)?\\d+([./]\\d+)?",
                                    t = {
                                        $pattern: u,
                                        built_in: "case-lambda call/cc class define-class exit-handler field import inherit init-field interface let*-values let-values let/ec mixin opt-lambda override protect provide public rename require require-for-syntax syntax syntax-case syntax-error unit/sig unless when with-syntax and begin call-with-current-continuation call-with-input-file call-with-output-file case cond define define-syntax delay do dynamic-wind else for-each if lambda let let* let-syntax letrec letrec-syntax map or syntax-rules ' * + , ,@ - ... / ; < <= = => > >= ` abs acos angle append apply asin assoc assq assv atan boolean? caar cadr call-with-input-file call-with-output-file call-with-values car cdddar cddddr cdr ceiling char->integer char-alphabetic? char-ci<=? char-ci<? char-ci=? char-ci>=? char-ci>? char-downcase char-lower-case? char-numeric? char-ready? char-upcase char-upper-case? char-whitespace? char<=? char<? char=? char>=? char>? char? close-input-port close-output-port complex? cons cos current-input-port current-output-port denominator display eof-object? eq? equal? eqv? eval even? exact->inexact exact? exp expt floor force gcd imag-part inexact->exact inexact? input-port? integer->char integer? interaction-environment lcm length list list->string list->vector list-ref list-tail list? load log magnitude make-polar make-rectangular make-string make-vector max member memq memv min modulo negative? newline not null-environment null? number->string number? numerator odd? open-input-file open-output-file output-port? pair? peek-char port? positive? procedure? quasiquote quote quotient rational? rationalize read read-char real-part real? remainder reverse round scheme-report-environment set! set-car! set-cdr! sin sqrt string string->list string->number string->symbol string-append string-ci<=? string-ci<? string-ci=? string-ci>=? string-ci>? string-copy string-fill! string-length string-ref string-set! string<=? string<? string=? string>=? string>? string? substring symbol->string symbol? tan transcript-off transcript-on truncate values vector vector->list vector-fill! vector-length vector-ref vector-set! with-input-from-file with-output-to-file write write-char zero?"
                                    },
                                    a = {
                                        className: "literal",
                                        begin: "(#t|#f|#\\\\" + u + "|#\\\\.)"
                                    },
                                    r = {
                                        className: "number",
                                        variants: [{
                                            begin: n,
                                            relevance: 0
                                        }, {
                                            begin: n + "[+\\-]" + n + "i",
                                            relevance: 0
                                        }, {
                                            begin: "#b[0-1]+(/[0-1]+)?"
                                        }, {
                                            begin: "#o[0-7]+(/[0-7]+)?"
                                        }, {
                                            begin: "#x[0-9a-f]+(/[0-9a-f]+)?"
                                        }]
                                    },
                                    i = e.QUOTE_STRING_MODE,
                                    D = [e.COMMENT(";", "$", {
                                        relevance: 0
                                    }), e.COMMENT("#\\|", "\\|#")],
                                    s = {
                                        begin: u,
                                        relevance: 0
                                    },
                                    o = {
                                        className: "symbol",
                                        begin: "'" + u
                                    },
                                    c = {
                                        endsWithParent: !0,
                                        relevance: 0
                                    },
                                    l = {
                                        variants: [{
                                            begin: /'/
                                        }, {
                                            begin: "`"
                                        }],
                                        contains: [{
                                            begin: "\\(",
                                            end: "\\)",
                                            contains: ["self", a, i, r, s, o]
                                        }]
                                    },
                                    d = {
                                        className: "name",
                                        relevance: 0,
                                        begin: u,
                                        keywords: t
                                    },
                                    E = {
                                        variants: [{
                                            begin: "\\(",
                                            end: "\\)"
                                        }, {
                                            begin: "\\[",
                                            end: "\\]"
                                        }],
                                        contains: [{
                                            begin: /lambda/,
                                            endsWithParent: !0,
                                            returnBegin: !0,
                                            contains: [d, {
                                                endsParent: !0,
                                                variants: [{
                                                    begin: /\(/,
                                                    end: /\)/
                                                }, {
                                                    begin: /\[/,
                                                    end: /\]/
                                                }],
                                                contains: [s]
                                            }]
                                        }, d, c]
                                    };
                                return c.contains = [a, r, i, s, o, l, E].concat(D), {
                                    name: "Scheme",
                                    aliases: ["scm"],
                                    illegal: /\S/,
                                    contains: [e.SHEBANG(), r, i, o, l, E].concat(D)
                                }
                            },
                            grmr_scss: function(e) {
                                var u = be(e),
                                    n = Be,
                                    t = fe,
                                    a = "@[a-z-]+",
                                    r = {
                                        className: "variable",
                                        begin: "(\\$[a-zA-Z-][a-zA-Z0-9_-]*)\\b",
                                        relevance: 0
                                    };
                                return {
                                    name: "SCSS",
                                    case_insensitive: !0,
                                    illegal: "[=/|']",
                                    contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, u.CSS_NUMBER_MODE, {
                                        className: "selector-id",
                                        begin: "#[A-Za-z0-9_-]+",
                                        relevance: 0
                                    }, {
                                        className: "selector-class",
                                        begin: "\\.[A-Za-z0-9_-]+",
                                        relevance: 0
                                    }, u.ATTRIBUTE_SELECTOR_MODE, {
                                        className: "selector-tag",
                                        begin: "\\b(" + me.join("|") + ")\\b",
                                        relevance: 0
                                    }, {
                                        className: "selector-pseudo",
                                        begin: ":(" + t.join("|") + ")"
                                    }, {
                                        className: "selector-pseudo",
                                        begin: ":(:)?(" + n.join("|") + ")"
                                    }, r, {
                                        begin: /\(/,
                                        end: /\)/,
                                        contains: [u.CSS_NUMBER_MODE]
                                    }, u.CSS_VARIABLE, {
                                        className: "attribute",
                                        begin: "\\b(" + he.join("|") + ")\\b"
                                    }, {
                                        begin: "\\b(whitespace|wait|w-resize|visible|vertical-text|vertical-ideographic|uppercase|upper-roman|upper-alpha|underline|transparent|top|thin|thick|text|text-top|text-bottom|tb-rl|table-header-group|table-footer-group|sw-resize|super|strict|static|square|solid|small-caps|separate|se-resize|scroll|s-resize|rtl|row-resize|ridge|right|repeat|repeat-y|repeat-x|relative|progress|pointer|overline|outside|outset|oblique|nowrap|not-allowed|normal|none|nw-resize|no-repeat|no-drop|newspaper|ne-resize|n-resize|move|middle|medium|ltr|lr-tb|lowercase|lower-roman|lower-alpha|loose|list-item|line|line-through|line-edge|lighter|left|keep-all|justify|italic|inter-word|inter-ideograph|inside|inset|inline|inline-block|inherit|inactive|ideograph-space|ideograph-parenthesis|ideograph-numeric|ideograph-alpha|horizontal|hidden|help|hand|groove|fixed|ellipsis|e-resize|double|dotted|distribute|distribute-space|distribute-letter|distribute-all-lines|disc|disabled|default|decimal|dashed|crosshair|collapse|col-resize|circle|char|center|capitalize|break-word|break-all|bottom|both|bolder|bold|block|bidi-override|below|baseline|auto|always|all-scroll|absolute|table|table-cell)\\b"
                                    }, {
                                        begin: /:/,
                                        end: /[;}{]/,
                                        relevance: 0,
                                        contains: [u.BLOCK_COMMENT, r, u.HEXCOLOR, u.CSS_NUMBER_MODE, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, u.IMPORTANT, u.FUNCTION_DISPATCH]
                                    }, {
                                        begin: "@(page|font-face)",
                                        keywords: {
                                            $pattern: a,
                                            keyword: "@page @font-face"
                                        }
                                    }, {
                                        begin: "@",
                                        end: "[{;]",
                                        returnBegin: !0,
                                        keywords: {
                                            $pattern: /[a-z-]+/,
                                            keyword: "and or not only",
                                            attribute: pe.join(" ")
                                        },
                                        contains: [{
                                            begin: a,
                                            className: "keyword"
                                        }, {
                                            begin: /[a-z-]+(?=:)/,
                                            className: "attribute"
                                        }, r, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, u.HEXCOLOR, u.CSS_NUMBER_MODE]
                                    }, u.FUNCTION_DISPATCH]
                                }
                            },
                            grmr_shell: function(e) {
                                return {
                                    name: "Shell Session",
                                    aliases: ["console", "shellsession"],
                                    contains: [{
                                        className: "meta.prompt",
                                        begin: /^\s{0,3}[/~\w\d[\]()@-]*[>%$#][ ]?/,
                                        starts: {
                                            end: /[^\\](?=\s*$)/,
                                            subLanguage: "bash"
                                        }
                                    }]
                                }
                            },
                            grmr_sql: function(e) {
                                var u = e.regex,
                                    n = e.COMMENT("--", "$"),
                                    t = ["true", "false", "unknown"],
                                    a = ["bigint", "binary", "blob", "boolean", "char", "character", "clob", "date", "dec", "decfloat", "decimal", "float", "int", "integer", "interval", "nchar", "nclob", "national", "numeric", "real", "row", "smallint", "time", "timestamp", "varchar", "varying", "varbinary"],
                                    r = ["abs", "acos", "array_agg", "asin", "atan", "avg", "cast", "ceil", "ceiling", "coalesce", "corr", "cos", "cosh", "count", "covar_pop", "covar_samp", "cume_dist", "dense_rank", "deref", "element", "exp", "extract", "first_value", "floor", "json_array", "json_arrayagg", "json_exists", "json_object", "json_objectagg", "json_query", "json_table", "json_table_primitive", "json_value", "lag", "last_value", "lead", "listagg", "ln", "log", "log10", "lower", "max", "min", "mod", "nth_value", "ntile", "nullif", "percent_rank", "percentile_cont", "percentile_disc", "position", "position_regex", "power", "rank", "regr_avgx", "regr_avgy", "regr_count", "regr_intercept", "regr_r2", "regr_slope", "regr_sxx", "regr_sxy", "regr_syy", "row_number", "sin", "sinh", "sqrt", "stddev_pop", "stddev_samp", "substring", "substring_regex", "sum", "tan", "tanh", "translate", "translate_regex", "treat", "trim", "trim_array", "unnest", "upper", "value_of", "var_pop", "var_samp", "width_bucket"],
                                    i = ["create table", "insert into", "primary key", "foreign key", "not null", "alter table", "add constraint", "grouping sets", "on overflow", "character set", "respect nulls", "ignore nulls", "nulls first", "nulls last", "depth first", "breadth first"],
                                    D = r,
                                    s = [].concat(["abs", "acos", "all", "allocate", "alter", "and", "any", "are", "array", "array_agg", "array_max_cardinality", "as", "asensitive", "asin", "asymmetric", "at", "atan", "atomic", "authorization", "avg", "begin", "begin_frame", "begin_partition", "between", "bigint", "binary", "blob", "boolean", "both", "by", "call", "called", "cardinality", "cascaded", "case", "cast", "ceil", "ceiling", "char", "char_length", "character", "character_length", "check", "classifier", "clob", "close", "coalesce", "collate", "collect", "column", "commit", "condition", "connect", "constraint", "contains", "convert", "copy", "corr", "corresponding", "cos", "cosh", "count", "covar_pop", "covar_samp", "create", "cross", "cube", "cume_dist", "current", "current_catalog", "current_date", "current_default_transform_group", "current_path", "current_role", "current_row", "current_schema", "current_time", "current_timestamp", "current_path", "current_role", "current_transform_group_for_type", "current_user", "cursor", "cycle", "date", "day", "deallocate", "dec", "decimal", "decfloat", "declare", "default", "define", "delete", "dense_rank", "deref", "describe", "deterministic", "disconnect", "distinct", "double", "drop", "dynamic", "each", "element", "else", "empty", "end", "end_frame", "end_partition", "end-exec", "equals", "escape", "every", "except", "exec", "execute", "exists", "exp", "external", "extract", "false", "fetch", "filter", "first_value", "float", "floor", "for", "foreign", "frame_row", "free", "from", "full", "function", "fusion", "get", "global", "grant", "group", "grouping", "groups", "having", "hold", "hour", "identity", "in", "indicator", "initial", "inner", "inout", "insensitive", "insert", "int", "integer", "intersect", "intersection", "interval", "into", "is", "join", "json_array", "json_arrayagg", "json_exists", "json_object", "json_objectagg", "json_query", "json_table", "json_table_primitive", "json_value", "lag", "language", "large", "last_value", "lateral", "lead", "leading", "left", "like", "like_regex", "listagg", "ln", "local", "localtime", "localtimestamp", "log", "log10", "lower", "match", "match_number", "match_recognize", "matches", "max", "member", "merge", "method", "min", "minute", "mod", "modifies", "module", "month", "multiset", "national", "natural", "nchar", "nclob", "new", "no", "none", "normalize", "not", "nth_value", "ntile", "null", "nullif", "numeric", "octet_length", "occurrences_regex", "of", "offset", "old", "omit", "on", "one", "only", "open", "or", "order", "out", "outer", "over", "overlaps", "overlay", "parameter", "partition", "pattern", "per", "percent", "percent_rank", "percentile_cont", "percentile_disc", "period", "portion", "position", "position_regex", "power", "precedes", "precision", "prepare", "primary", "procedure", "ptf", "range", "rank", "reads", "real", "recursive", "ref", "references", "referencing", "regr_avgx", "regr_avgy", "regr_count", "regr_intercept", "regr_r2", "regr_slope", "regr_sxx", "regr_sxy", "regr_syy", "release", "result", "return", "returns", "revoke", "right", "rollback", "rollup", "row", "row_number", "rows", "running", "savepoint", "scope", "scroll", "search", "second", "seek", "select", "sensitive", "session_user", "set", "show", "similar", "sin", "sinh", "skip", "smallint", "some", "specific", "specifictype", "sql", "sqlexception", "sqlstate", "sqlwarning", "sqrt", "start", "static", "stddev_pop", "stddev_samp", "submultiset", "subset", "substring", "substring_regex", "succeeds", "sum", "symmetric", "system", "system_time", "system_user", "table", "tablesample", "tan", "tanh", "then", "time", "timestamp", "timezone_hour", "timezone_minute", "to", "trailing", "translate", "translate_regex", "translation", "treat", "trigger", "trim", "trim_array", "true", "truncate", "uescape", "union", "unique", "unknown", "unnest", "update", "upper", "user", "using", "value", "values", "value_of", "var_pop", "var_samp", "varbinary", "varchar", "varying", "versioning", "when", "whenever", "where", "width_bucket", "window", "with", "within", "without", "year"], ["add", "asc", "collation", "desc", "final", "first", "last", "view"]).filter((function(e) {
                                        return !r.includes(e)
                                    })),
                                    o = {
                                        begin: u.concat(/\b/, u.either.apply(u, D), /\s*\(/),
                                        relevance: 0,
                                        keywords: {
                                            built_in: D
                                        }
                                    };
                                return {
                                    name: "SQL",
                                    case_insensitive: !0,
                                    illegal: /[{}]|<\//,
                                    keywords: {
                                        $pattern: /\b[\w\.]+/,
                                        keyword: function(e) {
                                            var u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                                n = u.exceptions,
                                                t = u.when;
                                            return n = n || [], e.map((function(e) {
                                                return e.match(/\|\d+$/) || n.includes(e) ? e : t(e) ? "".concat(e, "|0") : e
                                            }))
                                        }(s, {
                                            when: function(e) {
                                                return e.length < 3
                                            }
                                        }),
                                        literal: t,
                                        type: a,
                                        built_in: ["current_catalog", "current_date", "current_default_transform_group", "current_path", "current_role", "current_schema", "current_transform_group_for_type", "current_user", "session_user", "system_time", "system_user", "current_time", "localtime", "current_timestamp", "localtimestamp"]
                                    },
                                    contains: [{
                                        begin: u.either.apply(u, i),
                                        relevance: 0,
                                        keywords: {
                                            $pattern: /[\w\.]+/,
                                            keyword: s.concat(i),
                                            literal: t,
                                            type: a
                                        }
                                    }, {
                                        className: "type",
                                        begin: u.either.apply(u, ["double precision", "large object", "with timezone", "without timezone"])
                                    }, o, {
                                        className: "variable",
                                        begin: /@[a-z0-9][a-z0-9_]*/
                                    }, {
                                        className: "string",
                                        variants: [{
                                            begin: /'/,
                                            end: /'/,
                                            contains: [{
                                                begin: /''/
                                            }]
                                        }]
                                    }, {
                                        begin: /"/,
                                        end: /"/,
                                        contains: [{
                                            begin: /""/
                                        }]
                                    }, e.C_NUMBER_MODE, e.C_BLOCK_COMMENT_MODE, n, {
                                        className: "operator",
                                        begin: /[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,
                                        relevance: 0
                                    }]
                                }
                            },
                            grmr_swift: function(e) {
                                var u = {
                                        match: /\s+/,
                                        relevance: 0
                                    },
                                    n = e.COMMENT("/\\*", "\\*/", {
                                        contains: ["self"]
                                    }),
                                    t = [e.C_LINE_COMMENT_MODE, n],
                                    a = {
                                        match: [/\./, B.apply(void 0, o(Pe).concat(o(Ue)))],
                                        className: {
                                            2: "keyword"
                                        }
                                    },
                                    r = {
                                        match: f(/\./, B.apply(void 0, Ke)),
                                        relevance: 0
                                    },
                                    i = Ke.filter((function(e) {
                                        return "string" == typeof e
                                    })).concat(["_|0"]),
                                    D = Ke.filter((function(e) {
                                        return "string" != typeof e
                                    })).concat($e).map(je),
                                    s = {
                                        variants: [{
                                            className: "keyword",
                                            match: B.apply(void 0, o(D).concat(o(Ue)))
                                        }]
                                    },
                                    l = {
                                        $pattern: B(/\b\w+/, /#\w+/),
                                        keyword: i.concat(Ze),
                                        literal: qe
                                    },
                                    d = [a, r, s],
                                    E = [{
                                        match: f(/\./, B.apply(void 0, Ge)),
                                        relevance: 0
                                    }, {
                                        className: "built_in",
                                        match: f(/\b/, B.apply(void 0, Ge), /(?=\()/)
                                    }],
                                    F = {
                                        match: /->/,
                                        relevance: 0
                                    },
                                    A = [F, {
                                        className: "operator",
                                        relevance: 0,
                                        variants: [{
                                            match: Ve
                                        }, {
                                            match: "\\.(\\.|".concat(Qe, ")+")
                                        }]
                                    }],
                                    C = "([0-9]_*)+",
                                    g = "([0-9a-fA-F]_*)+",
                                    m = {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            match: "\\b(".concat(C, ")(\\.(").concat(C, "))?") + "([eE][+-]?(".concat(C, "))?\\b")
                                        }, {
                                            match: "\\b0x(".concat(g, ")(\\.(").concat(g, "))?") + "([pP][+-]?(".concat(C, "))?\\b")
                                        }, {
                                            match: /\b0o([0-7]_*)+\b/
                                        }, {
                                            match: /\b0b([01]_*)+\b/
                                        }]
                                    },
                                    p = function() {
                                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                                        return {
                                            className: "subst",
                                            variants: [{
                                                match: f(/\\/, e, /[0\\tnr"']/)
                                            }, {
                                                match: f(/\\/, e, /u\{[0-9a-fA-F]{1,8}\}/)
                                            }]
                                        }
                                    },
                                    h = function() {
                                        return {
                                            className: "subst",
                                            match: f(/\\/, arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", /[\t ]*(?:[\r\n]|\r\n)/)
                                        }
                                    },
                                    _ = function() {
                                        return {
                                            className: "subst",
                                            label: "interpol",
                                            begin: f(/\\/, arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", /\(/),
                                            end: /\)/
                                        }
                                    },
                                    v = function() {
                                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                                        return {
                                            begin: f(e, /"""/),
                                            end: f(/"""/, e),
                                            contains: [p(e), h(e), _(e)]
                                        }
                                    },
                                    y = function() {
                                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                                        return {
                                            begin: f(e, /"/),
                                            end: f(/"/, e),
                                            contains: [p(e), _(e)]
                                        }
                                    },
                                    w = {
                                        className: "string",
                                        variants: [v(), v("#"), v("##"), v("###"), y(), y("#"), y("##"), y("###")]
                                    },
                                    N = [e.BACKSLASH_ESCAPE, {
                                        begin: /\[/,
                                        end: /\]/,
                                        relevance: 0,
                                        contains: [e.BACKSLASH_ESCAPE]
                                    }],
                                    x = {
                                        begin: /\/[^\s](?=[^/\n]*\/)/,
                                        end: /\//,
                                        contains: N
                                    },
                                    k = function(e) {
                                        var u = f(e, /\//),
                                            n = f(/\//, e);
                                        return {
                                            begin: u,
                                            end: n,
                                            contains: [].concat(N, [{
                                                scope: "comment",
                                                begin: "#(?!.*".concat(n, ")"),
                                                end: /$/
                                            }])
                                        }
                                    },
                                    O = {
                                        scope: "regexp",
                                        variants: [k("###"), k("##"), k("#"), x]
                                    },
                                    M = {
                                        match: f(/`/, Ye, /`/)
                                    },
                                    S = [M, {
                                        className: "variable",
                                        match: /\$\d+/
                                    }, {
                                        className: "variable",
                                        match: "\\$".concat(Je, "+")
                                    }],
                                    T = [{
                                        match: /(@|#(un)?)available/,
                                        scope: "keyword",
                                        starts: {
                                            contains: [{
                                                begin: /\(/,
                                                end: /\)/,
                                                keywords: nu,
                                                contains: [].concat(A, [m, w])
                                            }]
                                        }
                                    }, {
                                        scope: "keyword",
                                        match: f(/@/, B.apply(void 0, uu))
                                    }, {
                                        scope: "meta",
                                        match: f(/@/, Ye)
                                    }],
                                    R = {
                                        match: b(/\b[A-Z]/),
                                        relevance: 0,
                                        contains: [{
                                            className: "type",
                                            match: f(/(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)/, Je, "+")
                                        }, {
                                            className: "type",
                                            match: eu,
                                            relevance: 0
                                        }, {
                                            match: /[?!]+/,
                                            relevance: 0
                                        }, {
                                            match: /\.\.\./,
                                            relevance: 0
                                        }, {
                                            match: f(/\s+&\s+/, b(eu)),
                                            relevance: 0
                                        }]
                                    },
                                    I = {
                                        begin: /</,
                                        end: />/,
                                        keywords: l,
                                        contains: [].concat(t, d, T, [F, R])
                                    };
                                R.contains.push(I);
                                var L, z = {
                                        begin: /\(/,
                                        end: /\)/,
                                        relevance: 0,
                                        keywords: l,
                                        contains: ["self", {
                                            match: f(Ye, /\s*:/),
                                            keywords: "_|0",
                                            relevance: 0
                                        }].concat(t, [O], d, E, A, [m, w], S, T, [R])
                                    },
                                    j = {
                                        begin: /</,
                                        end: />/,
                                        keywords: "repeat each",
                                        contains: [].concat(t, [R])
                                    },
                                    P = {
                                        begin: /\(/,
                                        end: /\)/,
                                        keywords: l,
                                        contains: [{
                                            begin: B(b(f(Ye, /\s*:/)), b(f(Ye, /\s+/, Ye, /\s*:/))),
                                            end: /:/,
                                            relevance: 0,
                                            contains: [{
                                                className: "keyword",
                                                match: /\b_\b/
                                            }, {
                                                className: "params",
                                                match: Ye
                                            }]
                                        }].concat(t, d, A, [m, w], T, [R, z]),
                                        endsParent: !0,
                                        illegal: /["']/
                                    },
                                    U = {
                                        match: [/(func|macro)/, /\s+/, B(M.match, Ye, Ve)],
                                        className: {
                                            1: "keyword",
                                            3: "title.function"
                                        },
                                        contains: [j, P, u],
                                        illegal: [/\[/, /%/]
                                    },
                                    $ = {
                                        match: [/\b(?:subscript|init[?!]?)/, /\s*(?=[<(])/],
                                        className: {
                                            1: "keyword"
                                        },
                                        contains: [j, P, u],
                                        illegal: /\[|%/
                                    },
                                    K = {
                                        match: [/operator/, /\s+/, Ve],
                                        className: {
                                            1: "keyword",
                                            3: "title"
                                        }
                                    },
                                    q = {
                                        begin: [/precedencegroup/, /\s+/, eu],
                                        className: {
                                            1: "keyword",
                                            3: "title"
                                        },
                                        contains: [R],
                                        keywords: [].concat(He, qe),
                                        end: /}/
                                    },
                                    H = function(e, u) {
                                        var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                        if (!n) {
                                            if (Array.isArray(e) || (n = c(e)) || u && e && "number" == typeof e.length) {
                                                n && (e = n);
                                                var t = 0,
                                                    a = function() {};
                                                return {
                                                    s: a,
                                                    n: function() {
                                                        return t >= e.length ? {
                                                            done: !0
                                                        } : {
                                                            done: !1,
                                                            value: e[t++]
                                                        }
                                                    },
                                                    e: function(e) {
                                                        throw e
                                                    },
                                                    f: a
                                                }
                                            }
                                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                        }
                                        var r, i = !0,
                                            D = !1;
                                        return {
                                            s: function() {
                                                n = n.call(e)
                                            },
                                            n: function() {
                                                var e = n.next();
                                                return i = e.done, e
                                            },
                                            e: function(e) {
                                                D = !0, r = e
                                            },
                                            f: function() {
                                                try {
                                                    i || null == n.return || n.return()
                                                } finally {
                                                    if (D) throw r
                                                }
                                            }
                                        }
                                    }(w.variants);
                                try {
                                    for (H.s(); !(L = H.n()).done;) {
                                        var Z = L.value.contains.find((function(e) {
                                            return "interpol" === e.label
                                        }));
                                        Z.keywords = l;
                                        var G = [].concat(d, E, A, [m, w], S);
                                        Z.contains = [].concat(o(G), [{
                                            begin: /\(/,
                                            end: /\)/,
                                            contains: ["self"].concat(o(G))
                                        }])
                                    }
                                } catch (e) {
                                    H.e(e)
                                } finally {
                                    H.f()
                                }
                                return {
                                    name: "Swift",
                                    keywords: l,
                                    contains: [].concat(t, [U, $, {
                                        beginKeywords: "struct protocol class extension enum actor",
                                        end: "\\{",
                                        excludeEnd: !0,
                                        keywords: l,
                                        contains: [e.inherit(e.TITLE_MODE, {
                                            className: "title.class",
                                            begin: /[A-Za-z$_][\u00C0-\u02B80-9A-Za-z$_]*/
                                        })].concat(d)
                                    }, K, q, {
                                        beginKeywords: "import",
                                        end: /$/,
                                        contains: [].concat(t),
                                        relevance: 0
                                    }, O], d, E, A, [m, w], S, T, [R, z])
                                }
                            },
                            grmr_typescript: function(e) {
                                var u = ze(e),
                                    n = ve,
                                    t = ["any", "void", "number", "boolean", "string", "object", "never", "symbol", "bigint", "unknown"],
                                    a = {
                                        beginKeywords: "namespace",
                                        end: /\{/,
                                        excludeEnd: !0,
                                        contains: [u.exports.CLASS_REFERENCE]
                                    },
                                    r = {
                                        beginKeywords: "interface",
                                        end: /\{/,
                                        excludeEnd: !0,
                                        keywords: {
                                            keyword: "interface extends",
                                            built_in: t
                                        },
                                        contains: [u.exports.CLASS_REFERENCE]
                                    },
                                    i = {
                                        $pattern: ve,
                                        keyword: ye.concat(["type", "namespace", "interface", "public", "private", "protected", "implements", "declare", "abstract", "readonly", "enum", "override"]),
                                        literal: we,
                                        built_in: Me.concat(t),
                                        "variable.language": Oe
                                    },
                                    D = {
                                        className: "meta",
                                        begin: "@" + n
                                    },
                                    s = function(e, u, n) {
                                        var t = e.contains.findIndex((function(e) {
                                            return e.label === u
                                        }));
                                        if (-1 === t) throw new Error("can not find mode to replace");
                                        e.contains.splice(t, 1, n)
                                    };
                                return Object.assign(u.keywords, i), u.exports.PARAMS_CONTAINS.push(D), u.contains = u.contains.concat([D, a, r]), s(u, "shebang", e.SHEBANG()), s(u, "use_strict", {
                                    className: "meta",
                                    relevance: 10,
                                    begin: /^\s*['"]use strict['"]/
                                }), u.contains.find((function(e) {
                                    return "func.def" === e.label
                                })).relevance = 0, Object.assign(u, {
                                    name: "TypeScript",
                                    aliases: ["ts", "tsx", "mts", "cts"]
                                }), u
                            },
                            grmr_vbnet: function(e) {
                                var u = e.regex,
                                    n = /\d{1,2}\/\d{1,2}\/\d{4}/,
                                    t = /\d{4}-\d{1,2}-\d{1,2}/,
                                    a = /(\d|1[012])(:\d+){0,2} *(AM|PM)/,
                                    r = /\d{1,2}(:\d{1,2}){1,2}/,
                                    i = {
                                        className: "literal",
                                        variants: [{
                                            begin: u.concat(/# */, u.either(t, n), / *#/)
                                        }, {
                                            begin: u.concat(/# */, r, / *#/)
                                        }, {
                                            begin: u.concat(/# */, a, / *#/)
                                        }, {
                                            begin: u.concat(/# */, u.either(t, n), / +/, u.either(a, r), / *#/)
                                        }]
                                    },
                                    D = e.COMMENT(/'''/, /$/, {
                                        contains: [{
                                            className: "doctag",
                                            begin: /<\/?/,
                                            end: />/
                                        }]
                                    }),
                                    s = e.COMMENT(null, /$/, {
                                        variants: [{
                                            begin: /'/
                                        }, {
                                            begin: /([\t ]|^)REM(?=\s)/
                                        }]
                                    });
                                return {
                                    name: "Visual Basic .NET",
                                    aliases: ["vb"],
                                    case_insensitive: !0,
                                    classNameAliases: {
                                        label: "symbol"
                                    },
                                    keywords: {
                                        keyword: "addhandler alias aggregate ansi as async assembly auto binary by byref byval call case catch class compare const continue custom declare default delegate dim distinct do each equals else elseif end enum erase error event exit explicit finally for friend from function get global goto group handles if implements imports in inherits interface into iterator join key let lib loop me mid module mustinherit mustoverride mybase myclass namespace narrowing new next notinheritable notoverridable of off on operator option optional order overloads overridable overrides paramarray partial preserve private property protected public raiseevent readonly redim removehandler resume return select set shadows shared skip static step stop structure strict sub synclock take text then throw to try unicode until using when where while widening with withevents writeonly yield",
                                        built_in: "addressof and andalso await directcast gettype getxmlnamespace is isfalse isnot istrue like mod nameof new not or orelse trycast typeof xor cbool cbyte cchar cdate cdbl cdec cint clng cobj csbyte cshort csng cstr cuint culng cushort",
                                        type: "boolean byte char date decimal double integer long object sbyte short single string uinteger ulong ushort",
                                        literal: "true false nothing"
                                    },
                                    illegal: "//|\\{|\\}|endif|gosub|variant|wend|^\\$ ",
                                    contains: [{
                                        className: "string",
                                        begin: /"(""|[^/n])"C\b/
                                    }, {
                                        className: "string",
                                        begin: /"/,
                                        end: /"/,
                                        illegal: /\n/,
                                        contains: [{
                                            begin: /""/
                                        }]
                                    }, i, {
                                        className: "number",
                                        relevance: 0,
                                        variants: [{
                                            begin: /\b\d[\d_]*((\.[\d_]+(E[+-]?[\d_]+)?)|(E[+-]?[\d_]+))[RFD@!#]?/
                                        }, {
                                            begin: /\b\d[\d_]*((U?[SIL])|[%&])?/
                                        }, {
                                            begin: /&H[\dA-F_]+((U?[SIL])|[%&])?/
                                        }, {
                                            begin: /&O[0-7_]+((U?[SIL])|[%&])?/
                                        }, {
                                            begin: /&B[01_]+((U?[SIL])|[%&])?/
                                        }]
                                    }, {
                                        className: "label",
                                        begin: /^\w+:/
                                    }, D, s, {
                                        className: "meta",
                                        begin: /[\t ]*#(const|disable|else|elseif|enable|end|externalsource|if|region)\b/,
                                        end: /$/,
                                        keywords: {
                                            keyword: "const disable else elseif enable end externalsource if region then"
                                        },
                                        contains: [s]
                                    }]
                                }
                            },
                            grmr_vhdl: function(e) {
                                var u = "\\d(_|\\d)*",
                                    n = "[eE][-+]?" + u,
                                    t = "\\b(" + (u + "#\\w+(\\.\\w+)?#(" + n + ")?") + "|" + (u + "(\\." + u + ")?(" + n + ")?") + ")";
                                return {
                                    name: "VHDL",
                                    case_insensitive: !0,
                                    keywords: {
                                        keyword: ["abs", "access", "after", "alias", "all", "and", "architecture", "array", "assert", "assume", "assume_guarantee", "attribute", "begin", "block", "body", "buffer", "bus", "case", "component", "configuration", "constant", "context", "cover", "disconnect", "downto", "default", "else", "elsif", "end", "entity", "exit", "fairness", "file", "for", "force", "function", "generate", "generic", "group", "guarded", "if", "impure", "in", "inertial", "inout", "is", "label", "library", "linkage", "literal", "loop", "map", "mod", "nand", "new", "next", "nor", "not", "null", "of", "on", "open", "or", "others", "out", "package", "parameter", "port", "postponed", "procedure", "process", "property", "protected", "pure", "range", "record", "register", "reject", "release", "rem", "report", "restrict", "restrict_guarantee", "return", "rol", "ror", "select", "sequence", "severity", "shared", "signal", "sla", "sll", "sra", "srl", "strong", "subtype", "then", "to", "transport", "type", "unaffected", "units", "until", "use", "variable", "view", "vmode", "vprop", "vunit", "wait", "when", "while", "with", "xnor", "xor"],
                                        built_in: ["boolean", "bit", "character", "integer", "time", "delay_length", "natural", "positive", "string", "bit_vector", "file_open_kind", "file_open_status", "std_logic", "std_logic_vector", "unsigned", "signed", "boolean_vector", "integer_vector", "std_ulogic", "std_ulogic_vector", "unresolved_unsigned", "u_unsigned", "unresolved_signed", "u_signed", "real_vector", "time_vector"],
                                        literal: ["false", "true", "note", "warning", "error", "failure", "line", "text", "side", "width"]
                                    },
                                    illegal: /\{/,
                                    contains: [e.C_BLOCK_COMMENT_MODE, e.COMMENT("--", "$"), e.QUOTE_STRING_MODE, {
                                        className: "number",
                                        begin: t,
                                        relevance: 0
                                    }, {
                                        className: "string",
                                        begin: "'(U|X|0|1|Z|W|L|H|-)'",
                                        contains: [e.BACKSLASH_ESCAPE]
                                    }, {
                                        className: "symbol",
                                        begin: "'[A-Za-z](_?[A-Za-z0-9])*",
                                        contains: [e.BACKSLASH_ESCAPE]
                                    }]
                                }
                            },
                            grmr_xml: function(e) {
                                var u = e.regex,
                                    n = u.concat(/(?:[A-Z_a-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD887][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF39\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD888[\uDC00-\uDFAF])/, u.optional(/(?:[\x2D\.0-9A-Z_a-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD887][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF39\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD888[\uDC00-\uDFAF])*:/), /(?:[\x2D\.0-9A-Z_a-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD887][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF39\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD888[\uDC00-\uDFAF])*/),
                                    t = {
                                        className: "symbol",
                                        begin: /&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/
                                    },
                                    a = {
                                        begin: /\s/,
                                        contains: [{
                                            className: "keyword",
                                            begin: /#?[a-z_][a-z1-9_-]+/,
                                            illegal: /\n/
                                        }]
                                    },
                                    r = e.inherit(a, {
                                        begin: /\(/,
                                        end: /\)/
                                    }),
                                    i = e.inherit(e.APOS_STRING_MODE, {
                                        className: "string"
                                    }),
                                    D = e.inherit(e.QUOTE_STRING_MODE, {
                                        className: "string"
                                    }),
                                    s = {
                                        endsWithParent: !0,
                                        illegal: /</,
                                        relevance: 0,
                                        contains: [{
                                            className: "attr",
                                            begin: /(?:[\x2D\.0-:A-Z_a-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD887][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF39\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD888[\uDC00-\uDFAF])+/,
                                            relevance: 0
                                        }, {
                                            begin: /=\s*/,
                                            relevance: 0,
                                            contains: [{
                                                className: "string",
                                                endsParent: !0,
                                                variants: [{
                                                    begin: /"/,
                                                    end: /"/,
                                                    contains: [t]
                                                }, {
                                                    begin: /'/,
                                                    end: /'/,
                                                    contains: [t]
                                                }, {
                                                    begin: /[^\s"'=<>`]+/
                                                }]
                                            }]
                                        }]
                                    };
                                return {
                                    name: "HTML, XML",
                                    aliases: ["html", "xhtml", "rss", "atom", "xjb", "xsd", "xsl", "plist", "wsf", "svg"],
                                    case_insensitive: !0,
                                    unicodeRegex: !0,
                                    contains: [{
                                        className: "meta",
                                        begin: /<![a-z]/,
                                        end: />/,
                                        relevance: 10,
                                        contains: [a, D, i, r, {
                                            begin: /\[/,
                                            end: /\]/,
                                            contains: [{
                                                className: "meta",
                                                begin: /<![a-z]/,
                                                end: />/,
                                                contains: [a, r, D, i]
                                            }]
                                        }]
                                    }, e.COMMENT(/<!--/, /-->/, {
                                        relevance: 10
                                    }), {
                                        begin: /<!\[CDATA\[/,
                                        end: /\]\]>/,
                                        relevance: 10
                                    }, t, {
                                        className: "meta",
                                        end: /\?>/,
                                        variants: [{
                                            begin: /<\?xml/,
                                            relevance: 10,
                                            contains: [D]
                                        }, {
                                            begin: /<\?[a-z][a-z0-9]+/
                                        }]
                                    }, {
                                        className: "tag",
                                        begin: /<style(?=\s|>)/,
                                        end: />/,
                                        keywords: {
                                            name: "style"
                                        },
                                        contains: [s],
                                        starts: {
                                            end: /<\/style>/,
                                            returnEnd: !0,
                                            subLanguage: ["css", "xml"]
                                        }
                                    }, {
                                        className: "tag",
                                        begin: /<script(?=\s|>)/,
                                        end: />/,
                                        keywords: {
                                            name: "script"
                                        },
                                        contains: [s],
                                        starts: {
                                            end: /<\/script>/,
                                            returnEnd: !0,
                                            subLanguage: ["javascript", "handlebars", "xml"]
                                        }
                                    }, {
                                        className: "tag",
                                        begin: /<>|<\/>/
                                    }, {
                                        className: "tag",
                                        begin: u.concat(/</, u.lookahead(u.concat(n, u.either(/\/>/, />/, /\s/)))),
                                        end: /\/?>/,
                                        contains: [{
                                            className: "name",
                                            begin: n,
                                            relevance: 0,
                                            starts: s
                                        }]
                                    }, {
                                        className: "tag",
                                        begin: u.concat(/<\//, u.lookahead(u.concat(n, />/))),
                                        contains: [{
                                            className: "name",
                                            begin: n,
                                            relevance: 0
                                        }, {
                                            begin: />/,
                                            relevance: 0,
                                            endsParent: !0
                                        }]
                                    }]
                                }
                            },
                            grmr_yaml: function(e) {
                                var u = "true false yes no null",
                                    n = "[\\w#;/?:@&=+$,.~*'()[\\]]+",
                                    t = {
                                        className: "string",
                                        relevance: 0,
                                        variants: [{
                                            begin: /'/,
                                            end: /'/
                                        }, {
                                            begin: /"/,
                                            end: /"/
                                        }, {
                                            begin: /\S+/
                                        }],
                                        contains: [e.BACKSLASH_ESCAPE, {
                                            className: "template-variable",
                                            variants: [{
                                                begin: /\{\{/,
                                                end: /\}\}/
                                            }, {
                                                begin: /%\{/,
                                                end: /\}/
                                            }]
                                        }]
                                    },
                                    a = e.inherit(t, {
                                        variants: [{
                                            begin: /'/,
                                            end: /'/
                                        }, {
                                            begin: /"/,
                                            end: /"/
                                        }, {
                                            begin: /[^\s,{}[\]]+/
                                        }]
                                    }),
                                    r = {
                                        className: "number",
                                        begin: "\\b[0-9]{4}(-[0-9][0-9]){0,2}([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?(\\.[0-9]*)?([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?\\b"
                                    },
                                    i = {
                                        end: ",",
                                        endsWithParent: !0,
                                        excludeEnd: !0,
                                        keywords: u,
                                        relevance: 0
                                    },
                                    D = {
                                        begin: /\{/,
                                        end: /\}/,
                                        contains: [i],
                                        illegal: "\\n",
                                        relevance: 0
                                    },
                                    s = {
                                        begin: "\\[",
                                        end: "\\]",
                                        contains: [i],
                                        illegal: "\\n",
                                        relevance: 0
                                    },
                                    o = [{
                                        className: "attr",
                                        variants: [{
                                            begin: "\\w[\\w :\\/.-]*:(?=[ \t]|$)"
                                        }, {
                                            begin: '"\\w[\\w :\\/.-]*":(?=[ \t]|$)'
                                        }, {
                                            begin: "'\\w[\\w :\\/.-]*':(?=[ \t]|$)"
                                        }]
                                    }, {
                                        className: "meta",
                                        begin: "^---\\s*$",
                                        relevance: 10
                                    }, {
                                        className: "string",
                                        begin: "[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*"
                                    }, {
                                        begin: "<%[%=-]?",
                                        end: "[%-]?%>",
                                        subLanguage: "ruby",
                                        excludeBegin: !0,
                                        excludeEnd: !0,
                                        relevance: 0
                                    }, {
                                        className: "type",
                                        begin: "!\\w+!" + n
                                    }, {
                                        className: "type",
                                        begin: "!<" + n + ">"
                                    }, {
                                        className: "type",
                                        begin: "!" + n
                                    }, {
                                        className: "type",
                                        begin: "!!" + n
                                    }, {
                                        className: "meta",
                                        begin: "&" + e.UNDERSCORE_IDENT_RE + "$"
                                    }, {
                                        className: "meta",
                                        begin: "\\*" + e.UNDERSCORE_IDENT_RE + "$"
                                    }, {
                                        className: "bullet",
                                        begin: "-(?=[ ]|$)",
                                        relevance: 0
                                    }, e.HASH_COMMENT_MODE, {
                                        beginKeywords: u,
                                        keywords: {
                                            literal: u
                                        }
                                    }, r, {
                                        className: "number",
                                        begin: e.C_NUMBER_RE + "\\b",
                                        relevance: 0
                                    }, D, s, t],
                                    c = [].concat(o);
                                return c.pop(), c.push(a), i.contains = c, {
                                    name: "YAML",
                                    case_insensitive: !0,
                                    aliases: ["yml"],
                                    contains: o
                                }
                            }
                        }), au = ge, ru = 0, iu = Object.keys(tu); ru < iu.length; ru++) {
                        var Du = iu[ru],
                            su = Du.replace("grmr_", "").replace("_", "-");
                        au.registerLanguage(su, tu[Du])
                    }
                    return au
                }();
                "object" === C(u) && (e.exports = g)
            },
            68954: (e, u, n) => {
                var t = n(84124),
                    a = n(34160);
                void 0 === a.hljs && (a.hljs = t), e.exports = t
            },
            34160: (e, u, n) => {
                "use strict";
                e.exports = function() {
                    if ("object" == typeof globalThis) return globalThis;
                    var e;
                    try {
                        e = this || new Function("return this")()
                    } catch (e) {
                        if ("object" == typeof window) return window;
                        if ("object" == typeof self) return self;
                        if (void 0 !== n.g) return n.g
                    }
                    return e
                }()
            }
        },
        u = {};

    function n(t) {
        var a = u[t];
        if (void 0 !== a) return a.exports;
        var r = u[t] = {
            exports: {}
        };
        return e[t](r, r.exports, n), r.exports
    }
    n.n = e => {
        var u = e && e.__esModule ? () => e.default : () => e;
        return n.d(u, {
            a: u
        }), u
    }, n.d = (e, u) => {
        for (var t in u) n.o(u, t) && !n.o(e, t) && Object.defineProperty(e, t, {
            enumerable: !0,
            get: u[t]
        })
    }, n.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), n.o = (e, u) => Object.prototype.hasOwnProperty.call(e, u), n.p = "", (() => {
        "use strict";
        n.p = document.getElementById("webpack-public-path").innerText + "Js/"
    })(), (() => {
        "use strict";
        n(68954);
        class e {
            constructor() {
                this.originalStream = null
            }
            "before:highlightElement" ({
                el: e
            }) {
                this.originalStream = this.nodeStream(e)
            }
            "after:highlightElement" ({
                el: e,
                result: u,
                text: n
            }) {
                if (!this.originalStream.length) return;
                const t = document.createElement("div");
                t.innerHTML = u.value, u.value = this.mergeStreams(this.originalStream, this.nodeStream(t), n), e.innerHTML = u.value
            }
            nodeStream(e) {
                const n = [];
                return function e(a, r) {
                    for (let i = a.firstChild; i; i = i.nextSibling) i.nodeType === Node.TEXT_NODE ? r += i.nodeValue.length : i.nodeType === Node.ELEMENT_NODE && (n.push(new u("start", r, i)), r = e(i, r), t(i).match(/br|hr|img|input/) || n.push(new u("stop", r, i)));
                    return r
                }(e, 0), n
            }
            selectStream(e, u) {
                return e.length && u.length ? e[0].offset !== u[0].offset ? e[0].offset < u[0].offset ? e : u : "start" === u[0].event ? e : u : e.length ? e : u
            }
            mergeStreams(e, u, n) {
                let t = 0,
                    r = "";
                const i = [];
                for (; e.length || u.length;) {
                    let D = this.selectStream(e, u);
                    if (r += a(n.substring(t, D[0].offset)), t = D[0].offset, D === e) {
                        i.reverse().forEach((e => r += e.close()));
                        do {
                            r += D.splice(0, 1)[0].render(), D = this.selectStream(e, u)
                        } while (D === e && D.length && D[0].offset === t);
                        i.reverse().forEach((e => r += e.open()))
                    } else "start" === D[0].event ? i.push(D[0]) : i.pop(), r += D.splice(0, 1)[0].render()
                }
                return r + a(n.substr(t))
            }
        }
        class u {
            constructor(e, u, n) {
                this.event = e, this.offset = u, this.node = n
            }
            open() {
                return "<" + t(this.node) + [].map.call(this.node.attributes, this.attributeString).join("") + ">"
            }
            close() {
                return "</" + t(this.node) + ">"
            }
            render() {
                return "start" === this.event ? this.open() : this.close()
            }
            attributeString(e) {
                return " " + e.nodeName + '="' + a(e.value) + '"'
            }
        }

        function t(e) {
            return e.nodeName.toLowerCase()
        }

        function a(e) {
            return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;")
        }
        const r = window.jQuery;
        var i = n.n(r);

        function D(e) {
            const u = i()(e);
            return u.extend({
                With(e) {
                    return i()(this).clone().addClass(e)
                },
                WithAttr(e) {
                    const u = i()(this).clone();
                    return u.attr(e), u
                }
            }), u
        }
        class s {
            "after:highlightElement" ({
                el: e,
                _: u,
                text: n
            }) {
                if (function(e) {
                        let u = C(e);
                        return null != u && null != d(u) && function(e) {
                            let u = e.closest("[data-author-username]");
                            if (!u) return null;
                            let n = u.getAttribute("data-should-show-copy-button");
                            return null != u.getAttribute("data-author-username") && "True" == n
                        }(e) && null != A(e)
                    }(e.parentElement)) {
                    let u = C(e.parentElement);
                    ! function(e) {
                        const u = '<div class="mtn4 d-flex jc-end ps-sticky l0 mrn4" data-nosnippet><button class="py2 mb2 s-btn s-btn__muted s-btn__xs fs-caption ff-sans d-flex ai-center js-copy-button fc-black-400 h:fc-black-500 f:bg-black-200" type="button">' + __tr(["Copy"], undefined, "en", []) + "</button></div>";
                        e.insertAdjacentHTML("afterbegin", u), F(e.getElementsByClassName("js-copy-button")[0], c.outerHTML)
                    }(e.parentElement), e.parentElement.getElementsByClassName("js-copy-button")[0].addEventListener("click", (n => {
                        ! function(e, u) {
                            let n = function(e) {
                                    let u = e.closest("[data-author-username]");
                                    if (!u) return null;
                                    return u.getAttribute("data-author-username")
                                }(e),
                                t = A(e),
                                a = function(e) {
                                    const u = window.location.href;
                                    let n = e.closest("[data-author-username]");
                                    if (!n) return u;
                                    let t = n.querySelector("a.js-share-link");
                                    if (!t) return u;
                                    let a = t.getAttribute("href");
                                    if (!a) return u;
                                    if (a.split("/").filter((e => e.length > 0)).length >= 3) {
                                        const e = a.lastIndexOf("/");
                                        a = a.slice(0, e)
                                    }
                                    return `${window.location.origin}${a}`
                                }(e),
                                r = function(e) {
                                    let u = e.closest("[data-is-edited]");
                                    if (!u) return !1;
                                    return "True" == u.getAttribute("data-is-edited")
                                }(e),
                                i = function(e, u, n, t, a, r) {
                                    let i = (new Date).toLocaleDateString("en-ca"),
                                        D = `Source - ${a}\r\nPosted by ${n}${r?", modified by community. See post 'Timeline' for change history":""}\r\nRetrieved ${i}, License - ${t}`;
                                    return D = function(e, u) {
                                        const n = d(e);
                                        if (!n) return void console.warn(`Unsupported language: ${e}`);
                                        return n.end ? `${n.start}\n${u}\n${n.end}` : u.split("\n").map((e => `${n.start} ${e}`)).join("\n")
                                    }(e, D), `${D}\r\n\r\n${u}`
                                }(u, e.textContent, n, t, a, r);
                            navigator.clipboard.writeText(i),
                                function(e) {
                                    if ("undefined" == typeof ClipboardEvent) return void console.warn("ClipboardEvent is undefined. Skipping clipboard event logic.");
                                    const u = new ClipboardEvent("copy", {
                                        bubbles: !0,
                                        cancelable: !0
                                    });
                                    e.dispatchEvent(u)
                                }(e),
                                function(e) {
                                    E(e), e.textContent = __tr(["Copied with attribution"], undefined, "en", []), F(e, l.outerHTML), setTimeout((() => {
                                        E(e), e.textContent = __tr(["Copy"], undefined, "en", []), F(e, c.outerHTML)
                                    }), 3e3)
                                }(e.parentElement.querySelector(".js-copy-button"))
                        }(e, u)
                    }))
                }
            }
        }
        const o = "language-",
            c = D('<svg aria-hidden="true" class="svg-icon iconCopy" width="17" height="18"  viewBox="0 0 17 18"><path  d="M5 6c0-1.09.91-2 2-2h4.5L15 7.5V15c0 1.09-.91 2-2 2H7c-1.09 0-2-.91-2-2zm6-1.25V8h3.25z"/><path  d="M10 1a2 2 0 0 1 2 2H6a2 2 0 0 0-2 2v9a2 2 0 0 1-2-2V4a3 3 0 0 1 3-3z" opacity=".4"/></svg>').With("mr4")[0],
            l = D('<svg aria-hidden="true" class="svg-icon iconCheckmark" width="18" height="18"  viewBox="0 0 18 18"><path  d="M16 4.41 14.59 3 6 11.59 2.41 8 1 9.41l5 5z"/></svg>').With("mr4")[0];

        function d(e) {
            return g[e]
        }

        function E(e) {
            const u = e.querySelector("svg");
            u && e.removeChild(u)
        }

        function F(e, u) {
            e.insertAdjacentHTML("afterbegin", u)
        }

        function A(e) {
            let u = e.closest("[data-se-share-sheet-license-name]");
            return u ? u.getAttribute("data-se-share-sheet-license-name") : null
        }

        function C(e, u = !1) {
            var n;
            if (null == e.firstElementChild) return null;
            const t = Array.from(e.firstElementChild.classList).find((e => e.startsWith(o)));
            let a = null !== (n = null == t ? void 0 : t.substring(o.length)) && void 0 !== n ? n : null;
            return u && (a = function(e, u) {
                if ("xml" == e && u.classList.contains("lang-html")) return "html";
                return e
            }(a, e)), a
        }
        const g = {
            bash: {
                start: "#",
                end: void 0
            },
            c: {
                start: "//",
                end: void 0
            },
            cpp: {
                start: "//",
                end: void 0
            },
            csharp: {
                start: "//",
                end: void 0
            },
            css: {
                start: "/*",
                end: "*/"
            },
            clojure: {
                start: ";",
                end: void 0
            },
            coffeescript: {
                start: "#",
                end: void 0
            },
            dart: {
                start: "//",
                end: void 0
            },
            delphi: {
                start: "(*",
                end: "*)"
            },
            dpr: {
                start: "//",
                end: void 0
            },
            erlang: {
                start: "%",
                end: void 0
            },
            go: {
                start: "//",
                end: void 0
            },
            xml: {
                start: "\x3c!--",
                end: "--\x3e"
            },
            haskell: {
                start: "--",
                end: void 0
            },
            ini: {
                start: "#",
                end: void 0
            },
            java: {
                start: "//",
                end: void 0
            },
            javascript: {
                start: "//",
                end: void 0
            },
            julia: {
                start: "#",
                end: void 0
            },
            kotlin: {
                start: "//",
                end: void 0
            },
            tex: {
                start: "%",
                end: void 0
            },
            latex: {
                start: "%",
                end: void 0
            },
            less: {
                start: "/*",
                end: "*/"
            },
            lisp: {
                start: ";",
                end: void 0
            },
            lua: {
                start: "--",
                end: void 0
            },
            markdown: {
                start: "\x3c!--",
                end: "--\x3e"
            },
            mathematica: {
                start: "(*",
                end: "*)"
            },
            matlab: {
                start: "%",
                end: void 0
            },
            ocaml: {
                start: "(*",
                end: "*)"
            },
            objectivec: {
                start: "//",
                end: void 0
            },
            php: {
                start: "//",
                end: void 0
            },
            "php-template": {
                start: "//",
                end: void 0
            },
            perl: {
                start: "#",
                end: void 0
            },
            protobuf: {
                start: "//",
                end: void 0
            },
            python: {
                start: "#",
                end: void 0
            },
            r: {
                start: "#",
                end: void 0
            },
            ruby: {
                start: "#",
                end: void 0
            },
            rust: {
                start: "//",
                end: void 0
            },
            scss: {
                start: "//",
                end: void 0
            },
            sql: {
                start: "--",
                end: void 0
            },
            scala: {
                start: "//",
                end: void 0
            },
            scheme: {
                start: ";",
                end: void 0
            },
            shell: {
                start: "#",
                end: void 0
            },
            swift: {
                start: "//",
                end: void 0
            },
            typescript: {
                start: "//",
                end: void 0
            },
            vbnet: {
                start: "'",
                end: void 0
            },
            vbscript: {
                start: "'",
                end: void 0
            },
            vhdl: {
                start: "--",
                end: void 0
            },
            yaml: {
                start: "#",
                end: void 0
            }
        };
        var b, m;
        StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.highlightjs = (b = {
            none: "plaintext",
            bsh: "bash",
            csh: "bash",
            sh: "bash",
            cc: "cpp",
            cxx: "cpp",
            cyc: "c",
            m: "c",
            "c-like": "c",
            cs: "csharp",
            coffee: "coffeescript",
            html: "xml",
            xsl: "xml",
            js: "javascript",
            pl: "perl",
            py: "python",
            cv: "python",
            rb: "ruby",
            clj: "clojure",
            erl: "erlang",
            hs: "haskell",
            mma: "mathematica",
            tex: "latex",
            cl: "lisp",
            el: "lisp",
            lsp: "lisp",
            scm: "scheme",
            ss: "scheme",
            rkt: "scheme",
            fs: "ocaml",
            ml: "ocaml",
            s: "r",
            rc: "rust",
            rs: "rust",
            vb: "vbnet",
            vbs: "vbnet",
            vhd: "vhdl"
        }, m = window.hljs, Object.keys(b).forEach((function(e) {
            m.registerAliases(e, {
                languageName: b[e]
            })
        })), m.configure({
            noHighlightRe: /^none$/,
            ignoreUnescapedHTML: !0
        }), m.addPlugin({
            "before:highlight": function(e) {
                "no-highlight" === e.language && (e.result = m.highlightAuto(e.code))
            }
        }), m.addPlugin(new e), m.addPlugin(new s), m.addPlugin({
            "after:highlightElement": function(e) {
                var u = "CODE" === e.el.tagName ? e.el.parentElement : e.el,
                    n = /linenums(:\d+)?/.exec(u);
                if (n) {
                    var t = 1;
                    n[1] && (t = +n[1].slice(1));
                    var a = e.el.innerText.trim().split(/\r?\n/),
                        r = document.createElement("code");
                    r.classList.add("s-code-block--line-numbers");
                    for (var i = 0; i < a.length; i++) {
                        var D = document.createElement("div");
                        D.innerText = i + t, r.append(D)
                    }
                    u.prepend(r)
                }
            }
        }), {
            instance: m
        }), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}
    })()
})();