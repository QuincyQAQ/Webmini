(() => {
    var t = {
            89621: () => {
                StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange.gps = function() {
                    if (StackExchange.gps && StackExchange.gps.inited) return StackExchange.gps;
                    var t = {};

                    function e() {
                        return StackExchange && StackExchange.options && StackExchange.options.site && StackExchange.options.site.routePrefix && StackExchange.options.site.routePrefix.length ? StackExchange.options.site.routePrefix : ""
                    }

                    function a(t, e, a, n) {
                        $(t).find(e).each((function() {
                            var t = $(this).find(a);
                            t.each((function(e) {
                                var a;
                                $(this).addClass("js-gps-track").data("gps-track", "question_tags.click({ " + (a = {
                                    tagName: $(this).text(),
                                    position_in_list: e + 1,
                                    total_number_in_list: t.length,
                                    ...n
                                }, (Object.entries(a).map((([t, e]) => `${t}:${e}`)).join(", ") ? ? "") + " })"))
                            }))
                        }))
                    }

                    function n(t) {
                        p("bindTrackClicks bound {0} elements in {1}", $(t || document).find(".js-gps-track").off("click.gps").one("click.gps", (function() {
                            var t = $(this).data("gps-track") ? .trim();
                            if (t)
                                for (var e = o(t), a = 0; a < e.length; a++) {
                                    var n = e[a];
                                    StackExchange.gps.track(n[0], n[1], !0)
                                }
                        })).length, t || "document")
                    }

                    function o(t) {
                        for (var e = [], a = t.match(/([a-z._-]+)(\([^)]+\))?/gi), n = 0; n < a.length; n++) {
                            var o = a[n];
                            if (o.indexOf("{") < 0) e.push([o, {}]);
                            else {
                                for (var i = o.match(/([a-z._-]+)\s*\(\s*\{([^}]+)\}\s*\)/i) || [], s = i[1], r = (i[2].trim() || "").match(/[^,]+/gi) || [], c = {}, g = 0; g < r.length; g++) {
                                    var p = r[g],
                                        l = p.indexOf(":"),
                                        u = p.substr(0, l).trim(),
                                        d = f(p.substr(l + 1).trim());
                                    c[u] = d
                                }
                                e.push([s, c])
                            }
                        }
                        return e;

                        function f(t) {
                            if ("true" === t) return !0;
                            if ("false" === t) return !1;
                            if ("'" === t[0] || '"' === t[0]) return t.substring(1, t.length - 1);
                            var e = parseFloat(t);
                            return isNaN(e) ? t : e
                        }
                    }

                    function i(a) {
                        var n = function() {
                            var t = r(),
                                e = localStorage[t];
                            return e ? JSON.parse(e) : []
                        }();
                        if (n.length > 0) {
                            for (var o = (new Date).getTime(), i = [], s = 0; s < n.length && i.length < 20; s++) {
                                var c = n[s],
                                    l = o - c.now;
                                l < 0 || l > 36e5 ? g(c) : i.push(c)
                            }
                            i.length > 0 ? function(a, n) {
                                Array.isArray(a) || (a = [a]);
                                for (var o = 0; o < a.length; o++) {
                                    var i = JSON.stringify(a[o]);
                                    t[i] && (a.splice(o, 1), o--)
                                }
                                for (o = 0; o < a.length; o++) {
                                    i = JSON.stringify(a[o]);
                                    t[i] = !0
                                }
                                var s = JSON.stringify(a);
                                if (navigator && navigator.sendBeacon) try {
                                    p("sending (beacon): " + s);
                                    var r = e() + "/gps/event";
                                    if (navigator && navigator.sendBeacon(r, s)) {
                                        for (o = 0; o < a.length; o++) {
                                            g(a[o]);
                                            i = JSON.stringify(a[o]);
                                            delete t[i]
                                        }
                                        return void(n && n())
                                    }
                                } catch (t) {
                                    p(t)
                                }
                                p("sending (AJAX): " + s), $.ajax({
                                    type: "POST",
                                    url: "/gps/event",
                                    data: {
                                        data: s
                                    },
                                    success: function(t, e, n) {
                                        for (var o = 0; o < a.length; o++) g(a[o])
                                    },
                                    complete: function() {
                                        for (var e = 0; e < a.length; e++) {
                                            var o = JSON.stringify(a[e]);
                                            delete t[o]
                                        }
                                        n && n()
                                    }
                                })
                            }(i, a) : a && a()
                        }
                    }

                    function s(t, e, a, n) {
                        c({
                            evt: t,
                            properties: e || {},
                            now: (new Date).getTime()
                        }), navigator && navigator.sendBeacon && (a = !1), a ? (n && n(), window.setTimeout(i, 1e4)) : i(n)
                    }

                    function r() {
                        return "gps-pending" + e()
                    }

                    function c(t) {
                        var e;
                        (e = t) && StackExchange.options && StackExchange.options.user && (e.properties && !e.properties.user_type && (e.properties.user_type = StackExchange.options.user.user_type), !e.ab && StackExchange.options.user.ab && (e.ab = StackExchange.options.user.ab));
                        var a, n = r(),
                            o = localStorage[n];
                        if (o) {
                            var i = JSON.parse(o);
                            i.push(t), a = JSON.stringify(i)
                        } else a = JSON.stringify([t]);
                        p("addToPending " + JSON.stringify(t)), localStorage[n] = a
                    }

                    function g(t) {
                        var e = r(),
                            a = localStorage[e];
                        if (a) {
                            for (var n = JSON.parse(a), o = JSON.stringify(t), i = -1, s = 0; s < n.length; s++) {
                                if (o == JSON.stringify(n[s])) {
                                    i = s;
                                    break
                                }
                            } - 1 != i && (n.splice(i, 1), 0 != n.length ? localStorage[e] = JSON.stringify(n) : localStorage.removeItem(e))
                        }
                    }

                    function p(t) {
                        if ((StackExchange.options && StackExchange.options.enableLogging || $.cookie("devlog")) && "string" == typeof t) {
                            if (arguments.length > 1) {
                                var e = Array.prototype.slice.call(arguments, 1);
                                t = String.prototype.formatUnicorn.apply(t, e)
                            }
                            console.log("gps: " + t)
                        }
                    }
                    return {
                        inited: !1,
                        init: function(t) {
                            return !!StackExchange.gps.inited || (StackExchange.gps.inited = !0, t && function() {
                                try {
                                    if (!window.localStorage) return !1;
                                    if (window.localStorage["gps-probe"] = "1", "1" != window.localStorage["gps-probe"]) return !1;
                                    window.localStorage.removeItem("gps-probe")
                                } catch (t) {
                                    return !1
                                }
                                return !0
                            }() ? (StackExchange.gps.sendPending = i, StackExchange.gps.track = s, StackExchange._gps_track && ($.each(StackExchange._gps_track, (function(t, e) {
                                c(e)
                            })), delete StackExchange._gps_track), i(), e = ".js-gps-related-tags .post-tag", o = "related_tags.click", r = ", item_type:1", $(".tagged-questions-page, .questions-page, .tags-page").find(e).each((function(t) {
                                $(this).addClass("js-gps-track").data("gps-track", o + "({ position:" + (t + 1) + r + " })")
                            })), a(".home-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 1,
                                location_on_page: 1
                            }), a(".home-page", "#recent-tags-list", ".post-tag", {
                                page: 1,
                                location_on_page: 2
                            }), a(".home-page", "#watched-tags-list", ".s-tag", {
                                page: 1,
                                location_on_page: 9
                            }), a(".questions-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 2,
                                location_on_page: 1
                            }), a(".questions-page", ".js-gps-related-tags", ".post-tag", {
                                page: 2,
                                location_on_page: 2
                            }), a(".question-page", ".post-taglist .js-post-tag-list-wrapper", ".post-tag", {
                                page: 3,
                                location_on_page: 3
                            }), a(".question-page", ".js-bottom-notice .js-post-tag-list-wrapper", ".post-tag", {
                                page: 3,
                                location_on_page: 4
                            }), a(".tags-page", "#tags_list", ".post-tag", {
                                page: 4,
                                location_on_page: 5
                            }), a(".tagged-questions-page", ".js-post-tag-list-wrapper", ".post-tag", {
                                page: 5,
                                location_on_page: 1
                            }), a(".tagged-questions-page", ".js-gps-related-tags", ".post-tag", {
                                page: 5,
                                location_on_page: 2
                            }), a(".tagged-questions-page", ".js-watched-tag-list", ".post-tag", {
                                page: 5,
                                location_on_page: 7
                            }), a(".tagged-questions-page", ".js-ignored-tag-list", ".post-tag", {
                                page: 5,
                                location_on_page: 8
                            }), n(), !0) : (StackExchange.gps.track = function(t, e, a, n) {
                                n && n()
                            }, delete StackExchange._gps_track, !1));
                            var e, o, r
                        },
                        bindTrackClicks: n,
                        track: StackExchange.gps.track,
                        sendPending: StackExchange.gps.sendPending,
                        trackOutboundClicks: function(t, e) {
                            $(t).on("click", e + " a[href]:not(.question-hyperlink, .answer-hyperlink)", (function() {
                                var t = $(this).attr("href");
                                StackExchange.helpers.isInNetwork(t) || ("undefined" == typeof ga ? p("outbound link clicked " + t) : ga("send", "event", "outbound", "click", t, {
                                    useBeacon: !0
                                }))
                            }))
                        },
                        parseTrackData: o
                    }
                }()
            }
        },
        e = {};

    function a(n) {
        var o = e[n];
        if (void 0 !== o) return o.exports;
        var i = e[n] = {
            exports: {}
        };
        return t[n](i, i.exports, a), i.exports
    }
    a.p = "", (() => {
        "use strict";
        a.p = document.getElementById("webpack-public-path").innerText + "Js/"
    })(), (() => {
        "use strict";
        var t;
        a(89621);
        ! function(t) {
            t[t.Question = 1] = "Question", t[t.Answer = 2] = "Answer", t[t.Wiki = 3] = "Wiki", t[t.TagWikiUsageGuidance = 4] = "TagWikiUsageGuidance", t[t.TagWiki = 5] = "TagWiki", t[t.ModeratorNomination = 6] = "ModeratorNomination", t[t.WikiPlaceholder = 7] = "WikiPlaceholder", t[t.PrivilegeWiki = 8] = "PrivilegeWiki", t[t.Article = 9] = "Article", t[t.HelpArticle = 10] = "HelpArticle", t[t.Collection = 12] = "Collection", t[t.ModeratorQuestionnaireResponse = 13] = "ModeratorQuestionnaireResponse", t[t.Announcement = 14] = "Announcement", t[t.CollectiveDiscussion = 15] = "CollectiveDiscussion", t[t.CollectiveCollection = 17] = "CollectiveCollection", t[t.TagWikiSummary = 18] = "TagWikiSummary", t[t.Challenge = 19] = "Challenge", t[t.ChallengeEntry = 20] = "ChallengeEntry"
        }(t || (t = {}));
        const {
            sortType: e,
            numberOfVisibleAnswers: n,
            trackQuestions: o,
            trackArticles: i,
            userReputationBand: s,
            userReputation: r,
            sendPrizmEvent: c,
            sendAEHEvent: g
        } = function(t) {
            const e = function(t) {
                const e = function(t) {
                    const e = t.replace(/\.(t|j)sx?/, ""),
                        a = `script[type="application/json"][data-role="module-args"][data-module-name="${e}"]`;
                    return document.querySelectorAll(a)
                }(t);
                return Array.from(e).map((t => JSON.parse(t.textContent || t.innerText)))
            }(t);
            return function(t, e) {
                    if (0 === t.length) throw `Couldn't find args for module "${e}". Did you forget to call @JavaScriptHelper.Args?`
                }(e, t),
                function(t, e) {
                    if (t.length > 1) throw `Found too many instances of args for module "${e}". Did you call @JavaScriptHelper.Args too many times?`
                }(e, t), e[0]
        }("entry-points/misc/copy.mod.ts");
        let p, l;
        document.addEventListener("copy", (function(a) {
            var u, d;
            const f = a.target;
            if (f == p) return;
            p = f;
            const h = a.composedPath().filter((t => t instanceof HTMLElement));
            let k, S, v, m;
            for (var y = 0; y < h.length; y++) {
                var x = h[y];
                "CODE" == x.nodeName && (v = x), (null === (u = x.classList) || void 0 === u ? void 0 : u.contains("snippet")) && (m = x), (null === (d = x.classList) || void 0 === d ? void 0 : d.contains("js-post-body")) && (k = x), (x.dataset.answerid || x.dataset.questionid || x.dataset.articleid) && (S = x)
            }
            if (void 0 !== k && void 0 !== S) {
                const p = parseInt(S.dataset.answerid || S.dataset.questionid || S.dataset.articleid, 10);
                if (l === p) return;
                l = p;
                const u = parseInt(S.dataset.score, 10),
                    d = parseInt(S.dataset.positionOnPage, 10),
                    f = S.classList.contains("js-accepted-answer"),
                    h = "1" == S.dataset.questionHasAcceptedHighestScore,
                    k = "1" == S.dataset.highestScored,
                    y = parseInt(S.dataset.authorReputation, 10),
                    x = void 0 !== v,
                    w = void 0 !== m,
                    E = S.dataset.creationSource,
                    A = S.dataset.creationMethod;
                let b = t.Answer;
                if (S.classList.contains("js-question") ? b = t.Question : S.classList.contains("js-article") && (b = t.Article), !o && b === t.Question || !i && b === t.Article) return;
                var _ = b == t.Answer ? parseInt(S.dataset.parentid) : p;
                const O = a.isTrusted ? "manual" : "button";
                if (c) {
                    ! function(...t) {
                        StackExchange.gps.track(...t)
                    }("client_copy.post", {
                        PostId: p,
                        question_id: _,
                        PostType: b,
                        PostScore: u,
                        PostIsAccepted: f,
                        PostIsHighestScore: k,
                        QuestionHasAcceptedHighestScore: h,
                        SortMethod: e,
                        PositionOnPage: d,
                        UserReputationBand: s,
                        source: O,
                        CreationSource: E,
                        CreationMethod: A
                    })
                }
                if (g) {
                    ! function(t, e, a, n) {
                        const o = new FormData;
                        o.append("fKey", null != n ? n : StackExchange.options.user.fkey), o.append("data", JSON.stringify(e)), o.append("event", t);
                        let i = {};
                        a && (i["X-Previous-Event-Id"] = a), fetch((StackExchange.options.site.routePrefix || "") + "/stackevent", {
                            method: "POST",
                            keepalive: !0,
                            body: o,
                            headers: i
                        }).then((() => {}))
                    }("questions_show.client_copy.post", {
                        postId: p,
                        questionId: _,
                        postType: b,
                        postScoreAtCopyTime: u,
                        postIsAcceptedAtCopyTime: f,
                        sortMethod: e,
                        positionOnPage: d,
                        numberOfVisibleAnswersAtCopyTime: n,
                        userReputationAtCopyTime: r,
                        authorReputationAtCopyTime: y,
                        fromCodeBlock: x,
                        fromStackSnippets: w,
                        source: O
                    })
                }
            }
        }))
    })()
})();