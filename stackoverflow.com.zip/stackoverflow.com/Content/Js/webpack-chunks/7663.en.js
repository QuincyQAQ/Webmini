"use strict";
(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [7663], {
        17663: (t, e, n) => {
            n.d(e, {
                UE: () => Rt,
                ll: () => xt,
                rD: () => Lt,
                UU: () => bt,
                mG: () => Tt,
                cY: () => vt
            });
            const o = Math.min,
                i = Math.max,
                r = Math.round,
                l = Math.floor,
                c = t => ({
                    x: t,
                    y: t
                }),
                s = {
                    left: "right",
                    right: "left",
                    bottom: "top",
                    top: "bottom"
                },
                a = {
                    start: "end",
                    end: "start"
                };

            function f(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function u(t) {
                return t.split("-")[0]
            }

            function h(t) {
                return t.split("-")[1]
            }

            function d(t) {
                return "y" === t ? "height" : "width"
            }
            const g = new Set(["top", "bottom"]);

            function m(t) {
                return g.has(u(t)) ? "y" : "x"
            }

            function p(t) {
                return "x" === m(t) ? "y" : "x"
            }

            function y(t) {
                return t.replace(/start|end/g, (t => a[t]))
            }
            const w = ["left", "right"],
                x = ["right", "left"],
                v = ["top", "bottom"],
                b = ["bottom", "top"];

            function R(t, e, n, o) {
                const i = h(t);
                let r = function(t, e, n) {
                    switch (t) {
                        case "top":
                        case "bottom":
                            return n ? e ? x : w : e ? w : x;
                        case "left":
                        case "right":
                            return e ? v : b;
                        default:
                            return []
                    }
                }(u(t), "start" === n, o);
                return i && (r = r.map((t => t + "-" + i)), e && (r = r.concat(r.map(y)))), r
            }

            function T(t) {
                return t.replace(/left|right|bottom|top/g, (t => s[t]))
            }

            function L(t) {
                return "number" != typeof t ? function(t) {
                    return {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...t
                    }
                }(t) : {
                    top: t,
                    right: t,
                    bottom: t,
                    left: t
                }
            }

            function E(t) {
                const {
                    x: e,
                    y: n,
                    width: o,
                    height: i
                } = t;
                return {
                    width: o,
                    height: i,
                    top: n,
                    left: e,
                    right: e + o,
                    bottom: n + i,
                    x: e,
                    y: n
                }
            }

            function A(t, e, n) {
                let {
                    reference: o,
                    floating: i
                } = t;
                const r = m(e),
                    l = p(e),
                    c = d(l),
                    s = u(e),
                    a = "y" === r,
                    f = o.x + o.width / 2 - i.width / 2,
                    g = o.y + o.height / 2 - i.height / 2,
                    y = o[c] / 2 - i[c] / 2;
                let w;
                switch (s) {
                    case "top":
                        w = {
                            x: f,
                            y: o.y - i.height
                        };
                        break;
                    case "bottom":
                        w = {
                            x: f,
                            y: o.y + o.height
                        };
                        break;
                    case "right":
                        w = {
                            x: o.x + o.width,
                            y: g
                        };
                        break;
                    case "left":
                        w = {
                            x: o.x - i.width,
                            y: g
                        };
                        break;
                    default:
                        w = {
                            x: o.x,
                            y: o.y
                        }
                }
                switch (h(e)) {
                    case "start":
                        w[l] -= y * (n && a ? -1 : 1);
                        break;
                    case "end":
                        w[l] += y * (n && a ? -1 : 1)
                }
                return w
            }
            async function S(t, e) {
                var n;
                void 0 === e && (e = {});
                const {
                    x: o,
                    y: i,
                    platform: r,
                    rects: l,
                    elements: c,
                    strategy: s
                } = t, {
                    boundary: a = "clippingAncestors",
                    rootBoundary: u = "viewport",
                    elementContext: h = "floating",
                    altBoundary: d = !1,
                    padding: g = 0
                } = f(e, t), m = L(g), p = c[d ? "floating" === h ? "reference" : "floating" : h], y = E(await r.getClippingRect({
                    element: null == (n = await (null == r.isElement ? void 0 : r.isElement(p))) || n ? p : p.contextElement || await (null == r.getDocumentElement ? void 0 : r.getDocumentElement(c.floating)),
                    boundary: a,
                    rootBoundary: u,
                    strategy: s
                })), w = "floating" === h ? {
                    x: o,
                    y: i,
                    width: l.floating.width,
                    height: l.floating.height
                } : l.reference, x = await (null == r.getOffsetParent ? void 0 : r.getOffsetParent(c.floating)), v = await (null == r.isElement ? void 0 : r.isElement(x)) && await (null == r.getScale ? void 0 : r.getScale(x)) || {
                    x: 1,
                    y: 1
                }, b = E(r.convertOffsetParentRelativeRectToViewportRelativeRect ? await r.convertOffsetParentRelativeRectToViewportRelativeRect({
                    elements: c,
                    rect: w,
                    offsetParent: x,
                    strategy: s
                }) : w);
                return {
                    top: (y.top - b.top + m.top) / v.y,
                    bottom: (b.bottom - y.bottom + m.bottom) / v.y,
                    left: (y.left - b.left + m.left) / v.x,
                    right: (b.right - y.right + m.right) / v.x
                }
            }

            function C(t) {
                const e = o(...t.map((t => t.left))),
                    n = o(...t.map((t => t.top)));
                return {
                    x: e,
                    y: n,
                    width: i(...t.map((t => t.right))) - e,
                    height: i(...t.map((t => t.bottom))) - n
                }
            }
            const D = new Set(["left", "top"]);

            function O() {
                return "undefined" != typeof window
            }

            function k(t) {
                return B(t) ? (t.nodeName || "").toLowerCase() : "#document"
            }

            function P(t) {
                var e;
                return (null == t || null == (e = t.ownerDocument) ? void 0 : e.defaultView) || window
            }

            function F(t) {
                var e;
                return null == (e = (B(t) ? t.ownerDocument : t.document) || window.document) ? void 0 : e.documentElement
            }

            function B(t) {
                return !!O() && (t instanceof Node || t instanceof P(t).Node)
            }

            function H(t) {
                return !!O() && (t instanceof Element || t instanceof P(t).Element)
            }

            function W(t) {
                return !!O() && (t instanceof HTMLElement || t instanceof P(t).HTMLElement)
            }

            function V(t) {
                return !(!O() || "undefined" == typeof ShadowRoot) && (t instanceof ShadowRoot || t instanceof P(t).ShadowRoot)
            }
            const M = new Set(["inline", "contents"]);

            function z(t) {
                const {
                    overflow: e,
                    overflowX: n,
                    overflowY: o,
                    display: i
                } = K(t);
                return /auto|scroll|overlay|hidden|clip/.test(e + o + n) && !M.has(i)
            }
            const N = new Set(["table", "td", "th"]);

            function I(t) {
                return N.has(k(t))
            }
            const U = [":popover-open", ":modal"];

            function Y(t) {
                return U.some((e => {
                    try {
                        return t.matches(e)
                    } catch (t) {
                        return !1
                    }
                }))
            }
            const j = ["transform", "translate", "scale", "rotate", "perspective"],
                q = ["transform", "translate", "scale", "rotate", "perspective", "filter"],
                X = ["paint", "layout", "strict", "content"];

            function $(t) {
                const e = _(),
                    n = H(t) ? K(t) : t;
                return j.some((t => !!n[t] && "none" !== n[t])) || !!n.containerType && "normal" !== n.containerType || !e && !!n.backdropFilter && "none" !== n.backdropFilter || !e && !!n.filter && "none" !== n.filter || q.some((t => (n.willChange || "").includes(t))) || X.some((t => (n.contain || "").includes(t)))
            }

            function _() {
                return !("undefined" == typeof CSS || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none")
            }
            const G = new Set(["html", "body", "#document"]);

            function J(t) {
                return G.has(k(t))
            }

            function K(t) {
                return P(t).getComputedStyle(t)
            }

            function Q(t) {
                return H(t) ? {
                    scrollLeft: t.scrollLeft,
                    scrollTop: t.scrollTop
                } : {
                    scrollLeft: t.scrollX,
                    scrollTop: t.scrollY
                }
            }

            function Z(t) {
                if ("html" === k(t)) return t;
                const e = t.assignedSlot || t.parentNode || V(t) && t.host || F(t);
                return V(e) ? e.host : e
            }

            function tt(t) {
                const e = Z(t);
                return J(e) ? t.ownerDocument ? t.ownerDocument.body : t.body : W(e) && z(e) ? e : tt(e)
            }

            function et(t, e, n) {
                var o;
                void 0 === e && (e = []), void 0 === n && (n = !0);
                const i = tt(t),
                    r = i === (null == (o = t.ownerDocument) ? void 0 : o.body),
                    l = P(i);
                if (r) {
                    const t = nt(l);
                    return e.concat(l, l.visualViewport || [], z(i) ? i : [], t && n ? et(t) : [])
                }
                return e.concat(i, et(i, [], n))
            }

            function nt(t) {
                return t.parent && Object.getPrototypeOf(t.parent) ? t.frameElement : null
            }

            function ot(t) {
                const e = K(t);
                let n = parseFloat(e.width) || 0,
                    o = parseFloat(e.height) || 0;
                const i = W(t),
                    l = i ? t.offsetWidth : n,
                    c = i ? t.offsetHeight : o,
                    s = r(n) !== l || r(o) !== c;
                return s && (n = l, o = c), {
                    width: n,
                    height: o,
                    $: s
                }
            }

            function it(t) {
                return H(t) ? t : t.contextElement
            }

            function rt(t) {
                const e = it(t);
                if (!W(e)) return c(1);
                const n = e.getBoundingClientRect(),
                    {
                        width: o,
                        height: i,
                        $: l
                    } = ot(e);
                let s = (l ? r(n.width) : n.width) / o,
                    a = (l ? r(n.height) : n.height) / i;
                return s && Number.isFinite(s) || (s = 1), a && Number.isFinite(a) || (a = 1), {
                    x: s,
                    y: a
                }
            }
            const lt = c(0);

            function ct(t) {
                const e = P(t);
                return _() && e.visualViewport ? {
                    x: e.visualViewport.offsetLeft,
                    y: e.visualViewport.offsetTop
                } : lt
            }

            function st(t, e, n, o) {
                void 0 === e && (e = !1), void 0 === n && (n = !1);
                const i = t.getBoundingClientRect(),
                    r = it(t);
                let l = c(1);
                e && (o ? H(o) && (l = rt(o)) : l = rt(t));
                const s = function(t, e, n) {
                    return void 0 === e && (e = !1), !(!n || e && n !== P(t)) && e
                }(r, n, o) ? ct(r) : c(0);
                let a = (i.left + s.x) / l.x,
                    f = (i.top + s.y) / l.y,
                    u = i.width / l.x,
                    h = i.height / l.y;
                if (r) {
                    const t = P(r),
                        e = o && H(o) ? P(o) : o;
                    let n = t,
                        i = nt(n);
                    for (; i && o && e !== n;) {
                        const t = rt(i),
                            e = i.getBoundingClientRect(),
                            o = K(i),
                            r = e.left + (i.clientLeft + parseFloat(o.paddingLeft)) * t.x,
                            l = e.top + (i.clientTop + parseFloat(o.paddingTop)) * t.y;
                        a *= t.x, f *= t.y, u *= t.x, h *= t.y, a += r, f += l, n = P(i), i = nt(n)
                    }
                }
                return E({
                    width: u,
                    height: h,
                    x: a,
                    y: f
                })
            }

            function at(t, e) {
                const n = Q(t).scrollLeft;
                return e ? e.left + n : st(F(t)).left + n
            }

            function ft(t, e, n) {
                void 0 === n && (n = !1);
                const o = t.getBoundingClientRect();
                return {
                    x: o.left + e.scrollLeft - (n ? 0 : at(t, o)),
                    y: o.top + e.scrollTop
                }
            }

            function ut(t, e, n) {
                let o;
                if ("viewport" === e) o = function(t, e) {
                    const n = P(t),
                        o = F(t),
                        i = n.visualViewport;
                    let r = o.clientWidth,
                        l = o.clientHeight,
                        c = 0,
                        s = 0;
                    if (i) {
                        r = i.width, l = i.height;
                        const t = _();
                        (!t || t && "fixed" === e) && (c = i.offsetLeft, s = i.offsetTop)
                    }
                    return {
                        width: r,
                        height: l,
                        x: c,
                        y: s
                    }
                }(t, n);
                else if ("document" === e) o = function(t) {
                    const e = F(t),
                        n = Q(t),
                        o = t.ownerDocument.body,
                        r = i(e.scrollWidth, e.clientWidth, o.scrollWidth, o.clientWidth),
                        l = i(e.scrollHeight, e.clientHeight, o.scrollHeight, o.clientHeight);
                    let c = -n.scrollLeft + at(t);
                    const s = -n.scrollTop;
                    return "rtl" === K(o).direction && (c += i(e.clientWidth, o.clientWidth) - r), {
                        width: r,
                        height: l,
                        x: c,
                        y: s
                    }
                }(F(t));
                else if (H(e)) o = function(t, e) {
                    const n = st(t, !0, "fixed" === e),
                        o = n.top + t.clientTop,
                        i = n.left + t.clientLeft,
                        r = W(t) ? rt(t) : c(1);
                    return {
                        width: t.clientWidth * r.x,
                        height: t.clientHeight * r.y,
                        x: i * r.x,
                        y: o * r.y
                    }
                }(e, n);
                else {
                    const n = ct(t);
                    o = {
                        x: e.x - n.x,
                        y: e.y - n.y,
                        width: e.width,
                        height: e.height
                    }
                }
                return E(o)
            }

            function ht(t, e) {
                const n = Z(t);
                return !(n === e || !H(n) || J(n)) && ("fixed" === K(n).position || ht(n, e))
            }

            function dt(t, e, n) {
                const o = W(e),
                    i = F(e),
                    r = "fixed" === n,
                    l = st(t, !0, r, e);
                let s = {
                    scrollLeft: 0,
                    scrollTop: 0
                };
                const a = c(0);

                function f() {
                    a.x = at(i)
                }
                if (o || !o && !r)
                    if (("body" !== k(e) || z(i)) && (s = Q(e)), o) {
                        const t = st(e, !0, r, e);
                        a.x = t.x + e.clientLeft, a.y = t.y + e.clientTop
                    } else i && f();
                r && !o && i && f();
                const u = !i || o || r ? c(0) : ft(i, s);
                return {
                    x: l.left + s.scrollLeft - a.x - u.x,
                    y: l.top + s.scrollTop - a.y - u.y,
                    width: l.width,
                    height: l.height
                }
            }

            function gt(t) {
                return "static" === K(t).position
            }

            function mt(t, e) {
                if (!W(t) || "fixed" === K(t).position) return null;
                if (e) return e(t);
                let n = t.offsetParent;
                return F(t) === n && (n = n.ownerDocument.body), n
            }

            function pt(t, e) {
                const n = P(t);
                if (Y(t)) return n;
                if (!W(t)) {
                    let e = Z(t);
                    for (; e && !J(e);) {
                        if (H(e) && !gt(e)) return e;
                        e = Z(e)
                    }
                    return n
                }
                let o = mt(t, e);
                for (; o && I(o) && gt(o);) o = mt(o, e);
                return o && J(o) && gt(o) && !$(o) ? n : o || function(t) {
                    let e = Z(t);
                    for (; W(e) && !J(e);) {
                        if ($(e)) return e;
                        if (Y(e)) return null;
                        e = Z(e)
                    }
                    return null
                }(t) || n
            }
            const yt = {
                convertOffsetParentRelativeRectToViewportRelativeRect: function(t) {
                    let {
                        elements: e,
                        rect: n,
                        offsetParent: o,
                        strategy: i
                    } = t;
                    const r = "fixed" === i,
                        l = F(o),
                        s = !!e && Y(e.floating);
                    if (o === l || s && r) return n;
                    let a = {
                            scrollLeft: 0,
                            scrollTop: 0
                        },
                        f = c(1);
                    const u = c(0),
                        h = W(o);
                    if ((h || !h && !r) && (("body" !== k(o) || z(l)) && (a = Q(o)), W(o))) {
                        const t = st(o);
                        f = rt(o), u.x = t.x + o.clientLeft, u.y = t.y + o.clientTop
                    }
                    const d = !l || h || r ? c(0) : ft(l, a, !0);
                    return {
                        width: n.width * f.x,
                        height: n.height * f.y,
                        x: n.x * f.x - a.scrollLeft * f.x + u.x + d.x,
                        y: n.y * f.y - a.scrollTop * f.y + u.y + d.y
                    }
                },
                getDocumentElement: F,
                getClippingRect: function(t) {
                    let {
                        element: e,
                        boundary: n,
                        rootBoundary: r,
                        strategy: l
                    } = t;
                    const c = [..."clippingAncestors" === n ? Y(e) ? [] : function(t, e) {
                            const n = e.get(t);
                            if (n) return n;
                            let o = et(t, [], !1).filter((t => H(t) && "body" !== k(t))),
                                i = null;
                            const r = "fixed" === K(t).position;
                            let l = r ? Z(t) : t;
                            for (; H(l) && !J(l);) {
                                const e = K(l),
                                    n = $(l);
                                n || "fixed" !== e.position || (i = null), (r ? !n && !i : !n && "static" === e.position && i && ["absolute", "fixed"].includes(i.position) || z(l) && !n && ht(t, l)) ? o = o.filter((t => t !== l)) : i = e, l = Z(l)
                            }
                            return e.set(t, o), o
                        }(e, this._c) : [].concat(n), r],
                        s = c[0],
                        a = c.reduce(((t, n) => {
                            const r = ut(e, n, l);
                            return t.top = i(r.top, t.top), t.right = o(r.right, t.right), t.bottom = o(r.bottom, t.bottom), t.left = i(r.left, t.left), t
                        }), ut(e, s, l));
                    return {
                        width: a.right - a.left,
                        height: a.bottom - a.top,
                        x: a.left,
                        y: a.top
                    }
                },
                getOffsetParent: pt,
                getElementRects: async function(t) {
                    const e = this.getOffsetParent || pt,
                        n = this.getDimensions,
                        o = await n(t.floating);
                    return {
                        reference: dt(t.reference, await e(t.floating), t.strategy),
                        floating: {
                            x: 0,
                            y: 0,
                            width: o.width,
                            height: o.height
                        }
                    }
                },
                getClientRects: function(t) {
                    return Array.from(t.getClientRects())
                },
                getDimensions: function(t) {
                    const {
                        width: e,
                        height: n
                    } = ot(t);
                    return {
                        width: e,
                        height: n
                    }
                },
                getScale: rt,
                isElement: H,
                isRTL: function(t) {
                    return "rtl" === K(t).direction
                }
            };

            function wt(t, e) {
                return t.x === e.x && t.y === e.y && t.width === e.width && t.height === e.height
            }

            function xt(t, e, n, r) {
                void 0 === r && (r = {});
                const {
                    ancestorScroll: c = !0,
                    ancestorResize: s = !0,
                    elementResize: a = "function" == typeof ResizeObserver,
                    layoutShift: f = "function" == typeof IntersectionObserver,
                    animationFrame: u = !1
                } = r, h = it(t), d = c || s ? [...h ? et(h) : [], ...et(e)] : [];
                d.forEach((t => {
                    c && t.addEventListener("scroll", n, {
                        passive: !0
                    }), s && t.addEventListener("resize", n)
                }));
                const g = h && f ? function(t, e) {
                    let n, r = null;
                    const c = F(t);

                    function s() {
                        var t;
                        clearTimeout(n), null == (t = r) || t.disconnect(), r = null
                    }
                    return function a(f, u) {
                        void 0 === f && (f = !1), void 0 === u && (u = 1), s();
                        const h = t.getBoundingClientRect(),
                            {
                                left: d,
                                top: g,
                                width: m,
                                height: p
                            } = h;
                        if (f || e(), !m || !p) return;
                        const y = {
                            rootMargin: -l(g) + "px " + -l(c.clientWidth - (d + m)) + "px " + -l(c.clientHeight - (g + p)) + "px " + -l(d) + "px",
                            threshold: i(0, o(1, u)) || 1
                        };
                        let w = !0;

                        function x(e) {
                            const o = e[0].intersectionRatio;
                            if (o !== u) {
                                if (!w) return a();
                                o ? a(!1, o) : n = setTimeout((() => {
                                    a(!1, 1e-7)
                                }), 1e3)
                            }
                            1 !== o || wt(h, t.getBoundingClientRect()) || a(), w = !1
                        }
                        try {
                            r = new IntersectionObserver(x, { ...y,
                                root: c.ownerDocument
                            })
                        } catch (t) {
                            r = new IntersectionObserver(x, y)
                        }
                        r.observe(t)
                    }(!0), s
                }(h, n) : null;
                let m, p = -1,
                    y = null;
                a && (y = new ResizeObserver((t => {
                    let [o] = t;
                    o && o.target === h && y && (y.unobserve(e), cancelAnimationFrame(p), p = requestAnimationFrame((() => {
                        var t;
                        null == (t = y) || t.observe(e)
                    }))), n()
                })), h && !u && y.observe(h), y.observe(e));
                let w = u ? st(t) : null;
                return u && function e() {
                    const o = st(t);
                    w && !wt(w, o) && n();
                    w = o, m = requestAnimationFrame(e)
                }(), n(), () => {
                    var t;
                    d.forEach((t => {
                        c && t.removeEventListener("scroll", n), s && t.removeEventListener("resize", n)
                    })), null == g || g(), null == (t = y) || t.disconnect(), y = null, u && cancelAnimationFrame(m)
                }
            }
            const vt = function(t) {
                    return void 0 === t && (t = 0), {
                        name: "offset",
                        options: t,
                        async fn(e) {
                            var n, o;
                            const {
                                x: i,
                                y: r,
                                placement: l,
                                middlewareData: c
                            } = e, s = await async function(t, e) {
                                const {
                                    placement: n,
                                    platform: o,
                                    elements: i
                                } = t, r = await (null == o.isRTL ? void 0 : o.isRTL(i.floating)), l = u(n), c = h(n), s = "y" === m(n), a = D.has(l) ? -1 : 1, d = r && s ? -1 : 1, g = f(e, t);
                                let {
                                    mainAxis: p,
                                    crossAxis: y,
                                    alignmentAxis: w
                                } = "number" == typeof g ? {
                                    mainAxis: g,
                                    crossAxis: 0,
                                    alignmentAxis: null
                                } : {
                                    mainAxis: g.mainAxis || 0,
                                    crossAxis: g.crossAxis || 0,
                                    alignmentAxis: g.alignmentAxis
                                };
                                return c && "number" == typeof w && (y = "end" === c ? -1 * w : w), s ? {
                                    x: y * d,
                                    y: p * a
                                } : {
                                    x: p * a,
                                    y: y * d
                                }
                            }(e, t);
                            return l === (null == (n = c.offset) ? void 0 : n.placement) && null != (o = c.arrow) && o.alignmentOffset ? {} : {
                                x: i + s.x,
                                y: r + s.y,
                                data: { ...s,
                                    placement: l
                                }
                            }
                        }
                    }
                },
                bt = function(t) {
                    return void 0 === t && (t = {}), {
                        name: "flip",
                        options: t,
                        async fn(e) {
                            var n, o;
                            const {
                                placement: i,
                                middlewareData: r,
                                rects: l,
                                initialPlacement: c,
                                platform: s,
                                elements: a
                            } = e, {
                                mainAxis: g = !0,
                                crossAxis: w = !0,
                                fallbackPlacements: x,
                                fallbackStrategy: v = "bestFit",
                                fallbackAxisSideDirection: b = "none",
                                flipAlignment: L = !0,
                                ...E
                            } = f(t, e);
                            if (null != (n = r.arrow) && n.alignmentOffset) return {};
                            const A = u(i),
                                C = m(c),
                                D = u(c) === c,
                                O = await (null == s.isRTL ? void 0 : s.isRTL(a.floating)),
                                k = x || (D || !L ? [T(c)] : function(t) {
                                    const e = T(t);
                                    return [y(t), e, y(e)]
                                }(c)),
                                P = "none" !== b;
                            !x && P && k.push(...R(c, L, b, O));
                            const F = [c, ...k],
                                B = await S(e, E),
                                H = [];
                            let W = (null == (o = r.flip) ? void 0 : o.overflows) || [];
                            if (g && H.push(B[A]), w) {
                                const t = function(t, e, n) {
                                    void 0 === n && (n = !1);
                                    const o = h(t),
                                        i = p(t),
                                        r = d(i);
                                    let l = "x" === i ? o === (n ? "end" : "start") ? "right" : "left" : "start" === o ? "bottom" : "top";
                                    return e.reference[r] > e.floating[r] && (l = T(l)), [l, T(l)]
                                }(i, l, O);
                                H.push(B[t[0]], B[t[1]])
                            }
                            if (W = [...W, {
                                    placement: i,
                                    overflows: H
                                }], !H.every((t => t <= 0))) {
                                var V, M;
                                const t = ((null == (V = r.flip) ? void 0 : V.index) || 0) + 1,
                                    e = F[t];
                                if (e) {
                                    if (!("alignment" === w && C !== m(e)) || W.every((t => m(t.placement) !== C || t.overflows[0] > 0))) return {
                                        data: {
                                            index: t,
                                            overflows: W
                                        },
                                        reset: {
                                            placement: e
                                        }
                                    }
                                }
                                let n = null == (M = W.filter((t => t.overflows[0] <= 0)).sort(((t, e) => t.overflows[1] - e.overflows[1]))[0]) ? void 0 : M.placement;
                                if (!n) switch (v) {
                                    case "bestFit":
                                        {
                                            var z;
                                            const t = null == (z = W.filter((t => {
                                                if (P) {
                                                    const e = m(t.placement);
                                                    return e === C || "y" === e
                                                }
                                                return !0
                                            })).map((t => [t.placement, t.overflows.filter((t => t > 0)).reduce(((t, e) => t + e), 0)])).sort(((t, e) => t[1] - e[1]))[0]) ? void 0 : z[0];t && (n = t);
                                            break
                                        }
                                    case "initialPlacement":
                                        n = c
                                }
                                if (i !== n) return {
                                    reset: {
                                        placement: n
                                    }
                                }
                            }
                            return {}
                        }
                    }
                },
                Rt = t => ({
                    name: "arrow",
                    options: t,
                    async fn(e) {
                        const {
                            x: n,
                            y: r,
                            placement: l,
                            rects: c,
                            platform: s,
                            elements: a,
                            middlewareData: u
                        } = e, {
                            element: g,
                            padding: m = 0
                        } = f(t, e) || {};
                        if (null == g) return {};
                        const y = L(m),
                            w = {
                                x: n,
                                y: r
                            },
                            x = p(l),
                            v = d(x),
                            b = await s.getDimensions(g),
                            R = "y" === x,
                            T = R ? "top" : "left",
                            E = R ? "bottom" : "right",
                            A = R ? "clientHeight" : "clientWidth",
                            S = c.reference[v] + c.reference[x] - w[x] - c.floating[v],
                            C = w[x] - c.reference[x],
                            D = await (null == s.getOffsetParent ? void 0 : s.getOffsetParent(g));
                        let O = D ? D[A] : 0;
                        O && await (null == s.isElement ? void 0 : s.isElement(D)) || (O = a.floating[A] || c.floating[v]);
                        const k = S / 2 - C / 2,
                            P = O / 2 - b[v] / 2 - 1,
                            F = o(y[T], P),
                            B = o(y[E], P),
                            H = F,
                            W = O - b[v] - B,
                            V = O / 2 - b[v] / 2 + k,
                            M = i(H, o(V, W));
                        const z = !u.arrow && null != h(l) && V !== M && c.reference[v] / 2 - (V < H ? F : B) - b[v] / 2 < 0,
                            N = z ? V < H ? V - H : V - W : 0;
                        return {
                            [x]: w[x] + N,
                            data: {
                                [x]: M,
                                centerOffset: V - M - N,
                                ...z && {
                                    alignmentOffset: N
                                }
                            },
                            reset: z
                        }
                    }
                }),
                Tt = function(t) {
                    return void 0 === t && (t = {}), {
                        name: "inline",
                        options: t,
                        async fn(e) {
                            const {
                                placement: n,
                                elements: r,
                                rects: l,
                                platform: c,
                                strategy: s
                            } = e, {
                                padding: a = 2,
                                x: h,
                                y: d
                            } = f(t, e), g = Array.from(await (null == c.getClientRects ? void 0 : c.getClientRects(r.reference)) || []), p = function(t) {
                                const e = t.slice().sort(((t, e) => t.y - e.y)),
                                    n = [];
                                let o = null;
                                for (let t = 0; t < e.length; t++) {
                                    const i = e[t];
                                    !o || i.y - o.y > o.height / 2 ? n.push([i]) : n[n.length - 1].push(i), o = i
                                }
                                return n.map((t => E(C(t))))
                            }(g), y = E(C(g)), w = L(a);
                            const x = await c.getElementRects({
                                reference: {
                                    getBoundingClientRect: function() {
                                        if (2 === p.length && p[0].left > p[1].right && null != h && null != d) return p.find((t => h > t.left - w.left && h < t.right + w.right && d > t.top - w.top && d < t.bottom + w.bottom)) || y;
                                        if (p.length >= 2) {
                                            if ("y" === m(n)) {
                                                const t = p[0],
                                                    e = p[p.length - 1],
                                                    o = "top" === u(n),
                                                    i = t.top,
                                                    r = e.bottom,
                                                    l = o ? t.left : e.left,
                                                    c = o ? t.right : e.right;
                                                return {
                                                    top: i,
                                                    bottom: r,
                                                    left: l,
                                                    right: c,
                                                    width: c - l,
                                                    height: r - i,
                                                    x: l,
                                                    y: i
                                                }
                                            }
                                            const t = "left" === u(n),
                                                e = i(...p.map((t => t.right))),
                                                r = o(...p.map((t => t.left))),
                                                l = p.filter((n => t ? n.left === r : n.right === e)),
                                                c = l[0].top,
                                                s = l[l.length - 1].bottom;
                                            return {
                                                top: c,
                                                bottom: s,
                                                left: r,
                                                right: e,
                                                width: e - r,
                                                height: s - c,
                                                x: r,
                                                y: c
                                            }
                                        }
                                        return y
                                    }
                                },
                                floating: r.floating,
                                strategy: s
                            });
                            return l.reference.x !== x.reference.x || l.reference.y !== x.reference.y || l.reference.width !== x.reference.width || l.reference.height !== x.reference.height ? {
                                reset: {
                                    rects: x
                                }
                            } : {}
                        }
                    }
                },
                Lt = (t, e, n) => {
                    const o = new Map,
                        i = {
                            platform: yt,
                            ...n
                        },
                        r = { ...i.platform,
                            _c: o
                        };
                    return (async (t, e, n) => {
                        const {
                            placement: o = "bottom",
                            strategy: i = "absolute",
                            middleware: r = [],
                            platform: l
                        } = n, c = r.filter(Boolean), s = await (null == l.isRTL ? void 0 : l.isRTL(e));
                        let a = await l.getElementRects({
                                reference: t,
                                floating: e,
                                strategy: i
                            }),
                            {
                                x: f,
                                y: u
                            } = A(a, o, s),
                            h = o,
                            d = {},
                            g = 0;
                        for (let n = 0; n < c.length; n++) {
                            const {
                                name: r,
                                fn: m
                            } = c[n], {
                                x: p,
                                y,
                                data: w,
                                reset: x
                            } = await m({
                                x: f,
                                y: u,
                                initialPlacement: o,
                                placement: h,
                                strategy: i,
                                middlewareData: d,
                                rects: a,
                                platform: l,
                                elements: {
                                    reference: t,
                                    floating: e
                                }
                            });
                            f = null != p ? p : f, u = null != y ? y : u, d = { ...d,
                                [r]: { ...d[r],
                                    ...w
                                }
                            }, x && g <= 50 && (g++, "object" == typeof x && (x.placement && (h = x.placement), x.rects && (a = !0 === x.rects ? await l.getElementRects({
                                reference: t,
                                floating: e,
                                strategy: i
                            }) : x.rects), ({
                                x: f,
                                y: u
                            } = A(a, h, s))), n = -1)
                        }
                        return {
                            x: f,
                            y: u,
                            placement: h,
                            strategy: i,
                            middlewareData: d
                        }
                    })(t, e, { ...i,
                        platform: r
                    })
                }
        }
    }
]);