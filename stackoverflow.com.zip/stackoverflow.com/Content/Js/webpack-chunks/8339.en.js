(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [8339], {
        74353: function(t) {
            t.exports = function() {
                "use strict";
                var t = 1e3,
                    e = 6e4,
                    r = 36e5,
                    s = "millisecond",
                    n = "second",
                    i = "minute",
                    a = "hour",
                    u = "day",
                    o = "week",
                    c = "month",
                    f = "quarter",
                    d = "year",
                    l = "date",
                    v = "Invalid Date",
                    h = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
                    p = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
                    $ = {
                        name: "en",
                        weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
                        months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
                        ordinal: function(t) {
                            var e = ["th", "st", "nd", "rd"],
                                r = t % 100;
                            return "[" + t + (e[(r - 20) % 10] || e[r] || e[0]) + "]"
                        }
                    },
                    m = function(t, e, r) {
                        var s = String(t);
                        return !s || s.length >= e ? t : "" + Array(e + 1 - s.length).join(r) + t
                    },
                    y = {
                        s: m,
                        z: function(t) {
                            var e = -t.utcOffset(),
                                r = Math.abs(e),
                                s = Math.floor(r / 60),
                                n = r % 60;
                            return (e <= 0 ? "+" : "-") + m(s, 2, "0") + ":" + m(n, 2, "0")
                        },
                        m: function t(e, r) {
                            if (e.date() < r.date()) return -t(r, e);
                            var s = 12 * (r.year() - e.year()) + (r.month() - e.month()),
                                n = e.clone().add(s, c),
                                i = r - n < 0,
                                a = e.clone().add(s + (i ? -1 : 1), c);
                            return +(-(s + (r - n) / (i ? n - a : a - n)) || 0)
                        },
                        a: function(t) {
                            return t < 0 ? Math.ceil(t) || 0 : Math.floor(t)
                        },
                        p: function(t) {
                            return {
                                M: c,
                                y: d,
                                w: o,
                                d: u,
                                D: l,
                                h: a,
                                m: i,
                                s: n,
                                ms: s,
                                Q: f
                            }[t] || String(t || "").toLowerCase().replace(/s$/, "")
                        },
                        u: function(t) {
                            return void 0 === t
                        }
                    },
                    M = "en",
                    g = {};
                g[M] = $;
                var b = "$isDayjsObject",
                    w = function(t) {
                        return t instanceof O || !(!t || !t[b])
                    },
                    D = function t(e, r, s) {
                        var n;
                        if (!e) return M;
                        if ("string" == typeof e) {
                            var i = e.toLowerCase();
                            g[i] && (n = i), r && (g[i] = r, n = i);
                            var a = e.split("-");
                            if (!n && a.length > 1) return t(a[0])
                        } else {
                            var u = e.name;
                            g[u] = e, n = u
                        }
                        return !s && n && (M = n), n || !s && M
                    },
                    U = function(t, e) {
                        if (w(t)) return t.clone();
                        var r = "object" == typeof e ? e : {};
                        return r.date = t, r.args = arguments, new O(r)
                    },
                    S = y;
                S.l = D, S.i = w, S.w = function(t, e) {
                    return U(t, {
                        locale: e.$L,
                        utc: e.$u,
                        x: e.$x,
                        $offset: e.$offset
                    })
                };
                var O = function() {
                        function $(t) {
                            this.$L = D(t.locale, null, !0), this.parse(t), this.$x = this.$x || t.x || {}, this[b] = !0
                        }
                        var m = $.prototype;
                        return m.parse = function(t) {
                            this.$d = function(t) {
                                var e = t.date,
                                    r = t.utc;
                                if (null === e) return new Date(NaN);
                                if (S.u(e)) return new Date;
                                if (e instanceof Date) return new Date(e);
                                if ("string" == typeof e && !/Z$/i.test(e)) {
                                    var s = e.match(h);
                                    if (s) {
                                        var n = s[2] - 1 || 0,
                                            i = (s[7] || "0").substring(0, 3);
                                        return r ? new Date(Date.UTC(s[1], n, s[3] || 1, s[4] || 0, s[5] || 0, s[6] || 0, i)) : new Date(s[1], n, s[3] || 1, s[4] || 0, s[5] || 0, s[6] || 0, i)
                                    }
                                }
                                return new Date(e)
                            }(t), this.init()
                        }, m.init = function() {
                            var t = this.$d;
                            this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds()
                        }, m.$utils = function() {
                            return S
                        }, m.isValid = function() {
                            return !(this.$d.toString() === v)
                        }, m.isSame = function(t, e) {
                            var r = U(t);
                            return this.startOf(e) <= r && r <= this.endOf(e)
                        }, m.isAfter = function(t, e) {
                            return U(t) < this.startOf(e)
                        }, m.isBefore = function(t, e) {
                            return this.endOf(e) < U(t)
                        }, m.$g = function(t, e, r) {
                            return S.u(t) ? this[e] : this.set(r, t)
                        }, m.unix = function() {
                            return Math.floor(this.valueOf() / 1e3)
                        }, m.valueOf = function() {
                            return this.$d.getTime()
                        }, m.startOf = function(t, e) {
                            var r = this,
                                s = !!S.u(e) || e,
                                f = S.p(t),
                                v = function(t, e) {
                                    var n = S.w(r.$u ? Date.UTC(r.$y, e, t) : new Date(r.$y, e, t), r);
                                    return s ? n : n.endOf(u)
                                },
                                h = function(t, e) {
                                    return S.w(r.toDate()[t].apply(r.toDate("s"), (s ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e)), r)
                                },
                                p = this.$W,
                                $ = this.$M,
                                m = this.$D,
                                y = "set" + (this.$u ? "UTC" : "");
                            switch (f) {
                                case d:
                                    return s ? v(1, 0) : v(31, 11);
                                case c:
                                    return s ? v(1, $) : v(0, $ + 1);
                                case o:
                                    var M = this.$locale().weekStart || 0,
                                        g = (p < M ? p + 7 : p) - M;
                                    return v(s ? m - g : m + (6 - g), $);
                                case u:
                                case l:
                                    return h(y + "Hours", 0);
                                case a:
                                    return h(y + "Minutes", 1);
                                case i:
                                    return h(y + "Seconds", 2);
                                case n:
                                    return h(y + "Milliseconds", 3);
                                default:
                                    return this.clone()
                            }
                        }, m.endOf = function(t) {
                            return this.startOf(t, !1)
                        }, m.$set = function(t, e) {
                            var r, o = S.p(t),
                                f = "set" + (this.$u ? "UTC" : ""),
                                v = (r = {}, r[u] = f + "Date", r[l] = f + "Date", r[c] = f + "Month", r[d] = f + "FullYear", r[a] = f + "Hours", r[i] = f + "Minutes", r[n] = f + "Seconds", r[s] = f + "Milliseconds", r)[o],
                                h = o === u ? this.$D + (e - this.$W) : e;
                            if (o === c || o === d) {
                                var p = this.clone().set(l, 1);
                                p.$d[v](h), p.init(), this.$d = p.set(l, Math.min(this.$D, p.daysInMonth())).$d
                            } else v && this.$d[v](h);
                            return this.init(), this
                        }, m.set = function(t, e) {
                            return this.clone().$set(t, e)
                        }, m.get = function(t) {
                            return this[S.p(t)]()
                        }, m.add = function(s, f) {
                            var l, v = this;
                            s = Number(s);
                            var h = S.p(f),
                                p = function(t) {
                                    var e = U(v);
                                    return S.w(e.date(e.date() + Math.round(t * s)), v)
                                };
                            if (h === c) return this.set(c, this.$M + s);
                            if (h === d) return this.set(d, this.$y + s);
                            if (h === u) return p(1);
                            if (h === o) return p(7);
                            var $ = (l = {}, l[i] = e, l[a] = r, l[n] = t, l)[h] || 1,
                                m = this.$d.getTime() + s * $;
                            return S.w(m, this)
                        }, m.subtract = function(t, e) {
                            return this.add(-1 * t, e)
                        }, m.format = function(t) {
                            var e = this,
                                r = this.$locale();
                            if (!this.isValid()) return r.invalidDate || v;
                            var s = t || "YYYY-MM-DDTHH:mm:ssZ",
                                n = S.z(this),
                                i = this.$H,
                                a = this.$m,
                                u = this.$M,
                                o = r.weekdays,
                                c = r.months,
                                f = r.meridiem,
                                d = function(t, r, n, i) {
                                    return t && (t[r] || t(e, s)) || n[r].slice(0, i)
                                },
                                l = function(t) {
                                    return S.s(i % 12 || 12, t, "0")
                                },
                                h = f || function(t, e, r) {
                                    var s = t < 12 ? "AM" : "PM";
                                    return r ? s.toLowerCase() : s
                                };
                            return s.replace(p, (function(t, s) {
                                return s || function(t) {
                                    switch (t) {
                                        case "YY":
                                            return String(e.$y).slice(-2);
                                        case "YYYY":
                                            return S.s(e.$y, 4, "0");
                                        case "M":
                                            return u + 1;
                                        case "MM":
                                            return S.s(u + 1, 2, "0");
                                        case "MMM":
                                            return d(r.monthsShort, u, c, 3);
                                        case "MMMM":
                                            return d(c, u);
                                        case "D":
                                            return e.$D;
                                        case "DD":
                                            return S.s(e.$D, 2, "0");
                                        case "d":
                                            return String(e.$W);
                                        case "dd":
                                            return d(r.weekdaysMin, e.$W, o, 2);
                                        case "ddd":
                                            return d(r.weekdaysShort, e.$W, o, 3);
                                        case "dddd":
                                            return o[e.$W];
                                        case "H":
                                            return String(i);
                                        case "HH":
                                            return S.s(i, 2, "0");
                                        case "h":
                                            return l(1);
                                        case "hh":
                                            return l(2);
                                        case "a":
                                            return h(i, a, !0);
                                        case "A":
                                            return h(i, a, !1);
                                        case "m":
                                            return String(a);
                                        case "mm":
                                            return S.s(a, 2, "0");
                                        case "s":
                                            return String(e.$s);
                                        case "ss":
                                            return S.s(e.$s, 2, "0");
                                        case "SSS":
                                            return S.s(e.$ms, 3, "0");
                                        case "Z":
                                            return n
                                    }
                                    return null
                                }(t) || n.replace(":", "")
                            }))
                        }, m.utcOffset = function() {
                            return 15 * -Math.round(this.$d.getTimezoneOffset() / 15)
                        }, m.diff = function(s, l, v) {
                            var h, p = this,
                                $ = S.p(l),
                                m = U(s),
                                y = (m.utcOffset() - this.utcOffset()) * e,
                                M = this - m,
                                g = function() {
                                    return S.m(p, m)
                                };
                            switch ($) {
                                case d:
                                    h = g() / 12;
                                    break;
                                case c:
                                    h = g();
                                    break;
                                case f:
                                    h = g() / 3;
                                    break;
                                case o:
                                    h = (M - y) / 6048e5;
                                    break;
                                case u:
                                    h = (M - y) / 864e5;
                                    break;
                                case a:
                                    h = M / r;
                                    break;
                                case i:
                                    h = M / e;
                                    break;
                                case n:
                                    h = M / t;
                                    break;
                                default:
                                    h = M
                            }
                            return v ? h : S.a(h)
                        }, m.daysInMonth = function() {
                            return this.endOf(c).$D
                        }, m.$locale = function() {
                            return g[this.$L]
                        }, m.locale = function(t, e) {
                            if (!t) return this.$L;
                            var r = this.clone(),
                                s = D(t, e, !0);
                            return s && (r.$L = s), r
                        }, m.clone = function() {
                            return S.w(this.$d, this)
                        }, m.toDate = function() {
                            return new Date(this.valueOf())
                        }, m.toJSON = function() {
                            return this.isValid() ? this.toISOString() : null
                        }, m.toISOString = function() {
                            return this.$d.toISOString()
                        }, m.toString = function() {
                            return this.$d.toUTCString()
                        }, $
                    }(),
                    k = O.prototype;
                return U.prototype = k, [
                    ["$ms", s],
                    ["$s", n],
                    ["$m", i],
                    ["$H", a],
                    ["$W", u],
                    ["$M", c],
                    ["$y", d],
                    ["$D", l]
                ].forEach((function(t) {
                    k[t[1]] = function(e) {
                        return this.$g(e, t[0], t[1])
                    }
                })), U.extend = function(t, e) {
                    return t.$i || (t(e, O, U), t.$i = !0), U
                }, U.locale = D, U.isDayjs = w, U.unix = function(t) {
                    return U(1e3 * t)
                }, U.en = g[M], U.Ls = g, U.p = {}, U
            }()
        },
        6279: function(t) {
            t.exports = function() {
                "use strict";
                return function(t, e, r) {
                    t = t || {};
                    var s = e.prototype,
                        n = {
                            future: "in %s",
                            past: "%s ago",
                            s: "a few seconds",
                            m: "a minute",
                            mm: "%d minutes",
                            h: "an hour",
                            hh: "%d hours",
                            d: "a day",
                            dd: "%d days",
                            M: "a month",
                            MM: "%d months",
                            y: "a year",
                            yy: "%d years"
                        };

                    function i(t, e, r, n) {
                        return s.fromToBase(t, e, r, n)
                    }
                    r.en.relativeTime = n, s.fromToBase = function(e, s, i, a, u) {
                        for (var o, c, f, d = i.$locale().relativeTime || n, l = t.thresholds || [{
                                l: "s",
                                r: 44,
                                d: "second"
                            }, {
                                l: "m",
                                r: 89
                            }, {
                                l: "mm",
                                r: 44,
                                d: "minute"
                            }, {
                                l: "h",
                                r: 89
                            }, {
                                l: "hh",
                                r: 21,
                                d: "hour"
                            }, {
                                l: "d",
                                r: 35
                            }, {
                                l: "dd",
                                r: 25,
                                d: "day"
                            }, {
                                l: "M",
                                r: 45
                            }, {
                                l: "MM",
                                r: 10,
                                d: "month"
                            }, {
                                l: "y",
                                r: 17
                            }, {
                                l: "yy",
                                d: "year"
                            }], v = l.length, h = 0; h < v; h += 1) {
                            var p = l[h];
                            p.d && (o = a ? r(e).diff(i, p.d, !0) : i.diff(e, p.d, !0));
                            var $ = (t.rounding || Math.round)(Math.abs(o));
                            if (f = o > 0, $ <= p.r || !p.r) {
                                $ <= 1 && h > 0 && (p = l[h - 1]);
                                var m = d[p.l];
                                u && ($ = u("" + $)), c = "string" == typeof m ? m.replace("%d", $) : m($, s, p.l, f);
                                break
                            }
                        }
                        if (s) return c;
                        var y = f ? d.future : d.past;
                        return "function" == typeof y ? y(c) : y.replace("%s", c)
                    }, s.to = function(t, e) {
                        return i(t, e, this, !0)
                    }, s.from = function(t, e) {
                        return i(t, e, this)
                    };
                    var a = function(t) {
                        return t.$u ? r.utc() : r()
                    };
                    s.toNow = function(t) {
                        return this.to(a(this), t)
                    }, s.fromNow = function(t) {
                        return this.from(a(this), t)
                    }
                }
            }()
        },
        53581: function(t) {
            t.exports = function() {
                "use strict";
                return function(t, e, r) {
                    r.updateLocale = function(t, e) {
                        var s = r.Ls[t];
                        if (s) return (e ? Object.keys(e) : []).forEach((function(t) {
                            s[t] = e[t]
                        })), s
                    }
                }
            }()
        },
        20779: (t, e, r) => {
            "use strict";
            r(82170), r(67578), r(78430)
        },
        59468: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(77934), s.vUu("<div><!> <!> <p><!></p> <!></div>")
        },
        92380: (t, e, r) => {
            "use strict";
            r(82170), r(67578).vUu('<div class="d-flex ai-center ps-relative w100"><textarea></textarea> <pre aria-hidden="true"> <br/></pre></div>')
        },
        2551: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(41134), r(37079), r(77934), s.vUu("<div><!> <!></div>")
        },
        7873: (t, e, r) => {
            "use strict";
            r(82170), r(67578).vUu('<li role="separator"></li>')
        },
        72524: (t, e, r) => {
            "use strict";
            r(82170), r(67578).vUu('<li role="separator"> <!></li>')
        },
        38504: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(77934), r(39772), s.vUu('<div class="s-notice--actions"><!> <!></div>'), s.vUu('<div><span class="s-notice--icon"><!></span> <!> <!></div>')
        },
        20242: (t, e, r) => {
            "use strict";
            r(82170), r(67578), r(13592)
        },
        61392: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(77934), r(93062);
            s.vUu('<button type="button"><!></button>');
            s.MmH(["click"])
        },
        61944: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(5541), r(51954), r(48167), r(77934), r(55834), r(68343), s.vUu('<div class="s-post-summary--stats-answers"><!> </div>'), s.vUu('<div><div class="s-post-summary--content-meta"><!> <div class="s-post-summary--stats"><div class="s-post-summary--stats-votes"><!> </div> <!></div></div> <!></div>')
        },
        34536: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(22024), r(77934), r(52730);
            s.vUu('<p class="s-description mb0 mtn2"><!></p>'), s.vUu('<div class="s-input-icon"><!></div>'), s.vUu('<p class="s-input-message"><!></p>'), s.vUu("<div><!> <!> <div><select><!></select> <!></div> <!></div>")
        },
        97675: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(34536), s.vUu("<option> </option>")
        },
        988: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(77934), r(52730), s.vUu('<p class="s-description"><!></p>'), s.vUu('<div class="s-input-icon"><!></div>'), s.vUu('<p class="s-input-message"><!></p>'), s.vUu('<div><!> <!> <div class="ps-relative w100 d-flex"><textarea></textarea> <!></div> <!></div>')
        },
        69982: (t, e, r) => {
            "use strict";
            r(82170), r(76467), r(67578), r(38504), r(22024)
        },
        75883: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(64006), r(93062), r(20005), r(15965), s.vUu("<!> <!>", 1), s.vUu("<li><!></li>")
        },
        91308: (t, e, r) => {
            "use strict";
            r(82170);
            var s = r(67578);
            r(77934), r(68343), s.vUu('<span class="s-vote--upvotes"> </span>'), s.vUu('<span class="s-vote--downvotes"> </span>'), s.vUu('<span class="v-visible-sr"> </span>'), s.vUu('<!> <span class="s-vote--total"> </span> <!> <!>', 1), s.vUu('<!> <span class="v-visible-sr"> </span>', 1), s.vUu('<!> <span class="v-visible-sr"> </span>', 1), s.vUu('<!> <span class="v-visible-sr"> </span>', 1), s.vUu('<!> <span class="v-visible-sr"> </span>', 1), s.vUu('<!> <button class="s-vote--btn"><!></button>', 1), s.vUu('<div><button class="s-vote--btn"><!> <!></button> <!></div>');
            s.MmH(["click"])
        },
        34164: (t, e, r) => {
            "use strict";

            function s(t) {
                var e, r, n = "";
                if ("string" == typeof t || "number" == typeof t) n += t;
                else if ("object" == typeof t)
                    if (Array.isArray(t)) {
                        var i = t.length;
                        for (e = 0; e < i; e++) t[e] && (r = s(t[e])) && (n && (n += " "), n += r)
                    } else
                        for (r in t) t[r] && (n && (n += " "), n += r);
                return n
            }

            function n() {
                for (var t, e, r = 0, n = "", i = arguments.length; r < i; r++)(t = arguments[r]) && (e = s(t)) && (n && (n += " "), n += e);
                return n
            }
            r.d(e, {
                $: () => n
            })
        },
        74488: (t, e, r) => {
            "use strict";
            r.d(e, {
                h5: () => s,
                IJ: () => i
            });
            const s = !0,
                n = globalThis.process ? .env ? .NODE_ENV,
                i = n && !n.toLowerCase().startsWith("prod")
        },
        33498: (t, e, r) => {
            "use strict";
            r(67578)
        }
    }
]);