"use strict";
(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [8112], {
        16029: (e, t, s) => {
            s.d(t, {
                E: () => a
            });
            const a = e => {
                const t = t => {
                    const s = t.target;
                    e.contains(s) || e.dispatchEvent(new CustomEvent("outclick", {
                        detail: s
                    }))
                };
                return document.addEventListener("click", t, !0), {
                    destroy() {
                        document.removeEventListener("click", t, !0)
                    }
                }
            }
        },
        12429: (e, t, s) => {
            if (s.d(t, {
                    E: () => a.E,
                    i: () => v
                }), !/^(39(45|74)|(12|41)05|(57|71)50|1599|2843|9498|9719)$/.test(s.j)) var a = s(16029);
            var i = s(22024);
            const r = /^(39(45|74)|(120|410|697)5|(57|71)50|1599|2843|4823|5321|682|9498|9719)$/.test(s.j) ? null : ["a[href]", "area[href]", 'input:not([disabled]):not([type="hidden"]):not([aria-hidden])', "select:not([disabled]):not([aria-hidden])", "textarea:not([disabled]):not([aria-hidden])", "button:not([disabled]):not([aria-hidden])", "iframe", "object", "embed", "[contenteditable]", '[tabindex]:not([tabindex^="-"])'],
                n = e => {
                    const t = document.defaultView ? .getComputedStyle(e);
                    return !(!t || "none" === t.getPropertyValue("display") || "hidden" === t.getPropertyValue("visibility"))
                },
                l = async e => (await (0, i.io)(), [...e.querySelectorAll(r.join(", "))].filter(n)),
                c = e => {
                    e[0] && e[0].focus()
                },
                o = e => {
                    e[e.length - 1] && e[e.length - 1].focus()
                },
                v = (e, {
                    active: t,
                    initialFocusElement: s,
                    returnFocusElement: a
                }) => {
                    let i;
                    const r = async t => {
                            const {
                                key: s,
                                shiftKey: a
                            } = t;
                            if ("Tab" === s) {
                                t.preventDefault(), t.stopPropagation();
                                const s = await l(e),
                                    i = document.activeElement;
                                a ? (({
                                    allFocusableItems: e,
                                    currentlyFocusedItem: t
                                }) => {
                                    if (!t) return void o(e);
                                    const s = e.indexOf(t);
                                    if (0 === s) return void o(e);
                                    const a = e[s - 1];
                                    a && a.focus()
                                })({
                                    allFocusableItems: s,
                                    currentlyFocusedItem: i
                                }) : (({
                                    allFocusableItems: e,
                                    currentlyFocusedItem: t
                                }) => {
                                    if (!t) return void c(e);
                                    const s = e.indexOf(t);
                                    if (e.length - 1 === s) return void c(e);
                                    const a = e[s + 1];
                                    a && a.focus()
                                })({
                                    allFocusableItems: s,
                                    currentlyFocusedItem: i
                                })
                            }
                        },
                        n = async () => {
                            const t = await l(e);
                            i ? ? = document.activeElement, s ? s.focus() : c(t), document.addEventListener("keydown", r)
                        },
                        v = () => {
                            a ? a.focus() : i ? .focus(), document.removeEventListener("keydown", r), i = null
                        };
                    return t && n(), {
                        update: ({
                            active: e
                        }) => {
                            e ? n() : v()
                        },
                        destroy: v
                    }
                }
        },
        98962: (e, t, s) => {
            s.d(t, {
                _: () => a
            });
            const a = (e, t) => {
                if (t <= 5) return Array.from({
                    length: t
                }, ((e, t) => t + 1));
                const s = [];
                s.push(1);
                let a = Math.max(2, e - 2),
                    i = Math.min(t - 1, e + 2);
                2 === a && (i = 5), i === t - 1 && (a = t - 4), a > 2 && s.push("…");
                for (let e = a; e <= i; e++) s.push(e);
                return i < t - 1 && s.push("…"), s.push(t), s
            }
        },
        99724: (e, t, s) => {
            s.d(t, {
                $n: () => v,
                Z_: () => p,
                In: () => i,
                N_: () => f,
                aF: () => J,
                J_: () => Q,
                AM: () => ie,
                qR: () => ce,
                hl: () => ve,
                hj: () => ne,
                l6: () => Ne,
                eb: () => Ke,
                EA: () => _,
                y$: () => w,
                vw: () => Oe,
                ks: () => z,
                l$: () => A,
                qu: () => Ie,
                P0: () => q
            });
            s(82170);
            var a = s(67578);
            a.vUu('<span><!> <span class="v-visible-sr"> </span></span>');

            function i(e, t) {
                const s = a._w2(t, "title", 3, ""),
                    i = a._w2(t, "native", 3, !1),
                    r = a._w2(t, "class", 3, "");
                let n = a.unG((() => ((e, t, s, a) => {
                    let i = e;
                    return t && (i = i.replace("</svg>", "<title>" + t + "</title></svg>"), i = i.replace(' aria-hidden="true"', "")), s && (i = i.replace(/class="/, 'class="native ')), a && (i = i.replace(/class="/, 'class="' + a + " ")), i
                })(t.src, s(), i(), r())));
                var l = a.Imx(),
                    c = a.esp(l);
                a.qyt(c, (() => a.JtY(n))), a.BCw(e, l)
            }
            if (/^(394|797)5$/.test(s.j)) var r = s(54152);
            var n = a.vUu('<img class="s-avatar--image" alt="" role="presentation"/>'),
                l = a.vUu('<span class="s-avatar--letter" aria-hidden="true"> </span>'),
                c = a.vUu('<!> <span class="v-visible-sr"> </span> <!>', 1);
            var o = a.vUu('<!> <span class="s-btn--badge"><span class="s-btn--number"><!></span></span>', 1);

            function v(e, t) {
                const s = a._w2(t, "branding", 3, ""),
                    i = a._w2(t, "size", 3, ""),
                    r = a._w2(t, "variant", 3, ""),
                    n = a._w2(t, "weight", 3, ""),
                    l = a._w2(t, "href", 3, void 0),
                    c = a._w2(t, "disabled", 3, !1),
                    v = a._w2(t, "dropdown", 3, !1),
                    d = a._w2(t, "icon", 3, !1),
                    u = a._w2(t, "link", 3, !1),
                    p = a._w2(t, "loading", 3, !1),
                    f = a._w2(t, "selected", 3, !1),
                    g = a._w2(t, "unset", 3, !1),
                    w = a._w2(t, "class", 3, ""),
                    h = a.iRd(t, ["$$slots", "$$events", "$$legacy", "branding", "size", "variant", "weight", "href", "disabled", "dropdown", "icon", "link", "loading", "selected", "unset", "class", "children", "badge"]),
                    _ = a.unG((() => ((e, t, s, a, i, r, n, l, c, o, v) => {
                        const d = "s-btn";
                        let u = d;
                        return e && (u += " " + e), [t, s, a, i].forEach((e => {
                            e && (u += ` ${d}__${e}`)
                        })), r && (u += ` ${d}__dropdown`), n && (u += ` ${d}__link`), l && (u += ` ${d}__icon`), c && (u += ` ${d}__unset`), o && (u += " is-loading"), v && (u += " is-selected"), u
                    })(w(), s(), i(), r(), n(), v(), u(), d(), g(), p(), f())));
                var m = a.Imx(),
                    b = a.esp(m);
                a.ND4(b, (() => l() ? "a" : "button"), !1, ((e, s) => {
                    a.p_Y(e, (() => ({
                        href: l(),
                        class: a.JtY(_),
                        disabled: !l() && c() || null,
                        "aria-disabled": l() && c() ? "true" : null,
                        ...h
                    })));
                    var i = a.Imx(),
                        r = a.esp(i),
                        n = e => {
                            var s = a.Imx(),
                                i = a.esp(s);
                            a.UAl(i, (() => t.children)), a.BCw(e, s)
                        },
                        v = e => {
                            var s = o(),
                                i = a.esp(s);
                            a.UAl(i, (() => t.children));
                            var r = a.hg4(i, 2),
                                n = a.jfp(r),
                                l = a.jfp(n);
                            a.UAl(l, (() => t.badge)), a.cLc(n), a.cLc(r), a.BCw(e, s)
                        };
                    a.if(r, (e => {
                        t.badge ? e(v, !1) : e(n)
                    })), a.BCw(s, i)
                })), a.BCw(e, m)
            }
            s(76467);
            var d = a.vUu('<div class="d-flex ai-center ps-relative w100"><textarea></textarea> <pre aria-hidden="true"> <br/></pre></div>');
            const u = {
                hash: "svelte-ttdarg",
                code: ".hmn48.svelte-ttdarg {min-height:48px;}textarea.svelte-ttdarg {resize:none;}"
            };

            function p(e, t) {
                const s = a.gjz(t, ["children", "$$slots", "$$events", "$$legacy"]),
                    i = a.gjz(s, ["id", "variant", "value"]);
                a.VCO(t, !1), a.kZQ(e, u);
                const r = a.zgK();
                let n = a._w2(t, "id", 8),
                    l = a._w2(t, "variant", 8, "default"),
                    c = a._w2(t, "value", 12, "");
                a.M3l((() => a.iTV(l())), (() => {
                    a.hZp(r, (e => {
                        let t = "s-textarea ws-pre-wrap break-word hmx3 lh-lg",
                            s = `${t} ps-absolute i0 h100`,
                            a = `${t} v-hidden overflow-hidden`;
                        if ("chat" === e) {
                            let e = " py12 pr64 hmn48";
                            s += e, a += e
                        }
                        return {
                            textarea: s,
                            grower: a
                        }
                    })(l()))
                })), a.iqF();
                var o = d(),
                    v = a.jfp(o);
                a.VUN(v), a.p_Y(v, (() => ({
                    class: (a.JtY(r), a.vzK((() => a.JtY(r).textarea))),
                    rows: "1",
                    id: n(),
                    ...i
                })), void 0, "svelte-ttdarg");
                var p = a.hg4(v, 2),
                    f = a.jfp(p, !0);
                a.K2T(), a.cLc(p), a.cLc(o), a.vNg((() => {
                    a.ysU(p, 1, a.$z$((a.JtY(r), a.vzK((() => a.JtY(r).grower)))), "svelte-ttdarg"), a.jax(f, c())
                })), a.oJB(v, c), a.f0J("input", v, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("keydown", v, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.BCw(e, o), a.uYY()
            }

            function f(e, t) {
                const s = a.gjz(t, ["children", "$$slots", "$$events", "$$legacy"]),
                    i = a.gjz(s, ["href", "variant", "disabled", "dropdown", "underlined", "visited", "class"]);
                a.VCO(t, !1);
                const r = a.zgK();
                let n = a._w2(t, "href", 8, void 0),
                    l = a._w2(t, "variant", 8, ""),
                    c = a._w2(t, "disabled", 8, !1),
                    o = a._w2(t, "dropdown", 8, !1),
                    v = a._w2(t, "underlined", 8, !1),
                    d = a._w2(t, "visited", 8, !1),
                    u = a._w2(t, "class", 8, "");
                a.M3l((() => (a.iTV(u()), a.iTV(l()), a.iTV(o()), a.iTV(v()), a.iTV(d()))), (() => {
                    a.hZp(r, ((e, t, s, a, i) => {
                        const r = "s-link";
                        let n = r;
                        return e && (n += ` ${e}`), t && (n += ` ${r}__${t}`), s && (n += ` ${r}__dropdown`), a && (n += ` ${r}__underlined`), i && (n += ` ${r}__visited`), n
                    })(u(), l(), o(), v(), d()))
                })), a.iqF();
                var p = a.Imx(),
                    f = a.esp(p);
                a.ND4(f, (() => n() ? "a" : "button"), !1, ((e, s) => {
                    a.p_Y(e, (() => ({
                        href: n(),
                        class: a.JtY(r),
                        disabled: !n() && c() || null,
                        "aria-disabled": n() && c() ? "true" : null,
                        ...i
                    }))), a.f0J("click", e, (function(e) {
                        a.Ibr.call(this, t, e)
                    }));
                    var l = a.Imx(),
                        o = a.esp(l);
                    a.NIy(o, t, "default", {}, null), a.BCw(s, l)
                })), a.BCw(e, p), a.uYY()
            }
            var g = a.vUu('<div><div class="v-visible-sr"> </div></div>');

            function w(e, t) {
                a.VCO(t, !1);
                const s = a.zgK();
                let i = a._w2(t, "label", 8, "Loading…"),
                    r = a._w2(t, "size", 8, ""),
                    n = a._w2(t, "class", 8, "");
                a.M3l((() => (a.iTV(n()), a.iTV(r()))), (() => {
                    a.hZp(s, ((e, t) => {
                        let s = "s-spinner";
                        return e && (s += " " + e), t && (s += " s-spinner__" + t), s
                    })(n(), r()))
                })), a.iqF();
                var l = g(),
                    c = a.jfp(l),
                    o = a.jfp(c, !0);
                a.cLc(c), a.cLc(l), a.vNg((() => {
                    a.ysU(l, 1, a.$z$(a.JtY(s))), a.jax(o, i())
                })), a.BCw(e, l), a.uYY()
            }
            var h = a.vUu('<div><div class="v-visible-sr"> </div></div>');

            function _(e, t) {
                a.VCO(t, !1);
                const s = a.zgK();
                let i = a._w2(t, "label", 8, "Loading…"),
                    r = a._w2(t, "variant", 8, "");
                a.M3l((() => a.iTV(r())), (() => {
                    a.hZp(s, (e => {
                        const t = "s-skeleton";
                        let s = t;
                        return e && (s += ` ${t}__${e}`), s
                    })(r()))
                })), a.iqF();
                var n = h(),
                    l = a.jfp(n),
                    c = a.jfp(l, !0);
                a.cLc(l), a.cLc(n), a.vNg((() => {
                    a.ysU(n, 1, a.$z$(a.JtY(s))), a.jax(c, i())
                })), a.BCw(e, n), a.uYY()
            }
            var m = a.vUu('<span class="s-label--status"> </span>'),
                b = a.vUu('<abbr class="s-required-symbol">*</abbr>'),
                $ = a.vUu("<label><!> <!><!></label>");

            function y(e, t) {
                const s = a._w2(t, "size", 3, ""),
                    i = a._w2(t, "optional", 3, !1),
                    r = a._w2(t, "required", 3, !1),
                    n = a._w2(t, "class", 3, ""),
                    l = a._w2(t, "i18nOptionalText", 3, "Optional"),
                    c = a._w2(t, "i18nRequiredText", 3, "Required"),
                    o = a.unG((() => ((e, t) => {
                        const s = "s-label";
                        let a = s;
                        return e && (a += " " + e), t && (a += ` ${s}__${t}`), a
                    })(n(), s())));
                var v = $(),
                    d = a.jfp(v);
                a.UAl(d, (() => t.children));
                var u = a.hg4(d, 2),
                    p = e => {
                        var t = m(),
                            s = a.jfp(t, !0);
                        a.cLc(t), a.vNg((() => a.jax(s, l()))), a.BCw(e, t)
                    };
                a.if(u, (e => {
                    i() && e(p)
                }));
                var f = a.hg4(u),
                    g = e => {
                        var t = b();
                        a.vNg((() => a.aIK(t, "title", c()))), a.BCw(e, t)
                    };
                a.if(f, (e => {
                    r() && e(g)
                })), a.cLc(v), a.vNg((() => {
                    a.ysU(v, 1, a.$z$(a.JtY(o))), a.aIK(v, "for", t.id)
                })), a.BCw(e, v)
            }
            if (/^(4726|7614)$/.test(s.j)) r = s(54152);
            var j = a.vUu('<p class="s-description mb0 mtn2"><!></p>'),
                C = a.vUu("<div><!></div>"),
                U = a.vUu("<div><!></div>"),
                x = a.vUu('<div class="s-input-icon"><!></div>'),
                I = a.vUu('<p class="s-input-message"><!></p>'),
                Y = a.vUu('<div><!> <!> <div class="d-flex"><!> <div class="ps-relative w100"><!> <input/> <!></div></div> <!></div>');

            function z(e, t) {
                const s = a.iWx(t),
                    n = a.gjz(t, ["children", "$$slots", "$$events", "$$legacy"]),
                    l = a.gjz(n, ["id", "label", "disabled", "hideLabel", "fillSide", "name", "optional", "placeholder", "readonly", "required", "size", "state", "type", "class", "i18nOptionalText", "i18nRequiredText"]);
                a.VCO(t, !1);
                const c = a.zgK();
                let o = a._w2(t, "id", 8),
                    v = a._w2(t, "label", 8),
                    d = a._w2(t, "disabled", 8, !1),
                    u = a._w2(t, "hideLabel", 8, !1),
                    p = a._w2(t, "fillSide", 8, "prepend"),
                    f = a._w2(t, "name", 8, void 0),
                    g = a._w2(t, "optional", 8, !1),
                    w = a._w2(t, "placeholder", 8, ""),
                    h = a._w2(t, "readonly", 8, !1),
                    _ = a._w2(t, "required", 8, !1),
                    m = a._w2(t, "size", 8, ""),
                    b = a._w2(t, "state", 8, ""),
                    $ = a._w2(t, "type", 8, "text"),
                    z = a._w2(t, "class", 8, ""),
                    L = a._w2(t, "i18nOptionalText", 8, void 0),
                    T = a._w2(t, "i18nRequiredText", 8, void 0);
                a.M3l((() => (a.iTV(z()), a.iTV(m()))), (() => {
                    a.hZp(c, ((e, t) => {
                        const s = "s-input";
                        let a = s;
                        return e && (a += " " + e), t && (a += ` ${s}__${t}`), a
                    })(z(), m()))
                })), a.iqF();
                var B = Y();
                let N;
                var J = a.jfp(B);
                const K = a.Xdt((() => u() ? "v-visible-sr" : ""));
                y(J, {
                    get id() {
                        return o()
                    },
                    get class() {
                        return a.JtY(K)
                    },
                    get size() {
                        return m()
                    },
                    get required() {
                        return _()
                    },
                    get i18nRequiredText() {
                        return T()
                    },
                    get optional() {
                        return g()
                    },
                    get i18nOptionalText() {
                        return L()
                    },
                    children: (e, t) => {
                        a.K2T();
                        var s = a.Qq7();
                        a.vNg((() => a.jax(s, v()))), a.BCw(e, s)
                    },
                    $$slots: {
                        default: !0
                    }
                });
                var V = a.hg4(J, 2),
                    k = e => {
                        var s = j(),
                            i = a.jfp(s);
                        a.NIy(i, t, "description", {}, null), a.cLc(s), a.vNg((() => a.aIK(s, "id", `${o()}-description`))), a.BCw(e, s)
                    };
                a.if(V, (e => {
                    a.vzK((() => s.description)) && e(k)
                }));
                var E = a.hg4(V, 2),
                    O = a.jfp(E),
                    F = e => {
                        var s = C();
                        let i;
                        var r = a.jfp(s);
                        a.NIy(r, t, "fill", {}, null), a.cLc(s), a.vNg((e => i = a.ysU(s, 1, "s-input-fill", null, i, e)), [() => ({
                            "order-first": "prepend" === p(),
                            "order-last": "append" === p()
                        })], a.Xdt), a.BCw(e, s)
                    };
                a.if(O, (e => {
                    a.vzK((() => s.fill)) && e(F)
                }));
                var q = a.hg4(O, 2),
                    A = a.jfp(q),
                    Z = e => {
                        var t = U();
                        let s;
                        var n = a.jfp(t);
                        const l = a.Xdt((() => "credit-card" === $() ? r.Bln : r.C0l));
                        i(n, {
                            get src() {
                                return a.JtY(l)
                            }
                        }), a.cLc(t), a.vNg((e => s = a.ysU(t, 1, "s-input-icon", null, s, e)), [() => ({
                            "s-input-icon__creditcard": "credit-card" === $(),
                            "s-input-icon__search": "search" === $()
                        })], a.Xdt), a.BCw(e, t)
                    };
                a.if(A, (e => {
                    "search" !== $() && "credit-card" !== $() || e(Z)
                }));
                var X = a.hg4(A, 2);
                a.R0j(X), a.p_Y(X, (e => ({
                    id: o(),
                    "aria-describedby": (a.iTV(o()), a.vzK((() => s.message ? `${o()}-message` : s.description ? `${o()}-description` : void 0))),
                    "aria-invalid": "error" === b(),
                    class: a.JtY(c),
                    type: "credit-card" === $() ? "text" : $(),
                    disabled: d(),
                    name: f(),
                    placeholder: w(),
                    readonly: h(),
                    required: _(),
                    ...l,
                    [a.tpM]: e
                })), [() => ({
                    "s-input__creditcard": "credit-card" === $(),
                    "s-input__search": "search" === $(),
                    blr0: s.fill && "prepend" === p(),
                    brr0: s.fill && "append" === p()
                })]);
                var P = a.hg4(X, 2),
                    D = e => {
                        var t = x(),
                            s = a.jfp(t),
                            n = e => {
                                i(e, {
                                    get src() {
                                        return r.GBC
                                    }
                                })
                            },
                            l = (e, t) => {
                                var s = e => {
                                        i(e, {
                                            get src() {
                                                return r.VsF
                                            }
                                        })
                                    },
                                    n = e => {
                                        i(e, {
                                            get src() {
                                                return r.O7Z
                                            }
                                        })
                                    };
                                a.if(e, (e => {
                                    "success" === b() ? e(s) : e(n, !1)
                                }), t)
                            };
                        a.if(s, (e => {
                            "error" === b() ? e(n) : e(l, !1)
                        })), a.cLc(t), a.BCw(e, t)
                    };
                a.if(P, (e => {
                    b() && e(D)
                })), a.cLc(q), a.cLc(E);
                var R = a.hg4(E, 2),
                    G = e => {
                        var s = I(),
                            i = a.jfp(s);
                        a.NIy(i, t, "message", {}, null), a.cLc(s), a.vNg((() => a.aIK(s, "id", `${o()}-message`))), a.BCw(e, s)
                    };
                a.if(R, (e => {
                    a.vzK((() => s.message)) && e(G)
                })), a.cLc(B), a.vNg((e => N = a.ysU(B, 1, "d-flex fd-column gy4", null, N, e)), [() => ({
                    "has-error": "error" === b(),
                    "has-success": "success" === b(),
                    "has-warning": "warning" === b()
                })], a.Xdt), a.f0J("change", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("input", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("keydown", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("keyup", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("focus", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("blur", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("paste", X, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.BCw(e, B), a.uYY()
            }
            var L = s(22024);
            if (/^((188|587|671)8|3019|3231|4337|4901|6894|8264|987)$/.test(s.j)) r = s(54152);
            var T = s(12429),
                B = a.vUu('<div class="d-flex g8 s-modal--footer"><!></div>'),
                N = a.vUu('<aside role="dialog"><div role="document"><h1 class="s-modal--header"><!></h1> <div class="s-modal--body"><!></div> <!> <!></div></aside>');

            function J(e, t) {
                const s = a.iWx(t);
                a.VCO(t, !1);
                const n = a.zgK();
                let l = a._w2(t, "id", 8),
                    c = a._w2(t, "visible", 12, !1),
                    o = a._w2(t, "state", 8, ""),
                    d = a._w2(t, "class", 8, ""),
                    u = a._w2(t, "i18nCloseButtonLabel", 8, "Close"),
                    p = a._w2(t, "preventCloseOnClickOutside", 8, !1),
                    f = a._w2(t, "hideCloseButton", 8, !1);
                const g = (0, L.ur)(),
                    w = () => {
                        c() && (c(!1), g("close"))
                    };
                a.M3l((() => a.iTV(d())), (() => {
                    a.hZp(n, (e => {
                        let t = "s-modal--dialog";
                        return e && (t += " " + e), t
                    })(d()))
                })), a.iqF(), a.TsN();
                var h = N();
                let _;
                a.f0J("keydown", a.xa8, (e => {
                    "Escape" === e.key && w()
                }));
                var m = a.jfp(h),
                    b = a.jfp(m),
                    $ = a.jfp(b);
                a.NIy($, t, "header", {}, null), a.cLc(b);
                var y = a.hg4(b, 2),
                    j = a.jfp(y);
                a.NIy(j, t, "body", {}, null), a.cLc(y);
                var C = a.hg4(y, 2),
                    U = e => {
                        var s = B(),
                            i = a.jfp(s);
                        a.NIy(i, t, "footer", {}, null), a.cLc(s), a.BCw(e, s)
                    };
                a.if(C, (e => {
                    a.vzK((() => s.footer)) && e(U)
                }));
                var x = a.hg4(C, 2),
                    I = e => {
                        v(e, {
                            variant: "muted",
                            icon: !0,
                            get "aria-label" () {
                                return u()
                            },
                            class: "s-modal--close",
                            onclick: w,
                            children: (e, t) => {
                                i(e, {
                                    get src() {
                                        return r.nFV
                                    },
                                    class: "modal-close"
                                })
                            },
                            $$slots: {
                                default: !0
                            }
                        })
                    };
                a.if(x, (e => {
                    f() || e(I)
                })), a.cLc(m), a.XId(m, (e => (0, T.E) ? .(e))), a.XId(m, ((e, t) => (0, T.i) ? .(e, t)), (() => ({
                    active: c()
                }))), a.cLc(h), a.vNg((e => {
                    _ = a.ysU(h, 1, "s-modal", null, _, e), a.aIK(h, "aria-hidden", !c()), a.aIK(h, "aria-labelledby", `${l()}-title`), a.aIK(h, "aria-describedby", `${l()}-description`), a.ysU(m, 1, a.$z$(a.JtY(n))), a.aIK(b, "id", `${l()}-title`), a.aIK(y, "id", `${l()}-description`)
                }), [() => ({
                    "s-modal__danger": "danger" === o(),
                    "s-modal__celebration": "celebration" === o()
                })], a.Xdt), a.f0J("outclick", m, (() => !p() && w())), a.BCw(e, h), a.uYY()
            }
            var K = a.vUu('<div class="d-flex"><!></div>'),
                V = a.vUu('<div><!> <p class="m0 fl-grow1"><!></p> <!></div>');

            function k(e, t) {
                const s = a._w2(t, "variant", 3, void 0),
                    r = a._w2(t, "important", 3, !1),
                    n = a._w2(t, "role", 3, "status"),
                    l = a._w2(t, "icon", 3, void 0),
                    c = a._w2(t, "iconTitle", 3, void 0),
                    o = a._w2(t, "class", 3, ""),
                    v = a.unG((() => ((e, s, a) => {
                        const i = "s-notice";
                        let r = i;
                        return e && (r += ` ${e}`), s && (r += ` ${i}__${s}`), a && (r += ` ${i}__important`), (l() || t.actions) && (r += " d-flex ai-center gx8"), t.actions && (r += "  p8 pl16"), r
                    })(o(), s(), r())));
                var d = V(),
                    u = a.jfp(d),
                    p = e => {
                        i(e, {
                            get src() {
                                return l()
                            },
                            get title() {
                                return c()
                            }
                        })
                    };
                a.if(u, (e => {
                    l() && e(p)
                }));
                var f = a.hg4(u, 2),
                    g = a.jfp(f);
                a.UAl(g, (() => t.children)), a.cLc(f);
                var w = a.hg4(f, 2),
                    h = e => {
                        var s = K(),
                            i = a.jfp(s);
                        a.UAl(i, (() => t.actions)), a.cLc(s), a.BCw(e, s)
                    };
                a.if(w, (e => {
                    t.actions && e(h)
                })), a.cLc(d), a.vNg((() => {
                    a.ysU(d, 1, a.$z$(a.JtY(v))), a.aIK(d, "role", n())
                })), a.BCw(e, d)
            }

            function E(e, t) {
                const s = a._w2(t, "i18nCloseButtonLabel", 3, "Close"),
                    n = a._w2(t, "class", 3, ""),
                    l = a.iRd(t, ["$$slots", "$$events", "$$legacy", "children", "type", "i18nCloseButtonLabel", "class"]),
                    c = a.unG((() => "s-notice--btn " + n()));
                v(e, a.DuQ({
                    get class() {
                        return a.JtY(c)
                    }
                }, (() => l), {
                    children: (e, n) => {
                        var l = a.Imx(),
                            c = a.esp(l),
                            o = e => {
                                i(e, {
                                    get src() {
                                        return r.nFV
                                    },
                                    get title() {
                                        return s()
                                    }
                                })
                            },
                            v = (e, s) => {
                                var i = e => {
                                    var s = a.Imx(),
                                        i = a.esp(s);
                                    a.UAl(i, (() => t.children)), a.BCw(e, s)
                                };
                                a.if(e, (e => {
                                    t.children && e(i)
                                }), s)
                            };
                        a.if(c, (e => {
                            "close" === t.type ? e(o) : e(v, !1)
                        })), a.BCw(e, l)
                    },
                    $$slots: {
                        default: !0
                    }
                }))
            }
            if (7975 == s.j) var O = s(79784);
            if (7975 == s.j) var F = s(73035);

            function q(e, t = {}) {
                const {
                    variant: s,
                    important: a,
                    icon: i,
                    iconTitle: r,
                    duration: n = 1e4,
                    dismissible: l = !0,
                    transient: c = !0,
                    onAutoClose: o = () => {},
                    onUserClose: v = () => {},
                    onClose: d = () => {},
                    actions: u
                } = t, p = "string" == typeof e ? (0, L.aX)((() => ({
                    render: () => `<span>${e}</span>`
                }))) : e, f = (0, L.aX)((() => ({
                    render: () => "<span />",
                    setup: e => {
                        const t = (0, L.Or)(E, {
                            target: e,
                            props: {
                                type: "close",
                                onclick: () => {
                                    O.oR.dismiss(h), v(), d()
                                }
                            }
                        });
                        return () => (0, L.vs)(t)
                    }
                }))), g = u || l ? (0, L.aX)((() => ({
                    render: () => "<span />",
                    setup: e => {
                        u && u(e), l && f(e)
                    }
                }))) : void 0;
                let w;
                w = "danger" === s ? "alert" : u ? "alertdialog" : "status";
                const h = O.oR.custom(k, {
                    componentProps: {
                        icon: i,
                        iconTitle: r,
                        variant: s,
                        important: a,
                        role: w,
                        children: p,
                        actions: g
                    },
                    class: "wmn6 sm:wmn-initial",
                    duration: c ? n : Number.POSITIVE_INFINITY,
                    onAutoClose: () => {
                        o(), d()
                    }
                });
                return h
            }

            function A(e, t) {
                a.VCO(t, !1), a.TsN(), (0, F.A)(e, {
                    position: "top-center",
                    class: "wmn6 sm:wmn-initial",
                    style: "z-index: calc(var(--zi-modals) + 1); top: calc(var(--theme-topbar-height, calc(var(--su-static48) + var(--su-static8))) + var(--su-static16))"
                }), a.uYY()
            }
            var Z = a.vUu('<nav class="pl24"><ul class="list-reset s-pagination"><!></ul></nav>');
            var X = a.vUu("<li><a><!></a></li>");

            function P(e, t) {
                let s = a._w2(t, "url", 8),
                    i = a._w2(t, "selected", 8, !1);
                var r = X(),
                    n = a.jfp(r);
                let l;
                var c = a.jfp(n);
                a.NIy(c, t, "default", {}, null), a.cLc(n), a.cLc(r), a.vNg((e => {
                    l = a.ysU(n, 1, "s-pagination--item", null, l, e), a.aIK(n, "aria-current", i() ? "page" : void 0), a.aIK(n, "href", s())
                }), [() => ({
                    "is-selected": i()
                })], a.Xdt), a.f0J("click", n, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.BCw(e, r)
            }
            var D = a.vUu('<li class="s-pagination--item s-pagination--item__clear">…</li>');
            if (3974 == s.j) var R = s(98962);
            var G = a.vUu(' <span class="v-visible-sr"> </span>', 1),
                M = a.vUu('<span class="v-visible-sr"> </span> ', 1),
                S = a.vUu(' <span class="v-visible-sr"> </span>', 1),
                H = a.vUu("<!> <!> <!>", 1);

            function Q(e, t) {
                a.VCO(t, !1);
                let s = a._w2(t, "page", 8),
                    i = a._w2(t, "totalPages", 8),
                    r = a._w2(t, "urlGenerator", 8),
                    n = a._w2(t, "followLink", 8, !0),
                    l = a._w2(t, "i18nNextText", 8, "Next"),
                    c = a._w2(t, "i18nPrevText", 8, "Prev"),
                    o = a._w2(t, "i18nPageText", 8, "page"),
                    v = a._w2(t, "i18nNavigationLabel", 8, "Pagination");
                const d = (0, L.ur)(),
                    u = e => t => {
                        n() || (t.preventDefault(), d("pagechange", e))
                    };
                a.TsN(),
                    function(e, t) {
                        let s = a._w2(t, "i18nNavigationLabel", 8, "Pagination");
                        var i = Z(),
                            r = a.jfp(i),
                            n = a.jfp(r);
                        a.NIy(n, t, "default", {}, null), a.cLc(r), a.cLc(i), a.vNg((() => a.aIK(i, "aria-label", s()))), a.BCw(e, i)
                    }(e, {
                        get i18nNavigationLabel() {
                            return v()
                        },
                        children: (e, t) => {
                            var n = H(),
                                v = a.esp(n),
                                d = e => {
                                    const t = a.Xdt((() => (a.iTV(r()), a.iTV(s()), a.vzK((() => r()(s() - 1))))));
                                    var i = a.unG((() => u(s() - 1)));
                                    P(e, {
                                        get url() {
                                            return a.JtY(t)
                                        },
                                        $$events: {
                                            click(...e) {
                                                a.JtY(i) ? .apply(this, e)
                                            }
                                        },
                                        children: (e, t) => {
                                            a.K2T();
                                            var s = G(),
                                                i = a.esp(s),
                                                r = a.hg4(i),
                                                n = a.jfp(r, !0);
                                            a.cLc(r), a.vNg((() => {
                                                a.jax(i, `${c()??""} `), a.jax(n, o())
                                            })), a.BCw(e, s)
                                        },
                                        $$slots: {
                                            default: !0
                                        }
                                    })
                                };
                            a.if(v, (e => {
                                s() > 1 && e(d)
                            }));
                            var p = a.hg4(v, 2);
                            a.__1(p, 3, (() => (a.iTV(R._), a.iTV(s()), a.iTV(i()), a.vzK((() => (0, R._)(s(), i()))))), ((e, t) => e.toString() + t), ((e, t) => {
                                var i = a.Imx(),
                                    n = a.esp(i),
                                    l = e => {
                                        const i = a.Xdt((() => (a.iTV(r()), a.JtY(t), a.vzK((() => r()(a.JtY(t)))))));
                                        var n = a.unG((() => u(a.JtY(t))));
                                        const l = a.Xdt((() => a.JtY(t) === s()));
                                        P(e, {
                                            get url() {
                                                return a.JtY(i)
                                            },
                                            get selected() {
                                                return a.JtY(l)
                                            },
                                            $$events: {
                                                click(...e) {
                                                    a.JtY(n) ? .apply(this, e)
                                                }
                                            },
                                            children: (e, s) => {
                                                var i = M(),
                                                    r = a.esp(i),
                                                    n = a.jfp(r, !0);
                                                a.cLc(r);
                                                var l = a.hg4(r);
                                                a.vNg((() => {
                                                    a.jax(n, o()), a.jax(l, ` ${a.JtY(t)??""}`)
                                                })), a.BCw(e, i)
                                            },
                                            $$slots: {
                                                default: !0
                                            }
                                        })
                                    },
                                    c = e => {
                                        ! function(e) {
                                            var t = D();
                                            a.BCw(e, t)
                                        }(e)
                                    };
                                a.if(n, (e => {
                                    "number" == typeof a.JtY(t) ? e(l) : e(c, !1)
                                })), a.BCw(e, i)
                            }));
                            var f = a.hg4(p, 2),
                                g = e => {
                                    const t = a.Xdt((() => (a.iTV(r()), a.iTV(s()), a.vzK((() => r()(s() + 1))))));
                                    var i = a.unG((() => u(s() + 1)));
                                    P(e, {
                                        get url() {
                                            return a.JtY(t)
                                        },
                                        $$events: {
                                            click(...e) {
                                                a.JtY(i) ? .apply(this, e)
                                            }
                                        },
                                        children: (e, t) => {
                                            a.K2T();
                                            var s = S(),
                                                i = a.esp(s),
                                                r = a.hg4(i),
                                                n = a.jfp(r, !0);
                                            a.cLc(r), a.vNg((() => {
                                                a.jax(i, `${l()??""} `), a.jax(n, o())
                                            })), a.BCw(e, s)
                                        },
                                        $$slots: {
                                            default: !0
                                        }
                                    })
                                };
                            a.if(f, (e => {
                                s() < i() && e(g)
                            })), a.BCw(e, n)
                        },
                        $$slots: {
                            default: !0
                        }
                    }), a.uYY()
            }
            var W = s(85630);
            if (/^(4(7(26|33|68)|337|468)|7(614|795|975)|3645|5048|6718|6894)$/.test(s.j)) var ee = s(17663);
            var te = s(2322);
            const se = "popover-context";

            function ae(e) {
                let t = (0, L.SD)(se);
                if (void 0 === t) throw new Error(`<${e} /> is missing a parent <Popover /> component.`);
                return t
            }

            function ie(e, t) {
                const s = a.gjz(t, ["children", "$$slots", "$$events", "$$legacy"]);
                a.VCO(t, !1);
                const [i, r] = a.DZI(), n = () => a.Hzn(x, "$pstate", i), l = () => a.Hzn(m, "$arrowEl", i), c = a.zgK();
                let o = a._w2(t, "id", 8),
                    v = a._w2(t, "autoshow", 8, !1),
                    d = a._w2(t, "visible", 8, void 0),
                    u = a._w2(t, "placement", 8, "bottom"),
                    p = a._w2(t, "strategy", 8, "absolute"),
                    f = a._w2(t, "trapFocus", 8, !1),
                    g = a._w2(t, "dismissible", 8, !0),
                    w = a._w2(t, "tooltip", 8, !1);
                let h, _;
                const m = (0, W.T5)(),
                    [b, $, y] = (0, te.Kf)({
                        placement: u(),
                        strategy: p(),
                        middleware: [(0, ee.cY)(10), (0, ee.UU)(), (0, ee.mG)(), (0, te.UE)({
                            element: m
                        })],
                        onComputed({
                            placement: e,
                            middlewareData: t
                        }) {
                            if (a.hYb(x, a.vzK(n).computedPlacement = e, a.vzK(n)), t.arrow && l()) {
                                const {
                                    x: e,
                                    y: s
                                } = t.arrow;
                                Object.assign(l().style, {
                                    left: null != e ? `${e}px` : "",
                                    top: null != s ? `${s}px` : ""
                                })
                            }
                        }
                    }),
                    j = (0, L.ur)(),
                    C = (e = 0) => {
                        window.clearTimeout(_), a.JtY(c) || n().visible || (_ = window.setTimeout((() => {
                            a.hYb(x, a.vzK(n).visible = !0, a.vzK(n)), j("open")
                        }), e))
                    },
                    U = (e = 0) => {
                        window.clearTimeout(_), a.JtY(c) || n().visible && (_ = window.setTimeout((() => {
                            a.hYb(x, a.vzK(n).visible = !1, a.vzK(n)), w() || h.focus(), j("close")
                        }), e))
                    },
                    x = (0, W.T5)({
                        id: o(),
                        controlled: void 0 !== s.visible,
                        visible: v(),
                        dismissible: g(),
                        trapFocus: f(),
                        computedPlacement: u(),
                        tooltip: w(),
                        floatingRef: e => {
                            h = e, b(e)
                        },
                        floatingContent: $,
                        arrowEl: m,
                        onOutclick: e => {
                            g() && e.detail !== h && U()
                        },
                        open: C,
                        openTooltip: () => {
                            w() && C(300)
                        },
                        close: U,
                        closeTooltip: () => {
                            w() && U(100)
                        },
                        toggle: () => {
                            n().visible ? U() : C()
                        }
                    });
                (0, L.o)(se, x), a.M3l((() => a.iTV(s)), (() => {
                    a.hZp(c, void 0 !== s.visible)
                })), a.M3l((() => (a.JtY(c), a.iTV(d()))), (() => {
                    a.JtY(c) && a.hYb(x, a.vzK(n).visible = d(), a.vzK(n))
                })), a.M3l((() => a.iTV(u())), (() => {
                    y({
                        placement: u()
                    })
                })), a.iqF(), a.TsN();
                var I = a.Imx();
                a.f0J("keydown", a.xa8, (e => {
                    "Escape" === e.key && g() && U()
                }));
                var Y = a.esp(I);
                a.NIy(Y, t, "default", {
                    get visible() {
                        return n(), a.vzK((() => n().visible))
                    },
                    open: C,
                    close: U
                }, null), a.BCw(e, I), a.uYY(), r()
            }
            var re = a.vUu("<span><!></span>");

            function ne(e, t) {
                a.VCO(t, !1);
                const [s, i] = a.DZI(), r = () => a.Hzn(o, "$pstate", s);
                let n = a._w2(t, "elementId", 8, null),
                    l = a.zgK(),
                    c = a.zgK(),
                    o = ae("PopoverReference");
                (0, L.Rc)((() => {
                    a.hZp(c, ((e, t, s) => {
                        const a = e ? document.getElementById(e) : t.firstElementChild;
                        if (!a) throw new Error("No reference element found.");
                        return s.floatingRef(a), a
                    })(n(), a.JtY(l), r())), r().controlled || (r().tooltip ? ((e, t) => {
                        e.addEventListener("mouseenter", t.openTooltip), e.addEventListener("mouseleave", t.closeTooltip), e.addEventListener("focusin", t.openTooltip), e.addEventListener("focusout", t.closeTooltip), e.setAttribute("aria-describedby", `${t.id}-popover`)
                    })(a.JtY(c), r()) : ((e, t) => {
                        if ("button" !== e.tagName.toLowerCase() && "button" !== e.role) throw new Error("Reference element must have a role of 'button' for uncontrolled popovers.");
                        e.setAttribute("aria-controls", `${t.id}-popover`);
                        const s = t.dismissible ? t.toggle : t.open;
                        e.addEventListener("click", s)
                    })(a.JtY(c), r()))
                })), a.M3l((() => (r(), a.JtY(c))), (() => {
                    r().controlled || r().tooltip || a.JtY(c) ? .setAttribute("aria-expanded", Boolean(r().visible).toString())
                })), a.iqF(), a.TsN();
                var v = re(),
                    d = a.jfp(v);
                a.NIy(d, t, "default", {}, null), a.cLc(v), a.Lcc(v, (e => a.hZp(l, e)), (() => a.JtY(l))), a.BCw(e, v), a.uYY(), i()
            }
            if (/^(4733|5048)$/.test(s.j)) r = s(54152);
            var le = a.vUu('<button type="button"><!></button>');

            function ce(e, t) {
                a.VCO(t, !1);
                const [s, n] = a.DZI(), l = ae("PopoverCloseButton");
                let c = a._w2(t, "label", 8, "Close"),
                    o = a._w2(t, "class", 8, "");
                a.TsN();
                var v = le();
                i(a.jfp(v), {
                    get src() {
                        return r.nFV
                    }
                }), a.cLc(v), a.vNg((() => {
                    a.aIK(v, "aria-label", c()), a.ysU(v, 1, "s-popover--close s-btn s-btn__muted ps-absolute" + (o() ? ` ${o()}` : ""))
                })), a.f0J("click", v, (function(...e) {
                    a.Hzn(l, "$pstate", s).close ? .apply(this, e)
                })), a.f0J("click", v, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.BCw(e, v), a.uYY(), n()
            }
            var oe = a.vUu('<div><div class="s-popover--arrow"></div> <div class="s-popover--content p12 mn12"><div class="ps-relative"><!></div></div></div>');

            function ve(e, t) {
                a.VCO(t, !1);
                const [s, i] = a.DZI(), r = () => a.Hzn(c, "$pstate", s);
                let n = a._w2(t, "role", 8, null),
                    l = a._w2(t, "class", 8, ""),
                    c = ae("PopoverContent"),
                    o = a.zgK("s-popover");
                const v = r().arrowEl;
                r().tooltip && a.hZp(o, a.JtY(o) + " s-popover__tooltip"), l() && a.hZp(o, a.JtY(o) + " " + l()), a.TsN();
                var d = oe();
                d.__focusin = function(...e) {
                    r().openTooltip ? .apply(this, e)
                }, d.__focusout = function(...e) {
                    r().closeTooltip ? .apply(this, e)
                };
                var u = a.jfp(d);
                a.Lcc(u, (e => a.fTr(v, e)), (() => a.Hzn(v, "$arrowEl", s)));
                var p = a.hg4(u, 2),
                    f = a.jfp(p),
                    g = a.jfp(f);
                a.NIy(g, t, "default", {}, null), a.cLc(f), a.cLc(p), a.cLc(d), a.XId(d, (e => r().floatingContent ? .(e))), a.XId(d, ((e, t) => (0, T.i) ? .(e, t)), (() => ({
                    active: r().trapFocus && !!r().visible
                }))), a.XId(d, (e => (0, T.E) ? .(e))), a.vNg((() => {
                    a.aIK(d, "id", (r(), a.vzK((() => `${r().id}-popover`)))), a.ysU(d, 1, (a.JtY(o), r(), a.vzK((() => `${a.JtY(o)}${r().visible?" is-visible":""}`)))), a.aIK(d, "role", (a.iTV(n()), r(), a.vzK((() => n() || (r().tooltip ? "tooltip" : "dialog"))))), a.aIK(d, "data-popper-placement", (r(), a.vzK((() => r().computedPlacement))))
                })), a.f0J("outclick", d, (function(...e) {
                    r().onOutclick ? .apply(this, e)
                })), a.f0J("mouseenter", d, (function(...e) {
                    r().openTooltip ? .apply(this, e)
                })), a.f0J("mouseleave", d, (function(...e) {
                    r().closeTooltip ? .apply(this, e)
                })), a.BCw(e, d), a.uYY(), i()
            }
            a.MmH(["focusin", "focusout"]);
            a.vUu("<!> ", 1), a.vUu('<div class="s-post-summary--content-type"><!></div>');
            a.vUu("<!> <!>", 1), a.vUu("<!> <!>", 1), a.vUu("<span><!></span>");
            a.vUu('<span class="s-post-summary--stats-item-unit"> </span>'), a.vUu('<div><span class="s-post-summary--stats-item-number"><!> </span> <!></div>');
            a.vUu("<p> </p>");
            var de = a.vUu('<time class="s-user-card--time"> </time>'),
                ue = a.vUu('<div class="s-badge s-badge__xs s-badge__moderator">Mod</div>'),
                pe = a.vUu('<div class="s-badge s-badge__xs s-badge__staff">Staff</div>'),
                fe = a.vUu('<div class="s-badge s-badge__xs s-badge__admin">Admin</div>'),
                ge = a.vUu(" <!> <!> <!>", 1),
                we = a.vUu('<li class="s-user-card--rep"> </li>'),
                he = a.vUu('<li class="s-award-bling s-award-bling__gold"> </li>'),
                _e = a.vUu('<li class="s-award-bling s-award-bling__silver"> </li>'),
                me = a.vUu('<li class="s-award-bling s-award-bling__bronze"> </li>'),
                be = a.vUu('<ul class="s-user-card--awards"><!> <!> <!> <!></ul>'),
                $e = a.vUu('<div class="s-user-card--role"> </div>'),
                ye = a.vUu('<div class="s-user-card--location"> </div>'),
                je = a.vUu('<time class="s-user-card--time"> </time>'),
                Ce = a.vUu('<div class="s-user-card--tags d-flex g4"><!></div>'),
                Ue = a.vUu('<div class="s-user-card--type"><!></div>'),
                xe = a.vUu('<div><!> <!> <div class="s-user-card--info as-stretch"><!> <!> <!> <!> <!> <!></div> <!></div>');

            function Ie(e, t) {
                const s = a._w2(t, "deleted", 3, !1),
                    o = a._w2(t, "highlighted", 3, !1),
                    v = a._w2(t, "admin", 3, !1),
                    d = a._w2(t, "moderator", 3, !1),
                    u = a._w2(t, "staff", 3, !1),
                    p = a._w2(t, "class", 3, ""),
                    f = a.unG((() => ((e, t, s, a) => {
                        const i = "s-user-card";
                        let r = i;
                        return e && (r += ` ${e}`), t && (r += ` ${i}__deleted`), s && (r += ` ${i}__highlighted`), a && (r += ` ${i}__${a}`), r
                    })(p(), s(), o(), t.size))),
                    g = a.unG((() => (e => {
                        switch (e) {
                            case "full":
                                return 48;
                            case "small":
                                return 24;
                            case "minimal":
                                return 16;
                            default:
                                return 32
                        }
                    })(t.size))),
                    w = a.unG((() => `w${a.JtY(g)} h${a.JtY(g)}`));
                var h = xe(),
                    _ = a.jfp(h),
                    m = e => {
                        var s = de(),
                            i = a.jfp(s, !0);
                        a.cLc(s), a.vNg((() => a.jax(i, t.timestamp))), a.BCw(e, s)
                    };
                a.if(_, (e => {
                    t.timestamp && "minimal" !== t.size && "small" !== t.size && e(m)
                }));
                var b = a.hg4(_, 2),
                    $ = e => {
                        i(e, {
                            get src() {
                                return r.jb3
                            },
                            get class() {
                                return `bar-md fc-white bg-black-225 s-user-card--avatar ${a.JtY(w)??""}`
                            },
                            get title() {
                                return t.name
                            }
                        })
                    },
                    y = e => {
                        const o = a.unG((() => !s() && t.href ? t.href : void 0));
                        ! function(e, t) {
                            const s = a._w2(t, "size", 3, 16),
                                o = a._w2(t, "badge", 3, !1),
                                v = a._w2(t, "class", 3, ""),
                                d = a.iRd(t, ["$$slots", "$$events", "$$legacy", "name", "size", "href", "src", "letter", "badge", "class", "role"]),
                                u = a.unG((() => ((e, t) => {
                                    const s = "s-avatar";
                                    let a = s;
                                    return e && (a += ` ${e}`), 16 !== t && (a += ` ${s}__${t}`), a
                                })(v(), s())));
                            var p = a.Imx(),
                                f = a.esp(p);
                            a.ND4(f, (() => t.href ? "a" : "span"), !1, ((e, s) => {
                                a.p_Y(e, (() => ({
                                    class: a.JtY(u),
                                    href: t.href,
                                    role: t.role || t.href && "link",
                                    ...d
                                })));
                                var v = c(),
                                    p = a.esp(v),
                                    f = e => {
                                        var s = n();
                                        a.vNg((() => a.aIK(s, "src", t.src))), a.BCw(e, s)
                                    },
                                    g = (e, s) => {
                                        var i = e => {
                                            var s = l(),
                                                i = a.jfp(s, !0);
                                            a.cLc(s), a.vNg((() => a.jax(i, t.letter))), a.BCw(e, s)
                                        };
                                        a.if(e, (e => {
                                            t.letter && e(i)
                                        }), s)
                                    };
                                a.if(p, (e => {
                                    t.src ? e(f) : e(g, !1)
                                }));
                                var w = a.hg4(p, 2),
                                    h = a.jfp(w, !0);
                                a.cLc(w);
                                var _ = a.hg4(w, 2),
                                    m = e => {
                                        i(e, {
                                            class: "s-avatar--badge",
                                            get src() {
                                                return r.RpA
                                            },
                                            native: !0
                                        })
                                    };
                                a.if(_, (e => {
                                    o() && e(m)
                                })), a.vNg((() => a.jax(h, t.name))), a.BCw(s, v)
                            })), a.BCw(e, p)
                        }(e, {
                            class: "s-user-card--avatar",
                            get name() {
                                return t.name
                            },
                            get href() {
                                return a.JtY(o)
                            },
                            get src() {
                                return t.avatar
                            },
                            get size() {
                                return a.JtY(g)
                            }
                        })
                    };
                a.if(b, (e => {
                    s() ? e($) : e(y, !1)
                }));
                var j = a.hg4(b, 2),
                    C = a.jfp(j),
                    U = e => {
                        var i = a.Imx(),
                            r = a.esp(i);
                        a.ND4(r, (() => t.href && !s() ? "a" : "div"), !1, ((e, i) => {
                            a.p_Y(e, (() => ({
                                class: "s-user-card--link",
                                href: s() ? null : t.href
                            })));
                            var r = ge(),
                                n = a.esp(r),
                                l = a.hg4(n),
                                c = e => {
                                    var t = ue();
                                    a.BCw(e, t)
                                };
                            a.if(l, (e => {
                                !s() && d() && e(c)
                            }));
                            var o = a.hg4(l, 2),
                                p = e => {
                                    var t = pe();
                                    a.BCw(e, t)
                                };
                            a.if(o, (e => {
                                !s() && u() && e(p)
                            }));
                            var f = a.hg4(o, 2),
                                g = e => {
                                    var t = fe();
                                    a.BCw(e, t)
                                };
                            a.if(f, (e => {
                                !s() && v() && e(g)
                            })), a.vNg((() => a.jax(n, `${t.name??""} `))), a.BCw(i, r)
                        })), a.BCw(e, i)
                    };
                a.if(C, (e => {
                    t.name && e(U)
                }));
                var x = a.hg4(C, 2),
                    I = e => {
                        var s = be(),
                            i = a.jfp(s),
                            r = e => {
                                var s = we(),
                                    i = a.jfp(s, !0);
                                a.cLc(s), a.vNg((() => a.jax(i, t.reputation))), a.BCw(e, s)
                            };
                        a.if(i, (e => {
                            t.reputation && e(r)
                        }));
                        var n = a.hg4(i, 2),
                            l = e => {
                                var s = he(),
                                    i = a.jfp(s, !0);
                                a.cLc(s), a.vNg((() => a.jax(i, t.gold))), a.BCw(e, s)
                            };
                        a.if(n, (e => {
                            t.gold && e(l)
                        }));
                        var c = a.hg4(n, 2),
                            o = e => {
                                var s = _e(),
                                    i = a.jfp(s, !0);
                                a.cLc(s), a.vNg((() => a.jax(i, t.silver))), a.BCw(e, s)
                            };
                        a.if(c, (e => {
                            t.silver && e(o)
                        }));
                        var v = a.hg4(c, 2),
                            d = e => {
                                var s = me(),
                                    i = a.jfp(s, !0);
                                a.cLc(s), a.vNg((() => a.jax(i, t.bronze))), a.BCw(e, s)
                            };
                        a.if(v, (e => {
                            t.bronze && e(d)
                        })), a.cLc(s), a.BCw(e, s)
                    };
                a.if(x, (e => {
                    !s() && (t.reputation || t.gold || t.silver || t.bronze) && e(I)
                }));
                var Y = a.hg4(x, 2),
                    z = e => {
                        var s = $e(),
                            i = a.jfp(s, !0);
                        a.cLc(s), a.vNg((() => a.jax(i, t.role))), a.BCw(e, s)
                    };
                a.if(Y, (e => {
                    !s() && t.role && e(z)
                }));
                var L = a.hg4(Y, 2),
                    T = e => {
                        var s = ye(),
                            i = a.jfp(s, !0);
                        a.cLc(s), a.vNg((() => a.jax(i, t.location))), a.BCw(e, s)
                    };
                a.if(L, (e => {
                    !s() && t.location && e(T)
                }));
                var B = a.hg4(L, 2),
                    N = e => {
                        var s = je(),
                            i = a.jfp(s, !0);
                        a.cLc(s), a.vNg((() => a.jax(i, t.timestamp))), a.BCw(e, s)
                    };
                a.if(B, (e => {
                    !t.timestamp || "minimal" !== t.size && "small" !== t.size || e(N)
                }));
                var J = a.hg4(B, 2),
                    K = e => {
                        var s = Ce(),
                            i = a.jfp(s);
                        a.UAl(i, (() => t.tags)), a.cLc(s), a.BCw(e, s)
                    };
                a.if(J, (e => {
                    !s() && t.tags && e(K)
                })), a.cLc(j);
                var V = a.hg4(j, 2),
                    k = e => {
                        var s = Ue(),
                            i = a.jfp(s);
                        a.UAl(i, (() => t.type)), a.cLc(s), a.BCw(e, s)
                    };
                a.if(V, (e => {
                    !s() && t.type && e(k)
                })), a.cLc(h), a.vNg((() => a.ysU(h, 1, a.$z$(a.JtY(f))))), a.BCw(e, h)
            }
            a.vUu('<div class="s-activity-indicator"><div class="v-visible-sr"> </div></div>'), a.vUu("<!> ", 1), a.vUu('<div class="s-post-summary--meta-tags"><!></div>'), a.vUu('<!> <span class="v-visible-sr"> </span>', 1), a.vUu("<!> <!>", 1), a.vUu('<div><div class="s-post-summary--stats"><!> <!> <!> <!> <!> <!></div> <div class="s-post-summary--content"><!> <h3 class="s-post-summary--content-title"><!> <!></h3> <!> <div class="s-post-summary--meta"><!> <!></div> <!> <!></div></div>');
            a.vUu('<div class="s-post-summary--answer"><div class="s-post-summary--stats"><!> <!></div> <p class="s-post-summary--answer-excerpt"> </p> <div class="s-post-summary--meta"><!> <!></div></div>');
            const Ye = "select-context";
            var ze = a.vUu('<p class="s-description mb0 mtn2"><!></p>'),
                Le = a.vUu('<div class="s-input-icon"><!></div>'),
                Te = a.vUu('<p class="s-input-message"><!></p>'),
                Be = a.vUu("<div><!> <!> <div><select><!></select> <!></div> <!></div>");

            function Ne(e, t) {
                const s = a.iWx(t);
                a.VCO(t, !1);
                const n = a.zgK();
                let l = a._w2(t, "id", 8),
                    c = a._w2(t, "label", 8),
                    o = a._w2(t, "selected", 8, void 0),
                    v = a._w2(t, "disabled", 8, !1),
                    d = a._w2(t, "hideLabel", 8, !1),
                    u = a._w2(t, "name", 8, void 0),
                    p = a._w2(t, "size", 8, ""),
                    f = a._w2(t, "state", 8, ""),
                    g = a._w2(t, "labelPlacement", 8, "top");
                const w = (0, W.T5)({
                    selected: o()
                });
                (0, L.o)(Ye, w);
                a.M3l((() => (a.iTV(p()), a.iTV(g()))), (() => {
                    a.hZp(n, ((e, t) => {
                        const s = "s-select";
                        let a = s;
                        return e && (a += ` ${s}__${e}`), "left" === t && (a += " ml8"), a
                    })(p(), g()))
                })), a.iqF(), a.TsN();
                var h = Be();
                let _;
                var m = a.jfp(h);
                const b = a.Xdt((() => d() ? "v-visible-sr" : ""));
                y(m, {
                    get id() {
                        return l()
                    },
                    get class() {
                        return a.JtY(b)
                    },
                    get size() {
                        return p()
                    },
                    children: (e, t) => {
                        a.K2T();
                        var s = a.Qq7();
                        a.vNg((() => a.jax(s, c()))), a.BCw(e, s)
                    },
                    $$slots: {
                        default: !0
                    }
                });
                var $ = a.hg4(m, 2),
                    j = e => {
                        var s = ze(),
                            i = a.jfp(s);
                        a.NIy(i, t, "description", {}, null), a.cLc(s), a.vNg((() => a.aIK(s, "id", `${l()}-description`))), a.BCw(e, s)
                    };
                a.if($, (e => {
                    a.iTV(d()), a.iTV(g()), a.vzK((() => s.description && !d() && "top" === g())) && e(j)
                }));
                var C = a.hg4($, 2),
                    U = a.jfp(C),
                    x = a.jfp(U);
                a.NIy(x, t, "default", {}, null), a.cLc(U);
                var I = a.hg4(U, 2),
                    Y = e => {
                        var t = Le(),
                            s = a.jfp(t),
                            n = e => {
                                i(e, {
                                    get src() {
                                        return r.GBC
                                    }
                                })
                            },
                            l = (e, t) => {
                                var s = e => {
                                        i(e, {
                                            get src() {
                                                return r.VsF
                                            }
                                        })
                                    },
                                    n = e => {
                                        i(e, {
                                            get src() {
                                                return r.O7Z
                                            }
                                        })
                                    };
                                a.if(e, (e => {
                                    "success" === f() ? e(s) : e(n, !1)
                                }), t)
                            };
                        a.if(s, (e => {
                            "error" === f() ? e(n) : e(l, !1)
                        })), a.cLc(t), a.BCw(e, t)
                    };
                a.if(I, (e => {
                    f() && e(Y)
                })), a.cLc(C);
                var z = a.hg4(C, 2),
                    T = e => {
                        var s = Te(),
                            i = a.jfp(s);
                        a.NIy(i, t, "message", {}, null), a.cLc(s), a.vNg((() => a.aIK(s, "id", `${l()}-message`))), a.BCw(e, s)
                    };
                a.if(z, (e => {
                    a.vzK((() => s.message)) && e(T)
                })), a.cLc(h), a.vNg((e => {
                    _ = a.ysU(h, 1, "d-flex " + ("top" === g() ? " fd-column gy4" : "ai-center"), null, _, e), a.ysU(C, 1, a.$z$(a.JtY(n))), a.aIK(U, "id", l()), a.aIK(U, "name", u()), U.disabled = v(), a.aIK(U, "aria-describedby", (a.iTV(l()), a.vzK((() => s.message ? `${l()}-message` : s.description ? `${l()}-description` : void 0)))), a.aIK(U, "aria-invalid", "error" === f())
                }), [() => ({
                    "has-error": "error" === f(),
                    "has-success": "success" === f(),
                    "has-warning": "warning" === f()
                })], a.Xdt), a.f0J("change", U, (e => {
                    const t = e.target;
                    w.set({
                        selected: t.value
                    })
                })), a.f0J("change", U, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("focus", U, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.f0J("blur", U, (function(e) {
                    a.Ibr.call(this, t, e)
                })), a.BCw(e, h), a.uYY()
            }
            var Je = a.vUu("<option> </option>");

            function Ke(e, t) {
                a.VCO(t, !1);
                const [s, i] = a.DZI(), r = () => a.Hzn(o, "$state", s);
                let n = a._w2(t, "value", 8, ""),
                    l = a._w2(t, "text", 8, ""),
                    c = a._w2(t, "disabled", 8, !1),
                    o = function(e) {
                        const t = (0, L.SD)(Ye);
                        if (void 0 === t) throw new Error(`<${e} /> is missing a parent <Select /> component.`);
                        return t
                    }("SelectItem");
                a.TsN();
                var v = Je(),
                    d = {},
                    u = a.jfp(v, !0);
                a.cLc(v), a.vNg((() => {
                    d !== (d = n()) && (v.value = (v.__value = n()) ? ? ""), v.disabled = c(), a.$ZS(v, (r(), a.iTV(n()), a.vzK((() => r().selected === n())))), a.aIK(v, "data-selected", (r(), a.iTV(n()), a.vzK((() => r().selected === n())))), a.jax(u, l() || n())
                })), a.BCw(e, v), a.uYY(), i()
            }
            if (3645 == s.j) r = s(54152);
            var Ve = a.vUu('<span class="s-tag--sponsor"><!></span>'),
                ke = a.vUu('<button class="s-tag--dismiss" type="button"><span class="v-visible-sr"> </span><!></button>'),
                Ee = a.vUu("<!> <!><!>", 1);

            function Oe(e, t) {
                const s = a._w2(t, "size", 3, ""),
                    n = a._w2(t, "variant", 3, ""),
                    l = a._w2(t, "dismissable", 3, !1),
                    c = a._w2(t, "ignored", 3, !1),
                    o = a._w2(t, "watched", 3, !1),
                    v = a._w2(t, "i18nDismissButtonText", 3, "Dismiss tag"),
                    d = a._w2(t, "class", 3, ""),
                    u = a._w2(t, "ondismiss", 3, (() => {})),
                    p = a.iRd(t, ["$$slots", "$$events", "$$legacy", "size", "variant", "href", "dismissable", "ignored", "watched", "i18nDismissButtonText", "class", "ondismiss", "children", "sponsor", "role"]),
                    f = a.unG((() => ((e, t, s, a, i) => {
                        const r = "s-tag";
                        let n = r;
                        return e && (n += " " + e), [t, s].forEach((e => {
                            e && (n += ` ${r}__${e}`)
                        })), a && (n += ` ${r}__ignored`), i && (n += ` ${r}__watched`), n
                    })(d(), s(), n(), c(), o())));
                var g = a.Imx(),
                    w = a.esp(g);
                a.ND4(w, (() => t.href ? "a" : "span"), !1, ((e, s) => {
                    a.p_Y(e, (() => ({
                        class: a.JtY(f),
                        href: t.href,
                        role: t.role || t.href && "link",
                        ...p
                    })));
                    var n = Ee(),
                        c = a.esp(n),
                        o = e => {
                            var s = Ve(),
                                i = a.jfp(s);
                            a.UAl(i, (() => t.sponsor)), a.cLc(s), a.BCw(e, s)
                        };
                    a.if(c, (e => {
                        t.sponsor && e(o)
                    }));
                    var d = a.hg4(c, 2);
                    a.UAl(d, (() => t.children));
                    var g = a.hg4(d),
                        w = e => {
                            var t = ke();
                            t.__click = function(...e) {
                                u() ? .apply(this, e)
                            };
                            var s = a.jfp(t),
                                n = a.jfp(s, !0);
                            a.cLc(s), i(a.hg4(s), {
                                get src() {
                                    return r.j5$
                                }
                            }), a.cLc(t), a.vNg((() => a.jax(n, v()))), a.BCw(e, t)
                        };
                    a.if(g, (e => {
                        l() && !t.href && e(w)
                    })), a.BCw(s, n)
                })), a.BCw(e, g)
            }
            a.MmH(["click"])
        }
    }
]);