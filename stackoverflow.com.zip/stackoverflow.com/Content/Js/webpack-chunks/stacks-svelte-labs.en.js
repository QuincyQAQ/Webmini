"use strict";
(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [4365], {
        47287: (e, n, t) => {
            t.d(n, {
                Z_: () => T,
                Ip: () => p,
                aF: () => M,
                Sj: () => y,
                OM: () => Y,
                j0: () => ue,
                es: () => ne,
                jp: () => V,
                fU: () => H,
                V6: () => te
            });
            t(82170);
            var a = t(67578),
                r = t(69980);
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const o = /^(476|949)8$/.test(t.j) ? '<svg width="32" height="23" viewBox="0 0 32 23" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M14.609 19.2609C19.0993 19.2609 22.7394 15.6208 22.7394 11.1304C22.7394 6.64012 19.0993 3 14.609 3C10.1186 3 6.47852 6.64012 6.47852 11.1304C6.47852 15.6208 10.1186 19.2609 14.609 19.2609ZM14.609 22.2609C20.7561 22.2609 25.7394 17.2776 25.7394 11.1304C25.7394 4.98327 20.7561 0 14.609 0C8.46178 0 3.47852 4.98327 3.47852 11.1304C3.47852 17.2776 8.46178 22.2609 14.609 22.2609Z" fill="url(#paint0_linear_1023_82276)"/>\n\n<path class="rotator" opacity="0.8" fill-rule="evenodd" clip-rule="evenodd" d="M25.7393 11.1304C25.7393 17.2776 20.7561 22.2609 14.609 22.2609C8.46178 22.2609 3.47852 17.2776 3.47852 11.1304C3.47852 4.98327 8.46178 0 14.609 0C20.7561 0 25.7393 4.98326 25.7393 11.1304ZM20.1843 17.0482C18.7287 18.4201 16.767 19.2609 14.609 19.2609C10.1186 19.2609 6.47852 15.6208 6.47852 11.1304C6.47852 6.64012 10.1186 3 14.609 3C16.6069 3 18.4365 3.72066 19.8521 4.91621L21.8633 2.68857C24.2365 4.7298 25.7393 7.75461 25.7393 11.1304C25.7393 14.236 24.4675 17.0444 22.4163 19.0634L20.1843 17.0482Z" fill="white"/>\n\n<path class="star" d="M0.928526 3.01521L0 3.47947L0.92577 3.94236L1.39144 4.8737L1.85737 3.94183L2.78255 3.47924L1.85369 3.01481L1.39121 2.08984L0.928526 3.01521Z" fill="url(#paint1_linear_1023_82276)"/>\n<path class="star star--two" d="M30.1468 12.7531L29.2178 13.2176L30.1437 13.6805L30.6095 14.612L31.0756 13.6797L32.0003 13.2173L31.0717 12.753L30.6092 11.8281L30.1468 12.7531Z" fill="url(#paint2_linear_1023_82276)"/>\n<path class="star star--three" d="M27.5938 19.7094L28.5217 21.5651L29.448 19.7125L31.3044 18.7843L29.4506 17.8574L28.5219 16L27.5946 17.8544L25.7393 18.7821L27.5938 19.7094Z" fill="url(#paint3_linear_1023_82276)"/>\n\n<defs>\n   <linearGradient id="paint0_linear_1023_82276" x1="3.47852" y1="11.1304" x2="25.7394" y2="11.1304" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#AC76F0"/>\n      <stop offset="0.526042" stop-color="#297FFF"/>\n      <stop offset="1" stop-color="#6ABCF8"/>\n   </linearGradient>\n   <linearGradient id="paint1_linear_1023_82276" x1="0" y1="3.48177" x2="2.78255" y2="3.48177" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#AC76F0"/>\n      <stop offset="0.526042" stop-color="#297FFF"/>\n      <stop offset="1" stop-color="#6ABCF8"/>\n   </linearGradient>\n   <linearGradient id="paint2_linear_1023_82276" x1="29.2178" y1="13.2201" x2="32.0003" y2="13.2201" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#AC76F0"/>\n      <stop offset="0.526042" stop-color="#297FFF"/>\n      <stop offset="1" stop-color="#6ABCF8"/>\n   </linearGradient>\n   <linearGradient id="paint3_linear_1023_82276" x1="25.7393" y1="18.7826" x2="31.3044" y2="18.7826" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#AC76F0"/>\n      <stop offset="0.526042" stop-color="#297FFF"/>\n      <stop offset="1" stop-color="#6ABCF8"/>\n   </linearGradient>\n</defs>\n</svg>\n\n<style>\n    /* rotate */\n    .rotator {\n        transform-origin: center;\n        transform-box: fill-box;\n        animation: rotate .9s cubic-bezier(.5,.1,.5,.9) infinite;\n        -moz-animation: rotate .9s cubic-bezier(.5,.1,.5,.9) infinite;\n        -ms-animation: rotate .9s cubic-bezier(.5,.1,.5,.9) infinite;\n        -webkit-animation: rotate .9s cubic-bezier(.5,.1,.5,.9) infinite;\n        -o-animation: rotate .9s cubic-bezier(.5,.1,.5,.9) infinite;\n    }\n\n    @keyframes rotate {\n      from {\n          transform: rotate(-90deg);\n      }\n      to {\n          transform: rotate(270deg);\n      }\n    }\n\n    @-webkit-keyframes rotate {\n      from {\n          transform: rotate(-90deg);\n      }\n      to {\n          transform: rotate(270deg);\n      }\n    }\n\n    /* sparkle */\n    .star {\n        animation: sparkle 3s infinite;\n        -moz-animation: sparkle 3s infinite;\n        -ms-animation: sparkle 3s infinite;\n        -webkit-animation: sparkle 3s infinite;\n        -o-animation: sparkle 3s infinite;\n    }\n    .star--two {\n        animation-delay: 0.4s;\n    }\n    .star--three {\n        animation-delay: 0.8s;\n    }\n\n    @keyframes sparkle {\n        0% {\n          opacity: 1;\n        }\n        30% {\n          opacity: 1;\n        }\n        50% {\n          opacity: 0.2;\n        }\n        70% {\n          opacity: 1;\n        }\n        100% {\n          opacity: 1;\n        }\n      }\n\n      @-webkit-keyframes sparkle {\n          0% {\n            opacity: 1;\n          }\n          30% {\n            opacity: 1;\n          }\n          50% {\n            opacity: 0.2;\n          }\n          70% {\n            opacity: 1;\n          }\n          100% {\n            opacity: 1;\n          }\n        }\n</style>' : null;
            var i = t(99724),
                s = a.vUu('<div class="s-spinner fc-theme-primary svelte-s2am4v"><div class="v-visible-sr svelte-s2am4v">Loading…</div></div>'),
                l = a.vUu('<!> <span class="v-visible-sr svelte-s2am4v">Loading…</span>', 1),
                c = a.vUu('<span class="grid--row-start1 grid--col-start1 fs-body2 fw-normal svelte-s2am4v"> </span>'),
                d = a.vUu('<div aria-label="Loading AI-generated content..." class="svelte-s2am4v"><div class="progress-gradient w100 h12 bar-pill mb6 svelte-s2am4v"></div> <div class="progress-gradient w90 h12 bar-pill mb6 svelte-s2am4v"></div> <div class="progress-gradient w75 h12 bar-pill svelte-s2am4v"></div></div>'),
                u = a.vUu('<h3 class="d-flex g12 ai-center svelte-s2am4v"><!> <div class="d-grid svelte-s2am4v"></div></h3> <!>', 1);
            const v = {
                hash: "svelte-s2am4v",
                code: ".progress-gradient.svelte-s2am4v {background:repeating-linear-gradient(\n            to right,\n            rgba(186, 191, 197, 0.6),\n            rgba(186, 191, 197, 0.4),\n            rgba(186, 191, 197, 0.25),\n            rgba(186, 191, 197, 0.6)\n        );background-size:200% auto;\n        animation: svelte-s2am4v-gradient 1.5s infinite;animation-fill-mode:forwards;animation-timing-function:linear;}\n\n    @-webkit-keyframes svelte-s2am4v-gradient {\n        0% {\n            background-position: 0 0;\n        }\n        100% {\n            background-position: -200% 0;\n        }\n    }\n    @-moz-keyframes svelte-s2am4v-gradient {\n        0% {\n            background-position: 0 0;\n        }\n        100% {\n            background-position: -200% 0;\n        }\n    }\n    @keyframes svelte-s2am4v-gradient {\n        0% {\n            background-position: 0 0;\n        }\n        100% {\n            background-position: -200% 0;\n        }\n    }"
            };

            function p(e, n) {
                a.VCO(n, !0), a.kZQ(e, v);
                const t = a._w2(n, "messages", 19, (() => ["Processing request...", "Gathering sources...", "Crafting response..."])),
                    p = a._w2(n, "messageInterval", 3, 2e3),
                    w = a._w2(n, "transitionTime", 3, 1e3),
                    f = a._w2(n, "useStacksStyle", 3, !1);
                let g = a.wk1(0);
                (() => {
                    const e = setInterval((() => {
                        a.yoy(g), a.JtY(g) >= t().length - 1 && clearInterval(e)
                    }), p())
                })();
                var h = u(),
                    m = a.esp(h),
                    k = a.jfp(m),
                    y = e => {
                        var n = s();
                        a.BCw(e, n)
                    },
                    b = e => {
                        var n = l(),
                            t = a.esp(n);
                        (0, i.In)(t, {
                            get src() {
                                return o
                            }
                        }), a.K2T(2), a.BCw(e, n)
                    };
                a.if(k, (e => {
                    f() ? e(y) : e(b, !1)
                }));
                var x = a.hg4(k, 2);
                a.__1(x, 22, t, (e => e), ((e, n, t) => {
                    var o = a.Imx(),
                        i = a.esp(o),
                        s = e => {
                            var t = c(),
                                o = a.jfp(t, !0);
                            a.cLc(t), a.vNg((() => a.jax(o, n))), a.kYK(3, t, (() => r.Rv), (() => ({
                                duration: w()
                            }))), a.BCw(e, t)
                        };
                    a.if(i, (e => {
                        a.JtY(g) === a.JtY(t) && e(s)
                    })), a.BCw(e, o)
                })), a.cLc(x), a.cLc(m);
                var S = a.hg4(m, 2),
                    _ = e => {
                        var n = d();
                        a.BCw(e, n)
                    },
                    C = e => {
                        (0, i.EA)(e, {
                            label: "Loading AI-generated content...",
                            variant: "ai"
                        })
                    };
                a.if(S, (e => {
                    f() ? e(_) : e(C, !1)
                })), a.BCw(e, h), a.uYY()
            }
            const w = (e, n, t, r) => {
                    n(e.target.value), a.hZp(t, 0), r()
                },
                f = (e, n, t, r, o, i) => {
                    "ArrowDown" === e.key && n().length && a.JtY(t) < a.JtY(r).length - 1 && (a.cEh(t), o()), "ArrowUp" === e.key && n().length && a.JtY(t) > 0 && (a.cEh(t, -1), o()), "Enter" === e.key && n().length && (i.onItemSearchSelected({
                        item: a.JtY(r).length && a.JtY(t) >= 0 ? a.JtY(r)[a.JtY(t)] : null,
                        action: "keydown",
                        searchString: n()
                    }), n("")), "Escape" === e.key && e.stopPropagation()
                };
            var g = (e, n, t, r) => {
                    n.onItemSearchSelected({
                        item: a.JtY(t),
                        action: "click"
                    }), r("")
                },
                h = a.vUu('<li role="menuitem" class="h:bg-black-150"><button> </button></li>'),
                m = a.vUu('<ul class="s-menu hmx1 overflow-x-hidden" role="menu"></ul>'),
                k = a.vUu('<div role="combobox" tabindex="0" aria-controls="search-popover-popover"><!></div> <!>', 1);

            function y(e, n) {
                a.VCO(n, !0);
                let t = a._w2(n, "filterString", 15, ""),
                    r = a._w2(n, "highlightedItem", 15, null),
                    o = a.wk1(a.BXG([])),
                    s = a.BXG([]),
                    l = a.wk1(0),
                    c = a.unG((() => t().length > 0 && a.JtY(o).length > 0));
                const d = () => s[a.JtY(l)] ? .scrollIntoView ? .();
                a.MWq((() => {
                    t() || a.hZp(l, 0), n.searchItems(t()).then((e => {
                        a.hZp(o, e, !0), d()
                    })), d()
                })), a.MWq((() => {
                    r(a.JtY(o).length > 0 ? a.JtY(o)[a.JtY(l)] : null)
                })), (0, i.AM)(e, {
                    id: "search-popover",
                    position: "bottom",
                    get visible() {
                        return a.JtY(c)
                    },
                    children: (e, r) => {
                        var u = k(),
                            v = a.esp(u);
                        v.__input = [w, t, l, d], v.__keydown = [f, t, l, o, d, n];
                        var p = a.jfp(v);
                        (0, i.hj)(p, {
                            children: (e, t) => {
                                var r = a.Imx(),
                                    o = a.esp(r);
                                a.UAl(o, (() => n.children ? ? a.lQ1)), a.BCw(e, r)
                            },
                            $$slots: {
                                default: !0
                            }
                        }), a.cLc(v);
                        var y = a.hg4(v, 2);
                        (0, i.hl)(y, {
                            class: "wmx-initial",
                            children: (e, r) => {
                                var i = m();
                                a.__1(i, 23, (() => a.JtY(o)), ((e, n) => e + n), ((e, r, o) => {
                                    var i = h(),
                                        c = a.jfp(i);
                                    let d;
                                    c.__click = [g, n, r, t];
                                    var u = a.jfp(c, !0);
                                    a.cLc(c), a.cLc(i), a.Lcc(i, ((e, n) => s[n] = e), (e => s ? .[e]), (() => [a.JtY(o)])), a.vNg((e => {
                                        d = a.ysU(c, 1, "s-block-link", null, d, e), a.jax(u, a.JtY(r))
                                    }), [() => ({
                                        "bg-black-150": a.JtY(o) === a.JtY(l)
                                    })]), a.BCw(e, i)
                                })), a.cLc(i), a.f0J("mouseenter", i, (() => a.hZp(l, -1))), a.BCw(e, i)
                            },
                            $$slots: {
                                default: !0
                            }
                        }), a.vNg((() => a.aIK(v, "aria-expanded", a.JtY(c)))), a.BCw(e, u)
                    },
                    $$slots: {
                        default: !0
                    }
                }), a.uYY()
            }
            a.MmH(["input", "keydown", "click"]);
            var b = t(83281);
            const x = (e, n, t, r) => {
                    n(e.target.value), a.hZp(t, 0), r()
                },
                S = (e, n, t, r, o, i) => {
                    "ArrowDown" === e.key && n().length && a.JtY(t) < a.JtY(r).length - 1 && (a.cEh(t), o()), "ArrowUp" === e.key && n().length && a.JtY(t) > 0 && (a.cEh(t, -1), o()), "Enter" === e.key && n().length && (i.onItemSearchSelected({
                        item: a.JtY(r).length && a.JtY(t) >= 0 ? a.JtY(r)[a.JtY(t)] : null,
                        action: "keydown",
                        searchString: n()
                    }), n("")), "Escape" === e.key && e.stopPropagation()
                };
            var _ = a.vUu('<div role="menu" tabindex="-1"><!></div>'),
                C = a.vUu('<div role="combobox" tabindex="-1" aria-controls="search-popover-popover"><!></div> <!>', 1);

            function Y(e, n) {
                a.VCO(n, !0);
                let t = a._w2(n, "filterString", 15, ""),
                    r = a._w2(n, "highlightedItem", 15, null),
                    o = a._w2(n, "getDisplayString", 3, (e => String(e))),
                    i = a.wk1(a.BXG([])),
                    s = a.BXG([]),
                    l = a.wk1(0),
                    c = a.unG((() => t().length > 0 && a.JtY(i).length > 0));
                const d = () => s[a.JtY(l)] ? .scrollIntoView ? .();
                a.MWq((() => {
                    t() || a.hZp(l, 0), n.searchItems(t()).then((e => {
                        a.hZp(i, e, !0), d()
                    })), d()
                })), a.MWq((() => {
                    r(a.JtY(i).length > 0 ? a.JtY(i)[a.JtY(l)] : null)
                })), (0, b.AM)(e, {
                    id: "search-popover",
                    placement: "bottom",
                    get visible() {
                        return a.JtY(c)
                    },
                    children: (e, r) => {
                        var u = C(),
                            v = a.esp(u);
                        v.__input = [x, t, l, d], v.__keydown = [S, t, l, i, d, n];
                        var p = a.jfp(v);
                        (0, b.hj)(p, {
                            children: (e, t) => {
                                var r = a.Imx(),
                                    o = a.esp(r);
                                a.UAl(o, (() => n.children ? ? a.lQ1)), a.BCw(e, r)
                            },
                            $$slots: {
                                default: !0
                            }
                        }), a.cLc(v);
                        var w = a.hg4(v, 2);
                        (0, b.hl)(w, {
                            class: "wmx-initial",
                            children: (e, r) => {
                                var c = _(),
                                    d = a.jfp(c);
                                (0, b.W1)(d, {
                                    children: (e, r) => {
                                        var c = a.Imx(),
                                            d = a.esp(c);
                                        a.__1(d, 19, (() => a.JtY(i)), ((e, n) => o()(e) + n), ((e, r, i) => {
                                            const c = a.unG((() => a.JtY(l) === a.JtY(i) ? "bg-black-150 bar-md" : ""));
                                            a.Lcc((0, b.Dr)(e, {
                                                role: "button",
                                                get class() {
                                                    return a.JtY(c)
                                                },
                                                onclick: () => {
                                                    n.onItemSearchSelected({
                                                        item: a.JtY(r),
                                                        action: "click"
                                                    }), t("")
                                                },
                                                children: (e, n) => {
                                                    a.K2T();
                                                    var t = a.Qq7();
                                                    a.vNg((e => a.jax(t, e)), [() => o()(a.JtY(r))]), a.BCw(e, t)
                                                },
                                                $$slots: {
                                                    default: !0
                                                }
                                            }), ((e, n) => s[n] = e), (e => s ? .[e]), (() => [a.JtY(i)]))
                                        })), a.BCw(e, c)
                                    },
                                    $$slots: {
                                        default: !0
                                    }
                                }), a.cLc(c), a.f0J("mouseenter", c, (() => a.hZp(l, -1))), a.BCw(e, c)
                            },
                            $$slots: {
                                default: !0
                            }
                        }), a.vNg((() => a.aIK(v, "aria-expanded", a.JtY(c)))), a.BCw(e, u)
                    },
                    $$slots: {
                        default: !0
                    }
                }), a.uYY()
            }
            a.MmH(["input", "keydown"]);
            t(76467);
            var J = t(22024);
            if (682 == t.j) var L = t(54152);
            var I = t(12429);
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const F = 682 == t.j ? ["a[href]", "area[href]", 'input:not([disabled]):not([type="hidden"]):not([aria-hidden])', "select:not([disabled]):not([aria-hidden])", "textarea:not([disabled]):not([aria-hidden])", "button:not([disabled]):not([aria-hidden])", "iframe", "object", "embed", "[contenteditable]", '[tabindex]:not([tabindex^="-"])'] : null,
                E = e => {
                    var n;
                    const t = null === (n = document.defaultView) || void 0 === n ? void 0 : n.getComputedStyle(e);
                    return !(!t || "none" === t.getPropertyValue("display") || "hidden" === t.getPropertyValue("visibility"))
                },
                $ = async e => (await (0, J.io)(), [...e.querySelectorAll(F.join(", "))].filter(E)),
                U = e => {
                    e[0] && e[0].focus()
                },
                j = e => {
                    e[e.length - 1] && e[e.length - 1].focus()
                },
                O = (e, {
                    active: n,
                    initialFocusElement: t,
                    returnFocusElement: a,
                    suppressInitFocus: r,
                    suppressReturnFocus: o
                }) => {
                    let i;
                    const s = async n => {
                            const {
                                key: t,
                                shiftKey: a
                            } = n;
                            if ("Tab" === t) {
                                n.preventDefault(), n.stopPropagation();
                                const t = await $(e),
                                    r = document.activeElement;
                                a ? (({
                                    allFocusableItems: e,
                                    currentlyFocusedItem: n
                                }) => {
                                    if (!n) return void j(e);
                                    const t = e.indexOf(n);
                                    if (0 === t) return void j(e);
                                    const a = e[t - 1];
                                    a && a.focus()
                                })({
                                    allFocusableItems: t,
                                    currentlyFocusedItem: r
                                }) : (({
                                    allFocusableItems: e,
                                    currentlyFocusedItem: n
                                }) => {
                                    if (!n) return void U(e);
                                    const t = e.indexOf(n);
                                    if (e.length - 1 === t) return void U(e);
                                    const a = e[t + 1];
                                    a && a.focus()
                                })({
                                    allFocusableItems: t,
                                    currentlyFocusedItem: r
                                })
                            }
                        },
                        l = async () => {
                            if (r) return;
                            const n = await $(e);
                            null != i || (i = document.activeElement), t ? t.focus() : U(n), document.addEventListener("keydown", s)
                        },
                        c = () => {
                            o || (a ? a.focus() : null == i || i.focus(), document.removeEventListener("keydown", s), i = null)
                        };
                    return n && l(), {
                        update: ({
                            active: e
                        }) => {
                            e ? l() : c()
                        },
                        destroy: c
                    }
                };
            var B = a.vUu('<div class="d-flex g8 s-modal--footer"><!></div>'),
                A = a.vUu('<aside role="dialog"><div role="document"><h1 class="s-modal--header"><!></h1> <div class="s-modal--body"><!></div> <!> <!></div></aside>');

            function M(e, n) {
                const t = a.iWx(n);
                a.VCO(n, !1);
                const r = a.zgK();
                let o = a._w2(n, "id", 8),
                    s = a._w2(n, "visible", 12, !1),
                    l = a._w2(n, "state", 8, ""),
                    c = a._w2(n, "class", 8, ""),
                    d = a._w2(n, "i18nCloseButtonLabel", 8, "Close"),
                    u = a._w2(n, "preventCloseOnClickOutside", 8, !1),
                    v = a._w2(n, "hideCloseButton", 8, !1),
                    p = a._w2(n, "suppressInitFocus", 8, !1),
                    w = a._w2(n, "suppressReturnFocus", 8, !1);
                const f = (0, J.ur)(),
                    g = () => {
                        s() && (s(!1), f("close"))
                    };
                a.M3l((() => a.iTV(c())), (() => {
                    a.hZp(r, (e => {
                        let n = "s-modal--dialog";
                        return e && (n += " " + e), n
                    })(c()))
                })), a.iqF(), a.TsN();
                var h = A();
                let m;
                a.f0J("keydown", a.xa8, (e => {
                    "Escape" === e.key && g()
                }));
                var k = a.jfp(h),
                    y = a.jfp(k),
                    b = a.jfp(y);
                a.NIy(b, n, "header", {}, null), a.cLc(y);
                var x = a.hg4(y, 2),
                    S = a.jfp(x);
                a.NIy(S, n, "body", {}, null), a.cLc(x);
                var _ = a.hg4(x, 2),
                    C = e => {
                        var t = B(),
                            r = a.jfp(t);
                        a.NIy(r, n, "footer", {}, null), a.cLc(t), a.BCw(e, t)
                    };
                a.if(_, (e => {
                    a.vzK((() => t.footer)) && e(C)
                }));
                var Y = a.hg4(_, 2),
                    F = e => {
                        (0, i.$n)(e, {
                            variant: "muted",
                            icon: !0,
                            get "aria-label" () {
                                return d()
                            },
                            class: "s-modal--close",
                            onclick: g,
                            children: (e, n) => {
                                (0, i.In)(e, {
                                    get src() {
                                        return L.nFV
                                    },
                                    class: "modal-close"
                                })
                            },
                            $$slots: {
                                default: !0
                            }
                        })
                    };
                a.if(Y, (e => {
                    v() || e(F)
                })), a.cLc(k), a.XId(k, (e => (0, I.E) ? .(e))), a.XId(k, ((e, n) => O ? .(e, n)), (() => ({
                    active: s(),
                    suppressInitFocus: p(),
                    suppressReturnFocus: w()
                }))), a.cLc(h), a.vNg((e => {
                    m = a.ysU(h, 1, "s-modal", null, m, e), a.aIK(h, "aria-hidden", !s()), a.aIK(h, "aria-labelledby", `${o()}-title`), a.aIK(h, "aria-describedby", `${o()}-description`), a.ysU(k, 1, a.$z$(a.JtY(r))), a.aIK(y, "id", `${o()}-title`), a.aIK(x, "id", `${o()}-description`)
                }), [() => ({
                    "s-modal__danger": "danger" === l(),
                    "s-modal__celebration": "celebration" === l()
                })], a.Xdt), a.f0J("outclick", k, (() => !u() && g())), a.BCw(e, h), a.uYY()
            }
            var Z = a.vUu('<div class="d-flex ai-center ps-relative w100"><textarea></textarea> <pre aria-hidden="true"> <br/></pre></div>');
            const z = {
                hash: "svelte-p4ncyy",
                code: ".hmn48.svelte-p4ncyy {min-height:48px;}.hmn64.svelte-p4ncyy {min-height:64px;}textarea.svelte-p4ncyy {resize:none;}"
            };

            function T(e, n) {
                const t = a.gjz(n, ["children", "$$slots", "$$events", "$$legacy"]),
                    r = a.gjz(t, ["id", "variant", "value"]);
                a.VCO(n, !1), a.kZQ(e, z);
                const o = a.zgK();
                let i = a._w2(n, "id", 8),
                    s = a._w2(n, "variant", 8, "default"),
                    l = a._w2(n, "value", 12, "");
                a.M3l((() => a.iTV(s())), (() => {
                    a.hZp(o, (e => {
                        let n = "s-textarea ws-pre-wrap break-word hmx3 lh-lg";
                        return "chat" === e && (n = " py12 pr64 hmn48"), "comment" === e && (n += " hmn64"), {
                            textarea: `${n} ps-absolute i0 h100`,
                            grower: `${n} v-hidden overflow-hidden`
                        }
                    })(s()))
                })), a.iqF();
                var c = Z(),
                    d = a.jfp(c);
                a.VUN(d), a.p_Y(d, (() => ({
                    class: (a.JtY(o), a.vzK((() => a.JtY(o).textarea))),
                    rows: "1",
                    id: i(),
                    ...r
                })), void 0, "svelte-p4ncyy");
                var u = a.hg4(d, 2),
                    v = a.jfp(u, !0);
                a.K2T(), a.cLc(u), a.cLc(c), a.vNg((() => {
                    a.ysU(u, 1, a.$z$((a.JtY(o), a.vzK((() => a.JtY(o).grower)))), "svelte-p4ncyy"), a.jax(v, l())
                })), a.oJB(d, l), a.f0J("input", d, (function(e) {
                    a.Ibr.call(this, n, e)
                })), a.f0J("keydown", d, (function(e) {
                    a.Ibr.call(this, n, e)
                })), a.BCw(e, c), a.uYY()
            }
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const N = new Intl.NumberFormat("en-US", {
                    notation: "compact",
                    compactDisplay: "short",
                    maximumFractionDigits: 1
                }),
                G = new Intl.NumberFormat("en-US", {
                    notation: "standard"
                }),
                K = [{
                    condition: e => e < 1e4,
                    format: e => G.format(e)
                }, {
                    condition: e => e >= 1e4,
                    format: e => N.format(e).toLowerCase()
                }],
                V = e => {
                    for (const n of K)
                        if (n.condition(e)) return n.format(e);
                    return e.toString()
                };
            var q = t(74353),
                D = t.n(q),
                P = t(6279),
                W = t.n(P),
                X = t(53581),
                Q = t.n(X);
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, D().extend(W()), D().extend(Q());
            const R = {
                thresholds: [{
                    l: "s",
                    r: 1
                }, {
                    l: "m",
                    r: 1
                }, {
                    l: "mm",
                    r: 59,
                    d: "minute"
                }, {
                    l: "h",
                    r: 1
                }, {
                    l: "hh",
                    r: 23,
                    d: "hour"
                }, {
                    l: "d",
                    r: 1
                }, {
                    l: "dd",
                    r: 29,
                    d: "day"
                }],
                relativeTime: {
                    future: "in %s",
                    past: "%s ago",
                    s: "%d seconds ago",
                    ss: "%d seconds ago",
                    m: "1 minute ago",
                    mm: "%d minutes ago",
                    h: "1 hour ago",
                    hh: "%d hours ago",
                    d: "yesterday",
                    dd: "%d days ago"
                },
                rounding: Math.floor
            };
            D().updateLocale("en", R);
            const H = e => {
                const n = new Date,
                    t = new Date(e),
                    a = Math.floor((n.getTime() - t.getTime()) / 1e3),
                    r = {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                        hour12: !1
                    },
                    o = [{
                        condition: e => e <= 172800,
                        format: e => D()(e).fromNow(!0)
                    }, {
                        condition: e => n.getFullYear() === t.getFullYear(),
                        format: e => new Intl.DateTimeFormat("en-US", r).format(e).replace(/,([^,]*)$/, " at$1")
                    }];
                let i = new Intl.DateTimeFormat("en-US", { ...r,
                    year: "numeric"
                }).format(t).replace(/,([^,]*)$/, " at$1");
                for (const e of o)
                    if (e.condition(a)) {
                        i = e.format(t);
                        break
                    }
                return i
            };
            var ee = t(23626);
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const ne = async (e, n = void 0, t) => {
                var a, r;
                try {
                    const o = await fetch(e, n);
                    if (!o.ok) throw Error(`Failed to get response: ${o.statusText}`);
                    if (!(null === (a = o.headers.get("Content-Type")) || void 0 === a ? void 0 : a.startsWith("application/json"))) throw Error(`Invalidate content type: ${o.headers.get("Content-Type")}`);
                    const i = await o.json();
                    return i ? (r = i, (0, ee.xQ)(r, 100)) : t
                } catch (e) {
                    return e instanceof SyntaxError || e instanceof TypeError ? console.warn("Failed to parse JSON response:", e.message) : console.warn(e), t
                }
            };
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const te = async (e, n, t) => new Promise((function(a, r) {
                    t || (t = ae), t(e, n).then((e => {
                        e.success ? a(e.uploadedImage) : e.errorMessage ? r(e.errorMessage) : r("An error occurred when uploading the image.")
                    }))
                })),
                ae = async (e, n) => {
                    if (!n) return {
                        success: !1
                    };
                    const t = new FormData;
                    return t.append("file", n), t.append("fkey", e), await ne("/upload/image?method=json", {
                        method: "POST",
                        body: t
                    }, {
                        success: !1
                    })
                };
            if (7975 == t.j) var re = t(55022);
            var oe = a.vUu('<li class="s-input-message fc-error s-anchors s-anchors__underlined"><!></li>'),
                ie = a.vUu("<li><!></li>"),
                se = a.vUu('<ul class="my2"><!> <!></ul>'),
                le = a.vUu('<div class="s-input-message fc-error s-anchors s-anchors__underlined"><!></div>'),
                ce = a.vUu('<div class="s-input-message fc-warning s-anchors s-anchors__underlined"><!></div>'),
                de = a.vUu("<div><!></div>");

            function ue(e, n) {
                a.VCO(n, !0);
                const t = (0, re.A)(),
                    r = a.unG((() => (n.errors ? .length ? ? 0) + (n.warnings ? .length ? ? 0)));
                a.MWq((() => {
                    a.JtY(r) > 0 && document.querySelectorAll(`.js-warnings-and-errors-container-${t} .s-input-message a`).forEach((e => {
                        e instanceof HTMLAnchorElement && !e.hasAttribute("target") && e.setAttribute("target", "_blank")
                    }))
                }));
                var o = a.Imx(),
                    i = a.esp(o),
                    s = e => {
                        var o = de(),
                            i = a.jfp(o),
                            s = e => {
                                var t = se(),
                                    r = a.jfp(t),
                                    o = e => {
                                        var t = a.Imx(),
                                            r = a.esp(t);
                                        a.__1(r, 17, (() => n.errors), a.Pe0, ((e, n) => {
                                            var t = oe(),
                                                r = a.jfp(t);
                                            a.qyt(r, (() => a.JtY(n))), a.cLc(t), a.BCw(e, t)
                                        })), a.BCw(e, t)
                                    };
                                a.if(r, (e => {
                                    n.errors && e(o)
                                }));
                                var i = a.hg4(r, 2),
                                    s = e => {
                                        var t = a.Imx(),
                                            r = a.esp(t);
                                        a.__1(r, 17, (() => n.warnings), a.Pe0, ((e, t) => {
                                            var r = ie();
                                            let o;
                                            var i = a.jfp(r);
                                            a.qyt(i, (() => a.JtY(t))), a.cLc(r), a.vNg((e => o = a.ysU(r, 1, "s-input-message s-anchors s-anchors__underlined", null, o, e)), [() => ({
                                                "fc-error": n.errors ? .length > 0,
                                                "fc-warning": null == n.errors || 0 === n.errors.length
                                            })]), a.BCw(e, r)
                                        })), a.BCw(e, t)
                                    };
                                a.if(i, (e => {
                                    n.warnings && e(s)
                                })), a.cLc(t), a.BCw(e, t)
                            },
                            l = (e, t) => {
                                var r = e => {
                                        var t = le(),
                                            r = a.jfp(t);
                                        a.qyt(r, (() => n.errors[0])), a.cLc(t), a.BCw(e, t)
                                    },
                                    o = (e, t) => {
                                        var r = e => {
                                            var t = ce(),
                                                r = a.jfp(t);
                                            a.qyt(r, (() => n.warnings[0])), a.cLc(t), a.BCw(e, t)
                                        };
                                        a.if(e, (e => {
                                            null != n.warnings && n.warnings.length > 0 && e(r)
                                        }), t)
                                    };
                                a.if(e, (e => {
                                    null != n.errors && n.errors.length > 0 ? e(r) : e(o, !1)
                                }), t)
                            };
                        a.if(i, (e => {
                            a.JtY(r) > 1 ? e(s) : e(l, !1)
                        })), a.cLc(o), a.vNg((() => a.ysU(o, 1, `js-warnings-and-errors-container-${t??""} `))), a.BCw(e, o)
                    };
                a.if(i, (e => {
                    a.JtY(r) > 0 && e(s)
                })), a.BCw(e, o), a.uYY()
            }
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}
        }
    }
]);