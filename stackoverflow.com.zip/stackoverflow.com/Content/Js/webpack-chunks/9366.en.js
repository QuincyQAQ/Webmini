"use strict";
(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [9366], {
        39366: (e, t, r) => {
            function n(e, t) {
                return t ? Array.isArray(t) ? t.reduce(((e, t) => t(e)), e) : t(e) : e
            }

            function i(e) {
                return "[object Object]" === Object.prototype.toString.call(e)
            }

            function a(e) {
                return Object.keys(e || {}).reduce(((t, r) => Object.assign(Object.assign({}, t), {
                    [r]: i(e[r]) ? a(e[r]) : Array.isArray(e[r]) ? [...e[r]] : e[r]
                })), {})
            }

            function o(e, t, r) {
                e && (e = a(e)), i(e) || (e = {});
                const n = Array.isArray(t) ? t : t.match(/[^.[\]]+/g) || [],
                    o = n[n.length - 1];
                if (!o) return e;
                let s = e;
                for (let e = 0; e < n.length - 1; e++) {
                    const t = n[e];
                    if (!s[t] || !i(s[t]) && !Array.isArray(s[t])) {
                        const r = n[e + 1];
                        isNaN(Number(r)) ? s[t] = {} : s[t] = []
                    }
                    s = s[t]
                }
                return s[o] = r(s[o]), e
            }

            function s(e, t, r) {
                const n = r => String.prototype.split.call(t, r).filter(Boolean).reduce(((e, t) => null != e ? e[t] : e), e),
                    i = n(/[,[\]]+?/) || n(/[,[\].]+?/);
                return void 0 === i || i === e ? r : i
            }

            function u(e, t, r) {
                return o(e, t, (() => r))
            }

            function l(e) {
                return "INPUT" === (null == e ? void 0 : e.nodeName)
            }

            function c(e) {
                return "SELECT" === (null == e ? void 0 : e.nodeName)
            }

            function d(e) {
                return "FIELDSET" === (null == e ? void 0 : e.nodeName)
            }

            function f(e) {
                return l(e) || function(e) {
                    return "TEXTAREA" === (null == e ? void 0 : e.nodeName)
                }(e) || c(e)
            }

            function v(e) {
                return e.nodeType === Node.ELEMENT_NODE
            }

            function y(e, t) {
                return null != t ? t : f(e) ? e.name : ""
            }

            function p(e) {
                if (f(e)) return [e];
                if (0 === e.childElementCount) return [];
                const t = new Set;
                for (const r of e.children) {
                    if (f(r) && t.add(r), d(r))
                        for (const e of r.elements) f(e) && t.add(e);
                    r.childElementCount > 0 && p(r).forEach((e => t.add(e)))
                }
                return Array.from(t)
            }

            function m(e) {
                for (const t of e.elements)(f(t) || d(t)) && e.hasAttribute("data-felte-keep-on-remove") && !t.hasAttribute("data-felte-keep-on-remove") && (t.dataset.felteKeepOnRemove = e.dataset.felteKeepOnRemove)
            }

            function b(e) {
                return e.type.match(/^(number|range)$/) ? e.value ? +e.value : null : e.value
            }

            function h(e) {
                var t;
                let r = {},
                    n = {};
                for (const i of e.elements) {
                    if (d(i) && m(i), !f(i) || !i.name) continue;
                    const a = y(i);
                    if (l(i)) {
                        if ("checkbox" === i.type) {
                            if (void 0 === s(r, a)) {
                                if (1 === Array.from(e.querySelectorAll(`[name="${i.name}"]`)).filter((e => !!f(e) && a === y(e))).length) {
                                    r = u(r, a, i.checked), n = u(n, a, !1);
                                    continue
                                }
                                r = u(r, a, i.checked ? [i.value] : []), n = u(n, a, !1);
                                continue
                            }
                            Array.isArray(s(r, a)) && i.checked && (r = o(r, a, (e => [...e, i.value])));
                            continue
                        }
                        if ("radio" === i.type) {
                            if (s(r, a)) continue;
                            r = u(r, a, i.checked ? i.value : void 0), n = u(n, a, !1);
                            continue
                        }
                        if ("file" === i.type) {
                            r = u(r, a, i.multiple ? Array.from(i.files || []) : null === (t = i.files) || void 0 === t ? void 0 : t[0]), n = u(n, a, !1);
                            continue
                        }
                    } else if (c(i)) {
                        if (i.multiple) {
                            const e = Array.from(i.selectedOptions).map((e => e.value));
                            r = u(r, a, e)
                        } else r = u(r, a, i.value);
                        n = u(n, a, !1);
                        continue
                    }
                    const v = b(i);
                    r = u(r, a, v), n = u(n, a, !1)
                }
                return {
                    defaultData: r,
                    defaultTouched: n
                }
            }

            function g(e, t) {
                var r;
                if (!f(e)) return;
                const n = t;
                if (l(e)) {
                    if ("checkbox" === e.type) {
                        const t = n;
                        return void 0 === t || "boolean" == typeof t ? void(e.checked = !!t) : void(Array.isArray(t) && (t.includes(e.value) ? e.checked = !0 : e.checked = !1))
                    }
                    if ("radio" === e.type) {
                        const t = n;
                        return void(e.value === t ? e.checked = !0 : e.checked = !1)
                    }
                    if ("file" === e.type) {
                        if (t instanceof FileList) e.files = t;
                        else if (t instanceof File && "undefined" != typeof DataTransfer) {
                            const r = new DataTransfer;
                            r.items.add(t), e.files = r.files
                        } else if ("undefined" != typeof DataTransfer && Array.isArray(t) && t.some((e => e instanceof File))) {
                            const r = new DataTransfer;
                            for (const e of t) e instanceof File && r.items.add(e);
                            e.files = r.files
                        } else(!t || Array.isArray(t) && !t.length) && (e.files = null, e.value = "");
                        return
                    }
                } else if (c(e)) {
                    if (e.multiple) {
                        if (Array.isArray(n)) {
                            e.value = String(null !== (r = n[0]) && void 0 !== r ? r : "");
                            const t = n.map((e => String(e)));
                            for (const r of e.options) t.includes(r.value) ? r.selected = !0 : r.selected = !1
                        }
                    } else {
                        e.value = String(null != n ? n : "");
                        for (const t of e.options) t.value === String(n) ? t.selected = !0 : t.selected = !1
                    }
                    return
                }
                e.value = String(null != n ? n : "")
            }

            function A(e, t) {
                for (const r of e.elements) {
                    if (d(r) && m(r), !f(r) || !r.name) continue;
                    g(r, s(t, y(r)))
                }
            }

            function E(e, t) {
                return Object.keys(e || {}).reduce(((r, n) => Object.assign(Object.assign({}, r), {
                    [n]: t(e[n])
                })), {})
            }

            function w(e) {
                return function(t) {
                    if (i(t)) {
                        return function(e, t) {
                            var r = {};
                            for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                            if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                var i = 0;
                                for (n = Object.getOwnPropertySymbols(e); i < n.length; i++) t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (r[n[i]] = e[n[i]])
                            }
                            return r
                        }(S(t, e), ["key"])
                    }
                    return e
                }
            }

            function S(e, t) {
                return E(e, (e => i(e) ? S(e, t) : Array.isArray(e) ? e.map(w(t)) : t))
            }

            function O(e = 8) {
                const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                let r = "";
                for (let n = 0; n < e; n++) r += t.charAt(Math.floor(62 * Math.random()));
                return r
            }

            function j(e, t) {
                if (!e || Object(e) !== e) return;
                void 0 !== e && (e = a(e));
                const r = Array.isArray(t) ? t : t.toString().match(/[^.[\]]+/g) || [],
                    n = 1 === r.length ? e : s(e, r.slice(0, -1).join("."));
                return Array.isArray(n) ? n.splice(Number(r[r.length - 1]), 1) : null == n || delete n[r[r.length - 1]], e
            }

            function k(...e) {
                const t = e.pop(),
                    r = e.shift();
                if ("string" == typeof r) return r;
                const n = a(r);
                if (0 === e.length) return n;
                for (const r of e) {
                    if (!r) continue;
                    if ("string" == typeof r) return r;
                    let e = t(n, r);
                    if (void 0 !== e) return e;
                    const o = Array.from(new Set(Object.keys(n).concat(Object.keys(r))));
                    for (const s of o)
                        if (e = t(n[s], r[s]), void 0 !== e) n[s] = e;
                        else if (i(r[s]) && i(n[s])) n[s] = k(n[s], r[s], t);
                    else if (Array.isArray(r[s])) n[s] = r[s].map(((e, r) => {
                        if (!i(e)) return e;
                        return k(Array.isArray(n[s]) ? n[s][r] : n[s], e, t)
                    }));
                    else if (i(r[s])) {
                        const e = S(a(r[s]), void 0);
                        n[s] = k(e, r[s], t)
                    } else void 0 !== r[s] && (n[s] = r[s])
                }
                return n
            }

            function T(...e) {
                return k(...e, (() => {}))
            }

            function V(e, t) {
                return function(e, t) {
                    return Object.keys(e).some((r => t(e[r])))
                }(e, (e => i(e) ? V(e, t) : Array.isArray(e) ? 0 === e.length || e.every((e => "string" == typeof e)) ? t(e) : e.some((e => i(e) ? V(e, t) : t(e))) : t(e)))
            }

            function x(e) {
                let t;
                return function(e, ...t) {
                    const r = e.subscribe(...t);
                    return r.unsubscribe ? () => r.unsubscribe() : r
                }(e, (e => t = e))(), t
            }

            function D(e, t) {
                var r = {};
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                    var i = 0;
                    for (n = Object.getOwnPropertySymbols(e); i < n.length; i++) t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (r[n[i]] = e[n[i]])
                }
                return r
            }

            function F(e, t) {
                return E(e, (e => i(e) ? F(e, t) : Array.isArray(e) ? 0 === e.length || e.every((e => "string" == typeof e)) ? t : e.map((e => D(F(e, t), ["key"]))) : t))
            }

            function N(e) {
                return e ? E(e, (e => i(e) ? N(e) : Array.isArray(e) ? 0 === e.length || e.every((e => "string" == typeof e)) ? e : e.map((e => {
                    if (!i(e)) return e;
                    const t = N(e);
                    return t.key || (t.key = O()), t
                })) : e)) : {}
            }

            function P(e) {
                return e ? E(e, (e => i(e) ? P(e) : Array.isArray(e) ? 0 === e.length || e.every((e => "string" == typeof e)) ? e : e.map((e => {
                    if (!i(e)) return e;
                    return D(P(e), ["key"])
                })) : e)) : {}
            }
            r.d(t, {
                D: () => Q
            }), "function" == typeof SuppressedError && SuppressedError, "function" == typeof SuppressedError && SuppressedError;
            class L extends Error {
                constructor(e, t) {
                    super(e), this.name = "FelteSubmitError", this.response = t
                }
            }

            function C(e, t, r, n) {
                return o(e, t, (e => void 0 === e || Array.isArray(e) ? (e || (e = []), void 0 === n ? e.push(r) : e.splice(n, 0, r), e) : e))
            }

            function I(e) {
                return "function" == typeof e
            }

            function _(e) {
                return (t, r) => {
                    if ("string" == typeof t) {
                        const n = t;
                        e((e => {
                            const t = I(r) ? r(s(e, n)) : r;
                            return u(e, n, t)
                        }))
                    } else e((e => I(t) ? t(e) : t))
                }
            }

            function M({
                stores: e,
                config: t,
                validateErrors: r,
                validateWarnings: n,
                _getCurrentExtenders: l
            }) {
                var c;
                let d, v = N(null !== (c = t.initialValues) && void 0 !== c ? c : {});
                const {
                    data: y,
                    touched: p,
                    errors: m,
                    warnings: b,
                    isDirty: h,
                    isSubmitting: g,
                    interacted: E
                } = e, w = _(y.update), k = _(p.update), D = _(m.update), I = _(b.update);

                function M(e) {
                    w((t => {
                        const r = e(t);
                        return d && A(d, r), r
                    }))
                }
                const R = (e, t, r) => {
                    _(M)(e, t), "string" == typeof e && r && k(e, !0)
                };

                function U(e, t, r) {
                    const n = !!i(t) && F(t, !1),
                        a = i(n) ? S(n, []) : [];
                    t = i(t) ? Object.assign(Object.assign({}, t), {
                        key: O()
                    }) : t, m.update((t => C(t, e, a, r))), b.update((t => C(t, e, a, r))), p.update((t => C(t, e, n, r))), y.update((n => {
                        const i = C(n, e, t, r);
                        return setTimeout((() => d && A(d, i))), i
                    }))
                }

                function q(e) {
                    m.update(e), b.update(e), p.update(e), y.update((t => {
                        const r = e(t);
                        return setTimeout((() => d && A(d, r))), r
                    }))
                }

                function H(e) {
                    q((t => j(t, e)))
                }

                function W(e, t, r) {
                    q((n => function(e, t, r, n) {
                        return o(e, t, (e => e && Array.isArray(e) ? ([e[r], e[n]] = [e[n], e[r]], e) : e))
                    }(n, e, t, r)))
                }

                function $(e, t, r) {
                    q((n => function(e, t, r, n) {
                        return o(e, t, (e => e && Array.isArray(e) ? (e.splice(n, 0, e.splice(r, 1)[0]), e) : e))
                    }(n, e, t, r)))
                }

                function B(e) {
                    const t = s(v, e),
                        r = !!i(t) && F(t, !1),
                        n = i(r) ? S(r, []) : [];
                    y.update((r => {
                        const n = u(r, e, t);
                        return d && A(d, n), n
                    })), p.update((t => u(t, e, r))), m.update((t => u(t, e, n))), b.update((t => u(t, e, n)))
                }
                const K = _(g.update),
                    X = _(h.update),
                    z = _(E.update);

                function G() {
                    R(a(v)), k((e => S(e, !1))), E.set(null), h.set(!1)
                }

                function J(e) {
                    return async function(i) {
                        var a, o, s, u, c, v, h;
                        const {
                            createErrorEvent: A,
                            createSubmitEvent: O,
                            createSuccessEvent: j
                        } = function() {
                            class e extends CustomEvent {
                                constructor(e) {
                                    super("feltesuccess", {
                                        detail: e
                                    })
                                }
                            }
                            class t extends CustomEvent {
                                constructor(e) {
                                    super("felteerror", {
                                        detail: e,
                                        cancelable: !0
                                    })
                                }
                                setErrors(e) {
                                    this.preventDefault(), this.errors = e
                                }
                            }
                            class r extends Event {
                                constructor() {
                                    super("feltesubmit", {
                                        cancelable: !0
                                    })
                                }
                                handleSubmit(e) {
                                    this.onSubmit = e
                                }
                                handleError(e) {
                                    this.onError = e
                                }
                                handleSuccess(e) {
                                    this.onSuccess = e
                                }
                            }
                            return {
                                createErrorEvent: e => new t(e),
                                createSubmitEvent: () => new r,
                                createSuccessEvent: t => new e(t)
                            }
                        }(), N = O();
                        null == d || d.dispatchEvent(N);
                        const C = null !== (o = null !== (a = N.onError) && void 0 !== a ? a : null == e ? void 0 : e.onError) && void 0 !== o ? o : t.onError,
                            _ = null !== (u = null !== (s = N.onSuccess) && void 0 !== s ? s : null == e ? void 0 : e.onSuccess) && void 0 !== u ? u : t.onSuccess,
                            M = null !== (h = null !== (v = null !== (c = N.onSubmit) && void 0 !== c ? c : null == e ? void 0 : e.onSubmit) && void 0 !== v ? v : t.onSubmit) && void 0 !== h ? h : function(e) {
                                if (e) return async function() {
                                    let t = new FormData(e);
                                    const r = new URL(e.action),
                                        n = "get" === e.method.toLowerCase() ? "get" : r.searchParams.get("_method") || e.method;
                                    let i, a = e.enctype;
                                    e.querySelector('input[type="file"]') && (a = "multipart/form-data"), "get" !== n && "application/x-www-form-urlencoded" !== a || (t = new URLSearchParams(t)), "get" === n ? (t.forEach(((e, t) => {
                                        r.searchParams.append(t, e)
                                    })), i = {
                                        method: n,
                                        headers: {
                                            Accept: "application/json"
                                        }
                                    }) : i = {
                                        method: n,
                                        body: t,
                                        headers: Object.assign(Object.assign({}, "multipart/form-data" !== a && {
                                            "Content-Type": a
                                        }), {
                                            Accept: "application/json"
                                        })
                                    };
                                    const o = await window.fetch(r.toString(), i);
                                    if (o.ok) return o;
                                    throw new L("An error occurred while submitting the form", o)
                                }
                            }(d);
                        if (!M) return;
                        if (null == i || i.preventDefault(), N.defaultPrevented) return;
                        g.set(!0), E.set(null);
                        const q = P(x(y)),
                            K = await r(q, null == e ? void 0 : e.validate),
                            X = await n(q, null == e ? void 0 : e.warn);
                        if (X && b.set(T(S(q, []), X)), p.set(F(q, !0)), K) {
                            p.set(F(K, !0));
                            if (V(K, (e => Array.isArray(e) ? e.length >= 1 : !!e))) return await new Promise((e => setTimeout(e))), l().forEach((e => {
                                var t;
                                return null === (t = e.onSubmitError) || void 0 === t ? void 0 : t.call(e, {
                                    data: q,
                                    errors: K
                                })
                            })), void g.set(!1)
                        }
                        const z = {
                            event: i,
                            setFields: R,
                            setData: w,
                            setTouched: k,
                            setErrors: D,
                            setWarnings: I,
                            unsetField: H,
                            addField: U,
                            resetField: B,
                            reset: G,
                            setInitialValues: Q.setInitialValues,
                            moveField: $,
                            swapFields: W,
                            form: d,
                            controls: d && Array.from(d.elements).filter(f),
                            config: Object.assign(Object.assign({}, t), e)
                        };
                        try {
                            const e = await M(q, z);
                            null == d || d.dispatchEvent(j(Object.assign({
                                response: e
                            }, z))), await (null == _ ? void 0 : _(e, z))
                        } catch (e) {
                            const t = A(Object.assign({
                                error: e
                            }, z));
                            if (null == d || d.dispatchEvent(t), !C && !t.defaultPrevented) throw e;
                            if (!C && !t.errors) return;
                            const r = t.errors || await (null == C ? void 0 : C(e, z));
                            r && (p.set(F(r, !0)), m.set(r), await new Promise((e => setTimeout(e))), l().forEach((e => {
                                var t;
                                return null === (t = e.onSubmitError) || void 0 === t ? void 0 : t.call(e, {
                                    data: q,
                                    errors: x(m)
                                })
                            })))
                        } finally {
                            g.set(!1)
                        }
                    }
                }
                const Q = {
                    setData: w,
                    setFields: R,
                    setTouched: k,
                    setErrors: D,
                    setWarnings: I,
                    setIsSubmitting: K,
                    setIsDirty: X,
                    setInteracted: z,
                    validate: async function() {
                        const e = x(y);
                        p.set(F(e, !0)), E.set(null);
                        const t = await r(e);
                        return await n(e), t
                    },
                    reset: G,
                    unsetField: H,
                    resetField: B,
                    addField: U,
                    swapFields: W,
                    moveField: $,
                    createSubmitHandler: J,
                    handleSubmit: J(),
                    setInitialValues: e => {
                        v = N(e)
                    }
                };
                return {
                    public: Q,
                    private: {
                        _setFormNode(e) {
                            d = e
                        },
                        _getInitialValues: () => v
                    }
                }
            }

            function R(e) {
                let t = e;
                for (; t && "FORM" !== t.nodeName;) {
                    if (t.hasAttribute("data-felte-ignore")) return !0;
                    t = t.parentElement
                }
                return !1
            }

            function U(e, t, {
                onInit: r,
                onEnd: n
            } = {}) {
                let i;
                return (...a) => {
                    i || null == r || r(), i && clearTimeout(i), i = setTimeout((() => {
                        e.apply(this, a), i = void 0, null == n || n()
                    }), t)
                }
            }

            function q(e, t) {
                if (!i(e) || !i(t)) {
                    if (Array.isArray(t)) {
                        if (t.some(i)) return;
                        const r = Array.isArray(e) ? e : [];
                        return t.map(((e, t) => {
                            var n;
                            return null !== (n = r[t]) && void 0 !== n ? n : e
                        }))
                    }
                    return void 0 !== e ? e : void 0
                }
            }

            function H(...e) {
                return k(...e, q)
            }

            function W({
                helpers: e,
                stores: t,
                config: r,
                extender: n,
                createSubmitHandler: o,
                handleSubmit: d,
                _setFormNode: m,
                _getInitialValues: g,
                _setCurrentExtenders: A,
                _getCurrentExtenders: E
            }) {
                const {
                    setFields: w,
                    setTouched: S,
                    reset: O,
                    setInitialValues: k
                } = e, {
                    addValidator: V,
                    addTransformer: D,
                    validate: F
                } = e, {
                    data: N,
                    errors: P,
                    warnings: L,
                    touched: C,
                    isSubmitting: I,
                    isDirty: _,
                    interacted: M,
                    isValid: q,
                    isValidating: W
                } = t;
                return {
                    form: function(t) {
                        function $(e) {
                            return function(n) {
                                return n({
                                    form: t,
                                    stage: e,
                                    controls: Array.from(t.elements).filter(f),
                                    data: N,
                                    errors: P,
                                    warnings: L,
                                    touched: C,
                                    isValid: q,
                                    isValidating: W,
                                    isSubmitting: I,
                                    isDirty: _,
                                    interacted: M,
                                    config: r,
                                    addValidator: V,
                                    addTransformer: D,
                                    setFields: w,
                                    validate: F,
                                    reset: O,
                                    createSubmitHandler: o,
                                    handleSubmit: d
                                })
                            }
                        }
                        t.requestSubmit || (t.requestSubmit = d), A(n.map($("MOUNT"))), t.noValidate = !!r.validate;
                        const {
                            defaultData: B,
                            defaultTouched: K
                        } = h(t);

                        function X(e) {
                            const t = e.target;
                            if (!t || !f(t) || c(t) || R(t)) return;
                            if (["checkbox", "radio", "file"].includes(t.type)) return;
                            if (!t.name) return;
                            _.set(!0);
                            const r = b(t);
                            M.set(t.name), N.update((e => u(e, y(t), r)))
                        }

                        function z(e) {
                            const r = e.target;
                            if (r && f(r) && !R(r) && r.name)
                                if (S(y(r), !0), M.set(r.name), (c(r) || ["checkbox", "radio", "file", "hidden"].includes(r.type)) && _.set(!0), "hidden" === r.type && N.update((e => u(e, y(r), r.value))), c(r)) ! function(e) {
                                    if (e.multiple) {
                                        const t = Array.from(e.selectedOptions).map((e => e.value));
                                        N.update((r => u(r, y(e), t)))
                                    } else N.update((t => u(t, y(e), e.value)))
                                }(r);
                                else {
                                    if (!l(r)) return;
                                    "checkbox" === r.type ? function(e) {
                                        const r = y(e),
                                            n = Array.from(t.querySelectorAll(`[name="${e.name}"]`)).filter((e => !!f(e) && r === y(e)));
                                        if (0 !== n.length) 1 === n.length ? N.update((t => u(t, y(e), e.checked))) : N.update((t => u(t, y(e), n.filter(l).filter((e => e.checked)).map((e => e.value)))))
                                    }(r) : "radio" === r.type ? function(e) {
                                        const r = t.querySelectorAll(`[name="${e.name}"]`),
                                            n = Array.from(r).find((e => l(e) && e.checked));
                                        N.update((t => u(t, y(e), null == n ? void 0 : n.value)))
                                    }(r) : "file" === r.type && function(e) {
                                        var t;
                                        const r = Array.from(null !== (t = e.files) && void 0 !== t ? t : []);
                                        N.update((t => u(t, y(e), e.multiple ? r : r[0])))
                                    }(r)
                                }
                        }

                        function G(e) {
                            const t = e.target;
                            t && f(t) && !R(t) && t.name && (S(y(t), !0), M.set(t.name))
                        }

                        function J(e) {
                            e.preventDefault(), O()
                        }
                        m(t), k(T(a(B), g())), w(g()), C.set(K);
                        const Q = U((() => {
                            E().forEach((e => {
                                var t;
                                return null === (t = e.destroy) || void 0 === t ? void 0 : t.call(e)
                            })), A(n.map($("UPDATE")));
                            const {
                                defaultData: r,
                                defaultTouched: i
                            } = h(t);
                            N.update((e => H(e, r))), C.update((e => H(e, i))), e.setFields(x(N))
                        }), 0);
                        let Y = [];
                        const Z = U((() => {
                            E().forEach((e => {
                                    var t;
                                    return null === (t = e.destroy) || void 0 === t ? void 0 : t.call(e)
                                })), A(n.map($("UPDATE"))),
                                function(e) {
                                    let t = x(N),
                                        r = x(C),
                                        n = x(P),
                                        a = x(L);
                                    for (const o of e.reverse()) {
                                        if (o.hasAttribute("data-felte-keep-on-remove") && "false" !== o.dataset.felteKeepOnRemove) continue;
                                        const e = /.*(\[[0-9]+\]|\.[0-9]+)\.[^.]+$/;
                                        let u = y(o);
                                        const l = x(C);
                                        if (e.test(u)) {
                                            const e = u.split(".").slice(0, -1).join("."),
                                                t = s(l, e);
                                            i(t) && Object.keys(t).length <= 1 && (u = e)
                                        }
                                        t = j(t, u), r = j(r, u), n = j(n, u), a = j(a, u)
                                    }
                                    N.set(t), C.set(r), P.set(n), L.set(a)
                                }(Y), Y = []
                        }), 0);

                        function ee(e) {
                            const t = Array.from(e.addedNodes).some((e => {
                                if (!v(e)) return !1;
                                if (f(e)) return !0;
                                return p(e).length > 0
                            }));
                            t && Q()
                        }

                        function te(e) {
                            for (const t of e.removedNodes) {
                                if (!v(t)) continue;
                                const e = p(t);
                                0 !== e.length && (Y.push(...e), Z())
                            }
                        }
                        const re = new MutationObserver((function(e) {
                            for (const t of e) "childList" === t.type && (t.addedNodes.length > 0 && ee(t), t.removedNodes.length > 0 && te(t))
                        }));
                        re.observe(t, {
                            childList: !0,
                            subtree: !0
                        }), t.addEventListener("input", X), t.addEventListener("change", z), t.addEventListener("focusout", G), t.addEventListener("submit", d), t.addEventListener("reset", J);
                        const ne = P.subscribe((e => {
                            for (const r of t.elements) {
                                if (!f(r) || !r.name) continue;
                                const t = s(e, y(r)),
                                    n = Array.isArray(t) ? t.join("\n") : "string" == typeof t ? t : void 0;
                                n !== r.dataset.felteValidationMessage && (n ? (r.dataset.felteValidationMessage = n, r.setAttribute("aria-invalid", "true")) : (delete r.dataset.felteValidationMessage, r.removeAttribute("aria-invalid")))
                            }
                        }));
                        return {
                            destroy() {
                                re.disconnect(), t.removeEventListener("input", X), t.removeEventListener("change", z), t.removeEventListener("focusout", G), t.removeEventListener("submit", d), t.removeEventListener("reset", J), ne(), E().forEach((e => {
                                    var t;
                                    return null === (t = e.destroy) || void 0 === t ? void 0 : t.call(e)
                                }))
                            }
                        }
                    }
                }
            }

            function $(e, t) {
                if (!i(e) && !i(t)) {
                    if (null === e || "" === e) return t;
                    if (null === t || "" === t) return e;
                    if (!t) return e;
                    if (e && t) {
                        if (Array.isArray(e)) {
                            if (!Array.isArray(t)) return [...e, t];
                            const r = [],
                                n = Math.max(t.length, e.length);
                            for (let a = 0; a < n; a++) {
                                let n = e[a],
                                    o = t[a];
                                i(n) || i(o) ? r.push(B([null != n ? n : {}, null != o ? o : {}])) : (Array.isArray(n) || (n = [n]), Array.isArray(o) || (o = [o]), r.push(...n, ...o))
                            }
                            return r.filter(Boolean)
                        }
                        return Array.isArray(t) || (t = [t]), [e, ...t].reduce(((e, t) => e.concat(t)), []).filter(Boolean)
                    }
                }
            }

            function B(e) {
                return k(...e, $)
            }

            function K(e, t) {
                if (i(e)) return !t || i(t) && 0 === Object.keys(t).length ? S(e, null) : void 0;
                if (Array.isArray(e)) {
                    if (e.some(i)) return;
                    const r = Array.isArray(t) ? t : [];
                    return e.map(((e, t) => {
                        const n = r[t];
                        return Array.isArray(n) && 0 === n.length ? null : e && n || null
                    }))
                }
                return Array.isArray(t) && 0 === t.length ? null : Array.isArray(t) ? e ? t : null : e && t ? [t] : null
            }

            function X(e, t) {
                if (i(e)) return !t || i(t) && 0 === Object.keys(t).length ? S(e, null) : void 0;
                if (Array.isArray(e)) {
                    if (e.some(i)) return;
                    const r = Array.isArray(t) ? t : [];
                    return e.map(((e, t) => {
                        const n = r[t];
                        return Array.isArray(n) && 0 === n.length ? null : n || null
                    }))
                }
                return Array.isArray(t) && 0 === t.length ? null : Array.isArray(t) ? t : t ? [t] : null
            }

            function z([e, t]) {
                return k(t, e, K)
            }

            function G([e, t]) {
                return k(t, e, X)
            }

            function J(e, t) {
                var r, i, o, s, u, l, c, d, f;
                const v = function(e) {
                        return function(t, r, n) {
                            const i = Array.isArray(t) ? t : [t],
                                a = new Array(i.length),
                                o = e(n),
                                s = o.set,
                                u = o.subscribe;
                            let l;
                            return o.subscribe = function(e) {
                                const t = u(e);
                                return () => {
                                    t()
                                }
                            }, [o, function() {
                                l = i.map(((e, t) => e.subscribe((e => {
                                    a[t] = e, s(r(a))
                                }))))
                            }, function() {
                                null == l || l.forEach((e => e()))
                            }]
                        }
                    }(e),
                    y = t.initialValues = t.initialValues ? N(n(a(t.initialValues), t.transform)) : {},
                    p = F(P(y), !1),
                    m = e(p),
                    b = e(0),
                    [h, g, A] = v([m, b], (([e, t]) => V(e, (e => !!e)) && t >= 1), !1);

                function E(e) {
                    let t;
                    return async function(r, n, i, a = !1) {
                        if (!i || !r) return;
                        let o = n && Object.keys(n).length > 0 ? n : S(r, []);
                        const s = function(e) {
                            const t = {
                                aborted: !1,
                                priority: e
                            };
                            return {
                                signal: t,
                                abort() {
                                    t.aborted = !0
                                }
                            }
                        }(a);
                        if ((null == t ? void 0 : t.signal.priority) && !a || (null == t || t.abort(), t = s), t.signal.priority && !a) return;
                        b.update((e => e + 1));
                        const u = (l = P(r), (c = i) ? (Array.isArray(c) ? c : [c]).map((e => e(l))) : []);
                        var l, c;
                        return u.forEach((async t => {
                            const r = await t;
                            s.signal.aborted || (o = B([o, r]), e.set(o))
                        })), await Promise.all(u), t = void 0, b.update((e => e - 1)), o
                    }
                }
                delete h.set, delete h.update;
                let w = S(p, []);
                const O = e(y),
                    j = S(p, []),
                    k = e(j),
                    T = e(a(j)),
                    [x, D, L] = v([k, T], B, a(j)),
                    C = S(p, []),
                    I = e(C),
                    _ = e(a(C)),
                    [M, R, q] = v([I, _], B, a(C)),
                    [H, W, $] = v([x, m], z, a(j)),
                    [K, X, J] = v([M, m], G, a(C));
                let Q = !1;
                const [Y, Z, ee] = v(x, (([e]) => {
                    var r;
                    return Q ? !V(e, (e => Array.isArray(e) ? e.length >= 1 : !!e)) : (Q = !0, !t.validate && !(null === (r = t.debounced) || void 0 === r ? void 0 : r.validate))
                }), !t.validate && !(null === (r = t.debounced) || void 0 === r ? void 0 : r.validate));
                delete Y.set, delete Y.update;
                const te = e(!1),
                    re = e(!1),
                    ne = e(null),
                    ie = E(k),
                    ae = E(I),
                    oe = E(T),
                    se = E(_),
                    ue = U(oe, null !== (u = null !== (o = null === (i = t.debounced) || void 0 === i ? void 0 : i.validateTimeout) && void 0 !== o ? o : null === (s = t.debounced) || void 0 === s ? void 0 : s.timeout) && void 0 !== u ? u : 300, {
                        onInit: () => {
                            b.update((e => e + 1))
                        },
                        onEnd: () => {
                            b.update((e => e - 1))
                        }
                    }),
                    le = U(se, null !== (f = null !== (c = null === (l = t.debounced) || void 0 === l ? void 0 : l.warnTimeout) && void 0 !== c ? c : null === (d = t.debounced) || void 0 === d ? void 0 : d.timeout) && void 0 !== f ? f : 300);
                let ce = j,
                    de = C;

                function fe() {
                    const e = O.subscribe((e => {
                            var r, n;
                            const i = P(e);
                            ie(i, w, t.validate), ae(i, w, t.warn), ue(i, w, null === (r = t.debounced) || void 0 === r ? void 0 : r.validate), le(i, w, null === (n = t.debounced) || void 0 === n ? void 0 : n.warn)
                        })),
                        r = m.subscribe((e => {
                            w = S(e, [])
                        })),
                        n = x.subscribe((e => {
                            ce = e
                        })),
                        i = M.subscribe((e => {
                            de = e
                        }));
                    return D(), Z(), R(), W(), X(), g(),
                        function() {
                            e(), $(), L(), q(), J(), ee(), A(), r(), n(), i()
                        }
                }

                function ve(e) {
                    k.set(e(ce)), T.set({})
                }

                function ye(e) {
                    I.set(e(de)), _.set({})
                }
                return H.set = function(e) {
                    ve((() => e))
                }, H.update = ve, K.set = function(e) {
                    ye((() => e))
                }, K.update = ye, {
                    data: O,
                    errors: H,
                    warnings: K,
                    touched: m,
                    isValid: Y,
                    isSubmitting: te,
                    isDirty: re,
                    isValidating: h,
                    interacted: ne,
                    validateErrors: async function(e, r) {
                        var n;
                        const i = ie(e, w, null != r ? r : t.validate, !0);
                        if (r) return i;
                        const a = oe(e, w, null === (n = t.debounced) || void 0 === n ? void 0 : n.validate, !0);
                        return B(await Promise.all([i, a]))
                    },
                    validateWarnings: async function(e, r) {
                        var n;
                        const i = ae(e, w, null != r ? r : t.warn, !0);
                        if (r) return i;
                        const a = se(e, w, null === (n = t.debounced) || void 0 === n ? void 0 : n.warn, !0);
                        return B(await Promise.all([i, a]))
                    },
                    cleanup: t.preventStoreStart ? () => {} : fe(),
                    start: fe
                }
            }

            function Q(e, t) {
                var r, i;

                function a(t, {
                    debounced: r,
                    level: n
                } = {
                    debounced: !1,
                    level: "error"
                }) {
                    var i;
                    const a = "error" === n ? "validate" : "warn";
                    null !== (i = e.debounced) && void 0 !== i || (e.debounced = {});
                    const o = r ? e.debounced : e;
                    o[a] ? o[a] = [...o[a], t] : o[a] = [t]
                }

                function o(t) {
                    e.transform ? e.transform = [...e.transform, t] : e.transform = [t]
                }
                null !== (r = e.extend) && void 0 !== r || (e.extend = []), null !== (i = e.debounced) && void 0 !== i || (e.debounced = {}), e.validate && !Array.isArray(e.validate) && (e.validate = [e.validate]), e.debounced.validate && !Array.isArray(e.debounced.validate) && (e.debounced.validate = [e.debounced.validate]), e.transform && !Array.isArray(e.transform) && (e.transform = [e.transform]), e.warn && !Array.isArray(e.warn) && (e.warn = [e.warn]), e.debounced.warn && !Array.isArray(e.debounced.warn) && (e.debounced.warn = [e.debounced.warn]);
                const s = Array.isArray(e.extend) ? e.extend : [e.extend];
                let u = [];
                const l = () => u,
                    {
                        isSubmitting: c,
                        isValidating: d,
                        data: f,
                        errors: v,
                        warnings: y,
                        touched: p,
                        isValid: m,
                        isDirty: b,
                        cleanup: h,
                        start: g,
                        validateErrors: A,
                        validateWarnings: E,
                        interacted: w
                    } = J(t.storeFactory, e),
                    S = f.update,
                    O = f.set;
                f.update = t => S((r => N(n(t(r), e.transform)))), f.set = t => O(N(n(t, e.transform)));
                const j = M({
                        extender: s,
                        config: e,
                        addValidator: a,
                        addTransformer: o,
                        validateErrors: A,
                        validateWarnings: E,
                        _getCurrentExtenders: l,
                        stores: {
                            data: f,
                            errors: v,
                            warnings: y,
                            touched: p,
                            isValid: m,
                            isValidating: d,
                            isSubmitting: c,
                            isDirty: b,
                            interacted: w
                        }
                    }),
                    {
                        createSubmitHandler: k,
                        handleSubmit: T
                    } = j.public;
                u = s.map((t => t({
                    stage: "SETUP",
                    errors: v,
                    warnings: y,
                    touched: p,
                    data: f,
                    isDirty: b,
                    isValid: m,
                    isValidating: d,
                    isSubmitting: c,
                    interacted: w,
                    config: e,
                    addValidator: a,
                    addTransformer: o,
                    setFields: j.public.setFields,
                    reset: j.public.reset,
                    validate: j.public.validate,
                    handleSubmit: T,
                    createSubmitHandler: k
                })));
                const V = Object.assign({
                        config: e,
                        stores: {
                            data: f,
                            touched: p,
                            errors: v,
                            warnings: y,
                            isSubmitting: c,
                            isValidating: d,
                            isValid: m,
                            isDirty: b,
                            interacted: w
                        },
                        createSubmitHandler: k,
                        handleSubmit: T,
                        helpers: Object.assign(Object.assign({}, j.public), {
                            addTransformer: o,
                            addValidator: a
                        }),
                        extender: s,
                        _getCurrentExtenders: l,
                        _setCurrentExtenders: e => {
                            u = e
                        }
                    }, j.private),
                    {
                        form: x
                    } = W(V);
                return Object.assign({
                    data: f,
                    errors: v,
                    warnings: y,
                    touched: p,
                    isValid: m,
                    isSubmitting: c,
                    isValidating: d,
                    isDirty: b,
                    interacted: w,
                    form: x,
                    cleanup: h,
                    startStores: g
                }, j.public)
            }
        }
    }
]);