"use strict";
(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [3696], {
        41134: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(52730), r.vUu('<div> <p class="s-description"> </p></div>'), r.vUu('<p class="s-description"> </p>'), r.vUu(" <!>", 1), r.vUu('<input type="checkbox"/> <!>', 1);
            r.MmH(["change"])
        },
        78430: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(41134), t(37079), r.vUu('<fieldset><legend class="s-label"> </legend> <!></fieldset>')
        },
        39772: (s, a, t) => {
            t(82170), t(67578)
        },
        77556: (s, a, t) => {
            t(82170);
            var r = t(67578);
            r.vUu('<nav class="pl24"><ul class="list-reset s-pagination"><!></ul></nav>');
            r.vUu("<li><a><!></a></li>");
            r.MmH(["click"]);
            t(76467), r.vUu('<li class="s-pagination--item s-pagination--item__clear">…</li>');
            t(77934), r.vUu('<span class="v-visible-sr"> </span> ', 1), r.vUu("<!> <!> <!>", 1)
        },
        31214: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(76467), t(77934), t(39772), r.vUu("<!> ", 1), r.vUu('<div class="s-post-summary--content-type"><!></div>');
            t(5541), t(64006);
            t(51954), t(48167), t(55834), t(68343), r.vUu('<div class="s-post-summary--stats-bounty"><span>+</span> <span class="v-visible-sr"> </span></div>'), r.vUu('<div class="s-post-summary--stats-bounty"><span>+</span> <span class="v-visible-sr"> </span></div>'), r.vUu('<div class="s-post-summary--stats-item"> </div>'), r.vUu('<div class="s-post-summary--stats-item"> </div>'), r.vUu('<div class="s-post-summary--sm-hide ml-auto"><!></div>'), r.vUu('<div class="s-post-summary--tags"><!> <!></div>'), r.vUu('<div class="s-post-summary--answers"><!></div>'), r.vUu('<div><div class="s-post-summary--stats s-post-summary--sm-hide"><div class="s-post-summary--stats-votes"><!> <span class="v-visible-sr"> </span></div> <div class="s-post-summary--stats-answers"><!> <span class="v-visible-sr"> </span></div> <!></div> <div class="s-post-summary--content"><div class="s-post-summary--sm-show"><!></div> <div class="s-post-summary--content-meta"><!> <div class="s-post-summary--stats s-post-summary--sm-show"><div class="s-post-summary--stats-votes"><!> </div> <div class="s-post-summary--stats-answers"><!> <span class="v-visible-sr"> </span></div> <!></div> <div class="s-post-summary--stats-item"> </div> <!> <!> <!></div> <div class="s-post-summary--title"><a class="s-post-summary--title-link"><!> </a></div> <!> <!> <!></div></div>')
        },
        5541: (s, a, t) => {
            t(82170), t(76467), t(67578).vUu("<p> </p>")
        },
        37079: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(52730), r.vUu('<div> <p class="s-description"> </p></div>'), r.vUu('<p class="s-description"> </p>'), r.vUu(" <!>", 1), r.vUu('<input type="radio"/> <!>', 1);
            r.MmH(["change"])
        },
        5840: (s, a, t) => {
            t(82170), t(67578), t(78430)
        },
        34981: (s, a, t) => {
            t(82170), t(67578)._i8('<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="1.44543" y="1.44543" width="45.1091" height="45.1091" stroke="var(--black-300)" stroke-width="2.89086" stroke-dasharray="5.78 5.78"></rect><rect x="10" y="14" width="12" height="3.12" fill="var(--black-500)"></rect><rect x="26" y="14" width="12" height="3.12" fill="var(--black-500)"></rect><rect x="14" y="31.12" width="20" height="3.12" fill="var(--black-500)"></rect></svg>')
        },
        51954: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(54250), t(77934), t(93062), t(15965), t(20005), t(34981), r.vUu('<span class="s-user-card--username s-user-card--username__op"> </span>'), r.vUu('<span><a class="s-link s-link__underlined"> </a> </span>'), r.vUu("<!> <!>", 1), r.vUu('<span class="s-user-card--username"> </span>'), r.vUu("<!> <!>", 1), r.vUu('<ul class="s-user-card--group"><!></ul>'), r.vUu('<ul class="s-user-card--group"><!></ul>'), r.vUu("<!> <!> <!> <!> <!>", 1), r.vUu("<span> </span>"), r.vUu("<!> <!>", 1), r.vUu('<div class="s-user-card--group"><!> <span class="s-user-card--username s-user-card--deleted"> </span></div> <!>', 1), r.vUu('<div class="s-user-card--column"><div class="s-user-card--row"><!></div> <div class="s-user-card--row s-user-card--recognition"><!> <!></div></div>'), r.vUu('<ul class="s-user-card--group"><!></ul>'), r.vUu('<ul class="s-user-card--group"><!></ul>'), r.vUu('<div class="s-user-card--row s-user-card--recognition"><!> <!></div>'), r.vUu("<li> </li>"), r.vUu("<li> </li>"), r.vUu('<ul class="s-user-card--group s-user-card--group__split"><!> <!></ul>'), r.vUu('<div class="s-user-card--column"><!> <!> <!></div>'), r.vUu('<div class="s-user-card--row"><!> <div class="s-user-card--column"><div class="s-user-card--row"><!> <!></div> <!></div></div> <!>', 1), r.vUu("<div><!></div>")
        },
        55834: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(86070), r.vUu("<li><!> </li>")
        },
        48167: (s, a, t) => {
            t(82170);
            var r = t(67578);
            t(68343), t(93062), t(20005), t(15965), r.vUu('<a class="s-user-card--time"> </a>'), r.vUu("<time> </time>"), r.vUu("<!> <!>", 1)
        },
        61722: (s, a, t) => {
            var r = t(74353),
                i = t(6279),
                e = t(53581);
            r.extend(i), r.extend(e);
            const u = {
                thresholds: [{
                    l: "s",
                    r: 1
                }, {
                    l: "m",
                    r: 1
                }, {
                    l: "mm",
                    r: 59,
                    d: "minute"
                }, {
                    l: "h",
                    r: 1
                }, {
                    l: "hh",
                    r: 23,
                    d: "hour"
                }, {
                    l: "d",
                    r: 1
                }, {
                    l: "dd",
                    r: 29,
                    d: "day"
                }],
                relativeTime: {
                    future: "in %s",
                    past: "%s ago",
                    s: "%d seconds ago",
                    ss: "%d seconds ago",
                    m: "1 minute ago",
                    mm: "%d minutes ago",
                    h: "1 hour ago",
                    hh: "%d hours ago",
                    d: "yesterday",
                    dd: "%d days ago"
                },
                rounding: Math.floor
            };
            r.updateLocale("en", u);
            const {
                formatTime: o
            } = class {
                static formatTime(s) {
                    const a = new Date,
                        t = new Date(s),
                        i = Math.floor((a.getTime() - t.getTime()) / 1e3),
                        e = {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: !1
                        },
                        u = [{
                            condition: s => s <= 172800,
                            format: s => r(s).fromNow(!0)
                        }, {
                            condition: s => a.getFullYear() === t.getFullYear(),
                            format: s => new Intl.DateTimeFormat("en-US", e).format(s).replace(/,([^,]*)$/, " at$1")
                        }];
                    let o = new Intl.DateTimeFormat("en-US", { ...e,
                        year: "numeric"
                    }).format(t).replace(/,([^,]*)$/, " at$1");
                    for (const s of u)
                        if (s.condition(i)) {
                            o = s.format(t);
                            break
                        }
                    return o
                }
            }
        },
        28726: (s, a, t) => {
            class r {
                static largeNumberFormat = new Intl.NumberFormat("en-US", {
                    notation: "compact",
                    compactDisplay: "short",
                    maximumFractionDigits: 1
                });
                static standardNumberFormat = new Intl.NumberFormat("en-US", {
                    notation: "standard"
                });
                static formatCount(s, a = 1e4) {
                    const t = Math.abs(s),
                        i = s < 0 ? "-" : "";
                    for (const s of r.getFormatters(a))
                        if (s.condition(t)) return i + s.format(t);
                    return s.toString()
                }
                static getFormatters(s) {
                    return [{
                        condition: a => a < s,
                        format: s => r.standardNumberFormat.format(s)
                    }, {
                        condition: a => a >= s,
                        format: s => r.largeNumberFormat.format(s).toLowerCase()
                    }]
                }
            }
            const {
                formatCount: i
            } = r
        },
        68343: (s, a, t) => {
            t(28726), t(61722)
        }
    }
]);