"use strict";
(self.webpackChunkstackoverflow = self.webpackChunkstackoverflow || []).push([
    [7660], {
        7660: (t, e, o) => {
            o.d(e, {
                A: () => ie
            });
            o(82170);
            var s = o(67578),
                n = o(22024),
                i = o(99724),
                a = o(54152),
                l = s.vUu('<a itemprop="url"> </a>'),
                r = s.vUu("<span> </span>"),
                d = (t, e, o) => {
                    dispatchEvent(new CustomEvent("clearFollowUpHighlight")), e.setScrollAndHighlight(o.followUpId.toString(), !0)
                },
                c = s.vUu('<span class="o50"><!></span>'),
                p = s.vUu('<span class="flex--item s-badge ml2 s-badge__moderator s-badge__xs ws-nowrap" title="Moderator">Mod</span>'),
                u = s.vUu('<a class="s-user-card--link ws-nowrap truncate wmx1"> </a> <!>', 1),
                w = s.vUu('<span class="s-user-card--link ws-nowrap truncate wmx1">a user</span>'),
                g = s.vUu('<span class="mx4" aria-hidden="true">|</span> <span class="fc-red-400 ws-nowrap overflow-visible fs-caption">Deleted by</span> <!> <time class="s-user-card--time ws-nowrap truncate"> </time>', 1),
                h = s.vUu('<div class="flex--item h24 ai-center s-user-card s-user-card__small lh-md"><div class="s-user-card--info" itemprop="author" itemscope="" itemtype="https://schema.org/Person"><div class="d-none" itemprop="name"> </div> <div class="s-user-card--awards"><!> <a class="comment-link"><time class="s-user-card--time ws-nowrap truncate"> </time></a> <!> <!></div></div></div>');
            s.MmH(["click"]);
            var m = o(1977),
                f = o(70243);
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            class v {
                constructor(t) {
                    this.isMentionEnabled = t
                }
                triggerMentionInitEvent(t) {
                    if (!this.isMentionEnabled) return;
                    const e = window,
                        o = e.__followUpsMentionPending;
                    null === o ? document.dispatchEvent(new CustomEvent("follow-ups-mention:init", {
                        detail: {
                            elements: t
                        }
                    })) : e.__followUpsMentionPending = [...null != o ? o : [], ...t]
                }
                isMentionPopupShow() {
                    return this.isMentionEnabled && null != document.querySelector(".mention-popup")
                }
                triggerMentionEditEvent(t, e, o) {
                    this.isMentionEnabled && document.dispatchEvent(new CustomEvent("follow-ups-mention:edit", {
                        detail: {
                            container: t,
                            postId: e,
                            followUpId: o
                        }
                    }))
                }
                getMentionList(t) {
                    var e, o;
                    if (!this.isMentionEnabled) return "";
                    const s = [],
                        n = this.parseMentions(t.value),
                        i = Array.from(null !== (o = null === (e = t.parentElement) || void 0 === e ? void 0 : e.querySelectorAll(".js-inputted-mention")) && void 0 !== o ? o : []);
                    return i.forEach((t => {
                        t.setAttribute("data-index", "0")
                    })), n.forEach(((t, e) => {
                        var o;
                        const n = this.findMentionElement(i, t);
                        if (n) {
                            const t = {
                                AppearanceOrdinal: e + 1,
                                TargetUserId: null != n.getAttribute("data-userid") ? parseInt(n.getAttribute("data-userid")) : void 0,
                                TargetAtName: null !== (o = n.textContent) && void 0 !== o ? o : void 0
                            };
                            n.setAttribute("data-index", `${e+1}`), s.push(t)
                        }
                    })), JSON.stringify(s)
                }
                findMentionElement(t, e) {
                    let o = t.find((t => null !== t.textContent && e === t.textContent.trim() && "0" === t.getAttribute("data-index")));
                    return void 0 === o && (o = t.find((t => null !== t.textContent && e.startsWith(t.textContent.trim()) && "0" === t.getAttribute("data-index")))), o
                }
                parseMentions(t) {
                    const e = /@\S+/g,
                        o = [];
                    let s;
                    for (; null !== (s = e.exec(t));) o.push(`${s[0]}`);
                    return o
                }
                clearMentionList(t) {
                    var e;
                    this.isMentionEnabled && (null === (e = t.parentElement) || void 0 === e || e.querySelectorAll(".js-inputted-mention").forEach((t => {
                        t.remove()
                    })))
                }
            }
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const I = {
                    showToast: f.P0
                },
                U = t => new v(t);
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            let k = "";
            const b = t => {
                    k = t
                },
                C = async (t, e) => {
                    const o = await fetch(`${k}/data/posts/${t}/follow-ups`, {
                        method: "POST",
                        headers: {
                            "X-SO-fkey": e,
                            "Content-Type": "application/json"
                        }
                    });
                    return await o.json()
                },
                y = async (t, e) => {
                    try {
                        const o = await fetch(k + t, {
                            method: "POST",
                            body: e
                        });
                        if (o.ok) {
                            const t = await o.text();
                            return {
                                success: !0,
                                id: x(t)
                            }
                        } {
                            const t = await o.text();
                            throw new Error(t)
                        }
                    } catch (t) {
                        let e = __tr(["An error occurred during submit."], undefined, "en", []);
                        return t instanceof Error && t.message && (e = t.message), {
                            success: !1,
                            type: "error",
                            error: e
                        }
                    }
                },
                x = t => {
                    const e = (new DOMParser).parseFromString(t, "text/html").querySelectorAll(".js-comment"),
                        o = e[e.length - 1];
                    return parseInt(o.getAttribute("data-comment-id") || "0")
                },
                _ = (t, e, o) => {
                    ((t, e, o) => {
                        (0, m.H)(t, {
                            source: window.location.href,
                            ...e
                        }, void 0, o)
                    })(t, {
                        source: window.location.href,
                        followUpsUIExperimentGroup: "test",
                        ...e
                    }, o)
                },
                E = t => {
                    let e = "other";
                    const o = t.topFollowUpsOnly && t.getHiddenFollowUpsCount() > 0 ? "hidden" : "all_shown";
                    var s, n;
                    null != t.trackingData.questionId && t.trackingData.questionId === t.postId ? e = "question" : null != t.trackingData.answerId && t.trackingData.answerId === t.postId && (e = "answer"), s = "comment.add", n = {
                        location: e,
                        type: o
                    }, window.StackExchange.using("gps", (() => {
                        window.StackExchange.gps.track(s, n)
                    }))
                };
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const L = (t, e) => t && e ? `${window.location.origin}${window.location.pathname}#comment${t}_${e}` : "",
                S = () => {
                    const t = window.location.hash,
                        [e, o] = t.replace("#comment", "").split("_");
                    return [e, o]
                },
                F = (t, e) => {
                    if (!window.location.hash.startsWith("#comment")) return !1;
                    const [o, s] = S();
                    if (!o || !s || isNaN(Number(o)) || isNaN(Number(s))) return !1;
                    if (Number(s) !== e) return !1;
                    const n = (t, e) => {
                        for (const o of e) {
                            if (o.id === t) return !0;
                            if (o.replies && o.replies.length > 0 && n(t, o.replies)) return !0
                        }
                        return !1
                    };
                    return !!n(Number(o), t) || (StackExchange.helpers.showToast(__tr(["Comment not found."], undefined, "en", []), {
                        type: "danger"
                    }), !1)
                },
                D = t => {
                    setTimeout((() => {
                        const e = T(t);
                        e && e.scrollIntoView({
                            behavior: "smooth",
                            block: "center"
                        })
                    }), 300)
                },
                j = t => window.location.hash === `#addcomment_${t}`,
                T = t => document.querySelector(`#follow-up-${t}`),
                A = (t, e = void 0) => window.dispatchEvent(new CustomEvent("signupModalShow", {
                    detail: {
                        location: t,
                        overrideTitle: e
                    }
                })),
                B = async (t, e, o, n) => {
                    if (t.preventDefault(), e.currentUserIsAnonymous) A("vote-button-comment");
                    else if (o.isDeleted) {
                        const {
                            questionId: t,
                            answerId: s
                        } = e.trackingData ? ? {};
                        _("follow_ups_ui_experiment.vote_attempt", {
                            questionId: t,
                            answerId: s,
                            commentId: o.followUpId
                        }, e.fkey)
                    } else {
                        s.hZp(n, !0);
                        try {
                            const t = await (async (t, e, o) => {
                                const s = new FormData;
                                s.append("fkey", o);
                                const n = e ? "0" : "2";
                                try {
                                    const e = await fetch(`${k}/posts/comments/${t}/vote/${n}`, {
                                        method: "POST",
                                        body: s
                                    });
                                    if (!e.ok) {
                                        const t = await e.text();
                                        throw new Error(t)
                                    }
                                    const o = await e.json();
                                    if (!o.Success) throw new Error(o.Message);
                                    return {
                                        success: !0,
                                        id: t
                                    }
                                } catch (t) {
                                    let e = __tr(["An error occurred during voting."], undefined, "en", []);
                                    return t instanceof Error && t.message && (e = t.message), {
                                        success: !1,
                                        type: "error",
                                        error: e
                                    }
                                }
                            })(o.followUpId, o.userHasVoted, e.fkey);
                            if (!t ? .success && "error" === t ? .type) return void I.showToast(t.error, {
                                type: "danger",
                                useRawHtml: !0
                            });
                            const {
                                replies: s
                            } = await C(e.postId, e.fkey);
                            e.setFollowUpsList(s)
                        } finally {
                            s.hZp(n, !1)
                        }
                    }
                };
            var O = s.vUu('<button type="button"><div class="d-flex ai-center g6"><span class="s-btn--icon"><!></span> <span class="fw-normal fs-caption fc-black-500"> </span></div></button>');
            s.MmH(["click"]);
            const M = (t, e, o) => {
                e.userCanVote || _("follow_ups_ui_experiment.vote_attempt", {
                    source: window.location.href,
                    questionId: o ? .trackingData ? .questionId ? ? -1,
                    answerId: o ? .trackingData ? .answerId ? ? -1,
                    commentId: e.followUpId,
                    followUpsUIExperimentGroup: "test"
                }, o ? .fkey)
            };
            var $ = s.vUu('<button class="s-btn s-btn__xs s-btn__outlined s-btn__muted s-btn__icon h24 py2 is-disabled" type="button"><div class="d-flex ai-center g6"><span class="s-btn--icon"><!></span> <span class="fw-normal fs-caption fc-black-500"> </span></div></button>'),
                Y = s.vUu("<!> <!>", 1);
            s.MmH(["click"]);
            var H = s.vUu('<button class="s-btn s-btn__xs s-btn__outlined s-btn__muted h24 py2" type="button"><div class="d-flex ai-center g6"><span class="s-btn--icon"><!></span> <span class="fw-normal fs-caption fc-black-500">Reply</span></div></button>');
            s.MmH(["click"]);
            const J = async (t, e, o, n) => {
                t.preventDefault(), s.hZp(e, !0);
                try {
                    const t = await (async (t, e, o) => {
                        const s = new FormData;
                        s.append("fkey", o);
                        try {
                            const o = await fetch(`${k}/admin/posts/${e}/comments/${t}/undelete`, {
                                method: "POST",
                                body: s
                            });
                            if (!o.ok) {
                                const t = await o.text();
                                throw new Error(t)
                            }
                            return {
                                success: !0,
                                id: t
                            }
                        } catch (t) {
                            let e = __tr(["An error occurred while attempting to undelete."], undefined, "en", []);
                            return t instanceof Error && t.message && (e = t.message), {
                                success: !1,
                                type: "error",
                                error: e
                            }
                        }
                    })(o.followUpId, n.postId, n.fkey);
                    if (t.success || "error" !== t.type) {
                        const {
                            replies: t
                        } = await C(n.postId, n.fkey);
                        n.setFollowUpsList(t)
                    } else I.showToast(t.error, {
                        type: "danger",
                        useRawHtml: !0
                    })
                } finally {
                    s.hZp(e, !1)
                }
            };
            var P = s.vUu('<a class="s-btn s-btn__xs fs-caption h24 pt4 s-btn__muted bc-red-400 fc-red-400">Redact</a>'),
                R = s.vUu("<button>Undelete</button>"),
                N = s.vUu('<div class="flex--item d-flex ai-center g6"><!> <!></div>');
            s.MmH(["click"]);
            const V = async (t, e, o, n) => {
                    if (t.preventDefault(), !e.currentUserIsMod) {
                        if (!window.confirm(__tr(["Delete this comment?"], undefined, "en", []))) return
                    }
                    s.hZp(o, !0);
                    try {
                        const t = await (async (t, e) => {
                            const o = new FormData;
                            o.append("fkey", e);
                            try {
                                const e = await fetch(`${k}/posts/comments/${t}/vote/10`, {
                                    method: "POST",
                                    body: o
                                });
                                if (!e.ok) {
                                    const t = await e.text();
                                    throw new Error(t)
                                }
                                return {
                                    success: !0,
                                    id: t
                                }
                            } catch (t) {
                                let e = __tr(["An error occurred while attempting to delete."], undefined, "en", []);
                                return t instanceof Error && t.message && (e = t.message), {
                                    success: !1,
                                    type: "error",
                                    error: e
                                }
                            }
                        })(n.followUpId, e.fkey);
                        if (t.success || "error" !== t.type) {
                            const {
                                replies: t
                            } = await C(e.postId, e.fkey);
                            e.setFollowUpsList(t)
                        } else I.showToast(t.error, {
                            type: "danger",
                            useRawHtml: !0
                        })
                    } finally {
                        s.hZp(o, !1)
                    }
                },
                Z = (t, e, o) => {
                    window.dispatchEvent(new CustomEvent("flagModalOpen", {
                        detail: {
                            postId: e.postId,
                            followUpId: o.followUpId,
                            retracting: o.userHasFlagged,
                            currentUserIsMod: e.currentUserIsMod,
                            commentFlagsRemainingToday: e.commentFlagsRemainingToday
                        }
                    }))
                },
                q = async (t, e, o, n) => {
                    t.preventDefault(), s.hZp(e, !0);
                    try {
                        const t = await fetch(`${o.siteUrl}/posts/comments/${n.followUpId}/edit-history`, {
                            method: "GET"
                        });
                        if (t.ok) {
                            const e = `[aria-controls="${`popover-menu-${n.followUpId}`}"]`,
                                o = document.querySelector(e);
                            o ? .click();
                            const s = {
                                    my: "top left",
                                    at: "bottom left",
                                    offsetTop: -12,
                                    offsetLeft: 0
                                },
                                i = await t.text(),
                                a = `#follow-up-${n.followUpId}`;
                            StackExchange.helpers.showMessage(a, i, {
                                type: "config",
                                relativeToBody: !0,
                                position: s,
                                fixedTo$elem: !0
                            })
                        } else {
                            const e = await t.text() || __tr(["Failed to load comment history"], undefined, "en", []);
                            I.showToast(e, {
                                type: "danger"
                            })
                        }
                    } catch {
                        I.showToast(__tr(["Failed to load comment history"], undefined, "en", []), {
                            type: "danger"
                        })
                    } finally {
                        s.hZp(e, !1)
                    }
                };
            var G = (t, e, o) => e.setShownEditorId(`${o.followUpId}-edit`),
                K = s.vUu('<li role="menuitem"><button class="s-block-link h:bg-black-100 js-follow-up-edit">Edit</button></li>'),
                X = s.vUu('<li role="menuitem"><button data-so-test="follow-up-delete">Delete</button></li>'),
                W = s.vUu('<li role="menuitem"><button class="s-block-link h:bg-black-100 js-follow-up-delete" data-so-test="follow-up-flag">Flag</button></li>'),
                Q = s.vUu('<li role="menuitem"><button class="s-block-link h:bg-black-100 js-follow-up-delete">Unflag</button></li>'),
                z = s.vUu('<li role="menuitem"><button>History</button></li>'),
                tt = s.vUu('<button class="flex--item s-btn s-btn__xs s-btn__outlined s-btn__muted py2 h24" type="button" aria-expanded="false" aria-label="Open menu" data-controller="s-popover" data-action="s-popover#toggle" data-s-popover-placement="bottom-start" data-s-popover-toggle-class="is-selected"><!></button> <div class="s-popover s-popover__tooltip" role="menu"><div class="s-popover--arrow"></div> <div class="s-popover--content"><ul class="s-menu" role="menu"><li role="menuitem"><button class="s-block-link h:bg-black-100 js-follow-up-copy-link">Copy link</button></li> <!> <!> <!> <!></ul></div></div>', 1);
            s.MmH(["click"]), StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            var et = s.vUu('<div><div class="flex--item d-flex ai-center g16 fl-grow1"><div class="d-flex jc-space-between fl-grow1"><div class="flex--item d-flex ai-center g8"><!> <!> <!></div> <!></div></div></div>');

            function ot(t, e) {
                s.VCO(e, !0);
                let o = (0, n.SD)("appState");
                var l = et();
                let r;
                var d = s.jfp(l),
                    c = s.jfp(d),
                    p = s.jfp(c),
                    u = s.jfp(p),
                    w = t => {
                        ! function(t, e) {
                            s.VCO(e, !0);
                            const o = (0, n.SD)("appState");
                            (0, i.AM)(t, {
                                id: "vote-tooltip",
                                children: (t, n) => {
                                    var l = Y(),
                                        r = s.esp(l);
                                    (0, i.hj)(r, {
                                        children: (t, n) => {
                                            var l = $();
                                            l.__click = [M, e, o];
                                            var r = s.jfp(l),
                                                d = s.jfp(r),
                                                c = s.jfp(d);
                                            (0, i.In)(c, {
                                                get src() {
                                                    return a.UPF
                                                },
                                                class: "fc-black-400 va-middle w16"
                                            }), s.cLc(d);
                                            var p = s.hg4(d, 2),
                                                u = s.jfp(p, !0);
                                            s.cLc(p), s.cLc(r), s.cLc(l), s.vNg((() => {
                                                l.disabled = e.isDeleted, s.aIK(l, "data-so-test", `vote-button-comment-${e.followUpId??""}`), s.jax(u, e.showVoteWording ? "Vote" : e.score)
                                            })), s.BCw(t, l)
                                        },
                                        $$slots: {
                                            default: !0
                                        }
                                    });
                                    var d = s.hg4(r, 2);
                                    (0, i.hl)(d, {
                                        class: "w-auto",
                                        children: (t, o) => {
                                            s.K2T();
                                            var n = s.Qq7();
                                            s.vNg((() => s.jax(n, e.voteButtonTooltipText))), s.BCw(t, n)
                                        },
                                        $$slots: {
                                            default: !0
                                        }
                                    }), s.BCw(t, l)
                                },
                                $$slots: {
                                    default: !0
                                }
                            }), s.uYY()
                        }(t, {
                            get followUpId() {
                                return e.followUpId
                            },
                            get score() {
                                return e.score
                            },
                            get showVoteWording() {
                                return e.showVoteWording
                            },
                            get userCanVote() {
                                return e.userCanVote
                            },
                            get voteButtonTooltipText() {
                                return e.voteButtonTooltipText
                            },
                            get isDeleted() {
                                return e.isDeleted
                            }
                        })
                    },
                    g = t => {
                        ! function(t, e) {
                            s.VCO(e, !0);
                            const o = (0, n.SD)("appState");
                            let l = s.wk1(!1),
                                r = s.unG((() => e.userHasVoted ? "fc-orange-400" : "fc-black-400")),
                                d = "s-btn s-btn__xs s-btn__outlined s-btn__muted s-btn__icon h24 py2",
                                c = s.unG((() => e.isDeleted ? `${d} is-disabled` : e.userHasVoted ? `${d} bc-orange-400 fc-orange-100 bg-orange-100` : `${d}`));
                            var p = O();
                            let u;
                            p.__click = [B, o, e, l];
                            var w = s.jfp(p),
                                g = s.jfp(w),
                                h = s.jfp(g);
                            const m = s.unG((() => `${s.JtY(r)} va-middle w16`));
                            (0, i.In)(h, {
                                get src() {
                                    return a.UPF
                                },
                                get class() {
                                    return s.JtY(m)
                                }
                            }), s.cLc(g);
                            var f = s.hg4(g, 2),
                                v = s.jfp(f, !0);
                            s.cLc(f), s.cLc(w), s.cLc(p), s.vNg((t => {
                                u = s.ysU(p, 1, s.$z$(s.JtY(c)), null, u, t), p.disabled = e.isDeleted, s.aIK(p, "data-so-test", `vote-button-comment-${e.followUpId??""}`), s.jax(v, e.showVoteWording ? "Vote" : e.score)
                            }), [() => ({
                                "is-loading": s.JtY(l)
                            })]), s.BCw(t, p), s.uYY()
                        }(t, {
                            get followUpId() {
                                return e.followUpId
                            },
                            get score() {
                                return e.score
                            },
                            get showVoteWording() {
                                return e.showVoteWording
                            },
                            get userHasVoted() {
                                return e.userHasVoted
                            },
                            get isDeleted() {
                                return e.isDeleted
                            }
                        })
                    };
                s.if(u, (t => {
                    e.voteButtonTooltipText && !o.currentUserIsAnonymous ? t(w) : t(g, !1)
                }));
                var h = s.hg4(u, 2),
                    m = t => {
                        ! function(t, e) {
                            var o = H();
                            o.__click = function(...t) {
                                e.onclick ? .apply(this, t)
                            };
                            var n = s.jfp(o),
                                l = s.jfp(n),
                                r = s.jfp(l);
                            (0, i.In)(r, {
                                get src() {
                                    return a.pjm
                                },
                                class: "fc-black-400 w16"
                            }), s.cLc(l), s.K2T(2), s.cLc(n), s.cLc(o), s.vNg((() => {
                                o.disabled = e.isDisabled, s.aIK(o, "data-so-test", `reply-button-comment-${e.followUpId??""}`)
                            })), s.BCw(t, o)
                        }(t, {
                            get isDisabled() {
                                return e.replyButtonDisabled
                            },
                            get followUpId() {
                                return e.followUpId
                            },
                            onclick: () => {
                                o.currentUserIsAnonymous ? A("reply-to-comment-button", __tr(["Sign up to add a comment"], undefined, "en", [])) : e.showFirstTimeCommentingModal ? document.dispatchEvent(new CustomEvent("firstTimeCommenting", {
                                    detail: {
                                        followUpId: e.followUpId,
                                        postId: o.postId
                                    }
                                })) : o.setShownEditorId(e.followUpId.toString()), _("follow_ups_ui_experiment.reply_button_click", {
                                    questionId: o.trackingData.questionId,
                                    answerId: o.trackingData.answerId,
                                    answerPositionOnPage: o.trackingData.answerPositionOnPage,
                                    numberOfPreExistingComments: o.followUpsList.length
                                }, o.fkey)
                            }
                        })
                    };
                s.if(h, (t => {
                    e.userCanReply && t(m)
                }));
                var f = s.hg4(h, 2),
                    v = t => {
                        ! function(t, e) {
                            s.VCO(e, !0);
                            const o = (0, n.SD)("appState");
                            let l = s.wk1(!1),
                                r = s.wk1(!1),
                                d = "";
                            (0, n.Rc)((() => {
                                d = L(e.followUpId, o.postId)
                            }));
                            var c = tt(),
                                p = s.esp(c),
                                u = s.jfp(p);
                            (0, i.In)(u, {
                                get src() {
                                    return a.b4L
                                },
                                class: "fc-black-400"
                            }), s.cLc(p);
                            var w = s.hg4(p, 2),
                                g = s.hg4(s.jfp(w), 2),
                                h = s.jfp(g),
                                m = s.jfp(h);
                            s.jfp(m).__click = () => {
                                try {
                                    navigator.clipboard.writeText(d), I.showToast(__tr(["Link copied to clipboard"], undefined, "en", []), {
                                        type: "success"
                                    })
                                } catch {
                                    I.showToast(__tr(["Failed to copy link to clipboard"], undefined, "en", []), {
                                        type: "danger"
                                    })
                                }
                            }, s.cLc(m);
                            var f = s.hg4(m, 2),
                                v = t => {
                                    var n = K();
                                    s.jfp(n).__click = [G, o, e], s.cLc(n), s.BCw(t, n)
                                };
                            s.if(f, (t => {
                                e.userCanEdit && t(v)
                            }));
                            var U = s.hg4(f, 2),
                                k = t => {
                                    var n = X(),
                                        i = s.jfp(n);
                                    let a;
                                    i.__click = [V, o, l, e], s.cLc(n), s.vNg((t => a = s.ysU(i, 1, "s-block-link h:bg-black-100 js-follow-up-delete", null, a, t)), [() => ({
                                        "is-loading": s.JtY(l)
                                    })]), s.BCw(t, n)
                                };
                            s.if(U, (t => {
                                e.userCanDelete && t(k)
                            }));
                            var b = s.hg4(U, 2),
                                C = t => {
                                    var n = W();
                                    s.jfp(n).__click = [Z, o, e], s.cLc(n), s.BCw(t, n)
                                },
                                y = (t, n) => {
                                    var i = t => {
                                        var n = Q();
                                        s.jfp(n).__click = [Z, o, e], s.cLc(n), s.BCw(t, n)
                                    };
                                    s.if(t, (t => {
                                        e.userHasFlagged && o.allowRetractingCommentFlags && t(i)
                                    }), n)
                                };
                            s.if(b, (t => {
                                e.userCanFlag && !e.userHasFlagged ? t(C) : t(y, !1)
                            }));
                            var x = s.hg4(b, 2),
                                _ = t => {
                                    var n = z(),
                                        i = s.jfp(n);
                                    let a;
                                    i.__click = [q, r, o, e], s.cLc(n), s.vNg((t => a = s.ysU(i, 1, "s-block-link h:bg-black-100 js-follow-up-history", null, a, t)), [() => ({
                                        "is-loading": s.JtY(r)
                                    })]), s.BCw(t, n)
                                };
                            s.if(x, (t => {
                                e.editCount > 0 && e.userCanViewHistory && t(_)
                            })), s.cLc(h), s.cLc(g), s.cLc(w), s.vNg((() => {
                                s.aIK(p, "aria-controls", `popover-menu-${e.followUpId}`), s.aIK(p, "data-so-test", `actions-button-comment-${e.followUpId??""}`), s.aIK(w, "id", `popover-menu-${e.followUpId}`)
                            })), s.BCw(t, c), s.uYY()
                        }(t, {
                            get followUpId() {
                                return e.followUpId
                            },
                            get userCanEdit() {
                                return e.userCanEdit
                            },
                            get userCanDelete() {
                                return e.userCanDelete
                            },
                            get userCanFlag() {
                                return e.userCanFlag
                            },
                            get userHasFlagged() {
                                return e.userHasFlagged
                            },
                            get userCanViewHistory() {
                                return e.userCanViewHistory
                            },
                            get editCount() {
                                return e.editCount
                            }
                        })
                    };
                s.if(f, (t => {
                    e.isDeleted || t(v)
                })), s.cLc(p);
                var U = s.hg4(p, 2),
                    k = t => {
                        ! function(t, e) {
                            s.VCO(e, !0);
                            const o = (0, n.SD)("appState");
                            let i = s.wk1(!1);
                            var a = N(),
                                l = s.jfp(a),
                                r = t => {
                                    var o = P();
                                    s.vNg((() => s.aIK(o, "href", `/posts/comments/${e.followUpId}/redact`))), s.BCw(t, o)
                                };
                            s.if(l, (t => {
                                e.userCanRedact && t(r)
                            }));
                            var d = s.hg4(l, 2),
                                c = t => {
                                    var n = R();
                                    let a;
                                    n.__click = [J, i, e, o], s.vNg((t => a = s.ysU(n, 1, "s-btn s-btn__xs fs-caption h24 py2 s-btn__muted bc-blue-400 fc-blue-400", null, a, t)), [() => ({
                                        "is-loading": s.JtY(i)
                                    })]), s.BCw(t, n)
                                };
                            s.if(d, (t => {
                                e.userCanUndelete && t(c)
                            })), s.cLc(a), s.BCw(t, a), s.uYY()
                        }(t, {
                            get followUpId() {
                                return e.followUpId
                            },
                            get userCanRedact() {
                                return e.userCanRedact
                            },
                            get userCanUndelete() {
                                return e.userCanUndelete
                            }
                        })
                    };
                s.if(U, (t => {
                    e.isDeleted && t(k)
                })), s.cLc(c), s.cLc(d), s.cLc(l), s.vNg((t => r = s.ysU(l, 1, "d-flex g16", null, r, t)), [() => ({
                    pb8: !(e.isDeleted || e.highlighted)
                })]), s.BCw(t, l), s.uYY()
            }
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            var st = s.vUu('<div class="d-flex g6"><div class="flex--item w24"><!></div> <div class="flex--item d-flex fd-column g8 fl-grow1 overflow-hidden"><div class="d-flex jc-space-between"><!></div></div></div>'),
                nt = s.vUu('<div class="flex--item d-flex g6 pt4">[deleted]</div>'),
                it = s.vUu('<div class="pb4 pt4">[deleted]</div>'),
                at = s.vUu('<div class="p0 mt4 mb8"><!></div>'),
                lt = s.vUu('<div class="d-flex fd-column"><!> <div class="flex--item d-flex g6 fl-grow1"><div class="flex--item d-flex fd-column ai-center pt4"><div></div></div> <div class="flex--item d-flex fd-column g4 fl-grow1"><div itemprop="text"><!></div> <time class="d-none" itemprop="datePublished"> </time> <!> <!></div></div></div>'),
                rt = s.vUu('<div class="p0 mt4 mb8"><!></div>'),
                dt = s.vUu('<div class="follow-up-thread-line bg-black-200 h100 ml12 svelte-56stg4"></div>'),
                ct = s.vUu('<div class="h8"><!></div>'),
                pt = s.vUu('<div class="follow-up-thread-line bg-black-200 h100 mr12 mtn8 svelte-56stg4"></div>'),
                ut = s.vUu('<div class="d-flex"><div class="flex--item w32 fc-black-200 ml12 mrn12 fl-shrink0"><div class="bl bb w16 h12 bblr-lg"></div> <!></div> <div class="flex--item fl-grow1"><!></div></div>'),
                wt = s.vUu('<div itemprop="comment" itemscope="" itemtype="https://schema.org/Comment" role="listitem"><!></div> <!> <!>', 1);
            const gt = {
                hash: "svelte-56stg4",
                code: ".follow-up-thread-line.svelte-56stg4 {width:1px;}"
            };

            function ht(t, e) {
                s.VCO(e, !0), s.kZQ(t, gt);
                let o = (0, n.SD)("appState"),
                    m = s.unG((() => o.scrollAndHighlight ? .elementId === e.id.toString() && o.scrollAndHighlight ? .shouldHighlight));
                var f = wt(),
                    v = s.esp(f);
                let I;
                var U = s.jfp(v),
                    k = t => {
                        var f = lt(),
                            v = s.jfp(f),
                            I = t => {
                                var o = st(),
                                    m = s.jfp(o);
                                ! function(t, e) {
                                    s.kZQ(t, _t);
                                    var o = s.Imx(),
                                        n = s.esp(o),
                                        i = t => {
                                            var o = yt(),
                                                n = s.jfp(o);
                                            s.cLc(o), s.vNg((() => {
                                                s.aIK(o, "href", e.url), s.aIK(n, "src", e.profileImageUrl)
                                            })), s.BCw(t, o)
                                        },
                                        a = t => {
                                            var e = xt();
                                            s.BCw(t, e)
                                        };
                                    s.if(n, (t => {
                                        e.userIsDeleted ? t(a, !1) : t(i)
                                    })), s.BCw(t, o)
                                }(s.jfp(m), {
                                    get url() {
                                        return e.user.url
                                    },
                                    get profileImageUrl() {
                                        return e.user.profileImageUrl
                                    },
                                    get userIsDeleted() {
                                        return e.user.isDeleted
                                    }
                                }), s.cLc(m);
                                var f = s.hg4(m, 2),
                                    v = s.jfp(f);
                                ! function(t, e) {
                                    s.VCO(e, !0);
                                    let o = s._w2(e, "isDeleted", 3, !1),
                                        m = (0, n.SD)("appState");
                                    const f = `Edited ${e.editCount} time${e.editCount>1?"s":""}`,
                                        v = m.isPostAuthor(e.userId) ? " owner px8 py4" : "";
                                    var I = h(),
                                        U = s.jfp(I),
                                        k = s.jfp(U),
                                        b = s.jfp(k, !0);
                                    s.cLc(k);
                                    var C = s.hg4(k, 2),
                                        y = s.jfp(C),
                                        x = t => {
                                            var o = l(),
                                                n = s.jfp(o, !0);
                                            s.cLc(o), s.vNg((() => {
                                                s.aIK(o, "href", e.url), s.ysU(o, 1, `s-user-card--link truncate wmx2 comment-user lh-xs${v}`), s.jax(n, e.displayName)
                                            })), s.BCw(t, o)
                                        },
                                        _ = t => {
                                            var o = r(),
                                                n = s.jfp(o, !0);
                                            s.cLc(o), s.vNg((() => {
                                                s.ysU(o, 1, `s-user-card--link truncate wmx2 comment-user lh-xs${v}`), s.jax(n, e.displayName)
                                            })), s.BCw(t, o)
                                        };
                                    s.if(y, (t => {
                                        o() ? t(_, !1) : t(x)
                                    }));
                                    var E = s.hg4(y, 2);
                                    E.__click = [d, m, e];
                                    var L = s.jfp(E),
                                        S = s.jfp(L, !0);
                                    s.cLc(L), s.cLc(E);
                                    var F = s.hg4(E, 2),
                                        D = t => {
                                            var e = c(),
                                                o = s.jfp(e);
                                            (0, i.In)(o, {
                                                get src() {
                                                    return a.pSV
                                                }
                                            }), s.cLc(e), s.vNg((() => s.aIK(e, "title", f))), s.BCw(t, e)
                                        };
                                    s.if(F, (t => {
                                        e.editCount > 0 && t(D)
                                    }));
                                    var j = s.hg4(F, 2),
                                        T = t => {
                                            var o = g(),
                                                n = s.hg4(s.esp(o), 4),
                                                i = t => {
                                                    var o = u(),
                                                        n = s.esp(o),
                                                        i = s.jfp(n, !0);
                                                    s.cLc(n);
                                                    var a = s.hg4(n, 2),
                                                        l = t => {
                                                            var e = p();
                                                            s.BCw(t, e)
                                                        };
                                                    s.if(a, (t => {
                                                        e.deletionUser.isModerator && t(l)
                                                    })), s.vNg((() => {
                                                        s.aIK(n, "href", e.deletionUser.url), s.jax(i, e.deletionUser.displayName)
                                                    })), s.BCw(t, o)
                                                },
                                                a = t => {
                                                    var e = w();
                                                    s.BCw(t, e)
                                                };
                                            s.if(n, (t => {
                                                e.deletionUser ? t(i) : t(a, !1)
                                            }));
                                            var l = s.hg4(n, 2),
                                                r = s.jfp(l, !0);
                                            s.cLc(l), s.vNg((() => {
                                                s.aIK(l, "title", e.deletedAt), s.jax(r, e.deletedAtRelative)
                                            })), s.BCw(t, o)
                                        };
                                    s.if(j, (t => {
                                        e.deletedAt && t(T)
                                    })), s.cLc(C), s.cLc(U), s.cLc(I), s.vNg((() => {
                                        s.jax(b, e.displayName), s.aIK(E, "href", `#comment${e.followUpId}_${m.postId}`), s.aIK(L, "title", e.postedAt), s.jax(S, e.postedAtRelative)
                                    })), s.BCw(t, I), s.uYY()
                                }(s.jfp(v), s.DuQ((() => e.user), {
                                    get followUpId() {
                                        return e.id
                                    },
                                    get postedAt() {
                                        return e.postedAt
                                    },
                                    get postedAtRelative() {
                                        return e.postedAtRelative
                                    },
                                    get deletionUser() {
                                        return e.deletionUser
                                    },
                                    get deletedAt() {
                                        return e.deletedAt
                                    },
                                    get deletedAtRelative() {
                                        return e.deletedAtRelative
                                    },
                                    get editCount() {
                                        return e.editCount
                                    }
                                })), s.cLc(v), s.cLc(f), s.cLc(o), s.BCw(t, o)
                            },
                            U = t => {
                                var e = nt();
                                s.BCw(t, e)
                            };
                        s.if(v, (t => {
                            !e.isDeletedAndReadOnly || o.showDeleted ? t(I) : t(U, !1)
                        }));
                        var k = s.hg4(v, 2),
                            b = s.jfp(k),
                            C = s.jfp(b);
                        let y;
                        s.cLc(b);
                        var x = s.hg4(b, 2),
                            _ = s.jfp(x),
                            E = s.jfp(_),
                            L = t => {
                                var o = s.Imx(),
                                    n = s.esp(o);
                                s.qyt(n, (() => e.htmlBody)), s.BCw(t, o)
                            },
                            S = t => {
                                var e = it();
                                s.BCw(t, e)
                            };
                        s.if(E, (t => {
                            !e.isDeletedAndReadOnly || o.showDeleted ? t(L) : t(S, !1)
                        })), s.cLc(_);
                        var F = s.hg4(_, 2),
                            D = s.jfp(F);
                        s.cLc(F);
                        var j = s.hg4(F, 2),
                            T = t => {
                                ot(t, {
                                    get followUpId() {
                                        return e.id
                                    },
                                    get score() {
                                        return e.score
                                    },
                                    get editCount() {
                                        return e.editCount
                                    },
                                    get showVoteWording() {
                                        return e.showVoteWording
                                    },
                                    get isDeleted() {
                                        return e.isDeleted
                                    },
                                    get highlighted() {
                                        return s.JtY(m)
                                    },
                                    get userCanEdit() {
                                        return e.userCanEdit
                                    },
                                    get userCanDelete() {
                                        return e.userCanDelete
                                    },
                                    get userCanFlag() {
                                        return e.userCanFlag
                                    },
                                    get userCanVote() {
                                        return e.userCanVote
                                    },
                                    get userCanReply() {
                                        return e.userCanReply
                                    },
                                    get userCanRedact() {
                                        return e.userCanRedact
                                    },
                                    get userCanViewHistory() {
                                        return e.userCanViewHistory
                                    },
                                    get userCanUndelete() {
                                        return e.userCanUndelete
                                    },
                                    get userHasFlagged() {
                                        return e.userHasFlagged
                                    },
                                    get userHasVoted() {
                                        return e.userHasVoted
                                    },
                                    get voteButtonTooltipText() {
                                        return e.voteButtonTooltipText
                                    },
                                    get replyButtonDisabled() {
                                        return o.blockCommentingButtons
                                    },
                                    get showFirstTimeCommentingModal() {
                                        return o.showFirstTimeCommentingModal
                                    }
                                })
                            };
                        s.if(j, (t => {
                            e.isDeletedAndReadOnly && !o.showDeleted || t(T)
                        }));
                        var A = s.hg4(j, 2),
                            B = t => {
                                var n = at();
                                Ct(s.jfp(n), {
                                    editorType: "reply",
                                    get postId() {
                                        return e.id
                                    },
                                    get minCharCount() {
                                        return o.commentMinLength
                                    },
                                    maxCharCount: 600
                                }), s.cLc(n), s.BCw(t, n)
                            };
                        s.if(A, (t => {
                            e.userCanReply && o.shownEditorId === e.id.toString() && t(B)
                        })), s.cLc(x), s.cLc(k), s.cLc(f), s.vNg((t => {
                            y = s.ysU(C, 1, "follow-up-thread-line h100 ml12 mr12 pt4 svelte-56stg4", null, y, t), s.ysU(_, 1, `flex--item fw-normal ${o.newUiSettings.largerFontSize?"fs-body2":"fs-body1"} mb4 ow-anywhere`), s.jax(D, `${e.postedAt??""}+00:00`)
                        }), [() => ({
                            "bg-black-200": e.replies.length > 0
                        })]), s.BCw(t, f)
                    },
                    b = t => {
                        var n = rt(),
                            i = s.jfp(n);
                        const a = s.unG((() => e.noSpacesReplyToUserName ? ? null));
                        Ct(i, {
                            editorType: "edit",
                            get postId() {
                                return e.id
                            },
                            get minCharCount() {
                                return o.commentMinLength
                            },
                            maxCharCount: 600,
                            get initialInputValue() {
                                return e.body
                            },
                            get replyToUserName() {
                                return s.JtY(a)
                            }
                        }), s.cLc(n), s.BCw(t, n)
                    };
                s.if(U, (t => {
                    o.shownEditorId !== `${e.id.toString()}-edit` ? t(k) : t(b, !1)
                })), s.cLc(v);
                var C = s.hg4(v, 2),
                    y = t => {
                        var o = ct(),
                            n = s.jfp(o),
                            i = t => {
                                var e = dt();
                                s.BCw(t, e)
                            };
                        s.if(n, (t => {
                            e.replies.length > 0 && t(i)
                        })), s.cLc(o), s.BCw(t, o)
                    };
                s.if(C, (t => {
                    (e.isDeleted || s.JtY(m)) && t(y)
                }));
                var x = s.hg4(C, 2),
                    _ = t => {
                        var o = s.Imx(),
                            n = s.esp(o);
                        s.__1(n, 19, (() => e.replies), (t => t.id), ((t, o, n) => {
                            var i = s.Imx(),
                                a = s.esp(i),
                                l = t => {
                                    ht(t, s.DuQ((() => s.JtY(o))))
                                },
                                r = t => {
                                    var i = ut(),
                                        a = s.jfp(i),
                                        l = s.hg4(s.jfp(a), 2),
                                        r = t => {
                                            var e = pt();
                                            s.BCw(t, e)
                                        };
                                    s.if(l, (t => {
                                        s.JtY(n) !== e.replies.length - 1 && t(r)
                                    })), s.cLc(a);
                                    var d = s.hg4(a, 2);
                                    ht(s.jfp(d), s.DuQ((() => s.JtY(o)))), s.cLc(d), s.cLc(i), s.BCw(t, i)
                                };
                            s.if(a, (t => {
                                e.exceedsNestingLimit ? t(l) : t(r, !1)
                            })), s.BCw(t, i)
                        })), s.BCw(t, o)
                    };
                s.if(x, (t => {
                    e.replies.length > 0 && t(_)
                })), s.vNg((t => {
                    s.aIK(v, "id", `follow-up-${e.id}`), s.aIK(v, "data-so-test", `reply-parent-comment-${e.parentCommentId??0??""}`), I = s.ysU(v, 1, "", null, I, t)
                }), [() => ({
                    "bg-red-100": e.isDeleted && o.showDeleted,
                    comment__highlight: s.JtY(m)
                })]), s.BCw(t, f), s.uYY()
            }
            var mt = (t, e) => {
                    e.currentUserIsAnonymous ? A("add-comment-top-button", __tr(["Sign up to add a comment"], undefined, "en", [])) : e.showFirstTimeCommentingModal ? document.dispatchEvent(new CustomEvent("firstTimeCommenting", {
                        detail: {
                            postId: e.postId,
                            editorPosition: "top"
                        }
                    })) : (e.setShownEditorId(`${e.postId}-top`), e.setFollowUpsExpanded(!0), e.setTopFollowUpsOnly(!1)), _("follow_ups_ui_experiment.reply_bar_click", {
                        questionId: e.trackingData.questionId,
                        answerId: e.trackingData.answerId,
                        answerPositionOnPage: e.trackingData.answerPositionOnPage,
                        numberOfPreExistingComments: e.followUpsList.length
                    }, e.fkey), E(e)
                },
                ft = s.vUu('<div class="flex--item"><img class="s-avatar s-avatar--image" alt="user avatar"/></div>'),
                vt = s.vUu('<button type="button"><!> <div class="flex--item ml8"><p class="mb0">Add a comment</p></div></button>');
            s.MmH(["click"]);
            var It = o(47287),
                Ut = s.vUu("<span> </span>");
            var kt = (t, e) => e.clearShownEditorId(),
                bt = s.vUu('<form class="d-flex fd-column g8"><!> <div class="d-flex jc-space-between ai-center mt4"><div class="flex--item jc-space-between"><button type="submit"> </button> <button type="button" class="s-btn s-btn__xs">Cancel</button></div> <!></div></form>');

            function Ct(t, e) {
                s.VCO(e, !0);
                let o = s._w2(e, "initialInputValue", 3, ""),
                    i = s.wk1(s.BXG(o())),
                    a = s.wk1(!1),
                    l = s.unG((() => s.JtY(i).length < e.minCharCount || s.JtY(i).length > e.maxCharCount || s.JtY(a)));
                const r = (0, n.SD)("appState");
                b(r.siteUrl);
                const d = {
                        add: `/posts/${e.postId}/comments`,
                        edit: `/posts/comments/${e.postId}/edit`,
                        reply: `/posts/${r.postId}/comments`
                    },
                    c = U(r.isMentionEnabled),
                    p = async t => {
                        t.preventDefault(), s.hZp(a, !0);
                        try {
                            const t = new FormData;
                            t.append("fkey", r.fkey);
                            var o = s.JtY(i);
                            if ("reply" === e.editorType) {
                                t.append("parentCommentId", e.postId.toString());
                                var n = r.followUpsList.find((t => t.id == e.postId));
                                n ? .user.noSpacesUserName && (o = `@${n?.user.noSpacesUserName} ${o}`)
                            } else "edit" === e.editorType && e.replyToUserName && (o = `@${e.replyToUserName} ${o}`);
                            t.append("comment", o);
                            const a = document.getElementById(`${e.editorType}-${e.postId}-input`);
                            t.append("mentionsJson", c.getMentionList(a));
                            const l = await y(d[e.editorType], t);
                            if (l.success || "error" !== l.type) {
                                const {
                                    replies: t
                                } = await C(r.postId, r.fkey);
                                if ("add" === e.editorType) {
                                    r.setTopFollowUpsOnly(!1);
                                    const e = t[t.length - 1].id.toString();
                                    r.setScrollAndHighlight(e, !1)
                                }
                                r.setFollowUpsList(t, "add" !== e.editorType), r.clearShownEditorId()
                            } else I.showToast(l.error, {
                                type: "danger",
                                useRawHtml: !0
                            });
                            _("follow_ups_ui_experiment.comment.submit", {
                                submitSuccess: l.success,
                                questionId: r.trackingData ? .questionId,
                                answerId: r.trackingData ? .answerId,
                                commentId: l.success ? l.id : 0,
                                numberOfPreExistingComments: r.followUpsList.length,
                                answerPositionOnPage: r.trackingData ? .answerPositionOnPage
                            }, r.fkey)
                        } finally {
                            s.hZp(a, !1)
                        }
                    };
                (0, n.Rc)((() => {
                    const t = document.getElementById(`${e.editorType}-${e.postId}-input`);
                    if (t instanceof HTMLTextAreaElement) {
                        const o = t;
                        c.triggerMentionInitEvent([o]), "edit" === e.editorType && c.triggerMentionEditEvent(o, r.postId, e.postId)
                    }
                    return t ? .focus(), () => {
                        s.hZp(i, ""), t ? .blur()
                    }
                }));
                var u = bt(),
                    w = s.jfp(u);
                const g = s.unG((() => `${e.editorType}-${e.postId}-input`));
                (0, It.Z_)(w, {
                    get id() {
                        return s.JtY(g)
                    },
                    variant: "comment",
                    onkeydown: t => {
                        "Enter" !== t.key || t.shiftKey || s.JtY(l) || c.isMentionPopupShow() || p(t), "Escape" === t.key && r.clearShownEditorId()
                    },
                    get value() {
                        return s.JtY(i)
                    },
                    set value(t) {
                        s.hZp(i, t, !0)
                    }
                });
                var h = s.hg4(w, 2),
                    m = s.jfp(h),
                    f = s.jfp(m);
                let v;
                var k = s.jfp(f, !0);
                s.cLc(f), s.hg4(f, 2).__click = [kt, r], s.cLc(m),
                    function(t, e) {
                        const o = e.warnAtStartAndEndOnly ? 0 : Math.round(2 * e.maxCount / 5),
                            n = e.warnAtStartAndEndOnly ? 0 : Math.round(3 * e.maxCount / 5),
                            i = Math.round(4 * e.maxCount / 5);
                        let a = s.unG((() => 0 === e.currentLength ? {
                            message: `Enter at least ${e.minCount} characters`,
                            classes: "fs-caption fc-black-400"
                        } : e.currentLength < e.minCount ? {
                            message: e.minCount - e.currentLength + " more to go...",
                            classes: "fs-caption fc-black-400"
                        } : e.warnAtStartAndEndOnly && e.currentLength >= e.minCount && e.currentLength < i ? null : e.currentLength >= e.minCount && e.currentLength <= o ? {
                            message: e.maxCount - e.currentLength + " characters left",
                            classes: "fs-caption fc-black-400"
                        } : e.currentLength > o && e.currentLength <= n ? {
                            message: e.maxCount - e.currentLength + " characters left",
                            classes: "fs-caption fc-orange-600"
                        } : e.currentLength > n && e.currentLength <= i ? {
                            message: e.maxCount - e.currentLength + " characters left",
                            classes: "fs-caption fc-orange-500"
                        } : e.currentLength > i && e.currentLength <= e.maxCount ? {
                            message: e.maxCount - e.currentLength + " characters left",
                            classes: "fs-caption fc-orange-400"
                        } : {
                            message: `Too long by ${e.currentLength-e.maxCount} characters`,
                            classes: "fs-caption fc-red-400"
                        }));
                        var l = Ut(),
                            r = s.jfp(l, !0);
                        s.cLc(l), s.vNg((() => {
                            s.ysU(l, 1, s.$z$(s.JtY(a) ? .classes)), s.jax(r, s.JtY(a) ? .message)
                        })), s.BCw(t, l)
                    }(s.hg4(m, 2), {
                        get currentLength() {
                            return s.JtY(i).length
                        },
                        get minCount() {
                            return e.minCharCount
                        },
                        get maxCount() {
                            return e.maxCharCount
                        },
                        warnAtStartAndEndOnly: !0
                    }), s.cLc(h), s.cLc(u), s.vNg((t => {
                        s.aIK(u, "id", `${e.editorType}-${e.postId}`), v = s.ysU(f, 1, "s-btn s-btn__xs s-btn__filled", null, v, t), f.disabled = s.JtY(l), s.jax(k, "edit" === e.editorType ? "Save edits" : "Comment")
                    }), [() => ({
                        "is-loading": s.JtY(a)
                    })]), s.f0J("submit", u, p), s.BCw(t, u), s.uYY()
            }
            s.MmH(["click"]);
            var yt = s.vUu('<a class="s-avatar s-avatar__24 s-user-card--avatar" aria-label="User profile"><img class="s-avatar--image" alt=""/></a>'),
                xt = s.vUu('<div class="s-avatar s-avatar__24 s-user-card--avatar gravatar-wrapper-24"><div class="anonymous-gravatar shift-left-a-bit svelte-1jhulwk"></div></div>');
            const _t = {
                hash: "svelte-1jhulwk",
                code: ".shift-left-a-bit.svelte-1jhulwk {background-position-x:-3.5px;}"
            };
            var Et = s.vUu('<div class="d-flex g8 my8"><button type="button" class="s-link s-btn__muted s-btn__outlined comments-link">Add a comment</button></div>');
            s.MmH(["click"]);
            var Lt = s.vUu('<div role="listitem" class="native-comment-threaded-ad js-native-comment-threaded-ad"><div class="js-zone-container zone-container-native-comment-threaded ta-right"><div class="everyonelovesstackoverflow everyoneloves__native-comment-threaded"></div> <div class="js-report-ad-button-container" style="width: 100%;"></div></div></div>');
            StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {}, StackExchange = window.StackExchange = window.StackExchange || {}, StackOverflow = window.StackOverflow = window.StackOverflow || {};
            const St = !1,
                Ft = null,
                Dt = !1,
                jt = [],
                Tt = 0,
                At = "",
                Bt = {},
                Ot = 0,
                Mt = !1,
                $t = !1,
                Yt = {
                    largerFontSize: !0
                },
                Ht = "",
                Jt = !1,
                Pt = !1,
                Rt = !1,
                Nt = 0,
                Vt = !1,
                Zt = !0,
                qt = 15,
                Gt = [];
            class Kt {#
                t;
                get followUpsExpanded() {
                    return s.JtY(this.#t)
                }
                set followUpsExpanded(t) {
                    s.hZp(this.#t, t, !0)
                }#
                e;
                get shownEditorId() {
                    return s.JtY(this.#e)
                }
                set shownEditorId(t) {
                    s.hZp(this.#e, t, !0)
                }#
                o;
                get topFollowUpsOnly() {
                    return s.JtY(this.#o)
                }
                set topFollowUpsOnly(t) {
                    s.hZp(this.#o, t, !0)
                }#
                s;
                get showDeleted() {
                    return s.JtY(this.#s)
                }
                set showDeleted(t) {
                    s.hZp(this.#s, t, !0)
                }#
                n;
                get followUpsList() {
                    return s.JtY(this.#n)
                }
                set followUpsList(t) {
                    s.hZp(this.#n, t, !0)
                }#
                i;
                get postId() {
                    return s.JtY(this.#i)
                }
                set postId(t) {
                    s.hZp(this.#i, t, !0)
                }#
                a;
                get flagFollowUpId() {
                    return s.JtY(this.#a)
                }
                set flagFollowUpId(t) {
                    s.hZp(this.#a, t, !0)
                }#
                l;
                get retractFlagFollowUpId() {
                    return s.JtY(this.#l)
                }
                set retractFlagFollowUpId(t) {
                    s.hZp(this.#l, t, !0)
                }#
                r;
                get fkey() {
                    return s.JtY(this.#r)
                }
                set fkey(t) {
                    s.hZp(this.#r, t, !0)
                }#
                d;
                get trackingData() {
                    return s.JtY(this.#d)
                }
                set trackingData(t) {
                    s.hZp(this.#d, t, !0)
                }#
                c;
                get questionAuthorId() {
                    return s.JtY(this.#c)
                }
                set questionAuthorId(t) {
                    s.hZp(this.#c, t, !0)
                }#
                p;
                get scrollAndHighlight() {
                    return s.JtY(this.#p)
                }
                set scrollAndHighlight(t) {
                    s.hZp(this.#p, t, !0)
                }#
                u;
                get newUiSettings() {
                    return s.JtY(this.#u)
                }
                set newUiSettings(t) {
                    s.hZp(this.#u, t, !0)
                }#
                w;
                get siteUrl() {
                    return s.JtY(this.#w)
                }
                set siteUrl(t) {
                    s.hZp(this.#w, t, !0)
                }#
                g;
                get showFirstTimeCommentingModal() {
                    return s.JtY(this.#g)
                }
                set showFirstTimeCommentingModal(t) {
                    s.hZp(this.#g, t, !0)
                }#
                h;
                get blockCommentingButtons() {
                    return s.JtY(this.#h)
                }
                set blockCommentingButtons(t) {
                    s.hZp(this.#h, t, !0)
                }#
                m;
                get showCtaUnderComments() {
                    return s.JtY(this.#m)
                }
                set showCtaUnderComments(t) {
                    s.hZp(this.#m, t, !0)
                }#
                f;
                get isMentionEnabled() {
                    return s.JtY(this.#f)
                }
                set isMentionEnabled(t) {
                    s.hZp(this.#f, t, !0)
                }#
                v;
                get isDisabled() {
                    return s.JtY(this.#v)
                }
                set isDisabled(t) {
                    s.hZp(this.#v, t, !0)
                }#
                I;
                get currentUserIsMod() {
                    return s.JtY(this.#I)
                }
                set currentUserIsMod(t) {
                    s.hZp(this.#I, t, !0)
                }#
                U;
                get commentFlagsRemainingToday() {
                    return s.JtY(this.#U)
                }
                set commentFlagsRemainingToday(t) {
                    s.hZp(this.#U, t, !0)
                }#
                k;
                get allowRetractingCommentFlags() {
                    return s.JtY(this.#k)
                }
                set allowRetractingCommentFlags(t) {
                    s.hZp(this.#k, t, !0)
                }#
                b;
                get currentUserIsAnonymous() {
                    return s.JtY(this.#b)
                }
                set currentUserIsAnonymous(t) {
                    s.hZp(this.#b, t, !0)
                }#
                C;
                get commentMinLength() {
                    return s.JtY(this.#C)
                }
                set commentMinLength(t) {
                    s.hZp(this.#C, t, !0)
                }#
                y;
                get nativeAdPositions() {
                    return s.JtY(this.#y)
                }
                set nativeAdPositions(t) {
                    s.hZp(this.#y, t, !0)
                }
                constructor(t) {
                    this.#t = s.wk1(s.BXG(St)), this.#e = s.wk1(s.BXG(Ft)), this.#o = s.wk1(s.BXG(Dt)), this.#s = s.wk1(!1), this.#n = s.wk1(s.BXG(jt)), this.#i = s.wk1(s.BXG(Tt)), this.#a = s.wk1(), this.#l = s.wk1(), this.#r = s.wk1(s.BXG(At)), this.#d = s.wk1(s.BXG(Bt)), this.#c = s.wk1(s.BXG(Ot)), this.#p = s.wk1(), this.#u = s.wk1(s.BXG(Yt)), this.#w = s.wk1(s.BXG(Ht)), this.#g = s.wk1(s.BXG(Mt)), this.#h = s.wk1(s.BXG($t)), this.#m = s.wk1(s.BXG(Jt)), this.#f = s.wk1(s.BXG(Pt)), this.#v = s.wk1(), this.#I = s.wk1(s.BXG(Rt)), this.#U = s.wk1(s.BXG(Nt)), this.#k = s.wk1(s.BXG(Vt)), this.#b = s.wk1(s.BXG(Zt)), this.#C = s.wk1(s.BXG(qt)), this.#y = s.wk1(s.BXG(Gt)), this.getTestingIndicator = () => null != this.trackingData.questionId && this.trackingData.questionId === this.postId ? `parent-question-${this.postId}` : null != this.trackingData.answerId && this.trackingData.answerId === this.postId ? `parent-answer-${this.postId}` : "", Object.assign(this, Object.assign({}, t))
                }
                setFollowUpsExpanded(t) {
                    this.followUpsExpanded = t
                }
                setShownEditorId(t) {
                    this.shownEditorId = t
                }
                clearShownEditorId() {
                    this.shownEditorId = null
                }
                setTopFollowUpsOnly(t) {
                    this.topFollowUpsOnly = t
                }
                showDeletedFollowUps() {
                    this.showDeleted = !0
                }
                setFollowUpsList(t, e = !0) {
                    e && this.clearScrollAndHighlight(), this.followUpsList = t
                }
                addFollowUp(t) {
                    this.followUpsList = [...this.followUpsList, t]
                }
                removeFollowUp(t) {
                    this.followUpsList = [...this.followUpsList].filter((e => e.id !== t))
                }
                updateFollowUp(t) {
                    const e = this.followUpsList.findIndex((e => e.id === t.id)); - 1 !== e && (this.followUpsList[e] = t)
                }
                getTotalFollowUpsCount() {
                    return Wt(this.followUpsList, this.showDeleted)
                }
                getFollowUpsToDisplay() {
                    return Xt(this.followUpsList.filter((t => (this.showDeleted || !t.isDeleted || t.isDeletedAndReadOnly) && (!this.topFollowUpsOnly || t.isTopScored))), this.showDeleted)
                }
                getDisplayItems() {
                    var t;
                    const e = this.getFollowUpsToDisplay();
                    if (0 === this.nativeAdPositions.length) return e.map((t => ({
                        kind: "follow-up",
                        followUp: t
                    })));
                    const o = new Map;
                    for (const {
                            afterIndex: e,
                            slotId: s
                        } of this.nativeAdPositions) {
                        const n = null !== (t = o.get(e)) && void 0 !== t ? t : [];
                        n.push(s), o.set(e, n)
                    }
                    const s = [];
                    return e.forEach(((t, e) => {
                        s.push({
                            kind: "follow-up",
                            followUp: t
                        });
                        const n = o.get(e + 1);
                        if (n)
                            for (const t of n) s.push({
                                kind: "ad",
                                slotId: t
                            })
                    })), s
                }
                getHiddenFollowUpsCount() {
                    return Wt(this.followUpsList.filter((t => !t.isTopScored)), this.showDeleted)
                }
                setFKey(t) {
                    this.fkey = t
                }
                setTrackingData(t) {
                    this.trackingData = t
                }
                setFlagFollowUpId(t) {
                    this.flagFollowUpId = t
                }
                clearFlagFollowUpId() {
                    this.flagFollowUpId = void 0
                }
                setRetractFlagFollowUpId(t) {
                    this.retractFlagFollowUpId = t
                }
                clearRetractFlagFollowUpId() {
                    this.retractFlagFollowUpId = void 0
                }
                setScrollAndHighlight(t, e) {
                    this.scrollAndHighlight = {
                        elementId: t,
                        shouldHighlight: e
                    }
                }
                clearScrollAndHighlight() {
                    this.scrollAndHighlight = void 0
                }
                isPostAuthor(t) {
                    return this.questionAuthorId === t
                }
            }
            const Xt = (t, e) => t.filter((t => e || !t.isDeleted || t.isDeletedAndReadOnly)).map((t => Object.assign(Object.assign({}, t), {
                    replies: Xt(t.replies, e)
                }))),
                Wt = (t, e) => t.reduce(((t, o) => {
                    let s = t;
                    return !e && o.isDeleted || (s += 1), s += Wt(o.replies, e), s
                }), 0),
                Qt = t => new Kt(t);
            var zt = s.vUu('<h2 class="mt0 mb8"><button type="button" class="d-flex ai-center g8 c-pointer s-btn s-btn__unset"> <!></button></h2>'),
                te = s.vUu('<div class="mb8 d-flex ai-center g8"><h2 class="mb0"> </h2></div>'),
                ee = s.vUu('<div class="p0 mt4"><!></div>'),
                oe = s.vUu('<div role="list"></div> <!>', 1),
                se = s.vUu('<div class="pl32 pr4 mt8"><!></div>'),
                ne = s.vUu('<div class="mt16"><!> <div class="mb12"><!></div> <!> <!></div>');

            function ie(t, e) {
                s.VCO(e, !0);
                let o = Qt({
                        followUpsExpanded: !0,
                        showDeleted: !1,
                        shownEditorId: null,
                        topFollowUpsOnly: !0,
                        followUpsList: e.replies || [],
                        postId: e.postId,
                        fkey: e.fKey,
                        trackingData: {
                            questionId: e.questionId,
                            answerId: e.answerId,
                            answerPositionOnPage: 0
                        },
                        questionAuthorId: e.questionAuthorId,
                        newUiSettings: e.newUiSettings,
                        siteUrl: e.siteUrl,
                        showFirstTimeCommentingModal: e.showFirstTimeCommentingModal,
                        blockCommentingButtons: !1,
                        showCtaUnderComments: e.showCtaUnderComments,
                        isMentionEnabled: e.isMentionEnabled,
                        currentUserIsMod: e.currentUserIsMod,
                        commentFlagsRemainingToday: e.commentFlagsRemainingToday,
                        allowRetractingCommentFlags: e.allowRetractingCommentFlags,
                        currentUserIsAnonymous: e.currentUserIsAnonymous,
                        commentMinLength: e.commentMinLength,
                        nativeAdPositions: e.nativeAdPositions ? ? []
                    }),
                    l = s.unG((() => o.getTotalFollowUpsCount() > 0));
                (0, n.o)("appState", o), b(o.siteUrl);
                const r = t => {
                        if (t.detail.postId !== o.postId) return;
                        o.setTopFollowUpsOnly(!1), o.showDeletedFollowUps();
                        const e = o.followUpsList.find((t => t.isDeleted));
                        e && D(e.id.toString())
                    },
                    d = (t, e) => {
                        t.detail.postId === o.postId && (!1 === e && t.detail.followUpDeleted ? o.removeFollowUp(t.detail.followUpId) : o.setFollowUpsList(o.followUpsList.map((o => o.id === t.detail.followUpId ? { ...o,
                            userHasFlagged: !e
                        } : o))))
                    };
                (0, n.Rc)((() => {
                    e.replies && F(e.replies.filter((t => e.currentUserIsMod || !t.isDeleted)), e.postId) && (o.topFollowUpsOnly = !1, o.scrollAndHighlight = {
                        elementId: S()[0],
                        shouldHighlight: !0
                    }), j(e.postId) && (o.topFollowUpsOnly = !1, o.setShownEditorId(`${e.postId}-top`));
                    const t = o.trackingData,
                        s = `follow-ups-container-${e.postId}`;
                    o.setTrackingData({ ...t,
                        answerPositionOnPage: [...document.querySelectorAll("[id^='follow-ups-container-']")].findIndex((t => t.id === s))
                    }), document.addEventListener("firstTimeCommenterValidationSuccess", (t => {
                        t.detail.postId === e.postId && (t.detail.editorPosition ? o.setShownEditorId(`${e.postId}-${t.detail.editorPosition}`) : t.detail.followUpId && o.setShownEditorId(t.detail.followUpId.toString()))
                    })), document.addEventListener("firstTimeCommenterValidationFailed", (() => {
                        o.blockCommentingButtons = !0
                    })), document.addEventListener("fetchDeletedFollowUps", r), window.addEventListener("flagSubmitted", (t => {
                        d(t, !1)
                    })), window.addEventListener("flagRetract", (t => {
                        d(t, !0)
                    })), window.addEventListener("clearFollowUpHighlight", (() => {
                        o.clearScrollAndHighlight()
                    }))
                }));
                const c = function() {
                    o.currentUserIsAnonymous ? A("add-comment-bottom-button", __tr(["Sign up to add a comment"], undefined, "en", [])) : o.showFirstTimeCommentingModal ? document.dispatchEvent(new CustomEvent("firstTimeCommenting", {
                        detail: {
                            postId: o.postId,
                            editorPosition: "bottom"
                        }
                    })) : (o.setShownEditorId(`${e.postId}-bottom`), o.setTopFollowUpsOnly(!1)), _("follow_ups_ui_experiment.add_comment_bottom_link_click", {
                        questionId: o.trackingData.questionId,
                        answerId: o.trackingData.answerId,
                        answerPositionOnPage: o.trackingData.answerPositionOnPage,
                        numberOfPreExistingComments: o.followUpsList.length
                    }, o.fkey), E(o)
                };
                s.Goy((() => {
                    o.scrollAndHighlight && (o.followUpsList.find((t => t.id.toString() === o.scrollAndHighlight.elementId)) ? .isDeleted && e.currentUserIsMod && o.showDeletedFollowUps(), (0, n.io)().then((() => {
                        D(o.scrollAndHighlight.elementId)
                    })))
                }));
                const p = () => {
                    o.followUpsExpanded && !o.topFollowUpsOnly ? o.setFollowUpsExpanded(!1) : (o.setFollowUpsExpanded(!0), o.setTopFollowUpsOnly(!1))
                };
                let u = s.unG((() => {
                    const t = o.getTotalFollowUpsCount();
                    return 0 === t ? "Comments" : `${t} Comment${1!==t?"s":""}`
                }));
                var w = ne(),
                    g = s.jfp(w),
                    h = t => {
                        var n = zt(),
                            l = s.jfp(n);
                        l.__click = p;
                        var r = s.jfp(l),
                            d = s.hg4(r),
                            c = t => {
                                (0, i.In)(t, {
                                    get src() {
                                        return a.q0e
                                    }
                                })
                            },
                            w = t => {
                                (0, i.In)(t, {
                                    get src() {
                                        return a.dpN
                                    }
                                })
                            };
                        s.if(d, (t => {
                            o.followUpsExpanded && !o.topFollowUpsOnly ? t(c) : t(w, !1)
                        })), s.cLc(l), s.cLc(n), s.vNg((() => {
                            s.aIK(l, "aria-expanded", o.followUpsExpanded), s.aIK(l, "aria-controls", `follow-ups-list-${e.postId??""}`), s.jax(r, `${s.JtY(u)??""} `)
                        })), s.BCw(t, n)
                    },
                    m = t => {
                        var e = te(),
                            o = s.jfp(e),
                            n = s.jfp(o, !0);
                        s.cLc(o), s.cLc(e), s.vNg((() => s.jax(n, s.JtY(u)))), s.BCw(t, e)
                    };
                s.if(g, (t => {
                    s.JtY(l) ? t(h) : t(m, !1)
                }));
                var f = s.hg4(g, 2),
                    v = s.jfp(f),
                    I = t => {
                        var o = ee();
                        Ct(s.jfp(o), {
                            editorType: "add",
                            get postId() {
                                return e.postId
                            },
                            get minCharCount() {
                                return e.commentMinLength
                            },
                            maxCharCount: 600
                        }), s.cLc(o), s.BCw(t, o)
                    },
                    U = t => {
                        ! function(t, e) {
                            s.VCO(e, !0);
                            let o = (0, n.SD)("appState"),
                                i = s.unG((() => 0 == o.getHiddenFollowUpsCount()));
                            var a = vt();
                            let l;
                            a.__click = [mt, o];
                            var r = s.jfp(a),
                                d = t => {
                                    var o = ft(),
                                        n = s.jfp(o);
                                    s.cLc(o), s.vNg((() => s.aIK(n, "src", e.currentUserProfileImageUrl))), s.BCw(t, o)
                                };
                            s.if(r, (t => {
                                e.currentUserProfileImageUrl && t(d)
                            })), s.K2T(2), s.cLc(a), s.vNg(((t, e) => {
                                l = s.ysU(a, 1, "s-btn s-btn__muted s-btn__outlined w100 d-flex ai-center p8", null, l, t), a.disabled = o.blockCommentingButtons, s.aIK(a, "data-so-test", e)
                            }), [() => ({
                                "comments-link": s.JtY(i)
                            }), () => o.getTestingIndicator()]), s.BCw(t, a), s.uYY()
                        }(t, {
                            get currentUserProfileImageUrl() {
                                return e.currentUserProfileImageUrl
                            }
                        })
                    };
                s.if(v, (t => {
                    o.shownEditorId === `${e.postId}-top` ? t(I) : t(U, !1)
                })), s.cLc(f);
                var k = s.hg4(f, 2),
                    C = t => {
                        var i = oe(),
                            a = s.esp(i);
                        s.__1(a, 21, (() => o.getDisplayItems()), (t => "follow-up" === t.kind ? `fu-${t.followUp.id}` : `ad-${t.slotId}`), ((t, e) => {
                                var o = s.Imx(),
                                    i = s.esp(o),
                                    a = t => {
                                        ht(t, s.DuQ((() => s.JtY(e).followUp)))
                                    },
                                    l = t => {
                                        ! function(t, e) {
                                            s.VCO(e, !0), (0, n.Rc)((() => {
                                                const t = window.cam;
                                                t ? .add ? .(e.slotId)
                                            }));
                                            var o = Lt(),
                                                i = s.jfp(o),
                                                a = s.jfp(i);
                                            s.K2T(2), s.cLc(i), s.cLc(o), s.vNg((() => s.aIK(a, "id", e.slotId))), s.BCw(t, o), s.uYY()
                                        }(t, {
                                            get slotId() {
                                                return s.JtY(e).slotId
                                            }
                                        })
                                    };
                                s.if(i, (t => {
                                    "follow-up" === s.JtY(e).kind ? t(a) : t(l, !1)
                                })), s.BCw(t, o)
                            })), s.cLc(a),
                            function(t, e) {
                                s.VCO(e, !0);
                                let o = (0, n.SD)("appState"),
                                    i = s.unG((() => o.showCtaUnderComments && !o.shownEditorId));
                                var a = s.Imx(),
                                    l = s.esp(a),
                                    r = t => {
                                        var n = Et(),
                                            i = s.jfp(n);
                                        i.__click = function(...t) {
                                            e.onBottomCtaClick ? .apply(this, t)
                                        }, s.cLc(n), s.vNg((t => s.aIK(i, "data-so-test", t)), [() => o.getTestingIndicator()]), s.BCw(t, n)
                                    };
                                s.if(l, (t => {
                                    s.JtY(i) && t(r)
                                })), s.BCw(t, a), s.uYY()
                            }(s.hg4(a, 2), {
                                onBottomCtaClick: c
                            }), s.vNg((() => s.aIK(a, "id", `follow-ups-list-${e.postId??""}`))), s.BCw(t, i)
                    };
                s.if(k, (t => {
                    o.followUpsExpanded && t(C)
                }));
                var y = s.hg4(k, 2),
                    x = t => {
                        var o = se();
                        Ct(s.jfp(o), {
                            editorType: "add",
                            get postId() {
                                return e.postId
                            },
                            get minCharCount() {
                                return e.commentMinLength
                            },
                            maxCharCount: 600
                        }), s.cLc(o), s.BCw(t, o)
                    };
                s.if(y, (t => {
                    o.shownEditorId === `${e.postId}-bottom` && t(x)
                })), s.cLc(w), s.BCw(t, w), s.uYY()
            }
            s.MmH(["click"])
        }
    }
]);