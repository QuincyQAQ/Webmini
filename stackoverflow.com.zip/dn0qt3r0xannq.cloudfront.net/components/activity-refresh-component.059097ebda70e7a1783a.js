/*! copyright 2026 Aditude, Inc - Prebid - production - Updated: 2026-06-18T15:50:15.668Z, v1.4.0, activity-refresh-component 6be8730e476328066473 dc3da510ab99371761f7 */
"use strict";
(self.tudeChunk = self.tudeChunk || []).push([
    [20900], {
        70644: function(e, i, s) {
            s.r(i), s.d(i, {
                ActivityRefresh: function() {
                    return c
                }
            });
            var t = s(30227),
                n = s(9016);

            function d(e, i, s) {
                return i in e ? Object.defineProperty(e, i, {
                    value: s,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[i] = s, e
            }
            let r = new Map,
                h = 0;
            class c extends n.A {
                getLoggerColor() {
                    return "#FF7276"
                }
                getInitialState() {
                    return {}
                }
                start() {
                    h += 1, this.container.eventBus.on(this.container.EVENTS.BEFORE_REFRESH, e => {
                        this.includeBaseDivIds.length > 0 && (e = e.filter(e => {
                            var i;
                            return this.props.includeBaseDivIds.includes(e.baseDivId) || (null == e || null == (i = e.refresh) ? void 0 : i.activityRefresh)
                        })), this.excludeBaseDivIds.length > 0 && (e = e.filter(e => {
                            var i;
                            return !this.excludeBaseDivIds.includes(e.baseDivId) || (null == e || null == (i = e.refresh) ? void 0 : i.activityRefresh)
                        })), this.excludeDivIds.length > 0 && (e = e.filter(e => {
                            var i;
                            return !this.excludeDivIds.includes(e.divId) || (null == e || null == (i = e.refresh) ? void 0 : i.activityRefresh)
                        })), e.forEach(e => {
                            if (this.divsOnRefresh.includes(e.divId)) return !1;
                            this.checkFirstInstanceToRefresh(e) && (h > 1 && this.multipleInstances && (r.set(e.divId, this.instanceId), this.advancedLog(`Instance ${this.instanceId} is the first to act on ${e.divId}
`, r)), this.advancedLog("Adding to activity refresh", e), this.divsOnRefresh.push(e.divId), this.addActivityRefreshListener(e))
                        })
                    })
                }
                constructor(e, i) {
                    var s, t;
                    super(e, i), d(this, "includeBaseDivIds", []), d(this, "excludeBaseDivIds", []), d(this, "excludeDivIds", []), d(this, "divsOnRefresh", []), d(this, "cb", void 0), d(this, "multipleInstances", !1), d(this, "inViewOnly", !0), d(this, "instanceId", `actref-${h}`), d(this, "viewportCheck", e => this.container.isElemInViewport(document.getElementById(e)) || !this.inViewOnly), d(this, "checkFirstInstanceToRefresh", e => {
                        if (r.has(e.divId)) {
                            let i = r.get(e.divId);
                            if (i !== this.instanceId) return this.log(`Instance ${this.instanceId} cannot act on ${e.divId}, already acted upon by Instance ${i}`), !1
                        }
                        return !0
                    }), d(this, "addActivityRefreshListener", e => {
                        document.addEventListener("visibilitychange", () => {
                            !document.hidden && (this.advancedLog("Visibilty change happened"), this.viewportCheck(e.divId) && (this.log("Refreshing", e.divId), this.props.cb && this.cb(e), this.container.refreshAds(e, this.props.forceRender)))
                        })
                    }), this.cb = this.props.cb || this.cb, this.inViewOnly = null != (s = this.props.inViewOnly) ? s : this.inViewOnly, this.includeBaseDivIds = this.props.includeBaseDivIds || this.includeBaseDivIds, this.excludeBaseDivIds = this.props.excludeBaseDivIds || this.excludeBaseDivIds, this.excludeDivIds = this.props.excludeDivIds || this.excludeDivIds, this.multipleInstances = null != (t = this.props.multipleInstances) ? t : this.multipleInstances, this.advancedLog("instanceId: ", this.instanceId), this.container.filters.sub("wrapperConfigOnInit", e => {
                        try {
                            Object.keys(e.AD_UNITS || {}).forEach(i => {
                                (e.AD_UNITS[i] || []).forEach(i => {
                                    let s = Object.keys(i.mediaTypes || {}),
                                        t = e.SLOT_PREFIX + i.slot;
                                    1 !== s.length || (null == s ? void 0 : s[0]) !== "video" || this.excludeBaseDivIds.includes(t) || this.excludeBaseDivIds.push(t)
                                })
                            })
                        } catch (e) {
                            this.error("ActivityRefresh error parsing ad units", e)
                        }
                        return e
                    })
                }
            }
            d(c, "componentName", "activity-refresh"), d(c, "logName", "ActivityRefresh"), (0, t.A1)(c), i.default = c
        }
    }
]);