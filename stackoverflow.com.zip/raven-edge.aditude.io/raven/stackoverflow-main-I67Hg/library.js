window.ravenLoaderConfig = {
    "cdn": "https://raven-static.aditude.io/prod",
    "property": {
        "eventPublisherValue": "stackoverflow",
        "id": "stackoverflow-main-I67Hg",
        "name": "stackexchange",
        "publisherId": "ebZqTKyz4DUJ",
        "ravenVersion": "stable"
    },
    "releaseId": "voeCK_224",
    "env": "production",
    "versions": [{
        "pct": 1,
        "version": "1.20.0-69wxiu"
    }]
};
/*! Copyright 2025 Aditude Inc. All rights reserved. Raven 2026-04-29T18:23:35.762Z */
(() => {
    "use strict";
    const e = "tude-rvn-",
        t = t => e + t,
        n = e => Date.now() > e,
        a = function(e, n) {
            let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 90;
            try {
                const s = t(e),
                    o = {
                        variant: n,
                        expiresAt: Date.now() + 24 * a * 60 * 60 * 1e3
                    };
                localStorage.setItem(s, JSON.stringify(o))
            } catch (e) {}
        },
        s = s => {
            try {
                const o = t(s),
                    i = localStorage.getItem(o);
                if (i) try {
                    const e = JSON.parse(i);
                    return n(e.expiresAt) ? (localStorage.removeItem(o), !1) : e.variant
                } catch {
                    localStorage.removeItem(o)
                }
                const r = (e => {
                    try {
                        const t = "tude-rvn" + e,
                            n = document.cookie.split(";");
                        for (const s of n) {
                            const [n, o] = s.trim().split("=");
                            if (n === t && o) {
                                const n = decodeURIComponent(o);
                                return a(e, n, 90), document.cookie = `${t}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`, n
                            }
                        }
                    } catch (e) {}
                    return null
                })(s);
                return r || (Math.random() < .01 && (() => {
                    try {
                        const t = [];
                        for (let a = 0; a < localStorage.length; a++) {
                            const s = localStorage.key(a);
                            if (s && s.startsWith(e)) {
                                const e = localStorage.getItem(s);
                                if (e) try {
                                    const a = JSON.parse(e);
                                    n(a.expiresAt) && t.push(s)
                                } catch {
                                    t.push(s)
                                }
                            }
                        }
                        t.forEach(e => localStorage.removeItem(e))
                    } catch (e) {}
                })(), !1)
            } catch (e) {
                return !1
            }
        },
        o = a;
    class i {
        name;
        value;
        percentage;
        constructor(e, t, n) {
            this.name = e, this.value = t, this.percentage = n
        }
    }

    function r(e, t) {
        return {
            experiment: e,
            fromCookie: arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
            trackingId: `${e}@${t.name}`,
            value: t.value,
            variant: t.name
        }
    }
    class c {
        variant(e) {
            let {
                name: t,
                value: n,
                percentage: a
            } = e;
            this.variants.push(new i(t, n, a))
        }
        pick() {
            let e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 30;
            if (this.pickResponse) return this.pickResponse;
            const n = new URL(window.location.href);
            if (n.searchParams.has(`ab_${this.name}`)) {
                const t = n.searchParams.get(`ab_${this.name}`),
                    a = this.variants.find(e => e.name === t);
                a && (e = r(this.name, a, !1))
            }
            if (e) {
                const t = this.variants.find(t => t.name === e.variant);
                return t && (this.selectedVariant = t), this.pickResponse = e, this.pickResponse
            }
            const a = s(this.name);
            if (a) {
                const e = this.variants.filter(e => e.name === a);
                if (e.length > 0) {
                    const t = e[0];
                    return this.selectedVariant = t ? ? !1, this.pickResponse = r(this.name, t, !0), this.pickResponse
                }
            }
            const i = this.chooseVariant(this.variants);
            return this.pickResponse = r(this.name, i, !1), o(this.name, i.name, t), this.selectedVariant = i, this.pickResponse
        }
        chooseVariant(e) {
            const t = Math.floor(1e6 * Math.random() + 1);
            let n, a = 0,
                s = 0;
            const o = e.sort((e, t) => t.percentage - e.percentage);
            let i;
            for (; s < o.length; s += 1) {
                if (i = o[s], n = i.percentage / 100 * 1e6, t <= a + n) return i;
                a += n + 1
            }
            return this.variants[0]
        }
        constructor(e) {
            this.name = e, this.selectedVariant = !1, this.variants = []
        }
        name;
        selectedVariant;
        variants;
        pickResponse
    }
    const l = (e, t) => {
            (function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [];
                const s = document.createElement("script");
                s.async = !!t, n && (s.defer = !0), a.forEach(e => {
                    s.setAttribute(`data-${e.key}`, e.value)
                }), s.src = e, document.head.appendChild(s)
            })(`${e}${`/${t}/raven.js`}`, !1, !1, [{
                key: "raven",
                value: "1"
            }])
        },
        d = "https://raven-static.aditude.io/prod";
    const h = Object.assign({
        cdn: d,
        env: "production",
        releaseId: "fallback",
        versions: [{
            pct: 100,
            version: "stable"
        }]
    }, window.ravenLoaderConfig || {});
    var v;
    (v = window).googletag = v.googletag || {}, v.googletag.cmd = v.googletag.cmd || [], void 0 === v.__ravenEarlyGptEvents && (v.__ravenEarlyGptEvents = [], setTimeout(function() {
        v.__ravenEarlyGptEvents = null
    }, 3e4), v.googletag.cmd.push(function() {
        var e = v.googletag.pubads();
        ["slotRequested", "slotRenderEnded", "impressionViewable"].forEach(function(t) {
            e.addEventListener(t, function(e) {
                var n = v.__ravenEarlyGptEvents;
                n && n.push({
                    eventType: t,
                    event: e,
                    timestamp: Date.now()
                })
            })
        })
    }));
    const {
        cdn: p,
        releaseId: g
    } = h, u = new class {
        baseCdnUrl;
        releaseId;
        constructor(e, t) {
            this.baseCdnUrl = e, this.releaseId = t
        }
        load(e) {
            if (e.length > 1) {
                const n = (t = `ver-${this.releaseId}`, new c(t));
                e.map(e => n.variant({
                    name: e.version,
                    percentage: 100 * e.pct,
                    value: e
                }));
                const a = n.pick(1);
                return void l(a.value ? .cdn ? ? this.baseCdnUrl, a.value.version)
            }
            var t;
            if (e.length > 0) {
                const {
                    cdn: t = this.baseCdnUrl,
                    version: n = "stable"
                } = e[0];
                return void l(t, n)
            }
            l(this.baseCdnUrl, "stable")
        }
    }(p ? ? d, g);
    if (u.load(h.versions), window.ravenLoaderConfig && (window.ravenLoaderConfig = void 0), h.property ? .id) {
        window.Raven = window.Raven || {
            cmd: [],
            initialConfig: {}
        };
        const {
            initialConfig: e
        } = window.Raven;
        window.Raven.initialConfig = {
            pbjsGlobals: e ? .pbjsGlobals || ["pbjs"],
            propertyId: h.property.id,
            ...e
        }
    }
})();