/*HTLv3*/
(e => {
    e.ADITUDE_WRAPPER_CONFIG = {
        SITE_DOMAIN: "mapping.base",
        HTLBID_GLOBAL: "htl",
        BID_MODIFIERS: {},
        PREBID_ALIASES: [],
        GPT_SET_CENTERING: !0,
        PREBID_CONFIG: {
            minBidCacheTTL: 0,
            eventHistoryTTL: 30,
            enableTIDs: !0,
            priceGranularity: "high",
            userSync: {},
            v3Settings: {
                gdpr: {
                    timeout: 8e3,
                    defaultGdprScope: !0
                },
                gpp: {
                    cmpApi: !0,
                    timeout: 8e3
                }
            },
            floors: {},
            s2sConfig: {
                accountId: "kYrTxdIsWUoC",
                bidders: ["ix_s2s", "openx_s2s", "pubmatic_s2s", "appnexus_s2s", "rubicon_s2s"],
                timeout: 1e3,
                endpoint: "https://amspbs.com/openrtb2/auction",
                syncEndpoint: "https://amspbs.com/cookie_sync",
                enabled: !0
            }
        },
        PREBID_GLOBAL: "pbjs",
        SLOT_PREFIX: "",
        ALL_AD_UNITS: [{
            slot: ".htlad-ai-assist",
            code: "/248424177/XXX/sb/ai-assist",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-ai-assist-msb",
            code: "/248424177/XXX/msb/ai-assist",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-bmlb-qp",
            code: "/248424177/XXX/bmlb/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277713"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_midpage_leaderboard_3"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277713"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-bottom-anchor-discussions",
            code: "/248424177/XXX/bottom-anchor/discussions",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 50],
                            [320, 50]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318772"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-bottom-anchor-hp",
            code: "/248424177/XXX/bottom-anchor/home-page",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 50],
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 50],
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318787"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322752"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031495"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064587"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853541"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015970"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399688"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185730
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_bQJ14MKccS"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408169"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201919"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318784"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322749"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031437"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064581"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853538"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015978"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399685"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185727
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_hK7ol5fl7S"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408166"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201916"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-bottom-anchor-qp",
            code: "/248424177/XXX/bottom-anchor/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 50],
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 50],
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318786"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322751"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031491"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064585"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853540"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015981"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399687"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185729
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_bQJ14MKccS"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408168"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201918"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318783"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322748"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031435"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064579"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853537"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015991"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399684"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185726
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_hK7ol5fl7S"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408165"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201915"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-bottom-anchor-tp",
            code: "/248424177/XXX/bottom-anchor/tag-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 50],
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 50],
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318788"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322753"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031497"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064589"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853542"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015972"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399689"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185731
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_bQJ14MKccS"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408170"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201920"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318785"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322750"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031439"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064583"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853539"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015971"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399686"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185728
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_hK7ol5fl7S"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408167"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201917"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-dev-bmlb",
            code: "/248424177/XXX/dev.stackoverflow.com/bmlb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277713"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-dev-lb",
            code: "/248424177/XXX/dev.stackoverflow.com/lb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277713"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-dev-mlb",
            code: "/248424177/XXX/dev.stackoverflow.com/mlb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277713"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-dev-msb",
            code: "/248424177/XXX/dev.stackoverflow.com/msb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-dev-sb",
            code: "/248424177/XXX/dev.stackoverflow.com/sb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "352277355"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-dev-smlb",
            code: "/248424177/XXX/dev.stackoverflow.com/smlb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-lb-qp",
            code: "/248424177/XXX/lb/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322734"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064551"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752970
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_leaderboard"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201901"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322734"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-magic-anchor-hp",
            code: "/248424177/XXX/magic-anchor/home-page",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318787"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322752"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031495"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064587"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853541"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015970"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399688"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185730
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_bQJ14MKccS"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408169"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201919"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318784"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322749"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031437"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064581"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853538"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015978"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399685"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185727
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_hK7ol5fl7S"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408166"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201916"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-magic-anchor-qp",
            code: "/248424177/XXX/magic-anchor/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318786"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322751"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031491"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064585"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853540"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015981"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399687"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185729
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_bQJ14MKccS"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408168"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201918"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318783"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322748"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031435"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064579"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853537"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015991"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399684"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185726
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_hK7ol5fl7S"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408165"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201915"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-magic-anchor-tp",
            code: "/248424177/XXX/magic-anchor/tag-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [320, 50],
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318788"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322753"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031497"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064589"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853542"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015972"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399689"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185731
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_bQJ14MKccS"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408170"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201920"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1318785"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322750"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031439"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064583"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853539"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015971"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7399686"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 37185728
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_hK7ol5fl7S"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408167"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201917"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-meta-bmlb",
            code: "/248424177/XXX/meta.stackexchange.local/bmlb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-meta-lb",
            code: "/248424177/XXX/meta.stackexchange.local/lb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-meta-mlb",
            code: "/248424177/XXX/meta.stackexchange.local/mlb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-meta-msb",
            code: "/248424177/XXX/meta.stackexchange.local/msb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191388"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_middle_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-meta-sb",
            code: "/248424177/XXX/meta.stackexchange.local/sb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "352277355"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "FCuzZwkOspIGSBbsCAyqKZM9"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "171347915"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752968
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201910"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064563"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020339"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015988"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277708"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322732"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868284"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-meta-smlb",
            code: "/248424177/XXX/meta.stackexchange.local/smlb",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322734"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-mlb-qp",
            code: "/248424177/XXX/mlb/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322734"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752973
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201904"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277710"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322734"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-msb-hp",
            code: "/248424177/XXX/msb/home-page",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277720"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322744"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191386"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752980
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "865723253"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_homepage_middle_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201911"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277721"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322745"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191396"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752981
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "FCuzZwkOspIGSBbsCAyqKZM9"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "129793948"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_homepage_middle_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201912"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-msb-qp",
            code: "/248424177/XXX/msb/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277716"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322740"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868284"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064563"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020339"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015988"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752976
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "Wf2sKTMXBToEwqnoG287uInB"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "352277355"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_middle_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408157"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201907"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277717"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322741"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868294"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064565"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020340"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015965"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752977
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "GFWYZsR83tPth4HCyfhacpZv"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "171347915"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_question_middle_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408158"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201908"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-msb-tp",
            code: "/248424177/XXX/msb/tag-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868268"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064547"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020331"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015979"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408149"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201899"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "FCuzZwkOspIGSBbsCAyqKZM9"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "870778665"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752974
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277716"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322740"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868270"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064549"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020332"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015987"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408150"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201900"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "Wf2sKTMXBToEwqnoG287uInB"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "870778665"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752979
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277717"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322741"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-native-comment-qp",
            code: "/248424177/XXX/native-comment/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: ["fluid"],
                        viewport: [0, 0]
                    }, {
                        sizes: ["fluid"],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: []
            }, {
                viewport: [0, 0],
                bids: []
            }]
        }, {
            slot: ".htlad-native-comment-threaded-qp",
            code: "/248424177/XXX/native-comment-threaded/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: ["fluid"],
                        viewport: [0, 0]
                    }, {
                        sizes: ["fluid"],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: []
            }, {
                viewport: [0, 0],
                bids: []
            }]
        }, {
            slot: ".htlad-native-question-hp",
            code: "/248424177/XXX/native-question/home-page",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: ["fluid", [730, 135]],
                        viewport: [0, 0]
                    }, {
                        sizes: ["fluid", [730, 135]],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-native-question-qp",
            code: "/248424177/XXX/native-question/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: ["fluid", [730, 135]],
                        viewport: [0, 0]
                    }, {
                        sizes: ["fluid", [730, 135]],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-native-question-tp",
            code: "/248424177/XXX/native-question/tag-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: ["fluid", [730, 135]],
                        viewport: [0, 0]
                    }, {
                        sizes: ["fluid", [730, 135]],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sb-discussions",
            code: "/248424177/XXX/sb/discussions",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277660"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "GFWYZsR83tPth4HCyfhacpZv"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "760748718"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752974
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064567"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408159"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191387"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020341"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015976"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322742"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868300"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sb-hp",
            code: "/248424177/XXX/sb/home-page",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277718"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322742"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868300"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064567"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020341"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015976"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191387"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752978
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "UUKx0kJCRv0uN8oLnm8qxTyJ"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "870778665"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_homepage_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408159"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201909"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277719"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322743"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868304"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064569"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020342"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015985"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191397"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752979
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "J2qaX3mU6miHs3ILQan9rtIO"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "760748718"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_homepage_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408160"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201910"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sb-qp",
            code: "/248424177/XXX/sb/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277714"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322738"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868280"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064559"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020337"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015969"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191394"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752974
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "YRJtPY5uBbVF04BRY0DI0mIo"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "212766556"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408155"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201905"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277715"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322739"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868282"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064561"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020338"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015968"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191400"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752975
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "IFYVnGyAFcz5cCCQ2L9hzJv1"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "268973784"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_question_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408156"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201906"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sb-tp",
            code: "/248424177/XXX/sb/tag-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [300, 250],
                            [300, 600]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277722"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322746"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868320"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064575"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020345"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015975"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191395"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752982
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "QcBbl8aD6mrnLsXXKGpC3d3f"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_xdmRh1G7dc"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "703604053"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_tag_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408163"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201913"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277723"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868326"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064577"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020346"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015974"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191401"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752983
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "JKSxrbwN1l2TDsySgGKmZ05x"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_nD2acIpASw"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "566464561"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_tag_sidebar"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408164"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201914"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322736"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-smlb-qp",
            code: "/248424177/XXX/smlb/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [728, 90]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ix",
                        params: {
                            siteId: "1277712"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868276"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064555"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020335"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015964"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191392"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752972
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "n7VlIaIAUJjGuuF05nJIZNmR"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "235708677"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_midpage_leaderboard_2"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408153"
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201903"
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "conversant",
                        params: {
                            site_id: "253215",
                            secure: "1"
                        }
                    }, {
                        bidder: "equativ",
                        params: {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }
                    }, {
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }, {
                        bidder: "triplelift",
                        params: {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }
                    }, {
                        bidder: "sharethrough",
                        params: {
                            pkey: "n7VlIaIAUJjGuuF05nJIZNmR"
                        }
                    }, {
                        bidder: "medianet",
                        params: {
                            cid: "8CU4SHE46",
                            crid: "235708677"
                        }
                    }, {
                        bidder: "appnexus",
                        params: {
                            placementId: 36752972
                        }
                    }, {
                        bidder: "appnexus_s2s",
                        params: {
                            placement_id: "37201903"
                        }
                    }, {
                        bidder: "rubicon_s2s",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064555"
                        }
                    }, {
                        bidder: "pubmatic_s2s",
                        params: {
                            publisherId: "167120",
                            adSlot: "7408153"
                        }
                    }, {
                        bidder: "pubmatic",
                        params: {
                            publisherId: "167120",
                            adSlot: "7191392"
                        }
                    }, {
                        bidder: "openx",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020335"
                        }
                    }, {
                        bidder: "openx_s2s",
                        params: {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015964"
                        }
                    }, {
                        bidder: "ix",
                        params: {
                            siteId: "1277712"
                        }
                    }, {
                        bidder: "ix_s2s",
                        params: {
                            siteId: "1322737"
                        }
                    }, {
                        bidder: "kargo",
                        params: {
                            placementId: "_w8AGLxREJl"
                        }
                    }, {
                        bidder: "rubicon",
                        params: {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868276"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sspon-hp",
            code: "/248424177/XXX/site-sponsorship/home-page",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [230, 60]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [230, 60]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sspon-qp",
            code: "/248424177/XXX/site-sponsorship/question-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [230, 60]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [230, 60]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }, {
            slot: ".htlad-sspon-tp",
            code: "/248424177/XXX/site-sponsorship/tag-pages",
            targeting: {},
            interstitial: !1,
            oop: !1,
            mediaTypes: {
                banner: {
                    sizes: [{
                        sizes: [
                            [230, 60]
                        ],
                        viewport: [0, 0]
                    }, {
                        sizes: [
                            [230, 60]
                        ],
                        viewport: [0, 0]
                    }]
                }
            },
            bids: [{
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }, {
                viewport: [0, 0],
                bids: [
                    [{
                        bidder: "ttd",
                        params: {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }
                    }]
                ]
            }]
        }],
        COMPONENTS: [{
            name: "user-id",
            config: {
                userModules: [{
                    module: "unifiedId",
                    extraParams: {
                        url: "//match.adsrvr.org/track/rid?ttd_pid=4fr687n&fmt=json"
                    }
                }]
            }
        }, {
            name: "htl-prebid-floors",
            config: {
                config: {
                    prebidFloors: {
                        custom: {},
                        fields: ["device"],
                        floorReporting: {
                            enabled: !1,
                            keyName: "hasFloors"
                        },
                        rules: [{
                            cpm: "0.05",
                            values: {
                                device: "*"
                            },
                            uuid: "da7668dd-51f9-45c5-a263-36ec7dc31fa4"
                        }],
                        skipRate: {
                            enabled: !1,
                            keyName: "skip",
                            value: 0
                        }
                    }
                }
            }
        }, {
            name: "htl-injector",
            config: {
                autoStartLayouts: !0,
                htlbidGlobal: "htl",
                pageviewUrl: "//ams-pageview-public.s3.amazonaws.com/1x1-pixel.png?id=b1ffe3826ebc",
                selectors: [{
                    selector: ".htlad-ai-assist",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-ai-assist-msb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-bmlb-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-bottom-anchor-discussions",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-bottom-anchor-hp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-bottom-anchor-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-bottom-anchor-tp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-dev-bmlb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-dev-lb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-dev-mlb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-dev-msb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-dev-sb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-dev-smlb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-lb-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-magic-anchor-hp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-magic-anchor-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-magic-anchor-tp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-meta-bmlb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-meta-lb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-meta-mlb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-meta-msb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-meta-sb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-meta-smlb",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-mlb-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-msb-hp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-msb-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-msb-tp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-native-comment-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-native-comment-threaded-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-native-question-hp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-native-question-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-native-question-tp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sb-discussions",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sb-hp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sb-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sb-tp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-smlb-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sspon-hp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sspon-qp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }, {
                    selector: ".htlad-sspon-tp",
                    forceRender: !1,
                    sticky: !1,
                    interstitial: !1,
                    oop: !1
                }],
                slots: [{
                    name: "ai-assist",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["ai-assist_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["ai-assist_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/ai-assist"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["ai-assist_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["ai-assist_Mobile"]
                    }]
                }, {
                    name: "ai-assist-msb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["ai-assist_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["ai-assist_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/ai-assist"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["ai-assist_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["ai-assist_Mobile"]
                    }]
                }, {
                    name: "bmlb-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bmlb-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bmlb-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bmlb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bmlb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bmlb-qp_Mobile"]
                    }]
                }, {
                    name: "bottom-anchor-discussions",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-discussions_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/discussions"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-discussions_Mobile"]
                    }]
                }, {
                    name: "bottom-anchor-hp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-hp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-hp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bottom-anchor-hp_Mobile"]
                    }]
                }, {
                    name: "bottom-anchor-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bottom-anchor-qp_Mobile"]
                    }]
                }, {
                    name: "bottom-anchor-tp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-tp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 50],
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["bottom-anchor-tp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bottom-anchor-tp_Mobile"]
                    }]
                }, {
                    name: "dev-bmlb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["dev-bmlb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/bmlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-bmlb_Desktop"]
                    }]
                }, {
                    name: "dev-lb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["dev-lb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/lb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-lb_Desktop"]
                    }]
                }, {
                    name: "dev-mlb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["dev-mlb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/mlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-mlb_Desktop"]
                    }]
                }, {
                    name: "dev-msb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["dev-msb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/msb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-msb_Desktop"]
                    }]
                }, {
                    name: "dev-sb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["dev-sb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/sb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-sb_Desktop"]
                    }]
                }, {
                    name: "dev-smlb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["dev-smlb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/smlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-smlb_Desktop"]
                    }]
                }, {
                    name: "lb-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["lb-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["lb-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/lb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["lb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["lb-qp_Mobile"]
                    }]
                }, {
                    name: "magic-anchor-hp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["magic-anchor-hp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["magic-anchor-hp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/magic-anchor/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["magic-anchor-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["magic-anchor-hp_Mobile"]
                    }]
                }, {
                    name: "magic-anchor-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["magic-anchor-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["magic-anchor-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/magic-anchor/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["magic-anchor-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["magic-anchor-qp_Mobile"]
                    }]
                }, {
                    name: "magic-anchor-tp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["magic-anchor-tp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [320, 50],
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["magic-anchor-tp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/magic-anchor/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["magic-anchor-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["magic-anchor-tp_Mobile"]
                    }]
                }, {
                    name: "meta-bmlb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["meta-bmlb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/bmlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-bmlb_Desktop"]
                    }]
                }, {
                    name: "meta-lb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["meta-lb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/lb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-lb_Desktop"]
                    }]
                }, {
                    name: "meta-mlb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["meta-mlb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/mlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-mlb_Desktop"]
                    }]
                }, {
                    name: "meta-msb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["meta-msb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/msb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-msb_Desktop"]
                    }]
                }, {
                    name: "meta-sb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["meta-sb_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["meta-sb_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/sb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-sb_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["meta-sb_Mobile"]
                    }]
                }, {
                    name: "meta-smlb",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["meta-smlb_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/smlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-smlb_Desktop"]
                    }]
                }, {
                    name: "mlb-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["mlb-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["mlb-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/mlb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["mlb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["mlb-qp_Mobile"]
                    }]
                }, {
                    name: "msb-hp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["msb-hp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["msb-hp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["msb-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["msb-hp_Mobile"]
                    }]
                }, {
                    name: "msb-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["msb-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["msb-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["msb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["msb-qp_Mobile"]
                    }]
                }, {
                    name: "msb-tp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["msb-tp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["msb-tp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["msb-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["msb-tp_Mobile"]
                    }]
                }, {
                    name: "native-comment-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid"]
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid"]
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-comment/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: []
                    }, {
                        viewport: [0, 0],
                        groups: []
                    }]
                }, {
                    name: "native-comment-threaded-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid"]
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid"]
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-comment-threaded/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: []
                    }, {
                        viewport: [0, 0],
                        groups: []
                    }]
                }, {
                    name: "native-question-hp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid", [730, 135]],
                            prebid: {
                                groups: ["native-question-hp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid", [730, 135]],
                            prebid: {
                                groups: ["native-question-hp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-question/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["native-question-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["native-question-hp_Mobile"]
                    }]
                }, {
                    name: "native-question-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid", [730, 135]],
                            prebid: {
                                groups: ["native-question-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid", [730, 135]],
                            prebid: {
                                groups: ["native-question-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-question/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["native-question-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["native-question-qp_Mobile"]
                    }]
                }, {
                    name: "native-question-tp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid", [730, 135]],
                            prebid: {
                                groups: ["native-question-tp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: ["fluid", [730, 135]],
                            prebid: {
                                groups: ["native-question-tp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-question/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["native-question-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["native-question-tp_Mobile"]
                    }]
                }, {
                    name: "sb-discussions",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-discussions_Desktop"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/discussions"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-discussions_Desktop"]
                    }]
                }, {
                    name: "sb-hp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-hp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-hp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sb-hp_Mobile"]
                    }]
                }, {
                    name: "sb-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sb-qp_Mobile"]
                    }]
                }, {
                    name: "sb-tp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-tp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [300, 250],
                                [300, 600]
                            ],
                            prebid: {
                                groups: ["sb-tp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sb-tp_Mobile"]
                    }]
                }, {
                    name: "smlb-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["smlb-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [728, 90]
                            ],
                            prebid: {
                                groups: ["smlb-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/smlb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["smlb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["smlb-qp_Mobile"]
                    }]
                }, {
                    name: "sspon-hp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [230, 60]
                            ],
                            prebid: {
                                groups: ["sspon-hp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [230, 60]
                            ],
                            prebid: {
                                groups: ["sspon-hp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/site-sponsorship/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sspon-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sspon-hp_Mobile"]
                    }]
                }, {
                    name: "sspon-qp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [230, 60]
                            ],
                            prebid: {
                                groups: ["sspon-qp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [230, 60]
                            ],
                            prebid: {
                                groups: ["sspon-qp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/site-sponsorship/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sspon-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sspon-qp_Mobile"]
                    }]
                }, {
                    name: "sspon-tp",
                    interstitial: !1,
                    tiles: [{
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [230, 60]
                            ],
                            prebid: {
                                groups: ["sspon-tp_Desktop"]
                            }
                        }
                    }, {
                        viewport: [0, 0],
                        config: {
                            sizes: [
                                [230, 60]
                            ],
                            prebid: {
                                groups: ["sspon-tp_Mobile"]
                            }
                        }
                    }],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/site-sponsorship/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sspon-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sspon-tp_Mobile"]
                    }]
                }]
            }
        }, {
            name: "throttle-refresh",
            config: {
                throttleMs: 5e3
            }
        }],
        INTERSECTION_OBSERVER: {
            ROOT_MARGIN: "350px 0px 350px 0px",
            THRESHOLD: [.25]
        },
        PREBID_TIMEOUT: 2e3,
        PBJS_BUILD: {
            version: "9.30.0",
            modules: ["equativBidAdapter", "ttdBidAdapter", "sharethroughBidAdapter", "medianetBidAdapter", "appnexusBidAdapter", "rubiconBidAdapter", "pubmaticBidAdapter", "openxBidAdapter", "ixBidAdapter", "conversantBidAdapter", "kargoBidAdapter", "tripleliftBidAdapter", "unifiedIdSystem", "priceFloors", "prebidServerBidAdapter", "gptPreAuction", "sharedIdSystem", "33acrossIdSystem", "fabrickIdSystem", "id5IdSystem", "criteoIdSystem", "pubProvidedIdSystem", "unifiedIdSystem", "consentManagement", "consentManagementGpp", "consentManagementUsp"]
        },
        THIRD_PARTY_SCRIPTS: [],
        COMPONENTS_CONFIG_ENABLED: !0,
        CUSTOM_JS: "",
        HTL_CONFIG: {
            modules: {
                prebid: {
                    config: {
                        minBidCacheTTL: 0,
                        eventHistoryTTL: 30,
                        enableTIDs: !0,
                        priceGranularity: "high",
                        userSync: {},
                        v3Settings: {
                            gdpr: {
                                timeout: 8e3,
                                defaultGdprScope: !0
                            },
                            gpp: {
                                cmpApi: !0,
                                timeout: 8e3
                            }
                        },
                        floors: {
                            data: {
                                default: .05
                            }
                        },
                        s2sConfig: {
                            accountId: "kYrTxdIsWUoC",
                            bidders: ["ix_s2s", "openx_s2s", "pubmatic_s2s", "appnexus_s2s", "rubicon_s2s"],
                            timeout: 1e3,
                            endpoint: "https://amspbs.com/openrtb2/auction",
                            syncEndpoint: "https://amspbs.com/cookie_sync",
                            enabled: !0
                        }
                    },
                    bids: [
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["sharethrough", {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["sharethrough", {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["ix", {
                            siteId: "1277713"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_midpage_leaderboard_3"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }],
                        ["ix", {
                            siteId: "1277713"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }],
                        ["ix", {
                            siteId: "1318772"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ix", {
                            siteId: "1318787"
                        }],
                        ["ix_s2s", {
                            siteId: "1322752"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031495"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064587"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853541"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015970"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399688"
                        }],
                        ["appnexus", {
                            placementId: 37185730
                        }],
                        ["kargo", {
                            placementId: "_bQJ14MKccS"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408169"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201919"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["ix", {
                            siteId: "1318784"
                        }],
                        ["ix_s2s", {
                            siteId: "1322749"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031437"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064581"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853538"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015978"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399685"
                        }],
                        ["appnexus", {
                            placementId: 37185727
                        }],
                        ["kargo", {
                            placementId: "_hK7ol5fl7S"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408166"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201916"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["ix", {
                            siteId: "1318786"
                        }],
                        ["ix_s2s", {
                            siteId: "1322751"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031491"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064585"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853540"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015981"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399687"
                        }],
                        ["appnexus", {
                            placementId: 37185729
                        }],
                        ["kargo", {
                            placementId: "_bQJ14MKccS"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408168"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201918"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["ix", {
                            siteId: "1318783"
                        }],
                        ["ix_s2s", {
                            siteId: "1322748"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031435"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064579"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853537"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015991"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399684"
                        }],
                        ["appnexus", {
                            placementId: 37185726
                        }],
                        ["kargo", {
                            placementId: "_hK7ol5fl7S"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408165"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201915"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["ix", {
                            siteId: "1318788"
                        }],
                        ["ix_s2s", {
                            siteId: "1322753"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031497"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064589"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853542"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015972"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399689"
                        }],
                        ["appnexus", {
                            placementId: 37185731
                        }],
                        ["kargo", {
                            placementId: "_bQJ14MKccS"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408170"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201920"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["ix", {
                            siteId: "1318785"
                        }],
                        ["ix_s2s", {
                            siteId: "1322750"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031439"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064583"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853539"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015971"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399686"
                        }],
                        ["appnexus", {
                            placementId: 37185728
                        }],
                        ["kargo", {
                            placementId: "_hK7ol5fl7S"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408167"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201917"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }],
                        ["ix", {
                            siteId: "1277713"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }],
                        ["ix", {
                            siteId: "1277713"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408154"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191393"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020336"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015967"
                        }],
                        ["ix", {
                            siteId: "1277713"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868278"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["sharethrough", {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["sharethrough", {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "352277355"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "rkYUwe92ZX5V6ig63dpYBrfH"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "958874748"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322734"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064551"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["appnexus", {
                            placementId: 36752970
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_leaderboard"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201901"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322734"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["ix", {
                            siteId: "1318787"
                        }],
                        ["ix_s2s", {
                            siteId: "1322752"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031495"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064587"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853541"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015970"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399688"
                        }],
                        ["appnexus", {
                            placementId: 37185730
                        }],
                        ["kargo", {
                            placementId: "_bQJ14MKccS"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408169"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201919"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["ix", {
                            siteId: "1318784"
                        }],
                        ["ix_s2s", {
                            siteId: "1322749"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031437"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064581"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853538"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015978"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399685"
                        }],
                        ["appnexus", {
                            placementId: 37185727
                        }],
                        ["kargo", {
                            placementId: "_hK7ol5fl7S"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408166"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201916"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["ix", {
                            siteId: "1318786"
                        }],
                        ["ix_s2s", {
                            siteId: "1322751"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031491"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064585"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853540"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015981"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399687"
                        }],
                        ["appnexus", {
                            placementId: 37185729
                        }],
                        ["kargo", {
                            placementId: "_bQJ14MKccS"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408168"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201918"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["ix", {
                            siteId: "1318783"
                        }],
                        ["ix_s2s", {
                            siteId: "1322748"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031435"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064579"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853537"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015991"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399684"
                        }],
                        ["appnexus", {
                            placementId: 37185726
                        }],
                        ["kargo", {
                            placementId: "_hK7ol5fl7S"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408165"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201915"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["ix", {
                            siteId: "1318788"
                        }],
                        ["ix_s2s", {
                            siteId: "1322753"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031497"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064589"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853542"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015972"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399689"
                        }],
                        ["appnexus", {
                            placementId: 37185731
                        }],
                        ["kargo", {
                            placementId: "_bQJ14MKccS"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408170"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201920"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["ix", {
                            siteId: "1318785"
                        }],
                        ["ix_s2s", {
                            siteId: "1322750"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4031439"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064583"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564853539"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015971"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7399686"
                        }],
                        ["appnexus", {
                            placementId: 37185728
                        }],
                        ["kargo", {
                            placementId: "_hK7ol5fl7S"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408167"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201917"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191388"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["sharethrough", {
                            pkey: "33b3HNY2dbsO8784alkpleas"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "210823146"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_middle_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "352277355"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "FCuzZwkOspIGSBbsCAyqKZM9"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "171347915"
                        }],
                        ["appnexus", {
                            placementId: 36752968
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201910"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064563"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020339"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015988"
                        }],
                        ["ix", {
                            siteId: "1277708"
                        }],
                        ["ix_s2s", {
                            siteId: "1322732"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868284"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322734"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322734"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "60GKzufcDclkDX048hEpdRQX"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "382553585"
                        }],
                        ["appnexus", {
                            placementId: 36752973
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201904"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064557"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408151"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191389"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020333"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015984"
                        }],
                        ["ix", {
                            siteId: "1277710"
                        }],
                        ["ix_s2s", {
                            siteId: "1322734"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868272"
                        }],
                        ["ix", {
                            siteId: "1277720"
                        }],
                        ["ix_s2s", {
                            siteId: "1322744"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868308"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064571"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020343"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015973"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191386"
                        }],
                        ["appnexus", {
                            placementId: 36752980
                        }],
                        ["sharethrough", {
                            pkey: "AeyiT0LNoen1C9kBL4QJdNHe"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "865723253"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_homepage_middle_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408161"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201911"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277721"
                        }],
                        ["ix_s2s", {
                            siteId: "1322745"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868316"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064573"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020344"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015982"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191396"
                        }],
                        ["appnexus", {
                            placementId: 36752981
                        }],
                        ["sharethrough", {
                            pkey: "FCuzZwkOspIGSBbsCAyqKZM9"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "129793948"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_homepage_middle_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408162"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201912"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277716"
                        }],
                        ["ix_s2s", {
                            siteId: "1322740"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868284"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064563"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020339"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015988"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }],
                        ["appnexus", {
                            placementId: 36752976
                        }],
                        ["sharethrough", {
                            pkey: "Wf2sKTMXBToEwqnoG287uInB"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "352277355"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_middle_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408157"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201907"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277717"
                        }],
                        ["ix_s2s", {
                            siteId: "1322741"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868294"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064565"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020340"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015965"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }],
                        ["appnexus", {
                            placementId: 36752977
                        }],
                        ["sharethrough", {
                            pkey: "GFWYZsR83tPth4HCyfhacpZv"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "171347915"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_question_middle_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408158"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201908"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868268"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064547"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020331"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015979"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408149"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201899"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "FCuzZwkOspIGSBbsCAyqKZM9"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "870778665"
                        }],
                        ["appnexus", {
                            placementId: 36752974
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191390"
                        }],
                        ["ix", {
                            siteId: "1277716"
                        }],
                        ["ix_s2s", {
                            siteId: "1322740"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868270"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064549"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020332"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015987"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408150"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201900"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "Wf2sKTMXBToEwqnoG287uInB"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "870778665"
                        }],
                        ["appnexus", {
                            placementId: 36752979
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191399"
                        }],
                        ["ix", {
                            siteId: "1277717"
                        }],
                        ["ix_s2s", {
                            siteId: "1322741"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277660"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "GFWYZsR83tPth4HCyfhacpZv"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "760748718"
                        }],
                        ["appnexus", {
                            placementId: 36752974
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064567"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408159"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191387"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020341"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015976"
                        }],
                        ["ix_s2s", {
                            siteId: "1322742"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868300"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["ix", {
                            siteId: "1277718"
                        }],
                        ["ix_s2s", {
                            siteId: "1322742"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868300"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064567"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020341"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015976"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191387"
                        }],
                        ["appnexus", {
                            placementId: 36752978
                        }],
                        ["sharethrough", {
                            pkey: "UUKx0kJCRv0uN8oLnm8qxTyJ"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "870778665"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_homepage_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408159"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201909"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277719"
                        }],
                        ["ix_s2s", {
                            siteId: "1322743"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868304"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064569"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020342"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015985"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191397"
                        }],
                        ["appnexus", {
                            placementId: 36752979
                        }],
                        ["sharethrough", {
                            pkey: "J2qaX3mU6miHs3ILQan9rtIO"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "760748718"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_homepage_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408160"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201910"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277714"
                        }],
                        ["ix_s2s", {
                            siteId: "1322738"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868280"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064559"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020337"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015969"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191394"
                        }],
                        ["appnexus", {
                            placementId: 36752974
                        }],
                        ["sharethrough", {
                            pkey: "YRJtPY5uBbVF04BRY0DI0mIo"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "212766556"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408155"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201905"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277715"
                        }],
                        ["ix_s2s", {
                            siteId: "1322739"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868282"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064561"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020338"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015968"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191400"
                        }],
                        ["appnexus", {
                            placementId: 36752975
                        }],
                        ["sharethrough", {
                            pkey: "IFYVnGyAFcz5cCCQ2L9hzJv1"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "268973784"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_question_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408156"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201906"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277722"
                        }],
                        ["ix_s2s", {
                            siteId: "1322746"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868320"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064575"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020345"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015975"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191395"
                        }],
                        ["appnexus", {
                            placementId: 36752982
                        }],
                        ["sharethrough", {
                            pkey: "QcBbl8aD6mrnLsXXKGpC3d3f"
                        }],
                        ["kargo", {
                            placementId: "_xdmRh1G7dc"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "703604053"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_tag_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408163"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201913"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix", {
                            siteId: "1277723"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868326"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064577"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020346"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015974"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191401"
                        }],
                        ["appnexus", {
                            placementId: 36752983
                        }],
                        ["sharethrough", {
                            pkey: "JKSxrbwN1l2TDsySgGKmZ05x"
                        }],
                        ["kargo", {
                            placementId: "_nD2acIpASw"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "566464561"
                        }],
                        ["triplelift", {
                            inventoryCode: "Sidebar_NativeFixed_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "M_tag_sidebar"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408164"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201914"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ix_s2s", {
                            siteId: "1322736"
                        }],
                        ["ix", {
                            siteId: "1277712"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868276"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064555"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020335"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015964"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191392"
                        }],
                        ["appnexus", {
                            placementId: 36752972
                        }],
                        ["sharethrough", {
                            pkey: "n7VlIaIAUJjGuuF05nJIZNmR"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "235708677"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1",
                            tag_id: "D_question_midpage_leaderboard_2"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408153"
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201903"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["conversant", {
                            site_id: "253215",
                            secure: "1"
                        }],
                        ["equativ", {
                            networkId: 5885,
                            siteId: 766906,
                            pageId: 2173933,
                            formatId: 153746
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["triplelift", {
                            inventoryCode: "Leaderboard_HDX_Prebid"
                        }],
                        ["sharethrough", {
                            pkey: "n7VlIaIAUJjGuuF05nJIZNmR"
                        }],
                        ["medianet", {
                            cid: "8CU4SHE46",
                            crid: "235708677"
                        }],
                        ["appnexus", {
                            placementId: 36752972
                        }],
                        ["appnexus_s2s", {
                            placement_id: "37201903"
                        }],
                        ["rubicon_s2s", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "4064555"
                        }],
                        ["pubmatic_s2s", {
                            publisherId: "167120",
                            adSlot: "7408153"
                        }],
                        ["pubmatic", {
                            publisherId: "167120",
                            adSlot: "7191392"
                        }],
                        ["openx", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "564020335"
                        }],
                        ["openx_s2s", {
                            delDomain: "stackoverflow-d.openx.net",
                            unit: "565015964"
                        }],
                        ["ix", {
                            siteId: "1277712"
                        }],
                        ["ix_s2s", {
                            siteId: "1322737"
                        }],
                        ["kargo", {
                            placementId: "_w8AGLxREJl"
                        }],
                        ["rubicon", {
                            accountId: "21408",
                            siteId: "288900",
                            zoneId: "3868276"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }],
                        ["ttd", {
                            supplySourceId: "direct29k4dc0z",
                            publisherId: "1"
                        }]
                    ]
                }
            },
            slots: {
                "ai-assist": {
                    name: "ai-assist",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["ai-assist_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["ai-assist_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/ai-assist"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["ai-assist_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["ai-assist_Mobile"]
                    }]
                },
                "ai-assist-msb": {
                    name: "ai-assist-msb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["ai-assist_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["ai-assist_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/ai-assist"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["ai-assist_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["ai-assist_Mobile"]
                    }]
                },
                "bmlb-qp": {
                    name: "bmlb-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bmlb-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bmlb-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bmlb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bmlb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bmlb-qp_Mobile"]
                    }]
                },
                "bottom-anchor-discussions": {
                    name: "bottom-anchor-discussions",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-discussions_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/discussions"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-discussions_Mobile"]
                    }]
                },
                "bottom-anchor-hp": {
                    name: "bottom-anchor-hp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-hp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-hp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bottom-anchor-hp_Mobile"]
                    }]
                },
                "bottom-anchor-qp": {
                    name: "bottom-anchor-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bottom-anchor-qp_Mobile"]
                    }]
                },
                "bottom-anchor-tp": {
                    name: "bottom-anchor-tp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-tp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 50],
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["bottom-anchor-tp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/bottom-anchor/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["bottom-anchor-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["bottom-anchor-tp_Mobile"]
                    }]
                },
                "dev-bmlb": {
                    name: "dev-bmlb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["dev-bmlb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/bmlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-bmlb_Desktop"]
                    }]
                },
                "dev-lb": {
                    name: "dev-lb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["dev-lb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/lb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-lb_Desktop"]
                    }]
                },
                "dev-mlb": {
                    name: "dev-mlb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["dev-mlb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/mlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-mlb_Desktop"]
                    }]
                },
                "dev-msb": {
                    name: "dev-msb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["dev-msb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/msb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-msb_Desktop"]
                    }]
                },
                "dev-sb": {
                    name: "dev-sb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["dev-sb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/sb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-sb_Desktop"]
                    }]
                },
                "dev-smlb": {
                    name: "dev-smlb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["dev-smlb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/dev.stackoverflow.com/smlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["dev-smlb_Desktop"]
                    }]
                },
                "lb-qp": {
                    name: "lb-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["lb-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["lb-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/lb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["lb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["lb-qp_Mobile"]
                    }]
                },
                "magic-anchor-hp": {
                    name: "magic-anchor-hp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["magic-anchor-hp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["magic-anchor-hp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/magic-anchor/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["magic-anchor-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["magic-anchor-hp_Mobile"]
                    }]
                },
                "magic-anchor-qp": {
                    name: "magic-anchor-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["magic-anchor-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["magic-anchor-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/magic-anchor/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["magic-anchor-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["magic-anchor-qp_Mobile"]
                    }]
                },
                "magic-anchor-tp": {
                    name: "magic-anchor-tp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["magic-anchor-tp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [320, 50],
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["magic-anchor-tp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/magic-anchor/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["magic-anchor-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["magic-anchor-tp_Mobile"]
                    }]
                },
                "meta-bmlb": {
                    name: "meta-bmlb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["meta-bmlb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/bmlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-bmlb_Desktop"]
                    }]
                },
                "meta-lb": {
                    name: "meta-lb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["meta-lb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/lb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-lb_Desktop"]
                    }]
                },
                "meta-mlb": {
                    name: "meta-mlb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["meta-mlb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/mlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-mlb_Desktop"]
                    }]
                },
                "meta-msb": {
                    name: "meta-msb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["meta-msb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/msb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-msb_Desktop"]
                    }]
                },
                "meta-sb": {
                    name: "meta-sb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["meta-sb_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["meta-sb_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/sb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-sb_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["meta-sb_Mobile"]
                    }]
                },
                "meta-smlb": {
                    name: "meta-smlb",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["meta-smlb_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/meta.stackexchange.local/smlb"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["meta-smlb_Desktop"]
                    }]
                },
                "mlb-qp": {
                    name: "mlb-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["mlb-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["mlb-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/mlb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["mlb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["mlb-qp_Mobile"]
                    }]
                },
                "msb-hp": {
                    name: "msb-hp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["msb-hp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["msb-hp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["msb-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["msb-hp_Mobile"]
                    }]
                },
                "msb-qp": {
                    name: "msb-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["msb-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["msb-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["msb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["msb-qp_Mobile"]
                    }]
                },
                "msb-tp": {
                    name: "msb-tp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["msb-tp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["msb-tp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/msb/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["msb-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["msb-tp_Mobile"]
                    }]
                },
                "native-comment-qp": {
                    name: "native-comment-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: ["fluid"]
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: ["fluid"]
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-comment/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: []
                    }, {
                        viewport: [0, 0],
                        groups: []
                    }]
                },
                "native-comment-threaded-qp": {
                    name: "native-comment-threaded-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: ["fluid"]
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: ["fluid"]
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-comment-threaded/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: []
                    }, {
                        viewport: [0, 0],
                        groups: []
                    }]
                },
                "native-question-hp": {
                    name: "native-question-hp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: ["fluid", [730, 135]],
                                prebid: {
                                    groups: ["native-question-hp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: ["fluid", [730, 135]],
                                prebid: {
                                    groups: ["native-question-hp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-question/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["native-question-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["native-question-hp_Mobile"]
                    }]
                },
                "native-question-qp": {
                    name: "native-question-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: ["fluid", [730, 135]],
                                prebid: {
                                    groups: ["native-question-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: ["fluid", [730, 135]],
                                prebid: {
                                    groups: ["native-question-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-question/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["native-question-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["native-question-qp_Mobile"]
                    }]
                },
                "native-question-tp": {
                    name: "native-question-tp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: ["fluid", [730, 135]],
                                prebid: {
                                    groups: ["native-question-tp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: ["fluid", [730, 135]],
                                prebid: {
                                    groups: ["native-question-tp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/native-question/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["native-question-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["native-question-tp_Mobile"]
                    }]
                },
                "sb-discussions": {
                    name: "sb-discussions",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-discussions_Desktop"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/discussions"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-discussions_Desktop"]
                    }]
                },
                "sb-hp": {
                    name: "sb-hp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-hp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-hp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sb-hp_Mobile"]
                    }]
                },
                "sb-qp": {
                    name: "sb-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sb-qp_Mobile"]
                    }]
                },
                "sb-tp": {
                    name: "sb-tp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-tp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [300, 250],
                                    [300, 600]
                                ],
                                prebid: {
                                    groups: ["sb-tp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/sb/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sb-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sb-tp_Mobile"]
                    }]
                },
                "smlb-qp": {
                    name: "smlb-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["smlb-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [728, 90]
                                ],
                                prebid: {
                                    groups: ["smlb-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/smlb/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["smlb-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["smlb-qp_Mobile"]
                    }]
                },
                "sspon-hp": {
                    name: "sspon-hp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [230, 60]
                                ],
                                prebid: {
                                    groups: ["sspon-hp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [230, 60]
                                ],
                                prebid: {
                                    groups: ["sspon-hp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/site-sponsorship/home-page"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sspon-hp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sspon-hp_Mobile"]
                    }]
                },
                "sspon-qp": {
                    name: "sspon-qp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [230, 60]
                                ],
                                prebid: {
                                    groups: ["sspon-qp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [230, 60]
                                ],
                                prebid: {
                                    groups: ["sspon-qp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/site-sponsorship/question-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sspon-qp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sspon-qp_Mobile"]
                    }]
                },
                "sspon-tp": {
                    name: "sspon-tp",
                    interstitial: !1,
                    tiles: [
                        [
                            [0, 0], {
                                sizes: [
                                    [230, 60]
                                ],
                                prebid: {
                                    groups: ["sspon-tp_Desktop"]
                                }
                            }
                        ],
                        [
                            [0, 0], {
                                sizes: [
                                    [230, 60]
                                ],
                                prebid: {
                                    groups: ["sspon-tp_Mobile"]
                                }
                            }
                        ]
                    ],
                    gpt: {
                        targeting: {},
                        outOfPage: !1,
                        adUnit: "XXX/site-sponsorship/tag-pages"
                    },
                    lazyLoad: {
                        enabled: !0,
                        pixels: 350
                    },
                    lazyFetch: {},
                    lockRefreshSize: !1,
                    prebidGroups: [{
                        viewport: [0, 0],
                        groups: ["sspon-tp_Desktop"]
                    }, {
                        viewport: [0, 0],
                        groups: ["sspon-tp_Mobile"]
                    }]
                }
            }
        }
    };
    const i = function() {
        if (document.currentScript.src) return document.currentScript.src;
        const e = document.getElementsByTagName("script");
        for (const i of e)
            if (i.src.includes("/mapping.base/htlbid.js")) return i.src;
        return console.warn("Unable to determine the original script URL for Aditude Loader"), ""
    }();

    function d() {
        if (!i) return void console.error("Unable to determine URL for fallback script.");
        console.warn("Loading bridge-htlbid.js.");
        const d = e.document.createElement("script");
        d.src = i.replace(/htlbid.js/, "bridge-htlbid.js"), d.async = !0, d.onerror = () => {
            console.error("Unable to load the htlbid wrapper.")
        }, d.src === i ? console.error("Unable to determine URL for htlbid wrapper.") : e.document.head.appendChild(d)
    }
    if (Object.keys(e.ADITUDE_WRAPPER_CONFIG).length > 0) {
        ["https://dn0qt3r0xannq.cloudfront.net/stackoverflow-M6HzSe6yue/mapping.base/prebid-load.js", "https://dn0qt3r0xannq.cloudfront.net/stackoverflow-M6HzSe6yue/mapping.base/prebid-wrapper.js"].forEach((i => {
                const d = e.document.createElement("link");
                d.setAttribute("rel", "preload"), d.setAttribute("as", "script"), d.setAttribute("href", i), e.document.head.appendChild(d)
            })),
            function() {
                const i = "https://dn0qt3r0xannq.cloudfront.net/stackoverflow-M6HzSe6yue/mapping.base/prebid-load.js";
                if (Array.from(document.scripts).some((e => {
                        try {
                            return new URL(e.src).href === new URL(i, document.baseURI).href
                        } catch {
                            return !1
                        }
                    }))) return void console.warn("Aditude Loader - attempted to load file multiple times, skipping:", i);
                const s = e.document.createElement("script");
                s.src = i, s.async = !0, s.onload = () => {
                    console.log("prebid-load.js loaded successfully."), e.tude = e.tude || {}, e.tude.cmd = e.tude.cmd || [], e.tude.cmd.push((() => {
                        e.tude.customJs((({
                            main: e,
                            events: i,
                            domContentLoaded: d,
                            loadScript: s,
                            useAditudePrebidFloors: t,
                            config: a
                        }) => {}))
                    }))
                }, s.onerror = () => {
                    console.warn("Failed to load prebid-load.js, loading fallback script."), d()
                }, e.document.head.appendChild(s)
            }()
    } else d()
})(window);