export default{
	//分享给好友
	onShareAppMessage(){
	    return {
	      title: "车辆管理"
	    }
	}
}