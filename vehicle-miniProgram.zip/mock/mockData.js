// Mock测试数据
module.exports = {
	// 用户相关
	user: {
		userInfo: {
			id: 1,
			username: "testuser",
			realName: "测试用户",
			phone: "13800138000",
			email: "test@example.com",
			avatar: "/static/images/avatar.png",
			deptName: "技术部",
			roleName: "普通用户",
			userType: 1
		},
		token: "mock_token_123456789"
	},

	// 车辆相关
	vehicles: [
		{
			id: 1,
			equipmentId: "1001",
			numberPlate: "粤A12345",
			plateNumber: "粤A12345", // 保持兼容性
			vehicleType: "轿车",
			brand: "丰田",
			model: "凯美瑞",
			status: "空闲",
			companyName: "行政部", // 所属部门
			location: "深圳市南山区科技园",
			driver: "张师傅",
			driverPhone: "13800138001",
			lat: 22.5431,
			lng: 113.9434,
			longitude: 113.9434, // 兼容性
			latitude: 22.5431, // 兼容性
			spd: 0,
			speed: 0,
			dre: 0,
			direction: 0,
			isOnline: 1, // 1=在线, 0=离线
			vehicleTaskStatus: 0, // 0=空闲, 1=任务中
			remark: "设备正常",
			updateTime: "2024-01-29 14:30:00"
		},
		{
			id: 2,
			equipmentId: "1002",
			numberPlate: "粤A67890",
			plateNumber: "粤A67890",
			vehicleType: "SUV",
			brand: "本田",
			model: "CR-V",
			status: "使用中",
			companyName: "销售部", // 所属部门
			location: "深圳市福田区中心区",
			driver: "李师傅",
			driverPhone: "13800138002",
			lat: 22.5267,
			lng: 114.0579,
			longitude: 114.0579,
			latitude: 22.5267,
			spd: 35,
			speed: 35,
			dre: 90,
			direction: 90,
			isOnline: 1,
			vehicleTaskStatus: 1,
			remark: "执行任务中",
			updateTime: "2024-01-29 14:28:00"
		},
		{
			id: 3,
			equipmentId: "1003",
			numberPlate: "粤A11111",
			plateNumber: "粤A11111",
			vehicleType: "商务车",
			brand: "别克",
			model: "GL8",
			status: "维修中",
			companyName: "技术部", // 所属部门
			location: "深圳市宝安区西乡街道",
			driver: "王师傅",
			driverPhone: "13800138003",
			lat: 22.5569,
			lng: 113.8288,
			longitude: 113.8288,
			latitude: 22.5569,
			spd: 0,
			speed: 0,
			dre: 0,
			direction: 0,
			isOnline: 0,
			vehicleTaskStatus: 0,
			remark: "维修保养中",
			updateTime: "2024-01-29 14:25:00"
		},
		{
			id: 4,
			equipmentId: "1004",
			numberPlate: "粤A22222",
			plateNumber: "粤A22222",
			vehicleType: "轿车",
			brand: "大众",
			model: "帕萨特",
			status: "空闲",
			companyName: "市场部", // 所属部门
			location: "深圳市龙岗区布吉街道",
			driver: "赵师傅",
			driverPhone: "13800138004",
			lat: 22.6056,
			lng: 114.1315,
			longitude: 114.1315,
			latitude: 22.6056,
			spd: 0,
			speed: 0,
			dre: 180,
			direction: 180,
			isOnline: 1,
			vehicleTaskStatus: 0,
			remark: "待命中",
			updateTime: "2024-01-29 14:32:00"
		},
		{
			id: 5,
			equipmentId: "1005",
			numberPlate: "粤A33333",
			plateNumber: "粤A33333",
			vehicleType: "面包车",
			brand: "五菱",
			model: "宏光",
			status: "离线",
			companyName: "后勤部", // 所属部门
			location: "深圳市罗湖区东门街道",
			driver: "钱师傅",
			driverPhone: "13800138005",
			lat: 22.5455,
			lng: 114.1244,
			longitude: 114.1244,
			latitude: 22.5455,
			spd: 0,
			speed: 0,
			dre: 270,
			direction: 270,
			isOnline: 0,
			vehicleTaskStatus: 0,
			remark: "设备离线",
			updateTime: "2024-01-29 13:45:00"
		}
	],

	// 用车申请
	vehicleApplications: [
		{
			id: 1,
			applyNo: "YC202401290001",
			applicant: "张三",
			department: "行政部",
			phone: "13800138000",
			purpose: "出差办事",
			destination: "广州市天河区",
			startTime: "2024-01-30 09:00:00",
			endTime: "2024-01-30 18:00:00",
			passengerCount: 2,
			status: "待审批",
			createTime: "2024-01-29 10:00:00",
			remark: "紧急出差"
		},
		{
			id: 2,
			applyNo: "YC202401290002",
			applicant: "李四",
			department: "销售部",
			phone: "13800138001",
			purpose: "客户拜访",
			destination: "东莞市南城区",
			startTime: "2024-01-31 14:00:00",
			endTime: "2024-01-31 17:00:00",
			passengerCount: 3,
			status: "已审批",
			createTime: "2024-01-29 11:30:00",
			remark: "重要客户"
		}
	],

	// 维修申请
	repairApplications: [
		{
			id: 1,
			repairNo: "WX202401290001",
			plateNumber: "粤A12345",
			applicant: "张师傅",
			phone: "13800138001",
			faultDescription: "发动机异响",
			urgencyLevel: "紧急",
			status: "待审批",
			createTime: "2024-01-29 09:00:00",
			estimatedCost: 2000,
			repairShop: "",
			remark: "行驶中发现异响"
		},
		{
			id: 2,
			repairNo: "WX202401290002",
			plateNumber: "粤A67890",
			applicant: "李师傅",
			phone: "13800138002",
			faultDescription: "轮胎磨损严重",
			urgencyLevel: "一般",
			status: "维修中",
			createTime: "2024-01-28 15:30:00",
			estimatedCost: 800,
			repairShop: "XX汽修厂",
			remark: "需更换四个轮胎"
		}
	],

	// 任务列表
	tasks: [
		{
			id: 1,
			taskNo: "RW202401290001",
			taskType: "用车审批",
			title: "张三的用车申请待审批",
			content: "申请用车前往广州出差",
			status: "待处理",
			priority: "高",
			createTime: "2024-01-29 10:00:00",
			deadline: "2024-01-29 18:00:00",
			relatedId: 1
		},
		{
			id: 2,
			taskNo: "RW202401290002",
			taskType: "维修审批",
			title: "粤A12345维修申请待审批",
			content: "发动机异响需要维修",
			status: "待处理",
			priority: "紧急",
			createTime: "2024-01-29 09:00:00",
			deadline: "2024-01-29 17:00:00",
			relatedId: 1
		}
	],

	// 驾驶员列表
	drivers: [
		{
			id: 1,
			name: "张师傅",
			phone: "13800138001",
			licenseType: "C1",
			experience: 10,
			status: "空闲",
			currentVehicle: "",
			companyName: "行政部" // 所属部门
		},
		{
			id: 2,
			name: "李师傅",
			phone: "13800138002",
			licenseType: "B2",
			experience: 15,
			status: "使用中",
			currentVehicle: "粤A67890",
			companyName: "销售部" // 所属部门
		},
		{
			id: 3,
			name: "王师傅",
			phone: "13800138003",
			licenseType: "A2",
			experience: 8,
			status: "空闲",
			currentVehicle: "",
			companyName: "技术部" // 所属部门
		}
	],

	// 轨迹数据
	trajectories: [
		{
			vehicleId: 1,
			plateNumber: "粤A12345",
			date: "2024-01-29",
			tracks: [
				{
					lat: 22.5431,
					lng: 113.9434,
					speed: 0,
					direction: 0,
					time: "09:00:00",
					address: "深圳市南山区科技园"
				},
				{
					lat: 22.5445,
					lng: 113.9456,
					speed: 25,
					direction: 45,
					time: "09:15:00",
					address: "深圳市南山区深南大道"
				},
				{
					lat: 22.5467,
					lng: 113.9478,
					speed: 35,
					direction: 90,
					time: "09:30:00",
					address: "深圳市南山区后海大道"
				}
			]
		}
	],

	// 组织架构
	orgTree: [
		{
			id: 1,
			name: "总公司",
			children: [
				{
					id: 2,
					name: "行政部",
					children: []
				},
				{
					id: 3,
					name: "销售部",
					children: [
						{
							id: 4,
							name: "华南销售组",
							children: []
						},
						{
							id: 5,
							name: "华北销售组",
							children: []
						}
					]
				},
				{
					id: 6,
					name: "技术部",
					children: []
				}
			]
		}
	]
}