#!/usr/bin/env node

/**
 * 定位功能修复验证脚本
 * 用于验证坐标系转换失败问题的修复效果
 */

console.log('🔧 定位功能修复验证')
console.log('==================')

// 检查修复的文件
const fs = require('fs')
const path = require('path')

const filesToCheck = [
    'pages/mock/locationTest.vue',
    'pages/mock/simpleMapTest.vue', 
    'static/js/locationService.js',
    'docs/map-troubleshooting.md'
]

console.log('\n📁 检查修复文件:')
filesToCheck.forEach(file => {
    const fullPath = path.join(process.cwd(), file)
    if (fs.existsSync(fullPath)) {
        console.log(`✅ ${file}`)
    } else {
        console.log(`❌ ${file} - 文件不存在`)
    }
})

// 检查关键修复点
console.log('\n🔍 检查关键修复点:')

// 检查locationTest.vue的修复
const locationTestPath = path.join(process.cwd(), 'pages/mock/locationTest.vue')
if (fs.existsSync(locationTestPath)) {
    const content = fs.readFileSync(locationTestPath, 'utf8')
    
    const checks = [
        { name: '多种坐标系配置', pattern: /altitude: false.*isHighAccuracy: false/s },
        { name: '增加超时时间', pattern: /timeout: 15000/ },
        { name: '配置日志输出', pattern: /console\.log.*尝试uni-app定位/ },
        { name: '降级策略', pattern: /tryUniLocationWithOptions/ }
    ]
    
    checks.forEach(check => {
        if (check.pattern.test(content)) {
            console.log(`✅ locationTest.vue - ${check.name}`)
        } else {
            console.log(`❌ locationTest.vue - ${check.name}`)
        }
    })
}

// 检查simpleMapTest.vue的修复
const simpleMapTestPath = path.join(process.cwd(), 'pages/mock/simpleMapTest.vue')
if (fs.existsSync(simpleMapTestPath)) {
    const content = fs.readFileSync(simpleMapTestPath, 'utf8')
    
    if (content.includes('altitude: false') && content.includes('isHighAccuracy: false')) {
        console.log('✅ simpleMapTest.vue - 坐标系修复已应用')
    } else {
        console.log('❌ simpleMapTest.vue - 坐标系修复未应用')
    }
}

// 检查locationService.js的修复
const locationServicePath = path.join(process.cwd(), 'static/js/locationService.js')
if (fs.existsSync(locationServicePath)) {
    const content = fs.readFileSync(locationServicePath, 'utf8')
    
    if (content.includes('tryLocationConfigs') && content.includes('配置${index + 1}')) {
        console.log('✅ locationService.js - 多配置降级策略已实现')
    } else {
        console.log('❌ locationService.js - 多配置降级策略未实现')
    }
}

// 检查文档更新
const troubleshootingPath = path.join(process.cwd(), 'docs/map-troubleshooting.md')
if (fs.existsSync(troubleshootingPath)) {
    const content = fs.readFileSync(troubleshootingPath, 'utf8')
    
    if (content.includes('坐标系转换失败') && content.includes('translate coordinate system fail')) {
        console.log('✅ map-troubleshooting.md - 坐标系问题文档已更新')
    } else {
        console.log('❌ map-troubleshooting.md - 坐标系问题文档未更新')
    }
}

console.log('\n🎯 修复要点总结:')
console.log('1. 关闭海拔获取 (altitude: false)')
console.log('2. 关闭高精度模式 (isHighAccuracy: false)')
console.log('3. 增加超时时间 (timeout: 15000)')
console.log('4. 尝试多种坐标系类型 (wgs84/gcj02/默认)')
console.log('5. H5平台优先使用浏览器原生定位')
console.log('6. 实现渐进式降级策略')

console.log('\n📋 测试建议:')
console.log('1. 访问 /pages/mock/locationTest 页面')
console.log('2. 点击"uni-app定位"按钮测试修复效果')
console.log('3. 查看控制台日志确认降级过程')
console.log('4. 如果仍失败，会自动切换到浏览器定位')

console.log('\n✨ 修复完成！请重新编译项目并测试定位功能。')