#!/usr/bin/env node

/**
 * Mock数据结构验证脚本
 * 验证地图数据API返回的数据结构是否正确
 */

console.log('🔧 Mock数据结构验证')
console.log('==================')

// 模拟导入mock数据
const mockData = {
	vehicles: [
		{
			id: 1,
			equipmentId: "1001",
			numberPlate: "粤A12345",
			isOnline: 1,
			vehicleTaskStatus: 0,
			lat: 22.5431,
			lng: 113.9434,
			spd: 0,
			dre: 0,
			location: "深圳市南山区科技园",
			remark: "设备正常"
		}
	]
}

console.log('\n📊 验证数据结构:')

// 验证必要字段
const requiredFields = [
	'equipmentId',
	'numberPlate', 
	'isOnline',
	'vehicleTaskStatus',
	'lat',
	'lng',
	'spd',
	'dre',
	'location',
	'remark'
]

const vehicle = mockData.vehicles[0]
let allFieldsPresent = true

requiredFields.forEach(field => {
	if (vehicle.hasOwnProperty(field)) {
		console.log(`✅ ${field}: ${vehicle[field]}`)
	} else {
		console.log(`❌ ${field}: 缺失`)
		allFieldsPresent = false
	}
})

// 验证数据类型
console.log('\n🔍 验证数据类型:')
console.log(`equipmentId类型: ${typeof vehicle.equipmentId} ${typeof vehicle.equipmentId === 'string' ? '✅' : '❌'}`)
console.log(`isOnline类型: ${typeof vehicle.isOnline} ${typeof vehicle.isOnline === 'number' ? '✅' : '❌'}`)
console.log(`vehicleTaskStatus类型: ${typeof vehicle.vehicleTaskStatus} ${typeof vehicle.vehicleTaskStatus === 'number' ? '✅' : '❌'}`)
console.log(`lat类型: ${typeof vehicle.lat} ${typeof vehicle.lat === 'number' ? '✅' : '❌'}`)
console.log(`lng类型: ${typeof vehicle.lng} ${typeof vehicle.lng === 'number' ? '✅' : '❌'}`)

// 验证常量值
console.log('\n📋 验证常量值:')
console.log(`isOnline值范围: ${vehicle.isOnline} ${[0, 1].includes(vehicle.isOnline) ? '✅' : '❌'}`)
console.log(`vehicleTaskStatus值范围: ${vehicle.vehicleTaskStatus} ${[0, 1].includes(vehicle.vehicleTaskStatus) ? '✅' : '❌'}`)

// 模拟API响应结构
const vehicles = mockData.vehicles
const apiResponse = {
	onlineCount: vehicles.filter(v => v.isOnline > 0).length,
	offlineCount: vehicles.filter(v => v.isOnline === 0).length,
	freeCount: vehicles.filter(v => v.vehicleTaskStatus === 0).length,
	taskCount: vehicles.filter(v => v.vehicleTaskStatus === 1).length,
	list: vehicles
}

console.log('\n📡 API响应结构:')
console.log(`onlineCount: ${apiResponse.onlineCount}`)
console.log(`offlineCount: ${apiResponse.offlineCount}`)
console.log(`freeCount: ${apiResponse.freeCount}`)
console.log(`taskCount: ${apiResponse.taskCount}`)
console.log(`list长度: ${apiResponse.list.length}`)

console.log('\n🎯 验证结果:')
if (allFieldsPresent) {
	console.log('✅ 所有必要字段都存在')
} else {
	console.log('❌ 存在缺失字段')
}

console.log('✅ Mock数据结构验证完成！')
console.log('\n📋 使用说明:')
console.log('1. 重新编译项目')
console.log('2. 登录系统')
console.log('3. 查看首页地图是否正常显示车辆标记')
console.log('4. 检查控制台是否还有forEach错误')